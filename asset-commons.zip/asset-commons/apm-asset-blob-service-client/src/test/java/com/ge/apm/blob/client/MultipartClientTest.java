/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.blob.client;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import com.ge.apm.blob.client.MultipartClient.RestResponse;

@PrepareForTest({ MultipartClient.class, HttpClientBuilder.class })
@RunWith(PowerMockRunner.class)
public class MultipartClientTest {

    String url;

    InputStream reqInputStream;

    InputStream resInputStream;

    Map<String, String> headersMap;

    Map<String, String> paramMap;

    CloseableHttpClient httpclient;

    CloseableHttpResponse response;

    HttpEntity entity;

    Header header;

    StatusLine statusLine;

    HttpPost httpPost;

    HttpClientBuilder httpClientBuilder;

    @Before
    public void setUp() {
        url = "http://test.com";
        String testReqString = "test\nstring";
        String testResString = "test-Content respones";
        reqInputStream = new ByteArrayInputStream(testReqString.getBytes(StandardCharsets.UTF_8));
        resInputStream = new ByteArrayInputStream(testResString.getBytes(StandardCharsets.UTF_8));
        headersMap = new HashMap<String, String>();
        paramMap = new HashMap<String, String>();
        httpclient = Mockito.mock(CloseableHttpClient.class);
        response = Mockito.mock(CloseableHttpResponse.class);
        entity = Mockito.mock(HttpEntity.class);
        header = Mockito.mock(Header.class);
        statusLine = Mockito.mock(StatusLine.class);
        httpPost = Mockito.mock(HttpPost.class);
        httpClientBuilder = Mockito.mock(HttpClientBuilder.class);
    }

    // @Test(expected = Exception.class)
    public void doPostTestException() throws IOException {
        String fileName = "test-file";
        headersMap.put("Content-Type", "application/json");
        paramMap.put("key1", "value1");
        MultipartClient.doPost(url, fileName, reqInputStream, headersMap, paramMap);
    }

    @Test
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void doPostTest() throws Exception {
        String fileName = "test-file";
        headersMap.put("Content-Type", "application/json");
        paramMap.put("key1", "value1");

        CloseableHttpClient closeableHttpClient = PowerMockito.mock(CloseableHttpClient.class);
        PowerMockito.mockStatic(HttpClientBuilder.class);
        PowerMockito.when(HttpClientBuilder.create()).thenReturn(httpClientBuilder);
        PowerMockito.when(httpClientBuilder.build()).thenReturn(closeableHttpClient);
        PowerMockito.whenNew(HttpPost.class).withAnyArguments().thenReturn(httpPost);

        Mockito.when(response.getEntity()).thenReturn(entity);
        Mockito.when(entity.getContentType()).thenReturn(header);
        Mockito.when(response.getStatusLine()).thenReturn(statusLine);
        Mockito.when(response.getEntity().getContentType().getValue()).thenReturn("application/json");
        Mockito.when(response.getEntity().getContent()).thenReturn(resInputStream);
        Mockito.when(response.getStatusLine().getStatusCode()).thenReturn(200);
        Mockito.when(closeableHttpClient.execute(Mockito.any(HttpPost.class))).thenReturn(response);
        RestResponse response = MultipartClient.doPost(url, fileName, reqInputStream, headersMap, paramMap);
        Assert.assertEquals(200, response.getStatus());
    }
}
