/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.blob.repository;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.CompleteMultipartUploadRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadResult;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PartETag;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.UploadPartRequest;
import com.amazonaws.services.s3.model.UploadPartResult;
import com.amazonaws.util.IOUtils;
import com.google.common.util.concurrent.UncheckedExecutionException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.ge.apm.blob.factory.BlobClientInfo;
import com.ge.apm.blob.factory.BlobClientInfoFactory;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.service.tenants.TenantInfoUtil;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class BlobServiceImplTest {

    @InjectMocks
    BlobServiceImpl blobService;

    @Mock
    BlobClientInfoFactory blobClientInfoFactory;

    @Mock
    TenantInfoUtil tenantInfoUtil;

    @Mock
    AmazonS3Client client;

    Log log = LogFactory.getLog(BlobServiceImplTest.class);

    private String tenantId = "501a5f1b-2b74-4ebe-8a64-aefa580ae3c0";

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        BlobClientInfo blobClientInfo = new BlobClientInfo("bucket-c6e2d120-98ca-4329-ae8c-82778012f38e", client);
        Mockito.doReturn(blobClientInfo).when(blobClientInfoFactory).generateBlobInfoContainer(anyString());
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test_Put() throws Exception {
        ArgumentCaptor<PutObjectRequest> objectCapture = ArgumentCaptor.forClass(PutObjectRequest.class);
        String objectKey = blobService.generateObjectKey("HtTestData", tenantId);
        InputStream stream = new ByteArrayInputStream("test data!".getBytes());
        blobService.put(stream, objectKey, tenantId, "noauth");

        verify(client, Mockito.times(1)).putObject(any());
        verify(client).putObject(objectCapture.capture());
        verify(client, Mockito.times(1)).getResourceUrl(eq("bucket-c6e2d120-98ca-4329-ae8c-82778012f38e"),
            eq(objectKey));
        assertEquals(objectCapture.getAllValues().size(), 1);
        PutObjectRequest putObjectRequest = objectCapture.getValue();

        assertEquals(IOUtils.toString(putObjectRequest.getInputStream()), "test data!");
        assertEquals(putObjectRequest.getKey(), objectKey);
        assertEquals(putObjectRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
        assertEquals(putObjectRequest.getMetadata().getSSEAlgorithm(), ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
    }

    @Test
    public void test_Put_ExecutionException() throws Exception {
        String objectKey = blobService.generateObjectKey("HtTestData", tenantId);
        InputStream stream = new ByteArrayInputStream("test data!".getBytes());
        Mockito.doThrow(new ServiceException("Unable to Get Service Credentials")).when(blobClientInfoFactory)
            .generateBlobInfoContainer(anyString());
        try {
            blobService.put(stream, objectKey, tenantId, "noauth");
        } catch (ServiceException ex) {
            Assert.assertEquals(ex.getMessage(), "Unable to upload file");
            return;
        }
        Assert.fail();
    }

    @Test
    public void test_Put_Concurrent() throws Exception {
        ArgumentCaptor<PutObjectRequest> objectCapture = ArgumentCaptor.forClass(PutObjectRequest.class);

        String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
        InputStream stream = new ByteArrayInputStream("test data!".getBytes());
        blobService.put(stream, objectKey1, tenantId, "noauth");

        String objectKey2 = blobService.generateObjectKey("HtTestData2", tenantId);
        stream = new ByteArrayInputStream("test data!".getBytes());
        blobService.put(stream, objectKey2, tenantId, "noauth");

        verify(blobClientInfoFactory, Mockito.times(1)).generateBlobInfoContainer(eq(tenantId));
        verify(client, Mockito.times(2)).putObject(any());
        verify(client, Mockito.times(2)).putObject(objectCapture.capture());
        assertEquals(objectCapture.getAllValues().size(), 2);

        PutObjectRequest putObjectRequest = objectCapture.getAllValues().get(0);
        assertEquals(IOUtils.toString(putObjectRequest.getInputStream()), "test data!");
        assertEquals(putObjectRequest.getKey(), objectKey1);
        assertEquals(putObjectRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
        assertEquals(putObjectRequest.getMetadata().getSSEAlgorithm(), ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);

        putObjectRequest = objectCapture.getAllValues().get(1);
        assertEquals(IOUtils.toString(putObjectRequest.getInputStream()), "test data!");
        assertEquals(putObjectRequest.getKey(), objectKey2);
        assertEquals(putObjectRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
        assertEquals(putObjectRequest.getMetadata().getSSEAlgorithm(), ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
    }

    @Test
    public void test_Put_Multiple_Tenants() throws Exception {
        ArgumentCaptor<PutObjectRequest> objectCapture = ArgumentCaptor.forClass(PutObjectRequest.class);

        InputStream stream = new ByteArrayInputStream("test data!".getBytes());
        String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
        blobService.put(stream, objectKey1, tenantId, "noauth");

        stream = new ByteArrayInputStream("test data!".getBytes());
        String objectKey2 = blobService.generateObjectKey("HtTestData2", "a3e2d1f0-38ca-4329-ae4c-25578017f38e");
        blobService.put(stream, objectKey2, "a3e2d1f0-38ca-4329-ae4c-25578017f38e", "noauth");

        verify(blobClientInfoFactory, Mockito.times(1)).generateBlobInfoContainer(eq(tenantId));
        verify(blobClientInfoFactory, Mockito.times(1)).generateBlobInfoContainer(
            eq("a3e2d1f0-38ca-4329-ae4c-25578017f38e"));
        verify(client, Mockito.times(2)).putObject(any());
        verify(client, Mockito.times(2)).putObject(objectCapture.capture());
        assertEquals(objectCapture.getAllValues().size(), 2);

        PutObjectRequest putObjectRequest = objectCapture.getAllValues().get(0);
        assertEquals(IOUtils.toString(putObjectRequest.getInputStream()), "test data!");
        assertEquals(putObjectRequest.getKey(), objectKey1);
        assertEquals(putObjectRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
        assertEquals(putObjectRequest.getMetadata().getSSEAlgorithm(), ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);

        putObjectRequest = objectCapture.getAllValues().get(1);
        assertEquals(IOUtils.toString(putObjectRequest.getInputStream()), "test data!");
        assertEquals(putObjectRequest.getKey(), objectKey2);
        assertEquals(putObjectRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
        assertEquals(putObjectRequest.getMetadata().getSSEAlgorithm(), ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
    }

    @Test
    public void test_Put_On_Exception() throws Exception {
        doThrow(new SdkClientException("Put Failed!")).when(client).putObject(any());
        InputStream stream = new ByteArrayInputStream("test data!".getBytes());
        try {
            String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
            blobService.put(stream, objectKey1, tenantId, "noauth");
        } catch (ServiceException ex1) {
            verify(blobClientInfoFactory, Mockito.times(1)).generateBlobInfoContainer(eq(tenantId));
            verify(client, Mockito.times(1)).putObject(any());
            stream = new ByteArrayInputStream("test data!".getBytes());
            try {
                String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
                blobService.put(stream, objectKey1, tenantId, "noauth");
            } catch (ServiceException ex2) {
                //Should generate s3 client on sub-sequent request as we cleared the cache on the previous exception
                verify(blobClientInfoFactory, Mockito.times(2)).generateBlobInfoContainer(eq(tenantId));
                verify(client, Mockito.times(2)).putObject(any());
                return;
            }
        }
        Assert.fail();
    }

    @Test(expected = ServiceException.class)
    public void test_Put_On_Empty_File() throws Exception {
        String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
        blobService.put(null, objectKey1, tenantId, "noauth");
    }

    @Test
    public void test_Put_Multipart_Single_Part_Less_Than_Max_Part_Size() throws Exception {
        ArgumentCaptor<PutObjectRequest> objectCapture = ArgumentCaptor.forClass(PutObjectRequest.class);
        ArgumentCaptor<InitiateMultipartUploadRequest> initMultipartUploadCapture = ArgumentCaptor.forClass(
            InitiateMultipartUploadRequest.class);
        InitiateMultipartUploadResult mockMultipartResult = mock(InitiateMultipartUploadResult.class);
        Mockito.doReturn(mockMultipartResult).when(client).initiateMultipartUpload(any());
        Mockito.doReturn("1").when(mockMultipartResult).getUploadId();

        InputStream stream = new ByteArrayInputStream("test data!".getBytes());
        String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
        blobService.putMultipart(stream, objectKey1, tenantId, "noauth");

        verify(client, Mockito.times(1)).initiateMultipartUpload(initMultipartUploadCapture.capture());
        verify(client, Mockito.times(1)).putObject(objectCapture.capture());
        verify(client, Mockito.never()).uploadPart(any());

        InitiateMultipartUploadRequest uploadRequest = initMultipartUploadCapture.getValue();
        assertEquals(uploadRequest.getKey(), objectKey1);
        assertEquals(uploadRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
        assertEquals(uploadRequest.getObjectMetadata().getSSEAlgorithm(),
            ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);

        PutObjectRequest putObjectRequest = objectCapture.getValue();
        assertEquals(IOUtils.toString(putObjectRequest.getInputStream()), "test data!");
        assertEquals(putObjectRequest.getKey(), objectKey1);
        assertEquals(putObjectRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
        assertEquals(putObjectRequest.getMetadata().getSSEAlgorithm(), ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
    }

    @Test
    public void test_Put_Multipart_Five_Parts() throws Exception {
        ArgumentCaptor<UploadPartRequest> objectCapture = ArgumentCaptor.forClass(UploadPartRequest.class);
        ArgumentCaptor<InitiateMultipartUploadRequest> initMultipartUploadCapture = ArgumentCaptor.forClass(
            InitiateMultipartUploadRequest.class);
        ArgumentCaptor<CompleteMultipartUploadRequest> completeMultipartCapture = ArgumentCaptor.forClass(
            CompleteMultipartUploadRequest.class);
        InitiateMultipartUploadResult mockMultipartResult = mock(InitiateMultipartUploadResult.class);
        Mockito.doReturn(mockMultipartResult).when(client).initiateMultipartUpload(any());
        Mockito.doReturn("1").when(mockMultipartResult).getUploadId();
        Mockito.doReturn(new UploadPartResult()).when(client).uploadPart(any());
        //Upload the content in 5 byte parts
        ReflectionTestUtils.setField(blobService, "maxPartSize", 5);

        InputStream stream = new ByteArrayInputStream("Part1Part2Part3Part4Part5".getBytes());
        String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
        blobService.putMultipart(stream, objectKey1, tenantId, "noauth");
        verify(client, Mockito.times(1)).getResourceUrl(eq("bucket-c6e2d120-98ca-4329-ae8c-82778012f38e"),
            eq(objectKey1));
        verify(client, Mockito.times(1)).initiateMultipartUpload(initMultipartUploadCapture.capture());
        verify(client, Mockito.never()).putObject(any());
        verify(client, Mockito.times(5)).uploadPart(objectCapture.capture());
        verify(client, Mockito.times(1)).completeMultipartUpload(completeMultipartCapture.capture());

        InitiateMultipartUploadRequest uploadRequest = initMultipartUploadCapture.getValue();
        assertEquals(uploadRequest.getKey(), objectKey1);
        assertEquals(uploadRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
        assertEquals(uploadRequest.getObjectMetadata().getSSEAlgorithm(),
            ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);

        List<UploadPartRequest> uploadPartRequestList = objectCapture.getAllValues();
        assertEquals(uploadPartRequestList.size(), 5);
        for (int i = 0; i < uploadPartRequestList.size(); i++) {
            UploadPartRequest uploadPartRequest = uploadPartRequestList.get(i);
            assertEquals(IOUtils.toString(uploadPartRequest.getInputStream()), "Part" + (i + 1));
            assertEquals(uploadPartRequest.getKey(), objectKey1);
            assertEquals(uploadPartRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
            assertEquals(uploadPartRequest.getPartNumber(), i + 1);
            assertEquals(uploadPartRequest.getPartSize(), 5);
        }
        List<PartETag> partTags = completeMultipartCapture.getValue().getPartETags();
        assertEquals(partTags.size(), 5);
    }

    @Test
    public void test_Put_Multipart_Two_Parts_With_Remainder() throws Exception {
        ArgumentCaptor<UploadPartRequest> objectCapture = ArgumentCaptor.forClass(UploadPartRequest.class);
        ArgumentCaptor<InitiateMultipartUploadRequest> initMultipartUploadCapture = ArgumentCaptor.forClass(
            InitiateMultipartUploadRequest.class);
        ArgumentCaptor<CompleteMultipartUploadRequest> completeMultipartCapture = ArgumentCaptor.forClass(
            CompleteMultipartUploadRequest.class);
        InitiateMultipartUploadResult mockMultipartResult = mock(InitiateMultipartUploadResult.class);
        Mockito.doReturn(mockMultipartResult).when(client).initiateMultipartUpload(any());
        Mockito.doReturn("1").when(mockMultipartResult).getUploadId();
        Mockito.doReturn(new UploadPartResult()).when(client).uploadPart(any());
        //Upload the content in 5 byte parts
        ReflectionTestUtils.setField(blobService, "maxPartSize", 5);

        InputStream stream = new ByteArrayInputStream("Part1Par".getBytes());
        String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
        blobService.putMultipart(stream, objectKey1, tenantId, "noauth");
        verify(client, Mockito.times(1)).initiateMultipartUpload(initMultipartUploadCapture.capture());
        verify(client, Mockito.never()).putObject(any());
        verify(client, Mockito.times(2)).uploadPart(objectCapture.capture());
        verify(client, Mockito.times(1)).completeMultipartUpload(completeMultipartCapture.capture());

        InitiateMultipartUploadRequest uploadRequest = initMultipartUploadCapture.getValue();
        assertEquals(uploadRequest.getKey(), objectKey1);
        assertEquals(uploadRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
        assertEquals(uploadRequest.getObjectMetadata().getSSEAlgorithm(),
            ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);

        List<UploadPartRequest> uploadPartRequestList = objectCapture.getAllValues();
        List<String> partContents = Arrays.asList("Part1", "Par");
        assertEquals(uploadPartRequestList.size(), 2);
        for (int i = 0; i < uploadPartRequestList.size(); i++) {
            UploadPartRequest uploadPartRequest = uploadPartRequestList.get(i);
            assertEquals(IOUtils.toString(uploadPartRequest.getInputStream()), partContents.get(i));
            assertEquals(uploadPartRequest.getKey(), objectKey1);
            assertEquals(uploadPartRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
            assertEquals(uploadPartRequest.getPartNumber(), i + 1);
            assertEquals(uploadPartRequest.getPartSize(), partContents.get(i).length());
        }
        List<PartETag> partTags = completeMultipartCapture.getValue().getPartETags();
        assertEquals(partTags.size(), 2);
    }

    @Test
    public void test_Put_Multipart_Equal_To_Max_Part_Size() throws Exception {
        ArgumentCaptor<UploadPartRequest> objectCapture = ArgumentCaptor.forClass(UploadPartRequest.class);
        ArgumentCaptor<InitiateMultipartUploadRequest> initMultipartUploadCapture = ArgumentCaptor.forClass(
            InitiateMultipartUploadRequest.class);
        ArgumentCaptor<CompleteMultipartUploadRequest> completeMultipartCapture = ArgumentCaptor.forClass(
            CompleteMultipartUploadRequest.class);
        InitiateMultipartUploadResult mockMultipartResult = mock(InitiateMultipartUploadResult.class);
        Mockito.doReturn(mockMultipartResult).when(client).initiateMultipartUpload(any());
        Mockito.doReturn("1").when(mockMultipartResult).getUploadId();
        Mockito.doReturn(new UploadPartResult()).when(client).uploadPart(any());
        //Upload the content in 5 byte parts
        ReflectionTestUtils.setField(blobService, "maxPartSize", 5);

        InputStream stream = new ByteArrayInputStream("Part1".getBytes());
        String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
        blobService.putMultipart(stream, objectKey1, tenantId, "noauth");
        verify(client, Mockito.times(1)).initiateMultipartUpload(initMultipartUploadCapture.capture());
        verify(client, Mockito.never()).putObject(any());
        verify(client, Mockito.times(1)).uploadPart(objectCapture.capture());
        verify(client, Mockito.times(1)).completeMultipartUpload(completeMultipartCapture.capture());

        InitiateMultipartUploadRequest uploadRequest = initMultipartUploadCapture.getValue();
        assertEquals(uploadRequest.getKey(), objectKey1);
        assertEquals(uploadRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
        assertEquals(uploadRequest.getObjectMetadata().getSSEAlgorithm(),
            ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);

        List<UploadPartRequest> uploadPartRequestList = objectCapture.getAllValues();
        List<String> partContents = Arrays.asList("Part1");
        assertEquals(uploadPartRequestList.size(), 1);
        for (int i = 0; i < uploadPartRequestList.size(); i++) {
            UploadPartRequest uploadPartRequest = uploadPartRequestList.get(i);
            assertEquals(IOUtils.toString(uploadPartRequest.getInputStream()), partContents.get(i));
            assertEquals(uploadPartRequest.getKey(), objectKey1);
            assertEquals(uploadPartRequest.getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
            assertEquals(uploadPartRequest.getPartNumber(), i + 1);
            assertEquals(uploadPartRequest.getPartSize(), partContents.get(i).length());
        }
        List<PartETag> partTags = completeMultipartCapture.getValue().getPartETags();
        assertEquals(partTags.size(), 1);
    }

    @Test
    public void test_Put_Multipart_Exception_On_Upload_Part() throws Exception {
        InitiateMultipartUploadResult mockMultipartResult = mock(InitiateMultipartUploadResult.class);
        Mockito.doReturn(mockMultipartResult).when(client).initiateMultipartUpload(any());
        Mockito.doReturn("1").when(mockMultipartResult).getUploadId();
        doThrow(new SdkClientException("Test Exception")).when(client).uploadPart(any());
        //Upload the content in 5 byte parts
        ReflectionTestUtils.setField(blobService, "maxPartSize", 5);

        InputStream stream = new ByteArrayInputStream("Part1Part2".getBytes());
        try {
            String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
            blobService.putMultipart(stream, objectKey1, tenantId, "noauth");
        } catch (ServiceException ex1) {
            verify(blobClientInfoFactory, Mockito.times(1)).generateBlobInfoContainer(eq(tenantId));
            verify(client, Mockito.times(1)).uploadPart(any());
            stream = new ByteArrayInputStream("Part1".getBytes());
            try {
                doThrow(new SdkClientException("Test Exception")).when(client).putObject(any());
                String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
                blobService.put(stream, objectKey1, tenantId, "noauth");
            } catch (ServiceException ex2) {
                //Should generate s3 client on sub-sequent request as we cleared the cache on the previous exception
                verify(blobClientInfoFactory, Mockito.times(2)).generateBlobInfoContainer(eq(tenantId));
                verify(client, Mockito.times(1)).putObject(any());
                verify(client, Mockito.times(1)).uploadPart(any());
                return;
            }
        }
        Assert.fail();
    }

    @Test
    public void test_Get_No_Range() {
        ArgumentCaptor<GetObjectRequest> getObjectRequestCaptor = ArgumentCaptor.forClass(GetObjectRequest.class);
        S3Object s3Object = mock(S3Object.class);
        Mockito.doReturn(s3Object).when(client).getObject(any());
        String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
        blobService.get(objectKey1, null, tenantId, "noauth");
        verify(client, Mockito.times(1)).getObject(getObjectRequestCaptor.capture());
        verify(blobClientInfoFactory, Mockito.times(1)).generateBlobInfoContainer(eq(tenantId));
        assertEquals(getObjectRequestCaptor.getValue().getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
        assertEquals(getObjectRequestCaptor.getValue().getKey(), objectKey1);
        Assert.assertNull(getObjectRequestCaptor.getValue().getRange());
    }

    @Test
    public void test_Get_With_Valid_Range() {
        ArgumentCaptor<GetObjectRequest> getObjectRequestCaptor = ArgumentCaptor.forClass(GetObjectRequest.class);
        S3Object s3Object = mock(S3Object.class);
        Mockito.doReturn(s3Object).when(client).getObject(any());
        String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
        blobService.get(objectKey1, "0:4", tenantId, "noauth");
        verify(client, Mockito.times(1)).getObject(getObjectRequestCaptor.capture());
        verify(blobClientInfoFactory, Mockito.times(1)).generateBlobInfoContainer(eq(tenantId));
        assertEquals(getObjectRequestCaptor.getValue().getBucketName(), "bucket-c6e2d120-98ca-4329-ae8c-82778012f38e");
        assertEquals(getObjectRequestCaptor.getValue().getKey(), objectKey1);
        Assert.assertArrayEquals(getObjectRequestCaptor.getValue().getRange(), new long[] { 0, 4 });
    }

    @Test(expected = ServiceException.class)
    public void test_Get_With_Invalid_Range() {
        S3Object s3Object = mock(S3Object.class);
        Mockito.doReturn(s3Object).when(client).getObject(any());
        String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
        blobService.get(objectKey1, "d:4", tenantId, "noauth");
    }

    @Test
    public void test_Get_With_Sdk_Exception() {
        doThrow(new SdkClientException("Test Exception")).when(client).getObject(any());
        try {
            String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
            blobService.get(objectKey1, "1:4", tenantId, "noauth");
        } catch (ServiceException ex1) {
            verify(blobClientInfoFactory, Mockito.times(1)).generateBlobInfoContainer(eq(tenantId));
            try {
                String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
                blobService.get(objectKey1, "1:4", tenantId, "noauth");
            } catch (ServiceException ex2) {
                verify(blobClientInfoFactory, Mockito.times(2)).generateBlobInfoContainer(eq(tenantId));
                return;
            }
        }
        Assert.fail();
    }

    @Test
    public void test_Get_List_Of_Blobs() {
        ArgumentCaptor<String> bucketNameCapture = ArgumentCaptor.forClass(String.class);
        ObjectListing objectListing = mock(ObjectListing.class);
        List<S3ObjectSummary> objSumList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            objSumList.add(new S3ObjectSummary());
            String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
            objSumList.get(i).setKey(objectKey1);
        }
        Mockito.doReturn(objectListing).when(client).listObjects(Matchers.anyString());
        Mockito.doReturn(objSumList).when(objectListing).getObjectSummaries();
        List<String> returnVal = blobService.get(tenantId, "noauth");
        verify(blobClientInfoFactory, Mockito.times(1)).generateBlobInfoContainer(eq(tenantId));
        for (int i = 0; i < objSumList.size(); i++) {
            assertEquals(objSumList.get(i).getKey(), returnVal.get(i));
        }
        verify(client, Mockito.times(1)).listObjects(bucketNameCapture.capture());
        assertEquals("bucket-c6e2d120-98ca-4329-ae8c-82778012f38e", bucketNameCapture.getValue());
    }

    @Test
    public void test_Get_List_Of_Blobs_Sdk_Exception() {
        ArgumentCaptor<String> bucketNameCapture = ArgumentCaptor.forClass(String.class);
        doThrow(new SdkClientException("Test Exception")).when(client).listObjects(Matchers.anyString());
        try {
            blobService.get(tenantId, "noauth");
        } catch (ServiceException ex1) {
            verify(blobClientInfoFactory, Mockito.times(1)).generateBlobInfoContainer(eq(tenantId));
            verify(client, Mockito.times(1)).listObjects(bucketNameCapture.capture());
            assertEquals("bucket-c6e2d120-98ca-4329-ae8c-82778012f38e", bucketNameCapture.getValue());
            try {
                blobService.get(tenantId, "noauth");
            } catch (ServiceException ex2) {
                verify(blobClientInfoFactory, Mockito.times(2)).generateBlobInfoContainer(eq(tenantId));
                verify(client, Mockito.times(2)).listObjects(bucketNameCapture.capture());
                assertEquals("bucket-c6e2d120-98ca-4329-ae8c-82778012f38e", bucketNameCapture.getAllValues().get(1));
                return;
            }
        }
        Assert.fail();
    }

    @Test
    public void test_Delete() {
        String objectKey1 = blobService.generateObjectKey("HtTestFile.zip", tenantId);
        blobService.delete(objectKey1, tenantId, "noauth");
        verify(client).deleteObject(eq("bucket-c6e2d120-98ca-4329-ae8c-82778012f38e"), eq(objectKey1));
    }

    @Test
    public void test_Delete_Sdk_Exception() {
        String objectKey1 = blobService.generateObjectKey("HtTestFile.zip", tenantId);
        doThrow(new SdkClientException("Test Exception")).when(client).deleteObject(
            eq("bucket-c6e2d120-98ca-4329-ae8c-82778012f38e"), eq(objectKey1));
        try {
            blobService.delete(objectKey1, tenantId, "noauth");
        } catch (ServiceException ex1) {
            verify(blobClientInfoFactory, Mockito.times(1)).generateBlobInfoContainer(eq(tenantId));
            verify(client).deleteObject(eq("bucket-c6e2d120-98ca-4329-ae8c-82778012f38e"), eq(objectKey1));
            String objectKey2 = blobService.generateObjectKey("HtTestFile2.zip", tenantId);
            try {
                doThrow(new SdkClientException("Test Exception")).when(client).deleteObject(
                    eq("bucket-c6e2d120-98ca-4329-ae8c-82778012f38e"), eq(objectKey2));
                blobService.delete(objectKey2, tenantId, "noauth");
            } catch (ServiceException ex2) {
                verify(blobClientInfoFactory, Mockito.times(2)).generateBlobInfoContainer(eq(tenantId));
                verify(client).deleteObject(eq("bucket-c6e2d120-98ca-4329-ae8c-82778012f38e"), eq(objectKey2));
                return;
            }
        }
        Assert.fail();
    }

    @Test(expected = ServiceException.class)
    public void put_InvalidKey() throws Exception {
        String objectKey1 = blobService.generateObjectKey("HtTestData1", tenantId);
        InputStream stream = new ByteArrayInputStream("test data!".getBytes());
        blobService.put(stream, "invalid" + objectKey1, tenantId, "noauth");
    }

    @Test(expected = ServiceException.class)
    public void putMultipart_InvalidKey() throws Exception {
        InputStream stream = new ByteArrayInputStream("test data!".getBytes());
        blobService.putMultipart(stream, "HtTestData1", tenantId, "noauth");
    }

    @Test(expected = ServiceException.class)
    public void delete_InvalidKey() throws Exception {
        blobService.delete(tenantId + "/HtTestData1", tenantId, "noauth");
    }

    @Test(expected = ServiceException.class)
    public void get_InvalidKey() throws Exception {
        blobService.get(tenantId + "/HtTestData1", null, tenantId, "noauth");
    }

    @Test
    public void blobExists_DoesNot() {
        Mockito.doThrow(
            new ServiceException(ErrorProvider.findError(ErrorConstants.BLOB_ERROR_DOES_NOT_EXIST), tenantId)).when(
            blobClientInfoFactory).generateBlobInfoContainer(eq(tenantId));
        Assert.assertEquals(blobService.blobExists(tenantId), false);
    }

    @Test
    public void blobExists_Exists() {
        Assert.assertEquals(blobService.blobExists(tenantId), true);
    }

    @Test(expected = UncheckedExecutionException.class)
    public void blobExists_UncheckedException() {
        Mockito.doThrow(new ServiceException(ErrorProvider.findError(ErrorConstants.BLOB_ERROR), tenantId)).when(
            blobClientInfoFactory).generateBlobInfoContainer(eq(tenantId));
        blobService.blobExists(tenantId);
    }
}