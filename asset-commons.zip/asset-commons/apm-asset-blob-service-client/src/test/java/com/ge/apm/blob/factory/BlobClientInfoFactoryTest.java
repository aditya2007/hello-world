/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.blob.factory;

import com.amazonaws.services.s3.AmazonS3;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.service.properties.ApmProperties;
import com.ge.apm.service.instances.ServiceInstanceInfo;
import com.ge.apm.service.tenants.TenantInfoUtil;
import com.ge.asset.commons.errorprovider.ErrorConstants;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class BlobClientInfoFactoryTest {

    @InjectMocks
    BlobClientInfoFactory blobClientInfoFactory;

    @Mock
    TenantInfoUtil tenantInfoUtil;

    @Mock
    ApmProperties apmProperties;

    @Mock
    AmazonS3 client;

    String tenantUuid = "501a5f1b-2b74-4ebe-8a64-aefa580ae3c0";

    @Before
    public void setUp() throws Exception {
        blobClientInfoFactory = spy(new BlobClientInfoFactory());
        MockitoAnnotations.initMocks(this);
        doReturn("/credentials/access_key_id").when(apmProperties).getPxBlobServiceAccessKeyIdPath();
        doReturn("/credentials/bucket_name").when(apmProperties).getPxBlobServiceBucketNamePath();
        doReturn("/credentials/host").when(apmProperties).getPxBlobServiceHostPath();
        doReturn("/credentials/secret_access_key").when(apmProperties).getPxBlobServiceSecretAccessKeyPath();
        doReturn("/credentials/url").when(apmProperties).getPxBlobServiceUrlPath();
        doReturn("predix-blobstore").when(apmProperties).getPxBlobServiceName();
        doReturn(client).when(blobClientInfoFactory).createS3Client(eq("bestUserEver"), eq("badPassword777"),
            eq("https://aws-us7.com"));
    }

    @Test
    public void generateBlobInfoContainer_ServiceInfoDoesNotExist() throws Exception {
        doReturn(null).when(tenantInfoUtil).getServiceInstanceInfo(eq(tenantUuid), any());
        try {
            blobClientInfoFactory.generateBlobInfoContainer(tenantUuid);
        } catch (ServiceException ex) {
            Assert.assertEquals(ex.getCode(), ErrorConstants.BLOB_ERROR_DOES_NOT_EXIST);
            return;
        }
        Assert.fail();
    }

    @Test
    public void generateBlobInfoContainer_RefreshServiceInfo() throws Exception {
        ServiceInstanceInfo serviceInstanceInfo = generateServiceInfo();
        when(tenantInfoUtil.getServiceInstanceInfo(eq(tenantUuid), any())).thenReturn(
            serviceInstanceInfo);
        BlobClientInfo blobInfo = blobClientInfoFactory.generateBlobInfoContainer(tenantUuid);
        Assert.assertEquals(blobInfo.getBucketName(), "bucket-234-234-234-234-234");
        verify(tenantInfoUtil, times(1)).getServiceInstanceInfo(eq(tenantUuid), eq("predix-blobstore"));
    }

    private ServiceInstanceInfo generateServiceInfo() {
        ServiceInstanceInfo serviceInstanceInfo = new ServiceInstanceInfo();
        serviceInstanceInfo.setServiceName("predix-blobstore");
        serviceInstanceInfo.getUris().put("/credentials/url", "https://bucket-234-234-234-234-234.aws-us7.com");
        serviceInstanceInfo.getCustomProperties().put("/credentials/bucket_name", "bucket-234-234-234-234-234");
        serviceInstanceInfo.getCustomProperties().put("/credentials/host", "aws-us7.com");
        serviceInstanceInfo.getCustomProperties().put("/credentials/access_key_id", "bestUserEver");
        serviceInstanceInfo.getCustomProperties().put("/credentials/secret_access_key", "badPassword777");
        return serviceInstanceInfo;
    }
}