/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.blob.client;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import javax.ws.rs.core.Response.Status;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.http.HttpStatus;
import org.apache.http.HttpVersion;
import org.apache.http.ProtocolVersion;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicStatusLine;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.junit.Assert.fail;

/**
 * @author 212312392
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({MultipartClient.class, HttpClients.class})
public class BlobArchiveClientTest {

    @Test(expected = ValidationFailedException.class)
    public void testArchiveBlob() throws ValidationFailedException, IOException {
        BlobArchiveClient blobArchiveClient = new BlobArchiveClient("http://www.ge.com");
        PowerMockito.mockStatic(MultipartClient.class);
        Exchange exchange = PowerMockito.mock(Exchange.class);
        InputStream file = PowerMockito.mock(InputStream.class);
        Message msg = PowerMockito.mock(Message.class);
        PowerMockito.when(exchange.getIn()).thenReturn(msg);
        Message msgOut = PowerMockito.mock(Message.class);
        PowerMockito.when(exchange.getOut()).thenReturn(msgOut);
        PowerMockito.when(msg.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("uuid");
        PowerMockito.when(msg.getHeader("parentEntityType", String.class)).thenReturn("assettest");
        PowerMockito.when(msg.getHeader(Exchange.FILE_NAME, String.class)).thenReturn("samplefile");
        PowerMockito.when(msg.getHeader(MessageConstants.AUTHORIZATION, String.class)).thenReturn("user");
        PowerMockito.when(msg.getHeader(RequestContext.TENANT, String.class)).thenReturn("tenant");
        InputStream stream = PowerMockito.mock(InputStream.class);
        PowerMockito.when(msg.getBody(InputStream.class)).thenReturn(stream);
        Map<String, String> headersMap = new HashMap<>();
        headersMap.put(RequestContext.AUTHORIZATION, "user");
        headersMap.put(RequestContext.TENANT, "tenant");

        try {
            PowerMockito.when(MultipartClient
                    .doPost(Matchers.anyString(), Matchers.anyString(), Matchers.any(), Matchers.any(), Matchers.any()))
                    .thenReturn(new MultipartClient.RestResponse("", "", HttpStatus.SC_NOT_FOUND));
            ReflectionUtils.setField(BlobArchiveClient.class, blobArchiveClient, "blobStorageUrl", "http://www.ge.com");
        } catch (Exception e) {
            fail(e.getLocalizedMessage());
        }

        blobArchiveClient.archiveBlob(exchange, file);
    }

    @Test(expected = ValidationFailedException.class)
    public void testDownloadBlob() throws ValidationFailedException, IOException {
        BlobArchiveClient blobArchiveClient = new BlobArchiveClient("http://www.ge.com");
        PowerMockito.mockStatic(HttpClients.class);
        CloseableHttpClient httpClient = PowerMockito.mock(CloseableHttpClient.class);
        CloseableHttpResponse httpResponse = PowerMockito.mock(CloseableHttpResponse.class);
        PowerMockito.when(HttpClients.createSystem()).thenReturn(httpClient);
        Exchange exchange = PowerMockito.mock(Exchange.class);
        String fileUrl = "http://blobDownloadLink";
        Message msg = PowerMockito.mock(Message.class);
        PowerMockito.when(exchange.getIn()).thenReturn(msg);
        PowerMockito.when(msg.getHeader(MessageConstants.AUTHORIZATION, String.class)).thenReturn("user");
        PowerMockito.when(msg.getHeader(RequestContext.TENANT, String.class)).thenReturn("tenant");

        PowerMockito.doReturn(httpResponse).when(httpClient).execute(Matchers.any());
        PowerMockito.doReturn(new BasicStatusLine(
                new ProtocolVersion("HTTP", HttpVersion.HTTP_1_1.getMajor(), HttpVersion.HTTP_1_1.getMinor()),
                Status.NOT_FOUND.getStatusCode(), Status.NOT_FOUND.getReasonPhrase())).when(httpResponse).getStatusLine();

        blobArchiveClient.downloadBlob(exchange, fileUrl);
    }

}
