/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.blob.repository;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import com.amazonaws.SdkBaseException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.AbortMultipartUploadRequest;
import com.amazonaws.services.s3.model.CompleteMultipartUploadRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadResult;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PartETag;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.UploadPartRequest;
import com.amazonaws.util.IOUtils;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.util.concurrent.UncheckedExecutionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ge.apm.blob.factory.BlobClientInfo;
import com.ge.apm.blob.factory.BlobClientInfoFactory;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.service.tenants.TenantInfoUtil;
import com.ge.asset.commons.errorprovider.ErrorConstants;

@Component
@Slf4j
public class BlobServiceImpl implements IBlobService {

    @Autowired
    BlobClientInfoFactory blobClientInfoFactory;

    @Autowired
    TenantInfoUtil tenantInfoUtil;

    @Value("${asset.blob.cache.expiration:60}")
    private Integer cacheExpireTimeInMinutes;

    private final LoadingCache<String, BlobClientInfo> blobInfoCache = CacheBuilder.newBuilder().maximumSize(10000)
        .expireAfterWrite(cacheExpireTimeInMinutes == null ? 60 : cacheExpireTimeInMinutes, TimeUnit.MINUTES)
        .concurrencyLevel(10).build(new CacheLoader<String, BlobClientInfo>() {
            @Override
            public BlobClientInfo load(String tenantId) throws Exception {
                return blobClientInfoFactory.generateBlobInfoContainer(tenantId);
            }
        });

    //50 * 1024 * 1024 = 50MB
    private int maxPartSize = 52428800;

    private static final String APPLICATION_OCTET_STREAM = "application/octet-stream";

    private final String delimiter = "/";

    private final String logicalSubFolder = "apm-asset";

    /**
     * Method to upload relatively small files to Predix Blob
     *
     * @param content File to be uploaded
     * @param key Key that will reference the file in the bucket
     * @param tenantId Tenant UUID
     * @param authorization Authorization token
     *
     * @return String Resource url
     */
    public String put(InputStream content, String key, String tenantId, String authorization) throws IOException {
        if (content == null) {
            log.error("BlobService put(): Empty file provided");
            throw new ServiceException("The file staged for upload is null");
        }
        validateObjectKey(key, tenantId);

        byte[] b = IOUtils.toByteArray(content);
        try (ByteArrayInputStream byteStream = new ByteArrayInputStream(b)) {
            BlobClientInfo blobInfo = getBlobInfoContainer(tenantId);
            AmazonS3 client = blobInfo.getS3Client();

            ObjectMetadata objectMetadata = createObjectMetadata(getContentType(b), b.length);
            PutObjectRequest putObjectRequest = new PutObjectRequest(blobInfo.getBucketName(), key, byteStream,
                objectMetadata);
            client.putObject(putObjectRequest);
            String url = ((AmazonS3Client) client).getResourceUrl(blobInfo.getBucketName(), key);
            log.info("Tenant {} uploaded blob to {}", tenantId, url);
            return url;
        } catch (Exception ex) {
            clearServiceInfoForTenant(tenantId);
            throw new ServiceException("Unable to upload file", ex);
        } finally {
            content.close();
        }
    }

    /**
     * Adds a new Blob to the bucket in the Object Store
     *
     * @param content File to be uploaded
     * @param key Key that will reference the file in the bucket
     * @param tenantId Tenant UUID
     * @param authorization Authorization token
     */
    public String putMultipart(InputStream content, String key, String tenantId, String authorization)
        throws IOException {
        if (content == null) {
            log.error("BlobService put(): Empty file provided");
            throw new ServiceException("The file staged for upload is null");
        }
        validateObjectKey(key, tenantId);

        try {
            BlobClientInfo blobInfo = getBlobInfoContainer(tenantId);
            AmazonS3 client = blobInfo.getS3Client();
            String bucket = blobInfo.getBucketName();
            List<PartETag> partETags = new ArrayList<>();

            ObjectMetadata objectMetadata = new ObjectMetadata();
            objectMetadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
            InitiateMultipartUploadRequest initRequest = new InitiateMultipartUploadRequest(bucket, key,
                objectMetadata);
            InitiateMultipartUploadResult initResponse = client.initiateMultipartUpload(initRequest);

            initiateMultipartUpload(content, key, client, bucket, partETags, initResponse);
            String url = ((AmazonS3Client) client).getResourceUrl(blobInfo.getBucketName(), key);
            log.info("Tenant {} uploaded blob to {}", tenantId, url);
            return url;
        } catch (Exception ex) {
            clearServiceInfoForTenant(tenantId);
            throw new ServiceException("Unable to upload multipart file", ex);
        } finally {
            content.close();
        }
    }

    /**
     * Retrieve file from Predix Blob
     *
     * @param key Key used to retrieve the file from the bucket
     * @param range Specified range bytes of an object to download
     * @param tenantId Tenant UUID
     * @param authorization Authorization token
     */
    public InputStream get(String key, String range, String tenantId, String authorization) {
        validateObjectKey(key, tenantId);

        try {
            BlobClientInfo blobInfo = getBlobInfoContainer(tenantId);
            AmazonS3 client = blobInfo.getS3Client();
            String bucket = blobInfo.getBucketName();

            if (range != null && !range.isEmpty()) {
                String[] r = range.split(":");
                if (r.length != 2) {
                    throw new ServiceException("Invalid range format in get request");
                }
                long start = Long.parseLong(r[0]);
                long end = Long.parseLong(r[1]);

                GetObjectRequest rangeObjectRequest = new GetObjectRequest(bucket, key);
                rangeObjectRequest.setRange(start, end);
                S3Object objectPortion = client.getObject(rangeObjectRequest);
                log.info("Tenant {} retrieved blob from {}", tenantId,
                    ((AmazonS3Client) client).getResourceUrl(bucket, key));
                return objectPortion.getObjectContent();
            } else {
                S3Object object = client.getObject(new GetObjectRequest(bucket, key));
                log.info("Tenant {} retrieved blob from {}", tenantId,
                    ((AmazonS3Client) client).getResourceUrl(bucket, key));
                return object.getObjectContent();
            }
        } catch (NumberFormatException ex) {
            throw new ServiceException("Invalid range specified ", ex);
        } catch (Exception ex) {
            log.error("Exception Occurred in get(): " + ex.getMessage());
            clearServiceInfoForTenant(tenantId);
            throw new ServiceException("Unable to get file", ex);
        }
    }

    /**
     * Gets the list of available Blobs for the bucket from the BlobStore.
     *
     * @param tenantId Tenant UUID
     * @param authorization Authorization token
     *
     * @return List<BlobFile> List of Blobs
     */
    public List<String> get(String tenantId, String authorization) {
        List<String> objs = new ArrayList<>();
        try {
            BlobClientInfo blobInfo = getBlobInfoContainer(tenantId);
            // Get the List from BlobStore
            ObjectListing objectList = blobInfo.getS3Client().listObjects(blobInfo.getBucketName());

            for (S3ObjectSummary objectSummary : objectList.getObjectSummaries()) {

                objs.add(objectSummary.getKey());
            }
        } catch (Exception ex) {
            log.error("Exception occurred in get(): " + ex.getMessage());
            clearServiceInfoForTenant(tenantId);
            throw new ServiceException("Unable to get list of available blobs for the provided tenant", ex);
        }

        return objs;
    }

    /**
     * Delete the Blob from the bound bucket
     *
     * @param key String of file to be removed
     * @param tenantId Tenant UUID
     * @param authorization Authorization token
     */
    public void delete(String key, String tenantId, String authorization) {
        validateObjectKey(key, tenantId);
        try {
            BlobClientInfo blobInfo = getBlobInfoContainer(tenantId);
            String bucket = blobInfo.getBucketName();
            blobInfo.getS3Client().deleteObject(bucket, key);
            if (log.isDebugEnabled()) {
                log.debug("delete(): Successfully deleted the file = " + key);
            }
        } catch (Exception ex) {
            log.error("delete(): Exception Occurred in delete(): " + ex.getMessage());
            clearServiceInfoForTenant(tenantId);
            throw new ServiceException("Unable to delete the blob for the provided tenant", ex);
        }
    }

    /**
     * @param uniqueIdentifier A unique identifier to represent part of the object key
     * @param tenantId Tenant UUID
     *
     * @return String valid object key
     */
    public String generateObjectKey(String uniqueIdentifier, String tenantId) {
        if (StringUtils.isEmpty(tenantId)) {
            throw new ServiceException("Tenant id is empty");
        }
        return StringUtils.collectionToDelimitedString(Arrays.asList(tenantId, logicalSubFolder, uniqueIdentifier),
            delimiter);
    }

    public boolean blobExists(String tenantId) {
        try {
            getBlobInfoContainer(tenantId);
        } catch (UncheckedExecutionException ex) {
            if (ex.getCause() instanceof ServiceException && ErrorConstants.BLOB_ERROR_DOES_NOT_EXIST.equals(
                ((ServiceException) ex.getCause()).getCode())) {
                return false;
            }
            throw ex;
        }
        return true;
    }

    private void initiateMultipartUpload(InputStream content, String key, AmazonS3 client, String bucket,
        List<PartETag> partETags, InitiateMultipartUploadResult initResponse) throws IOException {
        try (ByteArrayOutputStream tempBuffer = new ByteArrayOutputStream()) {
            int i = 1;
            int currentPartSize = 0;
            int byteValue;
            while ((byteValue = content.read()) != -1) {
                tempBuffer.write(byteValue);
                currentPartSize = tempBuffer.size();
                if (currentPartSize == maxPartSize) {
                    byte[] b = tempBuffer.toByteArray();
                    try (ByteArrayInputStream byteStream = new ByteArrayInputStream(b)) {
                        UploadPartRequest uploadPartRequest = new UploadPartRequest().withBucketName(bucket).withKey(
                            key).withUploadId(initResponse.getUploadId()).withPartNumber(i++).withInputStream(
                            byteStream).withPartSize(currentPartSize);
                        partETags.add(client.uploadPart(uploadPartRequest).getPartETag());

                        tempBuffer.reset();
                    }
                }
            }

            if (i == 1 && currentPartSize < maxPartSize) {
                client.abortMultipartUpload(new AbortMultipartUploadRequest(bucket, key, initResponse.getUploadId()));

                byte[] b = tempBuffer.toByteArray();
                try (ByteArrayInputStream byteStream = new ByteArrayInputStream(b)) {
                    ObjectMetadata objectMetadata = createObjectMetadata(getContentType(b), currentPartSize);
                    PutObjectRequest putObjectRequest = new PutObjectRequest(bucket, key, byteStream, objectMetadata);
                    client.putObject(putObjectRequest);
                }
                return;
            }

            if (currentPartSize > 0 && currentPartSize < maxPartSize) {
                byte[] b = tempBuffer.toByteArray();
                try (ByteArrayInputStream byteStream = new ByteArrayInputStream(b)) {
                    UploadPartRequest uploadPartRequest = new UploadPartRequest().withBucketName(bucket).withKey(key)
                        .withUploadId(initResponse.getUploadId()).withPartNumber(i).withInputStream(byteStream)
                        .withPartSize(currentPartSize);
                    partETags.add(client.uploadPart(uploadPartRequest).getPartETag());
                }
            }

            CompleteMultipartUploadRequest completeMultipartUploadRequest = new CompleteMultipartUploadRequest()
                .withBucketName(bucket).withPartETags(partETags).withUploadId(initResponse.getUploadId()).withKey(key);
            client.completeMultipartUpload(completeMultipartUploadRequest);
        } catch (IOException | SdkBaseException ex) {
            log.error("put(): Exception occurred in initiateMultipartUpload(): " + ex.getMessage());
            client.abortMultipartUpload(new AbortMultipartUploadRequest(bucket, key, initResponse.getUploadId()));
            throw ex;
        }
    }

    private String getContentType(byte[] b) {
        String contentType;
        try {
            contentType = URLConnection.guessContentTypeFromStream(new ByteArrayInputStream(b));
        } catch (IOException ex) {
            if (log.isDebugEnabled()) {
                log.debug("unable to determine content type ", ex);
            }
            return APPLICATION_OCTET_STREAM;
        }
        if (contentType == null) {
            return APPLICATION_OCTET_STREAM;
        }
        return contentType;
    }

    private ObjectMetadata createObjectMetadata(String contentType, int partSize) {
        ObjectMetadata objectMetadata = new ObjectMetadata();
        objectMetadata.setContentType(contentType);
        objectMetadata.setContentLength(partSize);
        objectMetadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
        return objectMetadata;
    }

    private BlobClientInfo getBlobInfoContainer(String tenantId) {
        try {
            return blobInfoCache.get(tenantId);
        } catch (ExecutionException ex) {
            log.error("Unable to retrieve blob info from cache.", ex);
            throw new ServiceException("Unable to retrieve blob info from cache.", ex);
        }
    }

    private void validateObjectKey(String key, String tenantId) {
        if (StringUtils.isEmpty(key) || StringUtils.isEmpty(tenantId)) {
            throw new ServiceException("Either the key or tenant id is empty");
        }
        if (!key.startsWith(
            StringUtils.collectionToDelimitedString(Arrays.asList(tenantId, logicalSubFolder, ""), delimiter))) {
            throw new ServiceException("Provided key has invalid format");
        }
    }

    private void clearServiceInfoForTenant(String tenantId) {
        blobInfoCache.invalidate(tenantId);
    }
}
