/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.blob.factory;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.service.properties.ApmProperties;
import com.ge.apm.service.instances.ServiceInstanceInfo;
import com.ge.apm.service.tenants.TenantInfoUtil;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

@Component
@Getter
@Setter
@NoArgsConstructor
@DependsOn({ "apmProperties", "tenantInfoUtil" })
public class BlobClientInfoFactory {

    @Autowired
    TenantInfoUtil tenantInfoUtil;

    @Autowired
    private ApmProperties apmProperties;

    public BlobClientInfo generateBlobInfoContainer(String tenantId) {
        ServiceInstanceInfo serviceInfo = getServiceInfoForTenant(tenantId);
        if (serviceInfo == null) {
            throw new ServiceException(ErrorProvider.findError(ErrorConstants.BLOB_ERROR_DOES_NOT_EXIST), tenantId);
        } else {
            String defaultBucketName = serviceInfo.getCustomProperty(apmProperties.getPxBlobServiceBucketNamePath());
            String accessKeyId = serviceInfo.getCustomProperty(apmProperties.getPxBlobServiceAccessKeyIdPath());
            String secretAccessKey = serviceInfo.getCustomProperty(apmProperties.getPxBlobServiceSecretAccessKeyPath());
            String url = getUrlWithoutBucketName(serviceInfo.getUri(apmProperties.getPxBlobServiceUrlPath()),
                defaultBucketName);

            AmazonS3 amazonS3 = createS3Client(accessKeyId, secretAccessKey, url);
            return new BlobClientInfo(defaultBucketName, amazonS3);
        }
    }

    protected AmazonS3 createS3Client(String accessKeyId, String secretAccessKey, String urlWithoutBucketName) {
        return AmazonS3ClientBuilder.standard().withCredentials(
            new AWSStaticCredentialsProvider(new BasicAWSCredentials(accessKeyId, secretAccessKey)))
            .withEndpointConfiguration(new EndpointConfiguration(urlWithoutBucketName, null)).build();
    }

    private ServiceInstanceInfo getServiceInfoForTenant(String tenantId) {
        return tenantInfoUtil.getServiceInstanceInfo(tenantId, apmProperties.getPxBlobServiceName());
    }

    private String getUrlWithoutBucketName(String blobStoreUrl, String bucketName) {
        return blobStoreUrl.replace(bucketName + ".", "");
    }
}
