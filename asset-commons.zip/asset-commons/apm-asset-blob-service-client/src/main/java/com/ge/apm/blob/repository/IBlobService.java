/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.blob.repository;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public interface IBlobService {

    String put(InputStream content, String key, String tenantId, String authorization) throws IOException;

    String putMultipart(InputStream content, String key, String tenantId, String authorization) throws IOException;

    InputStream get(String fileName, String range, String tenantId, String authorization);

    List<String> get(String tenantId, String authorization);

    String generateObjectKey(String uniqueIdentifier, String tenantId);

    boolean blobExists(String tenantId);

    void delete(String fileName, String tenantId, String authorization);
}
