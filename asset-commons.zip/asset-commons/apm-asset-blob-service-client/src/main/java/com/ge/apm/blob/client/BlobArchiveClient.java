/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.blob.client;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.core.Response.Status;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.ge.apm.blob.repository.IBlobService;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
@Slf4j
public class BlobArchiveClient {

    @Autowired
    IBlobService blobService;

    @Value("${blobStorage.url:}")
    private String blobStorageUrl;

    @Value("${predix.blob:false}")
    private boolean isPredixBlob;

    private static final String HEALTH_STATUS = "/system_status";

    private static ObjectMapper MAPPER = new ObjectMapper();

    public BlobArchiveClient() {
    }

    public BlobArchiveClient(String blobStorageUrl) {
        this.blobStorageUrl = blobStorageUrl;
    }

    public String archiveBlob(Exchange exchange, InputStream file) throws
        ValidationFailedException, IOException {
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        if (isPredixBlob && blobService.blobExists(tenantUuid)) {
            return archivePredixBlob(exchange, file);
        } else {
            return archiveBlob(exchange, file, null, null);
        }
    }

    public String archivePredixBlob(Exchange exchange, InputStream file) throws ValidationFailedException {
        // get the key from exchange header
        String key = exchange.getIn().getHeader(MessageConstants.PERDIX_BLOB_FILE_KEY, String.class);
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        String predixBlobKey = blobService.generateObjectKey(key, tenantUuid);
        String traceUuid = exchange.getIn().getHeader(MessageConstants.TRACE_UUID, String.class);
        MDC.put("X-B3-TraceId", traceUuid);
        MDC.put("tenant", tenantUuid);
        String auth = exchange.getIn().getHeader(MessageConstants.AUTHORIZATION, String.class);
        String name = exchange.getIn().getHeader(Exchange.FILE_NAME, String.class);
        String parentEntityType = exchange.getIn().getHeader("parentEntityType", String.class);
        String taskUuid = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);

        List<Error> blobErrorList = new ArrayList<>();
        Error blobError = new Error(Error.ErrorType.ERROR, ErrorConstants.BLOB_ERROR);
        blobErrorList.add(blobError);

        // call predix blob to store the file
        try {
            return blobService.put(file, predixBlobKey, tenantUuid, auth);
        } catch (IOException io) {
            log.error(String.format("Failed to archive File name %s for parentEntityType %s and TaskId %s: %s ", name,
                parentEntityType, taskUuid, io.getMessage()), io);
            blobError.setActualMessage(io.getMessage());
            throw new ValidationFailedException(blobErrorList);
        } catch (Exception ex) {
            log.error(String.format("Failed to archive File name %s for parentEntityType %s and TaskId %s: %s ", name,
                parentEntityType, taskUuid, ex.getMessage()), ex);
            blobError.setActualMessage(ex.getMessage());
            throw new ValidationFailedException(blobErrorList);
        }
    }

    public String archiveBlob(Exchange exchange, InputStream file, String entityName, String uuid)
        throws ValidationFailedException, IOException {
        String downloadUri = "";
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        String traceUuid = exchange.getIn().getHeader(MessageConstants.TRACE_UUID, String.class);
        MDC.put("X-B3-TraceId", traceUuid);
        MDC.put("tenant", tenantUuid);

        String taskUuid = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        String parentEntityType = exchange.getIn().getHeader("parentEntityType", String.class);
        String name = exchange.getIn().getHeader(Exchange.FILE_NAME, String.class);
        String auth = exchange.getIn().getHeader(MessageConstants.AUTHORIZATION, String.class);

        if (log.isDebugEnabled()) {
            // parentEntityUuid for the blobStorageAPI
            log.debug("parentEntityUuid/taskUuid = {}, parentEntityType = {}, name = {}", taskUuid, parentEntityType,
                name);
        }

        List<Error> blobErrorList = new ArrayList<>();
        Error blobError = new Error(Error.ErrorType.ERROR, ErrorConstants.BLOB_ERROR);
        blobErrorList.add(blobError);

        try {
            Map<String, String> paramMap = new HashMap<>();
            if (uuid == null) {
                paramMap.put("parentEntityUuid", taskUuid);
            } else {
                paramMap.put("parentEntityUuid", uuid);
            }
            paramMap.put("parentEntityType", parentEntityType);
            if (entityName != null) {
                paramMap.put("name", URLEncoder.encode(entityName, "UTF-8"));
            } else {
                paramMap.put("name", URLEncoder.encode(name, "UTF-8"));
            }

            Map<String, String> headersMap = new HashMap<>();
            headersMap.put(RequestContext.AUTHORIZATION, auth);
            headersMap.put(RequestContext.TENANT,
                exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class));

            String blobStorageUrlWithParams = formUrl(blobStorageUrl + "/attachments", paramMap);
            log.info("Blob Storage Url with params: {}", blobStorageUrlWithParams);

            MultipartClient.RestResponse restResponse = MultipartClient.doPost(blobStorageUrlWithParams, name, file,
                headersMap, paramMap);
            if (restResponse != null && restResponse.getStatus() == HttpStatus.SC_OK) {
                log.info("Blob Storage Response Status: {} | Content: {}", restResponse.getStatus(),
                    restResponse.getContent());
                JsonNode node = MAPPER.readTree(restResponse.getContent());
                downloadUri = node.findValue("url").textValue();
                log.info(downloadUri);
            } else {
                String blobErrorMsg;
                if (restResponse != null) {
                    String responseStatus = Status.fromStatusCode(restResponse.getStatus()) == null ? String.valueOf(
                        restResponse.getStatus()) : Status.fromStatusCode(restResponse.getStatus()).getReasonPhrase();
                    String responseContent = restResponse.getContent();
                    blobErrorMsg = "Blob Storage Response Status: " + responseStatus;
                    if (!StringUtils.isEmpty(responseContent)) {
                        blobErrorMsg = blobErrorMsg + " | Content: " + responseContent;
                    }
                } else {
                    blobErrorMsg = "Blob Storage Response is NULL";
                }
                log.error(blobErrorMsg);
                blobError.setActualMessage(blobErrorMsg);
                throw new ValidationFailedException(blobErrorList);
            }
        } catch (ServiceException ex) {
            log.error(String
                .format("Failed to archive file %s for parentEntityType %s and TaskId %s: %s ", name, parentEntityType,
                    taskUuid, ex.getMessage()), ex);
            throw ex;
        } catch (Exception ex) {
            if (ex instanceof ValidationFailedException) {
                throw ex;
            }
            log.error(String.format("Failed to archive File name %s for parentEntityType %s and TaskId %s: %s ", name,
                parentEntityType, taskUuid, ex.getMessage()), ex);
            blobError.setActualMessage(ex.getMessage());
            throw new ValidationFailedException(blobErrorList);
        }
        return downloadUri;
    }

    public InputStream downloadBlob(Exchange exchange, String url) throws
        ValidationFailedException, IOException {
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        if (isPredixBlob && blobService.blobExists(tenantUuid)) {
            return downloadPredixBlob(exchange, url);
        } else {
            return downloadApmBlob(exchange, url);
        }
    }

    private InputStream downloadPredixBlob(Exchange exchange, String downloadUrl) throws ValidationFailedException {
        String key = "";
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        String predixBlobObjectKey = blobService.generateObjectKey("",tenantUuid);
        if (downloadUrl != null && downloadUrl
            .split(predixBlobObjectKey) != null && downloadUrl.split(predixBlobObjectKey).length > 1) {
            key = predixBlobObjectKey + downloadUrl.split(predixBlobObjectKey)[1];
        }
        String auth = exchange.getIn().getHeader(MessageConstants.AUTHORIZATION, String.class);

        List<Error> blobErrorList = new ArrayList<>();
        Error blobError = new Error(Error.ErrorType.ERROR, ErrorConstants.BLOB_ERROR);

        try {
            InputStream response = blobService.get(key, null, tenantUuid, auth);

            if (response == null) {
                blobError.setActualMessage("Failed to download File from predix blob based on key: " + key);
                blobErrorList.add(blobError);
                throw new ValidationFailedException(blobErrorList);
            }

            return response;
        } catch (Exception exception) {
            log.error("Failed to download File from blob based on key: " + key, exception);
            if (exception instanceof ValidationFailedException) {
                throw exception;
            }
            blobError.setActualMessage(exception.getMessage());
            throw new ValidationFailedException(blobErrorList);
        }

    }

    private InputStream downloadApmBlob(Exchange exchange, String url) throws ValidationFailedException {
        List<Error> blobErrorList = new ArrayList<>();
        Error blobError = new Error(Error.ErrorType.ERROR, ErrorConstants.BLOB_ERROR);
        blobErrorList.add(blobError);

        HttpGet httpGet = new HttpGet(url);
        httpGet.addHeader(RequestContext.AUTHORIZATION,
            exchange.getIn().getHeader(MessageConstants.AUTHORIZATION, String.class));
        httpGet.addHeader(RequestContext.TENANT,
            exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class));

        //Cant close the connection since we are returning the content(InputStream)
        CloseableHttpClient httpClient = HttpClients.createSystem(); //NOSONAR

        HttpResponse response;
        try {
            response = httpClient.execute(httpGet);
            if (response.getStatusLine() == null || response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
                int statusCode = response.getStatusLine() != null ? response.getStatusLine().getStatusCode()
                    : HttpStatus.SC_BAD_REQUEST;
                blobError.setActualMessage(Status.fromStatusCode(statusCode) == null ? String.valueOf(statusCode)
                    : Status.fromStatusCode(statusCode).getReasonPhrase());
                log.error(String.format("Failed to download File from blob url: %s ", url));
                throw new ValidationFailedException(blobErrorList);
            }
            log.info(String.format("Downloaded File from url: %s", url));
            return response.getEntity().getContent();
        } catch (ValidationFailedException vfe) {
            throw vfe;
        } catch (Exception ex) {
            log.error(String.format("Failed to download File from blob url: %s ", url), ex);
            blobError.setActualMessage(ex.getMessage());
            throw new ValidationFailedException(blobErrorList);
        }
    }

    private String formUrl(String url, Map<String, String> paramMap) {
        StringBuilder sb = new StringBuilder(url);
        sb.append("?");

        for (Map.Entry<String, String> param : paramMap.entrySet()) {
            String paramKey = param.getKey();
            String paramValue = param.getValue();
            sb.append(paramKey).append("=");
            sb.append(paramValue).append("&");
        }
        sb.deleteCharAt(sb.lastIndexOf("&"));

        return sb.toString();
    }

    public boolean healthStatus() {
        try {
            //Ideally blobStorageUrl shouldn't include version. This requires change in cups for blob
            String blobStorageHealth = blobStorageUrl.substring(0, blobStorageUrl.lastIndexOf("/v3"));
            RestTemplate restTemplate = new RestTemplate();
            restTemplate.exchange(blobStorageHealth + HEALTH_STATUS, HttpMethod.GET, getHttpEntity(), String.class);
            return true;
        } catch (Exception ignored) {
            log.error(ignored.getMessage(), ignored);
            return false;
        }
    }

    private HttpEntity<?> getHttpEntity() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(HttpHeaders.AUTHORIZATION, RequestContext.get(RequestContext.AUTHORIZATION, String.class));
        headers.add(RequestContext.TENANT, RequestContext.get(RequestContext.TENANT_UUID, String.class));
        return new HttpEntity<>(headers);
    }
}
