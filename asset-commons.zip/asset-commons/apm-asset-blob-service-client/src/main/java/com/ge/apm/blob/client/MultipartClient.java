/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.blob.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class MultipartClient {

    private MultipartClient() {
        //Added a private constructor since this method contains only static methods and can be used as
        //utility method.
    }

    public static RestResponse doPost(String url, String fileName, InputStream inputStream,
        Map<String, String> headersMap, Map<String, String> paramMap) throws IOException {
        HttpPost httpPost = new HttpPost(url);

        MultipartEntityBuilder entityBuilder = MultipartEntityBuilder.create();
        entityBuilder.addBinaryBody("file", inputStream, ContentType.MULTIPART_FORM_DATA, fileName);

        for (Map.Entry<String, String> header : headersMap.entrySet()) {
            httpPost.setHeader(header.getKey(), header.getValue());
        }

        List<NameValuePair> urlParameters = paramMap.entrySet().stream().map(
            param -> new BasicNameValuePair(param.getKey(), param.getValue())).collect(Collectors.toList());
        httpPost.setEntity(new UrlEncodedFormEntity(urlParameters));

        final HttpEntity httpEntity = entityBuilder.build();
        httpPost.setEntity(httpEntity);

        HttpResponse response = null;
        CloseableHttpClient httpclient = null;
        String responseContent = null;
        String contentType = null;
        RestResponse restResponse = null;
        try {
            httpclient = HttpClients.createSystem();
            response = httpclient.execute(httpPost);
            if (response.getEntity() == null) {
                if (log.isDebugEnabled()) {
                    log.debug("HttpResponse contents are empty.");
                }
            } else {
                // Convert the response to com.ge.ast.common.rest.RestResponse
                responseContent = getStringFromInputStream(response.getEntity().getContent());
                if (response.getEntity().getContentType() != null) {
                    contentType = response.getEntity().getContentType().getValue();
                }
            }
            restResponse = new RestResponse(contentType, responseContent, response.getStatusLine().getStatusCode());
        } catch (IOException ie) {
            log.error(String.format("Unable to post file %s to %s", fileName, url), ie);
            throw ie;
        } finally {
            if (httpclient != null) {
                httpclient.close();
            }
        }
        return restResponse;
    }

    private static String getStringFromInputStream(InputStream is) throws IOException {

        StringBuilder sb = new StringBuilder();

        String line;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        }
        return sb.toString();
    }

    @Getter
    @Setter
    public static class RestResponse {

        private final String contentType;

        private final String content;

        private final int status;

        public RestResponse(String contentType, String content, int status) {
            this.contentType = contentType;
            this.content = content;
            this.status = status;
        }
    }
}
