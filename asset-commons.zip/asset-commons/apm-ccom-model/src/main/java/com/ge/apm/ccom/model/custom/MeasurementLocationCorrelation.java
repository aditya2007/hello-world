package com.ge.apm.ccom.model.custom;

import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import java.io.Serializable;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MeasurementLocationCorrelation")
@EqualsAndHashCode
@ToString
public class MeasurementLocationCorrelation implements Serializable {

    private static final long serialVersionUID = -4426896318610454481L;

    @XmlValue
    protected String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
