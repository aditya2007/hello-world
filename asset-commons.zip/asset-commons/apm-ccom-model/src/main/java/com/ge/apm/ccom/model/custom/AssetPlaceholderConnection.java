/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.ccom.model.custom;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import lombok.EqualsAndHashCode;
import lombok.ToString;

import com.ge.apm.ccom.model.core.Entity;

@XmlRootElement(name = "AssetPlaceholderConnection")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AssetPlaceholderConnection", propOrder = { "id", "placeholderId"})
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class AssetPlaceholderConnection extends Entity {

    private static final long serialVersionUID = 1815695289723198491L;

    @XmlElement(name = "Id")
    private String id;
    @XmlElement(name = "PlaceholderId")
    private String placeholderId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPlaceholderId() {
        return placeholderId;
    }

    public void setPlaceholderId(String placeholderId) {
        this.placeholderId = placeholderId;
    }

}