package com.ge.apm.ccom.model.custom;

import com.ge.apm.ccom.model.network.connections.AssetConnection;
import com.ge.apm.ccom.model.network.topologies.MeshType;
import com.ge.apm.ccom.model.network.topologies.Network;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PlaceholderMesh", propOrder = {
        "type",
        "connection"})
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class PlaceholderMesh
        extends Network {

    private static final long serialVersionUID = 697200075259871438L;
    @XmlElement(name = "Type")
    protected MeshType type;

    @XmlElement(name = "Connection")
    protected List<PlaceholderConnection> connection;

    /**
     * Gets the value of the type property.
     *
     * @return possible object is
     * {@link MeshType }
     */
    public MeshType getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     *
     * @param value allowed object is
     *              {@link MeshType }
     */
    public void setType(MeshType value) {
        this.type = value;
    }

    /**
     * Gets the value of the connection property.
     * <p>
     * <p>This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the connection property.
     * <p>
     * <p>For example, to add a new item, do as follows:
     * <pre>
     *    getConnection().add(newItem);
     * </pre>
     * <p>
     * <p>
     * <p>Objects of the following type(s) are allowed in the list
     * {@link AssetConnection }
     */
    public List<PlaceholderConnection> getConnection() {
        if (connection == null) {
            connection = new ArrayList<PlaceholderConnection>();
        }
        return this.connection;
    }
}
