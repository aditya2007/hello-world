/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.ccom.model.custom;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import lombok.EqualsAndHashCode;
import lombok.ToString;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TagExpression", namespace = "urn:un:unece:uncefact:documentation:standard:CoreComponentType:2",
    propOrder = {
        "idExpr", "nameExpr", "timeSeriesLinkExpr", "range" })
@EqualsAndHashCode
@ToString
public class TagExpression implements Serializable {

    private static final long serialVersionUID = -2059298093576121054L;

    protected String idExpr;
    protected String nameExpr;
    protected String timeSeriesLinkExpr;
    protected String range;

    public String getIdExpr() {
        return idExpr;
    }

    public void setIdExpr(String idExpr) {
        this.idExpr = idExpr;
    }

    public String getNameExpr() {
        return nameExpr;
    }

    public void setNameExpr(String nameExpr) {
        this.nameExpr = nameExpr;
    }

    public String getTimeSeriesLinkExpr() {
        return timeSeriesLinkExpr;
    }

    public void setTimeSeriesLinkExpr(String timeSeriesLinkExpr) {
        this.timeSeriesLinkExpr = timeSeriesLinkExpr;
    }

    public String getRange() {
        return range;
    }

    public void setRange(String range) {
        this.range = range;
    }
}
