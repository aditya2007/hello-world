/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.ccom.model.custom;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import lombok.EqualsAndHashCode;
import lombok.ToString;

import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.core.types.UUID;


/**
 * Created by 212391955 on 10/25/16.
 */
@XmlRootElement(name = "PlaceholderAssetTypeAssociation")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PlaceholderAssetTypeAssociation", propOrder = {"associatedEntityId", "associatedEntityCcomClass", "isPrimary"})
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class PlaceholderAssetTypeAssociation extends Entity {
    private static final long serialVersionUID = 3359374250285292335L;

    @XmlElement(name = "AssociatedEntityId")
    protected UUID associatedEntityId;

    @XmlElement(name = "AssociatedEntityCcomClass")
    protected MimosaCcomCategory associatedEntityCcomClass;

    @XmlElement(name = "IsPrimary")
    protected Boolean isPrimary;

    public UUID getAssociatedEntityId() {
        return associatedEntityId;
    }

    public void setAssociatedEntityId(UUID associatedEntityId) {
        this.associatedEntityId = associatedEntityId;
    }

    public MimosaCcomCategory getAssociatedEntityCcomClass() {
        return associatedEntityCcomClass;
    }

    public void setAssociatedEntityCcomClass(MimosaCcomCategory associatedEntityCcomClass) {
        this.associatedEntityCcomClass = associatedEntityCcomClass;
    }

    public Boolean getPrimary() {
        return isPrimary;
    }

    public void setPrimary(Boolean primary) {
        isPrimary = primary;
    }

}
