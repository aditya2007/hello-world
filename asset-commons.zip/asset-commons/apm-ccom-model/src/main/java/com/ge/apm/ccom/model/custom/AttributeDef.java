package com.ge.apm.ccom.model.custom;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import lombok.EqualsAndHashCode;
import lombok.ToString;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AttributeDef", namespace = "urn:un:unece:uncefact:documentation:standard:CoreComponentType:2",
    propOrder = {
        "id", "type" })
@EqualsAndHashCode
@ToString
public class AttributeDef implements Serializable {

    private static final long serialVersionUID = -4529359682507115344L;

    protected String id;

    protected String type;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
