package com.ge.apm.ccom.model.custom;

import com.ge.apm.ccom.model.core.types.TextType;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.xml.bind.annotation.*;
import java.io.Serializable;
import java.util.List;

/**
 * Created by 212326606 on 7/18/16.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ApmType")
@EqualsAndHashCode
@ToString
public class ApmType implements Serializable {

    private static final long serialVersionUID = 8002665733369339795L;
    @XmlElement(name = "Type")
    protected TextType type;

    @XmlElement(name = "AttributeValue")
    protected AttributeValue attributeValue;

    @XmlElement(name = "AttributeMetaInfo")
    protected List<AttributeDef> attributeMetaInfo;

    public AttributeValue getAttributeValue() {
        return attributeValue;
    }

    public void setAttributeValue(AttributeValue attributeValue) {
        this.attributeValue = attributeValue;
    }

    public TextType getType() {
        return type;
    }

    public void setType(TextType type) {
        this.type = type;
    }

    public List<AttributeDef> getAttributeMetaInfo() {
        return attributeMetaInfo;
    }

    public void setAttributeMetaInfo(List<AttributeDef> attributeMetaInfo) {
        this.attributeMetaInfo = attributeMetaInfo;
    }
}
