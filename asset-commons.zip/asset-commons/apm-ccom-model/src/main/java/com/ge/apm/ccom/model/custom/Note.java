package com.ge.apm.ccom.model.custom;

import com.ge.apm.ccom.model.core.Entity;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.xml.bind.annotation.*;

/**
 * Created by 212391955 on 1/3/17.
 */
@XmlRootElement(name = "Note")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Note", propOrder = {"content"})
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class Note extends Entity {

    private static final long serialVersionUID = -8862376441873153474L;
    
    @XmlElement(name = "Content")
    protected String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }


}
