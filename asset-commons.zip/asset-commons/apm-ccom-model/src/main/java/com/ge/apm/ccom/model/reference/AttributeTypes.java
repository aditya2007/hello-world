/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.ccom.model.reference;

public final class AttributeTypes {
    public static final String TimeReceived = "83A7CE80-4A3C-25E0-014A-3C3827CB0001";
    public static final String StatusCode = "83D068FA-E058-4373-BC12-0E05BDE1B64C";
    public static final String StatusDesc = "CEC602C8-1E17-41EA-A2C6-DD84310AD231";
    public static final String Origin = "46ABD050-87F8-4E37-B21A-4CD9A291B21A";
    public static final String Priority = "29289751-48CF-4713-BF4D-A1ECC71B6626";
    public static final String IncidentEventCount = "E1165754-DBD3-433A-807B-227DF0C0F56A";
    public static final String FirstOccurrence = "3360AB7C-26B5-4098-8D47-9390F13799C3";
    public static final String LastOccurrence = "62DBE787-879E-4607-BFD4-6C3179E47520";
}
