/******************************************************************************
 * Copyright (c) 2016 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.ccom.model.groups;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import lombok.EqualsAndHashCode;
import lombok.ToString;

import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.core.types.UUID;

/**
 * Created by 212553303 on 2/19/16.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InstanceGroupMap", propOrder = {
    "entityId",
    "entityCcomClass",
    "groupId" })
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class InstanceGroupMap
    extends Entity {

    private static final long serialVersionUID = 3359374250285292335L;
    @XmlElement(name = "EntityId")
    protected UUID entityId;
    @XmlElement(name = "EntityCcomClass")
    protected MimosaCcomCategory entityCcomClass;
    @XmlElement(name = "GroupId")
    protected UUID groupId;

    /**
     * Gets the value of the entityId property.
     *
     * @return
     *     possible object is
     *     {@link com.ge.apm.ccom.model.core.types.UUID }
     *
     */
    public UUID getEntityId() {
        return entityId;
    }

    /**
     * Sets the value of the entityId property.
     *
     * @param value
     *     allowed object is
     *     {@link com.ge.apm.ccom.model.core.types.UUID }
     *
     */
    public void setEntityId(UUID value) {
        this.entityId = value;
    }

    /**
     * Gets the value of the entityCcomClass property.
     *
     * @return
     *     possible object is
     *     {@link com.ge.apm.ccom.model.MimosaCcomCategory }
     *
     */
    public MimosaCcomCategory getEntityCcomClass() {
        return entityCcomClass;
    }

    /**
     * Sets the value of the entityCcomClass property.
     *
     * @param value
     *     allowed object is
     *     {@link com.ge.apm.ccom.model.MimosaCcomCategory }
     *
     */
    public void setEntityCcomClass(MimosaCcomCategory value) {
        this.entityCcomClass = value;
    }

    /**
     * Gets the value of the groupId property.
     *
     * @return
     *     possible object is
     *     {@link com.ge.apm.ccom.model.core.types.UUID }
     *
     */
    public UUID getGroupId() {
        return groupId;
    }

    /**
     * Sets the value of the groupId property.
     *
     * @param value
     *     allowed object is
     *     {@link com.ge.apm.ccom.model.core.types.UUID }
     *
     */
    public void setGroupId(UUID value) {
        this.groupId = value;
    }
}
