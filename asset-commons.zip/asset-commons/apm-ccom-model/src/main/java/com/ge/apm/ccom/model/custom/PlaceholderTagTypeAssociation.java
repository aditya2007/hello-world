/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.ccom.model.custom;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.core.types.UUID;


/**
 * Created by 502664102 on 03/01/17.
 */
@XmlRootElement(name = "PlaceholderTagTypeAssociation")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PlaceholderTagTypeAssociation", propOrder = {"associatedEntityId", "associatedEntityCcomClass",
        "category", "tagExpressions"})
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Getter
@Setter
public class PlaceholderTagTypeAssociation extends Entity {

    private static final long serialVersionUID = 3359374250285292335L;

    @XmlElement(name = "AssociatedEntityId")
    protected UUID associatedEntityId;

    @XmlElement(name = "AssociatedEntityCcomClass")
    protected MimosaCcomCategory associatedEntityCcomClass;

    @XmlElement(name = "Category")
    protected String category;

    @XmlElement(name = "TagExpressions")
    protected List<TagExpression> tagExpressions;

}
