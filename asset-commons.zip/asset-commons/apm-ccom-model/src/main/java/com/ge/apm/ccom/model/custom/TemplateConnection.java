/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.ccom.model.custom;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import lombok.EqualsAndHashCode;
import lombok.ToString;

import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.AttributableEntity;

@XmlRootElement(name = "TemplateConnection")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TemplateConnection", propOrder = { "templateId", "parentEntityId", "parentEntityCcomClass",
        "connections"})
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class TemplateConnection extends AttributableEntity {
    private static final long serialVersionUID = -5656683900682312682L;

    @XmlElement(name = "TemplateId")
    private String templateId;
    @XmlElement(name = "ParentEntityId")
    private String parentEntityId;
    @XmlElement(name = "ParentEntityCcomClass")
    protected MimosaCcomCategory parentEntityCcomClass;

    @XmlElement(name = "Connections")
    protected List<AssetPlaceholderConnection> connections;

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getParentEntityId() {
        return parentEntityId;
    }

    public void setParentEntityId(String parentEntityId) {
        this.parentEntityId = parentEntityId;
    }

    public MimosaCcomCategory getParentEntityCcomClass() {
        return parentEntityCcomClass;
    }

    public void setParentEntityCcomClass(MimosaCcomCategory parentEntityCcomClass) {
        this.parentEntityCcomClass = parentEntityCcomClass;
    }

    public List<AssetPlaceholderConnection> getConnections() {
        if (connections == null) {
            connections = new ArrayList<>();
        }
        return connections;
    }

    public void setConnections(List<AssetPlaceholderConnection> connections) {
        this.connections = connections;
    }
}