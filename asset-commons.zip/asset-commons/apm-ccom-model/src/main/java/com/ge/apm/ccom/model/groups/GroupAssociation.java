/******************************************************************************
 * Copyright (c) 2016 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.ccom.model.groups;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import lombok.EqualsAndHashCode;
import lombok.ToString;

import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.core.types.UUID;

/**
 * Created by 212553303 on 2/19/16.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GroupAssociation", propOrder = {
        "associatedEntityId",
        "associatedEntityCcomClass",
        "groupId"})
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class GroupAssociation
        extends Entity {

    private static final long serialVersionUID = 3359374250285292335L;
    @XmlElement(name = "AssociatedEntityId")
    protected UUID associatedEntityId;
    @XmlElement(name = "AssociatedEntityCcomClass")
    protected MimosaCcomCategory associatedEntityCcomClass;
    @XmlElement(name = "GroupId")
    protected UUID groupId;

    /**
     * Gets the value of the associatedEntityId property.
     *
     * @return
     *     possible object is
     *     {@link UUID }
     *
     */
    public UUID getAssociatedEntityId() {
        return associatedEntityId;
    }

    /**
     * Sets the value of the associatedEntityId property.
     *
     * @param value
     *     allowed object is
     *     {@link UUID }
     *
     */
    public void setAssociatedEntityId(UUID value) {
        this.associatedEntityId = value;
    }

    /**
     * Gets the value of the associatedEntityCcomClass property.
     *
     * @return
     *     possible object is
     *     {@link MimosaCcomCategory }
     *
     */
    public MimosaCcomCategory getAssociatedEntityCcomClass() {
        return associatedEntityCcomClass;
    }

    /**
     * Sets the value of the associatedEntityCcomClass property.
     *
     * @param value
     *     allowed object is
     *     {@link MimosaCcomCategory }
     *
     */
    public void setAssociatedEntityCcomClass(MimosaCcomCategory value) {
        this.associatedEntityCcomClass = value;
    }

    /**
     * Gets the value of the groupId property.
     *
     * @return
     *     possible object is
     *     {@link UUID }
     *
     */
    public UUID getGroupId() {
        return groupId;
    }

    /**
     * Sets the value of the groupId property.
     *
     * @param value
     *     allowed object is
     *     {@link UUID }
     *
     */
    public void setGroupId(UUID value) {
        this.groupId = value;
    }
}
