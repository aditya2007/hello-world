/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.ccom.model;

import java.util.HashMap;
import java.util.Map;

public enum MimosaCcomCategory {
    ENTERPRISE_TYPE(51),
    SITE_TYPE(52),
    SEGMENT_TYPE(53),
    ASSET_TYPE(54),
    MODEL_TYPE(55),
    ALARM_TYPE(56),
    TAG_TYPE(57),
    ENTERPRISE(11),
    SITE(12),
    SEGMENT(13),
    ASSET(14),
    MODEL(15),
    ALARM(16),
    TAG(17),
    GROUP(10),
    TEMPLATE(18);

    private static Map<Integer, MimosaCcomCategory> enumValueMap;

    static {
        enumValueMap = new HashMap<>();
        enumValueMap.put(ENTERPRISE_TYPE.getValue(), ENTERPRISE_TYPE);
        enumValueMap.put(SITE_TYPE.getValue(), SITE_TYPE);
        enumValueMap.put(SEGMENT_TYPE.getValue(), SEGMENT_TYPE);
        enumValueMap.put(ASSET_TYPE.getValue(), ASSET_TYPE);
        enumValueMap.put(MODEL_TYPE.getValue(), MODEL_TYPE);
        enumValueMap.put(ALARM_TYPE.getValue(), ALARM_TYPE);
        enumValueMap.put(TAG_TYPE.getValue(), TAG_TYPE);
        enumValueMap.put(GROUP.getValue(), GROUP);
        enumValueMap.put(ENTERPRISE.getValue(), ENTERPRISE);
        enumValueMap.put(SITE.getValue(), SITE);
        enumValueMap.put(SEGMENT.getValue(), SEGMENT);
        enumValueMap.put(ASSET.getValue(), ASSET);
        enumValueMap.put(MODEL.getValue(), MODEL);
        enumValueMap.put(ALARM.getValue(), ALARM);
        enumValueMap.put(TAG.getValue(), TAG);
        enumValueMap.put(TEMPLATE.getValue(), TEMPLATE);
    }

    private final int value;

    MimosaCcomCategory(final int newValue) {
        value = newValue;
    }

    public static MimosaCcomCategory getEnum(int value) {
        return enumValueMap.get(value);
    }

    public int getValue() {
        return value;
    }
}
