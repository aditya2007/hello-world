package com.ge.apm.ccom.model.custom;

import java.io.Serializable;
import javax.xml.bind.annotation.*;

import lombok.EqualsAndHashCode;
import lombok.ToString;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AttributeValue", namespace = "urn:un:unece:uncefact:documentation:standard:CoreComponentType:2",
        propOrder = {
                "value" })
@EqualsAndHashCode
@ToString
public class AttributeValue implements Serializable {

    private static final long serialVersionUID = -4529359682507115344L;

    @XmlValue
    protected String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
