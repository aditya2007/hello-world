/******************************************************************************
 * Copyright (c) 2016 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.ccom.model.groups;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.ge.apm.ccom.model.MimosaCcomCategory;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import com.ge.apm.ccom.model.core.AttributableEntity;
import com.ge.apm.ccom.model.core.types.TextType;


/**
 * Created by 212553303 on 2/19/16.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Group", propOrder = { "description", "associatedEntityCcomClass" })
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class Group extends AttributableEntity {

    private static final long serialVersionUID = 8002665781369339795L;
    @XmlElement(name = "Description")
    protected TextType description;
    @XmlElement(name = "AssociatedEntityCcomClass")
    protected MimosaCcomCategory associatedEntityCcomClass;

    /**
     * Gets the value of the description property.
     *
     * @return possible object is {@link TextType }
     *
     */
    public TextType getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     *
     * @param value
     *            allowed object is {@link TextType }
     *
     */
    public void setDescription(TextType value) {
        this.description = value;
    }

    /**
     * Gets the value of the associatedEntityCcomClass property.
     *
     * @return possible object is {@link MimosaCcomCategory }
     */
    public MimosaCcomCategory getAssociatedEntityCcomClass() {
        return associatedEntityCcomClass;
    }

    /**
     * Sets the value of the associatedEntityCcomClass property.
     *
     * @param associatedEntityCcomClass
     *            allowed object is {@link MimosaCcomCategory }
     */
    public void setAssociatedEntityCcomClass(MimosaCcomCategory associatedEntityCcomClass) {
        this.associatedEntityCcomClass = associatedEntityCcomClass;
    }
}
