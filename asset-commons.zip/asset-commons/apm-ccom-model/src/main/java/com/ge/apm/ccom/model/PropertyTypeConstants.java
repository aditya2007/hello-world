/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.ccom.model;

public class PropertyTypeConstants {
    public static final String BOOLEAN_TYPE = "NULL_OR_EMPTY_VALUE_OF_TYPE_BOOLEAN";
    public static final String NUMBER_TYPE = "NULL_OR_EMPTY_VALUE_OF_TYPE_NUMBER";
    public static final String STRING_TYPE = "NULL_OR_EMPTY_VALUE_OF_TYPE_STRING";
}
