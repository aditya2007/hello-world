/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.ccom.model;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.function.Consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import com.ge.apm.ccom.model.core.AttributableEntity;
import com.ge.apm.ccom.model.core.Attribute;
import com.ge.apm.ccom.model.core.AttributeType;
import com.ge.apm.ccom.model.core.UnitType;
import com.ge.apm.ccom.model.core.types.Boolean;
import com.ge.apm.ccom.model.core.types.CodeType;
import com.ge.apm.ccom.model.core.types.DateTimeType;
import com.ge.apm.ccom.model.core.types.IDType;
import com.ge.apm.ccom.model.core.types.Measure;
import com.ge.apm.ccom.model.core.types.MeasureType;
import com.ge.apm.ccom.model.core.types.NumericType;
import com.ge.apm.ccom.model.core.types.TextType;
import com.ge.apm.ccom.model.core.types.UTCDateTime;
import com.ge.apm.ccom.model.core.types.UUID;
import com.ge.apm.ccom.model.core.types.ValueContent;
import com.ge.apm.ccom.model.custom.ApmType;
import com.ge.apm.ccom.model.custom.AttributeDef;
import com.ge.apm.ccom.model.custom.AttributeValue;
import com.ge.apm.ccom.model.custom.ReservedAttribute;
import com.ge.apm.ccom.model.events.EventType;
import com.ge.apm.ccom.model.events.SubstantiatedByMeasurement;
import com.ge.apm.ccom.model.measurements.VectorMeasurement;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class CcomTypeHelper {
    private static final ObjectWriter WRITER = new ObjectMapper().writer();

    public static void setUuidAndTag(AttributableEntity entity, String uuid) {
        entity.setGUID(CcomTypeHelper.wrapUUID(uuid));
        entity.setTag(CcomTypeHelper.wrapText(uuid));
    }

    public static UUID wrapUUID(java.util.UUID uuid) {
        UUID ccomUuid = new UUID();
        ccomUuid.setValue(uuid.toString());
        return ccomUuid;
    }

    public static UUID wrapUUID(String uuid) {
        UUID ccomUuid = new UUID();
        ccomUuid.setValue(uuid);
        return ccomUuid;
    }

    public static TextType wrapText(String text) {
        TextType textType = new TextType();
        textType.setValue(text);
        return textType;
    }

    public static Boolean wrapBoolean(java.lang.Boolean value) {
        Boolean ccomBoolean = new Boolean();
        ccomBoolean.setValue(value.toString());
        return ccomBoolean;
    }

    public static NumericType wrapNumber(Number value) {
        NumericType ccomNumber = new NumericType();
        ccomNumber.setValue(value.toString());
        return ccomNumber;
    }

    public static ApmType wrapApmType(String type, Object value, List<AttributeDef> metaInfo) {
        ApmType apmType = new ApmType();
        apmType.setType(wrapText(type));
        AttributeValue attributeValue = new AttributeValue();
        String valueString = "";
        if (type.equalsIgnoreCase("Grid")) {
            
            try {
                valueString = WRITER.writeValueAsString(value);
            } catch (JsonProcessingException e) {
                log.error("Unable to serialize attribute of type {} and value {}", type, value, e);
            }
        } else {
            valueString =  value == null ? "" : value.toString();
        }
        attributeValue.setValue(valueString);
        apmType.setAttributeValue(attributeValue);
        apmType.setAttributeMetaInfo(metaInfo);
        return apmType;
    }

    public static Attribute getAttribute(java.util.UUID typeId) {
        return getAttribute(typeId.toString());
    }

    public static Attribute getAttribute(String typeId, int order) {
        Attribute attribute = getAttribute(typeId);
        attribute.setOrder(wrapNumber(order));
        return attribute;
    }

    public static Attribute getAttribute(String typeId) {
        Attribute attribute = new Attribute();
        attribute.setGUID(wrapUUID(IdGenerator.generateAsString()));
        if (typeId == null || typeId.isEmpty()) {
            typeId = IdGenerator.generateAsString();
        }
        AttributeType attributeType = new AttributeType();
        attributeType.setGUID(wrapUUID(typeId));
        attribute.setType(attributeType);
        attribute.setValueContent(new ValueContent());

        return attribute;
    }

    public static ReservedAttribute getReservedAttribute(String typeId) {
        ReservedAttribute reservedAttribute = new ReservedAttribute();
        reservedAttribute.setGUID(wrapUUID(IdGenerator.generateAsString()));
        if (typeId == null || typeId.isEmpty()) {
            typeId = IdGenerator.generateAsString();
        }
        AttributeType attributeType = new AttributeType();
        attributeType.setGUID(wrapUUID(typeId));
        reservedAttribute.setType(attributeType);
        reservedAttribute.setValueContent(new ValueContent());

        return reservedAttribute;
    }

    public static ReservedAttribute getReservedAttribute(String typeId, int order) {
        ReservedAttribute reservedAttribute = getReservedAttribute(typeId);
        reservedAttribute.setOrder(wrapNumber(order));
        return reservedAttribute;
    }

    public static Attribute getAttribute(String typeId, String value) {
        Attribute attribute = getAttribute(typeId);
        attribute.setValueContent(wrapStringInValueContent(value));
        return attribute;
    }

    public static void addAttribute(AttributableEntity entity, String name, String typeId, String value) {
        Attribute attribute = getAttribute(typeId);
        attribute.setValueContent(wrapStringInValueContent(value));
        attribute.setName(CcomTypeHelper.wrapText(name));
        entity.getAttribute().add(attribute);
    }

    public static void wrapValueInValueContentV2(String type, String unitOfMeasure, Object value,
                                                 ValueContent valueContent, List<AttributeDef> metaInfo) {
        type = type.toUpperCase();
        if (unitOfMeasure != null && !unitOfMeasure.isEmpty()) {
            setUnitOfMeasure(unitOfMeasure, valueContent);
        }
        try {
            valueContent.setApmType(CcomTypeHelper.wrapApmType(type, value, metaInfo));
        } catch (Exception e) {
            log.error("Failed to wrap value content {}: {}", value, e);
        }
    }

    public static void setUnitOfMeasure(String unitOfMeasure, ValueContent valueContent) {
        Measure measure = new Measure();
        measure.setUnitType(new UnitType());
        measure.getUnitType().setTag(CcomTypeHelper.wrapText(unitOfMeasure));
        measure.setValue(new MeasureType());
        valueContent.setMeasure(measure);
    }

    public static ValueContent wrapStringInValueContent(String value) {
        ValueContent stringValue = new ValueContent();
        stringValue.setText(wrapText(value));
        return stringValue;
    }

    public static Map<String, List<Attribute>> getAttributeTypeMap(AttributableEntity attributableEntity) {
        Map<String, List<Attribute>> attributeMap = new LinkedHashMap<>();
        for (Attribute attribute : attributableEntity.getAttribute()) {
            String attributeType = attribute.getType().getGUID().getValue();

            if (!attributeMap.containsKey(attributeType)) {
                attributeMap.put(attributeType, new ArrayList<>());
            }
            attributeMap.get(attributeType).add(attribute);
            attributeMap.get(attributeType).sort((attr1, attr2) -> {
                try {
                    if (attr1 != null && attr2 != null && attr1.getOrder() != null && attr2.getOrder() != null) {
                        int order1 = Integer.parseInt(attr1.getOrder().getValue());
                        int order2 = Integer.parseInt(attr2.getOrder().getValue());
                        return order1 - order2;
                    }
                } catch (Exception e) {//NOSONAR
                    //Ignore errors
                }
                return 0;
            });
        }
        return attributeMap;
    }

    public static Map<String, List<ReservedAttribute>> getReservedAttributeTypeMap(AttributableEntity attributableEntity) {
        Map<String, List<ReservedAttribute>> reservedAttributeMap = new LinkedHashMap<>();
        for (ReservedAttribute reservedAttribute : attributableEntity.getReservedAttributes()) {
            String reservedAttributeName = reservedAttribute.getName().getValue();

            if (!reservedAttributeMap.containsKey(reservedAttributeName)) {
                reservedAttributeMap.put(reservedAttributeName, new ArrayList<>());
            }
            reservedAttributeMap.get(reservedAttributeName).add(reservedAttribute);
            reservedAttributeMap.get(reservedAttributeName).sort((attr1, attr2) -> {
                try {
                    if (attr1 != null && attr2 != null && attr1.getOrder() != null && attr2.getOrder() != null) {
                        int order1 = Integer.parseInt(attr1.getOrder().getValue());
                        int order2 = Integer.parseInt(attr2.getOrder().getValue());
                        return order1 - order2;
                    }
                } catch (Exception e) { //NOSONAR
                    //Ignore errors
                }
                return 0;
            });
        }
        return reservedAttributeMap;
    }
}
