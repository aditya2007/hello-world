/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.ccom.model.custom;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import lombok.EqualsAndHashCode;

import com.ge.apm.ccom.model.core.HierarchicalEntity;
import com.ge.apm.ccom.model.core.types.TextType;


/**
 * Created by 212391955 on 10/24/16.
 */
@XmlRootElement(name = "Placeholder")
@XmlType(name = "Placeholder", propOrder = { "assetTypeAssociations", "tagTypeAssociations", "placeholderId"})
@EqualsAndHashCode(callSuper = true)
public class Placeholder extends HierarchicalEntity {

    private static final long serialVersionUID = -3202726341425332304L;

    @XmlElement(name = "AssetTypeAssociations")
    protected List<PlaceholderAssetTypeAssociation> assetTypeAssociations;

    @XmlElement(name = "TagTypeAssociations")
    protected List<PlaceholderTagTypeAssociation> tagTypeAssociations;

    @XmlElement(name = "PlaceholderId")
    protected TextType placeholderId;

    public List<PlaceholderAssetTypeAssociation> getAssetTypeAssociations() {
        if (assetTypeAssociations == null) {
            assetTypeAssociations = new ArrayList<PlaceholderAssetTypeAssociation>();
        }
        return this.assetTypeAssociations;
    }

    public List<PlaceholderTagTypeAssociation> getTagTypeAssociations() {
        if (tagTypeAssociations == null) {
            tagTypeAssociations = new ArrayList<PlaceholderTagTypeAssociation>();
        }
        return this.tagTypeAssociations;
    }

    public TextType getPlaceholderId() {
        return placeholderId;
    }

    public void setPlaceholderId(TextType placeholderId) {
        this.placeholderId = placeholderId;
    }

}
