/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.asset.model.constants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.AssetGroupAssociation;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.model.Edge;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.EnterpriseType;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.model.GroupAssociation;
import com.ge.apm.asset.model.GroupType;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.MeasurementTagLookup;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.Network;
import com.ge.apm.asset.model.Placeholder;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.SegmentType;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.SiteType;
import com.ge.apm.asset.model.TagCorrelation;
import com.ge.apm.asset.model.Template;
import com.ge.apm.ccom.model.MimosaCcomCategory;

@Slf4j
public abstract class Prefixes {
    public static final String AssetObjects = "/assetobjects";
    public static final String EnterpriseTypes = "/enterpriseTypes";
    public static final String SiteTypes = "/siteTypes";
    public static final String SegmentTypes = "/segmentTypes";
    public static final String AssetTypes = "/assetTypes";
    public static final String MeasurementTagTypes = "/tagTypes";
    public static final String Enterprises = "/enterprises";
    public static final String Sites = "/sites";
    public static final String Segments = "/segments";
    public static final String Assets = "/assets";
    public static final String MeasurementTags = "/tags";
    public static final String MeasurementTagLookups = "/tagLookups";
    public static final String noParent = "";

    public static final String GroupTypes = "/groupTypes";
    public static final String Groups = "/assetGroups";
    public static final String AssetGroupAssociations = "/assetgroupassociations";
    public static final String GroupAssociations = "/groupAssociations";
    public static final String ApmAssetUi = "/apmAssetUi";

    public static final String MeasurementTagCorrelations = "/tagCorrelations";

    public static final String Templates = "/assetTemplates";
    public static final String Placeholders = "/assetTemplatePlaceholders";
    public static final String TemplateConnections = "/assetTemplateConnections";

    public static final String Networks = "/networks";
    public static final String Nodes = "/nodes";
    public static final String Edges = "/edges";

    public static final String ContextConfig = "/contextConfig";

    public static final String equipmentInstances = "/equipmentInstances";

    private static final Map<String, String> CCOM_CATEGORY_URI;

    public static final String Tenants = "/tenants";

    static {
        Map<String, String> mimosaCcomCategoryForUri = new HashMap<>();
        mimosaCcomCategoryForUri.put(EnterpriseTypes, MimosaCcomCategory.ENTERPRISE_TYPE.name());
        mimosaCcomCategoryForUri.put(SiteTypes, MimosaCcomCategory.SITE_TYPE.name());
        mimosaCcomCategoryForUri.put(SegmentTypes, MimosaCcomCategory.SEGMENT_TYPE.name());
        mimosaCcomCategoryForUri.put(AssetTypes, MimosaCcomCategory.ASSET_TYPE.name());
        mimosaCcomCategoryForUri.put(Enterprises, MimosaCcomCategory.ENTERPRISE.name());
        mimosaCcomCategoryForUri.put(Sites, MimosaCcomCategory.SITE.name());
        mimosaCcomCategoryForUri.put(Segments, MimosaCcomCategory.SEGMENT.name());
        mimosaCcomCategoryForUri.put(Assets, MimosaCcomCategory.ASSET.name());
        mimosaCcomCategoryForUri.put(Groups, MimosaCcomCategory.GROUP.name());
        mimosaCcomCategoryForUri.put(Templates, MimosaCcomCategory.TEMPLATE.name());
        mimosaCcomCategoryForUri.put(MeasurementTagTypes, MimosaCcomCategory.TAG_TYPE.name());
        mimosaCcomCategoryForUri.put(MeasurementTags, MimosaCcomCategory.TAG.name());
        CCOM_CATEGORY_URI = Collections.unmodifiableMap(mimosaCcomCategoryForUri);
    }

    private enum Category {
        TAG,
        TAG_TYPE,
        ASSET,
        ASSET_TYPE,
        SEGMENT,
        SEGMENT_TYPE,
        SITE,
        SITE_TYPE,
        ENTERPRISE,
        ENTERPRISE_TYPE,
        GROUP,
        TEMPLATE,
        NETWORK,
        NODE,
        EDGE
    }

    protected Prefixes() {
    }

    public static String uri(String prefix, String uuid) {
        if (prefix == null || prefix.isEmpty()) {
            return uuid;
        }
        return prefix + "/" + uuid;
    }

    public static Class<? extends Attributable> getClass(String uri) {
        String prefix = prefixFromUri(uri);
        switch (prefix) {
            case AssetTypes:
                return AssetType.class;
            case SegmentTypes:
                return SegmentType.class;
            case SiteTypes:
                return SiteType.class;
            case EnterpriseTypes:
                return EnterpriseType.class;
            case MeasurementTagTypes:
                return MeasurementTagType.class;
            case Assets:
                return Asset.class;
            case Segments:
                return Segment.class;
            case Sites:
                return Site.class;
            case Enterprises:
                return Enterprise.class;
            case MeasurementTags:
                return MeasurementTag.class;
            case MeasurementTagLookups:
                return MeasurementTagLookup.class;
            case MeasurementTagCorrelations:
                return TagCorrelation.class;
            case Groups:
                return Group.class;
            case GroupAssociations:
                return GroupAssociation.class;
            case AssetGroupAssociations :
                return AssetGroupAssociation.class;
            case GroupTypes:
                return GroupType.class;
            case Templates:
                return Template.class;
            case Placeholders:
                return Placeholder.class;
            case Networks:
                return Network.class;
            case Edges:
                return Edge.class;
            default:
                return null;
        }
    }

    public static String getCcomTypeForPrefix(String prefix) {
        return CCOM_CATEGORY_URI.get(prefix);
    }

    public static String getPrefixByCategory(String category) {
        switch (Category.valueOf(category.toUpperCase())) {
            case TAG:
                return Prefixes.MeasurementTags;
            case TAG_TYPE:
                return Prefixes.MeasurementTagTypes;
            case ASSET:
                return Prefixes.Assets;
            case ASSET_TYPE:
                return Prefixes.AssetTypes;
            case SEGMENT:
                return Prefixes.Segments;
            case SEGMENT_TYPE:
                return Prefixes.SegmentTypes;
            case SITE:
                return Prefixes.Sites;
            case SITE_TYPE:
                return Prefixes.SiteTypes;
            case ENTERPRISE:
                return Prefixes.Enterprises;
            case ENTERPRISE_TYPE:
                return Prefixes.EnterpriseTypes;
            case GROUP:
                return Prefixes.Groups;
            case TEMPLATE:
                return Prefixes.Templates;
            case NETWORK:
                return Prefixes.Networks;
            case NODE:
                return Prefixes.Nodes;
            case EDGE:
                return Prefixes.Edges;
            default:
                throw new IllegalStateException("Invalid associated entity type");
        }
    }

    public static String getTypePrefix(String prefix) {
        switch (prefix) {
            case Enterprises:
                return Prefixes.EnterpriseTypes;
            case Sites:
                return Prefixes.SiteTypes;
            case Segments:
                return Prefixes.SegmentTypes;
            case Assets:
                return Prefixes.AssetTypes;
            case MeasurementTags:
                return Prefixes.MeasurementTagTypes;
            case Groups:
                return Prefixes.GroupTypes;
            case GroupAssociations:
                return Prefixes.GroupTypes;
            default:
                throw new IllegalStateException("Invalid prefix");
        }
    }

    public static boolean isValidType(String instancePrefix, String typePrefix) {
        return (getTypePrefix(instancePrefix).compareTo(typePrefix) == 0);
    }

    public static boolean isValidParent(String prefix, String parentPrefix) {
        return (getParentPrefixes(prefix).contains(parentPrefix));
    }

    public static List<String> getParentPrefixes(String prefix) {
        List<String> parentPrefixes = new ArrayList<>();
        switch (prefix) {
            case Enterprises:
                parentPrefixes.add(Prefixes.Enterprises);
                parentPrefixes.add(Prefixes.noParent);
                break;
            case Sites:
                parentPrefixes.add(Prefixes.Enterprises);
                parentPrefixes.add(Prefixes.Sites);
                parentPrefixes.add(Prefixes.noParent);
                break;
            case Segments:
                parentPrefixes.add(Prefixes.Sites);
                parentPrefixes.add(Prefixes.Segments);
                parentPrefixes.add(Prefixes.noParent);
                break;
            case Assets:
                parentPrefixes.add(Prefixes.Sites);
                parentPrefixes.add(Prefixes.Segments);
                parentPrefixes.add(Prefixes.Assets);
                parentPrefixes.add(Prefixes.noParent);
                break;
            case Groups:
                parentPrefixes.add(null);
                break;
            case EnterpriseTypes:
                parentPrefixes.add(EnterpriseTypes);
                break;
            case SiteTypes:
                parentPrefixes.add(Prefixes.SiteTypes);
                break;
            case SegmentTypes:
                parentPrefixes.add(Prefixes.SegmentTypes);
                break;
            case AssetTypes:
                parentPrefixes.add(Prefixes.AssetTypes);
                break;
            case MeasurementTagTypes:
                parentPrefixes.add(Prefixes.MeasurementTagTypes);
                break;
            case GroupTypes:
                parentPrefixes.add(null);
                break;
            case Placeholders:
                parentPrefixes.add(Prefixes.Placeholders);
                break;
            default:
                throw new IllegalStateException("Invalid prefix");
        }
        return parentPrefixes;
    }

    public static String prefixFromUri(final String uri) {
        String result = "";
        try {
            if (!StringUtils.isEmpty(uri)) {
                result = uri;
                if (uri.startsWith("/")) {
                    result = result.substring(1, uri.length());
                }
                if (result.endsWith("/")) {
                    result = result.substring(0, result.length() - 1);
                }
                String[] temp = result.split("/");
                if (temp.length == 1) {
                    result = "/" + temp[0];
                } else if (temp.length > 1) {
                    result = "/" + temp[temp.length - 2];
                } else {
                    throw new IllegalArgumentException(uri);
                }
            }
        } catch (ArrayIndexOutOfBoundsException ae) {
            throw ae;
        }
        return result;
    }
}
