package com.ge.apm.asset.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContextConfiguration implements Serializable {
    private static final long serialVersionUID = -4241399504993303949L;

    private String contextName;
    private String codeType;
    private String reservedCodeValidationExpression;
    private Boolean isReservedAttributeConfig;
    private String contextType;

}
