package com.ge.apm.asset.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContextConfigValue implements Serializable {
    private static final long serialVersionUID = 93851206318304972L;

    private String context;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String tenantId;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String code;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String displayName;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Boolean isActive;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Boolean isDefault;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String semanticName;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String description;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String value;


}
