package com.ge.apm.asset.model;

import java.io.Serializable;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@EqualsAndHashCode
public class TemplateTagPreview implements Serializable {

    private static final long serialVersionUID = -1L;

    String templateSourceKey;
    String placeholderId;
    String tagSourceKey;
    String tagName;

}
