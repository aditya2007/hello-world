/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.model;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
//@JsonSubTypes({ @JsonSubTypes.Type(value = PlaceholderTagTypeAssociation.class, name = "placeholderTagAssociation") })
@JsonIgnoreProperties(ignoreUnknown=true)
public class PlaceholderTagTypeAssociation extends EntityAssociation {
    public static enum CATEGORY {
        CONTRIBUTING,
        OUTPUT,
        TEMPORARY
    }

    private static final long serialVersionUID = -7330825437650280797L;

    private CATEGORY category;

    private List<TagExpression> tagExpressions;

}
