/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.asset.model;

import java.io.Serializable;

import com.google.gson.JsonObject;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class DownloadTask implements Serializable {

    private static final long serialVersionUID = -221327153259155472L;

    private String taskUuid;

    private String taskStatus;

    private String description;

    private JsonObject taskResponse;

    private Long lastUpdatedTime;

    public DownloadTask() {
        //DoNothing
    }

    public DownloadTask(String taskUuid, String taskStatus, String description,
        Long lastUpdatedTime,
        JsonObject taskResponse) {
        this.taskUuid = taskUuid;
        this.taskStatus = taskStatus;
        this.lastUpdatedTime = lastUpdatedTime;
        this.taskResponse = taskResponse;
        this.description = description;
    }

}
