package com.ge.apm.asset.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Holds the filters for retrieving ALM configuration based on given filter condition
 */
@Getter
@Setter
@ToString(callSuper = true)
public class ConfigContextQuery {

    String[] context;
    Boolean isActive;
    String[] code;
    String[] semanticName;
    String[] displayName;

    public boolean isAlmFilter() {
        return (context != null ||  isActive != null);
    }

    public boolean isEmpty() {
        return (context == null &&  isActive == null && code == null && semanticName == null && displayName == null);
    }
}
