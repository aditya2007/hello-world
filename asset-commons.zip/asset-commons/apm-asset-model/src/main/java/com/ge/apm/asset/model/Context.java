/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Context extends ConfigEntity {

    private static final long serialVersionUID = -5231507481326673215L;

    private String contextName;

    private String codeType;

    private String reservedCodeValidationExpression;

    private Boolean isReservedAttributeConfig;

    private String contextType;

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Context context = (Context) obj;

        if (!contextName.equals(context.contextName)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return contextName.hashCode();
    }
}
