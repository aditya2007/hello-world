/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.asset.model;

import com.ge.apm.asset.model.annotations.IgnoreBadRequest;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.LinkedHashSet;

@Getter
@Setter
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
//@JsonSubTypes({ @JsonSubTypes.Type(value = MeasurementTag.class, name = "measurementTag") })
public class MeasurementTag extends Typed {
    public static final String MonitoredEntityUri = "monitoredEntityUri";
    public static final String Aliases = "aliases";
    public static final String Correlation = "correlation";
    private static final long serialVersionUID = -5573088558138857079L;

    private DataSourceType tagType;

    private String monitoredEntityUri;
    private String monitoredEntitySourceKey;
    private String[] aliases;
    private String[] correlation;

    @IgnoreBadRequest
    private String monitoredEntityName;
    @IgnoreBadRequest
    private String monitoredEntityAlias;

    private NextCorrelatedTag nextRelatedTag;
    private String tagCorrelationUri;
    @IgnoreBadRequest
    private LinkedHashSet<MeasurementTag> tagCorrelations;
    @IgnoreBadRequest
    private MeasurementTagType measurementTagType;
}
