package com.ge.apm.asset.model;


import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Unit implements Serializable {

    private static final long serialVersionUID = 5904704689524580808L;

    @JsonProperty("unit")
    private String unit;

    @JsonIgnore
    private List<Link> links;
     /**
     *
     * @return
     * The unit
     */
    @JsonProperty("unit")
    public String getUnit() {
        return unit;
    }

    /**
     *
     * @param unit
     * The unit
     */
    @JsonProperty("unit")
    public void setUnit(String unit) {
        this.unit = unit;
    }

    /**
     *
     * @return
     * The links
     */
    public List<Link> getLinks() {
        return links;
    }

    /**
     *
     * @param links
     * The links
     */
    public void setLinks(List<Link> links) {
        this.links = links;
    }


}

