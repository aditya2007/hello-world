package com.ge.apm.asset.model;

import java.util.List;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by 212578721 on 10/5/17.
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class AssetFeature {

    String uuid;
    String name;
    String description;
    String filterOn;
    List<String> applicableSuperTypes;
    boolean requireUserInput;

}
