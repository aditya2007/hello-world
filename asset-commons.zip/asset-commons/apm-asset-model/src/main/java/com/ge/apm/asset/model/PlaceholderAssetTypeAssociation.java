/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.model;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
//@JsonSubTypes({ @JsonSubTypes.Type(value = PlaceholderAssetTypeAssociation.class, name = "placeholderAssociation") })
public class PlaceholderAssetTypeAssociation extends EntityAssociation {
    private static final long serialVersionUID = 1618906398448512481L;
    public static final String IsPrimary = "isPrimary";
    public static final String Status = "status";

    private Boolean isPrimary;
    private String status;

}
