/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.asset.model;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReservedAttributeConfig  implements Serializable{
    private static final long serialVersionUID = 2632354746770322923L;
    public  enum DataType {
        String, Integer, Double, KeyValue, UnitOfMeasure
    };
    private String name;
    private String displayName;
    private String type;
    private String possibleValuesContext;
    private Object permissionsContext;
    private List<Object> possibleValues;
    private Object defaultValue;
    private String tenant;
    public enum ArrayTypeEnum {
        NA, ONE_DIMENSIONAL
    };
    private Boolean overwrite;
    private String arrayType;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private InstanceApplicability instanceApplicability;

    @Getter
    @Setter
    @ToString(callSuper = true)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public class InstanceApplicability implements Serializable {
        private String arrayType;
        private Boolean overwrite;
    }
}
