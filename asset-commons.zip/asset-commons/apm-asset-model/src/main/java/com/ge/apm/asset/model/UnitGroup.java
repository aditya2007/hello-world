package com.ge.apm.asset.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UnitGroup implements Serializable {

    private static final long serialVersionUID = -3981739552271160629L;
    @JsonProperty("unitGroup")
    private String unitGroup;
    @JsonIgnore
    private Link[] links;
    @JsonProperty("measurementUnitResource")
    private Unit[] units;
    /**
     *
     * @return
     * The unitGroup
     */
    @JsonProperty("unitGroup")
    public String getUnitGroup() {
        return unitGroup;
    }

    /**
     *
     * @param unitGroup
     * The unitGroup
     */
    @JsonProperty("unitGroup")
    public void setUnitGroup(String unitGroup) {
        this.unitGroup = unitGroup;
    }

    /**
     *
     * @return
     * The links
     */
    public Link[] getLinks() {
        return links;
    }

    /**
     *
     * @param links
     * The links
     */
    public void setLinks(Link[] links) {
        this.links = links;
    }

    /**
     *
     * @return
     * The units
     */
    public Unit[] getUnits() {
        return units;
    }

    /**
     *
     * @param units
     * The units
     */
    public void setUnits(Unit[] units) {
        this.units = units;
    }


}

