/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.model;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Created by 212578721 on 7/25/17.
 */
public enum Direction {

    UNIDIRECTIONAL,
    BIDIRECTIONAL,
    UNDIRECTED;

    private static Map<String, Direction> namesMap = new HashMap<>(3);

    static {
        namesMap.put("unidirectional", UNIDIRECTIONAL);
        namesMap.put("bidirectional", BIDIRECTIONAL);
        namesMap.put("undirected", UNDIRECTED);
    }

    @JsonCreator
    public static Direction forValue(String value) {
        return namesMap.get(value.toLowerCase());
    }
}