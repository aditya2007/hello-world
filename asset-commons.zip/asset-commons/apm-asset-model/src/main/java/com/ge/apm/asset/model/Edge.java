/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.model;

/**
 * Created by 212578721 on 7/19/17.
 */

import com.ge.apm.asset.model.annotations.IgnoreBadRequest;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
//@JsonSubTypes({ @JsonSubTypes.Type(value = Edge.class, name = "edge") })
public class Edge extends Attributable {

    private static final long serialVersionUID = 2634654746770322923L;

    private Direction direction;

    @IgnoreBadRequest
    private NetworkNode source;

    @IgnoreBadRequest
    private NetworkNode target;

    @IgnoreBadRequest
    private String businessObjectUri;

    @IgnoreBadRequest
    private String businessObjectSourceKey;

    @IgnoreBadRequest
    private String businessObjectCategory;

    @IgnoreBadRequest
    private BusinessObject businessObject;

}
