package com.ge.apm.asset.model.annotations;

import com.fasterxml.jackson.annotation.JacksonAnnotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by 212590467 on 11/9/16.
 */
@JacksonAnnotation
@Retention(RetentionPolicy.RUNTIME)
public @interface IgnoreBadRequest {
}
