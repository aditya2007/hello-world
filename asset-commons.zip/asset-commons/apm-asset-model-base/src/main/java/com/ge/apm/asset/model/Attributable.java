/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.asset.model;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.asset.model.annotations.IgnoreBadRequest;

@Getter
@Setter
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true, exclude = "persistedObject")
public class Attributable extends Named {
    private static final long serialVersionUID = 3888538238586315559L;
    public static final String Attributes = "attributes";
    public static final String ReservedAttributes = "reservedAttributes";

    private LinkedHashMap<String, Attribute> attributes;

    private Map<String, Object> reservedAttributes;

    public static final String CreatedDate = "createdDate";
    public static final String LastModifiedDate = "lastModifiedDate";
    @IgnoreBadRequest
    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern= "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone= "UTC")
    private Date createdDate;
    @IgnoreBadRequest
    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern= "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone= "UTC")
    private Date lastModifiedDate;

    @IgnoreBadRequest
    @JsonIgnore
    private transient Object persistedObject;

    @SuppressWarnings("unchecked")
    @IgnoreBadRequest
    @JsonIgnore
    public <T> T getPersistedObject() {
        return (T) persistedObject;
    }
}
