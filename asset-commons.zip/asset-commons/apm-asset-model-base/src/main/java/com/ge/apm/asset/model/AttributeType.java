/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.asset.model;

import static java.util.Arrays.asList;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum AttributeType {
    UNDEFINED(Object.class) {
        public boolean isMember(Object value) {
            for (AttributeType each :
                    asList(Character, Number, Short, Integer, /*Long,*/ Float, Double, Boolean, Timestamp, String, Grid)) {
                if (each.isMember(value)) {
                    return true;
                }
            }
            return false;
        }

        @Override
        public List<Object> queryValues(String value) {
            List<Object> values = new ArrayList<>();
            for (AttributeType each :
                    asList(Character, Number, Short, Integer, /*Long,*/ Float, Double, Boolean, Timestamp, String, Grid)) {
                List<Object> converted = Collections.emptyList();
                try {
                    converted = each.queryValues(value);
                } catch (Exception e) {
                    log.error("Failed to process {}: {}", value, e);
                }
                values.addAll(converted);
            }
            return values;
        }
    },

    Character(Character.class) {
        @Override
        public List<Object> queryValues(String value) {
            return value.length() == 1 ? Collections.singletonList(value.charAt(0)) : Collections.emptyList();
        }

        @Override
        public boolean isMember(Object value) {
            return super.isMember(value) || (value instanceof String && value.toString().length() == 1);
        }
    },

    Number(Number.class) {
        @Override
        public List<Object> queryValues(String value) {
            return Collections.singletonList(java.lang.Double.parseDouble(value));
        }
    },

    Short(Short.class) {
        @Override
        public List<Object> queryValues(String value) {
            return Collections.singletonList(java.lang.Short.parseShort(value));
        }

        @Override
        public boolean isMember(Object value) {
            return super.isMember(value) ||
                    (value instanceof Integer &&
                            (Integer) value <= java.lang.Short.MAX_VALUE &&
                            (Integer) value >= java.lang.Short.MIN_VALUE);
        }
    },

    Integer(Integer.class) {
        @Override
        public List<Object> queryValues(String value) {
            return Collections.singletonList(java.lang.Integer.parseInt(value));
        }

        @Override
        public boolean isMember(Object value) {
            if (value instanceof Double) {
                Double d = (Double) value;
                return d.compareTo(Math.floor(d)) == 0 && !java.lang.Double.isInfinite(d);
            }
            return super.isMember(value) || value instanceof Short;
        }
    },

//    Long(Long.class) {
//        /*
//         * This is the range Predix Asset currently supports ({-2^53, 2^53-1}) due to representing
//         * numbers as 64 bit floating points (which uses 53 bits for the significand).
//         */
//        public static final long MIN_SUPPORTED_LONG = -9007199254740992L;
//        public static final long MAX_SUPPORTED_LONG = 9007199254740991L;
//
//        @Override
//        public List<Object> queryValues(String value) {
//            return Collections.singletonList(java.lang.Long.parseLong(value));
//        }
//
//        @Override
//        public boolean isMember(Object value) {
//            if (value == null) {
//                return true;
//            }
//            try {
//                long l = java.lang.Long.parseLong(value.toString());
//                return (super.isMember(value) && l <= MAX_SUPPORTED_LONG && l >= MIN_SUPPORTED_LONG) ||
//                        value instanceof Integer ||
//                        value instanceof Short;
//            } catch (Exception ex) {
//                return false;
//            }
//        }
//    },

    Float(Float.class) {
        @Override
        public List<Object> queryValues(String value) {
            return Collections.singletonList(java.lang.Float.parseFloat(value));
        }

        @Override
        public boolean isMember(Object value) {
            if (value == null) {
                return true;
            }
            try {
                float f = java.lang.Float.parseFloat(value.toString());
                return value instanceof Number && java.lang.Float.isFinite(f);
            } catch (Exception ex) {
                log.error("Error while parsing float Value ", ex);
                return false;
            }
        }
    },

    Double(Double.class) {
        @Override
        public List<Object> queryValues(String value) {
            return Collections.singletonList(java.lang.Double.parseDouble(value));
        }

        @Override
        public boolean isMember(Object value) {
            if (value == null) {
                return true;
            }
            try {
                double d = java.lang.Double.parseDouble(value.toString());
                return value instanceof Number && java.lang.Double.isFinite(d);
            } catch (Exception ex) {
                log.error("Error while parsing double Value ", ex);
                return false;
            }
        }
    },

    Boolean(Boolean.class) {
        @Override
        public List<Object> queryValues(String value) {
            return ("true".equalsIgnoreCase(value) ? Collections.singletonList(true)
                : ("false".equalsIgnoreCase(value) ? Collections.singletonList(false) : Collections.emptyList()));
        }
    },

    Timestamp(String.class) {
        @Override
        public boolean isMember(Object value) {
            //return super.isMember(value) && (value == null || TIMESTAMP_PATTERN.matcher((String) value).matches());
            return super.isMember(value) && (value == null || AttributeType.isTimeStampValid((String) value));
        }

        @Override
        public List<Object> queryValues(String value) {
            return isMember(value) ? Collections.singletonList(value) : Collections.emptyList();
        }
    },

    String(String.class) {
        @Override
        public boolean isMember(Object value) {
            return super.isMember(value);
        }

        @Override
        public List<Object> queryValues(String value) {
            return isMember(value) ? Collections.singletonList(value) : Collections.emptyList();
        }
    },

    Grid(Object.class) {
        private final ObjectReader READER = new ObjectMapper().reader(new TypeReference<Map<String, Object>>(){});
        @Override
        public boolean isMember(Object value) {
            return super.isMember(value) || (value instanceof Object);
        }

        @Override
        public List<Object> queryValues(String value) {
            Object obj = null;
            try {
                obj = READER.readValue(value);
            } catch (IOException e) {
                log.error("unable to deserialize value {}", value, e);
            }
            return isMember(value) ? Collections.singletonList(obj) : Collections.emptyList();
        }
    };

    //private static Pattern TIMESTAMP_PATTERN = Pattern.compile("(\\d{2})/(\\d{2})/(\\d{4}) (\\d{2}):(\\d{2}):"
       // + "(\\d{2})");
    private static Pattern TIMESTAMP_PATTERN = Pattern.compile("(0?[1-9]|1[012])/(0?[1-9]|[1-2][0-9]|3[0-1])/"
        + "([1-9][0-9]{3}) ([0-1]?[0-9]|2[0-3]):([0-5]?[0-9]):([0-5]?[0-9])");

    private Class<?> type;
    private static volatile Map<String,AttributeType> attributeTypeMap;

    AttributeType(Class<?> type) {
        this.type = type;
    }

    public boolean isMember(Object value) {
        return value == null || type.isAssignableFrom(value.getClass());
    }

    /**
     * Validates the input <code>value</code> can be processed as array of the same given data type.
     * @param value
     * @return
     */
    public abstract List<Object> queryValues(String value);

    public static AttributeType getAttributeType(String type) {
        synchronized (AttributeType.class) {
            if (attributeTypeMap == null) {
                synchronized (AttributeType.class) {
                    setAttributeTypeMap();
                }
            }
            Objects.requireNonNull(attributeTypeMap);
            return attributeTypeMap.get(type.toUpperCase());
        }
    }

    private static void setAttributeTypeMap() {
        attributeTypeMap = new HashMap<>();
        for (AttributeType attributeType : AttributeType.values()) {
            attributeTypeMap.put(attributeType.name().toUpperCase(), attributeType);
        }
    }

    public static String getName(String type) {
        return getAttributeType(type).name();
    }

    private static boolean isTimeStampValid(String timeStamp) {
        boolean isFeb = timeStamp.split("/")[0].matches("(0?[2])");
        if (isFeb) {
            boolean isValidFebDate = timeStamp.split("/")[1].matches("(0?[1-9]|1[1-9]|2[0-8])");
            if (!isValidFebDate) return false;
        }
        return TIMESTAMP_PATTERN.matcher(timeStamp).matches();
    }

}
