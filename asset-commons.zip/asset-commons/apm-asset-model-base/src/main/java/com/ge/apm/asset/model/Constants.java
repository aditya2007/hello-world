/******************************************************************************
 * Copyright (c) 2016 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.asset.model;

/**
 * Description of Constants
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Jul 8, 2016
 * @since 1.0
 */
public class Constants {
    public static final String UNKNOWN_PROXY_TYPE = "__UNKNOWN__";
    public static final String CONST_LOCATION_RESPONSE_HEADER = "Location";
    public static final String CONST_LOCATION_URI = "LocationUri";

    private Constants() {
        super();
    }
}
