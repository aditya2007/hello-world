/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.asset.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.asset.model.annotations.IgnoreBadRequest;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Base implements Serializable, ITypedJson {
    public static final String Uri = "uri";
    public static final String CursorState = "cursorState";
    public static final String SourceKey = "sourceKey";
    private static final long serialVersionUID = -3548823867226955436L;
    public static final String OBJECT_ID = "objectId";
    public static final String TENANT_ID = "tenantId";
    public static final String OBJECT_TYPE = "objectType";

    @IgnoreBadRequest
    private String objectId;

    @IgnoreBadRequest
    private String tenantId;

    @IgnoreBadRequest
    private String objectType;

    private String uri;
    private String sourceKey;
}
