/******************************************************************************
 * Copyright (c) 2016 GE Digital. All rights reserved.                        *
 *                                                                            *
 * The computer software herein is the property of GE Digital. The            *
 * software may be used and/or copied only with the written permission of     *
 * GE Digital or in accordance with the terms and conditions                  *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.asset.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GeoLocation implements Serializable {

    private static final long serialVersionUID = -8914431396947256746L;

    private PostalAddress postalAddress;
    private List<GeoPoint> geoPoints;
    private String timezone;
}
