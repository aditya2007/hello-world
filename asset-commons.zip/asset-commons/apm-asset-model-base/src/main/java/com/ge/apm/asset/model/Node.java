package com.ge.apm.asset.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * Created by 212430317 on 7/24/16.
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Node implements Serializable {
    private static final long serialVersionUID = 7596448376727051718L;
    private String id;
    private String uri;
    private String name;
    private boolean isOpenable = false;
    private boolean hasChildren = false;
    private String childResourcesUri;

    public void setIsOpenable(boolean pIsOpenable) {
        this.isOpenable = pIsOpenable;
    }

    public boolean getIsOpenable() {
        return this.isOpenable;
    }
}
