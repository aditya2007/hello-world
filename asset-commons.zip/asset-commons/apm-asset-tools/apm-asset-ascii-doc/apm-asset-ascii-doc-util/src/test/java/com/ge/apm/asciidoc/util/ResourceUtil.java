/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asciidoc.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.apm.common.exception.ServiceException;

public class ResourceUtil {

    protected static final Logger LOGGER = LoggerFactory.getLogger(ResourceUtil.class);

    public static String getResourceDirAbsolutePath(String resourceDir) {
        URL resource = ResourceUtil.class.getClassLoader().getResource(resourceDir);
        if (resource == null) {
            String errorMessage = String.format("Cannot get URL for the resource directory '%s'", resourceDir);
            LOGGER.error("{}", errorMessage);
            throw new ServiceException(errorMessage);
        }
        File directory;
        try {
            directory = Paths.get(resource.toURI()).toFile();
        } catch (URISyntaxException exception) {
            String errorMessage = String.format("Error getting the File Object for dir '%s''.\n%s", resourceDir,
                exception.getMessage());
            LOGGER.error("{}", errorMessage, exception);
            throw new ServiceException(errorMessage);
        }

        return directory.getAbsolutePath() + "/";
    }

    public static <T> void writeToResourceFileAbsolutePath(String absolutePath, String fileName,
        Class<T> inputDataClass, Object data) {
        String filePath = absolutePath + fileName;
        LOGGER.info("Writing file to cache: '{}'", filePath);
        try {
            File file = new File(new File(filePath).toURI());
            if (inputDataClass == String.class) {
                FileUtils.writeStringToFile(file, (String) data);
            } else if (inputDataClass == byte.class) {
                Files.write(Paths.get(new File(filePath).toURI()), (byte[]) data);
            } else {
                String errorMessage = String.format("Cannot write the resource file '%s' to the directory '%s' "
                    + "because the class type '%s' is not handled.", fileName, absolutePath, inputDataClass.getName());
                LOGGER.error("{}", errorMessage);
                throw new ServiceException(errorMessage);
            }
        } catch (IOException exceptionxception) {
            String errorMessage = String.format("Error creating the file '%s'. %s", filePath,
                exceptionxception.getMessage());
            LOGGER.error("{}", errorMessage, exceptionxception);
            throw new ServiceException(errorMessage);
        }
    }

    public static <T> void writeToResourceFile(String relativePath, String fileName, Class<T> inputDataClass,
        Object data) {
        String absolutePath = getResourceDirAbsolutePath(relativePath);
        writeToResourceFileAbsolutePath(absolutePath, fileName, inputDataClass, data);
    }

    public static boolean isResourceFileExists(String resourceDir, String fileName) {
        String directory = getResourceDirAbsolutePath(resourceDir);
        File file = new File(directory + fileName);
        return file.exists();
    }

    public static String readResourceFileAsString(String fileName) {
        byte[] bytes = readResourceFile(fileName);

        try {
            return new String(bytes, "UTF-8");
        } catch (UnsupportedEncodingException excp) {
            String errorMessage = "Cannot convert config json byte array into string. " + System.lineSeparator() + excp
                .getMessage();
            LOGGER.error("{}", errorMessage);
            LOGGER.error("", excp);
            throw new ServiceException(errorMessage);
        }
    }

    public static byte[] readResourceFile(String fileName) {
        String methodName = "readFromJarResourceFileAsBytes";
        LOGGER.info("Reading resource file: '{}'", fileName);

        // input stream included with try to avoid the resource leak.
        try(InputStream inputStream = ResourceUtil.class.getResourceAsStream(fileName)) {
            if (inputStream != null) {
                return IOUtils.toByteArray(inputStream);
            }
        } catch (IOException excp) {
            String errorMessage = String.format("Error reading the resource '%s'.", fileName);
            LOGGER.error("{}| {}", methodName, errorMessage);
            LOGGER.error("", excp);
            throw new ServiceException(errorMessage + "  " + System.lineSeparator() + "  " + excp.getMessage());
        }

        return readResourceFileAlternate(fileName);
    }

    public static <T> File getJarDir(Class<T> aclass) {
        URL url;

        // get an url
        try {
            url = aclass.getProtectionDomain().getCodeSource().getLocation();
            // url is in one of two forms
            // ./build/classes/ NetBeans test
            // jardir/JarName.jar froma jar
        } catch (SecurityException ex) {
            url = aclass.getResource(aclass.getSimpleName() + ".class");
            // url is in one of two forms, both ending "/com/physpics/tools/ui/PropNode.class"
            // file:/U:/Fred/java/Tools/UI/build/classes
            // jar:file:/U:/Fred/java/Tools/UI/dist/UI.jar!
        }

        // convert to external form
        String extUrl = url.toExternalForm();

        // prune for various cases
        // from getCodeSource
        if (extUrl.endsWith(".jar")) {
            extUrl = extUrl.substring(0, extUrl.lastIndexOf("/"));
        } else { // from getResource
            String suffix = "/" + (aclass.getName()).replace(".", "/") + ".class";
            extUrl = extUrl.replace(suffix, "");
            if (extUrl.startsWith("jar:") && extUrl.endsWith(".jar!")) {
                extUrl = extUrl.substring(4, extUrl.lastIndexOf("/"));
            }
        }

        // convert back to url
        try {
            url = new URL(extUrl);
        } catch (MalformedURLException mux) {
            // leave url unchanged; probably does not happen
        }

        // convert url to File
        try {
            return new File(url.toURI());
        } catch (URISyntaxException ex) {
            return new File(url.getPath());
        }
    }

    private static byte[] readResourceFileAlternate(String fileName) {
        String methodName = "readResourceFileAlternate";
        URL resourceUrl = ResourceUtil.class.getClassLoader().getResource(fileName);
        if (resourceUrl == null) {
            String errorMessage = String.format("Unknown error. Cannot find the resource file '%s'", fileName);
            LOGGER.error("{}| {}", methodName, errorMessage);
            throw new ServiceException(errorMessage);
        }
        File file = new File(resourceUrl.getFile());

        try {
            return Files.readAllBytes(file.toPath());
        } catch (IOException excp) {
            String errorMessage = String.format("Error reading the resource '%s'.", fileName);
            LOGGER.error("{}| {}", methodName, errorMessage);
            LOGGER.error("", excp);
            throw new ServiceException(errorMessage + "  " + System.lineSeparator() + "  " + excp.getMessage());
        }
    }
}
