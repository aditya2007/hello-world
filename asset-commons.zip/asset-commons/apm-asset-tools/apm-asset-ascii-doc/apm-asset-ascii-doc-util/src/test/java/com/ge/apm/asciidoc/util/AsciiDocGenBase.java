/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asciidoc.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.hamcrest.MatcherAssert;
import org.hamcrest.core.AnyOf;
import org.hamcrest.core.Is;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.mockmvc.MockMvcRestDocumentation;
import org.springframework.restdocs.mockmvc.RestDocumentationResultHandler;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.restdocs.request.ParameterDescriptor;
import org.springframework.restdocs.snippet.Snippet;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.RequestPostProcessor;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;

import com.ge.apm.asciidoc.util.preprocess.AsciiDocContentPreProcess;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.util.JsonHelper;

import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.delete;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.fileUpload;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.get;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.patch;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.post;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.put;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessRequest;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.restdocs.payload.PayloadDocumentation.requestFields;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;
import static org.springframework.restdocs.request.RequestDocumentation.pathParameters;
import static org.springframework.restdocs.request.RequestDocumentation.requestParameters;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class AsciiDocGenBase {

    @SuppressWarnings("WeakerAccess")
    public static final Object[] defaultPathVariables = new Object[] {};

    @SuppressWarnings("WeakerAccess")
    public static final ParameterDescriptor[] defaultRequestParamDescriptors = new ParameterDescriptor[] {};

    @SuppressWarnings("WeakerAccess")
    public static final ParameterDescriptor[] defaultPathVariableDescriptors = new ParameterDescriptor[] {};

    @SuppressWarnings("WeakerAccess")
    public static final FieldDescriptor[] defaultRequestFieldDescriptors = new FieldDescriptor[] {};

    @SuppressWarnings("WeakerAccess")
    public static final FieldDescriptor[] defaultResponseFieldDescriptors = new FieldDescriptor[] {};

    @SuppressWarnings("WeakerAccess")
    public static final MultiValueMap<String, String> defaultOverrideHeaders = new LinkedMultiValueMap<>();

    @SuppressWarnings("WeakerAccess")
    public static final String[] defaultRemoveResponseFields = new String[] {};

    private static final Logger log = LoggerFactory.getLogger(AsciiDocGenBase.class);

    @Rule
    public JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

    @Autowired
    private WebApplicationContext context;

    private MockMvc mockMvc;

    private AsciiDocContentPreProcess asciiDocContentPreProcess;

    @Value("#{'${exclude.request.headers:}'.length() > 0 ? '${exclude.request.headers:}'.split(',') : null}")
    private List<String> requestHeadersForExclusion;

    @Value("#{'${exclude.response.headers:}'.length() > 0 ? '${exclude.response.headers:}'.split(',') : null}")
    private List<String> responseHeadersForExclusion;

    @Value("#{'${mask.request.headers:}'.length() > 0 ? '${mask.request.headers:}'.split(',') : null}")
    private List<String> requestHeadersForMask;

    @Value("#{'${mask.response.headers:}'.length() > 0 ? '${mask.response.headers:}'.split(',') : null}")
    private List<String> responseHeadersForMask;

    private List<OperationPreprocessor> requestPreprocessors = new ArrayList<>();

    private List<OperationPreprocessor> responsePreprocessors = new ArrayList<>();

    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.context).apply(documentationConfiguration(
            this.restDocumentation).uris().withScheme("https").withHost("apm-asset-svc-domain").withPort(443)).build();

        this.asciiDocContentPreProcess = new AsciiDocContentPreProcess(this.requestHeadersForExclusion,
            this.responseHeadersForExclusion, this.requestHeadersForMask, this.responseHeadersForMask);

        this.requestPreprocessors.add(this.asciiDocContentPreProcess);
        this.requestPreprocessors.add(prettyPrint());

        this.responsePreprocessors.add(this.asciiDocContentPreProcess);
        this.responsePreprocessors.add(prettyPrint());
    }

    public <R> R doGet(String uri, Class<R> responseType, FieldDescriptor[] responseFieldDescriptors) {
        return doGet(uri, defaultPathVariables, defaultPathVariableDescriptors, defaultRequestParamDescriptors,
            responseType, responseFieldDescriptors, defaultRemoveResponseFields, defaultOverrideHeaders);
    }

    public <R> R doGet(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, Class<R> responseType,
        FieldDescriptor[] responseFieldDescriptors, String[] removeResponseFields,
        MultiValueMap<String, String> overrideHeaders) {
        return invokeUri(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, HttpMethod.GET, null
            /* requestInput */, defaultRequestFieldDescriptors, responseType, responseFieldDescriptors,
            removeResponseFields, overrideHeaders);
    }

    private <I, R> R invokeUri(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, HttpMethod httpMethod, I requestInput,
        FieldDescriptor[] requestFieldDescriptors, Class<R> responseType, FieldDescriptor[] responseFieldDescriptors,
        String[] removeResponseFields, MultiValueMap<String, String> overrideHeaders) {

        return invokeUri(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, httpMethod, requestInput,
            requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields, overrideHeaders,
            MediaType.APPLICATION_JSON);
    }

    private <I, R> R invokeUri(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, HttpMethod httpMethod, I requestInput,
        FieldDescriptor[] requestFieldDescriptors, Class<R> responseType, FieldDescriptor[] responseFieldDescriptors,
        String[] removeResponseFields, MultiValueMap<String, String> overrideHeaders, MediaType mediaType) {

        return invokeUri(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, httpMethod, requestInput,
            requestFieldDescriptors, null /* removeRequestFields */, responseType, responseFieldDescriptors,
            removeResponseFields, overrideHeaders, mediaType);
    }

    private <I> MockHttpServletRequestBuilder getRequestBuilderForMultipartFile(String uri, Object[] pathVariables,
        I requestInput, HttpMethod httpMethod) {
        MockHttpServletRequestBuilder requestBuilder;
        if (requestInput instanceof MockMultipartFile) {
            requestBuilder = fileUpload(uri, pathVariables).file((MockMultipartFile) requestInput);
        } else if (requestInput instanceof List) {
            if (((List) requestInput).size() > 0) {
                //URI createdUri = URI.create(uri);
                MockMultipartHttpServletRequestBuilder builder = fileUpload(uri, pathVariables);
                if (((List) requestInput).get(0) instanceof MultipartFile) {
                    for (Object mfile : (List) requestInput) {
                        builder.file((MockMultipartFile) mfile);
                    }
                    if (httpMethod == HttpMethod.PUT) {
                        builder.with(new RequestPostProcessor() {
                            @Override
                            public MockHttpServletRequest postProcessRequest(MockHttpServletRequest request) {
                                request.setMethod("PUT");
                                return request;
                            }
                        });
                    }

                    requestBuilder = builder;
                } else {
                    requestBuilder = getRequestBuilderForRequestType(uri, pathVariables, httpMethod);
                }
            } else {
                requestBuilder = getRequestBuilderForRequestType(uri, pathVariables, httpMethod);
            }
        } else {
            requestBuilder = getRequestBuilderForRequestType(uri, pathVariables, httpMethod);
        }
        return requestBuilder;
    }

    private MockHttpServletRequestBuilder getRequestBuilderForRequestType(String uri, Object[] pathVariables,
        HttpMethod httpMethod) {
        switch (httpMethod) {
            case GET:
                return get(uri, pathVariables);
            case POST:
                return post(uri, pathVariables);
            case PUT:
                return put(uri, pathVariables);
            case PATCH:
                return patch(uri, pathVariables);
            case DELETE:
                return delete(uri, pathVariables);
            default:
                throw new RuntimeException(
                    String.format("HttpMethod value '%s' is not handled.", httpMethod.toString()));
        }
    }

    @SuppressWarnings("ConstantConditions")
    private <I, R> R invokeUri(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, HttpMethod httpMethod, I requestInput,
        FieldDescriptor[] requestFieldDescriptors, String[] removeRequestFields, Class<R> responseType,
        FieldDescriptor[] responseFieldDescriptors, String[] removeResponseFields,
        MultiValueMap<String, String> overrideHeaders, MediaType mediaType) {
        R responseObject = null;
        try {

            pathVariables = pathVariables != null ? pathVariables : defaultPathVariables;
            pathVariableDescriptors = pathVariableDescriptors != null ? pathVariableDescriptors
                : defaultPathVariableDescriptors;
            requestParamDescriptors = requestParamDescriptors != null ? requestParamDescriptors
                : defaultRequestParamDescriptors;
            requestFieldDescriptors = requestFieldDescriptors != null ? requestFieldDescriptors
                : defaultRequestFieldDescriptors;
            responseFieldDescriptors = responseFieldDescriptors != null ? responseFieldDescriptors
                : defaultResponseFieldDescriptors;
            removeResponseFields = removeResponseFields != null ? removeResponseFields : defaultRemoveResponseFields;
            overrideHeaders = overrideHeaders != null ? overrideHeaders : defaultOverrideHeaders;

            this.asciiDocContentPreProcess.setRemoveResponseFields(removeResponseFields);

            MockHttpServletRequestBuilder requestBuilder;

            if (httpMethod == HttpMethod.POST || httpMethod == HttpMethod.PUT) {
                requestBuilder = getRequestBuilderForMultipartFile(uri, pathVariables, requestInput, httpMethod);
            } else {
                requestBuilder = getRequestBuilderForRequestType(uri, pathVariables, httpMethod);
            }

            requestBuilder = requestBuilder.headers(getHeaders(overrideHeaders));
            requestBuilder = requestBuilder.contentType(mediaType);

            if (requestInput != null) {
                if (requestInput instanceof MockMultipartFile
                    || requestInput instanceof List && ((List) requestInput).size() > 0 && ((List) requestInput).get(
                    0) instanceof MultipartFile) {
                    //do nothing because payload is part of file to be uploaded.

                } else {

                    byte[] requestInputBytes;
                    if (removeRequestFields != null && removeRequestFields.length > 0) {
                        Map<String, Object> jsonMap = JsonHelper.fromJsonToMap(requestInput);
                        Arrays.stream(removeRequestFields).forEach(jsonMap::remove);
                        requestInputBytes = JsonHelper.toJson(jsonMap).getBytes();
                    } else {
                        requestInputBytes = JsonHelper.toJson(requestInput).getBytes();
                    }

                    requestBuilder = requestBuilder.content(requestInputBytes);
                }
            }

            ResultActions resultActions = this.mockMvc.perform(requestBuilder).andExpect(validateStatus()).andDo(
                document(pathVariableDescriptors, requestParamDescriptors, requestFieldDescriptors,
                    responseFieldDescriptors));

            MvcResult mvcResult = resultActions.andReturn();

            MockHttpServletResponse servletResponse = mvcResult.getResponse();
            String responseBody = servletResponse.getContentAsString();

            responseObject = getResponse(responseBody, responseType);
        } catch (Exception exception) {
            log.error("", exception);
            Assert.fail(exception.getMessage());
        }

        return responseObject;
    }

    public ResultMatcher validateStatus() {
        return result -> {
            int status = result.getResponse().getStatus();
            System.out.println("HttpStatus:" + status);
            //noinspection unchecked
            MatcherAssert.assertThat(new String(result.getResponse().getContentAsByteArray()), status,
                AnyOf.anyOf(Is.is(200), Is.is(201), Is.is(202), Is.is(203), Is.is(204), Is.is(205), Is.is(206)));
        };
    }

    private RestDocumentationResultHandler document(ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, FieldDescriptor[] requestFieldDescriptors,
        FieldDescriptor[] responseFieldDescriptors) {

        List<Snippet> snippets = new ArrayList<>();

        if (pathVariableDescriptors.length != 0) {
            snippets.add(pathParameters(pathVariableDescriptors));
        }

        if (requestParamDescriptors.length != 0) {
            snippets.add(requestParameters(requestParamDescriptors));
        }

        if (requestFieldDescriptors.length != 0) {
            snippets.add(requestFields(requestFieldDescriptors));
        }

        if (responseFieldDescriptors.length != 0) {
            snippets.add(responseFields(responseFieldDescriptors));
        }

        return MockMvcRestDocumentation.document("{class-name}/{method-name}", preprocessRequest(
            this.requestPreprocessors.toArray(new OperationPreprocessor[this.requestPreprocessors.size()])),
            preprocessResponse(
                this.responsePreprocessors.toArray(new OperationPreprocessor[this.responsePreprocessors.size()])),
            snippets.toArray(new Snippet[snippets.size()]));
    }

    private <R> R getResponse(String response, Class<R> responseType) {
        if (response == null || responseType == null || responseType == Void.class) {
            return null;
        }

        if (responseType == String.class) {
            //noinspection unchecked
            return (R) response;
        } else {
            return JsonHelper.fromJson(response, responseType);
        }
    }

    private HttpHeaders getHeaders(MultiValueMap<String, String> overrideHeaders) {
        MultiValueMap<String, String> mapHeaders = overrideHeaders;

        if (mapHeaders == null) {
            mapHeaders = new LinkedMultiValueMap<>();
        }

        String headerName;

        headerName = HttpHeaders.AUTHORIZATION;
        addHeader(mapHeaders, headerName, "<Authorization>");

        headerName = RequestContext.TENANT;
        addHeader(mapHeaders, headerName, "<tenant>");

        //        addHeader(mapHeaders, HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        addHeader(mapHeaders, HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);

        HttpHeaders httpHeaders = new HttpHeaders();

        for (String key : mapHeaders.keySet()) {
            mapHeaders.get(key).forEach(value -> httpHeaders.add(key, value));
        }

        return httpHeaders;
    }

    private void addHeader(MultiValueMap<String, String> httpHeaders, String headerName, String headerValue) {
        if (!httpHeaders.containsKey(headerName)) {
            httpHeaders.add(headerName, headerValue);
        }
    }

    public <R> R doGetWithParams(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, Class<R> responseType,
        FieldDescriptor[] responseFieldDescriptors) {
        return doGet(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, responseType,
            responseFieldDescriptors, defaultRemoveResponseFields, defaultOverrideHeaders);
    }

    public <R> R doGetWithExcludeFields(String uri, Class<R> responseType, FieldDescriptor[] responseFieldDescriptors,
        String[] removeResponseFields) {
        return doGet(uri, defaultPathVariables, defaultPathVariableDescriptors, defaultRequestParamDescriptors,
            responseType, responseFieldDescriptors, removeResponseFields, defaultOverrideHeaders);
    }

    public <R> R doGetWithParamsAndExcludeFields(String uri, Object[] pathVariables,
        ParameterDescriptor[] pathVariableDescriptors, ParameterDescriptor[] requestParamDescriptors,
        Class<R> responseType, FieldDescriptor[] responseFieldDescriptors, String[] removeResponseFields) {
        return doGet(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, responseType,
            responseFieldDescriptors, removeResponseFields, defaultOverrideHeaders);
    }

    public <I, R> R doPost(String uri, I requestInput, FieldDescriptor[] requestFieldDescriptors, Class<R> responseType,
        FieldDescriptor[] responseFieldDescriptors) {
        return doPost(uri, defaultPathVariables, defaultPathVariableDescriptors, defaultRequestParamDescriptors,
            requestInput, requestFieldDescriptors, responseType, responseFieldDescriptors, defaultRemoveResponseFields,
            defaultOverrideHeaders);
    }

    public <I, R> R doPost(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, I requestInput, FieldDescriptor[] requestFieldDescriptors,
        Class<R> responseType, FieldDescriptor[] responseFieldDescriptors, String[] removeResponseFields,
        MultiValueMap<String, String> overrideHeaders) {
        return invokeUri(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, HttpMethod.POST,
            requestInput, requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields,
            overrideHeaders);
    }

    public <I, R> R doPost(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, I requestInput, FieldDescriptor[] requestFieldDescriptors,
        String[] removeRequestFields, Class<R> responseType, FieldDescriptor[] responseFieldDescriptors,
        String[] removeResponseFields, MultiValueMap<String, String> overrideHeaders) {

        return invokeUri(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, HttpMethod.POST,
            requestInput, requestFieldDescriptors, removeRequestFields, responseType, responseFieldDescriptors,
            removeResponseFields, overrideHeaders, MediaType.APPLICATION_JSON);
    }

    //    http://stackoverflow.com/questions/20389746/how-to-post-multipart-form-data-for-a-file-upload-using
    // -springmvc-and-mockmvc
    //     FileInputStream fis = new FileInputStream("/home/me/Desktop/someDir/image.jpg");
    //    MockMultipartFile multipartFile = new MockMultipartFile("file", fis);
    public <R> R doPost(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, MockMultipartFile requestInput, Map<String, String> inputParams,
        FieldDescriptor[] requestFieldDescriptors, Class<R> responseType, FieldDescriptor[] responseFieldDescriptors,
        String[] removeResponseFields, MultiValueMap<String, String> overrideHeaders) {

        MediaType mediaType = new MediaType("multipart", "form-data", inputParams);

        return invokeUri(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, HttpMethod.POST,
            requestInput, requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields,
            overrideHeaders, mediaType);
    }

    /**
     * Some api requires using a list of MultiopartFile. https://stackoverflow
     * .com/questions/21800726/using-spring-mvc-test-to-unit-test-multipart-post-request
     */
    public <R> R doPost(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, List<MockMultipartFile> requestInputs,
        Map<String, String> inputParams, FieldDescriptor[] requestFieldDescriptors, Class<R> responseType,
        FieldDescriptor[] responseFieldDescriptors, String[] removeResponseFields,
        MultiValueMap<String, String> overrideHeaders) {

        MediaType mediaType = new MediaType("multipart", "form-data", inputParams);

        return invokeUri(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, HttpMethod.POST,
            requestInputs, requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields,
            overrideHeaders, mediaType);
    }

    public <R> R doPut(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, List<MockMultipartFile> requestInputs,
        Map<String, String> inputParams, FieldDescriptor[] requestFieldDescriptors, Class<R> responseType,
        FieldDescriptor[] responseFieldDescriptors, String[] removeResponseFields,
        MultiValueMap<String, String> overrideHeaders) {

        MediaType mediaType = new MediaType("multipart", "form-data", inputParams);

        return invokeUri(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, HttpMethod.PUT,
            requestInputs, requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields,
            overrideHeaders, mediaType);
    }

    public <I, R> R doPost(String uri, I requestInput, FieldDescriptor[] requestFieldDescriptors, Class<R> responseType,
        FieldDescriptor[] responseFieldDescriptors, MultiValueMap<String, String> overrideHeaders) {
        return doPost(uri, defaultPathVariables, defaultPathVariableDescriptors, defaultRequestParamDescriptors,
            requestInput, requestFieldDescriptors, responseType, responseFieldDescriptors, defaultRemoveResponseFields,
            overrideHeaders);
    }

    public <I, R> R doPostWithParams(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, I requestInput, FieldDescriptor[] requestFieldDescriptors,
        Class<R> responseType, FieldDescriptor[] responseFieldDescriptors) {
        return doPost(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, requestInput,
            requestFieldDescriptors, responseType, responseFieldDescriptors, defaultRemoveResponseFields,
            defaultOverrideHeaders);
    }

    public <I, R> R doPostWithExcludeFields(String uri, I requestInput, FieldDescriptor[] requestFieldDescriptors,
        Class<R> responseType, FieldDescriptor[] responseFieldDescriptors, String[] removeResponseFields) {
        return doPost(uri, defaultPathVariables, defaultPathVariableDescriptors, defaultRequestParamDescriptors,
            requestInput, requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields,
            defaultOverrideHeaders);
    }

    public <I, R> R doPostWithParamsAndExcludeFields(String uri, Object[] pathVariables,
        ParameterDescriptor[] pathVariableDescriptors, ParameterDescriptor[] requestParamDescriptors, I requestInput,
        FieldDescriptor[] requestFieldDescriptors, Class<R> responseType, FieldDescriptor[] responseFieldDescriptors,
        String[] removeResponseFields) {
        return doPost(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, requestInput,
            requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields,
            defaultOverrideHeaders);
    }

    public <I, R> R doPut(String uri, I requestInput, FieldDescriptor[] requestFieldDescriptors, Class<R> responseType,
        FieldDescriptor[] responseFieldDescriptors) {
        return doPut(uri, defaultPathVariables, defaultPathVariableDescriptors, defaultRequestParamDescriptors,
            requestInput, requestFieldDescriptors, responseType, responseFieldDescriptors, defaultRemoveResponseFields,
            defaultOverrideHeaders);
    }

    public <I, R> R doPut(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, I requestInput, FieldDescriptor[] requestFieldDescriptors,
        Class<R> responseType, FieldDescriptor[] responseFieldDescriptors, String[] removeResponseFields,
        MultiValueMap<String, String> overrideHeaders) {

        return invokeUri(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, HttpMethod.PUT,
            requestInput, requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields,
            overrideHeaders);
    }

    public <I, R> R doPutWithParams(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, I requestInput, FieldDescriptor[] requestFieldDescriptors,
        Class<R> responseType, FieldDescriptor[] responseFieldDescriptors) {
        return doPut(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, requestInput,
            requestFieldDescriptors, responseType, responseFieldDescriptors, defaultRemoveResponseFields,
            defaultOverrideHeaders);
    }

    public <I, R> R doPutWithExcludeFields(String uri, I requestInput, FieldDescriptor[] requestFieldDescriptors,
        Class<R> responseType, FieldDescriptor[] responseFieldDescriptors, String[] removeResponseFields) {
        return doPut(uri, defaultPathVariables, defaultPathVariableDescriptors, defaultRequestParamDescriptors,
            requestInput, requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields,
            defaultOverrideHeaders);
    }

    public <I, R> R doPutWithParamsAndExcludeFields(String uri, Object[] pathVariables,
        ParameterDescriptor[] pathVariableDescriptors, ParameterDescriptor[] requestParamDescriptors, I requestInput,
        FieldDescriptor[] requestFieldDescriptors, Class<R> responseType, FieldDescriptor[] responseFieldDescriptors,
        String[] removeResponseFields) {
        return doPut(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, requestInput,
            requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields,
            defaultOverrideHeaders);
    }

    public <I, R> R doPatch(String uri, I requestInput, FieldDescriptor[] requestFieldDescriptors,
        Class<R> responseType, FieldDescriptor[] responseFieldDescriptors) {
        return doPatch(uri, defaultPathVariables, defaultPathVariableDescriptors, defaultRequestParamDescriptors,
            requestInput, requestFieldDescriptors, responseType, responseFieldDescriptors, defaultRemoveResponseFields,
            defaultOverrideHeaders);
    }

    public <I, R> R doPatch(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, I requestInput, FieldDescriptor[] requestFieldDescriptors,
        Class<R> responseType, FieldDescriptor[] responseFieldDescriptors, String[] removeResponseFields,
        MultiValueMap<String, String> overrideHeaders) {

        return invokeUri(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, HttpMethod.PATCH,
            requestInput, requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields,
            overrideHeaders);
    }

    public <I, R> R doPatchWithParams(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors, I requestInput, FieldDescriptor[] requestFieldDescriptors,
        Class<R> responseType, FieldDescriptor[] responseFieldDescriptors) {
        return doPatch(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, requestInput,
            requestFieldDescriptors, responseType, responseFieldDescriptors, defaultRemoveResponseFields,
            defaultOverrideHeaders);
    }

    public <I, R> R doPatchWithExcludeFields(String uri, I requestInput, FieldDescriptor[] requestFieldDescriptors,
        Class<R> responseType, FieldDescriptor[] responseFieldDescriptors, String[] removeResponseFields) {
        return doPatch(uri, defaultPathVariables, defaultPathVariableDescriptors, defaultRequestParamDescriptors,
            requestInput, requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields,
            defaultOverrideHeaders);
    }

    public <I, R> R doPatchWithParamsAndExcludeFields(String uri, Object[] pathVariables,
        ParameterDescriptor[] pathVariableDescriptors, ParameterDescriptor[] requestParamDescriptors, I requestInput,
        FieldDescriptor[] requestFieldDescriptors, Class<R> responseType, FieldDescriptor[] responseFieldDescriptors,
        String[] removeResponseFields) {
        return doPatch(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, requestInput,
            requestFieldDescriptors, responseType, responseFieldDescriptors, removeResponseFields,
            defaultOverrideHeaders);
    }

    //    private static void validateStatus(String responseBody, int status) {
    //        //noinspection unchecked
    //        MatcherAssert.assertThat(responseBody, status, AnyOf.anyOf(Is.is(200), Is.is(201), Is.is(202), Is.is(203),
    //            Is.is(204), Is.is(205), Is.is(206)));
    //    }

    public void doDelete(String uri) {
        invokeUri(uri, defaultPathVariables, defaultPathVariableDescriptors, defaultRequestParamDescriptors,
            HttpMethod.DELETE, null /* requestInput */, defaultRequestFieldDescriptors, null /* responseType */,
            defaultResponseFieldDescriptors, defaultRemoveResponseFields, defaultOverrideHeaders);
    }

    public void doDelete(String uri, MultiValueMap<String, String> overrideHeaders) {
        invokeUri(uri, defaultPathVariables, defaultPathVariableDescriptors, defaultRequestParamDescriptors,
            HttpMethod.DELETE, null /* requestInput */, defaultRequestFieldDescriptors, null /* responseType */,
            defaultResponseFieldDescriptors, defaultRemoveResponseFields, overrideHeaders);
    }

    public void doDeleteWithParams(String uri, Object[] pathVariables, ParameterDescriptor[] pathVariableDescriptors,
        ParameterDescriptor[] requestParamDescriptors) {
        invokeUri(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, HttpMethod.DELETE, null /*
        requestInput */, defaultRequestFieldDescriptors, null /* responseType */, defaultResponseFieldDescriptors,
            defaultRemoveResponseFields, defaultOverrideHeaders);
    }

    public <I, R> R doDeleteWithParams(String uri, Object[] pathVariables,
        ParameterDescriptor[] pathVariableDescriptors, ParameterDescriptor[] requestParamDescriptors, I requestInput,
        Class<R> responseType) {
        return invokeUri(uri, pathVariables, pathVariableDescriptors, requestParamDescriptors, HttpMethod.DELETE,
            requestInput, defaultRequestFieldDescriptors, responseType, defaultResponseFieldDescriptors,
            defaultRemoveResponseFields, defaultOverrideHeaders);
    }

    public void doDeleteWithParams(String uri, Object[] pathVariables, MultiValueMap<String, String> overrideHeaders) {
        invokeUri(uri, pathVariables, defaultPathVariableDescriptors, defaultRequestParamDescriptors, HttpMethod.DELETE,
            null /* requestInput */, defaultRequestFieldDescriptors, null /* responseType */,
            defaultResponseFieldDescriptors, defaultRemoveResponseFields, overrideHeaders);
    }
}
