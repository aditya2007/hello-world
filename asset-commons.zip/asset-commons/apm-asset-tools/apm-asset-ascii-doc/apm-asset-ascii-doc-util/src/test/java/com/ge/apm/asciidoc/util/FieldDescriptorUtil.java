/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asciidoc.util;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.util.StringUtils;

import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.util.CsvFileUtil;

import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;

@SuppressWarnings({ "WeakerAccess", "unused" })
public class FieldDescriptorUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(FieldDescriptorUtil.class);

    public static FieldDescriptor[] getFieldDescriptors(String csvInput, RequestType requestType, boolean isArray) {

        String fieldPrefix = isArray ? "[]." : "";

        List<FieldDescriptorEntry> fieldDescriptorEntryList = CsvFileUtil.readCsvContent(csvInput,
            FieldDescriptorEntry.columnHeadings, FieldDescriptorEntry.class);

        List<FieldDescriptor> fieldDescriptors = new ArrayList<>();

        fieldDescriptorEntryList.forEach(fieldDescriptorEntry -> {

            FieldValueInput fieldValueInput = fieldDescriptorEntry.getFieldValueInput(requestType);

            // If input for the field is not provided then continue to the next field without adding a descriptor
            if (fieldValueInput == FieldValueInput.NOT_PROVIDED) {
                return;
            }

            addFieldDescriptors(fieldDescriptors, fieldDescriptorEntry, fieldValueInput, fieldPrefix);
        });

        return fieldDescriptors.toArray(new FieldDescriptor[fieldDescriptors.size()]);
    }

    public static FieldDescriptor[] getFieldDescriptors(String csvInput, RequestType requestType) {
        return getFieldDescriptors(csvInput, requestType, false);
    }

    public static FieldDescriptor[] getFieldDescriptorsForResourceFile(String resourceFilePath, RequestType requestType,
        boolean isArray) {
        String csvContent = ResourceUtil.readResourceFileAsString(resourceFilePath);
        return getFieldDescriptors(csvContent, requestType, isArray);
    }

    public static FieldDescriptor[] getFieldDescriptorsForResourceFile(String resourceFilePath, RequestType requestType,
        String fieldPrefix) {
        String csvContent = ResourceUtil.readResourceFileAsString(resourceFilePath);
        String dirPath = resourceFilePath.substring(0, resourceFilePath.lastIndexOf("/") + 1);
        return getFieldDescriptors(csvContent, dirPath, requestType, fieldPrefix);
    }

    /**
     * included file should be in the same folder as current .csv fieldDescriptor file it will take the previous line's
     * field name as prefix; if previous line is empty, it will not set prefix
     */
    public static FieldDescriptor[] getFieldDescriptors(String csvInput, String dirPath, RequestType requestType,
        String fieldPrefix) {
        List<FieldDescriptorEntry> fieldDescriptorEntryList = CsvFileUtil.readCsvContent(csvInput,
            FieldDescriptorEntry.columnHeadings, FieldDescriptorEntry.class);

        List<FieldDescriptor> fieldDescriptors = new ArrayList<>();
        String previousField = "";

        for (FieldDescriptorEntry fieldDescriptorEntry : fieldDescriptorEntryList) {
            String fieldName = fieldDescriptorEntry.getName();
            if (fieldName.startsWith("~Include_")) {
                //get file path
                String tempPrefix = previousField.equals("") ? "" : previousField + ".";
                String prefix = fieldPrefix.equals("") ? tempPrefix : fieldPrefix + tempPrefix;

                FieldDescriptor[] tempFieldDescriptors = getFieldDescriptorsForResourceFile(
                    dirPath + fieldName.split("~Include_")[1], requestType, prefix);
                fieldDescriptors.addAll(Arrays.asList(tempFieldDescriptors));
                continue;
            }
            FieldValueInput fieldValueInput = fieldDescriptorEntry.getFieldValueInput(requestType);

            // If input for the field is not provided then continue to the next field without adding a descriptor
            if (fieldValueInput == FieldValueInput.NOT_PROVIDED) {
                continue;
            }

            addFieldDescriptors(fieldDescriptors, fieldDescriptorEntry, fieldValueInput, fieldPrefix);
            previousField = fieldName;
        }

        return fieldDescriptors.toArray(new FieldDescriptor[fieldDescriptors.size()]);
    }

    private static void addFieldDescriptors(List<FieldDescriptor> fieldDescriptors,
        FieldDescriptorEntry fieldDescriptorEntry, FieldValueInput fieldValueInput, String fieldPrefix) {

        String description = "";

        if (fieldValueInput == FieldValueInput.REQUIRED) {
            description = "* ";
        }

        FieldDescriptor fieldDescriptor = fieldWithPath(fieldPrefix + fieldDescriptorEntry.getName()).description(
            description + fieldDescriptorEntry.getDescription());

        if (StringUtils.hasText(fieldDescriptorEntry.getType())) {
            fieldDescriptor.type(fieldDescriptorEntry.getType());
        }

        if (fieldValueInput == FieldValueInput.OPTIONAL) {
            if (!StringUtils.hasText(fieldDescriptorEntry.getType())) {
                String errorMessage = MessageFormat.format(
                    "The field name ''{0}'' is optional. So data type " + "for this field should be provided.",
                    fieldDescriptorEntry.getName());
                LOGGER.error(errorMessage);
                throw new ServiceException(errorMessage);
            }

            fieldDescriptor = fieldDescriptor.type(fieldDescriptorEntry.getType()).optional();
        }

        fieldDescriptors.add(fieldDescriptor);
    }

    @Getter
    @Setter
    @ToString
    public static class FieldDescriptorEntry {

        public static final String NOT_PROVIDED = "NotProvided";

        public static final String REQUIRED = "Required";

        public static final String OPTIONAL = "Optional";

        private String name;

        private String type;

        private String description;

        private String forGet;

        private String forCreate;

        private String forUpdate;

        private String forDelete;

        public static final Map<String, String> columnHeadings = new HashMap<>();

        static {
            // Path,Type,Description,ForCreate,ForUpdate,ForDelete
            columnHeadings.put("Name", "Name");
            columnHeadings.put("Type", "Type");
            columnHeadings.put("Description", "Description");
            columnHeadings.put("ForCreate", "ForCreate");
            columnHeadings.put("ForGet", "ForGet");
            columnHeadings.put("ForUpdate", "ForUpdate");
            columnHeadings.put("ForDelete", "ForDelete");
        }

        // checks if the entry is equal to the inputString.
        public boolean isEqualToForRequestType(RequestType requestType, String inputString) {
            switch (requestType) {
                case FOR_CREATE:
                    if (StringUtils.hasText(this.forCreate) && this.forCreate.equalsIgnoreCase(inputString)) {
                        return true;
                    }
                    break;
                case FOR_GET:
                    if (StringUtils.hasText(this.forGet) && this.forGet.equalsIgnoreCase(inputString)) {
                        return true;
                    }
                    break;
                case FOR_UPDATE:
                    if (StringUtils.hasText(this.forUpdate) && this.forUpdate.equalsIgnoreCase(inputString)) {
                        return true;
                    }
                    break;
                case FOR_DELETE:
                    if (StringUtils.hasText(this.forDelete) && this.forDelete.equalsIgnoreCase(inputString)) {
                        return true;
                    }
                    break;
                default:
                    String errorMessage = MessageFormat.format(
                        "Internal server error. Request type '%s' is not handled.", requestType.toString());
                    LOGGER.error(errorMessage);
                    throw new ServiceException(errorMessage);
            }

            return false;
        }

        public FieldValueInput getFieldValueInput(RequestType requestType) {
            switch (requestType) {
                case FOR_CREATE:
                    if (StringUtils.isEmpty(this.forCreate)) {
                        return FieldValueInput.IS_EMPTY;
                    }
                    return FieldValueInput.getEnumForValue(this.forCreate);
                case FOR_GET:
                    if (StringUtils.isEmpty(this.forGet)) {
                        return FieldValueInput.IS_EMPTY;
                    }
                    return FieldValueInput.getEnumForValue(this.forGet);
                case FOR_UPDATE:
                    if (StringUtils.isEmpty(this.forUpdate)) {
                        return FieldValueInput.IS_EMPTY;
                    }
                    return FieldValueInput.getEnumForValue(this.forUpdate);
                case FOR_DELETE:
                    if (StringUtils.isEmpty(this.forDelete)) {
                        return FieldValueInput.IS_EMPTY;
                    }
                    return FieldValueInput.getEnumForValue(this.forDelete);
                default:
                    String errorMessage = MessageFormat.format(
                        "Internal server error. Request type '%s' is not handled.", requestType.toString());
                    LOGGER.error(errorMessage);
                    throw new ServiceException(errorMessage);
            }
        }
    }

    public enum FieldValueInput {
        IS_EMPTY("IsEmpty"),
        NOT_PROVIDED("NotProvided"),
        REQUIRED("Required"),
        OPTIONAL("Optional");

        private static final Map<String, FieldValueInput> valueToEnums = new HashMap<>();

        private static final Map<String, FieldValueInput> upperCaseValueToEnums = new HashMap<>();

        static {
            for (FieldValueInput fieldValueInput : FieldValueInput.values()) {
                valueToEnums.put(fieldValueInput.value, fieldValueInput);
                upperCaseValueToEnums.put(fieldValueInput.value.toUpperCase(), fieldValueInput);
            }
        }

        private String value;

        FieldValueInput(String value) {
            this.value = value;
        }

        @SuppressWarnings("unused")
        public static FieldValueInput getEnumForValue(String value) {
            FieldValueInput fieldValueInput = upperCaseValueToEnums.get(value.toUpperCase());
            if (fieldValueInput == null) {
                String errorMessage = String.format("Invalid field input value '%s'. Valid values are '%s'", value,
                    getValidValues());
                LOGGER.error("{}", errorMessage);
                throw new ServiceException(errorMessage);
            }

            return fieldValueInput;
        }

        public static String getValidValues() {
            return String.join(", ", valueToEnums.keySet());
        }

        @SuppressWarnings("unused")
        public static Set<String> getStrValues() {
            return valueToEnums.keySet();
        }
    }

    public enum RequestType {
        FOR_CREATE,
        FOR_GET,
        FOR_UPDATE,
        FOR_DELETE
    }
}
