/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asciidoc.util.preprocess;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.type.TypeFactory;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.restdocs.operation.OperationRequest;
import org.springframework.restdocs.operation.OperationRequestFactory;
import org.springframework.restdocs.operation.OperationResponse;
import org.springframework.restdocs.operation.OperationResponseFactory;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;

import com.ge.apm.util.JsonHelper;

public class AsciiDocContentPreProcess implements OperationPreprocessor {

    private OperationRequestFactory operationRequestFactory = new OperationRequestFactory();

    private OperationResponseFactory operationResponseFactory = new OperationResponseFactory();

    private List<String> responseHeadersForExclusion;

    private List<String> requestHeadersForExclusion;

    private List<String> requestHeadersForMask;

    private List<String> responseHeadersForMask;

    private String[] removeResponseFields;

    public AsciiDocContentPreProcess(List<String> requestHeadersForExclusion, List<String> responseHeadersForExclusion,
        List<String> requestHeadersForMask, List<String> responseHeadersForMask) {
        this.requestHeadersForExclusion = requestHeadersForExclusion != null ? requestHeadersForExclusion
            : new ArrayList<>();
        this.responseHeadersForExclusion = responseHeadersForExclusion != null ? responseHeadersForExclusion
            : new ArrayList<>();
        this.requestHeadersForMask = requestHeadersForMask != null ? requestHeadersForMask : new ArrayList<>();
        this.responseHeadersForMask = responseHeadersForMask != null ? responseHeadersForMask : new ArrayList<>();
    }

    public void setRemoveResponseFields(String[] removeResponseFields) {
        this.removeResponseFields = removeResponseFields != null ? removeResponseFields : new String[] {};
    }

    @Override
    public OperationRequest preprocess(OperationRequest request) {
        HttpHeaders newHttpHeaders = maskHeaders(request.getHeaders(), this.requestHeadersForMask,
            this.requestHeadersForExclusion);
        return this.operationRequestFactory.createFrom(request, newHttpHeaders);
    }

    @Override
    public OperationResponse preprocess(OperationResponse response) {
        HttpHeaders newHttpHeaders = maskHeaders(response.getHeaders(), this.responseHeadersForMask,
            this.responseHeadersForExclusion);
        byte[] newContent = processResponseContent(response);
        OperationResponse modifiedResponse = this.operationResponseFactory.createFrom(response, newContent);
        return this.operationResponseFactory.createFrom(modifiedResponse, newHttpHeaders);
    }

    private byte[] processResponseContent(OperationResponse response) {
        String content = response.getContentAsString();

        if (StringUtils.isEmpty(content)) {
            return content.getBytes();
        }

        // if the response is array of elements then we would like to print only the first element in the ascii-doc.
        if (content.startsWith(JsonToken.START_ARRAY.asString())) {
            List<Object> arrContent = JsonHelper.fromJson(content,
                TypeFactory.defaultInstance().constructCollectionType(List.class, Object.class));
            if (!arrContent.isEmpty()) {
                List<Object> arrFirstElement = Collections.singletonList(arrContent.get(0));
                return JsonHelper.toJson(arrFirstElement).getBytes();
            } else {
                return response.getContent();
            }
        }

        if (this.removeResponseFields != null && this.removeResponseFields.length > 0) {
            Map<String, Object> jsonMap = JsonHelper.fromJsonToMap(content);
            Arrays.stream(this.removeResponseFields).forEach(jsonMap::remove);
            return JsonHelper.toJson(jsonMap).getBytes();
        }

        return content.getBytes();
    }

    private HttpHeaders maskHeaders(HttpHeaders headers, List<String> headersForMask,
        List<String> headersForExclusion) {
        HttpHeaders modifiedHeaders = new HttpHeaders();

        for (Entry<String, List<String>> header : headers.entrySet()) {

            if (headersForExclusion.contains(header.getKey())) {
                continue;
            }
            for (String value : header.getValue()) {

                if (headersForMask.contains(header.getKey())) {
                    value = "<" + header.getKey() + ">";
                }

                modifiedHeaders.add(header.getKey(), value);
            }
        }
        return modifiedHeaders;
    }
}
