/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import org.junit.Test;

public class TempTest {
    public static class A {

    }

    public static class B extends A {

    }

    public static class C extends A {

    }

    @Test
    public void test() {
        A b = new B();
        A c = new C();

        ClassCastUtil.cast(b, B.class);
        ClassCastUtil.cast(b, C.class);
    }
}
