/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.lang3.StringUtils;
import org.apache.tools.ant.DirectoryScanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.ge.apm.util.errorcodes.UtilsErrorCodes.CANNOT_FIND_FILES_WITH_CRITERIA;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.CANNOT_FIND_FILE_WITH_EXT;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_COPYING_FILE;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_CREATING_TMP_DIR;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_DELETING_THE_DIRECTORY;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_READING_FILE_TO_STRING;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_WRITING_BYTES_TO_FILE;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_WRITING_TO_TEMPLATE_JSON_FILE;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.INVALID_FILE_PATH;
import static com.ge.apm.util.exceptions.ExceptionHelper.getException;

public class FileUtil {

    private static final Logger logger = LoggerFactory.getLogger(FileUtil.class);

    private FileUtil() {

    }

    public static void validateFileExists(String filePath) {
        final String methodName = "FileUtil.validateFileExists";

        File file = new File(filePath);
        if (!file.exists() || file.isDirectory()) {
            throw getException(methodName, logger, INVALID_FILE_PATH, filePath);
        }
    }

    public static void validateDirectoryExists(String filePath) {
        final String methodName = "FileUtil.validateDirectoryExists";

        File file = new File(filePath);
        if (!file.exists() && !file.isDirectory()) {
            throw getException(methodName, logger, INVALID_FILE_PATH, filePath);
        }
    }

    public static String readFileToString(String filePath) {
        File file = new File(filePath);
        final String methodName = "FileUtil.readFileToString";

        try {
            return FileUtils.readFileToString(file, "UTF-8");
        } catch (IOException exception) {
            logger.error(exception.getMessage(), exception);
            throw getException(methodName, logger, ERROR_READING_FILE_TO_STRING, filePath, exception.getMessage());
        }
    }

    public static void writeByteArrayToFile(String filePath, byte[] bytes) {
        final String methodName = "FileUtil.writeByteArrayToFile";

        try {
            FileUtils.writeByteArrayToFile(new File(filePath), bytes);
        } catch (IOException exception) {
            logger.error("Error writing bytes to file '{}'", filePath, exception);
            throw getException(methodName, logger, ERROR_WRITING_BYTES_TO_FILE, FilenameUtils.getName(filePath),
                exception.getMessage());
        }
    }

    public static File findFileForExtension(List<File> files, String extension) {

        final String methodName = "FileUtil.findFileForExtension";

        Optional<File> optionalFile = files.stream().filter(
            file -> FilenameUtils.getExtension(file.getName()).equalsIgnoreCase(extension)).findAny();

        if (optionalFile.isPresent()) {
            return optionalFile.get();
        }

        throw getException(methodName, logger, CANNOT_FIND_FILE_WITH_EXT, extension,
            files.stream().map(File::getName).reduce(", ", String::concat));
    }

    public static List<File> findFilesForFilter(String inputDir, String[] extensions, boolean recursive) {

        final String methodName = "FileUtil.findFilesForFilter";

        List<File> files = (List<File>) FileUtils.listFiles(new File(inputDir), extensions, recursive);

        if (files.size() == 0) {
            throw getException(methodName, logger, CANNOT_FIND_FILES_WITH_CRITERIA, StringUtils.join(extensions, ", "),
                inputDir);
        }

        return files;
    }

    public static String[] findFilePathsForAntPattern(String inputDir, String[] searchFilter) {
        final String methodName = "FileUtil.findFilesForFilterAntPattern";

        String[] fileNames = findFilePathsForAntPatternNoThrow(inputDir, searchFilter);

        if (fileNames.length == 0) {
            throw getException(methodName, logger, CANNOT_FIND_FILES_WITH_CRITERIA,
                StringUtils.join(searchFilter, ", "), inputDir);
        }

        inputDir = FileUtil.appendTrailingSlash(inputDir);

        for (int idx = 0; idx < fileNames.length; idx++) {
            fileNames[idx] = inputDir + fileNames[idx];
        }

        return fileNames;

    }

    public static String[] findFilePathsForAntPatternNoThrow(String inputDir, String[] searchFilter) {

        DirectoryScanner scanner = new DirectoryScanner();
        scanner.setIncludes(searchFilter);
        scanner.setBasedir(inputDir);
        scanner.setCaseSensitive(false);
        scanner.scan();
        return scanner.getIncludedFiles();
    }

    @SuppressWarnings("WeakerAccess")
    public static File createTmpFileFromBytes(String tmpDirectoryPrefix, byte[] input, String fileName) {
        Path tmpDirectory = createTmpDirectory(tmpDirectoryPrefix);
        return writeBytesToFile(tmpDirectory.toString() + "/" + fileName, input);
    }

    public static String appendTrailingSlash(String path) {
        if (StringUtils.isEmpty(path)) {
            return path;
        }
        if (path.charAt(path.length() - 1) != File.separatorChar) {
            path += File.separator;
        }

        return path;
    }

    public static Path createTmpDirectory(String tmpDirectoryPrefix) {
        String methodName = "ApmFileUtil.createTmpDirectory";
        try {
            return Files.createTempDirectory(tmpDirectoryPrefix);
        } catch (IOException exception) {
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CREATING_TMP_DIR,
                exception.getMessage());
        }
    }

    public static File writeBytesToFile(String fileName, byte[] input) {
        String methodName = "ApmFileUtil.writeBytesToFile";

        File file = new File(fileName);
        try {
            FileUtils.writeByteArrayToFile(file, input);
        } catch (IOException exception) {
            throw getException(methodName, logger, ERROR_WRITING_TO_TEMPLATE_JSON_FILE, exception,
                FilenameUtils.getBaseName(fileName), exception.getMessage());
        }
        return file;
    }

    public static void createDirectory(String directoryName) {
        String methodName = "ApmFileUtil.createDirectory";
        try {
            Files.createDirectories(Paths.get(directoryName));
        } catch (IOException exception) {
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CREATING_TMP_DIR,
                exception.getMessage());
        }
    }

    public static void deleteDirectoryIfExists(String directoryName) {
        final String methodName = "ApmFileUtil.deleteDirectoryIfExists";
        File file = new File(directoryName);

        if (file.exists()) {
            try {
                FileUtils.deleteDirectory(file);
            } catch (IOException exception) {
                logger.error(exception.getMessage(), exception);
                throw getException(methodName, logger, ERROR_DELETING_THE_DIRECTORY, file.getName(),
                    exception.getMessage());
            }
        }
    }

    public static void copyFile(File srcFile, String destFileWithPath) {
        final String methodName = "ApmFileUtil.copyFile";
        File destFile = new File(destFileWithPath);

        try {
            FileUtils.copyFile(srcFile, destFile);
        } catch (IOException ioException) {
            logger.error("Error copying '%s' to '%s'", srcFile.getAbsolutePath(), destFile.getAbsolutePath(),
                ioException);
            throw getException(methodName, logger, ERROR_COPYING_FILE, srcFile.getName(), destFile.getName(),
                ioException.getMessage());
        }
    }

    public static File[] getDirecotries(String directoryName) {
        File directory = new File(directoryName);
        return directory.listFiles((FileFilter) DirectoryFileFilter.DIRECTORY);
    }

}
