/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.Properties;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.apm.common.exception.ServiceException;

public class PropertiesUtil {
    private static final Logger logger = LoggerFactory.getLogger(PropertiesUtil.class);

    //    @NotNull
    //    public static LinkedProperties loadProperties(String propertiesFilePath) {
    //        LinkedProperties properties = new LinkedProperties();
    //        logger.info("Loading properties file '{}'", propertiesFilePath);
    //        try (InputStream input = new FileInputStream(propertiesFilePath)) {
    //            properties.load(input);
    //            return properties;
    //        } catch (IOException e) {
    //            logger.error("", e);
    //            String errorMessage = MessageFormat.format("Error loading the file ''{0}'': {1}",
    //                propertiesFilePath, e.getMessage());
    //            logger.error(errorMessage);
    //            throw new ServiceException(errorMessage);
    //        }
    //    }

    @NotNull
    public static Properties loadProperties(String propertiesFilePath) {
        Properties properties = new Properties();
        logger.info("Loading properties file '{}'", propertiesFilePath);
        try (InputStream input = new FileInputStream(propertiesFilePath)) {
            properties.load(input);
            return properties;
        } catch (IOException e) {
            logger.error("", e);
            String errorMessage = MessageFormat.format("Error loading the file ''{0}'': {1}",
                propertiesFilePath, e.getMessage());
            logger.error(errorMessage);
            throw new ServiceException(errorMessage);
        }
    }

    @NotNull
    public static LinkedProperties loadPropertiesText(String appPropertiesJson) {
        LinkedProperties properties = new LinkedProperties();
        try (InputStream input = new ByteArrayInputStream(appPropertiesJson.getBytes())) {
            properties.load(input);
            return properties;
        } catch (IOException e) {
            logger.error("", e);
            String errorMessage = MessageFormat.format("Error loading the JSON ''{0}'': {1}",
                appPropertiesJson, e.getMessage());
            logger.error(errorMessage);
            throw new ServiceException(errorMessage);
        }
    }

    //    @SuppressWarnings("WeakerAccess")
    //    @Getter
    //    public static class LinkedProperties extends Properties {
    //
    //        private static final long serialVersionUID = 1L;
    //
    //        private Map<Object, Object> map = new LinkedHashMap<>();
    //
    //        public void addNewLineAfter(String inputKeyName) {
    //            int idx = 0;
    //            for (Object objKeyName : this.map.keySet()) {
    //                String keyName = (String) objKeyName;
    //
    //                if (keyName.equalsIgnoreCase(inputKeyName)) {
    //                    break;
    //                }
    //
    //                idx++;
    //            }
    //
    //            add(idx, "", "");
    //        }
    //
    //        public void add(int index, Object key, Object value) {
    //            assert (this.map != null);
    //            assert !this.map.containsKey(key);
    //            assert (index >= 0) && (index < this.map.size());
    //
    //            int idx = 0;
    //            List<Entry<Object, Object>> rest = new ArrayList<>();
    //            for (Entry<Object, Object> entry : this.map.entrySet()) {
    //                if (idx++ >= index) {
    //                    rest.add(entry);
    //                }
    //            }
    //            this.map.put(key, value);
    //            for (Entry<Object, Object> entry : rest) {
    //                this.map.remove(entry.getKey());
    //                this.map.put(entry.getKey(), entry.getValue());
    //            }
    //        }
    //
    //        @Override
    //        public synchronized Enumeration<Object> elements() {
    //            throw new UnsupportedOperationException("Enumerations are so old-school, don't use them, "
    //                + "use keySet() or entrySet() instead");
    //        }
    //
    //        @Override
    //        public synchronized boolean contains(Object value) {
    //            return this.map.containsValue(value);
    //        }
    //
    //        @Override
    //        public boolean containsValue(Object value) {
    //            return this.map.containsValue(value);
    //        }
    //
    //        @Override
    //        public synchronized boolean containsKey(Object key) {
    //            return this.map.containsKey(key);
    //        }
    //
    //        @Override
    //        public synchronized Object get(Object key) {
    //            return this.map.get(key);
    //        }
    //
    //        @Override
    //        public synchronized Object put(Object key, Object value) {
    //            return this.map.put(key, value);
    //        }
    //
    //        @Override
    //        public synchronized void clear() {
    //            this.map.clear();
    //        }
    //
    //        public Set<Object> keySet() {
    //            return this.map.keySet();
    //        }
    //
    //        @Override
    //        public Set<Entry<Object, Object>> entrySet() {
    //            return this.map.entrySet();
    //        }
    //
    //        public synchronized Object putProperty(String key, String value) {
    //            if (!StringUtils.hasText(value)) {
    //                String errorMessage = MessageFormat.format("Cannot put property ''{0}'' as its value is empty
    // .", key);
    //                logger.error(errorMessage);
    //                throw new ServiceException(errorMessage);
    //            }
    //            return this.map.put(key, value);
    //        }
    //
    //        @Override
    //        public String getProperty(String key) {
    //            String propertyValue = (String) this.map.get(key);
    //
    //            if (!StringUtils.hasText(propertyValue)) {
    //                String errorMessage = MessageFormat.format("Property ''{0}'' value is empty.", key);
    //                logger.error(errorMessage);
    //                throw new ServiceException(errorMessage);
    //            }
    //
    //            return StringUtils.trimAllWhitespace(propertyValue);
    //        }
    //
    //        // the methods returning set should be overridden as a set by definition
    //        // does not maintain insertion order
    //        // @Override
    //        // public Set<String> stringPropertyNames()
    //        // {
    //        // Set<String> set = new LinkedHashSet<String>();
    //        //
    //        // for (Object key : keys)
    //        // {
    //        // set.add((String) key);
    //        // }
    //        //
    //        // return set;
    //        // }
    //    }
}
