/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.ge.apm.util.errorcodes.UtilsErrorCodes.CANNOT_CAST_INPUT_NULL;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.CANNOT_CAST_NOT_SUBCLASS;

public class ClassCastUtil {
    private static final Logger logger = LoggerFactory.getLogger(ClassCastUtil.class);

    public static <I, R> R cast(I fromObject, Class<R> toClazz) {

        String methodName = "ClassCastUtil.castClass";

        if (fromObject == null) {
            throw ExceptionHelper.getException(methodName, logger, CANNOT_CAST_INPUT_NULL, toClazz.getSimpleName());
        }

        if (!toClazz.isAssignableFrom(fromObject.getClass())) {
            throw ExceptionHelper.getException(methodName, logger, CANNOT_CAST_NOT_SUBCLASS,
                fromObject.getClass().getSimpleName(), toClazz.getSimpleName(), toClazz.getCanonicalName());
        }

        return toClazz.cast(fromObject);
    }

    public static <I, R> List<R> cast(List<I> fromList, Class<R> toClazz) {
        List<R> toList = new ArrayList<>();
        fromList.forEach(fromObject -> toList.add(cast(fromObject, toClazz)));

        return toList;
    }
}
