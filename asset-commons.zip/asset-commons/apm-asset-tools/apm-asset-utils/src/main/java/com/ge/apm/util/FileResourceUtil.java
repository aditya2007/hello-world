/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;

import com.ge.apm.util.exceptions.ExceptionHelper;
import com.ge.apm.util.model.Artifact;

import static com.ge.apm.util.FileUtil.createTmpFileFromBytes;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.CANNOT_READ_MULTIPART_FILE;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_WRITING_STREAM_TO_RESPONSE;
import static com.ge.apm.util.exceptions.ExceptionHelper.getException;

public class FileResourceUtil {

    private static final Logger logger = LoggerFactory.getLogger(FileResourceUtil.class);

    public static Resource getResource(String tmpDirectoryPrefix, byte[] input, String fileName) {
        File file = createTmpFileFromBytes(tmpDirectoryPrefix, input, fileName);
        return new FileSystemResource(file.getAbsolutePath());
    }

    public static Resource getResource(MultipartFile file) {
        String methodName = "RestUtil.getUploadResource";
        try {
            return new ByteArrayResource(file.getBytes()) {
                @Override
                public String getFilename() {
                    return FilenameUtils.getName(file.getOriginalFilename());
                }
            };
        } catch (IOException exception) {
            throw getException(methodName, logger, exception, CANNOT_READ_MULTIPART_FILE, file.getOriginalFilename(),
                exception.getMessage());
        }
    }

    public static Resource getResource(String fileName, byte[] bytes) {
        return new ByteArrayResource(bytes) {
            @Override
            public String getFilename() {
                return FilenameUtils.getName(fileName);
            }
        };
    }

    public static String getResourceAsString(MultipartFile file) {
        final String methodName = "FileResourceUtil.getResourceAsString";
        try {
            return new String(file.getBytes(), "UTF-8");
        } catch (IOException exception) {
            throw getException(methodName, logger, exception, CANNOT_READ_MULTIPART_FILE, file.getOriginalFilename(),
                exception.getMessage());
        }
    }

    public static void setDownloadOutputStream(HttpServletRequest request, HttpServletResponse response,
        String fileName, byte[] bytes) {
        String methodName = "setDownloadOutputStream";
        ServletContext context = request.getServletContext();
        String mimeType = context.getMimeType(fileName);
        if (mimeType == null) {
            mimeType = MediaType.APPLICATION_OCTET_STREAM_VALUE;
        }

        response.setStatus(HttpStatus.OK.value());
        response.setContentType(mimeType);
        response.setContentLength(bytes.length);
        response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", fileName));
        response.setHeader("Access-Control-Expose-Headers", "Content-Disposition");

        // get output stream of the response
        OutputStream outStream;
        try {
            outStream = response.getOutputStream();
            outStream.write(bytes);
            outStream.close();
        } catch (IOException exception) {
            logger.error(exception.getMessage(), exception);
            throw ExceptionHelper.getException(methodName, logger, ERROR_WRITING_STREAM_TO_RESPONSE,
                exception.getMessage());
        }
    }

    public static void setDownloadOutputStream(HttpServletResponse response, Artifact artifact) {
        String methodName = "setDownloadOutputStream";

        response.setStatus(HttpStatus.OK.value());
        response.setContentType(artifact.getContentType());
        response.setContentLength((int) artifact.getContentLength());
        response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", artifact.getFilename()));
        response.setHeader("Access-Control-Expose-Headers", "Content-Disposition");

        // get output stream of the response
        OutputStream outStream;
        try {
            outStream = response.getOutputStream();
            outStream.write(artifact.getBytes());
            outStream.close();
        } catch (IOException exception) {
            logger.error(exception.getMessage(), exception);
            throw ExceptionHelper.getException(methodName, logger, ERROR_WRITING_STREAM_TO_RESPONSE,
                exception.getMessage());
        }
    }
}
