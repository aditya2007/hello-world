/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.filter;

import java.io.IOException;
import java.util.Locale;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.NotAllowedException;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class HttpMethodOverrideFilter extends OncePerRequestFilter {

    public static final String HTTP_METHOD_OVERRIDE_HEADER = "X-HTTP-Method-Override";

    private static final String HTTP_METHOD_ORIGINAL = "POST";

    private static final String HTTP_METHOD_OVERRIDE = "PATCH";

    private String methodHeader = HTTP_METHOD_OVERRIDE_HEADER;

    public void setMethodHeader(String methodHeader) {
        Assert.hasText(methodHeader, "'methodHeader' must not be empty");
        this.methodHeader = methodHeader;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
        throws ServletException, IOException {

        String headerValue = request.getHeader(this.methodHeader);
        if (StringUtils.hasLength(headerValue)) {
            if (HTTP_METHOD_ORIGINAL.equals(request.getMethod()) && HTTP_METHOD_OVERRIDE.equals(
                headerValue.toUpperCase(Locale.ENGLISH))) {
                HttpServletRequest wrapper = new HttpMethodRequestWrapper(request, HTTP_METHOD_OVERRIDE);
                filterChain.doFilter(wrapper, response);
            } else {
                throw new NotAllowedException(
                    request.getMethod() + " to " + headerValue + " x-http-method-override not supported");
            }
        } else {
            filterChain.doFilter(request, response);
        }
    }

    private static class HttpMethodRequestWrapper extends HttpServletRequestWrapper {

        private final String method;

        public HttpMethodRequestWrapper(HttpServletRequest request, String method) {
            super(request);
            this.method = method;
        }

        @Override
        public String getMethod() {
            return this.method;
        }
    }

}
