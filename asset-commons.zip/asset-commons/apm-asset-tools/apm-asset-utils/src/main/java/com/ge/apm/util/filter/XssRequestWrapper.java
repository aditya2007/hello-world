/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.filter;

import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class XssRequestWrapper extends HttpServletRequestWrapper {

    private static final Pattern scriptPattern = Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE);

    private static final Pattern srcPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'",
        Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);

    private static final Pattern endScriptPattern = Pattern.compile("</script>", Pattern.CASE_INSENSITIVE);

    private static final Pattern scriptTagPattern = Pattern.compile("<script(.*?)>",
        Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);

    private static final Pattern evalPattern = Pattern.compile("eval\\((.*?)\\)",
        Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);

    private static final Pattern expressionPattern = Pattern.compile("expression\\((.*?)\\)",
        Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);

    private static final Pattern javascriptPattern = Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE);

    private static final Pattern vbScriptPattern = Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE);

    private static final Pattern onLoadPattern = Pattern.compile("onload(.*?)=",
        Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);

    public XssRequestWrapper(HttpServletRequest request) {
        super(request);
    }

    @Override
    public String getHeader(String name) {
        return filterXSS(super.getHeader(name));
    }

    @Override
    public String getParameter(String name) {
        return filterXSS(super.getParameter(name));
    }

    @Override
    public String[] getParameterValues(String name) {
        String[] values = super.getParameterValues(name);
        if (values == null) {
            return null;
        }
        String[] filteredValues = new String[values.length];
        for (int i = 0; i < values.length; i++) {
            filteredValues[i] = filterXSS(values[i]);
        }
        return filteredValues;
    }

    private String filterXSS(String input) {
        if (input == null) {
            return null;
        }
        if (input.trim().isEmpty()) {
            return input;
        }
        // Avoid null characters
        input = input.replaceAll("\0", "");
        // Avoid anything between script tags
        input = scriptPattern.matcher(input).replaceAll("");
        // Avoid anything in a src='...' type of expression
        input = srcPattern.matcher(input).replaceAll("");
        // Remove any lonesome </script> tag
        input = endScriptPattern.matcher(input).replaceAll("");
        // Remove any lonesome <script ...> tag
        input = scriptTagPattern.matcher(input).replaceAll("");
        // Avoid eval(...) expressions
        input = evalPattern.matcher(input).replaceAll("");
        // Avoid expression(...) expressions
        input = expressionPattern.matcher(input).replaceAll("");
        // Avoid javascript:... expressions
        input = javascriptPattern.matcher(input).replaceAll("");
        // Avoid vbscript:... expressions
        input = vbScriptPattern.matcher(input).replaceAll("");
        // Avoid onload= expressions
        input = onLoadPattern.matcher(input).replaceAll("");
        return input;
    }
}
