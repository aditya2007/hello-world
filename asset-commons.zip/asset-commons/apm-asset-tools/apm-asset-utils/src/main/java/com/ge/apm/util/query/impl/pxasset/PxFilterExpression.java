/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.query.impl.pxasset;

import org.springframework.util.Assert;

import com.ge.apm.util.query.api.IFilterExpression;
import com.ge.apm.util.query.constants.QueryToken;

@SuppressWarnings("WeakerAccess")
public class PxFilterExpression implements IFilterExpression {
    public static final String Uri = "uri";

    public static final String Parent = "parent";

    public static final String TYPE_EXPRESSION_PREFIX = "type->";

    private StringBuilder expressionBuilder;

    public PxFilterExpression() {
        this.expressionBuilder = new StringBuilder();
    }

    public PxFilterExpression(StringBuilder expressionBuilder) {
        this.expressionBuilder = expressionBuilder;
    }

    @Override
    public boolean isComposite() {
        return false;
    }

    @Override
    public IFilterExpression and(IFilterExpression operand2) {
        Assert.notNull(operand2, "'operand2' must not be null");
        if (!isNullExpression(operand2)) {
            if (expressionBuilder.length() <= 0) {
                return operand2;
            }
            return new PxAndFilterExpression(this, operand2);
        }
        return this;
    }

    @Override
    public IFilterExpression or(IFilterExpression operand2) {
        Assert.notNull(operand2, "'operand2' must not be null");
        if (!isNullExpression(operand2)) {
            if (expressionBuilder.length() <= 0) {
                return operand2;
            }
            return new PxOrFilterExpression(this, operand2);
        }
        return this;
    }

    @Override
    public IFilterExpression backwardRelate(String operand2, int depth) {
        return new PxBackwardRelateExpression(this, operand2, depth);
    }

    @Override
    public IFilterExpression forwardRelate(String operand2, int depth) {
        return new PxForwardRelateExpression(this, operand2, depth);
    }

    @Override
    public IFilterExpression parent(String uri, int depth) {
        StringBuilder expression = new StringBuilder();
        expression.append(QueryToken.OpenBracket)
            .append(PxFilterOperand.attribute(Uri).eq(uri).backwardRelate(Parent, depth).build())
            .append(QueryToken.CloseBracket);
        // parentSearchFilterQuery = attribute(Hierarchical.Uri).eq(uri).backwardRelate(Hierarchical.Parent,depth);
        return new PxFilterExpression(expression);
    }

    @Override
    public IFilterExpression deepSearch(String operand1Name, String operand1Value, String operand2Name,
        int transitiveDepth) {
        return deepSearchHelper(operand1Name, operand1Value, operand2Name, transitiveDepth);
    }

    public static IFilterExpression deepSearchHelper(String operand1Name, String operand1Value, String operand2Name,
        int transitiveDepth) {

        IFilterExpression deepSearchFilterQuery;

        /* search in current asset */
        IFilterExpression assetLevelSearchQuery = PxFilterOperand.attribute(operand1Name).eq(operand1Value);

        /* search in all grand children */
        IFilterExpression allLevelGrandChildSearchQuery = PxFilterOperand.uri().eq(operand1Value)
            .backwardRelate(operand2Name, transitiveDepth)
            .backwardRelate(operand1Name, 1);

        deepSearchFilterQuery = assetLevelSearchQuery.or(allLevelGrandChildSearchQuery);

        return deepSearchFilterQuery;
    }

    @Override
    public String build() {
        return expressionBuilder.toString();
    }

    @Override
    public boolean isTypeExpression() {
        return expressionBuilder.toString().startsWith(TYPE_EXPRESSION_PREFIX);
    }

    protected void appendExpression(IFilterExpression expression) {
        boolean wrap = expression.isComposite() && expression.getClass() != this.getClass();
        if (wrap) {
            expressionBuilder.append(QueryToken.OpenBracket);
        }
        expressionBuilder.append(expression.build());
        if (wrap) {
            expressionBuilder.append(QueryToken.CloseBracket);
        }
    }

    protected void append(String str) {
        expressionBuilder.append(str);
    }

    protected boolean isNullExpression(IFilterExpression expression) {
        return expression instanceof PxNullExpression;
    }
}
