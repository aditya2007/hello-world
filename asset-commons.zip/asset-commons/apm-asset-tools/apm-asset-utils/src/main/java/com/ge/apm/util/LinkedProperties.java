/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.ge.apm.common.exception.ServiceException;

@SuppressWarnings({ "WeakerAccess", "unused" })
public class LinkedProperties extends LinkedHashMap<Object, Object> {
    private static final Logger logger = LoggerFactory.getLogger(LinkedProperties.class);

    private static final long serialVersionUID = 4112578634029874840L;

    private String separator = "";

    public synchronized Object setProperty(String key, String value) {
        return put(key, value);
    }

    public Properties getJavaProperties() {
        Properties properties = new Properties();
        this.forEach(properties::put);
        return properties;
    }

    public void addSeparatorBefore(String inputKeyName) {
        int idx = 0;
        for (Object objKeyName : keySet()) {
            String keyName = (String) objKeyName;

            if (keyName.equalsIgnoreCase(inputKeyName)) {
                break;
            }

            idx++;
        }

        if (idx > 0) {
            this.separator += "-";
        }

        add(idx - 1, this.separator, "");
    }

    public void addSeparatorAfter(String inputKeyName) {
        int idx = 0;
        for (Object objKeyName : keySet()) {
            String keyName = (String) objKeyName;

            if (keyName.equalsIgnoreCase(inputKeyName)) {
                break;
            }

            idx++;
        }

        if (idx > 0) {
            this.separator += "-";
        }

        add(idx, this.separator, "");
    }

    public void add(int index, Object key, Object value) {
        int idx = 0;
        List<Entry<Object, Object>> rest = new ArrayList<>();
        for (Entry<Object, Object> entry : entrySet()) {
            if (idx++ >= index) {
                rest.add(entry);
            }
        }
        put(key, value);
        for (Entry<Object, Object> entry : rest) {
            remove(entry.getKey());
            put(entry.getKey(), entry.getValue());
        }
    }

    public synchronized Object putProperty(String key, String value) {
        if (!StringUtils.hasText(value)) {
            String errorMessage = MessageFormat.format("Cannot put property ''{0}'' as its value is empty.", key);
            logger.error(errorMessage);
            throw new ServiceException(errorMessage);
        }
        return put(key, value);
    }

    public String getProperty(String key) {
        String propertyValue = (String) get(key);
        validatePropertyValue(key, propertyValue);
        return StringUtils.trimAllWhitespace(propertyValue);
    }

    public static void validatePropertyValue(String propertyName, String propertyValue) {
        if (!StringUtils.hasText(propertyValue)) {
            String errorMessage = MessageFormat.format("The value for the property ''{0}'' is empty", propertyName);
            logger.error(errorMessage);
            throw new ServiceException(errorMessage);
        }
    }

    public synchronized void load(InputStream inStream) throws IOException {
        load0(new LineReader(inStream));
    }

    private void load0(LineReader lr) throws IOException {
        char[] convtBuf = new char[1024];
        int limit;
        int keyLen;
        int valueStart;
        char charVar;
        boolean hasSep;
        boolean precedingBackslash;

        while ((limit = lr.readLine()) >= 0) {
            keyLen = 0;
            valueStart = limit;
            hasSep = false;

            //System.out.println("line=<" + new String(lineBuf, 0, limit) + ">");
            precedingBackslash = false;
            while (keyLen < limit) {
                charVar = lr.lineBuf[keyLen];
                //need check if escaped.
                if ((charVar == '=' || charVar == ':') && !precedingBackslash) {
                    valueStart = keyLen + 1;
                    hasSep = true;
                    break;
                } else if ((charVar == ' ' || charVar == '\t' || charVar == '\f') && !precedingBackslash) {
                    valueStart = keyLen + 1;
                    break;
                }
                precedingBackslash = charVar == '\\' && !precedingBackslash;
                keyLen++;
            }
            while (valueStart < limit) {
                charVar = lr.lineBuf[valueStart];
                if (charVar != ' ' && charVar != '\t' && charVar != '\f') {
                    if (!hasSep && (charVar == '=' || charVar == ':')) {
                        hasSep = true;
                    } else {
                        break;
                    }
                }
                valueStart++;
            }
            String key = loadConvert(lr.lineBuf, 0, keyLen, convtBuf);
            String value = loadConvert(lr.lineBuf, valueStart, limit - valueStart, convtBuf);
            put(key, value);
        }
    }

    private String loadConvert(char[] in, int off, int len, char[] convtBuf) {
        if (convtBuf.length < len) {
            int newLen = len * 2;
            if (newLen < 0) {
                newLen = Integer.MAX_VALUE;
            }
            convtBuf = new char[newLen];
        }
        char achar;
        char[] out = convtBuf;
        int outLen = 0;
        int end = off + len;

        while (off < end) {
            achar = in[off++];
            if (achar == '\\') {
                achar = in[off++];
                if (achar == 'u') {
                    // Read the xxxx
                    int value = 0;
                    for (int i = 0; i < 4; i++) {
                        achar = in[off++];
                        switch (achar) {
                            case '0':
                            case '1':
                            case '2':
                            case '3':
                            case '4':
                            case '5':
                            case '6':
                            case '7':
                            case '8':
                            case '9':
                                value = (value << 4) + achar - '0';
                                break;
                            case 'a':
                            case 'b':
                            case 'c':
                            case 'd':
                            case 'e':
                            case 'f':
                                value = (value << 4) + 10 + achar - 'a';
                                break;
                            case 'A':
                            case 'B':
                            case 'C':
                            case 'D':
                            case 'E':
                            case 'F':
                                value = (value << 4) + 10 + achar - 'A';
                                break;
                            default:
                                throw new IllegalArgumentException(
                                    "Malformed \\uxxxx encoding.");
                        }
                    }
                    out[outLen++] = (char) value;
                } else {
                    if (achar == 't') {
                        achar = '\t';
                    } else if (achar == 'r') {
                        achar = '\r';
                    } else if (achar == 'n') {
                        achar = '\n';
                    } else if (achar == 'f') {
                        achar = '\f';
                    }
                    out[outLen++] = achar;
                }
            } else {
                out[outLen++] = achar;
            }
        }
        return new String(out, 0, outLen);
    }

    /* Read in a "logical line" from an InputStream/Reader, skip all comment
     * and blank lines and filter out those leading whitespace characters
     * (\u0020, \u0009 and \u000c) from the beginning of a "natural line".
     * Method returns the char length of the "logical line" and stores
     * the line in "lineBuf".
     */
    private class LineReader {
        byte[] inByteBuf;

        char[] inCharBuf;

        char[] lineBuf = new char[1024];

        int inLimit = 0;

        int inOff = 0;

        InputStream inStream;

        Reader reader;

        public LineReader(InputStream inStream) {
            this.inStream = inStream;
            this.inByteBuf = new byte[8192];
        }

        int readLine() throws IOException {
            int len = 0;
            char charVar;

            boolean skipWhiteSpace = true;
            boolean isCommentLine = false;
            boolean isNewLine = true;
            boolean appendedLineBegin = false;
            boolean precedingBackslash = false;
            boolean skipLF = false;

            while (true) {
                if (this.inOff >= this.inLimit) {
                    this.inLimit = (this.inStream == null) ? this.reader.read(this.inCharBuf)
                        : this.inStream.read(this.inByteBuf);
                    this.inOff = 0;
                    if (this.inLimit <= 0) {
                        if (len == 0 || isCommentLine) {
                            return -1;
                        }
                        if (precedingBackslash) {
                            len--;
                        }
                        return len;
                    }
                }
                if (this.inStream != null) {
                    //The line below is equivalent to calling a
                    //ISO8859-1 decoder.
                    charVar = (char) (0xff & this.inByteBuf[this.inOff++]);
                } else {
                    Objects.requireNonNull(this.inCharBuf);
                    charVar = this.inCharBuf[this.inOff++];
                }
                if (skipLF) {
                    skipLF = false;
                    if (charVar == '\n') {
                        continue;
                    }
                }
                if (skipWhiteSpace) {
                    if (charVar == ' ' || charVar == '\t' || charVar == '\f') {
                        continue;
                    }
                    if (!appendedLineBegin && (charVar == '\r' || charVar == '\n')) {
                        continue;
                    }
                    skipWhiteSpace = false;
                    appendedLineBegin = false;
                }
                if (isNewLine) {
                    isNewLine = false;
                    if (charVar == '#' || charVar == '!') {
                        isCommentLine = true;
                        continue;
                    }
                }

                if (charVar != '\n' && charVar != '\r') {
                    this.lineBuf[len++] = charVar;
                    if (len == this.lineBuf.length) {
                        int newLength = this.lineBuf.length * 2;
                        char[] buf = new char[newLength];
                        System.arraycopy(this.lineBuf, 0, buf, 0, this.lineBuf.length);
                        this.lineBuf = buf;
                    }
                    //flip the preceding backslash flag
                    precedingBackslash = charVar == '\\' && !precedingBackslash;
                } else {
                    // reached EOL
                    if (isCommentLine || len == 0) {
                        isCommentLine = false;
                        isNewLine = true;
                        skipWhiteSpace = true;
                        len = 0;
                        continue;
                    }
                    if (this.inOff >= this.inLimit) {
                        this.inLimit = (this.inStream == null)
                            ? this.reader.read(this.inCharBuf)
                            : this.inStream.read(this.inByteBuf);
                        this.inOff = 0;
                        if (this.inLimit <= 0) {
                            if (precedingBackslash) {
                                len--;
                            }
                            return len;
                        }
                    }
                    if (precedingBackslash) {
                        len -= 1;
                        //skip the leading whitespace characters in following line
                        skipWhiteSpace = true;
                        appendedLineBegin = true;
                        precedingBackslash = false;
                        if (charVar == '\r') {
                            skipLF = true;
                        }
                    } else {
                        return len;
                    }
                }
            }
        }
    }
}
