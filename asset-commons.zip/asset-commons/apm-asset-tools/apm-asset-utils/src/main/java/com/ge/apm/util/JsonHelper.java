/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.core.util.DefaultIndenter;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.ser.std.NonTypedScalarSerializerBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.AnnotationUtils;

import com.ge.apm.common.exception.DefaultErrorCode;
import com.ge.apm.common.exception.IErrorCode;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.util.errorcodes.UtilsErrorCodes;
import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;
import static com.fasterxml.jackson.databind.DeserializationFeature.UNWRAP_ROOT_VALUE;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_CONVERTING_JSON_TO_MAP;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_CONVERTING_JSON_TO_NODE;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_CONVERTING_JSON_TO_OBJ;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_CREATING_JSON_PARSER;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_PARSING_JSON;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.FIELD_NAME_DOES_NOT_EXIST_IN_JSON;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.INVALID_JSON_PATH;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.JSON_SUB_TYPE_ANNOTATION_IS_NOT_PRESENT;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.JSON_SUB_TYPE_CLASS_MISMATCH;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.MORE_THAN_ONE_TYPE_FOR_JSON_SUB_TYPE;
import static com.ge.apm.util.exceptions.ExceptionHelper.getException;
import static com.ge.apm.util.exceptions.ExceptionHelper.getRootCause;

public class JsonHelper {

    private static Logger logger = LoggerFactory.getLogger(JsonHelper.class);

    private static ObjectMapper deserializer_mapper_noFailUnknown_noUnWrapRoot;

    private static final ObjectMapper deserializer_mapper_noFailUnknown_unwrapRoot;

    private static final ObjectMapper deserializer_mapper_failUnknown_unwrapRoot_notNullOnlyInclude;

    private static final ObjectMapper deserializer_mapper_failUnknown_wrapRoot_notNullOnlyInclude;

    private static ObjectMapper serializer_mapper_nowrapRoot_notNullOnlyInclude;

    private static final ObjectMapper serializer_mapper_nowrapRoot_nullAlsoInclude;

    private static final ObjectMapper serializer_mapper_wrapRoot_nullAlsoInclude;

    private static final ObjectMapper serializer_mapper_wrapRoot_notNullOnlyInclude;

    private static final ObjectMapper noQuoteStringObjectMapper;

    static {
        // need to convert all these mappers into one.
        deserializer_mapper_noFailUnknown_unwrapRoot = new ObjectMapper();
        deserializer_mapper_noFailUnknown_unwrapRoot.configure(FAIL_ON_UNKNOWN_PROPERTIES, false);
        deserializer_mapper_noFailUnknown_unwrapRoot.configure(UNWRAP_ROOT_VALUE, true);
        deserializer_mapper_noFailUnknown_unwrapRoot.setSerializationInclusion(Include.NON_NULL);

        deserializer_mapper_noFailUnknown_noUnWrapRoot = new ObjectMapper();
        deserializer_mapper_noFailUnknown_noUnWrapRoot.configure(FAIL_ON_UNKNOWN_PROPERTIES, false);
        deserializer_mapper_noFailUnknown_noUnWrapRoot.configure(UNWRAP_ROOT_VALUE, false);
        deserializer_mapper_noFailUnknown_noUnWrapRoot.setSerializationInclusion(Include.NON_NULL);

        deserializer_mapper_failUnknown_unwrapRoot_notNullOnlyInclude = new ObjectMapper();
        deserializer_mapper_failUnknown_unwrapRoot_notNullOnlyInclude.configure(FAIL_ON_UNKNOWN_PROPERTIES, true);
        deserializer_mapper_failUnknown_unwrapRoot_notNullOnlyInclude.configure(UNWRAP_ROOT_VALUE, true);
        deserializer_mapper_failUnknown_unwrapRoot_notNullOnlyInclude.setSerializationInclusion(Include.NON_NULL);

        deserializer_mapper_failUnknown_wrapRoot_notNullOnlyInclude = new ObjectMapper();
        deserializer_mapper_failUnknown_wrapRoot_notNullOnlyInclude.configure(FAIL_ON_UNKNOWN_PROPERTIES, true);
        deserializer_mapper_failUnknown_wrapRoot_notNullOnlyInclude.configure(UNWRAP_ROOT_VALUE, false);
        deserializer_mapper_failUnknown_wrapRoot_notNullOnlyInclude.setSerializationInclusion(Include.NON_NULL);

        serializer_mapper_nowrapRoot_notNullOnlyInclude = new ObjectMapper();
        serializer_mapper_nowrapRoot_notNullOnlyInclude.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        serializer_mapper_nowrapRoot_notNullOnlyInclude.setSerializationInclusion(Include.NON_NULL);
        serializer_mapper_nowrapRoot_notNullOnlyInclude.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

        serializer_mapper_nowrapRoot_nullAlsoInclude = new ObjectMapper();
        serializer_mapper_nowrapRoot_nullAlsoInclude.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        serializer_mapper_nowrapRoot_nullAlsoInclude.setSerializationInclusion(Include.ALWAYS);

        serializer_mapper_wrapRoot_nullAlsoInclude = new ObjectMapper();
        serializer_mapper_wrapRoot_nullAlsoInclude.configure(SerializationFeature.WRAP_ROOT_VALUE, true);
        serializer_mapper_wrapRoot_nullAlsoInclude.setSerializationInclusion(Include.ALWAYS);

        serializer_mapper_wrapRoot_notNullOnlyInclude = new ObjectMapper();
        serializer_mapper_wrapRoot_notNullOnlyInclude.configure(SerializationFeature.WRAP_ROOT_VALUE, true);
        serializer_mapper_wrapRoot_notNullOnlyInclude.setSerializationInclusion(Include.NON_NULL);

        noQuoteStringObjectMapper = new ObjectMapper();
        noQuoteStringObjectMapper.configure(JsonGenerator.Feature.QUOTE_FIELD_NAMES, false);
        noQuoteStringObjectMapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        noQuoteStringObjectMapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS, true);
        SimpleModule simpleModule = new SimpleModule("NoQuteString");
        simpleModule.addSerializer(new NoQuoteStringSerializer());

        noQuoteStringObjectMapper.registerModule(simpleModule);
        noQuoteStringObjectMapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        noQuoteStringObjectMapper.setSerializationInclusion(Include.NON_NULL);
        noQuoteStringObjectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

    }

    public static void setDefaultObjectMapper(ObjectMapper objectMapper) {
        deserializer_mapper_noFailUnknown_noUnWrapRoot = objectMapper;
        serializer_mapper_nowrapRoot_notNullOnlyInclude = objectMapper;
    }

    public static String toJsonPrettyPrint(Object object) {
        return toJson(object, true /*prettyPrint*/, false /*wrapRootValue*/, true /*includeNotNullOnly*/, false /*
        enableDefaultTyping */);
    }

    public static String toJson(Object object, boolean prettyPrint, boolean wrapRootValue, boolean includeNotNullOnly) {
        return toJson(object, prettyPrint, wrapRootValue, includeNotNullOnly, false /* enableDefaultTyping */);
    }

    public static String toJson(Object object, boolean prettyPrint, boolean wrapRootValue, boolean includeNotNullOnly,
        boolean enableDefaultTyping) {
        String methodName = "toJson";

        if (object == null) {
            return "{}";
        }

        ObjectMapper mapper;
        ObjectWriter writer;

        if (wrapRootValue) {
            if (includeNotNullOnly) {
                mapper = serializer_mapper_wrapRoot_notNullOnlyInclude;
            } else {
                mapper = serializer_mapper_wrapRoot_nullAlsoInclude;
            }
        } else {
            if (includeNotNullOnly) {
                mapper = serializer_mapper_nowrapRoot_notNullOnlyInclude;
            } else {
                mapper = serializer_mapper_nowrapRoot_nullAlsoInclude;
            }
        }

        if (prettyPrint) {
            DefaultPrettyPrinter defaultPrettyPrinter = new DefaultPrettyPrinter();
            defaultPrettyPrinter.indentArraysWith(new DefaultIndenter());
            writer = mapper.writer(defaultPrettyPrinter);
        } else {
            writer = mapper.writer();
        }

        if (enableDefaultTyping) {
            mapper.enableDefaultTyping();
        } else {
            mapper.disableDefaultTyping();
        }

        try {
            return writer.writeValueAsString(object);
        } catch (JsonProcessingException exception) {
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CONVERTING_JSON_TO_OBJ,
                exception.getMessage());
        }
    }

    public static String toJson(Object object) {
        return toJson(object, false /*prettyPrint*/, false /*wrapRootValue*/, true /*includeNotNullOnly*/, false /*
        enableDefaultTyping */);
    }

    public static <T> T fromJson(String json, Class<T> clazz) {
        return fromJson(json, clazz, false /*unwrapRootValue*/, false /*failOnUnknownProperties*/);
    }

    public static <T> T fromJson(String json, Class<T> clazz, boolean unwrapRootValue,
        boolean failOnUnknownProperties) {
        return fromJson(json, clazz, unwrapRootValue, failOnUnknownProperties, null /*registerModules*/, false /*
        enableDefaultTyping */);
    }

    public static <T> T fromJson(String json, Class<T> clazz, boolean unwrapRootValue, boolean failOnUnknownProperties,
        List<SimpleModule> registerModules, boolean enableDefaultTyping) {
        String methodName = "fromJson";
        try {
            return fromJsonNoExcpLog(json, clazz, unwrapRootValue, failOnUnknownProperties, registerModules,
                enableDefaultTyping);
        } catch (JsonMappingException exception) {
            logger.error("", getRootCause(exception));
            logger.error("Error Json: '{}'", json);
            logger.error("{}| Location: {}", methodName, exception.getLocation());
            // Check if the message contains the at source [...] block introduced in Jackson 2.8.5 and remove it
            // This is making tests fail, that compare the expected error message with the actual in several places.
            String errMessage = exception.getMessage();
            Pattern pattern = Pattern.compile("at \\[Source");
            Matcher matcher = pattern.matcher(errMessage);
            int startindex = -1;
            while (matcher.find()) {
                startindex = matcher.start();
            }
            int endindex = -1;
            Pattern endPattern = Pattern.compile("] \\(through reference chain:");
            Matcher endmatcher = endPattern.matcher(errMessage);
            while (endmatcher.find()) {
                endindex = endmatcher.start();
            }

            String finalMessage = errMessage;
            if (startindex != -1 && endindex != -1) {
                finalMessage = errMessage.substring(0, startindex - 2) + errMessage.substring(endindex + 1,
                    errMessage.length());
                logger.debug("Error message after replace: {}", finalMessage);
            }
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CONVERTING_JSON_TO_OBJ,
                finalMessage);
        } catch (IllegalAccessException | InstantiationException | IOException exception) {
            logger.error("Error Json: '{}'", json);
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CONVERTING_JSON_TO_OBJ,
                exception.getMessage());
        }
    }

    public static <T> T fromJson(String json, JavaType type) {
        return fromJson(json, type, false);
    }

    public static <T> T fromJson(String json, JavaType type, boolean unwrapRootValue) {
        String methodName = "fromJson";

        try {

            ObjectMapper mapper = getObjectMapper(unwrapRootValue, false /*failOnUnknownProperties*/, null
                /*registerModules*/, false /* enableDefaultTyping */);
            T object;
            object = mapper.readValue(json, type);
            return object;
        } catch (JsonMappingException exception) {
            logger.info("{}| Location Of Problem: '{}'", methodName, exception.getLocation());
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CONVERTING_JSON_TO_OBJ,
                exception.getMessage());
        } catch (IOException exception) {
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CONVERTING_JSON_TO_OBJ,
                exception.getMessage());
        }
    }

    // new TypeReference<Map<String,Theme>>() {}
    public static <T> T fromJson(String json, TypeReference<?> valueTypeRef) {
        String methodName = "JsonHelper.fromJson";
        try {
            T object;
            object = deserializer_mapper_failUnknown_unwrapRoot_notNullOnlyInclude.readValue(json, valueTypeRef);
            return object;
        } catch (JsonMappingException exception) {
            logger.info("{}| Location Of Problem: '{}'", methodName, exception.getLocation());
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CONVERTING_JSON_TO_OBJ,
                exception.getMessage());
        } catch (IOException exception) {
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CONVERTING_JSON_TO_OBJ,
                exception.getMessage());
        }
    }

    public static <T> T fromJsonNoExcpLog(String json, Class<T> clazz, boolean unwrapRootValue,
        boolean failOnUnknownProperties) throws IllegalAccessException, IOException, InstantiationException {
        return fromJsonNoExcpLog(json, clazz, unwrapRootValue, failOnUnknownProperties, null /*registerModules*/,
            false /* enableDefaultTyping */);
    }

    public static <T> T fromJsonNoExcpLog(String json, Class<T> clazz, boolean unwrapRootValue,
        boolean failOnUnknownProperties, List<SimpleModule> registerModules)
        throws IOException, IllegalAccessException, InstantiationException {
        return fromJsonNoExcpLog(json, clazz, unwrapRootValue, failOnUnknownProperties, registerModules, false /*
        enableDefaultTyping */);
    }

    public static <T> T fromJsonNoExcpLog(String json, Class<T> clazz, boolean unwrapRootValue,
        boolean failOnUnknownProperties, List<SimpleModule> registerModules, boolean enableDefaultTyping)
        throws IOException, IllegalAccessException, InstantiationException {

        if (clazz == String.class) {
            return (T) json;
        }

        if (json == null) {
            return clazz.newInstance();
        }

        ObjectMapper mapper = getObjectMapper(unwrapRootValue, failOnUnknownProperties, registerModules, false /*
        enableDefaultTyping */);
        T object;
        object = mapper.readValue(json, clazz);
        return object;
    }

    public static ObjectMapper getObjectMapper(boolean unwrapRootValue, boolean failOnUnknownProperties,
        List<SimpleModule> registerModules, boolean enableDefaultTyping) {

        if (registerModules != null) {
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(FAIL_ON_UNKNOWN_PROPERTIES, failOnUnknownProperties);
            mapper.configure(UNWRAP_ROOT_VALUE, unwrapRootValue);
            mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

            registerModules.forEach(mapper::registerModule);
            return mapper;
        }

        if (!failOnUnknownProperties) {
            if (unwrapRootValue) {
                return deserializer_mapper_noFailUnknown_unwrapRoot;
            } else {
                return deserializer_mapper_noFailUnknown_noUnWrapRoot;
            }
        } else {
            if (unwrapRootValue) {
                return deserializer_mapper_failUnknown_unwrapRoot_notNullOnlyInclude;
            } else {
                return deserializer_mapper_failUnknown_wrapRoot_notNullOnlyInclude;
            }
        }
    }

    // SAMPLE FOR REGISTERING MODULES:
    //
    //    private static class SingleKeyHashMap<K, V> extends HashMap<K, V> {
    //        @Override
    //        public V put(K key, V value) {
    //            if (containsKey(key)) {
    //                throw new IllegalArgumentException("duplicate key " + key);
    //            }
    //            return super.put(key, value);
    //        }
    //    }
    //    SimpleModule module = new SimpleModule();
    //    module.addAbstractTypeMapping(Map.class, SingleKeyHashMap.class);
    //    ObjectMapper mapper = new ObjectMapper();
    //    mapper.registerModule(module);

    public static Map<String, Object> fromJsonToMap(Object object) {
        String methodName = "fromJsonToMap";

        if (object == null) {
            IErrorCode errorCode = UtilsErrorCodes.ARGUMENT_NULL;
            String errorMessage = String.format(errorCode.message(), "JSON");
            logger.error("{}| {}, \n JSON: '{}'", methodName, errorMessage);
            throw new ServiceException(DefaultErrorCode.create(errorCode.name(), errorMessage));
        }

        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        try {
            if (object instanceof String) {
                return mapper.readValue((String) object, new TypeReference<LinkedHashMap<String, Object>>() {});
            }

            return mapper.convertValue(object, new TypeReference<LinkedHashMap<String, Object>>() {});
        } catch (IOException exception) {
            logger.error("{}| {}, \n JSON: '{}'", methodName, exception.getMessage(), object);
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CONVERTING_JSON_TO_MAP,
                exception.getMessage());
        }
    }

    public static Map<String, String> fromJsonToStrToStrMap(Object object) {
        String methodName = "fromJsonToMap";

        if (object == null) {
            IErrorCode errorCode = UtilsErrorCodes.ARGUMENT_NULL;
            String errorMessage = String.format(errorCode.message(), "JSON");
            logger.error("{}| {}, \n JSON: '{}'", methodName, errorMessage);
            throw new ServiceException(DefaultErrorCode.create(errorCode.name(), errorMessage));
        }

        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        try {
            if (object instanceof String) {
                return mapper.readValue((String) object, new TypeReference<LinkedHashMap<String, String>>() {});
            }

            return mapper.convertValue(object, new TypeReference<LinkedHashMap<String, String>>() {});
        } catch (IOException exception) {
            logger.error("{}| {}, \n JSON: '{}'", methodName, exception.getMessage(), object);
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CONVERTING_JSON_TO_MAP,
                exception.getMessage());
        }
    }

    public static void checkIfDuplicateFieldsInJson(String json, List<String> skipFieldsForChecking) {
        String methodName = "checkIfDuplicateFieldsInJson";
        json = json.trim();
        final JsonFactory jsonFactory = new JsonFactory();
        JsonParser parser;
        try {
            parser = jsonFactory.createParser(json);
        } catch (IOException exception) {
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CREATING_JSON_PARSER,
                exception.getMessage());
        }
        JsonToken endToken;

        String startChar = json.substring(0, 1);
        if (startChar.equals(JsonToken.START_ARRAY.asString())) {
            endToken = JsonToken.END_ARRAY;
        } else if (startChar.equals(JsonToken.START_OBJECT.asString())) {
            endToken = JsonToken.END_OBJECT;
        } else {
            throw getException(methodName, logger, UtilsErrorCodes.INVALID_JSON_START_TOKEN, startChar, json);
        }
        checkIfDuplicateFieldsInJson(json, skipFieldsForChecking, parser, endToken);
    }

    public static void checkIfDuplicateFieldsInJson(String json, List<String> skipFieldsForChecking, JsonParser parser,
        JsonToken endToken) {
        String methodName = "checkIfDuplicateFieldsInJson";
        try {
            HashSet<String> set = new HashSet<>();

            JsonToken token;
            String fieldName;
            while ((token = parser.nextToken()) != endToken) {
                if (token == null) {
                    return;
                }
                switch (token) {
                    case FIELD_NAME:
                        fieldName = parser.getText();
                        if (skipFieldsForChecking.contains(fieldName)) {
                            continue;
                        }
                        if (!set.add(fieldName)) {
                            throw getException(methodName, logger, UtilsErrorCodes.DUPLICATE_FIELD_IN_THE_JSON,
                                fieldName, parser.getCurrentLocation().getLineNr(), json);
                        }
                        break;
                    case START_ARRAY:
                    case START_OBJECT:
                        checkIfDuplicateFieldsInJson(json, skipFieldsForChecking, parser,
                            (token == JsonToken.START_OBJECT) ? JsonToken.END_OBJECT : JsonToken.END_ARRAY);
                        parser.skipChildren();
                        break;
                    default:
                        break;
                }
            }
        } catch (IOException exception) {
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_PARSING_JSON,
                exception.getMessage(), json);
        }
    }

    public static JsonNode convertJsonToJsonNodeUnWrapRoot(String json) {
        final String methodName = "JsonHelper.convertJsonToJsonNode";
        try {
            return deserializer_mapper_noFailUnknown_unwrapRoot.readTree(json);
        } catch (IOException exception) {
            String logMsg =
                "Error converting the JSON into JsonNode." + System.lineSeparator() + exception.getMessage() + System
                    .lineSeparator() + "Json:" + System.lineSeparator() + json;
            logger.error(logMsg, exception);
            throw getException(methodName, logger, ERROR_CONVERTING_JSON_TO_NODE, exception.getMessage());
        }
    }

    public static JsonNode convertJsonToJsonNodeNoWrapRoot(String json) {
        final String methodName = "JsonHelper.convertJsonToJsonNode";
        try {
            return deserializer_mapper_noFailUnknown_noUnWrapRoot.readTree(json);
        } catch (IOException exception) {
            String logMsg =
                "Error converting the JSON into JsonNode." + System.lineSeparator() + exception.getMessage() + System
                    .lineSeparator() + "Json:" + System.lineSeparator() + json;
            logger.error(logMsg, exception);
            throw getException(methodName, logger, ERROR_CONVERTING_JSON_TO_NODE, exception.getMessage());
        }
    }

    public static JsonNode convertJsonToJsonArrayNode(String json) {
        final String methodName = "JsonHelper.convertJsonToJsonArrayNode";
        try {
            return deserializer_mapper_noFailUnknown_noUnWrapRoot.readTree(json);
        } catch (IOException exception) {
            String logMsg =
                "Error converting the JSON into JsonNode." + System.lineSeparator() + exception.getMessage() + System
                    .lineSeparator() + "Json:" + System.lineSeparator() + json;
            logger.error(logMsg, exception);
            throw getException(methodName, logger, ERROR_CONVERTING_JSON_TO_NODE, exception.getMessage());
        }
    }

    public static JsonNode getJsonPathNode(String json, String jsonPath) {
        JsonNode jsonNode = convertJsonToJsonNodeUnWrapRoot(json);
        return getJsonPathNode(jsonNode, jsonPath);
    }

    public static JsonNode getJsonPathNode(JsonNode jsonNode, String jsonPath) {
        final String methodName = "JsonHelper.getJsonPathNode";

        JsonNode fieldNode = getJsonPathNodeNoThrow(jsonNode, jsonPath);

        if (fieldNode.isMissingNode()) {
            logger.error("{}", jsonNode.asText());
            throw getException(methodName, logger, INVALID_JSON_PATH, jsonPath);
        }

        return fieldNode;
    }

    public static String replaceJsonFieldValue(String json, String fieldName, String newValue) {

        final String methodName = "JsonHelper.replaceJsonFieldValue";

        JsonNode jsonNode = convertJsonToJsonNodeNoWrapRoot(json);

        if (!jsonNode.has(fieldName)) {
            throw getException(methodName, logger, FIELD_NAME_DOES_NOT_EXIST_IN_JSON, json, fieldName);
        }

        ((ObjectNode) jsonNode).put(fieldName, newValue);
        return convertJsonNodeTreeToString(jsonNode);
    }

    public static String convertJsonNodeTreeToString(JsonNode jsonNode) {
        final String methodName = "JsonHelper.convertJsonNodeTreeToString";

        try {
            return JsonHelper.toJson(
                serializer_mapper_nowrapRoot_notNullOnlyInclude.treeToValue(jsonNode, Object.class));
        } catch (JsonProcessingException exception) {
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CONVERTING_JSON_TO_OBJ,
                exception.getMessage());
        }
    }

    public static JsonNode getJsonPathNodeNoThrow(JsonNode jsonNode, String jsonPath) {
        return jsonNode.at(jsonPath);
    }

    public static String getJsonSubTypeName(Class<?> beanClazz) {
        return getJsonSubTypeAnnotation(beanClazz).name();
    }

    public static Type getJsonSubTypeAnnotation(Class<?> beanClazz) {
        final String methodName = "JsonHelper.getJsonSubTypesAnnotation";

        // validate that JsonSubType annotation is actually on the current class
        if (!AnnotationUtils.isAnnotationDeclaredLocally(JsonSubTypes.class, beanClazz)) {
            throw getException(methodName, logger, JSON_SUB_TYPE_ANNOTATION_IS_NOT_PRESENT, beanClazz.getSimpleName());
        }

        JsonSubTypes jsonSubTypeAnnotation;
        jsonSubTypeAnnotation = AnnotationUtils.findAnnotation(beanClazz, JsonSubTypes.class);

        if (jsonSubTypeAnnotation == null) {
            throw getException(methodName, logger, JSON_SUB_TYPE_ANNOTATION_IS_NOT_PRESENT, beanClazz.getName());
        }

        Type[] types = jsonSubTypeAnnotation.value();
        if (types.length > 1) {
            throw getException(methodName, logger, MORE_THAN_ONE_TYPE_FOR_JSON_SUB_TYPE, beanClazz.getName());
        }

        Type jsonSubType = types[0];

        if (!jsonSubType.value().getName().equalsIgnoreCase(beanClazz.getName())) {
            throw getException(methodName, logger, JSON_SUB_TYPE_CLASS_MISMATCH, beanClazz.getSimpleName(),
                jsonSubType.value().getName());
        }

        return jsonSubType;
    }

    public static class NoQuoteStringSerializer extends NonTypedScalarSerializerBase<String> {

        public NoQuoteStringSerializer() {
            super(String.class);
        }

        /**
         * For Strings, both null and Empty String qualify for emptiness.
         */
        @Override
        public boolean isEmpty(SerializerProvider provider, String value) {
            return (value == null) || (value.length() == 0);
        }

        @Override
        public void serialize(String value, JsonGenerator jgen, SerializerProvider provider) throws IOException {
            jgen.writeRawValue(value);
        }

        @Override
        public JsonNode getSchema(SerializerProvider provider, java.lang.reflect.Type typeHint, boolean isOptional)
            throws JsonMappingException {
            return createSchemaNode("string", true);
        }

        @Override
        public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint)
            throws JsonMappingException {
            if (visitor != null) {
                visitor.expectStringFormat(typeHint);
            }
        }
    }

    public static class MyPrettyPrinter extends DefaultPrettyPrinter {

        @Override
        public DefaultPrettyPrinter createInstance() {
            return new MyPrettyPrinter();
        }

        @Override
        public void writeStartArray(JsonGenerator jg) throws IOException {
            if (!this._arrayIndenter.isInline()) {
                ++this._nesting;
            }

            jg.writeRaw("");
        }

        @Override
        public void writeEndArray(JsonGenerator gen, int nrOfValues) throws IOException {
            if (!this._arrayIndenter.isInline()) {
                --this._nesting;
            }

            gen.writeRaw("");
        }

        @Override
        public void writeArrayValueSeparator(JsonGenerator gen) throws IOException {
            gen.writeRaw(System.lineSeparator());
        }
    }

    public static String toJsonListAsStringNoQuotes(Object object) {
        final String methodName = "JsonHelper.toJsonListAsStringNoQuotes";

        ObjectWriter writer;

        MyPrettyPrinter defaultPrettyPrinter = new MyPrettyPrinter();
        defaultPrettyPrinter.indentArraysWith(new DefaultIndenter());
        writer = noQuoteStringObjectMapper.writer(defaultPrettyPrinter);

        // noQuoteStringObjectMapper.disableDefaultTyping();

        try {
            return writer.writeValueAsString(object);
        } catch (JsonProcessingException exception) {
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_CONVERTING_JSON_TO_OBJ,
                exception.getMessage());
        }
    }

}
