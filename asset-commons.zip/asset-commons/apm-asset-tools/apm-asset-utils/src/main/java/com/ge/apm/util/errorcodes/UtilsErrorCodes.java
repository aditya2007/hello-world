/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.errorcodes;

import com.ge.apm.common.exception.IErrorCode;

public enum UtilsErrorCodes implements IErrorCode {
    INTERNAL_SERVER_ERROR("Internal Server error. Please contact support."),
    OBJECT_NOT_FOUND("%s is not found."),
    ARGUMENT_NULL("Input '%s' object is null."),
    NO_DATA_TYPE("Data type is not given for the %s '%s'. Valid types are '%s'."),
    NO_VALUE_GIVEN("No value has been given for the %s '%s'. Please provide valid value."),
    INVALID_DATA_TYPE("Invalid data type '%s' given for the %s '%s'. Valid types are '%s'."),
    DATA_TYPE_NOT_HANDLED("Internal Logic Error. Data type '%s' for the %s '%s' is not handled."),
    INVALID_DEPLOY_STATUS_DISPLAY_NAME("Invalid display name: '%s'"),
    PREDIX_DEPLOY_STATUS_NOT_HANDLED("Invalid Predix status: '%s'."),
    INVALID_MAPPING_TYPE("Unknown mapping type given for deploy configuration."),
    INVALID_INPUT_DEF_IN_MAPPING("Input name '%s' does not exist in the rest."),
    ASSET_URI_IS_EMPTY("Asset Uri is empty for the asset '%s'"),
    ASSET_HAS_NO_MAPPING(
        "The input '%s' for the asset '%s' has not been mapped with a tag. Please do the mapping before executing."),
    DUPLICATE_INPUT_NAMES("Duplicate %s names are not allowed. Duplicates are '%s'"),
    OBJECT_FOR_NAME_NOT_FOUND("Cannot find %s for the name '%s'"),
    ERROR_CONVERTING_JSON_TO_MAP("Error convering JSON to map."),
    CANNOT_DESERIALIZE_DEFINETYPE("Cannot deserialize as the type '%s' is not handled."),
    MORE_TAGS_MAPPED("The tags mapped count '%s' is greater than the allowed tags count '%s'. "),
    INVALID_JSON_START_TOKEN("Invalid json start token '%s' in the JSON '%s'."),
    DUPLICATE_FIELD_IN_THE_JSON("Duplicate entry '%s' at line '%s' in JSON '%s'."),
    ERROR_CREATING_JSON_PARSER("Error creating JSON parser. %s"),
    ERROR_PARSING_JSON("Error '%s' parsing the JSON '%s'."),
    INVALID_ATTRIBUTE_NAME("Cannot delete attribute '%s' from rest as it does not exist."),
    PREDIX_NEXT_PAGE_LINK_IS_INVALID("The next page link URI '%s' is invalid."),
    ERROR_CONVERTING_JSON_TO_OBJ("Error converting JSON to object. %s"),
    PROXY_HOST_EMPTY("The proxy host value is not provided."),
    PROXY_PORT_EMPTY("The proxy port value is not provided."),
    INVALID_FILE_NAME("Invalid file name '%s'"),
    ERROR_CREATING_TMP_DIR("Error creating temporary directory. %s"),
    ERROR_CREATING_DIR("Error creating directory."),
    CANNOT_READ_MULTIPART_FILE("Cannot read file contents of '%s' %s."),
    NOT_A_VALID_NUMBER("The '%s' value '%s' is invalid."),
    VALUE_IS_EMPTY("Value is empty."),
    INVALID_TIME_VALUE("Invalid date value: '%s'. Expected format is '%s'"),
    NOT_VALID_LONG_DATE_VALUE("The date value '%s' is not valid long value."),
    ERROR_WRITING_TO_TEMPLATE_JSON_FILE("Error writing to analytic template to a file."),
    ERROR_COPYING_FILE("Error copying file '%s' to '%s'. %s"),
    ERROR_DELETING_THE_DIRECTORY("Error deleting the directory '%s'. %s"),
    ERROR_SUBMITTING_THE_COMMAND("Error submitting the command '%s' to execute."),
    ERROR_WAITING_FOR_COMMAND_TO_FINISH("Error waiting for the command '%s' to finish. %s"),
    ERROR_EXECUTING_THE_COMMAND("Error executing the command '%s'. %s"),
    ERROR_READING_COMMAND_STREAM("Error reading the '%s' stream while executing the command '%s'."),
    CANNOT_CAST_INPUT_NULL("Cannot cast object to '%s' as the input object is null."),
    ERROR_CONVERTING_JSON_TO_NODE("Error converting the JSON into JsonNode. %s"),
    INVALID_JSON_PATH("The service instances JSON does not contain data for the property '%s'."),
    CANNOT_CAST_NOT_SUBCLASS("Cannot cast object of type '%s' to the type '%s as the input object is not an instance "
        + "of the type '%s'."),
    SERVER_UNAVAILABLE("The server '%s' is not available."),
    REQUEST_TIMED_OUT("The request to the resource '%s' timed-out."),
    INVALID_HTTP_METHOD_VALUE("Invalid HTTP method value '%s'"),
    INVALID_URL("Invalid url '%s'. %s"),
    ERROR_CREATING_URI("Error creating URI from parameters '%s'."),
    ERROR_RETRIEVING_MIME_PATH("Unable to retrieve mime type for the file '%s'. %s"),
    ERROR_WRITING_STREAM_TO_RESPONSE("Error writing data to the output response. '%s'"),
    INVALID_FILE_EXTENSION("Unsupported file '%s'. Only files with extension '%s' are supported"),
    ERROR_GETTING_BYTES_FROM_MULTIPART_FILE("Error retrieving data from the uploaded file '%s'. %s"),
    ERROR_INITIALIZING_ZIP_FILE("Error zip file '%s', %s"),
    ERROR_EXTRACTING_ZIP_FILE("Error extracting zip file '%s' %s"),
    INVALID_FILE_PATH("The file '%s' does not exist."),
    ERROR_READING_FILE_TO_STRING("Error reading file '%s' to string. %s"),
    CANNOT_FIND_FILE_WITH_EXT("Cannot find a file with extension '%s'. Available files are '%s'."),
    CANNOT_FIND_FILES_WITH_CRITERIA("Cannot find files for the filter(s) '%s' in the directory '%s'."),
    ERROR_CREATING_ZIP_FILE("Error creating the zip file."),
    ERROR_WRITING_BYTES_TO_FILE("Error writing bytes to the file '%s'. %s"),
    JSON_SUB_TYPE_ANNOTATION_IS_NOT_PRESENT("The JsonSubTypes annotation is not available on the class '%s'."),
    MORE_THAN_ONE_TYPE_FOR_JSON_SUB_TYPE("The class '%s' has more than one type values for JsonSubType annotation."),
    JSON_SUB_TYPE_CLASS_MISMATCH(
        "The class name '%s' and JsonSubTypes @Type class value '%s' given for this class does not match."),
    FIELD_NAME_DOES_NOT_EXIST_IN_JSON("The json '%s' does not contain the field '%s'."),
    NO_ENTRIES_FOR_ZIP_FILE_CREATION("Cannot create zip file '%s' file as the the input data has no content."),
    CONNECTION_TIMED_OUT("Unable to get connection to the resource '%s'.");

    private String message;

    UtilsErrorCodes(String s) {
        this.message = s;
    }

    @Override
    public String message() {
        return this.message;
    }
}
