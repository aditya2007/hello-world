/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.query.impl.pxasset;

import org.springframework.util.Assert;

import com.ge.apm.util.query.api.IFilterExpression;
import com.ge.apm.util.query.constants.QueryToken;

@SuppressWarnings("WeakerAccess")
public class PxBackwardRelateExpression extends RxRelateExpression {
    public PxBackwardRelateExpression(IFilterExpression operand1, String operand2, int depth) {
        super();
        Assert.notNull(operand1, "'operand1' must not be null");
        Assert.notNull(operand2, "'operand2' must not be null");
        append(depth > 1 ? QueryToken.OpenBracket : "");
        appendExpression(operand1);
        append(QueryToken.BackwardRelateSeparator);
        append(operand2);
        if (depth > 1) {
            append("[t" + depth + "]");
            append(QueryToken.CloseBracket);
        }
    }
}
