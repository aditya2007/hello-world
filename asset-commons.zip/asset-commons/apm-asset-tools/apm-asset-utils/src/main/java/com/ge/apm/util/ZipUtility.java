/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.validation.constraints.NotNull;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

import com.ge.apm.util.model.Artifact;

import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_CREATING_ZIP_FILE;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_EXTRACTING_ZIP_FILE;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_GETTING_BYTES_FROM_MULTIPART_FILE;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_INITIALIZING_ZIP_FILE;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.INVALID_FILE_EXTENSION;
import static com.ge.apm.util.exceptions.ExceptionHelper.getException;

public class ZipUtility {

    private static final Logger logger = LoggerFactory.getLogger(ZipUtility.class);

    public static Pair<String, List<File>> extractZipFile(String tmpDirectoryPrefix, MultipartFile zipFileArtifact) {
        final String methodName = "ZipUtility.extractZipFile";

        try {
            return extractZipFile(tmpDirectoryPrefix, zipFileArtifact.getOriginalFilename(),
                zipFileArtifact.getBytes());
        } catch (IOException ioException) {
            logger.error(ioException.getMessage(), ioException);
            throw getException(methodName, logger, ERROR_GETTING_BYTES_FROM_MULTIPART_FILE,
                zipFileArtifact.getOriginalFilename(), ioException.getMessage());
        }
    }

    public static Pair<String, List<File>> extractZipFile(String tmpDirectoryPrefix, String zipFilename,
        byte[] zipFileBytes) {

        final String methodName = "ZipUtility.extractZipFile";

        String zipExtension = "zip";
        if (!FilenameUtils.getExtension(zipFilename).equalsIgnoreCase(zipExtension)) {
            throw getException(methodName, logger, INVALID_FILE_EXTENSION, zipFilename, zipExtension);
        }

        File tmpFile;
        tmpFile = FileUtil.createTmpFileFromBytes(tmpDirectoryPrefix, zipFileBytes, zipFilename);

        return extractZipFile(tmpDirectoryPrefix, tmpFile.getAbsolutePath());
    }

    public static Pair<String, List<File>> extractZipFile(String tmpDirectoryPrefix, String zipFilepath) {

        final String methodName = "ZipUtility.extractZipFile";

        String zipFilename = FilenameUtils.getName(zipFilepath);

        String zipExtension = "zip";
        if (!FilenameUtils.getExtension(zipFilepath).equalsIgnoreCase(zipExtension)) {
            throw getException(methodName, logger, INVALID_FILE_EXTENSION, zipFilename, zipExtension);
        }

        ZipFile zipFile;
        try {
            zipFile = new ZipFile(zipFilepath);
        } catch (ZipException ioException) {
            logger.error(ioException.getMessage(), ioException);
            throw getException(methodName, logger, ERROR_INITIALIZING_ZIP_FILE, zipFilename, ioException.getMessage());
        }

        Path tmpDirectory = FileUtil.createTmpDirectory(tmpDirectoryPrefix);
        String extractDirectory = tmpDirectory.toString() + "/extractedFiles";
        FileUtil.createDirectory(extractDirectory);

        try {
            zipFile.extractAll(extractDirectory);
        } catch (ZipException ioException) {
            logger.error(ioException.getMessage(), ioException);
            throw getException(methodName, logger, ERROR_EXTRACTING_ZIP_FILE, zipFilename, ioException.getMessage());
        }

        extractDirectory = FilenameUtils.normalize(extractDirectory);
        Objects.requireNonNull(extractDirectory);
        //noinspection unchecked
        List<File> folderList = (List<File>) FileUtils.listFiles(new File(extractDirectory), null /*extensions*/,
            true /*recursive*/);

        return new MutablePair<>(FileUtil.appendTrailingSlash(extractDirectory), folderList);
    }

    @SuppressWarnings("WeakerAccess")
    @NotNull
    public static Artifact getZippedFile(String zipName, Map<String, String> entries) {
        String methodName = "getZippedFile";
        Artifact artifact = new Artifact();
        artifact.setFilename(zipName + ".zip");

        //@formatter:off
        try (
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(byteArrayOutputStream);
            ZipOutputStream zipOutputStream = new ZipOutputStream(bufferedOutputStream)
        ) {
            for (Map.Entry<String, String> entry : entries.entrySet()) {
                String filename = entry.getKey();
                zipOutputStream.putNextEntry(new ZipEntry(filename));
                try {
                    try (InputStream inputStream = new ByteArrayInputStream(entry.getValue().getBytes())) {
                        IOUtils.copy(inputStream, zipOutputStream);
                    }
                } finally {
                    try {
                        zipOutputStream.closeEntry();
                    } catch (Exception exception) { // NOSONAR
                        // ignore
                    }
                }
            }

            zipOutputStream.finish();
            zipOutputStream.flush();
            byte[] bytes = byteArrayOutputStream.toByteArray();
            artifact.setBytes(bytes);
            artifact.setContentLength(bytes != null ? bytes.length : 0);
            return artifact;
        } catch (IOException exception) {
            logger.error(exception.getMessage(), exception);
            throw getException(methodName, logger, ERROR_CREATING_ZIP_FILE);
        }
    }
    //@formatter:on
}
