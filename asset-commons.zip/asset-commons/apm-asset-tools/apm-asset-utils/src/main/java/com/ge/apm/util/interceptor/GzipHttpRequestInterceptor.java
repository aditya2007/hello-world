/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.interceptor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

public class GzipHttpRequestInterceptor implements ClientHttpRequestInterceptor {
    private static final String GZIP_CODEC = "gzip";

    private static final int MIN_SIZE = 2;

    private static final byte GZIP_SIGNATURE_BYTE1 = (byte) 0x1F;

    private static final byte GZIP_SIGNATURE_BYTE2 = (byte) 0x8B;

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
        throws IOException {
        if (request.getHeaders().containsKey(HttpHeaders.CONTENT_ENCODING)
            && request.getHeaders().get(HttpHeaders.CONTENT_ENCODING).contains(GZIP_CODEC)) {
            if (body != null && body.length >= MIN_SIZE
                && body[0] != GZIP_SIGNATURE_BYTE1
                && body[1] != GZIP_SIGNATURE_BYTE2) {
                ByteArrayOutputStream arrayStream = new ByteArrayOutputStream();
                OutputStream zippedStream = new GZIPOutputStream(arrayStream);
                zippedStream.write(body);
                zippedStream.close();
                body = arrayStream.toByteArray();
            }
        }
        return execution.execute(request, body);
    }
}
