/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudException;
import org.springframework.cloud.CloudFactory;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;

public class ApmAppInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {
    private static final Logger logger = LoggerFactory.getLogger(ApmAppInitializer.class);

    public ApmAppInitializer() {
    }

    @Override
    public void initialize(ConfigurableApplicationContext applicationContext) {
        Cloud cloud = this.getCloud();
        ConfigurableEnvironment appEnvironment = applicationContext.getEnvironment();
        if (cloud != null) {
            appEnvironment.setActiveProfiles(new String[] { "cloud" });
            System.setProperty("spring.profiles.active", "cloud");
            logger.info("Cloud profile active");
        } else {
            appEnvironment.setActiveProfiles(new String[] { "local" });
            System.setProperty("spring.profiles.active", "local");
            logger.info("Local profile active");
        }
    }

    private Cloud getCloud() {
        try {
            CloudFactory ce = new CloudFactory();
            return ce.getCloud();
        } catch (CloudException var2) { // NOSONAR
            return null;
        }
    }
}
