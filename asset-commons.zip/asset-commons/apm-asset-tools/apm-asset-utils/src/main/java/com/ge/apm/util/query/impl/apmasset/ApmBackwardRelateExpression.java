/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.query.impl.apmasset;

import org.springframework.util.Assert;

import com.ge.apm.util.query.api.IFilterExpression;
import com.ge.apm.util.query.constants.QueryToken;

@SuppressWarnings("WeakerAccess")
public class ApmBackwardRelateExpression extends ApmRelateExpression {
    public ApmBackwardRelateExpression(IFilterExpression operand1, String operand2, int depth) {
        super();
        Assert.notNull(operand1, "'operand1' must not be null");
        Assert.notNull(operand2, "'operand2' must not be null");
        append(operand2);
        //This is not required for new APM ASSET
        // if (depth > 1) {
        //     append("[t" + depth + "]");
        // }
        append(QueryToken.ApmBackwardRelateSeparator);
        appendExpression(operand1);

    }
}
