/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.ParseException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.config.RequestConfig.Builder;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.ge.apm.util.errorcodes.UtilsErrorCodes.PROXY_HOST_EMPTY;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.PROXY_PORT_EMPTY;

@SuppressWarnings({ "WeakerAccess", "unused" })
public class HttpHelpers {
    private static final Logger logger = LoggerFactory.getLogger(HttpHelpers.class);

    private static final int TIMEOUT_VALUE = 60000;

    private static final String ACCEPT_KEYWD = "Accept";

    @SuppressWarnings("unchecked")
    public static <T> T doPost(String url, Object inputObject) {
        return (T) doPost(url, inputObject, String.class);
    }

    @SuppressWarnings("unchecked")
    public static <T> T doPost(String url, Object inputObject, Class<T> objectType) {
        String methodName = "doPost";

        try (CloseableHttpClient httpClient = getHttpClient()) {
            HttpPost request = new HttpPost(url);
            request.setHeader(ACCEPT_KEYWD, "application/json");

            String jsonInput = JsonHelper.toJson(inputObject);

            // Set the request post body
            StringEntity userEntity;
            userEntity = new StringEntity(jsonInput);
            userEntity.setContentType("application/json");
            request.setEntity(userEntity);

            try (CloseableHttpResponse response = httpClient.execute(request)) {

                checkResponseStatus(methodName, url, response);

                HttpEntity httpEntity = response.getEntity();

                ObjectMapper mapper = new ObjectMapper();
                T retValue;
                if (objectType == String.class) {
                    retValue = (T) EntityUtils.toString(httpEntity);
                } else {
                    retValue = mapper.readValue(EntityUtils.toString(httpEntity), objectType);
                }

                EntityUtils.consume(httpEntity);

                return retValue;
            }
        } catch (IOException exception) {
            logger.error("{}| ", methodName, exception);
            throw new ServiceException("Error HTTP post request");
        }
    }

    private static void checkResponseStatus(String methodName, String url, HttpResponse response) {
        if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
            String errorMessage = String.format("%s| Error posting URL:%n%s%nError: %s::%s", methodName, url,
                response.getStatusLine().getStatusCode(), response.getStatusLine().getReasonPhrase());

            HttpEntity httpEntity = response.getEntity();

            logger.error("{}|{}\n", methodName, errorMessage);
            try {
                logger.error("{}", EntityUtils.toString(httpEntity));
            } catch (ParseException | IOException excp) {
                logger.error("{}| ", methodName, excp);
            }
            throw new ServiceException(errorMessage);
        }
    }

    public static CloseableHttpClient getHttpClient() {
        return getHttpClient(true, null);
    }

    public static CloseableHttpClient getHttpClient(boolean redirectEnabled, HttpHost proxy) {
        Builder builder = RequestConfig.custom().setSocketTimeout(TIMEOUT_VALUE).setConnectTimeout(TIMEOUT_VALUE)
            .setRedirectsEnabled(redirectEnabled);

        if (proxy != null) {
            builder.setProxy(proxy);
        }

        RequestConfig config = builder.build();
        return HttpClients.custom().setDefaultRequestConfig(config).setSSLSocketFactory(
            createBypassCertSslSocketFactory()).build();
    }

    private static SSLConnectionSocketFactory createBypassCertSslSocketFactory() {
        SSLContext sslContext;
        try {
            sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[] { createBypassCertTrustManager() }, new SecureRandom());
        } catch (KeyManagementException | NoSuchAlgorithmException exception) {
            logger.error(exception.getMessage(), exception);
            return null;
        }
        return new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);
    }

    private static X509TrustManager createBypassCertTrustManager() {
        return new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] cert, String string) throws CertificateException {
            }

            @Override
            public void checkServerTrusted(X509Certificate[] cert, String string) throws CertificateException {
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
        };
    }

    public static HttpHost getProxy(String useProxy, String proxyHost, int proxyPort) {
        String methodName = "getProxy";

        if (useProxy.equalsIgnoreCase("false")) {
            return null;
        }

        String envProxyHost = System.getProperty("https.proxyHost");

        if (StringUtils.hasText(envProxyHost)) {
            logger.info("@@@ Using proxy from environment variable https.proxyHost.");
            int envProxyPort = Integer.valueOf(System.getProperty("https.proxyPort"));
            return new HttpHost(envProxyHost, envProxyPort);
        } else if (StringUtils.hasText(useProxy) && useProxy.equalsIgnoreCase("true")) {
            logger.info("@@@ Using proxy from application properties.");
            if (!StringUtils.hasText(proxyHost)) {
                throw ExceptionHelper.getException(methodName, logger, PROXY_HOST_EMPTY);
            }

            if (proxyPort == -1) {
                throw ExceptionHelper.getException(methodName, logger, PROXY_PORT_EMPTY);
            }

            return new HttpHost(proxyHost, proxyPort);
        }

        logger.info("@@@ no proxy used.");
        return null;
    }

    @SuppressWarnings("unchecked")
    public static <T> T doGet(String url, Map<String, String> queryParams, Class<T> objectType) {
        String methodName = "doGet";

        boolean paramAdded = false;
        if (queryParams != null) {
            StringBuilder strQueryParams = new StringBuilder();

            for (Map.Entry<String, String> entry : queryParams.entrySet()) {
                if (!paramAdded) {
                    strQueryParams.append("?");
                    paramAdded = true;
                } else {
                    strQueryParams.append("&");
                }
                strQueryParams.append(entry.getKey()).append("=").append(entry.getValue());
            }

            url += strQueryParams.toString();
        }

        // System.out.println("URL: ");
        // System.out.println(url);
        // System.out.println("Get Request");

        try (CloseableHttpClient httpClient = getHttpClient()) {
            HttpGet request = new HttpGet(url);
            request.setHeader(ACCEPT_KEYWD, "application/json");

            HttpEntity httpEntity;
            try (CloseableHttpResponse response = httpClient.execute(request)) {
                checkResponseStatus(methodName, url, response);

                httpEntity = response.getEntity();

                ObjectMapper mapper = new ObjectMapper();
                T retValue;
                if (objectType == String.class) {
                    retValue = (T) EntityUtils.toString(httpEntity);
                } else {
                    retValue = mapper.readValue(EntityUtils.toString(httpEntity), objectType);
                }
                EntityUtils.consume(httpEntity);
                return retValue;
            }
        } catch (IOException exception) {
            logger.error("{}| ", methodName, exception);
            throw new ServiceException("Error HTTP get request");
        }
    }
}
