/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.dto;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public interface IDtoBase {

    Logger logger = LoggerFactory.getLogger(IDtoBase.class);

    String getName();

    void setName(String name);

    String getDescription();

    void setDescription(String description);

    String getUri();

    void setUri(String uri);

    Date getCreatedOn();

    void setCreatedOn(Date createdOn);

    Date getUpdatedOn();

    void setUpdatedOn(Date updatedOn);

    String getCreatedBy();

    void setCreatedBy(String createdBy);

    String getUpdatedBy();

    void setUpdatedBy(String updatedBy);
}
