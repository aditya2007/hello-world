/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.exceptions;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import org.springframework.http.HttpStatus;

import com.ge.apm.common.exception.DefaultErrorCode;
import com.ge.apm.common.exception.IErrorCode;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.util.JsonHelper;

@SuppressWarnings({ "WeakerAccess", "unused" })
@Getter
public class ServiceExceptionHttpStatus extends ServiceException {
    private HttpStatus httpStatus;

    public ServiceExceptionHttpStatus(IErrorCode code, HttpStatus httpStatus) {
        super(code);
        this.httpStatus = httpStatus;
    }

    public ServiceExceptionHttpStatus(IErrorCode code, Throwable cause, HttpStatus httpStatus) {
        super(code, cause);
        this.httpStatus = httpStatus;
    }

    public ServiceExceptionHttpStatus(ServiceException serviceException, HttpStatus httpStatus) {
        super(DefaultErrorCode.create(serviceException.getCode(), serviceException.getMessage()),
            serviceException.getCause());
        this.httpStatus = httpStatus;
    }

    @Override
    @JsonIgnore
    public String getFormattedMessage() {
        return JsonHelper.toJson(this, true /* prettyPrint */, false /* wrapRootValue */,
            true /* includeNotNullOnly */);
    }
}
