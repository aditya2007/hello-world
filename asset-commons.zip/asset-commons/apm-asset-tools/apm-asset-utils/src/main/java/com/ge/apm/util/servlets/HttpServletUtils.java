/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.servlets;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;

import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_CREATING_URI;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.INVALID_URL;

public class HttpServletUtils {

    public static HttpStatus getHttpStatus(String errorCode, HttpServletRequest request) {

        try {
            if (!StringUtils.isEmpty(errorCode)) {
                // check if we can get HttpStatus code from the service exception error code.
                return HttpStatus.valueOf(errorCode);
            }
        } catch (Exception ignored) { // NOSONAR
            // ignored
        }

        // if we cannot get it, then try to get http status from the servlet request.
        return getHttpStatus(request);
    }

    public static HttpStatus getHttpStatus(HttpServletRequest request) {

        HttpStatus defaultStatus = HttpStatus.BAD_REQUEST;
        if (request == null) {
            return defaultStatus;
        }

        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        if (statusCode == null) {
            return defaultStatus;
        }
        try {
            return HttpStatus.valueOf(statusCode);
        } catch (Exception exception) { // NOSONAR
            // ignored
        }
        return defaultStatus;
    }

    public static String getHttpMethod(String methodName, Logger logger, HttpServletRequest request) {
        try {
            return HttpMethod.valueOf(request.getMethod()).name();
        } catch (IllegalArgumentException illegalArgumentException) {
            if (logger != null) {
                logger.error("{} | ", methodName, illegalArgumentException);
            }
            return "UNKNOWN_HTTP_METHOD";
        }
    }

    public static String getRequestUrl(String methodName, Logger logger, HttpServletRequest request) {
        String requestUri;

        URL url;
        try {
            url = new URL(request.getRequestURL().toString());
        } catch (MalformedURLException exception) {
            throw ExceptionHelper.getException(methodName, logger, INVALID_URL, request.getRequestURL());
        }

        String host = url.getHost();
        String userInfo = url.getUserInfo();
        String scheme = "https";
        int port = url.getPort();

        requestUri = (String) request.getAttribute("javax.servlet.forward.request_uri");
        String query;
        // if cannot find path in the request attributes, then take from the request directly.
        if (StringUtils.isBlank(requestUri)) {
            requestUri = request.getRequestURI();
            query = request.getQueryString();
        } else {
            query = (String) request.getAttribute("javax.servlet.forward.query_string");
        }

        try {
            return new URI(scheme, userInfo, host, port, requestUri, query, null).toString();
        } catch (URISyntaxException exception) {
            String parameters =
                "scheme: " + scheme + " userInfo: " + userInfo + " host: " + host + " requestUri: " + requestUri
                    + " query: " + query;
            logger.error(exception.getMessage(), parameters, exception);
            throw ExceptionHelper.getException(methodName, logger, ERROR_CREATING_URI, parameters);
        }
    }

    public static String getRequestUri(HttpServletRequest request) {
        String requestUri = (String) request.getAttribute("javax.servlet.forward.request_uri");
        if (StringUtils.isBlank(requestUri)) {
            return request.getRequestURI();
        }

        return null;
    }

    public static String getUrlPath(String methodName, Logger logger, String strUrl) {
        URL url;
        try {
            url = new URL(strUrl);
        } catch (MalformedURLException exception) {
            throw ExceptionHelper.getException(methodName, logger, INVALID_URL, strUrl);
        }

        return url.getPath();

        //        public class ParseURL {
        //            public static void main(String[] args) throws Exception {
        //
        //                URL aURL = new URL("http://example.com:80/docs/books/tutorial"
        //                    + "/index.html?name=networking#DOWNLOADING");
        //
        //                System.out.println("protocol = " + aURL.getProtocol());
        //                System.out.println("authority = " + aURL.getAuthority());
        //                System.out.println("host = " + aURL.getHost());
        //                System.out.println("port = " + aURL.getPort());
        //                System.out.println("path = " + aURL.getPath());
        //                System.out.println("query = " + aURL.getQuery());
        //                System.out.println("filename = " + aURL.getFile());
        //                System.out.println("ref = " + aURL.getRef());
        //            }
        //        }
        //        Here is the output displayed by the program:
        //
        //        protocol = http
        //        authority = example.com:80
        //        host = example.com
        //        port = 80
        //        path = /docs/books/tutorial/index.html
        //        query = name=networking
        //        filename = /docs/books/tutorial/index.html?name=networking
        //        ref = DOWNLOADING
    }

    public static HttpServletRequest getServletRequest(WebRequest webRequest) {
        if ((webRequest instanceof ServletWebRequest)) {
            ServletWebRequest servletWebRequest = (ServletWebRequest) webRequest;
            return (HttpServletRequest) servletWebRequest.getNativeRequest();
        }

        return null;
    }
}
