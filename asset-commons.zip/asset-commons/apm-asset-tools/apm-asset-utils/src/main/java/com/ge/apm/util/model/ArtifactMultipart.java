/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.model;

import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
public class ArtifactMultipart extends Artifact {

    private MultipartFile multipartFile;

    public ArtifactMultipart() {
    }

    public ArtifactMultipart(MultipartFile file, Map<String, String> metaData) {
        setFilename(file.getOriginalFilename());
        setMetaData(metaData);
        setContentType(file.getContentType());
        setContentLength(file.getSize());
        multipartFile = file;
    }

    public ArtifactMultipart(String uri, MultipartFile file, Map<String, String> metaData) {
        this(file, metaData);
        setUri(uri);
    }
}
