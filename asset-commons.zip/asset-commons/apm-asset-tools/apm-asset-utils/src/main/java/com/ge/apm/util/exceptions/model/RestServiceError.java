/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.exceptions.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.ge.apm.common.model.ServiceError;
import com.ge.apm.util.JsonHelper;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RestServiceError {

    @Setter(AccessLevel.NONE)
    private Date timestamp = new Date();

    private String traceId;

    private String path;

    private List<ErrorInfo> errors;

    public RestServiceError() {

    }

    public RestServiceError(ServiceError serviceError) {
        this.timestamp = serviceError.getTimestamp();
        this.traceId = serviceError.getRequestId();
        this.path = serviceError.getPath();
        getErrors().add(
            new ErrorInfo(null /* httpStatusCode */, serviceError.getErrorId(), serviceError.getErrorMessage(), "" /*
             detail */, "" /* requestId */));
    }

    public RestServiceError(List<ErrorInfo> errors) {
        this.errors = errors;
    }

    public List<ErrorInfo> getErrors() {
        if (errors == null) {
            errors = new ArrayList<>();
        }

        return errors;
    }

    @JsonIgnore
    public String getFormattedMessage() {
        return JsonHelper.toJson(this, true /* prettyPrint */, false /* wrapRootValue */,
            true /* includeNotNullOnly */);
    }

    @SuppressWarnings("unused")
    public void addError(ErrorInfo errorInfo) {
        getErrors().add(errorInfo);
    }

    @SuppressWarnings("WeakerAccess")
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ErrorInfo {

        private String httpStatusCode;

        private String code;

        private String message;

        private String detail;

        private String requestId;

        public ErrorInfo(String code, String message) {
            this.httpStatusCode = code;
            this.code = code;
            this.message = message;
        }

        public ErrorInfo(String code, String httpStatusCode, String message) {
            this.httpStatusCode = httpStatusCode;
            this.code = code;
            this.message = message;
        }

        @JsonIgnore
        public String getFormattedMessage() {
            return JsonHelper.toJson(this, true /* prettyPrint */, false /* wrapRootValue */, true
                /* includeNotNullOnly */);
        }
    }
}
