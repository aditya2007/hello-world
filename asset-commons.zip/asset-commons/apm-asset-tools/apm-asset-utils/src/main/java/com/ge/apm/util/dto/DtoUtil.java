/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.dto;

import java.util.UUID;

import com.ge.apm.common.util.DateTimeUtil;

public class DtoUtil {

    private DtoUtil() {

    }

    public static <T extends IDtoBase> T initializeDtoForCreate(String prefix, T dto) {
        return initializeDtoForCreate(prefix, dto, true /*initUri*/);
    }

    public static <T extends IDtoBase> T initializeDtoForCreate(String prefix, T dto, boolean initUri) {
        dto.setCreatedOn(DateTimeUtil.newDate());
        dto.setUpdatedOn(DateTimeUtil.newDate());

        if (initUri) {
            dto.setUri(prefix + "/" + UUID.randomUUID().toString());
        }

        //capture User information from the token to update CreatedBy and UpdatedBy?
        return dto;
    }

    public static <T extends IDtoBase> T initializeDtoForUpdate(T dto) {
        dto.setUpdatedOn(DateTimeUtil.newDate());
        return dto;
    }

    public static String getUuid(String uri) {
        return uri.substring(uri.lastIndexOf("/") + 1, uri.length());
    }
}
