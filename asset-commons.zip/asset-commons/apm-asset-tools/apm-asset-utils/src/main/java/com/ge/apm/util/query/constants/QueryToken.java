/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.query.constants;

public abstract class QueryToken {

    public static final String OpenBracket = "(";

    public static final String CloseBracket = ")";

    public static final String AndSeparator = ":";

    public static final String OrSeparator = "|";

    public static final String NameValueSeparator = "=";

    public static final String BackwardRelateSeparator = "<";

    public static final String ApmBackwardRelateSeparator = "->";

    public static final String ApmForwardRelateSeparator = "<-";

    public static final String ForwardRelateSeparator = ">";

    public static final String WildPrefix = "/*";

    public static final String WildSuffix = "*/";

    public static final String ParentSeparator = "->";

    private QueryToken() {
    }
}
