/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.ge.apm.util.ShellCommand.StreamType.STREAM_TYPE_ERR;
import static com.ge.apm.util.ShellCommand.StreamType.STREAM_TYPE_OUT;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_EXECUTING_THE_COMMAND;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_READING_COMMAND_STREAM;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_SUBMITTING_THE_COMMAND;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_WAITING_FOR_COMMAND_TO_FINISH;

@SuppressWarnings({ "WeakerAccess", "unused" })
@Getter
public class ShellCommand {
    private static final Logger logger = LoggerFactory.getLogger(ShellCommand.class);

    public String outLog;

    public String errLog;

    public void execute(String commandName, String command, String workingDirectory) {
        String methodName = "ShellCommand.execute";

        logger.info("Executing the command '{}': '{}'", commandName, command);
        Runtime runtime = Runtime.getRuntime();
        Process process;
        try {
            process = runtime.exec(command, null, new File(workingDirectory));
        } catch (IOException exception) {
            logger.error("", exception);
            throw ExceptionHelper.getException(methodName, logger, ERROR_SUBMITTING_THE_COMMAND, commandName);
        }

        StreamCapture errorStreamCapture = new StreamCapture(commandName, process.getErrorStream(), STREAM_TYPE_ERR);
        StreamCapture outputStreamCapture = new StreamCapture(commandName, process.getInputStream(), STREAM_TYPE_OUT);

        errorStreamCapture.start();
        outputStreamCapture.start();

        int exitVal;
        try {
            exitVal = process.waitFor();
        } catch (InterruptedException exception) { // NOSONAR
            throw ExceptionHelper.getException(methodName, logger, ERROR_WAITING_FOR_COMMAND_TO_FINISH, commandName,
                exception.getMessage());
        }

        outLog = outputStreamCapture.getCapturedStream().toString();
        errLog = errorStreamCapture.getCapturedStream().toString();

        if (exitVal != 0) {
            throw ExceptionHelper.getException(methodName, logger, ERROR_EXECUTING_THE_COMMAND, commandName, errLog);
        }
    }

    public enum StreamType {
        STREAM_TYPE_OUT,
        STREAM_TYPE_ERR
    }

    @Getter
    private static class StreamCapture extends Thread {
        private InputStream inputStream;

        private StreamType streamType;

        private String commandName;

        private ServiceException serviceException;

        @SuppressWarnings("MismatchedQueryAndUpdateOfStringBuilder")
        private StringBuilder capturedStream = new StringBuilder();

        StreamCapture(String commandName, InputStream inputStream, StreamType streamType) {
            this.commandName = commandName;
            this.inputStream = inputStream;
            this.streamType = streamType;
        }

        @Override
        public void run() {
            String methodName = "StreamCapture.run";
            try {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    capturedStream.append(line);
                    if (streamType == STREAM_TYPE_ERR) {
                        logger.error(line);
                    } else {
                        logger.info(line);
                    }
                }
            } catch (IOException exception) {
                logger.error(exception.getMessage(), exception);
                serviceException = ExceptionHelper.getException(methodName, logger, ERROR_READING_COMMAND_STREAM,
                    streamType.name(), commandName);
            }
        }
    }
}
