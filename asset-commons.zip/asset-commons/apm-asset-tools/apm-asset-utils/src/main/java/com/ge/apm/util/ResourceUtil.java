/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.Objects;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.apm.common.exception.ServiceException;

@SuppressWarnings({ "Duplicates", "WeakerAccess", "unused" })
public class ResourceUtil {

    protected static Logger logger = LoggerFactory.getLogger(ResourceUtil.class);

    public static String getResourceDirAbsolutePath(String resourceDir) {
        URL resource = ResourceUtil.class.getClassLoader().getResource(resourceDir);
        if (resource == null) {
            String errorMessage = String.format("Cannot get URL for the resource directory '%s'", resourceDir);
            logger.error("{}", errorMessage);
            throw new ServiceException(errorMessage);
        }
        File directory;
        try {
            directory = Paths.get(resource.toURI()).toFile();
        } catch (URISyntaxException e) {
            String errorMessage = String.format("Error getting the File Object for dir '%s''.%n%s", resourceDir,
                e.getMessage());
            logger.error("{}", errorMessage, e);
            throw new ServiceException(errorMessage);
        }

        return directory.getAbsolutePath() + "/";
    }

    public static <T> void writeToResourceFileAbsolutePath(String absolutePath, String fileName,
        Class<T> inputDataClass, Object data) {
        String filePath = absolutePath + fileName;
        logger.info("Writing file to cache: '{}'", filePath);
        try {
            File file = new File(new File(filePath).toURI());
            if (inputDataClass == String.class) {
                FileUtils.writeStringToFile(file, (String) data);
            } else if (inputDataClass == byte.class) {
                Files.write(Paths.get(new File(filePath).toURI()), (byte[]) data);
            } else {
                String errorMessage = String.format("Cannot write the resource file '%s' to the directory '%s' "
                    + "because the class type '%s' is not handled.", fileName, absolutePath, inputDataClass.getName());
                logger.error("{}", errorMessage);
                throw new ServiceException(errorMessage);
            }
        } catch (IOException e) {
            String errorMessage = String.format("Error creating the file '%s'. %s", filePath, e.getMessage());
            logger.error("{}", errorMessage, e);
            throw new ServiceException(errorMessage);
        }
    }

    public static boolean isJarResourceFileExists(String resourceDir, String fileName) {
        String directory = getResourceDirAbsolutePath(resourceDir);
        File file = new File(directory + fileName);
        return file.exists();
    }

    /**
     * Read from a file and return the contents as String. The file should exist in the jar resource directory.
     * @param fileName file path relative to resource directory. If the file path is
     *                 src/main/resources/dir1/dir2/file1.txt or src/test/resources/dir1/dir2/file1.txt, the input
     *                 should be /dir1/dir2/file1.txt
     * @return file contents as string.
     */
    public static String readFromJarResourceFileAsString(String fileName) {
        byte[] bytes = readFromJarResourceFileAsBytes(fileName);

        try {
            return new String(bytes, "UTF-8");
        } catch (UnsupportedEncodingException excp) {
            String errorMessage =
                "Cannot convert config json byte array into string. " + System.lineSeparator() + excp.getMessage();
            logger.error("{}", errorMessage);
            logger.error("", excp);
            throw new ServiceException(errorMessage);
        }
    }

    /**
     * Read from a file and return the contents as bytes. The file should exist in the jar resource directory.
     * @param fileName file path relative to resource directory. If the file path is
     *                 src/main/resources/dir1/dir2/file1.txt or src/test/resources/dir1/dir2/file1.txt, the input
     *                 should be /dir1/dir2/file1.txt
     * @return file contents as bytes.
     */
    public static byte[] readFromJarResourceFileAsBytes(String fileName) {
        String methodName = "readFromJarResourceFileAsBytes";
        logger.info("Reading resource file: '{}'", fileName);

        // input stream included with try to avoid the resource leak.
        try (InputStream inputStream = ResourceUtil.class.getResourceAsStream(fileName)) {
            if (inputStream != null) {
                return IOUtils.toByteArray(inputStream);
            }
        } catch (IOException excp) {
            String errorMessage = String.format("Error reading the resource '%s'.", fileName);
            logger.error("{}| {}", methodName, errorMessage);
            logger.error("", excp);
            throw new ServiceException(errorMessage + "  " + System.lineSeparator() + "  " + excp.getMessage());
        }

        return readResourceFileAlternate(fileName);
    }

    public static byte[] readFromJarResourceFileAsBytes(Class<?> clazz, String fileName) {
        String methodName = "readFromJarResourceFileAsBytes";
        logger.info("Reading resource file: '{}'", fileName);

        // input stream creation included with try to avoid the resource leak.
        try (InputStream inputStream = clazz.getResourceAsStream(fileName)) {
            if (inputStream != null) {
                return IOUtils.toByteArray(inputStream);
            }
        } catch (IOException excp) {
            String errorMessage = String.format("Error reading the resource '%s'.", fileName);
            logger.error("{}| {}", methodName, errorMessage);
            logger.error("", excp);
            throw new ServiceException(errorMessage + "  " + System.lineSeparator() + "  " + excp.getMessage());
        }

        return readResourceFileAlternate(clazz, fileName);
    }

    /**
     * Read from a file whose content is JSON text, convert the JSON into an object of the given targetType. The file
     * should exist in the jar resource directory.
     * @param fileName file path relative to resource directory. If the file path is
     *                 src/main/resources/dir1/dir2/file1.txt or src/test/resources/dir1/dir2/file1.txt, the input
     *                 should be /dir1/dir2/file1.txt
     * @return object instance of the given target type.
     */
    public static <T> T readFromJarResourceJsonFile(String fileName, Class<T> targetType) {
        String json = ResourceUtil.readFromJarResourceFileAsString(fileName);
        return JsonHelper.fromJson(json, targetType);
    }

    /**
     * Read from a file whose content is JSON text, convert the JSON into an object of the given targetType. The file
     * should exist in the jar resource directory.
     * @param absoluteFilePath absolute file path
     * @param targetType target class type
     * @return object instance of the given target type.
     */
    public static <T> T readFromAbsolutePathJsonFile(String absoluteFilePath, Class<T> targetType) {
        return JsonHelper.fromJson(readAbsolutePathFileAsString(absoluteFilePath), targetType);
    }

    /**
     * Read from a file and return the contents as String.
     * @param absoluteFilePath absolute file path
     * @return file contents as string.
     */
    public static String readAbsolutePathFileAsString(String absoluteFilePath) {
        File file = new File(absoluteFilePath);

        if (!file.exists()) {
            String errorMessage = MessageFormat.format("Invalid file ''{0}''", file.getAbsolutePath());
            logger.error(errorMessage);
            throw new ServiceException(errorMessage);
        }

        try {
            return FileUtils.readFileToString(file);
        } catch (IOException e) {
            String errorMessage = MessageFormat.format("Error loading file ''{0}''. Error: ''{1}''",
                file.getAbsolutePath(), e.getMessage());
            logger.error(errorMessage);
            logger.error("", e);

            throw new ServiceException(errorMessage);
        }
    }

    /**
     * Read from a file and return the contents as String.
     * @param absoluteFilePath absolute file path
     * @return file contents as byte array.
     */
    public static byte[] readAbsolutePathFileAsByte(String absoluteFilePath) {
        File file = new File(absoluteFilePath);

        if (!file.exists()) {
            String errorMessage = MessageFormat.format("Invalid file ''{0}''", file.getAbsolutePath());
            logger.error(errorMessage);
            throw new ServiceException(errorMessage);
        }

        try {
            return Files.readAllBytes(file.toPath());
        } catch (IOException e) {
            String errorMessage = MessageFormat.format("Error loading file ''{0}''. Error: ''{1}''",
                file.getAbsolutePath(), e.getMessage());
            logger.error(errorMessage);
            logger.error("", e);

            throw new ServiceException(errorMessage);
        }
    }

    public static <T> T readFromRelativeToModuleDirJsonFile(String filePathRelativeToUserDir, Class<T> targetType) {
        return JsonHelper.fromJson(readFromRelativeToModuleDirFileAsString(filePathRelativeToUserDir), targetType);
    }

    public static String readFromRelativeToModuleDirFileAsString(String filePathRelativeToUserDir) {
        // user directory is the directory of the artifact that is currently executing.
        String workingDir = System.getProperty("user.dir");
        workingDir += "/";

        return readAbsolutePathFileAsString(workingDir + filePathRelativeToUserDir);
    }

    private static byte[] readResourceFileAlternate(String fileName) {
        String methodName = "readResourceFileAlternate";
        URL resourceUrl = ResourceUtil.class.getClassLoader().getResource(fileName);
        if (resourceUrl == null) {
            String errorMessage = String.format("Unknown error. Cannot find the resource file '%s'", fileName);
            logger.error("{}| {}", methodName, errorMessage);
            throw new ServiceException(errorMessage);
        }
        File file = new File(resourceUrl.getFile());

        try {
            return Files.readAllBytes(file.toPath());
        } catch (IOException excp) {
            String errorMessage = String.format("Error reading the resource '%s'.", fileName);
            logger.error("{}| {}", methodName, errorMessage);
            logger.error("", excp);
            throw new ServiceException(errorMessage + "  " + System.lineSeparator() + "  " + excp.getMessage());
        }
    }

    private static byte[] readResourceFileAlternate(Class<?> clazz, String fileName) {
        String methodName = "readResourceFileAlternate";
        URL resourceUrl = clazz.getClassLoader().getResource(fileName);
        if (resourceUrl == null) {
            String errorMessage = String.format("Unknown error. Cannot find the resource file '%s'", fileName);
            logger.error("{}| {}", methodName, errorMessage);
            throw new ServiceException(errorMessage);
        }
        File file = new File(resourceUrl.getFile());

        try {
            return Files.readAllBytes(file.toPath());
        } catch (IOException excp) {
            String errorMessage = String.format("Error reading the resource '%s'.", fileName);
            logger.error("{}| {}", methodName, errorMessage);
            logger.error("", excp);
            throw new ServiceException(errorMessage + "  " + System.lineSeparator() + "  " + excp.getMessage());
        }
    }

    public static <T> File getJarDir(Class<T> aclass) {
        URL url;

        // get an url
        try {
            url = aclass.getProtectionDomain().getCodeSource().getLocation();
            // url is in one of two forms
            // ./build/classes/
            // jardir/JarName.jar from a jar

            // If we are executing a unit test using command mvn, then the path will be following:
            //  (1) If the input aClass is a class from test package, then the url will be
            //          /<path>/target/test-classes
            //  (2) If the input aClass is a class from main package, then the url will be
            //          /<path>/target/classes
            //  (3) If the input aClass is a class from a jar that is different from the jar that this ResourceUtil
            //      class exists, then the the path will be different based on the condition that the aClass jar
            //      source code is opened in IntelliJ/Eclipse or not
            //          if the project is opened in the IDE, then the url path will be
            //              file:/<path-of-aclass-jar>/target/classes/
            //          if the project is not opened in the IDE, then the url path will be
            //              file:/path/.m2/repository/path/apm-rest-2.5.0-SNAPSHOT.jar
            //
            // if we came into this method when the code has been executed as java -jar <jar-file-path>, then
            //  (1) if the aClass is in the same jar file that is being executed or in a different jar the path is
            //          file:/path/target/file.jar
            //
            // When running as a spring-boot-app, then this will give the path as follows:
            //   (1) if the aClass is in dependent jar file, then the path will be
            //          'jar:file:/path/apm-env-var-app-2.5.0-SNAPSHOT.jar!/lib/dependent.jar!/
            //   (2) if the aClass is in the same jar that is used to run as spring boot app, then the path is
            //           'jar:file:/path/apm-env-var-app-2.5.0-SNAPSHOT.jar!/

        } catch (SecurityException ex) { // NOSONAR
            url = aclass.getResource(aclass.getSimpleName() + ".class");
            // url is in one of two forms, both ending "/com/physpics/tools/ui/PropNode.class"
            // file:/U:/Fred/java/Tools/UI/build/classes
            // jar:file:/U:/Fred/java/Tools/UI/dist/UI.jar!
        }

        // convert to external form
        String externalForm = url.toExternalForm();
        String path = getFilePathFromResourceFilePath(externalForm, aclass);
        Objects.requireNonNull(path);
        return new File(path);
    }

    public static <T> String getFilePathFromResourceFilePath(String resourceFilePathInput, Class<T> aclass) {
        String methodName = "getFilePath";

        String resourceFilePath = resourceFilePathInput;
        logger.info("Actual path: '{}", resourceFilePath);

        // if the external form has the following values:
        //      /Users/path/target/test-classes/
        //      /Users/path/target/classes/
        //
        // then it implies that this method is being called while executing artifact in IDE.
        // In this situation, we need to remove the string after target dir.
        if (resourceFilePath.endsWith("classes/")) {
            // remove the last slash i.e. the variable will be initialized with value:
            //          /Users/path/target/test-classes
            resourceFilePath = resourceFilePath.substring(0, resourceFilePath.length() - 1);
            // now remove everything after the last slash.
            resourceFilePath = resourceFilePath.substring(0, resourceFilePath.lastIndexOf("/"));
        }

        resourceFilePath = resourceFilePath.replace("file:", "");

        resourceFilePath = resourceFilePath.replace("jar:", "");
        logger.info("jar path1: '{}", resourceFilePath);

        if (resourceFilePath.contains("!")) {
            // the path could be one of the following:
            // jar:/Users/path/dir2/target/abc.jar!/filename.ext
            // jar:/Users/path/dir2/target/abc.jar!/
            // jar:file:/Users/path/dir2/target/abc.jar!/
            // jar:file:/Users/path/dir2/target/abc.jar!/lib/util-2.5.0-SNAPSHOT.jar!/
            resourceFilePath = resourceFilePath.substring(0, resourceFilePath.indexOf("!"));
        }

        if (resourceFilePath.endsWith(".jar")) {
            // at this point extUrl will be
            //      /Users/path/dir2/target/abc.jar
            // removing abc.jar
            //  we want to return just the path.
            return FilenameUtils.getFullPathNoEndSeparator(resourceFilePath);
        } else { // from getResource
            String suffix = "/" + (aclass.getName()).replace(".", "/") + ".class";
            resourceFilePath = resourceFilePath.replace(suffix, "");
        }

        File resourceFile = new File(resourceFilePath);

        if (!resourceFile.exists()) {
            String errorMessage = MessageFormat.format(
                "Converting resource path {0} to a normal path resulted in an invalid path {1}.",
                resourceFilePathInput, resourceFilePath);
        }

        if (resourceFile.isFile()) {
            return "/" + FilenameUtils.getPath(resourceFilePath);
        } else {
            return resourceFilePath;
        }
    }

    //    public static <T> File getJarDir(Class<T> aclass) {
    //        URL url;
    //
    //        // get an url
    //        try {
    //            url = aclass.getProtectionDomain().getCodeSource().getLocation();
    //            // url is in one of two forms
    //            // ./build/classes/ NetBeans test
    //            // jardir/JarName.jar froma jar
    //        } catch (SecurityException ex) {
    //            url = aclass.getResource(aclass.getSimpleName() + ".class");
    //            // url is in one of two forms, both ending "/com/physpics/tools/ui/PropNode.class"
    //            // file:/U:/Fred/java/Tools/UI/build/classes
    //            // jar:file:/U:/Fred/java/Tools/UI/dist/UI.jar!
    //        }
    //
    //        // convert to external form
    //        String externalForm = url.toExternalForm();
    //        logger.error("externalForm: '{}'", externalForm);
    //
    //        // handle the case of
    //        // file:/dir/artifact-tests.jar
    //        externalForm = externalForm.replace("file:", "");
    //        logger.info("jar path1: '{}", externalForm);
    //
    //        // handle the case of
    //        // jar:/dir/artifact-tests.jar
    //        externalForm = externalForm.replace("file:", "");
    //        logger.info("jar path1: '{}", externalForm);
    //
    //        // prune for various cases
    //        // from getCodeSource
    //        if (externalForm.endsWith(".jar!/")) {
    //            // the path could be one of the following:
    //            // jar:/Users/path/dir2/target/abc.jar!/
    //            // jar:file:/Users/path/dir2/target/abc.jar!/
    //            // jar:file:/Users/path/dir2/target/abc.jar!/lib/util-2.5.0-SNAPSHOT.jar!/
    //            externalForm = externalForm.replace("jar:", "");
    //            externalForm = externalForm.replace("file:", "");
    //            externalForm = externalForm.substring(0, externalForm.indexOf("!"));
    //            // at this point extUrl will be
    //            //      /Users/path/dir2/target/abc.jar
    //            // removing abc.jar
    //            //  we want to return just the path.
    //            return new File(FilenameUtils.getFullPathNoEndSeparator(externalForm));
    //        } else if (externalForm.endsWith(".jar")) {
    //            return new File(FilenameUtils.getFullPathNoEndSeparator(externalForm));
    //        }
    //
    //        // convert back to url
    //        try {
    //            url = new URL(externalForm);
    //        } catch (MalformedURLException mux) {
    //            // leave url unchanged; probably does not happen
    //        }
    //
    //        // convert url to File
    //        try {
    //            return new File(url.toURI());
    //        } catch (URISyntaxException ex) {
    //            return new File(url.getPath());
    //        }
    //    }
}
