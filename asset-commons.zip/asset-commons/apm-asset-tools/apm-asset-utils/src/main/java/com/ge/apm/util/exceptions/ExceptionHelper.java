/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.exceptions;

import java.io.PrintWriter;
import java.io.StringWriter;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.springframework.http.HttpStatus;

import com.ge.apm.common.exception.DefaultErrorCode;
import com.ge.apm.common.exception.IErrorCode;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.util.ClassCastUtil;

import static com.ge.apm.common.support.RequestContext.HTTP_SERVLET_REQUEST;
import static com.ge.apm.util.servlets.HttpServletUtils.getHttpMethod;
import static com.ge.apm.util.servlets.HttpServletUtils.getHttpStatus;
import static com.ge.apm.util.servlets.HttpServletUtils.getRequestUrl;

public class ExceptionHelper {

    public static ServiceException getException(String methodName, Logger logger, String message, Object... arguments) {
        String errorMessage = getMessageUsingArguments(message, arguments);
        ServiceException serviceException = new ServiceException(errorMessage);
        logException(methodName, logger, serviceException);
        return serviceException;
    }

    public static ServiceException getException(String methodName, Logger logger, IErrorCode errorCode,
        Object... arguments) {
        return getException(methodName, logger, null /*exception*/, null /*httpStatus*/, errorCode, arguments);
    }

    public static ServiceException getException(String methodName, Logger logger, HttpStatus httpStatus,
        IErrorCode errorCode, Object... arguments) {
        return getException(methodName, logger, null /*exception*/, httpStatus, errorCode, arguments);
    }

    public static ServiceException getException(String methodName, Logger logger, Exception exception) {
        return getException(methodName, logger, exception, "" /*inputErrorMessage*/);
    }

    public static ServiceException getException(String methodName, Logger logger, Exception exception,
        String inputErrorMessage, Object... arguments) {

        String errorMessage;
        if (!StringUtils.isEmpty(inputErrorMessage)) {
            errorMessage = getMessageUsingArguments(inputErrorMessage, arguments);
        } else if (exception instanceof ServiceException) {
            ServiceException serviceException = (ServiceException) exception;
            logException(methodName, logger, serviceException);
            return serviceException;
        } else {
            errorMessage = getMessageUsingArguments(getRootCauseMessage(exception));
        }

        String errorCode = "";
        return getServiceException(methodName, logger, exception, errorMessage, null /*httpStatus*/, errorCode);
    }

    public static ServiceException getException(String methodName, Logger logger, Exception exception,
        IErrorCode errorCode, Object... arguments) {
        return getException(methodName, logger, exception, null /*httpStatus*/, errorCode, arguments);
    }

    public static ServiceException getException(String methodName, Logger logger, Exception exception,
        HttpStatus httpStatus, IErrorCode errorCode, Object... arguments) {

        String errorMessage = getMessageUsingArguments(errorCode.message(), arguments);

        return getServiceException(methodName, logger, exception, errorMessage, httpStatus, errorCode.name());
    }

    private static ServiceException getServiceException(String methodName, Logger logger, Exception exception,
        String errorMessage, HttpStatus httpStatus, String errorCode) {

        if (httpStatus == null) {
            httpStatus = getHttpStatus(errorCode, (HttpServletRequest) RequestContext.get(HTTP_SERVLET_REQUEST));
        }

        ServiceException serviceException = new ServiceExceptionHttpStatus(
            DefaultErrorCode.create(errorCode, escapeForStringFormat(errorMessage)), httpStatus);

        logException(methodName, logger, exception, serviceException);

        return serviceException;
    }

    public static String escapeForStringFormat(String argument) {
        if (StringUtils.isBlank(argument)) {
            return argument;
        }
        if (argument.contains("%")) {
            // escaping all % symbols to avoid error when ServiceException is using String.format(). If the
            // message values contain % then it will be treated as message format specifier and complains
            // missing format specifier argument.
            return argument.replace("%", "%%");
        }
        return argument;
    }

    private static String getMessageUsingArguments(String message, Object... arguments) {
        for (int idx = 0; idx < arguments.length; idx++) {
            if (arguments[idx] instanceof String) {
                String argument = (String) arguments[idx];
                arguments[idx] = escapeForStringFormat(argument);
            }
        }

        return String.format(message, arguments);
    }

    public static String getStackTrace(Exception exception) {
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        exception.printStackTrace(printWriter);
        return stringWriter.toString();
    }

    // public static HttpStatus getHttpStatus(String strHttpStatus) {
    //
    //     if (StringUtils.isEmpty(strHttpStatus)) {
    //         return HttpStatus.BAD_REQUEST;
    //     }
    //
    //     try {
    //         return HttpStatus.valueOf(strHttpStatus);
    //     } catch (IllegalArgumentException illegalArgumentException) {
    //         return HttpStatus.BAD_REQUEST;
    //     }
    // }

    @SuppressWarnings("WeakerAccess")
    public static void logException(String methodName, Logger logger, ServiceException serviceException) {
        logException(methodName, logger, null /* exception */, serviceException);
    }

    public static synchronized void logException(String methodName, Logger logger, Exception exception,
        ServiceException serviceException) {

        if (serviceException.isExceptionLogged() || logger == null) {
            return;
        }

        HttpServletRequest httpServletRequest = (HttpServletRequest) RequestContext.get(HTTP_SERVLET_REQUEST);

        String requestHttpMethod = null;
        String requestUrl = null;

        if (httpServletRequest != null) {
            requestHttpMethod = getHttpMethod(methodName, logger, httpServletRequest);
            requestUrl = getRequestUrl(methodName, logger, httpServletRequest);
        }

        String httpStatus;
        if (exception instanceof ServiceExceptionHttpStatus) {
            httpStatus = ((ServiceExceptionHttpStatus) exception).getHttpStatus().name();
        } else {
            httpStatus = getHttpStatus(httpServletRequest).name();
        }

        logException(methodName, logger, requestHttpMethod, requestUrl, httpStatus, exception, serviceException);
    }

    public static void logException(String methodName, Logger logger, String requestHttpMethod, String requestUrl,
        String httpStatus, Exception exception, ServiceException serviceException) {

        if (serviceException.isExceptionLogged() || (exception instanceof ServiceException
            && ((ServiceException) exception).isExceptionLogged()) || logger == null) {
            return;
        }

        String messagePrefix = "";
        if (!StringUtils.isEmpty(requestHttpMethod)) {
            logger.error("\nService Request:\n[{}] URL: '{}', Error_HttpStatus: '{}' \n", requestHttpMethod, requestUrl,
                httpStatus);
            messagePrefix = "\nError for above service request:";
        }

        if (exception != null && !(exception instanceof ServiceException)) {
            logger.error("{}, {}", messagePrefix, exception.getMessage(), exception);
        } else {
            logger.error("\n{} | {} {}", messagePrefix, methodName, serviceException.getFormattedMessage(), exception);
            StringWriter stringWriter = new StringWriter();
            serviceException.printStackTrace(new PrintWriter(stringWriter));
            logger.error("{}", stringWriter.toString());
        }

        serviceException.setExceptionLogged(true);
    }

    public static String getRootCauseMessage(Exception exception) {

        if (exception instanceof NullPointerException) {
            return "Null Pointer exception.";
        }

        Throwable rootCause = ExceptionUtils.getRootCause(exception);
        if (rootCause != null) {
            return rootCause.getMessage();
        } else {
            return exception.getMessage();
        }
    }

    public static Throwable getRootCause(Exception exception) {

        Throwable rootCause = ExceptionUtils.getRootCause(exception);
        if (rootCause != null) {
            return rootCause;
        } else {
            return exception;
        }
    }

    public static void handleContinueOnErrorExceptions(Logger logger, IErrorCode errorCode, boolean continueOnError,
        ServiceExceptionMulti serviceExceptionMulti, Exception exceptionThatHappened) {

        if (serviceExceptionMulti == null) {
            serviceExceptionMulti = new ServiceExceptionMulti(errorCode, null);
        }

        if (exceptionThatHappened instanceof ServiceException) {
            if (continueOnError) {
                serviceExceptionMulti.addException(ClassCastUtil.cast(exceptionThatHappened, ServiceException.class));
            } else if (!(exceptionThatHappened instanceof RestServiceErrorException)
                || ((RestServiceErrorException) exceptionThatHappened).getHttpStatus() != HttpStatus.NOT_FOUND) {
                throw (ServiceException) exceptionThatHappened;
            }
            return;
        }

        logger.error("", exceptionThatHappened);
        ServiceException serviceException = new ServiceException(errorCode);

        if (continueOnError) {
            serviceExceptionMulti.addException(serviceException);
        } else {
            throw serviceException;
        }
    }

}
