/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.query.impl.apmasset;

import org.springframework.util.Assert;

import com.ge.apm.util.query.api.IFilterExpression;
import com.ge.apm.util.query.api.IFilterOperand;
import com.ge.apm.util.query.constants.QueryToken;

import static com.ge.apm.util.query.impl.pxasset.PxFilterExpression.Uri;

@SuppressWarnings("WeakerAccess")
public final class ApmFilterOperand implements IFilterOperand {

    private final String attribute;

    public ApmFilterOperand(String attribute) {
        Assert.notNull(attribute, "'attribute' must not be null");
        Assert.hasLength(attribute.trim(), "'attribute' must not be empty or whitespace");
        this.attribute = attribute.trim();
    }

    public static IFilterOperand uri() {
        return new ApmFilterOperand(Uri);
    }

    public static IFilterOperand attribute(String attribute) {
        return new ApmFilterOperand(attribute);
    }

    @Override
    public IFilterExpression eq(String value) {
        StringBuilder expressionBuilder = new StringBuilder();
        expressionBuilder.append(attribute).append(QueryToken.NameValueSeparator).append(value);
        return new ApmFilterExpression(expressionBuilder);
    }

    @Override
    public IFilterExpression in(String... values) {
        Assert.notNull(values, "'values' must not be null");
        IFilterExpression filterExpression = new ApmFilterExpression();
        for (String value : values) {
            filterExpression = filterExpression.or(attribute(attribute).eq(value));
        }
        return filterExpression;
    }

    @Override
    public IFilterExpression like(String value) {
        StringBuilder expressionBuilder = new StringBuilder();
        //TODO: This needs to be fixed later
        // expressionBuilder.append(attribute).append(QueryToken.WildPrefix).append(value)
        //     .append(QueryToken.WildSuffix);
        return new ApmFilterExpression(expressionBuilder);
    }
}
