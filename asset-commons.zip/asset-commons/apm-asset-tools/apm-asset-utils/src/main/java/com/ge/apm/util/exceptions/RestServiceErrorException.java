/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.exceptions;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import org.springframework.http.HttpStatus;

import com.ge.apm.common.exception.IErrorCode;
import com.ge.apm.util.JsonHelper;
import com.ge.apm.util.exceptions.model.RestServiceError;

@Getter
public class RestServiceErrorException extends ServiceExceptionHttpStatus {
    private String httpMethod;

    private RestServiceError restServiceError;

    public RestServiceErrorException(IErrorCode code, String httpMethod, HttpStatus httpStatus,
        RestServiceError restServiceError) {
        super(code, httpStatus);
        if (restServiceError == null) {
            throw new IllegalArgumentException();
        }
        this.restServiceError = restServiceError;
        this.httpMethod = httpMethod;
    }

    @Override
    @JsonIgnore
    public String getFormattedMessage() {
        return JsonHelper.toJson(this, true /* prettyPrint */, false /* wrapRootValue */,
            true /* includeNotNullOnly */);
    }

    @JsonIgnore
    public String getActualMessage() {
        return restServiceError.getFormattedMessage();
    }

    @Override
    public String getMessage() {
        return restServiceError.getFormattedMessage();
    }

    public RestServiceError getRestServiceError() {
        return this.restServiceError;
    }
}
