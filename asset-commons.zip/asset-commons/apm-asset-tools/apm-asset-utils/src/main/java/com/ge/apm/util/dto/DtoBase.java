/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.dto;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.Set;
import java.util.stream.IntStream;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.ge.apm.util.errorcodes.UtilsErrorCodes.DUPLICATE_INPUT_NAMES;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.OBJECT_FOR_NAME_NOT_FOUND;

@Getter
@Setter
public class DtoBase implements IDtoBase {
    private String uri;

    private String name;

    private String description;

    private Date createdOn;

    private Date updatedOn;

    private String createdBy;

    private String updatedBy;

    public static <T extends IDtoBase> T getObjectForNameNoThrow(List<T> list, String name) {

        if (list == null) {
            return null;
        }

        Optional<T> optional = list.stream().filter(object -> object.getName().equalsIgnoreCase(name)).findAny();

        return optional.orElse(null);
    }

    public static <T extends IDtoBase> int getIndexForName(List<T> list, String type, String name) {

        final String methodName = "IDtoBase.getIndexForName";

        int index = getIndexForNameNoThrow(list, name);

        if (index == -1) {
            throw ExceptionHelper.getException(methodName, logger, OBJECT_FOR_NAME_NOT_FOUND, type, name);
        }

        return index;
    }

    public static <T extends IDtoBase> int getIndexForNameNoThrow(List<T> list, String name) {

        OptionalInt optional = IntStream.range(0, list.size()).filter(idx -> list.get(idx).getName()
            .equalsIgnoreCase(name)).findAny();

        if (optional.isPresent()) {
            return optional.getAsInt();
        }

        return -1;
    }

    public static <T extends IDtoBase> T getObjectForName(List<T> list, String type, String name) {
        String methodName = "getObjectForName";

        T object = getObjectForNameNoThrow(list, name);

        if (object == null) {
            throw ExceptionHelper.getException(methodName, logger, OBJECT_FOR_NAME_NOT_FOUND, type, name);
        }

        return object;
    }

    public static <T extends IDtoBase> void checkForDuplicates(String type, List<T> namedEntries) {
        final String methodName = "IDtoBase.checkForDuplicates";

        if (namedEntries == null) {
            return;
        }

        removeInvalidElements(namedEntries);

        Set<String> names = new HashSet<>();
        Set<String> duplicates = new HashSet<>();

        namedEntries.forEach(element -> {
            if (!names.add(element.getName())) {
                duplicates.add(element.getName());
            }
        });

        if (duplicates.isEmpty()) {
            return;
        }

        throw ExceptionHelper.getException(methodName, logger, DUPLICATE_INPUT_NAMES, type,
            StringUtils.join(duplicates, ", "));
    }

    public static <T extends IDtoBase> void removeInvalidElements(List<T> analyticPorts) {
        analyticPorts.removeIf(object -> StringUtils.isBlank(object.getName()));
    }
}
