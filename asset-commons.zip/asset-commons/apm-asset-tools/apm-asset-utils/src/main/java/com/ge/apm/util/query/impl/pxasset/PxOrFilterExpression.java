/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.query.impl.pxasset;

import org.springframework.util.Assert;

import com.ge.apm.util.query.api.IFilterExpression;
import com.ge.apm.util.query.constants.QueryToken;

@SuppressWarnings("WeakerAccess")
public class PxOrFilterExpression extends PxFilterExpression {
    public PxOrFilterExpression(IFilterExpression operand1, IFilterExpression operand2) {
        super();
        Assert.notNull(operand1, "'operand1' must not be null");
        Assert.notNull(operand2, "'operand2' must not be null");
        appendExpression(operand1);
        append(QueryToken.OrSeparator);
        appendExpression(operand2);
    }

    @Override
    public boolean isComposite() {
        return true;
    }

    @Override
    public IFilterExpression or(IFilterExpression operand2) {
        if (!isNullExpression(operand2)) {
            append(QueryToken.OrSeparator);
            appendExpression(operand2);
        }
        return this;
    }
}
