/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.query.impl.apmasset;

import com.ge.apm.util.query.api.IFilterExpression;
import com.ge.apm.util.query.constants.QueryToken;

@SuppressWarnings("WeakerAccess")
public abstract class ApmRelateExpression extends ApmFilterExpression {
    @Override
    protected void appendExpression(IFilterExpression expression) {
        // This is commented to support new apm asset format
        // if (!expression.isComposite() && (!expression.isTypeExpression())) {
        //     append(QueryToken.OpenBracket);
        // }
        super.appendExpression(expression);
        // if (!expression.isComposite() && (!expression.isTypeExpression())) {
        //     append(QueryToken.CloseBracket);
        // }
    }

    @SuppressWarnings("unused")
    protected void deepSearch(IFilterExpression expression, String uri) {
    }
}
