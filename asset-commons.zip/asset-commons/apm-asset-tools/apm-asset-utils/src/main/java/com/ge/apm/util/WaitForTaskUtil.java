/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import lombok.Setter;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.ge.apm.common.exception.ServiceException;

@SuppressWarnings({"Duplicates", "WeakerAccess"})
@Setter
public abstract class WaitForTaskUtil {

    protected static final Logger logger = LoggerFactory.getLogger(WaitForTaskUtil.class);

    private int sleepTime = 60000;

    public Pair<Boolean, ServiceException> waitForTaskToFinish(long waitTimeMinutes, String operation) {
        double timeSpentWaitingS = 0;
        StopWatch timer = new StopWatch();
        timer.start();

        while (true) {

            try {
                Pair<Boolean, ServiceException> taskStatus = isTaskFinished();
                if (taskStatus.getLeft()) {
                    return taskStatus;
                }

                logger.info("{}: Already waited for '{}' seconds. Sleeping for "
                        + "another '{}' seconds before the next check. Timeout time is '{}' seconds.", operation,
                    timeSpentWaitingS, this.sleepTime / 1000, waitTimeMinutes * 60);
                Thread.sleep(this.sleepTime);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            }

            timer.stop();
            timeSpentWaitingS = timer.getTotalTimeSeconds();
            // If the timeout value is less than the time spent then return null.
            if (timeSpentWaitingS > waitTimeMinutes * 60) {
                String errorMessage = String.format("Timed-out waiting ('%s' minutes) for the '%s' to finish.",
                    Long.toString(waitTimeMinutes), operation);
                throw new ServiceException(errorMessage);
            }
            timer.start();
        }
    }

    public abstract Pair<Boolean, ServiceException> isTaskFinished();
}
