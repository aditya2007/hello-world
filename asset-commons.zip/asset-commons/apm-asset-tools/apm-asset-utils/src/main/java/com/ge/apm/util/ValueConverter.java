/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.ge.apm.util.errorcodes.UtilsErrorCodes.NOT_A_VALID_NUMBER;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.VALUE_IS_EMPTY;

public class ValueConverter {

    private static Logger logger = LoggerFactory.getLogger(ValueConverter.class);

    public static long parseLong(String strlong) {
        String methodName = "parseLong";
        ParseResult parseResult = parseLongNoThrow(strlong);
        throwIfError(methodName, parseResult, "Integer", strlong);
        return (long) parseResult.getValue();
    }

    public static ParseResult parseLongNoThrow(String value) {

        ParseResult doubleParseResult = parseDoubleNoThrow(value);

        if (doubleParseResult.getParseResultType() == ParseResultType.INVALID_VALUE) {
            return doubleParseResult;
        }

        double doubleValue = (double) doubleParseResult.getValue();
        if (!isDoubleLong(doubleValue)) {
            return new ParseResult<>(ParseResultType.INVALID_VALUE, (Long) null);
        }

        return new ParseResult<>(ParseResultType.VALID_VALUE, (long) doubleValue);
    }

    public static ParseResult parseDoubleNoThrow(String value) {
        double doubleValue;
        if (StringUtils.isBlank(value)) {
            return new ParseResult<>(ParseResultType.VALUE_EMPTY, (Long) null);
        }

        try {
            doubleValue = Double.parseDouble(value);
        } catch (NumberFormatException excp) {
            return new ParseResult<>(ParseResultType.INVALID_VALUE, (Long) null);
        }

        return new ParseResult<>(ParseResultType.VALID_VALUE, doubleValue);
    }

    // checks if the given double value is long or not. If long, then return true;
    private static boolean isDoubleLong(double d) {
        //select a "tolerance range" for being an integer
        double tolerance = 1E-5;
        //do not use (int)d, due to weird floating point conversions!
        return Math.abs(Math.floor(d) - d) <= tolerance;
    }

    public static double parseDouble(String strValue) {
        String methodName = "parseDouble";
        try {
            return Double.parseDouble(strValue);
        } catch (NumberFormatException excp) {
            throw ExceptionHelper.getException(methodName, logger, NOT_A_VALID_NUMBER, "Double", strValue);
        }
    }

    private static void throwIfError(String callerMethod, ParseResult parseResult, String dataType, String value) {
        if (parseResult.getParseResultType() == ParseResultType.VALUE_EMPTY) {
            throw ExceptionHelper.getException(callerMethod, logger, VALUE_IS_EMPTY);
        } else if (parseResult.getParseResultType() == ParseResultType.INVALID_VALUE) {
            throw ExceptionHelper.getException(callerMethod, logger, NOT_A_VALID_NUMBER, dataType, value);
        }
    }

    public enum ParseResultType {
        VALID_VALUE,
        VALUE_EMPTY,
        INVALID_VALUE
    }

    @Getter
    @Setter
    @AllArgsConstructor
    public static class ParseResult<T> {

        private ParseResultType parseResultType;

        private T value;
    }
}

