/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.model;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.ge.apm.util.errorcodes.UtilsErrorCodes.ERROR_RETRIEVING_MIME_PATH;

@Getter
@Setter
public class ArtifactFile extends Artifact {

    private File file;

    public ArtifactFile() {
    }

    public ArtifactFile(File file, Map<String, String> metaData) {
        String methodName = "ArtifactFile.ArtifactFile";
        setFilename(file.getName());
        setMetaData(metaData);

        try {
            setContentType(Files.probeContentType(Paths.get(file.getAbsolutePath())));
        } catch (IOException exception) {
            throw ExceptionHelper.getException(methodName, logger, exception, ERROR_RETRIEVING_MIME_PATH,
                file.getName(), exception.getMessage());
        }
        setContentLength(file.length());
        this.file = file;
    }

    public ArtifactFile(String uri, File file, Map<String, String> metaData) {
        this(file, metaData);
        setUri(uri);
    }
}
