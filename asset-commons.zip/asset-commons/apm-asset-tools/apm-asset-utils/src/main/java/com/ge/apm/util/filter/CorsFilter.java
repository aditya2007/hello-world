/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.filter;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * @author 204069133
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CorsFilter implements Filter {

    private static final Logger logger = LoggerFactory.getLogger(CorsFilter.class);

    @Value("${BASE_ORIGIN_LIST:}")
    private String BASE_ORIGIN_LIST;

    private static String BASE_ALLOWED_HEADERS =
        "Origin,Accept,X-Requested-With,Content-Type,Content-Disposition,Access-Control-Request-Method,"
            + "Access-Control-Request-Headers,X-HTTP-Method-Override,Authorization,username,data,tenant";

    private static String BASE_ALLOWED_METHODS = "POST, GET, HEAD, OPTIONS, PUT, PATCH, DELETE";

    private static String BASE_MAX_AGE = "3600";

    private static String BASE_ALLOW_CREDENTIAL = "true";

    @Value("${corsControlAdditionalAllowOrigin:}")
    private String ADDITIONAL_ORIGIN_LIST;

    @Value("${corsControlAdditionalAllowHeaders:}")
    private String ADDITIONAL_ALLOWED_HEADERS;

    @Value("${corsControlAdditionalAllowMethods:}")
    private String ADDITIONAL_ALLOWED_METHODS;

    @Value("${corsControlOverrideMaxAge:3600}")
    private String OVERRIDE_MAX_AGE;

    @Value(value = "${corsControlOverrideAllowCredential:true}")
    private String OVERRIDE_ALLOW_CREDENTIAL;

    private Set<String> allowedOrigins;

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
        throws IOException, ServletException {
        HttpServletResponse response = (HttpServletResponse) res;
        HttpServletRequest request = (HttpServletRequest) req;
        String method = request.getMethod();
        String originHeader = request.getHeader("Origin");
        boolean isOriginAllowed = isOriginAllowed(originHeader);
        if (isOriginAllowed) {
            response.setHeader("Access-Control-Allow-Origin", originHeader);
        }

        response.setHeader("Access-Control-Allow-Methods", concat(BASE_ALLOWED_METHODS, ADDITIONAL_ALLOWED_METHODS));
        response.setHeader("Access-Control-Max-Age", BASE_MAX_AGE);
        response.setHeader("Access-Control-Allow-Credentials", BASE_ALLOW_CREDENTIAL);
        response.setHeader("Access-Control-Allow-Headers", concat(BASE_ALLOWED_HEADERS, ADDITIONAL_ALLOWED_HEADERS));

        // Additional Security Headers
        response.setHeader("X-Frame-Options", "SAMEORIGIN");
        response.setHeader("Strict-Transport-Security", "max-age=16070400");
        response.setHeader("Content-Security-Policy", "child-src 'self'");
        response.setHeader("X-XSS-Protection", "1; mode=block");
        response.setHeader("Cache-Control", "no-cache");
        //Strict MIME-Type checking
        response.setHeader("X-Content-Type-Options", "nosniff");

        if ("OPTIONS".equals(method)) {
            response.setStatus(HttpStatus.OK.value());
        } else {
            chain.doFilter(req, res);
        }

    }

    public String concat(String base, String additional) {
        System.out.println(base + " - " + additional);
        StringBuilder sb = new StringBuilder();
        sb.append(base);
        if (additional.length() > 0) {
            sb.append(",").append(additional);
        }
        return sb.toString();
    }

    public String useBaseIfNotOverridden(String base, String override) {
        System.out.println(base + " - " + override);
        if (override.length() > 1) {
            return override;
        } else {
            return base;
        }
    }

    @Override
    public void init(FilterConfig filterConfig) {
        allowedOrigins = new HashSet<>();
        if (!StringUtils.isEmpty(BASE_ORIGIN_LIST)) {
            String additionalOriginList[] = BASE_ORIGIN_LIST.split(",");
            allowedOrigins.addAll(Arrays.asList(additionalOriginList));
        }
    }

    /**
     * Method to check if the origin is from the allowed list of origins.
     */
    private boolean isOriginAllowed(String originHeader) {
        boolean isOriginAllowed = false;
        if (!StringUtils.isEmpty(originHeader)) {
            isOriginAllowed = allowedOrigins.stream().anyMatch(org -> ((originHeader.matches((".*" + org))) || (
                originHeader.compareTo(org) == 0)));
        }
        return isOriginAllowed;
    }

    @Override
    public void destroy() {
        // Nothing special here
    }

}
