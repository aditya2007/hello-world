/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.model;

import java.util.Date;
import java.util.Map;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.util.dto.IDtoBase;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Artifact implements IDtoBase {

    public static final String ARTIFACTS_PREFIX = "/artifacts";

    private String uri;

    private String filename;

    private String version;

    private String description;

    private String artifactType;

    private byte[] bytes;

    private String contentType;

    private long contentLength;

    private Map<String, String> metaData;

    private Date createdOn;

    private Date updatedOn;

    private String createdBy;

    private String updatedBy;

    public Artifact() {
    }

    @Override
    public String getName() {
        return filename;
    }

    @Override
    public void setName(String name) {
        filename = name;
    }
}



