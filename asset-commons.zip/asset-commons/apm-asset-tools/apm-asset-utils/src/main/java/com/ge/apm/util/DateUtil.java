/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.temporal.TemporalUnit;
import java.util.Date;
import java.util.TimeZone;

import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.apm.util.ValueConverter.ParseResult;
import com.ge.apm.util.ValueConverter.ParseResultType;
import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.ge.apm.util.errorcodes.UtilsErrorCodes.INVALID_TIME_VALUE;
import static com.ge.apm.util.errorcodes.UtilsErrorCodes.NOT_VALID_LONG_DATE_VALUE;

@SuppressWarnings("WeakerAccess")
public class DateUtil {

    public static final TimeZone utcTimezone = TimeZone.getTimeZone("UTC");

    public static final TimeZone pstTimezone = TimeZone.getTimeZone("PST");

    private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);

    private static SimpleDateFormat getSimpleDateFormat(String dateFormat, TimeZone timeZone) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
        simpleDateFormat.setTimeZone(timeZone);
        return simpleDateFormat;
    }

    // returns in ISO_NO_TZ and UTC timezone
    public static String getDate(long date) {
        return getDate(date, DateFormat.TS_FORMAT_ISO_NO_TZ.format);
    }

    public static String getDate(long date, DateFormat dateFormat) {
        return getDate(date, dateFormat.format);
    }

    // returns in UTC timezone.
    public static String getDate(long date, String dateFormat) {
        return getSimpleDateFormat(dateFormat, utcTimezone).format(date);
    }

    public static String getDate(long date, DateFormat dateFormat, TimeZone timezone) {
        return getDate(date, dateFormat.format, timezone);
    }

    public static String getDate(long date, String dateFormat, TimeZone timezone) {
        return getSimpleDateFormat(dateFormat, timezone).format(date);
    }

    public static long getDate(String date, DateFormat dateFormat) {
        return getDate(date, dateFormat.format);
    }

    // returns UTC timezone value fo the given string with the given format.
    @SuppressWarnings("unused")
    public static long getDate(String date, String dateFormat) {
        String methodName = "getDate(String, DateFormat)";
        try {
            return getSimpleDateFormat(dateFormat, utcTimezone).parse(date).getTime();
        } catch (ParseException e) {
            throw ExceptionHelper.getException(methodName, logger, INVALID_TIME_VALUE, date, dateFormat);
        }
    }

    public static String getDate(DateFormat dateFormat) {
        return getDate(dateFormat.format, utcTimezone);
    }

    public static String getDate(DateFormat dateFormat, TimeZone timeZone) {
        return getDate(dateFormat.format, timeZone);
    }

    public static String getDate(String dateFormat, TimeZone timeZone) {
        return getSimpleDateFormat(dateFormat, timeZone).format(new Date(System.currentTimeMillis()));
    }

    public static String getDateFromStrLong(String strLong, DateFormat dateFormat, TimeZone timeZone) {
        return getDateFromStrLong(strLong, dateFormat.format, timeZone);
    }

    public static String getDateFromStrLong(String strLong, String dateFormat, TimeZone timeZone) {
        String methodName = "getDateFromStrLong";
        ParseResult parseResult = ValueConverter.parseLongNoThrow(strLong);
        if (parseResult.getParseResultType() != ParseResultType.VALID_VALUE) {
            throw ExceptionHelper.getException(methodName, logger, NOT_VALID_LONG_DATE_VALUE, strLong);
        }
        Date date = new Date((long) parseResult.getValue());
        return getSimpleDateFormat(dateFormat, timeZone).format(date);
    }

    public static boolean isDateBefore(Date date, long amountToSubtract, TemporalUnit unit) {
        Instant then = date.toInstant();
        Instant now = Instant.now();
        Instant dateEarlier = now.minus(amountToSubtract, unit);
        // Is that moment (a) before 24 hours ago, AND (b) before now (not in the future)?
        return then.isBefore(dateEarlier);
    }

    public static Date datePlus(long amountToAdd, TemporalUnit unit) {
        return Date.from(LocalDateTime.now().plus(amountToAdd, unit).toInstant(ZoneOffset.UTC));
    }

    @Getter
    public enum DateFormat {
        TS_FORMAT_ISO_NO_TZ("yyyy-MM-dd'T'HH:mm:ss.SSS"),
        TS_FORMAT_ISO("yyyy-MM-dd'T'HH:mm:ss.SSSZ"),
        TS_FORMAT_ISO8601_2("yyyy-MM-dd'T'HH:mm:ssXXX"),
        // "2016-10-21T22:25:11+00:00"
        TS_FORMAT_ISO8601("yyyy-MM-dd'T'HH:mm:ss.SSSX"),
        TS_FORMAT_PROFICY("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
        TS_FORMAT_CSV_IMPORT("MM/dd/yyyy hh:mm:ss a"),
        TS_FORMAT_1("yyyy-MM-dd HH:mm:ss.SSS"); // "2016-11-30 01:40:03.13"

        private final String format;

        DateFormat(String format) {
            this.format = format;
        }
    }
}
