/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.ge.apm.common.exception.ServiceException;

@SuppressWarnings({ "WeakerAccess", "unused" })
public class LogCaptureUtil {
    private static final Logger logger = LoggerFactory.getLogger(LogCaptureUtil.class);

    private OutputStream newOutputStream;

    private PrintStream newPrintStream;

    private PrintStream oldStream;

    public void startCapturingLogToFile(File file) {
        try {
            this.newOutputStream = new FileOutputStream(file.getAbsolutePath(), false /* append */);
        } catch (FileNotFoundException e) {
            logger.error("", e);
            throw new ServiceException(e.getMessage());
        }
        this.newPrintStream = new PrintStream(this.newOutputStream);
        startCapturingLog();
    }

    public void startCapturingLog() {
        // IMPORTANT: Save the old System.out!
        this.oldStream = System.out;
        // Tell Java to use your special stream
        System.setOut(this.newPrintStream);
    }

    public void startCapturingLogToString() {
        // Create a stream to hold the output
        this.newOutputStream = new ByteArrayOutputStream();
        this.newPrintStream = new PrintStream(this.newOutputStream);
        startCapturingLog();
    }

    @NotNull
    public String[] resetLogToDefault() {
        try {
            String[] capturedLog = getCapturedLog();
            System.setOut(this.oldStream);
            this.newOutputStream.close();
            return capturedLog;
        } catch (IOException e) {
            logger.error("", e);
            throw new ServiceException(e.getMessage());
        } finally {
            this.newPrintStream.close();
        }
    }

    public String[] getCapturedLog() {
        System.out.flush();
        String capturedLog = this.newOutputStream.toString();
        return StringUtils.split(capturedLog, System.lineSeparator());
    }
}
