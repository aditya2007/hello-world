/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.List;
import java.util.Map;

import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.apm.util.errorcodes.UtilsErrorCodes;
import com.ge.apm.util.exceptions.ExceptionHelper;

@SuppressWarnings({ "WeakerAccess", "unused" })
public class CsvFileUtil {
    private static final Logger logger = LoggerFactory.getLogger(CsvFileUtil.class);

    public static <T> List<T> readCsvContent(String csvContent, Map<String, String> columnMapping, Class<T> classType) {
        String methodName = "CsvFileUtil.readCsvContent";

        CSVReader csvReader = new CSVReader(new StringReader(csvContent));
        return parseContent(csvReader, columnMapping, classType);
    }

    public static <T> List<T> readCsvFile(String filename, Map<String,
        String> columnMapping, Class<T> classType) throws IOException {
        String methodName = "CsvFileUtil.readCsvFile";

        File file = new File(filename);

        if (!file.exists()) {
            throw ExceptionHelper.getException(methodName, logger, UtilsErrorCodes.INVALID_FILE_NAME, filename);
        }

        CSVReader csvReader;
        FileReader fr = null;
        try {
            fr = new FileReader(file);
            csvReader = new CSVReader(fr);
            fr.close();
            return parseContent(csvReader, columnMapping, classType);
        } catch (FileNotFoundException e) {
            logger.error(e.getMessage(), e);
            throw ExceptionHelper.getException(methodName, logger, UtilsErrorCodes.INVALID_FILE_NAME, filename);
        } finally {
            if (fr != null) {
                fr.close();
            }
        }
    }

    private static <T> List<T> parseContent(CSVReader csvReader, Map<String, String> columnMapping,
        Class<T> classType) {
        HeaderColumnNameTranslateMappingStrategy<T> strategy = new HeaderColumnNameTranslateMappingStrategy<>();
        strategy.setType(classType);
        strategy.setColumnMapping(columnMapping);

        CsvToBean<T> csvToBean = new CsvToBean<>();
        return csvToBean.parse(strategy, csvReader);
    }
}
