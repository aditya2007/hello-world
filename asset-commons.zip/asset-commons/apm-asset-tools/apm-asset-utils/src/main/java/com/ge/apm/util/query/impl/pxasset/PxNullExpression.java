/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.query.impl.pxasset;

import org.apache.commons.lang3.NotImplementedException;

import com.ge.apm.util.query.api.IFilterExpression;

import static com.ge.apm.util.query.impl.pxasset.PxFilterExpression.deepSearchHelper;

@SuppressWarnings("WeakerAccess")
public class PxNullExpression implements IFilterExpression {
    @Override
    public boolean isComposite() {
        return false;
    }

    @Override
    public IFilterExpression and(IFilterExpression operand2) {
        return operand2;
    }

    @Override
    public IFilterExpression or(IFilterExpression operand2) {
        return operand2;
    }

    @Override
    public IFilterExpression backwardRelate(String operand2, int depth) {
        final String methodName = "NullExpression.backwardRelate";
        throw new NotImplementedException(methodName + " not implemented.");
    }

    @Override
    public IFilterExpression forwardRelate(String operand2, int depth) {
        final String methodName = "NullExpression.forwardRelate";
        throw new NotImplementedException(methodName + " not implemented.");
    }

    @Override
    public IFilterExpression parent(String uri, int depth) {
        final String methodName = "NullExpression.parent";
        throw new NotImplementedException(methodName + " not implemented.");
    }

    @Override
    public IFilterExpression deepSearch(String operand1Name, String operand1Value, String operand2Name,
        int transitiveDepth) {
        return deepSearchHelper(operand1Name, operand1Value, operand2Name, transitiveDepth);
    }

    @Override
    public String build() {
        final String methodName = "NullExpression.build";
        throw new NotImplementedException(methodName + " not implemented.");
    }

    @Override
    public boolean isTypeExpression() {
        return false;
    }
}
