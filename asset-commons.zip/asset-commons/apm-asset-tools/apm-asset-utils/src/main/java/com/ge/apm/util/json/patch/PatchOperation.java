/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.util.json.patch;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@EqualsAndHashCode
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PatchOperation implements Serializable {
    private static final long serialVersionUID = -5846827465844227158L;

    private final String op;

    private final String from;

    private final String path;

    private final Object value;

    public PatchOperation() {
        this(null, null, null);
    }

    public PatchOperation(String op, String path) {
        this(op, path, null);
    }

    public PatchOperation(String op, String from, String path) {
        this.op = op;
        this.from = from;
        this.path = path;
        this.value = null;
    }

    public PatchOperation(String op, String path, Object value) {
        this.op = op;
        this.path = path;
        this.value = value;
        this.from = null;
    }
}
