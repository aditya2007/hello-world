/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.controller;

import javax.ws.rs.core.MediaType;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.apm.rest.util.RestExceptionHelper;

@SuppressWarnings("unused")
@RequestMapping("/")
@RestController
public class ThrowsExceptionController {

    @RequestMapping(value = "/throws", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public String throwsServiceException() {
        throw RestExceptionHelper.getRestServiceErrorException("", null, "Url1", "HttpMethod1", HttpStatus.INTERNAL_SERVER_ERROR,
            new RuntimeException("hello"), "ExceptionMsg1");
    }

    // @RequestMapping(value = "/nullPointer", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
    // @ResponseBody
    // public String throwsNullPointerException() {
    //     Object nullObject = null;
    //     return nullObject.toString();
    // }
}
