/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;

import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.rest.exception.handler.RequestErrorController;
import com.ge.apm.util.servlets.HttpServletUtils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Ignore
public class RestExceptionHelperTest {

    @Before
    public void beforeEach() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getException() {
        Exception excp = mock(Exception.class);
        HttpServletResponse response = mock(HttpServletResponse.class);

        Exception actual = RestExceptionHelper.getException("", null, excp, response);

        assertNotNull(actual);
    }

    @Test
    public void getException_NotFoundException() {
        NotFoundException excp = mock(NotFoundException.class);
        HttpServletResponse response = new MockHttpServletResponse();

        Exception actual = RestExceptionHelper.getException("", null, excp, response);

        assertNotNull(actual);
        assertEquals(response.getStatus(), HttpStatus.NOT_FOUND.value());
    }

    @Test
    public void getException_ServiceException() {
        ServiceException excp = mock(ServiceException.class);
        when(excp.getMessage()).thenReturn("Test");

        HttpServletResponse response = new MockHttpServletResponse();

        Exception actual = RestExceptionHelper.getException("", null, excp, response);

        assertNotNull(actual);
        assertEquals(actual.getMessage(), "Test");
    }

    @Test
    public void getServletRequest() {
        WebRequest webRequest = mock(WebRequest.class);

        HttpServletRequest actual = HttpServletUtils.getServletRequest(webRequest);
        assertNull(actual);
    }

    @Test
    public void getServletRequest_servletWebRequest() {
        ServletWebRequest webRequest = mock(ServletWebRequest.class);
        HttpServletRequest request = new MockHttpServletRequest();
        when(webRequest.getNativeRequest()).thenReturn(request);

        HttpServletRequest actual = HttpServletUtils.getServletRequest(webRequest);
        assertEquals(request, actual);
    }

    @Test
    public void getHttpStatus() {
        HttpServletRequest request = new MockHttpServletRequest();
        request.setAttribute("javax.servlet.error.status_code", 404);

        HttpStatus actual = HttpServletUtils.getHttpStatus(request);
        assertEquals(HttpStatus.NOT_FOUND, actual);
    }

    @Test
    public void getHttpStatus_error() {
        HttpServletRequest request = new MockHttpServletRequest();
        request.setAttribute("javax.servlet.error.status_code", 9999);

        HttpStatus actual = HttpServletUtils.getHttpStatus(request);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actual);
    }

    @Test
    public void getError() {
        HttpServletRequest request = new MockHttpServletRequest();
        RequestAttributes requestAttributes = new ServletRequestAttributes(request);
        Exception ex = new Exception("Test");
        requestAttributes.setAttribute(RequestErrorController.ERROR_ATTRIBUTE, ex, 0);

        Throwable actual = RestExceptionHelper.getError(requestAttributes);
        assertEquals(ex, actual);
    }

    @Test
    public void getError_noErrorAttribute() {
        HttpServletRequest request = new MockHttpServletRequest();
        RequestAttributes requestAttributes = new ServletRequestAttributes(request);
        Exception ex = new Exception("Test");
        requestAttributes.setAttribute("javax.servlet.error.exception", ex, 0);

        Throwable actual = RestExceptionHelper.getError(requestAttributes);
        assertEquals(ex, actual);
    }

    @Test
    public void getResourceAccessExceptionMsg() {
        ResourceAccessException excption = mock(ResourceAccessException.class);

        String expected = "Test";
        when(excption.getCause()).thenReturn(new Exception(expected));

        Pair<HttpStatus, String> actual = RestExceptionHelper.getResourceAccessExceptionMsg(excption, "url");
        assertEquals(expected, actual.getRight());
    }
}
