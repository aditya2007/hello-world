/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableAutoConfiguration
@SpringBootApplication
@ComponentScan(
    { "com.ge.apm.rest.exception", "com.ge.apm.rest.controller", "com.ge.apm.rest.config", "com.ge.apm.rest.aspect" })
/*@Import({JsonMapperConfiguration.class})*/
public class TestRestApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {

        new SpringApplicationBuilder(TestRestApplication.class).run(args);
    }
}