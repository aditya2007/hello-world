/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.exception;

import java.beans.PropertyChangeEvent;
import java.net.UnknownHostException;
import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.ConversionNotSupportedException;
import org.springframework.beans.TypeMismatchException;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException;

import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.rest.SpringNonWebApplication;
import com.ge.apm.rest.exception.handler.ControllerExcpHandler;
import com.ge.apm.util.exceptions.model.RestServiceError;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = SpringNonWebApplication.class)
@Ignore
public class ControllerExcpHandlerTest {

    private String reqUri;

    private String fwdReqUri;

    private HttpHeaders headers;

    private HttpStatus status;

    private String errorMsg;

    private ResponseEntity<Object> response;

    private HttpServletRequest servletReq;

    @Mock
    private HttpServletRequest request;

    @Mock
    private WebRequest webRequest;

    @Mock
    private HttpServletRequest requestNoNative;

    @Mock
    private MethodArgumentNotValidException methodArgNotValidException;

    @Before
    public void beforeEach() {
        MockitoAnnotations.initMocks(this);

        this.reqUri = "http://test/";
        this.fwdReqUri = "";
        //exception = ;
        this.status = HttpStatus.OK;
        this.errorMsg = "Error message";
        this.servletReq = new MockHttpServletRequest("GET", this.reqUri);
        this.headers = new HttpHeaders();

        when(this.request.getAttribute("javax.servlet.forward.request_uri")).thenReturn(this.fwdReqUri);
        when(this.request.getAttribute("javax.servlet.error.status_code")).thenReturn(200);
        when(this.request.getMethod()).thenReturn("GET");
        //when(request.getAttribute( AnalyticRequestErrorHandler.ERROR_ATTRIBUTE )).thenReturn(exception);
        when(this.request.getRequestURL()).thenReturn(new StringBuffer(this.reqUri));
        when(this.methodArgNotValidException.getMessage()).thenReturn("Test");
    }

    @Test
    public void handlerExceptionInternal() {
        ServletWebRequest wrapperRequest = new ServletWebRequest(this.request);
        this.response = ControllerExcpHandler.handleExceptionInternal(new ServiceException("Test"), this.status,
            wrapperRequest);

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handlerExceptionInternal_noNativeRequest() {
        this.response = ControllerExcpHandler.handleExceptionInternal(new Exception("Test"), this.status,
            this.webRequest);

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handlerExceptionInternal_mockedServletRequest() {
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, new Exception("Test")));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handlerExceptionInternal_BindException() {
        BindException ex = new BindException("", "");
        ex.addError(new ObjectError("test", "error"));
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(),
            "Error in object 'test': codes []; arguments []; default message [error]\n");
    }

    @Test
    public void handlerExceptionInternal_ConversionNotSupportedException() {
        PropertyChangeEvent pcEvent = new PropertyChangeEvent("source", "property name", "old value", "new value");
        ConversionNotSupportedException ex = new ConversionNotSupportedException(pcEvent, String.class,
            new Exception("Test"));
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handlerExceptionInternal_HttpMediaTypeNotAcceptableException() {
        HttpMediaTypeNotAcceptableException ex = new HttpMediaTypeNotAcceptableException("test");
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "test\nSupported accept types: ");
    }

    @Test
    public void handlerExceptionInternal_HttpMediaTypeNotSupportedException() {
        HttpMediaTypeNotSupportedException ex = new HttpMediaTypeNotSupportedException("test");
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(),
            "Unsupported content type: 'null' \n test\nSupported content types: ''");
    }

    @Test
    public void handlerExceptionInternal_HttpMessageNotReadableException() {
        HttpMessageNotReadableException ex = new HttpMessageNotReadableException("Test");
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handlerExceptionInternal_HttpMessageNotWritableException() {
        HttpMessageNotWritableException ex = new HttpMessageNotWritableException("Test");
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handlerExceptionInternal_HttpRequestMethodNotSupportedException() {

        HttpRequestMethodNotSupportedException ex = new HttpRequestMethodNotSupportedException("POST",
            new String[] { "GET" });
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(),
            "Request method 'POST' not supported\nRequest method 'POST' not supported.\nSupported methods: 'GET");
    }

    @Test
    public void handlerExceptionInternal_MethodArgumentNotValidException() {
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, this.methodArgNotValidException));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handlerExceptionInternal_MissingServletRequestParameterException() {
        MissingServletRequestParameterException ex = new MissingServletRequestParameterException("id",
            "java.lang.String");
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(),
            "Required java.lang.String parameter 'id' is not present");
    }

    @Test
    public void handlerExceptionInternal_MissingServletRequestPartException() {
        MissingServletRequestPartException ex = new MissingServletRequestPartException("partName");
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals("Required request part 'partName' is not present", serviceError.getErrors().get(0).getMessage());
    }

    @Test
    public void handlerExceptionInternal_NoHandlerFoundException() {
        NoHandlerFoundException ex = new NoHandlerFoundException("GET", this.reqUri, this.headers);
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(),
            String.format("The URI '%s' is not found.", this.reqUri));
    }

    @Test
    public void handlerExceptionInternal_NoSuchRequestHandlingMethodException() {
        NoSuchRequestHandlingMethodException ex = new NoSuchRequestHandlingMethodException(this.servletReq);
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(),
            "No matching handler method found for servlet request: path 'http://test/', method 'GET', parameters "
                + "map[[empty]]");
    }

    @Test
    public void handlerExceptionInternal_ServletRequestBindingException() {
        ServletRequestBindingException ex = new ServletRequestBindingException("Oh no!");
        ex.initCause(new Exception("Root cause"));
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Root cause");
    }

    @Test
    public void handlerExceptionInternal_TypeMismatchException() {
        TypeMismatchException ex = new TypeMismatchException("blah", String.class);
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(),
            "Failed to convert value of type 'java.lang.String' to required type 'java.lang.String'");
    }

    @Test
    public void handlerExceptionInternal_ResourceAccessException() {
        ResourceAccessException ex = new ResourceAccessException("Oh no!");
        ex.initCause(new Exception("Root cause"));
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Root cause");
    }

    @Test
    public void handlerExceptionInternal_ResourceAccessException_unknownHost() {
        ResourceAccessException ex = new ResourceAccessException("Oh no!");
        ex.initCause(new UnknownHostException("www.apm-host-exception.com"));
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, ex));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(),
            "The server 'www.apm-host-exception.com' is not available.");
    }

    @Test
    public void handleConversionNotSupported() {
        ConversionNotSupportedException excp = mock(ConversionNotSupportedException.class);
        when(excp.getMessage()).thenReturn("Test");
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleHttpMediaTypeNotAcceptable() {
        HttpMediaTypeNotAcceptableException excp = mock(HttpMediaTypeNotAcceptableException.class);
        when(excp.getMessage()).thenReturn("Test");
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleHttpMediaTypeNotSupported() {
        HttpMediaTypeNotSupportedException excp = mock(HttpMediaTypeNotSupportedException.class);
        when(excp.getMessage()).thenReturn("Test");
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleHttpMessageNotReadable() {
        HttpMessageNotReadableException excp = mock(HttpMessageNotReadableException.class);
        when(excp.getMessage()).thenReturn("Test");
        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleHttpMessageNotWritable() {
        HttpMessageNotWritableException excp = mock(HttpMessageNotWritableException.class);
        when(excp.getMessage()).thenReturn("Test");

        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleHttpRequestMethodNotSupported() {
        HttpRequestMethodNotSupportedException excp = mock(HttpRequestMethodNotSupportedException.class);
        when(excp.getMessage()).thenReturn("Test");

        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleMethodArgumentNotValid() {
        MethodArgumentNotValidException excp = mock(MethodArgumentNotValidException.class);
        when(excp.getMessage()).thenReturn("Test");

        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleMissingServletRequestParameter() {
        MissingServletRequestParameterException excp = mock(MissingServletRequestParameterException.class);
        when(excp.getMessage()).thenReturn("Test");

        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleMissingServletRequestPart() {
        MissingServletRequestPartException excp = mock(MissingServletRequestPartException.class);
        when(excp.getMessage()).thenReturn("Test");

        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleNoHandlerFoundException() {
        NoHandlerFoundException excp = mock(NoHandlerFoundException.class);
        when(excp.getMessage()).thenReturn("Test");

        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleNoSuchRequestHandlingMethod() {
        NoSuchRequestHandlingMethodException excp = mock(NoSuchRequestHandlingMethodException.class);
        when(excp.getMessage()).thenReturn("Test");

        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleServletRequestBindingException() {
        ServletRequestBindingException excp = mock(ServletRequestBindingException.class);
        when(excp.getMessage()).thenReturn("Test");

        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleTypeMismatch() {
        TypeMismatchException excp = mock(TypeMismatchException.class);
        when(excp.getMessage()).thenReturn("Test");

        this.response = ControllerExcpHandler.getResponseEntity(
            ControllerExcpHandler.getErrorMessageForExcptionType(this.servletReq, this.status, excp));

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Test");
    }

    @Test
    public void handleException() {
        Exception excp = mock(Exception.class);
        when(excp.getMessage()).thenReturn("Test");
        ControllerExcpHandler handler = new ControllerExcpHandler();
        this.response = handler.handleException(this.request, excp);

        RestServiceError serviceError = getResponseError(this.response);
        assertEquals(serviceError.getErrors().get(0).getMessage(), "Internal Server error. Please contact support.");
    }

    private RestServiceError getResponseError(ResponseEntity<Object> response) {
        Object body = response.getBody();
        assertEquals(body.getClass(), RestServiceError.class);
        RestServiceError serviceError = (RestServiceError) body;
        return serviceError;
    }
}
