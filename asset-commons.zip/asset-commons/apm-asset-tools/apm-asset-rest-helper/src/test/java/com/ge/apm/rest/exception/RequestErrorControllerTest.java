/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.exception;

import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.ge.apm.rest.exception.handler.RequestErrorController;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.Mock;

/**
 * Created by 212348840 on 02/19/2016.
 */
public class RequestErrorControllerTest {

    private RequestErrorController requestErrorController;

    private String reqUri;

    private String fwdReqUri;

    private Throwable exception;

    @Mock
    private HttpServletRequest request;

    @Before
    public void beforeEach() {
        MockitoAnnotations.initMocks(this);

        requestErrorController = new RequestErrorController();

        reqUri = "http://test/";
        fwdReqUri = "";
        exception = new Exception("Test");
        when(request.getAttribute("javax.servlet.forward.request_uri")).thenReturn(fwdReqUri);
        when(request.getAttribute("javax.servlet.error.status_code")).thenReturn(200);
        when(request.getMethod()).thenReturn("GET");
        when(request.getAttribute(RequestErrorController.ERROR_ATTRIBUTE)).thenReturn(exception);
        when(request.getRequestURL()).thenReturn(new StringBuffer(reqUri));
    }

    @Test
    public void getErrorPath() {
        String errorPath = requestErrorController.getErrorPath();
        assertEquals(errorPath, "/error");
    }

    @Test
    public void error() {

        ResponseEntity<Object> response = requestErrorController.error(request);

        when(request.getAttribute(RequestErrorController.ERROR_ATTRIBUTE)).thenReturn(null);
        response = requestErrorController.error(request);

        when(request.getAttribute("javax.servlet.error.status_code")).thenReturn(404);
        response = requestErrorController.error(request);

        when(request.getAttribute(RequestErrorController.ERROR_ATTRIBUTE)).thenReturn(new AssertionError());
        response = requestErrorController.error(request);
    }
}
