/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.util;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.ge.apm.common.config.IServiceInfoProvider;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.support.RequestContext;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by 212348840 on 02/25/2016.
 */
public class PxRestUtilTest {

    String serviceInfoKey = "MyService";

    String restTemplateKey = "RestTemplateKey";

    @Mock
    IServiceInfoProvider serviceInfoProvider;

    @Mock
    RestTemplate restTemplate;

    @Before
    public void beforeEach() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void constructor() {
        PxRestUtil restUtil = getRestUtil();
        assertNotNull(restUtil);

        cleanUpRequestContext();
    }

    @Test(expected = ServiceException.class)
    public void constructor_noServiceInfoProvider() {

        cleanUpRequestContext();

        new PxRestUtil(this.serviceInfoKey, this.restTemplateKey);
    }

    @Test(expected = ServiceException.class)
    public void constructor_noRestTemplate() {

        RequestContext.put(this.serviceInfoKey, this.serviceInfoProvider);
        RequestContext.remove(this.restTemplateKey);

        new PxRestUtil(this.serviceInfoKey, this.restTemplateKey);

        cleanUpRequestContext();
    }

    @Test
    public void getUri() {

        String expected = "http://localhost/test";
        when(this.serviceInfoProvider.getUri()).thenReturn(expected);

        PxRestUtil restUtil = getRestUtil();
        String actual = restUtil.getUri();
        assertEquals(expected, actual);

        cleanUpRequestContext();
    }

    @Test
    public void getHeaders() {
        boolean hasContent = false;
        String contentType = "application/json";
        MultiValueMap<String, String> overrideHeaders = new HttpHeaders();

        PxRestUtil restUtil = getRestUtil();
        restUtil.getHeaders(hasContent, contentType, overrideHeaders);
    }

    private PxRestUtil getRestUtil() {

        RequestContext.put(this.serviceInfoKey, this.serviceInfoProvider);
        RequestContext.put(this.restTemplateKey, this.restTemplate);

        PxRestUtil restUtil = new PxRestUtil(this.serviceInfoKey, this.restTemplateKey);

        return restUtil;
    }

    private void cleanUpRequestContext() {
        RequestContext.remove(this.serviceInfoKey);
        RequestContext.remove(this.restTemplateKey);
    }
}
