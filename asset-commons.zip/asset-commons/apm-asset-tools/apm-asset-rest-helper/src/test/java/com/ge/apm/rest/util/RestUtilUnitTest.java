/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.util;

import java.io.IOException;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.support.RequestContext;

import static com.ge.apm.rest.util.RestExceptionHelper.getExceptionForRestRequest;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Ignore
public class RestUtilUnitTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private ApmRestUtil restUtil;

    @Mock
    private RestTemplate restTemplate;

    @Before
    public void beforeEach() {
        MockitoAnnotations.initMocks(this);
        this.restTemplate = mock(RestTemplate.class);
        this.restUtil = new ApmRestUtil(this.restTemplate);
    }

    @Test
    public void getExceptionForRestRequest_NoResponse() {
        WebApplicationException excp = mock(WebApplicationException.class);
        when(excp.getResponse()).thenReturn(null);
        when(excp.getMessage()).thenReturn("Test");
        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;
        ServiceException actual = RestExceptionHelper.getExceptionForRestRequest("", null, url, httpMethod, excp);
        assertNotNull(actual);
    }

    @Test
    public void getExceptionForRestRequest_HttpStatusCodeException() {
        HttpStatusCodeException excp = mock(HttpStatusCodeException.class);
        when(excp.getResponseBodyAsString()).thenReturn("Test");
        when(excp.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        when(excp.getStatusText()).thenReturn("Internal server error");
        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;
        ServiceException actual = RestExceptionHelper.getExceptionForRestRequest("", null, url, httpMethod.name(), excp,
            RestUtil.getDefaultErrorDeserializers());
        assertNotNull(actual);
    }

    @Test
    public void getExceptionForRestRequest_HttpStatusCodeException_EmptyResponseBody() {
        HttpStatusCodeException excp = mock(HttpStatusCodeException.class);
        when(excp.getResponseBodyAsString()).thenReturn("");
        when(excp.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        when(excp.getStatusText()).thenReturn("Internal server error");
        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;
        ServiceException actual = RestExceptionHelper.getExceptionForRestRequest("", null, url, httpMethod.name(), excp,
            RestUtil.getDefaultErrorDeserializers());
        assertNotNull(actual);
    }

    @Test
    public void getExceptionForRestRequest_HttpStatusCodeException_ResponseBody() {
        HttpStatusCodeException excp = mock(HttpStatusCodeException.class);
        when(excp.getResponseBodyAsString()).thenReturn("{\"message\":\"Test\"}");
        when(excp.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        when(excp.getStatusText()).thenReturn("Internal server error");
        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;
        ServiceException actual = RestExceptionHelper.getExceptionForRestRequest("", null, url, httpMethod.name(), excp,
            RestUtil.getDefaultErrorDeserializers());
        assertNotNull(actual);
    }

    @Test
    public void getExceptionForRestRequest_HttpStatusCodeException_ResponseBodyAsArray() {
        HttpStatusCodeException excp = mock(HttpStatusCodeException.class);
        when(excp.getResponseBodyAsString()).thenReturn("[{}]");
        when(excp.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        when(excp.getStatusText()).thenReturn("Internal server error");
        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;
        ServiceException actual = RestExceptionHelper.getExceptionForRestRequest("", null, url, httpMethod.name(), excp,
            RestUtil.getDefaultErrorDeserializers());
        assertNotNull(actual);
    }

    @Test
    public void getExceptionForRestRequest_HttpStatusCodeException_ResponseBodyAsMap_Detail() {
        HttpStatusCodeException excp = mock(HttpStatusCodeException.class);
        when(excp.getResponseBodyAsString()).thenReturn("{\"detail\":\"detail\"}");
        when(excp.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        when(excp.getStatusText()).thenReturn("Internal server error");
        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;
        ServiceException actual = RestExceptionHelper.getExceptionForRestRequest("", null, url, httpMethod.name(), excp,
            RestUtil.getDefaultErrorDeserializers());
        assertNotNull(actual);
    }

    @Test
    public void getExceptionForRestRequest_HttpStatusCodeException_ResponseBodyAsMap_Message() {
        HttpStatusCodeException excp = mock(HttpStatusCodeException.class);
        when(excp.getResponseBodyAsString()).thenReturn("{\"message\":\"message\",\"suggestion\":\"suggestion\"}");
        when(excp.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        when(excp.getStatusText()).thenReturn("Internal server error");
        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;
        ServiceException actual = RestExceptionHelper.getExceptionForRestRequest("", null, url, httpMethod.name(), excp,
            RestUtil.getDefaultErrorDeserializers());
        assertNotNull(actual);
    }

    @Test
    public void getExceptionForRestRequest_HttpStatusCodeException_ResponseBodyAsMap_MessageWithoutSuggestion() {
        HttpStatusCodeException excp = mock(HttpStatusCodeException.class);
        when(excp.getResponseBodyAsString()).thenReturn("{\"message\":\"message\"}");
        when(excp.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        when(excp.getStatusText()).thenReturn("Internal server error");
        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;
        ServiceException actual = RestExceptionHelper.getExceptionForRestRequest("", null, url, httpMethod.name(), excp,
            RestUtil.getDefaultErrorDeserializers());
        assertNotNull(actual);
    }

    @Test
    public void getExceptionForRestRequest_HttpStatusCodeException_ResponseBodyAsMap_ErrorDescription() {
        HttpStatusCodeException excp = mock(HttpStatusCodeException.class);
        when(excp.getResponseBodyAsString()).thenReturn("{\"error_description\":\"message\"}");
        when(excp.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        when(excp.getStatusText()).thenReturn("Internal server error");
        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;
        ServiceException actual = RestExceptionHelper.getExceptionForRestRequest("", null, url, httpMethod.name(), excp,
            RestUtil.getDefaultErrorDeserializers());
        assertNotNull(actual);
    }

    @Test
    public void getRestTemplate() {
        RestTemplate actual = this.restUtil.getRestTemplate();
        assertNotNull(actual);
    }

    @Test
    public void doExchange() {

        String expected = "Body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;
        Map<String, Object> uriVariables = new HashMap<>();
        uriVariables.put("key", "value");
        String actual = this.restUtil.doExchange(url, httpMethod, uriVariables, String.class);
        assertNotNull(actual);
        assertEquals(expected, actual);
    }

    @Test
    public void doExchange_withoutUriVariables() {

        String expected = "Body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;
        String actual = this.restUtil.doExchange(url, httpMethod, String.class);
        assertNotNull(actual);
        assertEquals(expected, actual);
    }

    @Test
    public void doExchange_withUrlMethodAndObject() {

        String expected = "Body";
        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;

        String actual = this.restUtil.doExchange(url, httpMethod, String.class, "Test");
        assertNotNull(actual);
        assertEquals(expected, actual);
    }

    @Test
    public void doExchangeArray() {
        String[] expected = new String[] { "1", "2" };
        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        this.restUtil.doExchangeArray(url, httpMethod, String.class, expected);
    }

    @Test
    public void getHttpEntity() {
        MultiValueMap<String, String> overrideHeaders = new HttpHeaders();

        HttpEntity actual = this.restUtil.getHttpEntity(overrideHeaders);
        assertNotNull(actual);
    }

    @Test
    public void doGet() {
        String url = "http://localhost/test";
        String expected = "Body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);
        String actual = this.restUtil.doGet(url, String.class);
        assertNotNull(actual);
    }

    @Test
    public void doGet_withOverrideHeaders() {
        String url = "http://localhost/test";
        HttpHeaders overrideHeaders = new HttpHeaders();
        String expected = "Body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doGet(url, String.class, overrideHeaders);
        assertNotNull(actual);
    }

    @Test
    public void doGet_withContentType() {
        String url = "http://localhost/test";
        String contentType = "application/json";
        String expected = "Body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doGet(url, String.class, contentType);
        assertNotNull(actual);
    }

    @Test
    public void doGet_withContentTypeAndOverrideHeaders() {
        String url = "http://localhost/test";
        String contentType = "application/json";
        HttpHeaders overrideHeaders = new HttpHeaders();
        String expected = "Body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doGet(url, String.class, contentType, overrideHeaders);
        assertNotNull(actual);
    }

    @Test
    public void doGet_withUriVariables() {
        String url = "http://localhost/test";
        Map<String, Object> uriVariables = new HashMap<>();
        String expected = "Body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doGet(url, String.class, uriVariables);
        assertNotNull(actual);
    }

    @Test
    public void doGet_withUriVariablesAndOverrideHeaders() {
        String url = "http://localhost/test";
        Map<String, Object> uriVariables = new HashMap<>();
        HttpHeaders overrideHeaders = new HttpHeaders();
        String expected = "Body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doGet(url, String.class, uriVariables, overrideHeaders);
        assertNotNull(actual);
    }

    @Test
    public void doGetArray_withUriVariablesAndOverrideHeaders() {

        String url = "http://localhost/test";
        Map<String, Object> uriVariables = new HashMap<>();
        HttpHeaders overrideHeaders = new HttpHeaders();

        String[] expected = new String[] { "1", "2" };

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String[] actual = this.restUtil.doGetArray(url, String.class, uriVariables, overrideHeaders);
        assertNotNull(actual);
    }

    @Test
    public void doGetArray() {

        String url = "http://localhost/test";

        String[] expected = new String[] { "1", "2" };

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String[] actual = this.restUtil.doGetArray(url, String.class);
        assertNotNull(actual);
    }

    @Test
    public void doPost() {

        String url = "http://localhost/test";

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPost(url, String.class, expected);
        assertNotNull(actual);
    }

    @Test
    public void doPost_withOverrideHeaders() {

        String url = "http://localhost/test";
        HttpHeaders overrideHeaders = new HttpHeaders();

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPost(url, String.class, expected, overrideHeaders);
        assertNotNull(actual);
    }

    @Test
    public void doPost_withContentTypeAndUriVariables() {

        String url = "http://localhost/test";
        String contentType = "application/json";
        Map<String, Object> uriVariables = new HashMap<>();

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPost(url, String.class, expected, contentType, uriVariables);
        assertNotNull(actual);
    }

    @Test
    public void doPost_withContentTypeAndUriVariablesAndOverrideHeaders() {

        String url = "http://localhost/test";
        String contentType = "application/json";
        Map<String, Object> uriVariables = new HashMap<>();
        HttpHeaders overrideHeaders = new HttpHeaders();

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPost(url, String.class, expected, contentType, uriVariables, overrideHeaders);
        assertNotNull(actual);
    }

    @Test
    public void doPost_withUriVariables() {

        String url = "http://localhost/test";
        Map<String, Object> uriVariables = new HashMap<>();

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPost(url, String.class, expected, uriVariables);
        assertNotNull(actual);
    }

    @Test
    public void doPost_withUriVariablesAndOverrideHeaders() {

        String url = "http://localhost/test";
        Map<String, Object> uriVariables = new HashMap<>();
        HttpHeaders overrideHeaders = new HttpHeaders();

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPost(url, String.class, expected, uriVariables, overrideHeaders);
        assertNotNull(actual);
    }

    @Test
    public void doPost_withInputsAndMultipartFileAndOverrideHeaders() {

        String url = "http://localhost/test";
        Map<String, Object> inputs = new HashMap<>();
        MultipartFile file = new MockMultipartFile("Test", new byte[0]);
        HttpHeaders overrideHeaders = new HttpHeaders();

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPost(url, String.class, inputs, file, overrideHeaders);
        assertNotNull(actual);
    }

    @Test
    public void doPost_withInputsAndMultipartFile() {

        String url = "http://localhost/test";
        Map<String, Object> inputs = new HashMap<>();
        MultipartFile file = new MockMultipartFile("Test", new byte[0]);

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPost(url, String.class, inputs, file);
        assertNotNull(actual);
    }

    @Test
    public void doPost_withUriVariablesAndInputsAndMultipartFile() {

        String url = "http://localhost/test";
        Map<String, Object> uriVariables = new HashMap<>();
        Map<String, Object> inputs = new HashMap<>();
        MultipartFile file = new MockMultipartFile("Test", new byte[0]);

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPost(url, uriVariables, String.class, inputs, file);
        assertNotNull(actual);
    }

    @Test
    public void doPost_withUriVariablesAndInputsAndResource() {

        String url = "http://localhost/test";
        Map<String, Object> uriVariables = new HashMap<>();
        Map<String, Object> inputs = new HashMap<>();
        Resource fileResource = new ByteArrayResource(new byte[0]);

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPost(url, uriVariables, String.class, inputs, fileResource);
        assertNotNull(actual);
    }

    @Test
    public void doPostArray() {

        String url = "http://localhost/test";

        String[] expected = new String[] { "1", "2" };

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        this.restUtil.doPostArray(url, expected);
    }

    @Test
    public void doPostArray_WithResponse() {

        String url = "http://localhost/test";

        String[] expected = new String[] { "1", "2" };

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String[] actual = this.restUtil.doPostArray(url, String.class, expected);
        assertNotNull(actual);
    }

    @Test
    public void doPut() {

        String url = "http://localhost/test";

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPut(url, String.class, expected);
        assertNotNull(actual);
    }

    @Test
    public void doPut_WithOverrideHeaders() {

        String url = "http://localhost/test";
        HttpHeaders overrideHeaders = new HttpHeaders();

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPut(url, String.class, expected, overrideHeaders);
        assertNotNull(actual);
    }

    @Test
    public void doPut_WithInputsAndFile() {

        String url = "http://localhost/test";
        Map<String, Object> inputs = new HashMap<>();
        MultipartFile file = new MockMultipartFile("Test", new byte[0]);

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPut(url, String.class, inputs, file);
        assertNotNull(actual);
    }

    @Test
    public void doPut_WithInputsAndFileAndOverrideHeaders() {

        String url = "http://localhost/test";
        Map<String, Object> inputs = new HashMap<>();
        MultipartFile file = new MockMultipartFile("Test", new byte[0]);
        HttpHeaders overrideHeaders = new HttpHeaders();

        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPut(url, String.class, inputs, file, overrideHeaders);
        assertNotNull(actual);
    }

    @Test
    public void doPatch() {

        String url = "http://localhost/test";
        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPatch(url, String.class, expected);
        assertNotNull(actual);
    }

    @Test
    public void doPatchArray_WithResponse() {

        String url = "http://localhost/test";

        String[] expected = new String[] { "1", "2" };

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String[] actual = this.restUtil.doPatchArray(url, String.class, expected);
        assertNotNull(actual);
    }

    @Test
    public void doPatch_WithOverrideHeaders() {

        String url = "http://localhost/test";
        String expected = "body";
        HttpHeaders overrideHeaders = new HttpHeaders();

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        String actual = this.restUtil.doPatch(url, String.class, expected, overrideHeaders);
        assertNotNull(actual);
    }

    @Test
    //TODO: assertions are needed here
    public void doDelete() {
        String url = "http://localhost/test";
        String expected = "body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        this.restUtil.doDelete(url);
    }

    @Test
    //TODO: assertions are needed here
    public void doDelete_WithOverrideHeaders() {

        String url = "http://localhost/test";
        String expected = "body";
        HttpHeaders overrideHeaders = new HttpHeaders();

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        this.restUtil.doDelete(url, overrideHeaders);
    }

    @Test
    public void exchange_shouldContructLinkHeaderForPartialContent() throws Exception {
        RequestContext.put(RequestContext.REQUEST_URL, "http://example.org");

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(RequestContext.LINK_HEADER, "<http://example.org?filter=uri=/asset/paginate>;rel=next");
        ResponseEntity<String> responseEntity = new ResponseEntity<>(headers, HttpStatus.PARTIAL_CONTENT);

        URI uri = new URI("http://some-url");
        doReturn(responseEntity).when(this.restTemplate).exchange(eq(uri), eq(HttpMethod.GET), any(HttpEntity.class),
            eq(String.class));

        this.restUtil.doExchange("http://some-url", HttpMethod.GET, String.class, String.class);
        assertThat(RequestContext.get(RequestContext.NEXT_PAGE_LINK),
            equalTo("<http://example.org?nextPageLink=/asset/paginate>;rel=next"));
    }

    //    @Test
    //    public void exchange_shouldThrowServiceExceptionsForMalFormedPaginateURLs() throws Exception {
    //        RequestContext.put(RequestContext.REQUEST_URL, "http://example.org");
    //
    //        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
    //        headers.add(RequestContext.LINK_HEADER, "<{}{}{}}>;rel=next");
    //        ResponseEntity<String> responseEntity = new ResponseEntity<String>(headers, HttpStatus.PARTIAL_CONTENT);
    //
    //        URI uri = new URI("http://some-url");
    //        doReturn(responseEntity).when(restTemplate)
    //            .exchange(eq(uri), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class));
    //
    //        thrown.expect(ServiceException.class);
    //        thrown.expectMessage("Invalid url '{}{}{}}'. Illegal character in path at index 0: {}{}{}}");
    //        restUtil.doExchange("http://some-url", HttpMethod.GET, String.class, String.class);
    //    }

    //    @Test
    //    public void exchange_shouldThrowWhenExceptionsForMalformedNextPageURIs() throws Exception {
    //        RequestContext.put(RequestContext.REQUEST_URL, "http://example.org");
    //
    //        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
    //        headers.add(RequestContext.LINK_HEADER, "<http://example.org/filter=WHOOPS>;rel=next");
    //        ResponseEntity<String> responseEntity = new ResponseEntity<String>(headers, HttpStatus.PARTIAL_CONTENT);
    //
    //        URI uri = new URI("http://some-url");
    //        doReturn(responseEntity).when(restTemplate)
    //            .exchange(eq(uri), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class));
    //
    //        thrown.expect(ServiceException.class);
    //        thrown.expectMessage("The next page link URI 'http://example.org/filter=WHOOPS' is invalid.");
    //        restUtil.doExchange("http://some-url", HttpMethod.GET, String.class, String.class);
    //    }

    //    @Test
    //    public void exchange_shouldThrowWhenPartialContentHasNoNextURI() throws Exception {
    //        RequestContext.put(RequestContext.REQUEST_URL, "http://example.org");
    //
    //        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
    //        headers.add(RequestContext.LINK_HEADER, "<http://example.org>;rel=next");
    //        ResponseEntity<String> responseEntity = new ResponseEntity<String>(headers, HttpStatus.PARTIAL_CONTENT);
    //
    //        URI uri = new URI("http://some-url");
    //        doReturn(responseEntity).when(restTemplate)
    //            .exchange(eq(uri), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class));
    //
    //        thrown.expect(ServiceException.class);
    //        thrown.expectMessage("The next page link URI 'http://example.org' is invalid.");
    //        restUtil.doExchange("http://some-url", HttpMethod.GET, String.class, String.class);
    //    }

    @Test(expected = ServiceException.class)
    public void getException() {
        generateRestUtilException(new RestClientException("Test"));
    }

    @Test(expected = ServiceException.class)
    public void getException_HttpStatusCodeException() {
        generateRestUtilException(new HttpServerErrorException(HttpStatus.UNAUTHORIZED));
    }

    @Test(expected = ServiceException.class)
    public void getException_ResourceAccessException() {
        generateRestUtilException(new ResourceAccessException("Test", new IOException("Cause")));
    }

    @Test(expected = ServiceException.class)
    public void getException_WebApplicationException() {
        String[] expected = new String[] { "1", "2" };
        final String url = "http://localhost/test";
        final HttpMethod httpMethod = HttpMethod.GET;

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        Response response = mock(Response.class);
        when(response.hasEntity()).thenReturn(true);
        when(response.getEntity()).thenReturn(entity);
        when(response.getStatus()).thenReturn(404);

        WebApplicationException ex = new WebApplicationException("Test", response);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenThrow(ex);

        this.restUtil.doExchangeArray(url, httpMethod, String.class, expected);
    }

    @Test(expected = ServiceException.class)
    public void getException_ServiceException() {
        generateRestUtilException(new ServiceException("Test", new IOException("Cause")));
    }

    @Test(expected = ServiceException.class)
    public void getException_HttpHostConnectException() {

        String expected = "Body";

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenReturn(entity);

        HttpMethod httpMethod = HttpMethod.GET;
        Map<String, Object> uriVariables = new HashMap<>();
        uriVariables.put("key", "value");
        this.restUtil.doExchange(null, httpMethod, uriVariables, String.class);
    }

    private void generateRestUtilException(Exception ex) {
        String[] expected = new String[] { "1", "2" };
        String url = "http://localhost/test";
        HttpMethod httpMethod = HttpMethod.GET;

        ResponseEntity entity = mock(ResponseEntity.class);
        when(entity.getBody()).thenReturn(expected);
        when(this.restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
            .thenThrow(ex);

        this.restUtil.doExchangeArray(url, httpMethod, String.class, expected);
    }
}
