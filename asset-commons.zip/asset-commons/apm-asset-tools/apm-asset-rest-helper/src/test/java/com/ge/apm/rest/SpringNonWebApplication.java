/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableAutoConfiguration
@ComponentScan({ "com.ge.apm.analytic.cache", "com.ge.apm.analytic.config", "com.ge.apm.rest.aspect",
    "com.ge.apm.rest.exception.handler" })
public class SpringNonWebApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {

        new SpringApplicationBuilder(SpringNonWebApplication.class).run(args);
    }
}