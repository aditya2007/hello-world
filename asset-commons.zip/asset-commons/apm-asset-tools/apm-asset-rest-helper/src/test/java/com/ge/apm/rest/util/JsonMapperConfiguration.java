/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.util;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.jsontype.NamedType;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.Primary;
import org.springframework.core.type.filter.AssignableTypeFilter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import com.ge.apm.asset.model.ITypedJson;
import com.ge.apm.util.JsonHelper;

import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;
import static com.fasterxml.jackson.databind.DeserializationFeature.UNWRAP_ROOT_VALUE;
import static com.ge.apm.util.JsonHelper.getJsonSubTypeAnnotation;

/**
 * Created by 212438472 on 9/29/17.
 */
public class JsonMapperConfiguration {

    @Bean
    public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter(ObjectMapper objectMapper) {
        MappingJackson2HttpMessageConverter jsonConverter = new MappingJackson2HttpMessageConverter();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        jsonConverter.setObjectMapper(objectMapper);
        return jsonConverter;
    }

    @Bean
    @Primary
    public ObjectMapper jacksonObjectMapper(Jackson2ObjectMapperBuilder builder) {
        ObjectMapper objectMapper = builder.build();
        initializeObjectMapper(objectMapper);
        return objectMapper;
    }

    public static void initializeObjectMapper(ObjectMapper objectMapper) {
        final String methodName = "AnalyticCommonConfig.initializeJsonHelperWithObjectMapper";
        objectMapper.setSerializationInclusion(Include.NON_NULL);
        objectMapper.configure(FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        objectMapper.configure(UNWRAP_ROOT_VALUE, false);

        String scanPackageName = "com.ge.apm.asset";

        ClassPathScanningCandidateComponentProvider scanner2 = new ClassPathScanningCandidateComponentProvider(false);

        scanner2.addIncludeFilter(new AssignableTypeFilter(ITypedJson.class));

        for (BeanDefinition bd : scanner2.findCandidateComponents(scanPackageName)) {

            Class<?> beanClazz = null;
            try {
                beanClazz = Class.forName(bd.getBeanClassName());
            } catch (ClassNotFoundException exception) {
                System.out.println("JSON_SUB_TYPE_METHOD_IS_NOT_FOUND");
                exception.printStackTrace();
            }

            Type jsonSubTypeAnnotation = getJsonSubTypeAnnotation(beanClazz);

            try {
                objectMapper.registerSubtypes(new NamedType(Class.forName(jsonSubTypeAnnotation.value().getName()),
                    jsonSubTypeAnnotation.name()));
            } catch (ClassNotFoundException exception) {
                System.out.println("Class not found when handling bean definition {}. " + exception.getMessage());
                exception.printStackTrace();
            }
        }

        JsonHelper.setDefaultObjectMapper(objectMapper);
    }
}
