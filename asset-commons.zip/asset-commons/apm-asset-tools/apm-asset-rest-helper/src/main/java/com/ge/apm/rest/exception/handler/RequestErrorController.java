/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.exception.handler;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.web.DefaultErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.boot.autoconfigure.web.ErrorMvcAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.ge.apm.common.support.RequestContext;
import com.ge.apm.rest.util.RestExceptionHelper;
import com.ge.apm.util.exceptions.RestServiceErrorException;

import static com.ge.apm.util.servlets.HttpServletUtils.getHttpMethod;
import static com.ge.apm.util.servlets.HttpServletUtils.getHttpStatus;
import static com.ge.apm.util.servlets.HttpServletUtils.getRequestUrl;

@Controller
@ConditionalOnWebApplication
@AutoConfigureBefore({ ErrorMvcAutoConfiguration.class })
public class RequestErrorController implements ErrorController {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestErrorController.class);

    public static final String ERROR_ATTRIBUTE = DefaultErrorAttributes.class.getName() + ".ERROR";

    @Override
    public String getErrorPath() {
        return "/error";
    }

    @RequestMapping(value = "/error")
    @ResponseBody
    public ResponseEntity<Object> error(HttpServletRequest request) {
        final String methodName = "RequestErrorController.error";

        RequestAttributes requestAttributes = new ServletRequestAttributes(request);

        HttpStatus status = getHttpStatus(request);
        String requestUrl = getRequestUrl(methodName, LOGGER, request);
        String httpMethod = getHttpMethod(methodName, LOGGER, request);

        LOGGER.info("RequestErrorController.TENANT: '{}'", request.getHeader(RequestContext.TENANT));

        @SuppressWarnings("ThrowableResultOfMethodCallIgnored") Throwable error = RestExceptionHelper.getError(requestAttributes);

        if (error == null) {
            String errorMessage = RestExceptionHelper.getAttribute(requestAttributes, "javax.servlet.error.message");
            if (!StringUtils.isBlank(errorMessage)) {
                return ControllerExcpHandler.getResponseEntity(
                    RestExceptionHelper
                        .getRestServiceErrorException(methodName, LOGGER, requestUrl, httpMethod, status, null
                        /* exception */, errorMessage));
            }
        }

        if (error == null) {
            String errorMessage = HttpStatus.INTERNAL_SERVER_ERROR.name();
            if (status == HttpStatus.NOT_FOUND) {
                errorMessage = "The resource requested is not found.";
            }
            return ControllerExcpHandler.getResponseEntity(
                RestExceptionHelper
                    .getRestServiceErrorException(methodName, LOGGER, requestUrl, httpMethod, status, null /* exception */,
                    errorMessage));
        }

        if (error instanceof RuntimeException) {

            if (error instanceof RestServiceErrorException) {
                return ControllerExcpHandler.getResponseEntity((RestServiceErrorException) error);
            }

            Throwable cause = error.getCause();
            String errorMessage = error.getMessage();

            if (cause != null) {
                errorMessage = cause.getMessage();
            }

            return ControllerExcpHandler.getResponseEntity(
                RestExceptionHelper.getRestServiceErrorException(methodName, LOGGER, requestUrl, httpMethod, status, (Exception) cause,
                    errorMessage));
        } else if (error instanceof Exception) {
            return ControllerExcpHandler.getResponseEntity(
                ControllerExcpHandler.getErrorMessageForExcptionType(request, null /* httpStatus */, (Exception) error));
        } else {
            LOGGER.error("", error);
            return ControllerExcpHandler.getResponseEntity(
                RestExceptionHelper
                    .getRestServiceErrorException(methodName, LOGGER, requestUrl, httpMethod, status, null /* exception */,
                    error.getMessage()));
        }
    }
}
