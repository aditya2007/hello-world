/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.util;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.ws.rs.WebApplicationException;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.protocol.HTTP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.NestedRuntimeException;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

import com.ge.apm.common.exception.DefaultErrorCode;
import com.ge.apm.common.exception.IErrorCode;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.rest.config.HttpConfig;
import com.ge.apm.rest.exception.codes.RestErrorCodes;
import com.ge.apm.rest.exception.responses.ApmViewSupport;
import com.ge.apm.rest.exception.responses.ErrorAndDescriptionResponse;
import com.ge.apm.rest.exception.responses.HttpClientErrorExceptionResponse;
import com.ge.apm.rest.exception.responses.IErrorDeserializer;
import com.ge.apm.rest.exception.responses.PxAnalyticsErrorResponse;
import com.ge.apm.util.FileResourceUtil;
import com.ge.apm.util.JsonHelper;
import com.ge.apm.util.exceptions.ExceptionHelper;
import com.ge.apm.util.exceptions.RestServiceErrorException;
import com.ge.apm.util.model.Artifact;

import static com.ge.apm.util.exceptions.ExceptionHelper.logException;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

@SuppressWarnings({ "WeakerAccess", "unused" })
public abstract class RestUtil {

    public static final String CONTENT_TYPE_DEFAULT = MediaType.APPLICATION_JSON_VALUE;

    protected static Logger logger = LoggerFactory.getLogger(RestUtil.class);

    protected RestTemplate restTemplate;

    protected RestTemplate restTemplateNoProxy;

    private boolean ignorePartialContent = false;

    private List<IErrorDeserializer> errorDeserializers = new ArrayList<>();

    public RestUtil(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
        this.errorDeserializers = getDefaultErrorDeserializers();
    }

    public static List<IErrorDeserializer> getDefaultErrorDeserializers() {
        List<IErrorDeserializer> errorDeserializers = new ArrayList<>();
        errorDeserializers.add(new ErrorAndDescriptionResponse());
        errorDeserializers.add(new PxAnalyticsErrorResponse());
        errorDeserializers.add(new HttpClientErrorExceptionResponse());
        errorDeserializers.add(new ApmViewSupport());
        return errorDeserializers;
    }

    public static URI getUriWithParams(String url, Map<String, Object> queryParams) {
        String methodName = "getUriWithParams";
        UriComponentsBuilder builder;
        try {
            builder = UriComponentsBuilder.fromHttpUrl(url);
        } catch (IllegalArgumentException exception) {
            logger.error(exception.getMessage(), exception);
            throw ExceptionHelper.getException(methodName, logger,
                DefaultErrorCode.create("INVALID_URL", exception.getMessage()));
        }

        if (queryParams == null) {
            return builder.build().encode().toUri();
        }
        for (Map.Entry<String, Object> entry : queryParams.entrySet()) {
            builder.queryParam(entry.getKey(), entry.getValue());
        }

        return builder.build().encode().toUri();
    }

    public static ServiceException getException(Exception actualException, String url, HttpMethod httpMethod,
        List<IErrorDeserializer> errorDeserializers) {
        String methodName = "RestUtil.getException";
        if (actualException instanceof RestServiceErrorException) {
            logException(methodName, logger, (ServiceException) actualException);
            return (ServiceException) actualException;
        } else if (actualException instanceof HttpStatusCodeException) {
            return RestExceptionHelper.getExceptionForRestRequest(methodName, logger, url, httpMethod.name(),
                (HttpStatusCodeException) actualException, errorDeserializers);
        } else if (actualException instanceof ResourceAccessException) {
            return RestExceptionHelper.getExceptionForRestRequest(methodName, logger, url, httpMethod,
                (ResourceAccessException) actualException);
        } else if (actualException instanceof NestedRuntimeException) {
            ServiceException exception = new ServiceException(
                DefaultErrorCode.create(BAD_REQUEST.name(), actualException.getMessage()));
            logException(methodName, logger, exception);
            return exception;
        } else if (actualException instanceof WebApplicationException) {
            return RestExceptionHelper.getExceptionForRestRequest(methodName, logger, url, httpMethod,
                (WebApplicationException) actualException);
        } else if (actualException instanceof IllegalArgumentException
            || actualException instanceof IllegalStateException) {
            ServiceException exception = RestExceptionHelper.getRestServiceErrorException(methodName, logger, url, httpMethod.name(),
                HttpStatus.INTERNAL_SERVER_ERROR, actualException, actualException.getMessage());
            logException(methodName, logger, exception);
            return exception;
        } else if (actualException instanceof ServiceException) {
            ServiceException serviceException = (ServiceException) actualException;
            return RestExceptionHelper.getRestServiceErrorException(methodName, logger, url, httpMethod.name(),
                RestExceptionHelper.getHttpStatusFromServiceExceptionCode(serviceException.getCode()), actualException,
                actualException.getMessage());
        }

        Throwable rootCause = actualException.getCause();

        if (rootCause instanceof HttpHostConnectException) {
            String errorMessage = String.format("The server related to the URL '%s' is down.", url);
            ServiceException serviceException = new ServiceException(
                DefaultErrorCode.create("SERVER_DOWN", errorMessage));
            logException(methodName, logger, serviceException);
            return serviceException;
        }

        String errorMessage;
        if (actualException instanceof NullPointerException) {
            errorMessage = "Null Pointer Exception";
        } else {
            errorMessage = actualException.getMessage();
        }

        ServiceException serviceException = new ServiceException(
            DefaultErrorCode.create(BAD_REQUEST.name(), errorMessage));
        logException(methodName, logger, actualException, serviceException);
        return serviceException;
    }

    public void registerErrorDeserializer(IErrorDeserializer deserializer) {
        if (deserializer == null) {
            throw new IllegalArgumentException("Error deserializer cannot be null.");
        }
        this.errorDeserializers.add(deserializer);
    }

    public RestTemplate getRestTemplate() {
        return this.restTemplate;
    }

    public void setIgnorePartialContent(boolean ignorePartialContent) {
        this.ignorePartialContent = ignorePartialContent;
    }

    // Methods that help in PredixAssetService
    public <R> ResponseEntity<R> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity,
        Class<R> responseType) {
        return exchange(url, method, requestEntity, responseType, null /*uriVariables*/);
    }

    private <T> ResponseEntity<T> exchange(URI url, HttpMethod httpMethod, HttpEntity<?> requestEntity,
        Class<T> responseType) {

        RestTemplate restTemplateToUse = this.restTemplate;
        if (HttpConfig.getHttpConfig() != null && HttpConfig.getHttpConfig().getUseProxy().equalsIgnoreCase("true")
            && url.toString().startsWith("http://localhost")) {
            if (this.restTemplateNoProxy == null) {
                synchronized (this) {
                    this.restTemplateNoProxy = new RestTemplate();
                    HttpConfig.configureRestTemplate(this.restTemplate, HttpConfig.getHttpConfig().getObjectMapper());
                }
            }
            restTemplateToUse = this.restTemplateNoProxy;
        }

        ResponseEntity<T> responseEntity = restTemplateToUse.exchange(url, httpMethod, requestEntity, responseType);

        if (!this.ignorePartialContent && responseEntity.getStatusCode() == HttpStatus.PARTIAL_CONTENT) {
            HttpHeaders responseHeaders = responseEntity.getHeaders();
            List<String> link = responseHeaders.get(RequestContext.LINK_HEADER);

            String linkUrls = getLinkUrls(link);

            if (!linkUrls.isEmpty()) {
                RequestContext.put(RequestContext.NEXT_PAGE_LINK, linkUrls);
            }
        }

        // reset the flag i.e. if ignorePartialContent is true, then set it to false.
        this.ignorePartialContent = false;

        return responseEntity;
    }

    private <T> ResponseEntity<T> exchange(String url, Map<String, Object> uriVariables, HttpMethod httpMethod,
        HttpEntity<?> requestEntity, Class<T> responseType) {

        RestTemplate restTemplateToUse = this.restTemplate;
        if (HttpConfig.getHttpConfig() != null && HttpConfig.getHttpConfig().getUseProxy().equalsIgnoreCase("true")
            && url.startsWith("http://localhost")) {
            if (this.restTemplateNoProxy == null) {
                synchronized (this) {
                    this.restTemplateNoProxy = new RestTemplate();
                    HttpConfig.configureRestTemplate(this.restTemplateNoProxy,
                        HttpConfig.getHttpConfig().getObjectMapper());
                }
            }
            restTemplateToUse = this.restTemplateNoProxy;
        }

        ResponseEntity<T> responseEntity;

        if (uriVariables == null) {
            responseEntity = restTemplateToUse.exchange(url, httpMethod, requestEntity, responseType);
        } else {
            responseEntity = restTemplateToUse.exchange(url, httpMethod, requestEntity, responseType, uriVariables);
        }

        if (!this.ignorePartialContent && responseEntity.getStatusCode() == HttpStatus.PARTIAL_CONTENT) {
            HttpHeaders responseHeaders = responseEntity.getHeaders();
            List<String> link = responseHeaders.get(RequestContext.LINK_HEADER);

            String linkUrls = getLinkUrls(link);

            if (!linkUrls.isEmpty()) {
                RequestContext.put(RequestContext.NEXT_PAGE_LINK, linkUrls);
            }
        }

        // reset the flag i.e. if ignorePartialContent is true, then set it to false.
        this.ignorePartialContent = false;

        return responseEntity;
    }

    @SuppressWarnings("SameParameterValue")
    public <R> ResponseEntity<R> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity,
        Class<R> responseType, Map<String, Object> uriVariables) {
        Object body = requestEntity.getBody();
        HttpHeaders headers = requestEntity.getHeaders();
        R response = doExchange(url, method, uriVariables /*queryParams*/, CONTENT_TYPE_DEFAULT /*contentType*/, responseType, body,
            headers);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    public <R> R doExchange(String url, HttpMethod httpMethod, Class<R> responseType) {
        return doExchange(url, httpMethod, null /*queryParams*/, responseType, null /*input*/);
    }

    public <I, R> R doExchange(String url, HttpMethod httpMethod, Map<String, Object> queryParams,
        Class<R> responseType, I input) {

        return doExchange(url, httpMethod, queryParams, CONTENT_TYPE_DEFAULT, responseType, input);
    }

    public <I, R> R doExchange(String url, HttpMethod httpMethod, Map<String, Object> queryParams, String contentType,
        Class<R> responseType, I input) {
        return doExchange(url, httpMethod, queryParams, contentType, responseType, input, null /*overrideHeaders*/);
    }

    public <R> R doExchange(String url, HttpMethod httpMethod, Map<String, Object> queryParams, Class<R> responseType) {
        return doExchange(url, httpMethod, queryParams, responseType, null);
    }

    public <I, R> R doExchange(String url, HttpMethod httpMethod, Class<R> responseType, I input) {

        return doExchange(url, httpMethod, null, responseType, input);
    }

    public <I, R> R doExchange(String url, HttpMethod httpMethod, Map<String, Object> queryParams, String contentType,
        Class<R> responseType, I input, MultiValueMap<String, String> overrideHeaders) {
        return doExchangeNew(getUrlWithVariablesUsingQueryParams(url, queryParams), queryParams, httpMethod,
            contentType, responseType, input, overrideHeaders);
    }

    private String getUrlWithVariablesUsingQueryParams(String url, Map<String, Object> queryParams) {
        if (queryParams == null || queryParams.isEmpty()) {
            return url;
        }

        StringBuilder urlSuffix = new StringBuilder();
        for (Map.Entry<String, Object> entry : queryParams.entrySet()) {
            if (urlSuffix.length() > 0) {
                urlSuffix.append("&");
            }
            urlSuffix.append(entry.getKey()).append("={").append(entry.getKey()).append("}");
        }

        return url + "?" + urlSuffix.toString();
    }

    public <I, R> R doExchangeNew(String url, Map<String, Object> uriVariables, HttpMethod httpMethod,
        String contentType, Class<R> responseType, I input, MultiValueMap<String, String> overrideHeaders) {
        return doExchangeNew(url, uriVariables, httpMethod, contentType, responseType, input, overrideHeaders, "file"
            /*uploadFileKeyName*/);
    }

    /**
     * @param overrideHeaders The header values override the values that this util sets. For example, if this parameter
     * already contains value for HttpHeaders.AUTHORIZATION, then this util will not set the value it normally sets.
     */
    public <I, R> R doExchangeNew(String url, Map<String, Object> uriVariables, HttpMethod httpMethod,
        String contentType, Class<R> responseType, I input, MultiValueMap<String, String> overrideHeaders,
        String uploadFileKeyName) {
        try {
            String format = "\n[{}] URL: '{}', accepts: '{}', responseType: '{}'\n";
            Object[] logargs = new Object[] { httpMethod.name(), url, contentType, responseType, "" };

            if (input != null && logger.isTraceEnabled()) {
                logargs[logargs.length - 1] = getInputJsonForLog(input, contentType, uploadFileKeyName);
                logger.trace(format + "\ninput: '{}'\n", logargs);
            } else {
                logger.info(format, logargs);
            }

            if (responseType == Artifact.class) {

                ResponseEntity<byte[]> responseEntity = exchange(url, uriVariables, httpMethod,
                    getHttpEntity(httpMethod, input, contentType, overrideHeaders), byte[].class);

                HttpHeaders responseHeaders = responseEntity.getHeaders();
                String filename;
                List<String> contentDispositionValues = responseHeaders.get(HttpHeaders.CONTENT_DISPOSITION);

                String unknownFilename = "unknown_file_name";
                if (contentDispositionValues.isEmpty()) {
                    filename = unknownFilename;
                } else {
                    String regex = "filename[^;=\\n]*=((['\"])(.*?)(\\2)|[^;\\n]*)";
                    Pattern pattern = Pattern.compile(regex);
                    Matcher matcher = pattern.matcher(contentDispositionValues.get(0));

                    if (!matcher.matches()) {
                        filename = unknownFilename;
                    } else {
                        filename = matcher.group(4);
                    }
                }

                Artifact artifact = new Artifact();
                artifact.setContentType(responseHeaders.getContentType().getType());
                artifact.setContentLength(responseHeaders.getContentLength());
                artifact.setFilename(filename);
                artifact.setBytes(responseEntity.getBody());
                //noinspection unchecked
                return (R) artifact;
            } else {
                ResponseEntity<R> responseEntity = exchange(url, uriVariables, httpMethod,
                    getHttpEntity(httpMethod, input, contentType, overrideHeaders), responseType);
                return responseEntity.getBody();
            }
        } catch (Exception exception) {
            throw getException(exception, url, httpMethod, this.errorDeserializers);
        }
    }

    private <I> String getInputJsonForLog(I input, String contentType, String uploadFileKeyName) {
        if (contentType.equalsIgnoreCase(MediaType.MULTIPART_FORM_DATA_VALUE) && input instanceof LinkedMultiValueMap) {
            //noinspection unchecked
            LinkedMultiValueMap<String, Object> uploadMap = (LinkedMultiValueMap<String, Object>) input;
            List<Object> fileEntityList = null;
            if (!StringUtils.isEmpty(uploadFileKeyName)) {
                fileEntityList = uploadMap.get(uploadFileKeyName);
            }

            if (fileEntityList == null) {
                return JsonHelper.toJson(input);
            }
            //noinspection unchecked
            HttpEntity<Resource> fileEntity = (HttpEntity<Resource>) fileEntityList.get(0);
            Resource fileResource = fileEntity.getBody();

            StringBuilder logMsg = new StringBuilder();

            logMsg.append("Uploading file '").append(fileResource.getFilename()).append("'");
            logMsg.append(System.lineSeparator());
            logMsg.append("inputs:");

            for (Map.Entry<String, List<Object>> entry : uploadMap.entrySet()) {
                if (entry.getKey().equalsIgnoreCase("file")) {
                    continue;
                }

                StringBuilder entryLog = new StringBuilder();
                entryLog.append(entry.getKey()).append("::");

                boolean firstElement = true;
                for (Object value : entry.getValue()) {

                    if (value instanceof String) {

                        if (!firstElement) {
                            entryLog.append(", ");
                        }

                        entryLog.append((String) value);
                        firstElement = false;
                    }
                }

                logMsg.append(entryLog.toString());
                logMsg.append(System.lineSeparator());
            }

            return logMsg.toString();
        }

        return JsonHelper.toJson(input);
    }

    private String getLinkUrls(List<String> links) {
        final String methodName = "RestUtil.getLinkUrls";

        String linkUrls = "";
        if (null == links) {
            return linkUrls;
        }

        for (String eachLink : links) {
            String resourceUri;
            String absoluteUrl = "";
            String nextPageRel = "";
            String linkUrl;

            // get the linking relation
            Pattern relPattern = Pattern.compile(">;(.*)");
            Matcher relMatcher = relPattern.matcher(eachLink);
            if (relMatcher.find()) {
                nextPageRel = relMatcher.group(1);
            }

            // get the absolute url
            Pattern completeUrlPattern = Pattern.compile("<(.*)>;");
            Matcher completeUrlMatcher = completeUrlPattern.matcher(eachLink);
            if (completeUrlMatcher.find()) {
                return decodeUrl(completeUrlMatcher.group(1));
            }

            completeUrlPattern = Pattern.compile("<(.*)>");
            completeUrlMatcher = completeUrlPattern.matcher(eachLink);
            if (completeUrlMatcher.find()) {
                return decodeUrl(completeUrlMatcher.group(1));
            }

            if (!StringUtils.isBlank(nextPageRel)) {
                resourceUri = getNextPageLinkUri(absoluteUrl);
                linkUrl = constructLinkUrl(resourceUri, nextPageRel);
                if (!linkUrl.isEmpty()) {
                    if (!linkUrls.isEmpty()) {
                        linkUrls = linkUrls.concat("," + linkUrl);
                    } else {
                        linkUrls = linkUrls.concat(linkUrl);
                    }
                }
            }
        }
        return linkUrls;
    }

    private String decodeUrl(String url) {
        final String methodName = "RestUtil.decodeUrl";
        try {
            return URLDecoder.decode(url, "UTF-8");
        } catch (UnsupportedEncodingException exception) {
            logger.error(exception.getMessage(), exception);
            throw ExceptionHelper.getException(methodName, logger, RestErrorCodes.ERROR_DECODING_URL, url, exception.getMessage());
        }
    }

    private String getNextPageLinkUri(String absoluteUrl) {
        String uri = "";
        if (!absoluteUrl.isEmpty()) {
            try {
                URL url = new URL(absoluteUrl);
                String[] queryParams = url.getQuery().split("&");

                for (String queryParam : queryParams) {
                    if (queryParam.contains("uri=")) {
                        // get the linking relation
                        Pattern relPattern = Pattern.compile("uri=(.*)");
                        Matcher relMatcher = relPattern.matcher(queryParam);
                        if (relMatcher.find()) {
                            uri = relMatcher.group(1);
                        }
                    }
                }
            } catch (MalformedURLException exception) {
                logger.error(exception.getMessage(), exception);
            }
        }
        return uri;
    }

    private String constructLinkUrl(String resourceUri, String nextPageRel) {
        String linkUrl = "";
        String requestUrl = "";
        if (RequestContext.contains(RequestContext.REQUEST_URL)) {
            Object requestContextObject = RequestContext.get(RequestContext.REQUEST_URL);
            Objects.requireNonNull(requestContextObject);
            requestUrl = requestContextObject.toString();
        }
        if (!requestUrl.isEmpty()) {
            if (!resourceUri.isEmpty()) {
                if (requestUrl.contains("?")) {
                    linkUrl = "<" + requestUrl + "&nextPageLink=" + resourceUri + ">;" + nextPageRel;
                } else {
                    linkUrl = "<" + requestUrl + "?nextPageLink=" + resourceUri + ">;" + nextPageRel;
                }
            }
        }
        return linkUrl;
    }

    public HttpEntity<?> getHttpEntity(MultiValueMap<String, String> overrideHeaders) {

        MultiValueMap<String, String> headers = getHeaders(false /*hasContent*/, CONTENT_TYPE_DEFAULT /*contentType*/,
            overrideHeaders);

        logHeaders(headers);

        return new HttpEntity<>(headers);
    }

    public <I> HttpEntity<I> getHttpEntity(HttpMethod httpMethod, I body, String contentType,
        MultiValueMap<String, String> overrideHeaders) {
        if (body == null) {
            if (httpMethod == HttpMethod.POST || httpMethod == HttpMethod.PATCH || httpMethod == HttpMethod.PUT) {
                IErrorCode errorCode = RestErrorCodes.NO_BODY_FOR_THE_REQUEST;
                String errorMessage = String.format(errorCode.message(), httpMethod.toString());
                logger.error("{}", errorMessage);
                ServiceException serviceException = new ServiceException(
                    DefaultErrorCode.create(errorCode.name(), errorMessage));
                logger.error("", serviceException);
                throw serviceException;
            }

            MultiValueMap<String, String> headers = getHeaders(false /*hasContent*/, contentType, overrideHeaders);

            logHeaders(headers);

            return new HttpEntity<>(headers);
        } else {

            MultiValueMap<String, String> headers = getHeaders(true /*hasContent*/, contentType, overrideHeaders);
            logHeaders(headers);
            return new HttpEntity<>(body, headers);
        }
    }

    private void logHeaders(MultiValueMap<String, String> headers) {
        // ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        // PrintStream printStream = new PrintStream(byteArrayOutputStream);
        // MapUtils.debugPrint(printStream, "RequestHeaders", headers);
        // logger.info("{}", new String(byteArrayOutputStream.toByteArray(), StandardCharsets.UTF_8));
    }

    /**
     * @param overrideHeaders The header values override the values that this util sets. For example, if this parameter
     * already contains value for HttpHeaders.AUTHORIZATION, then this util will not set the value it normally sets.
     */
    public MultiValueMap<String, String> getHeaders(boolean hasContent, String contentType,
        MultiValueMap<String, String> overrideHeaders) {

        MultiValueMap<String, String> headers;

        if (overrideHeaders != null) {
            headers = new LinkedMultiValueMap<>(overrideHeaders);
        } else {
            headers = new LinkedMultiValueMap<>();
        }

        String headerName;

        headerName = HttpHeaders.ACCEPT;
        // add the header if the overrideHeaders does not contain the header we are going to add.
        if (!headers.containsKey(headerName)) {
            headers.add(headerName, MediaType.APPLICATION_JSON_VALUE);
        }

        if (hasContent) {
            headerName = HttpHeaders.CONTENT_TYPE;
            if (!headers.containsKey(headerName)) {
                headers.add(headerName, contentType);
            }
        }

        headerName = HTTP.CONN_KEEP_ALIVE;
        if (!headers.containsKey(headerName)) {
            headers.add(headerName, "timeout=20, max=100");
        }

        return headers;
    }

    public <R> R doGet(String url, Class<R> responseType, MultiValueMap<String, String> overrideHeaders) {
        return doExchange(url, HttpMethod.GET, null /*queryParams*/, CONTENT_TYPE_DEFAULT, responseType, null /*input*/,
            overrideHeaders);
    }

    public <R> R doGet(String url, Class<R> responseType, String contentType) {
        return doExchange(url, HttpMethod.GET, null /*queryParams*/, contentType, responseType, null);
    }

    public <R> R doGet(String url, Class<R> responseType, String contentType,
        MultiValueMap<String, String> overrideHeaders) {
        return doExchange(url, HttpMethod.GET, null /*queryParams*/, contentType, responseType, null /*input*/,
            overrideHeaders);
    }

    public <R> R doGet(String url, Class<R> responseType, String contentType, Map<String, Object> queryParams) {
        return doExchange(url, HttpMethod.GET, queryParams, contentType, responseType, null /*input*/, null /*
        overrideHeaders */);
    }

    public <R> R doGet(String url, Class<R> responseType, Map<String, Object> queryParams) {
        return doExchange(url, HttpMethod.GET, queryParams, responseType);
    }

    public <R> R doGet(String url, Class<R> responseType, Map<String, Object> queryParams,
        MultiValueMap<String, String> overrideHeaders) {
        return doExchange(url, HttpMethod.GET, queryParams, CONTENT_TYPE_DEFAULT  /*contentType*/, responseType, null
            /*input*/, overrideHeaders);
    }

    public <R> R doGet(String url, Class<R> responseType) {
        return doExchange(url, HttpMethod.GET, responseType);
    }

    public byte[] doDownload(String url, Map<String, Object> queryParams,
        MultiValueMap<String, String> overrideHeaders) {
        return doExchange(url, HttpMethod.GET, queryParams, CONTENT_TYPE_DEFAULT /*contentType*/, byte[].class,
            overrideHeaders);
    }

    public Artifact doDownload(String url) {
        return doGet(url, Artifact.class, MediaType.APPLICATION_OCTET_STREAM_VALUE);
    }

    @SuppressWarnings("SameParameterValue")
    public Artifact doDownloadExt(String url, Map<String, Object> queryParams,
        MultiValueMap<String, String> overrideHeaders) {
        return doGet(url, Artifact.class, queryParams, overrideHeaders);
    }

    public <R> R[] doGetArray(String url, Class<R> responseType) {
        return doGetArray(url, responseType, null);
    }

    public <R> R[] doGetArray(String url, Class<R> responseType, Map<String, Object> queryParams) {
        return doExchangeArray(url, HttpMethod.GET, queryParams, responseType);
    }

    public <R> R[] doGetArray(String url, Class<R> responseType, Map<String, Object> queryParams,
        MultiValueMap<String, String> overrideHeaders) {
        return doExchangeArray(url, HttpMethod.GET, queryParams, responseType, null /*inputs*/, overrideHeaders);
    }

    // List<R> is input. Here the input type and the output
    public <I, R> R[] doExchangeArray(String url, HttpMethod httpMethod, Map<String, Object> queryParams,
        Class<R> responseType, I[] inputs, MultiValueMap<String, String> overrideHeaders) {
        return doExchangeArray(url, httpMethod, queryParams, CONTENT_TYPE_DEFAULT, responseType, inputs,
            overrideHeaders);
    }

    public <R> R[] doExchangeArray(String url, HttpMethod httpMethod, Map<String, Object> queryParams,
        Class<R> responseType) {
        MultiValueMap<String, String> overrideHeaders = null;
        //noinspection ConstantConditions
        return doExchangeArray(url, httpMethod, queryParams, responseType, null /*inputs*/, overrideHeaders);
    }

    public <I, R> R[] doExchangeArray(String url, HttpMethod httpMethod, Class<R> responseType, I[] inputs) {
        return doExchangeArray(url, httpMethod, null /*queryParams*/, responseType, inputs, null /*overrideHeaders*/);
    }

    public <I, R> R[] doExchangeArray(String url, HttpMethod httpMethod, Map<String, Object> queryParams,
        String contentType, Class<R> responseType, I[] inputs, MultiValueMap<String, String> overrideHeaders) {

        HttpEntity<?> httpEntity = getHttpEntity(httpMethod, inputs, contentType, overrideHeaders);

        String inputJson = null;
        if (inputs != null) {
            inputJson = JsonHelper.toJson(inputs);
        }

        return doExchangeArray(url, httpMethod, queryParams, responseType, httpEntity, inputJson);
    }

    public <I, R> R[] doExchangeArray(String url, HttpMethod httpMethod, Map<String, Object> queryParams,
        String contentType, Class<?> responseType, I input, MultiValueMap<String, String> overrideHeaders) {
        return doExchangeArray(url, httpMethod, queryParams, contentType, responseType, input, overrideHeaders,
            "file" /*uploadFileKeyName*/);
    }

    public <I, R> R[] doExchangeArray(String url, HttpMethod httpMethod, Map<String, Object> queryParams,
        String contentType, Class<?> responseType, I input, MultiValueMap<String, String> overrideHeaders,
        String uploadFileKeyName) {

        HttpEntity<?> httpEntity = getHttpEntity(httpMethod, input, contentType, overrideHeaders);

        String inputJson = null;
        if (input != null) {
            inputJson = getInputJsonForLog(input, contentType, uploadFileKeyName);
        }

        return doExchangeArray(url, httpMethod, queryParams, responseType, httpEntity, inputJson);
    }

    public <R> R[] doExchangeArray(String url, HttpMethod httpMethod, Map<String, Object> queryParams,
        Class<?> responseType, HttpEntity<?> httpEntity, String inputJson) {
        return doExchangeArray(getUrlWithVariablesUsingQueryParams(url, queryParams), queryParams, httpMethod,
            responseType, httpEntity, inputJson);
    }

    public <R> R[] doExchangeArray(String url, Map<String, Object> urlVariables, HttpMethod httpMethod,
        Class<?> responseType, HttpEntity<?> httpEntity, String inputJson) {

        try {
            if (responseType != null) {
                responseType = Array.newInstance(responseType, 0).getClass();
            }

            ResponseEntity<?> responseEntity;

            String format = "\n[{}] URL: '{}', parameters: '{}', responseType: '{}'\n";
            Object[] logArgs = new Object[] { httpMethod.name(), url, urlVariables, responseType, "" };

            if (inputJson != null && logger.isTraceEnabled()) {
                logArgs[logArgs.length - 1] = inputJson;
                logger.trace(format + "\ninput: '{}'\n", logArgs);
            } else {
                logger.info(format, logArgs);
            }

            responseEntity = exchange(url, urlVariables, httpMethod, httpEntity, responseType);
            //noinspection unchecked
            return (R[]) responseEntity.getBody();
        } catch (Exception exception) {
            throw getException(exception, url, httpMethod, this.errorDeserializers);
        }
    }

    public <R> R doPost(String url, Class<R> responseType, MultiValueMap<String, Object> additionalInputs,
        Map<String, MultipartFile> multiPartFiles, MultiValueMap<String, String> overrideHeaders) {
        return doUpload(url, HttpMethod.POST, null /* queryParams */, responseType, additionalInputs, multiPartFiles,
            overrideHeaders);
    }

    public <I, R> R doPost(String url, Class<R> responseType, I input) {
        return doExchange(url, HttpMethod.POST, responseType, input);
    }

    public <I, R> R doPost(String url, Class<R> responseType, I input, String contentType) {
        return doExchange(url, HttpMethod.GET, null /*queryParams*/, contentType, responseType, input, null
            /*overrideHeaders*/);
    }

    public <I, R> R doPost(String url, Class<R> responseType, I input, MultiValueMap<String, String> overrideHeaders) {
        return doExchange(url, HttpMethod.POST, null /*queryParams*/, CONTENT_TYPE_DEFAULT /*contentType*/,
            responseType, input, overrideHeaders);
    }

    public <I, R> R doPost(String url, Class<R> responseType, I input, String contentType,
        Map<String, Object> queryParams) {
        return doExchange(url, HttpMethod.POST, queryParams, contentType, responseType, input);
    }

    public <I, R> R doPost(String url, Class<R> responseType, I input, String contentType,
        Map<String, Object> queryParams, MultiValueMap<String, String> overrideHeaders) {
        return doExchange(url, HttpMethod.POST, queryParams, contentType, responseType, input, overrideHeaders);
    }

    public <I, R> R doPost(String url, Class<R> responseType, I input, Map<String, Object> queryParams) {
        return doExchange(url, HttpMethod.POST, queryParams, responseType, input);
    }

    public <I, R> R doPost(String url, Class<R> responseType, I input, Map<String, Object> queryParams,
        MultiValueMap<String, String> overrideHeaders) {
        return doExchange(url, HttpMethod.POST, queryParams, CONTENT_TYPE_DEFAULT /*contentType*/, responseType, input,
            overrideHeaders);
    }

    public <R> R doPost(String url, Class<R> responseType, Map<String, Object> inputs, MultipartFile file) {
        return doUpload(url, HttpMethod.POST, null, responseType, inputs, file, null /*overrideHeaders*/);
    }

    public <R> R doPost(String url, Map<String, Object> queryParams, Class<R> responseType, Map<String, Object> inputs,
        MultipartFile file) {
        return doUpload(url, HttpMethod.POST, queryParams, responseType, inputs, file, null /*overrideHeaders*/);
    }

    public <R> R doPost(String url, Map<String, Object> queryParams, Class<R> responseType, Map<String, Object> inputs,
        String fileKeyName, MultipartFile file) {
        return doUpload(url, HttpMethod.POST, queryParams, responseType, inputs, fileKeyName, file, null
            /*overrideHeaders*/);
    }

    public <R> R doPost(String url, Map<String, Object> queryParams, Class<R> responseType, Map<String, Object> inputs,
        Resource fileResource) {
        return doUpload(url, HttpMethod.POST, queryParams, responseType, inputs, "file" /* fileKeyName */, fileResource,
            null /*overrideHeaders*/);
    }

    public <R> R doPost(String url, Map<String, Object> queryParams, Class<R> responseType, Map<String, Object> inputs,
        String fileKeyName, Resource fileResource) {
        return doUpload(url, HttpMethod.POST, queryParams, responseType, inputs, fileKeyName, fileResource, null
            /*overrideHeaders*/);
    }

    public <R> R doPost(String url, Class<R> responseType, Map<String, Object> inputs, MultipartFile file,
        MultiValueMap<String, String> overrideHeaders) {
        return doUpload(url, HttpMethod.POST, null, responseType, inputs, file, overrideHeaders);
    }

    @SuppressWarnings("SameParameterValue")
    private <R> R doUpload(String url, HttpMethod httpMethod, Map<String, Object> queryParams, Class<R> responseType,
        MultiValueMap<String, Object> additionalInputs, Map<String, MultipartFile> multiPartFiles,
        MultiValueMap<String, String> overrideHeaders) {

        Map<String, Resource> fileResources = new HashMap<>();

        multiPartFiles.forEach((key, value) -> {
            Resource fileResource = FileResourceUtil.getResource(value);
            fileResources.put(key, fileResource);
        });

        MultiValueMap<String, Object> uploadMap = getUploadHeaders(additionalInputs, fileResources);

        return doExchange(url, httpMethod, queryParams, MediaType.MULTIPART_FORM_DATA_VALUE, responseType, uploadMap,
            overrideHeaders);
    }

    private <R> R doUpload(String url, HttpMethod httpMethod, Map<String, Object> queryParams, Class<R> responseType,
        Map<String, Object> inputs, String fileKeyName, Resource fileResource,
        MultiValueMap<String, String> overrideHeaders) {

        MultiValueMap<String, Object> uploadMap = getUploadHeaders(inputs, fileKeyName, fileResource);

        return doExchangeNew(url, queryParams, httpMethod, MediaType.MULTIPART_FORM_DATA_VALUE, responseType, uploadMap,
            overrideHeaders, fileKeyName);
    }

    private <R> R doUpload(String url, HttpMethod httpMethod, Map<String, Object> queryParams, Class<R> responseType,
        Map<String, Object> inputs, String fileKeyName, MultipartFile file,
        MultiValueMap<String, String> overrideHeaders) {
        Resource fileResource = null;
        if (file != null) {
            fileResource = FileResourceUtil.getResource(file);
        }
        return doUpload(url, httpMethod, queryParams, responseType, inputs, fileKeyName, fileResource, overrideHeaders);
    }

    private <R> R doUpload(String url, HttpMethod httpMethod, Map<String, Object> queryParams, Class<R> responseType,
        Map<String, Object> inputs, MultipartFile file, MultiValueMap<String, String> overrideHeaders) {
        return doUpload(url, httpMethod, queryParams, responseType, inputs, "file" /*fileKeyName*/, file,
            overrideHeaders);
    }

    private MultiValueMap<String, Object> getUploadHeaders(MultiValueMap<String, Object> additionalInputs,
        Map<String, Resource> fileResources) {

        HttpHeaders fileHeaders = new HttpHeaders();
        fileHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);
        fileResources.forEach((key, fileResource) -> {
            HttpEntity<Resource> fileEntity = new HttpEntity<>(fileResource, fileHeaders);
            additionalInputs.add(key, fileEntity);
        });

        return additionalInputs;
    }

    private MultiValueMap<String, Object> getUploadHeaders(Map<String, Object> inputs, String fileKeyName,
        Resource fileResource) {
        MultiValueMap<String, Object> uploadMap = new LinkedMultiValueMap<>();
        if (inputs != null) {
            inputs.entrySet().forEach(entry -> uploadMap.add(entry.getKey(), entry.getValue()));
        }

        HttpHeaders fileHeaders = new HttpHeaders();
        fileHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);

        if (fileResource != null) {
            HttpEntity<Resource> fileEntity = new HttpEntity<>(fileResource, fileHeaders);
            uploadMap.add(fileKeyName, fileEntity);
        }

        return uploadMap;
    }

    public <I> void doPostArray(String url, I[] inputs) {
        doExchangeArray(url, HttpMethod.POST, null, inputs);
    }

    public <I, R> R[] doPostArray(String url, Class<R> responseType, I[] inputs) {
        return doExchangeArray(url, HttpMethod.POST, responseType, inputs);
    }

    public <I, R> R[] doPostArray(String url, Class<R> responseType, I[] inputs,
        MultiValueMap<String, String> overrideHeaders) {
        return doExchangeArray(url, HttpMethod.POST, null /*queryParams*/, responseType, inputs, overrideHeaders);
    }

    public <I, R> R[] doPostArray(String url, Class<R> responseType, I input, Map<String, Object> queryParams,
        MultiValueMap<String, String> overrideHeaders) {
        return doExchangeArray(url, HttpMethod.POST, queryParams, CONTENT_TYPE_DEFAULT /*contentType*/, responseType,
            input, overrideHeaders);
    }

    public <R> R[] doPostArray(String url, Class<R> responseType, Map<String, Object> inputs, MultipartFile file,
        MultiValueMap<String, String> overrideHeaders) {
        Resource fileResource = FileResourceUtil.getResource(file);

        return doUploadArray(url, HttpMethod.POST, null /*queryParams*/, responseType, inputs, fileResource,
            overrideHeaders);
    }

    public <R> R[] doPostArray(String url, Class<R> responseType, Map<String, Object> inputs, MultipartFile file) {
        Resource fileResource = FileResourceUtil.getResource(file);

        return doUploadArray(url, HttpMethod.POST, null /*queryParams*/, responseType, inputs, fileResource, null
            /*overrideHeaders*/);
    }

    @SuppressWarnings("SameParameterValue")
    private <R> R[] doUploadArray(String url, HttpMethod httpMethod, Map<String, Object> queryParams,
        Class<R> responseType, Map<String, Object> inputs, Resource fileResource,
        MultiValueMap<String, String> overrideHeaders) {

        MultiValueMap<String, Object> uploadMap = getUploadHeaders(inputs, "file" /* fileKeyName */, fileResource);

        return doExchangeArray(url, httpMethod, queryParams, MediaType.MULTIPART_FORM_DATA_VALUE, responseType,
            uploadMap, overrideHeaders);
    }

    public <I, R> R doPut(String url, Class<R> responseType, I input) {
        return doExchange(url, HttpMethod.PUT, responseType, input);
    }

    public <I, R> R doPut(String url, Class<R> responseType, I input, Map<String, Object> queryParams) {
        return doExchange(url, HttpMethod.PUT, queryParams, CONTENT_TYPE_DEFAULT /*contentType*/, responseType, input,
            null /*overrideHeaders*/);
    }

    public <I, R> R doPut(String url, Class<R> responseType, I input, MultiValueMap<String, String> overrideHeaders) {
        return doExchange(url, HttpMethod.PUT, null /*queryParams*/, CONTENT_TYPE_DEFAULT /*contentType*/, responseType,
            input, overrideHeaders);
    }

    public <I, R> R doPut(String url, Class<R> responseType, I input, Map<String, Object> queryParams,
        MultiValueMap<String, String> overrideHeaders) {
        return doExchange(url, HttpMethod.PUT, queryParams, CONTENT_TYPE_DEFAULT /*contentType*/, responseType, input,
            overrideHeaders);
    }

    public <R> R doPut(String url, Class<R> responseType, Map<String, Object> inputs, MultipartFile file) {
        return doUpload(url, HttpMethod.PUT, null /* queryParams */, responseType, inputs, file, null
            /*overrideHeaders*/);
    }

    public <R> R doPut(String url, Class<R> responseType, Map<String, Object> inputs, String fileKeyName,
        MultipartFile file) {
        return doUpload(url, HttpMethod.PUT, null /* queryParams */, responseType, inputs, fileKeyName, file, null
            /*overrideHeaders*/);
    }

    public <R> R doPut(String url, Class<R> responseType, Map<String, Object> inputs, Resource file) {
        return doUpload(url, HttpMethod.PUT, null /* queryParams */, responseType, inputs, "file" /* fileKeyName */,
            file, null /*overrideHeaders*/);
    }

    public <R> R doPut(String url, Class<R> responseType, Map<String, Object> inputs, MultipartFile file,
        MultiValueMap<String, String> overrideHeaders) {
        return doUpload(url, HttpMethod.PUT, null, responseType, inputs, file, overrideHeaders);
    }

    public <I, R> R doPatch(String url, Class<R> responseType, I input) {
        return doExchange(url, HttpMethod.PATCH, responseType, input);
    }

    public <I, R> R doPatch(String url, Class<R> responseType, I input, MultiValueMap<String, String> overrideHeaders) {
        return doExchange(url, HttpMethod.PATCH, null /*queryParams*/, CONTENT_TYPE_DEFAULT /*contentType*/,
            responseType, input, overrideHeaders);
    }

    public <I, R> R doPatch(String url, Class<R> responseType, I input, Map<String, Object> queryParams,
        MultiValueMap<String, String> overrideHeaders) {
        return doExchange(url, HttpMethod.PATCH, queryParams, CONTENT_TYPE_DEFAULT /*contentType*/, responseType, input,
            overrideHeaders);
    }

    public <I, R> R[] doPatchArray(String url, Class<R> responseType, I[] inputs) {
        return doExchangeArray(url, HttpMethod.PATCH, responseType, inputs);
    }

    public void doDelete(String url) {
        doDelete(url, null /*overrideHeaders*/);
    }

    public void doDelete(String url, MultiValueMap<String, String> overrideHeaders) {
        HttpMethod httpMethod = HttpMethod.DELETE;
        try {
            exchange(url, httpMethod, getHttpEntity(overrideHeaders), Void.class);
        } catch (Exception exception) {
            throw getException(exception, url, httpMethod, this.errorDeserializers);
        }
    }

    public <T> ResponseEntity<T> postForEntity(String url, HttpEntity<?> requestEntity, Class<T> responseType) {
        Object body = requestEntity.getBody();
        HttpHeaders headers = requestEntity.getHeaders();
        T response = doExchange(url, HttpMethod.POST, null /*queryParams*/, CONTENT_TYPE_DEFAULT /*contentType*/, responseType, body,
            headers);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    // @SuppressWarnings("Duplicates")
    // private String getNextPageLinkUri(String absoluteUrl) {
    //     String methodName = "getNextPageLinkUri";
    //
    //     try {
    //         List<NameValuePair> params = URLEncodedUtils.parse(new URI(absoluteUrl.replace(" ", "%20")), "UTF-8");
    //
    //         for (NameValuePair param : params) {
    //             if (!param.getName().equalsIgnoreCase("filter")) {
    //                 continue;
    //             }
    //             String value = param.getValue();
    //             String[] values = value.split("=");
    //             if (values.length != 2 || !values[0].equalsIgnoreCase("uri")) {
    //                 throw RestExceptionHelper.getExceptionForErrorCode(methodName, logger,
    //                     RestErrorCodes.PREDIX_NEXT_PAGE_LINK_IS_INVALID, absoluteUrl);
    //             }
    //             return values[1];
    //         }
    //     } catch (URISyntaxException exception) {
    //         throw RestExceptionHelper
    //             .getExceptionForErrorCode(exception, methodName, logger, RestErrorCodes.INVALID_URL, absoluteUrl,
    //                 exception.getMessage());
    //     }
    //
    //     throw RestExceptionHelper.getExceptionForErrorCode(methodName, logger,
    //         RestErrorCodes.PREDIX_NEXT_PAGE_LINK_IS_INVALID, absoluteUrl);
    // }

    public static void initTenantUuidHeaderIfNotExist(MultiValueMap<String, String> headers) {
        String headerName;
        String headerValue;

        headerName = RequestContext.TENANT;
        if (!headers.containsKey(headerName)) {
            headerValue = RequestContext.get(RequestContext.TENANT_UUID, String.class);
            if (!StringUtils.isBlank(headerValue)) {
                headers.add(headerName, headerValue);
            }
        }
    }

    public static void initAuthorizationHeaderIfNotExist(MultiValueMap<String, String> headers) {
        String headerName;
        String headerValue;

        headerName = org.springframework.http.HttpHeaders.AUTHORIZATION;
        if (!headers.containsKey(headerName)) {
            headerValue = RequestContext.get(RequestContext.AUTHORIZATION, String.class);
            if (!StringUtils.isBlank(headerValue)) {
                headers.add(headerName, headerValue);
            }
        }
    }
}
