/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.exception.responses;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.StringUtils;

import com.ge.apm.util.JsonHelper;
import com.ge.apm.util.exceptions.model.RestServiceError.ErrorInfo;

@SuppressWarnings("WeakerAccess")
@Getter
@Setter
@ToString
public class HttpClientErrorExceptionResponse implements IErrorDeserializer {

    // HttpClientErrorException format.
    //
    //    {
    //        "timestamp": 1464650375791,
    //        "status": 405,
    //        "error": "Method Not Allowed",
    //        "exception": "org.springframework.web.HttpRequestMethodNotSupportedException",
    //        "message": "Request method 'POST' not supported",
    //        "path": "/v1/alarms/filter"
    //    }

    private Date timestamp;

    private int status;

    private String error;

    private String exception;

    private String message;

    private String path;

    @Override
    public List<ErrorInfo> getErrorResponse(String responseJson) {
        HttpClientErrorExceptionResponse httpClientExceptionResponse = null;

        try {
            httpClientExceptionResponse = JsonHelper.fromJsonNoExcpLog(responseJson,
                HttpClientErrorExceptionResponse.class, false /*unwrapRootValue*/, false /*failOnUnknownProperties*/,
                null /*registerModules*/);
        } catch (Exception excp) { // NOSONAR
            // Rest Util calls all the registered classes to check if the input json matches the given class.
            // if the current input json is not of this class, then JsonHelper might throw an error. We can
            // ignore these exceptions and initialize message as null;

        }

        if (httpClientExceptionResponse == null) {
            return null;
        }

        List<ErrorInfo> errorResponses = new ArrayList<>();
        if ((httpClientExceptionResponse.getTimestamp() != null) && !StringUtils.isBlank(
            httpClientExceptionResponse.getError()) && !StringUtils.isBlank(httpClientExceptionResponse.getMessage())) {

            errorResponses.add(
                new ErrorInfo(null /* httpStatusCode */, String.valueOf(httpClientExceptionResponse.getStatus()),
                    httpClientExceptionResponse.getMessage(), "" /* detail */, "" /* requestId */));
        }

        if (!errorResponses.isEmpty()) {
            return errorResponses;
        }

        return null;
    }
}
