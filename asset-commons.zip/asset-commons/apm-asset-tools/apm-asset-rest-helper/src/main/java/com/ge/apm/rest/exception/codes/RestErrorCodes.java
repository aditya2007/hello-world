/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.exception.codes;

import com.ge.apm.common.exception.IErrorCode;

public enum RestErrorCodes implements IErrorCode {
    INTERNAL_SERVER_ERROR("Internal Server error. Please contact support."),
    NO_BODY_FOR_THE_REQUEST("Invalid request. The HTTP body cannot be empty for '%s' request."),
    ERROR_RETRIEVING_CREDENTIAL_FOR_SERVICE(
        "Error retrieving the credential information for the tenant '%s' and service '%s'. %s"),
    RESOURCE_NOT_FOUND("The requested resource '%s' is not found."),
    PROXY_HOST_EMPTY("The proxy host value is not provided."),
    PROXY_PORT_EMPTY("The proxy port value is not provided."),
    TENANT_NOT_FOUND("Tenant identifier is not found in tenant context"),
    INVALID_INSTANCE_JSON_PATH("The service instances JSON does not contain data for the property '%s'."),
    INSTANCE_JSON_PATH_VALUE_IS_EMPTY("The service instance '%s' JSON has empty value for the property '%s'."),
    INSTANCE_PATH_NOT_PROVIDED("The property '%s' value is empty for the service instance '%s'."),
    ERROR_CONVERTING_JSON_TO_NODE("Error converting the JSON into JsonNode."),
    SERVICE_INSTANCE_PROPS_ALREADY_REGISTERED("Service instance properties for '%s' has already been registered."),
    VALUE_NOT_FOUND_FOR_SERVICE_PATH("The service instance '%s' does not have value for the path '%s'."),
    SERVICE_INSTANCE_INFO_NOT_AVAILABLE("Service instance information is not available for '%s'."),
    SERVICE_INSTANCES_INFO_NOT_INITIALIZED(
        "Service instances information has not been initialized for the " + "tenant '%s'."),
    SERVICE_INSTANCE_INFO_NOT_INITIALIZED(
        "Service instance information has not been initialized for the " + "service '%s' in the tenant '%s'."),
    ERROR_READING_BYTES_FROM_MULTIPART_FILE("Error reading data for the file '%s'. %s"),
    SERVER_UNAVAILABLE("The server '%s' is not available."),
    REQUEST_TIMED_OUT("The request to the resource '%s' timed-out."),
    ERROR_DECODING_URL("Error decoding the url '%s'. %s"),
    CONNECTION_TIMED_OUT("Unable to get connection to the resource '%s'.");

    private String message;

    RestErrorCodes(String s) {
        this.message = s;
    }

    @Override
    public String message() {
        return this.message;
    }
}
