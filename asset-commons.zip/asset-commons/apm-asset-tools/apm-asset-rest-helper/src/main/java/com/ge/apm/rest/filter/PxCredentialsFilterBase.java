/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.filter;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.ge.apm.common.config.IServiceInfoProvider;
import com.ge.apm.util.exceptions.ExceptionHelper;

@SuppressWarnings({ "unused", "WeakerAccess" })
public abstract class PxCredentialsFilterBase<T extends IServiceInfoProvider> extends ServiceCredentialsFilter<T> {

    private static Logger logger = LoggerFactory.getLogger(PxCredentialsFilterBase.class);

    @Value("${use.instance.info.from.config:true}")
    private boolean useInstanceFromConfigUrl;

    public PxCredentialsFilterBase(String serviceInfoKey, String serviceRestTemplateKey) {
        super(serviceInfoKey, serviceRestTemplateKey);
    }

    public PxCredentialsFilterBase(String serviceInfoKey, String serviceRestTemplateKey, int socketReadTimeoutMs,
        boolean throwOnServiceNotFound) {
        super(serviceInfoKey, serviceRestTemplateKey, socketReadTimeoutMs, throwOnServiceNotFound);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
        String methodName = "PxCredentialsFilterBase::doFilterInternal";
        try {
            super.doFilterInternal(request, response, filterChain);
        } catch (ServletException | IOException e) {
            logger.error(e.getMessage(), e);
            throw ExceptionHelper.getException(methodName, logger, e.getMessage());
        }
        postProcessing();
    }

    public abstract void postProcessing();
}