/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.exception.responses;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.StringUtils;

import com.ge.apm.util.JsonHelper;
import com.ge.apm.util.exceptions.model.RestServiceError.ErrorInfo;

@Getter
@Setter
@ToString
public class PxAnalyticsErrorResponse implements IErrorDeserializer {

    // Expected error responses:
    //
    //    {
    //        "error": "invalid_token",
    //        "error_description": "Token is expired"
    //    }
    //
    // or
    //
    //    {
    //        "detail": "Unable to retrieve. Analytic catalog entry does not exist for id [4ab4-85f5-d664f149b179b]",
    //        "code": "CATALOG003",
    //        "severity": "3",
    //        "message": "Unable to retrieve. Analytic catalog entry does not exist.",
    //        "parameters": [
    //        "6485d3bb-56af-4ab4-85f5-d664f149b179b"
    //        ]
    //    }

    private String detail;

    private String code;

    private String severity;

    private String message;

    private List<String> parameters;

    @Override
    public List<ErrorInfo> getErrorResponse(String responseJson) {

        PxAnalyticsErrorResponse pxAnalyticsErrorResponse = null;

        try {
            pxAnalyticsErrorResponse = JsonHelper.fromJsonNoExcpLog(responseJson, PxAnalyticsErrorResponse.class,
                false /*unwrapRootValue*/, false /*failOnUnknownProperties*/, null /*registerModules*/);
        } catch (Exception excp) { // NOSONAR
            // Rest Util calls all the registered classes to check if the input json matches the given class.
            // if the current input json is not of this class, then JsonHelper might throw an error. We can
            // ignore these exceptions and initialize message as null;
        }

        if (pxAnalyticsErrorResponse == null) {
            return null;
        }

        List<ErrorInfo> errorResponses = new ArrayList<>();
        if (!StringUtils.isBlank(pxAnalyticsErrorResponse.getMessage())
            && !StringUtils.isBlank(pxAnalyticsErrorResponse.getCode())) {
            errorResponses.add(new ErrorInfo(null /* httpStatusCode */, pxAnalyticsErrorResponse.getCode(),
                pxAnalyticsErrorResponse.getMessage(), pxAnalyticsErrorResponse.getDetail(), "" /* requestId */));
        }

        if (!errorResponses.isEmpty()) {
            return errorResponses;
        }

        return null;
    }
}
