/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.util;

import java.io.UnsupportedEncodingException;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Base64;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.common.AuthenticationScheme;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.util.exceptions.ExceptionHelper;
import com.ge.apm.util.exceptions.RestServiceErrorException;

public class BearerTokenUtil {
    private static final Logger logger = LoggerFactory.getLogger(BearerTokenUtil.class);

    public static String getBearerToken(String errorMsgPrefixInCaseOfError, BearerTokenGenInput bearerTokenGenInput) {
        String methodName = "BearerTokenUtil.getBearerToken";
        String basicAuthorization;
        MultiValueMap<String, String> formParams = new LinkedMultiValueMap<>();
        if (bearerTokenGenInput.getGrantType() == GrantType.GRANT_TYPE_PASSWORD) {
            formParams.add("grant_type", "password");
            formParams.add("username", bearerTokenGenInput.getUserName());
            formParams.add("password", bearerTokenGenInput.getPassword());
        } else {
            formParams.add("grant_type", "client_credentials");
        }

        if (bearerTokenGenInput.getScopes() != null && bearerTokenGenInput.getScopes().length > 0) {
            //noinspection ConfusingArgumentToVarargsMethod
            formParams.set("scope", String.join(",", bearerTokenGenInput.getScopes()));
        }

        basicAuthorization = getBasicAuthorization(bearerTokenGenInput.getClientId(),
            bearerTokenGenInput.getClientSecret());

        MultiValueMap<String, String> overrideHeaders = new HttpHeaders();
        overrideHeaders.set(HttpHeaders.AUTHORIZATION, basicAuthorization);
        overrideHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED.toString());

        UaaResponse uaaResponse;
        try {
            uaaResponse = bearerTokenGenInput.getRestUtil().doPost(bearerTokenGenInput.getUaaUrl(), UaaResponse.class,
                formParams, overrideHeaders);
        } catch (RestServiceErrorException restServiceErrorException) {
            String errorMessage = MessageFormat.format(
                errorMsgPrefixInCaseOfError + " One of the following values could be in-correct: ClientId: ''{0}'', "
                    + "UserName: ''{1}'', Password: ''{2}'' or clientSecret. Actual error message while generating "
                    + "token is ''{3}''", bearerTokenGenInput.getClientId(), bearerTokenGenInput.getUserName(),
                bearerTokenGenInput.getPassword(), restServiceErrorException.getActualMessage());
            logger.error(errorMessage, restServiceErrorException);

            throw ExceptionHelper.getException(methodName, logger, errorMessage);
        }

        return uaaResponse.getTokenType() + " " + uaaResponse.getAccessToken();
    }

    public static String getBasicAuthorization(String clientId, String clientSecret) {
        try {
            if (clientSecret == null) {
                clientSecret = "";
            }
            return "Basic " + Base64.getEncoder().encodeToString((clientId + ":" + clientSecret).getBytes("utf-8"));
        } catch (UnsupportedEncodingException e) {
            String errorMessage = String.format(
                "Error creating Base64 encoded string for clientId '%s' and clientSecret '%s'. %s", clientId,
                clientSecret, e.getMessage());
            logger.error(errorMessage, e);
            throw new ServiceException(errorMessage);
        }
    }

    public static ClientCredentialsResourceDetails getClientTypeResourceDetails(
        BearerTokenGenInput bearerTokenGenInput) {

        ClientCredentialsResourceDetails resourceDetails = new ClientCredentialsResourceDetails();

        resourceDetails.setAuthenticationScheme(AuthenticationScheme.header);
        resourceDetails.setAccessTokenUri(bearerTokenGenInput.getUaaUrl());

        resourceDetails.setClientId(bearerTokenGenInput.getClientId());
        resourceDetails.setClientSecret(bearerTokenGenInput.getClientSecret());

        if (bearerTokenGenInput.getScopes() != null) {
            resourceDetails.setScope(Arrays.asList(bearerTokenGenInput.getScopes()));
        }
        return resourceDetails;
    }

    @Getter
    @Setter
    public static class BearerTokenGenInput {
        private RestUtil restUtil;

        private String uaaUrl;

        private GrantType grantType;

        private String userName;

        private String password;

        private String clientId;

        private String clientSecret;

        private String[] scopes;
    }

    public enum GrantType {
        GRANT_TYPE_PASSWORD,
        GRANT_TYPE_CLIENT_CREDENTIALS
    }

    @ToString
    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class UaaResponse {
        @JsonProperty("access_token")
        private String accessToken;

        @JsonProperty("token_type")
        private String tokenType;

        @JsonProperty("refresh_token")
        private String refreshToken;

        @JsonProperty("expires_in")
        private String expiresIn;

        @JsonProperty("scope")
        private String scope;

        @JsonProperty("jti")
        private String jti;
    }
}
