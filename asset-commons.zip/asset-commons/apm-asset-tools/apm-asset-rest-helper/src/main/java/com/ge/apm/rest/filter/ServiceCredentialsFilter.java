/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.common.AuthenticationScheme;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.OncePerRequestFilter;

import com.ge.apm.common.config.ISecurityConfigurationProvider;
import com.ge.apm.common.config.IServiceInfoProvider;
import com.ge.apm.common.exception.CommonErrorCodes;
import com.ge.apm.common.exception.DefaultErrorCode;
import com.ge.apm.common.exception.IErrorCode;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.rest.config.HttpConfig;
import com.ge.apm.rest.exception.codes.RestErrorCodes;
import com.ge.stuf.tenant.context.TenantContext;

import static com.ge.apm.common.support.RequestContext.TENANT_UUID;

@SuppressWarnings("WeakerAccess")
public abstract class ServiceCredentialsFilter<T extends IServiceInfoProvider> extends OncePerRequestFilter {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceCredentialsFilter.class);

    private final ConcurrentHashMap<String, ServiceAccessInfo> serviceAccessInfoMap = new ConcurrentHashMap<>();

    @Autowired
    private ISecurityConfigurationProvider securityConfigProvider;

    @Autowired
    private HttpConfig httpConfig;

    private String serviceInfoKey;

    private String serviceRestTemplateKey;

    @Setter
    private int socketReadTimeoutMs;

    @Setter
    private boolean throwOnServiceNotFound;

    public ServiceCredentialsFilter(String serviceInfoKey, String serviceRestTemplateKey) {
        this.serviceInfoKey = serviceInfoKey;
        this.serviceRestTemplateKey = serviceRestTemplateKey;
    }

    @SuppressWarnings("unused")
    public ServiceCredentialsFilter(String serviceInfoKey, String serviceRestTemplateKey, int socketReadTimeoutMs,
        boolean throwOnServiceNotFound) {
        this.serviceInfoKey = serviceInfoKey;
        this.serviceRestTemplateKey = serviceRestTemplateKey;
        this.socketReadTimeoutMs = socketReadTimeoutMs;
        this.throwOnServiceNotFound = throwOnServiceNotFound;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
        throws ServletException, IOException {
        String methodName = "ServiceCredentialsFilter.doFilterInternal";
        try {
            String tenantUuid = getTenantUuid();
            ServiceAccessInfo serviceAccessInfo = getServiceAccessInfo(tenantUuid);
            initializeContext(serviceAccessInfo);
        } catch (Exception excp) {

            if (excp instanceof ServiceException) {

                if (throwOnServiceNotFound) {
                    throw (ServiceException) (excp);
                }
            }

            LOGGER.error("", excp);

            if (throwOnServiceNotFound) {
                throw getCannotGetCredentialExcp(methodName, excp);
            }
        }

        filterChain.doFilter(request, response);
    }

    private ServiceException getCannotGetCredentialExcp(String callerMethodName, Exception excp) {

        IErrorCode errorCode = RestErrorCodes.ERROR_RETRIEVING_CREDENTIAL_FOR_SERVICE;
        String excpMessage = excp.getMessage();
        if (excp instanceof NullPointerException) {
            excpMessage = RestErrorCodes.INTERNAL_SERVER_ERROR.message();
        } else if (excp instanceof ExecutionException) {
            ExecutionException executionException = (ExecutionException) excp;
            excpMessage = executionException.getMessage();
        }

        String errorMessage = String.format(errorCode.message(), getTenantUuid(), getServiceName(), excpMessage);
        LOGGER.error("{}| Analytic URI: '{}', {}", callerMethodName, errorMessage);
        return new ServiceException(DefaultErrorCode.create(errorCode.name(), errorMessage));
    }

    private void initializeContext(ServiceAccessInfo serviceAccessInfo) {
        RequestContext.put(this.serviceInfoKey, serviceAccessInfo.getInfoProvider());
        RequestContext.put(this.serviceRestTemplateKey, serviceAccessInfo.getRestTemplate());
    }

    private synchronized ServiceAccessInfo getServiceAccessInfo(String tenantUuid) {
        ServiceAccessInfo serviceAccessInfo;
        if (this.serviceAccessInfoMap.containsKey(tenantUuid)) {
            serviceAccessInfo = this.serviceAccessInfoMap.get(tenantUuid);
        } else {
            T serviceInstanceInfo = TenantContext.getInstance().getServiceInstanceInfoProperty(tenantUuid,
                getServiceName(), getPath(), getInfoClass());

            if (serviceInstanceInfo == null) {
                throw new ServiceException(CommonErrorCodes.SERVICE_INSTANCE_NOT_FOUND, getServiceName());
            }

            serviceInstanceInfo.setServiceName(getServiceName());

            OAuth2RestTemplate restTemplate = getOauth2RestTemplate(this.securityConfigProvider, serviceInstanceInfo,
                this.httpConfig, socketReadTimeoutMs);
            serviceAccessInfo = new ServiceAccessInfo(serviceInstanceInfo, restTemplate);
            this.serviceAccessInfoMap.put(tenantUuid, serviceAccessInfo);
        }
        return serviceAccessInfo;
    }

    public static OAuth2RestTemplate getOauth2RestTemplate(ISecurityConfigurationProvider securityConfigProvider,
        IServiceInfoProvider serviceInstanceInfo, HttpConfig httpConfig) {
        return getOauth2RestTemplate(securityConfigProvider, serviceInstanceInfo, httpConfig,
            httpConfig.getSocketReadTimeoutMs());
    }

    public static OAuth2RestTemplate getOauth2RestTemplate(ISecurityConfigurationProvider securityConfigProvider,
        IServiceInfoProvider serviceInstanceInfo, HttpConfig httpConfig, int requestTimeoutMs) {
        ClientCredentialsResourceDetails resourceDetails = getResourceDetails(securityConfigProvider);
        resourceDetails.getScope().addAll(Arrays.asList(serviceInstanceInfo.getZoneTokenScopes()));
        return httpConfig.getOauth2RestTemplate(resourceDetails, requestTimeoutMs);
    }

    public static ClientCredentialsResourceDetails getResourceDetails(
        ISecurityConfigurationProvider securityConfigProvider) {
        ClientCredentialsResourceDetails resourceDetails = new ClientCredentialsResourceDetails();
        resourceDetails.setAuthenticationScheme(AuthenticationScheme.header);
        resourceDetails.setAccessTokenUri(securityConfigProvider.getAuthenticationUri());
        resourceDetails.setClientId(securityConfigProvider.getAuthenticationClientId());
        resourceDetails.setClientSecret(securityConfigProvider.getAuthenticationClientSecret());
        resourceDetails.setScope(
            new ArrayList<>(Arrays.asList(securityConfigProvider.getAuthenticationTokenDefaultScopes())));
        return resourceDetails;
    }

    protected abstract String getServiceName();

    protected abstract String getPath();

    protected abstract Class<T> getInfoClass();

    public static String getTenantUuid() {
        String tenantUuid = (String) RequestContext.get(TENANT_UUID);
        if (tenantUuid == null) {
            throw new ServiceException(CommonErrorCodes.TENANT_NOT_FOUND);
        }
        return tenantUuid;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    private static class ServiceAccessInfo {

        private IServiceInfoProvider infoProvider;

        private RestTemplate restTemplate;
    }
}
