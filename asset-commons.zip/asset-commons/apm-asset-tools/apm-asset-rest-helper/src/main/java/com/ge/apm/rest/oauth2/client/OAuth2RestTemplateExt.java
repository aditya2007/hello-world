/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.oauth2.client;

import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.resource.UserRedirectRequiredException;
import org.springframework.security.oauth2.common.OAuth2AccessToken;

public class OAuth2RestTemplateExt extends OAuth2RestTemplate {

    public OAuth2RestTemplateExt(OAuth2ProtectedResourceDetails resource) {
        super(resource);
    }

    @Override
    protected synchronized OAuth2AccessToken acquireAccessToken(OAuth2ClientContext oauth2Context)
        throws UserRedirectRequiredException {
        return super.acquireAccessToken(oauth2Context);
    }
}
