/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.config;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HeaderElement;
import org.apache.http.HeaderElementIterator;
import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.SocketConfig;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.protocol.HTTP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordResourceDetails;
import org.springframework.web.client.RestTemplate;

import com.ge.apm.rest.exception.codes.RestErrorCodes;
import com.ge.apm.rest.oauth2.client.OAuth2PwdRestTemplate;
import com.ge.apm.rest.oauth2.client.OAuth2RestTemplateExt;
import com.ge.apm.rest.util.ApmRestUtil;
import com.ge.apm.rest.util.RestUtil;
import com.ge.apm.util.exceptions.ExceptionHelper;
import com.ge.apm.util.interceptor.GzipHttpRequestInterceptor;

import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;

@SuppressWarnings({ "SpringFacetCodeInspection", "WeakerAccess" })
@Configuration
//@ConditionalOnWebApplication
//@AutoConfigureAfter(WebMvcAutoConfiguration.class)
@Setter
@Getter
public class HttpConfig {

    //    private static final int DEFAULT_MAX_CONNECTIONS_PER_ROUTE = 100;
    private static Logger LOGGER = LoggerFactory.getLogger(HttpConfig.class);

    private static HttpConfig httpConfig;

    //    private static final int DEFAULT_READ_TIMEOUT_MILLISECONDS = (60 * 1000);
    ConnectionKeepAliveStrategy myStrategy = (response, context) -> {
        HeaderElementIterator it = new BasicHeaderElementIterator(response.headerIterator(HTTP.CONN_KEEP_ALIVE));
        while (it.hasNext()) {
            HeaderElement he = it.nextElement();
            String param = he.getName();
            String value = he.getValue();
            if (value != null && param.equalsIgnoreCase("timeout")) {
                return Long.parseLong(value) * 1000;
            }
        }
        return 10 * 1000;
    };

    @Value("${use.proxy:}")
    private String useProxy;

    @Value("${proxy.host:}")
    private String propertyProxyHost;

    @Value("${proxy.port:-1}")
    private int propertyProxyPort;

    @Value("${max.connections:500}")
    private int maxConnections;

    @Value("${max.connections.per.route:100}")
    private int maxConnectionsPerRoute;

    @SuppressWarnings({ "SpringJavaAutowiringInspection", "SpringAutowiredFieldsWarningInspection" })
    @Autowired
    private ObjectMapper objectMapper;

    private HttpHost proxyHostInput;

    // Determines the timeout in milliseconds until a connection is established. A timeout value of zero is
    // interpreted as an infinite timeout.
    // ConnectTimeout is the timeout for creating a connection. Let's say you have an unreliable server and
    // you want to wait only 15 seconds before you tell the user that "something is wrong".
    @Value("${http.connection.timeout.ms:20000}")
    private int connectTimeoutMs;

    // Returns the timeout in milliseconds used when requesting a connection from the connection manager.
    // connectionRequestTimeout happens when you have a pool of connections and they are all busy, not allowing
    // the connection manager to give you one connection to make the request.
    //
    // When equipped with a pooling connection manager such as PoolingClientConnectionManager, HttpClient can be used
    // to execute multiple requests simultaneously using multiple threads of execution. The
    // PoolingClientConnectionManager will allocate connections based on its configuration. If all connections for a
    // given route have already been leased, a request for a connection will block until a connection is released
    // back to the pool. One can ensure the connection manager does not block indefinitely in the connection request
    // operation by setting 'http.conn-manager.timeout' to a positive value. If the connection request cannot be
    // serviced within the given time period ConnectionPoolTimeoutException will be thrown.
    @Value("${http.connection.manager.timeout.ms:60000}")
    private int connectionRequestTimeoutMs;

    // The read timeout is the timeout on waiting to read data. Specifically, if the server fails to
    // send a byte <timeout> seconds after the last byte, a read timeout error will be raised.
    // cloud-foundry gives 502 if the request takes more than 120 seconds. To workaround this problem, we are setting
    // socket timeout to be 100 seconds.
    @Value("${http.socket.read.timeout.ms:100000}")
    private int socketReadTimeoutMs;

    private Map<Integer, PoolingHttpClientConnectionManager> connectionManagers = new ConcurrentHashMap<>();

    public static HttpConfig getHttpConfig() {
        return httpConfig;
    }

    @SuppressWarnings("unused")
    public void setUseProxy(String useProxy) {
        this.useProxy = useProxy;
    }

    @PostConstruct
    public void initialize() {
        this.objectMapper.configure(FAIL_ON_UNKNOWN_PROPERTIES, false);
        // initialize proxy.
        getProxy();
        LOGGER.info("HttpConfig initialized");
    }

    @Bean
    public RestUtil apmRestUtil() {
        return new ApmRestUtil(restTemplateWithConnectionPool());
    }

    @Bean
    @Qualifier("restTemplateConnectionPool")
    public RestTemplate restTemplateWithConnectionPool() {
        return restTemplateWithConnectionPool(connectTimeoutMs, connectionRequestTimeoutMs, socketReadTimeoutMs);
    }

    public RestTemplate restTemplateWithConnectionPool(int connectTimeoutMs, int connectionRequestTimeoutMs,
        int socketReadTimeoutMs) {
        RestTemplate restTemplate = new RestTemplate();
        configureRestTemplate(restTemplate, connectTimeoutMs, connectionRequestTimeoutMs, socketReadTimeoutMs);
        return restTemplate;
    }

    @SuppressWarnings("Duplicates")
    @Bean
    public ClientHttpRequestFactory clientHttpRequestFactory() {
        return clientHttpRequestFactory(connectTimeoutMs, connectionRequestTimeoutMs, socketReadTimeoutMs);
    }

    @SuppressWarnings("Duplicates")
    public ClientHttpRequestFactory clientHttpRequestFactory(int connectTimeoutMs, int connectionRequestTimeoutMs,
        int socketReadTimeoutMs) {
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(
            httpClient(socketReadTimeoutMs));

        requestFactory.setConnectTimeout(connectTimeoutMs);
        requestFactory.setConnectionRequestTimeout(connectionRequestTimeoutMs);
        requestFactory.setReadTimeout(socketReadTimeoutMs);
        return requestFactory;
    }

    @Bean
    public CloseableHttpClient httpClient() {
        return httpClient(socketReadTimeoutMs);
    }

    public CloseableHttpClient httpClient(int socketReadTimeoutMs) {

        PoolingHttpClientConnectionManager connectionManager = getConnectionManager();

        connectionManager.setMaxTotal(maxConnections);

        connectionManager.setDefaultMaxPerRoute(this.maxConnectionsPerRoute);

        RequestConfig requestConfig = RequestConfig.copy(RequestConfig.DEFAULT).setSocketTimeout(socketReadTimeoutMs)
            .build();

        HttpClientBuilder httpClientBuilder = HttpClients.custom()
            //            .disableAutomaticRetries()
            .setDefaultRequestConfig(requestConfig).setKeepAliveStrategy(this.myStrategy).setConnectionManager(
                connectionManager);

        HttpHost proxyHost = getProxy();

        if (proxyHost != null) {
            httpClientBuilder.setProxy(proxyHost);
        }

        return httpClientBuilder.build();
    }

    @Bean
    public PoolingHttpClientConnectionManager getConnectionManager() {
        PoolingHttpClientConnectionManager clientConnectionManager = connectionManagers.get(socketReadTimeoutMs);

        if (clientConnectionManager != null) {
            return clientConnectionManager;
        }

        clientConnectionManager = new PoolingHttpClientConnectionManager();
        SocketConfig socketConfig = SocketConfig.custom().setSoTimeout(socketReadTimeoutMs).build();
        clientConnectionManager.setDefaultSocketConfig(socketConfig);
        LOGGER.info("after SocketTimeout: '{}'", clientConnectionManager.getDefaultSocketConfig().getSoTimeout());
        connectionManagers.put(socketReadTimeoutMs, clientConnectionManager);
        return clientConnectionManager;
    }

    @Bean
    public IdleConnectionMonitorThread getIdleConnectionMonitorThread() {
        return new IdleConnectionMonitorThread(getConnectionManager());
    }

    public void setProxyHostInput(HttpHost httpHost) {
        if (httpHost == null) {
            return;
        }
        this.useProxy = "true";
        this.propertyProxyHost = httpHost.getHostName();
        this.propertyProxyPort = httpHost.getPort();
        getProxy();
    }

    public HttpHost getProxy() {
        String methodName = "HttpConfig.getProxy";
        if (this.proxyHostInput != null) {
            LOGGER.info("@@@ Using proxy from given as input.");
            return this.proxyHostInput;
        } else {
            String envProxyHost = System.getProperty("https.proxyHost");

            if (!StringUtils.isBlank(envProxyHost)) {
                LOGGER.info("@@@ Using proxy from environment variable https.proxyHost.");
                int envProxyPort = Integer.valueOf(System.getProperty("https.proxyPort"));

                this.useProxy = "true";
                this.propertyProxyHost = envProxyHost;
                this.propertyProxyPort = envProxyPort;

                HttpHost proxy;
                proxy = new HttpHost(envProxyHost, envProxyPort);

                return proxy;
            } else if (!StringUtils.isBlank(this.useProxy) && this.useProxy.equalsIgnoreCase("true")) {
                if (StringUtils.isBlank(this.propertyProxyHost)) {
                    throw ExceptionHelper.getException(methodName, LOGGER, RestErrorCodes.PROXY_HOST_EMPTY);
                }

                if (this.propertyProxyPort == -1) {
                    throw ExceptionHelper.getException(methodName, LOGGER, RestErrorCodes.PROXY_PORT_EMPTY);
                }

                LOGGER.info("@@@ Using proxy from application properties.");
                // for oauth2RestTemplate, the system property should be set.
                System.setProperty("https.proxyHost", this.propertyProxyHost);
                System.setProperty("https.proxyPort", String.valueOf(this.propertyProxyPort));

                HttpHost proxy;
                proxy = new HttpHost(this.propertyProxyHost, this.propertyProxyPort);
                return proxy;
            }
        }

        LOGGER.info("@@@ no proxy used.");
        return null;
    }

    public OAuth2RestTemplate getOauth2RestTemplate(ClientCredentialsResourceDetails resourceDetails) {
        OAuth2RestTemplate restTemplate = new OAuth2RestTemplateExt(resourceDetails);
        restTemplate.setRequestFactory(clientHttpRequestFactory());
        configureRestTemplate(restTemplate, objectMapper);
        return restTemplate;
    }

    public OAuth2RestTemplate getOauth2RestTemplate(ClientCredentialsResourceDetails resourceDetails,
        int socketReadTimeoutMs) {
        return getOauth2RestTemplate(resourceDetails, connectTimeoutMs, connectionRequestTimeoutMs,
            socketReadTimeoutMs);
    }

    public OAuth2RestTemplate getOauth2RestTemplate(ClientCredentialsResourceDetails resourceDetails,
        int connectTimeoutMs, int connectionRequestTimeoutMs, int socketReadTimeoutMs) {
        OAuth2RestTemplate restTemplate = new OAuth2RestTemplateExt(resourceDetails);
        configureRestTemplate(restTemplate, connectTimeoutMs, connectionRequestTimeoutMs, socketReadTimeoutMs);
        return restTemplate;
    }

    public OAuth2PwdRestTemplate getOauth2PwdRestTemplate(ResourceOwnerPasswordResourceDetails resourceDetails) {
        OAuth2PwdRestTemplate restTemplate = new OAuth2PwdRestTemplate(resourceDetails);
        restTemplate.setRequestFactory(clientHttpRequestFactory());
        configureRestTemplate(restTemplate, objectMapper);
        return restTemplate;
    }

    @SuppressWarnings("unused")
    public OAuth2PwdRestTemplate getOauth2PwdRestTemplate(ResourceOwnerPasswordResourceDetails resourceDetails,
        int socketReadTimeoutMs) {
        return getOauth2PwdRestTemplate(resourceDetails, connectTimeoutMs, connectionRequestTimeoutMs,
            socketReadTimeoutMs);
    }

    public OAuth2PwdRestTemplate getOauth2PwdRestTemplate(ResourceOwnerPasswordResourceDetails resourceDetails,
        int connectTimeoutMs, int connectionRequestTimeoutMs, int socketReadTimeoutMs) {
        OAuth2PwdRestTemplate restTemplate = new OAuth2PwdRestTemplate(resourceDetails);
        configureRestTemplate(restTemplate, connectTimeoutMs, connectionRequestTimeoutMs, socketReadTimeoutMs);
        return restTemplate;
    }

    public static <T extends RestTemplate> void configureRestTemplate(T restTemplate, ObjectMapper objectMapper) {
        List<HttpMessageConverter<?>> converters = restTemplate.getMessageConverters();

        converters.stream().filter(converter -> converter instanceof MappingJackson2HttpMessageConverter).forEach(
            converter -> {
                MappingJackson2HttpMessageConverter jsonConverter = (MappingJackson2HttpMessageConverter) converter;
                jsonConverter.setObjectMapper(objectMapper);
            });

        restTemplate.getInterceptors().add(new GzipHttpRequestInterceptor());
        restTemplate.getMessageConverters().add(new ByteArrayHttpMessageConverter());
    }

    private <T extends RestTemplate> void configureRestTemplate(T restTemplate, int connectTimeoutMs,
        int connectionRequestTimeoutMs, int socketReadTimeoutMs) {

        ClientHttpRequestFactory requestFactory = clientHttpRequestFactory(connectTimeoutMs, connectionRequestTimeoutMs,
            socketReadTimeoutMs);

        restTemplate.setRequestFactory(requestFactory);

        configureRestTemplate(restTemplate, objectMapper);
    }

    @SuppressWarnings("WeakerAccess")
    public static class IdleConnectionMonitorThread extends Thread {

        private final HttpClientConnectionManager connMgr;

        private volatile boolean shutdown;

        public IdleConnectionMonitorThread(PoolingHttpClientConnectionManager connMgr) {
            super();
            this.connMgr = connMgr;
            start();
        }

        @Override
        public void run() {
            try {
                while (!this.shutdown) {
                    synchronized (this) {
                        wait(180l * 1000l /* milli-seconds */);
                        this.connMgr.closeExpiredConnections();
                        this.connMgr.closeIdleConnections(30, TimeUnit.SECONDS);
                    }
                }
            } catch (InterruptedException ex) {
                LOGGER.error(ex.getMessage(), ex);
                Thread.currentThread().interrupt();
                shutdown();
            }
        }

        public void shutdown() {
            this.shutdown = true;
            synchronized (this) {
                notifyAll();
            }
        }
    }

    //    @PreDestroy
    //    public void shutdown() throws InterruptedException, IOException {
    //        // Shutdown the monitor.
    //        getIdleConnectionMonitorThread().shutdown();
    //    }
    //
    //    // Watches for stale connections and evicts them.
    //    private static class IdleConnectionMonitorThread extends Thread {
    //        // The manager to watch.
    //        private final PoolingHttpClientConnectionManager cm;
    //        // Use a BlockingQueue to stop everything.
    //        private final BlockingQueue<Stop> stopSignal = new ArrayBlockingQueue<>(1);
    //        CloseableHttpClient httpClient;
    //
    //        IdleConnectionMonitorThread(CloseableHttpClient httpClient, PoolingHttpClientConnectionManager cm) {
    //            super();
    //            this.httpClient = httpClient;
    //            this.cm = cm;
    //        }
    //
    //        @Override
    //        public void run() {
    //            try {
    //                // Holds the stop request that stopped the process.
    //                Stop stopRequest;
    //                // Every 5 seconds.
    //                while ((stopRequest = stopSignal.poll(5, TimeUnit.SECONDS)) == null) {
    //                    // Close expired connections
    //                    cm.closeExpiredConnections();
    //                    // Optionally, close connections that have been idle too long.
    //                    cm.closeIdleConnections(60, TimeUnit.SECONDS);
    //                    // Look at pool stats.
    //                    LOGGER.info("Stats: {}", cm.getTotalStats());
    //                }
    //                // Acknowledge the stop request.
    //                stopRequest.stopped();
    //            } catch (InterruptedException ex) {
    //                // terminate
    //            }
    //        }
    //
    //        public void shutdown() throws InterruptedException, IOException {
    //            LOGGER.info("Shutting down client pool");
    //            // Signal the stop to the thread.
    //            Stop stop = new Stop();
    //            stopSignal.add(stop);
    //            // Wait for the stop to complete.
    //            stop.waitForStopped();
    //            // Close the pool - Added
    //            httpClient.close();
    //            // Close the connection manager.
    //            cm.close();
    //            LOGGER.info("Client pool shut down");
    //        }
    //
    //        // Pushed up the queue.
    //        private static class Stop {
    //            // The return queue.
    //            private final BlockingQueue<Stop> stop = new ArrayBlockingQueue<>(1);
    //
    //            // Called by the process that is being told to stop.
    //            public void stopped() {
    //                // Push me back up the queue to indicate we are now stopped.
    //                stop.add(this);
    //            }
    //
    //            // Called by the process requesting the stop.
    //            public void waitForStopped() throws InterruptedException {
    //                // Wait until the callee acknowledges that it has stopped.
    //                stop.take();
    //            }
    //        }
    //    }
}
