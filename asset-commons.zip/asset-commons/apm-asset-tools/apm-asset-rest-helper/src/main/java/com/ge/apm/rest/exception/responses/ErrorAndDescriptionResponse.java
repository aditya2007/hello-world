/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.exception.responses;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.StringUtils;

import com.ge.apm.util.JsonHelper;
import com.ge.apm.util.exceptions.model.RestServiceError.ErrorInfo;

public class ErrorAndDescriptionResponse implements IErrorDeserializer {
    // Expected error responses:
    //
    //    {
    //        "error": "invalid_token",
    //        "error_description": "Token is expired"
    //    }

    @Override
    public List<ErrorInfo> getErrorResponse(String responseJson) {
        AlternateErrorResponse alternateErrorResponse = null;
        try {
            alternateErrorResponse = JsonHelper.fromJsonNoExcpLog(responseJson, AlternateErrorResponse.class,
                false /*unwrapRootValue*/, false /*failOnUnknownProperties*/, null /*registerModules*/);
        } catch (Exception excp) { // NOSONAR
            // Rest Util calls all the registered classes to check if the input json matches the given class.
            // if the current input json is not of this class, then JsonHelper might throw an error. We can
            // ignore these exceptions and initialize message as null;
        }

        if (alternateErrorResponse == null) {
            return null;
        }

        List<ErrorInfo> errorResponses = new ArrayList<>();
        if (!StringUtils.isBlank(alternateErrorResponse.getErrorDescription())
            && !StringUtils.isBlank(alternateErrorResponse.getError())) {
            errorResponses.add(new ErrorInfo(null /* httpStatusCode */, alternateErrorResponse.getError(),
                alternateErrorResponse.getErrorDescription(), "" /* detail */, "" /* requestId */));
        }

        if (!errorResponses.isEmpty()) {
            return errorResponses;
        }

        return null;
    }

    @SuppressWarnings("WeakerAccess")
    @Getter
    @Setter
    @ToString
    public static class AlternateErrorResponse {
        private String error;

        @JsonProperty("error_description")
        private String errorDescription;
    }
}
