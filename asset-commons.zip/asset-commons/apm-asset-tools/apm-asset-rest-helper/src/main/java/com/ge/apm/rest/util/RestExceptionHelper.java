/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.util;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.MDC;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.oauth2.client.resource.OAuth2AccessDeniedException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.context.request.RequestAttributes;

import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.DefaultErrorCode;
import com.ge.apm.common.exception.ForbiddenException;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.exception.UnauthorizedException;
import com.ge.apm.common.model.ServiceError;
import com.ge.apm.rest.exception.codes.RestErrorCodes;
import com.ge.apm.rest.exception.handler.RequestErrorController;
import com.ge.apm.rest.exception.responses.IErrorDeserializer;
import com.ge.apm.util.JsonHelper;
import com.ge.apm.util.exceptions.ExceptionHelper;
import com.ge.apm.util.exceptions.RestServiceErrorException;
import com.ge.apm.util.exceptions.ServiceExceptionHttpStatus;
import com.ge.apm.util.exceptions.model.RestServiceError;
import com.ge.apm.util.exceptions.model.RestServiceError.ErrorInfo;

import static com.ge.apm.util.exceptions.ExceptionHelper.escapeForStringFormat;
import static com.ge.apm.util.exceptions.ExceptionHelper.logException;
import static com.ge.apm.util.servlets.HttpServletUtils.getHttpMethod;
import static com.ge.apm.util.servlets.HttpServletUtils.getHttpStatus;
import static com.ge.apm.util.servlets.HttpServletUtils.getRequestUrl;
import static com.ge.apm.util.servlets.HttpServletUtils.getUrlPath;
import static org.springframework.http.HttpStatus.BAD_GATEWAY;

@SuppressWarnings({ "unused", "WeakerAccess" })
public class RestExceptionHelper {

    private static String SERVICE_ERROR = "ServiceError";

    public static Exception getException(String methodName, Logger LOGGER, Exception exception,
        HttpServletResponse response) {
        if (exception instanceof NotFoundException) {
            response.setStatus(HttpStatus.NOT_FOUND.value());
        } else if (!(exception instanceof ServiceException)) {
            return ExceptionHelper.getException(methodName, LOGGER, RestErrorCodes.INTERNAL_SERVER_ERROR);
        }
        return exception;
    }

    public static RestServiceErrorException getExceptionForNonControllerAdviceExcp(String methodName, Logger LOGGER,
        Exception actualException, HttpServletRequest request) {

        String httpMethod = getHttpMethod(methodName, LOGGER, request);
        String requestUrl = getRequestUrl(methodName, LOGGER, request);

        Throwable cause = actualException.getCause();

        if (cause instanceof IllegalStateException) {

            Throwable rootCause = ExceptionUtils.getRootCause(cause);
            HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
            return getRestServiceErrorException(methodName, LOGGER, requestUrl, httpMethod, httpStatus, actualException,
                rootCause == null ? cause.getMessage() : rootCause.getMessage());
        }

        if (cause != null && cause instanceof OAuth2AccessDeniedException) {
            HttpStatus httpStatus = HttpStatus.UNAUTHORIZED;
            return getRestServiceErrorException(methodName, LOGGER, requestUrl, httpMethod, httpStatus, actualException,
                cause.getMessage());
        }

        if (actualException instanceof RestServiceErrorException) {
            RestServiceErrorException restServiceErrorException = (RestServiceErrorException) actualException;
            logException(methodName, LOGGER, restServiceErrorException.getHttpMethod(), requestUrl,
                restServiceErrorException.getHttpStatus().name(), null, restServiceErrorException);
            return (RestServiceErrorException) actualException;
        } else if (actualException instanceof ServiceExceptionHttpStatus) {
            ServiceExceptionHttpStatus serviceExceptionHttpStatus = (ServiceExceptionHttpStatus) actualException;
            return getRestServiceErrorException(methodName, LOGGER, requestUrl, httpMethod,
                serviceExceptionHttpStatus.getHttpStatus(), actualException, serviceExceptionHttpStatus.getMessage());
        } else if (actualException instanceof ServiceException) {
            ServiceException serviceException = (ServiceException) actualException;
            HttpStatus httpStatus = getHttpStatusFromServiceExceptionCode(serviceException, request);
            return getRestServiceErrorException(methodName, LOGGER, requestUrl, httpMethod, httpStatus, actualException,
                serviceException.getMessage());
        } else if (actualException instanceof HttpStatusCodeException) {
            return getExceptionForRestRequest(methodName, LOGGER, requestUrl, httpMethod,
                (HttpStatusCodeException) actualException, RestUtil.getDefaultErrorDeserializers());
        }

        HttpStatus httpStatus = getHttpStatus(request);

        Throwable rootCause = ExceptionUtils.getRootCause(actualException);
        if (rootCause != null) {
            if (rootCause instanceof Error) {
                Error error = (Error) rootCause;
                logHttpRequestError(LOGGER, requestUrl, httpMethod, httpStatus.toString(), httpStatus.name(),
                    actualException, escapeForStringFormat(error.getMessage()));
                return getRestServiceErrorException(methodName, LOGGER, requestUrl, httpMethod, httpStatus,
                    actualException, escapeForStringFormat(error.getMessage()));
            } else {
                actualException = (Exception) rootCause;
            }
        }

        return getRestServiceErrorException(methodName, LOGGER, requestUrl, httpMethod, httpStatus, actualException,
            RestErrorCodes.INTERNAL_SERVER_ERROR.message());
    }

    public static RestServiceErrorException getRestServiceErrorException(String methodName, Logger LOGGER,
        String requestUrl, String requestHttpMethod, HttpStatus httpStatus, Exception exceptionInput,
        String errorMessage) {

        Object traceIdObject = MDC.get("X-B3-TraceId");
        String traceId = traceIdObject != null ? (String) traceIdObject : "";

        String errorCode = httpStatus.name();
        if (exceptionInput instanceof ServiceException) {
            errorCode = ((ServiceException) exceptionInput).getCode();
        }
        ErrorInfo errorInfo = new ErrorInfo(errorCode, httpStatus.name(), errorMessage);

        RestServiceError restServiceError = new RestServiceError(Collections.singletonList(errorInfo));
        restServiceError.setTraceId(traceId);
        restServiceError.setPath("[" + requestHttpMethod + "] " + requestUrl);

        RestServiceErrorException restServiceErrorException = new RestServiceErrorException(
            DefaultErrorCode.create(errorCode, ""), requestHttpMethod, httpStatus, restServiceError);

        if (exceptionInput instanceof ServiceException) {
            restServiceErrorException.setExceptionLogged(((ServiceException) exceptionInput).isExceptionLogged());
        }

        logException(methodName, LOGGER, requestHttpMethod, requestUrl, httpStatus.name(), exceptionInput,
            restServiceErrorException);

        return restServiceErrorException;
    }

    public static HttpStatus getHttpStatusFromServiceExceptionCode(String code) {
        try {
            // check if we can get HttpStatus code from the service exception error code.
            return HttpStatus.valueOf(code);
        } catch (Exception ignored) { // NOSONAR
            return HttpStatus.BAD_REQUEST;
        }
    }

    public static HttpStatus getHttpStatusFromServiceExceptionCode(ServiceException serviceException,
        HttpServletRequest request) {

        try {
            // check if we can get HttpStatus code from the service exception error code.
            return HttpStatus.valueOf(serviceException.getCode());
        } catch (Exception ignored) { // NOSONAR
            return serviceException instanceof UnauthorizedException ? HttpStatus.UNAUTHORIZED
                : (serviceException instanceof ForbiddenException ? HttpStatus.FORBIDDEN
                    : (serviceException instanceof NotFoundException ? HttpStatus.NOT_FOUND
                        : (serviceException instanceof BadRequestException ? HttpStatus.BAD_REQUEST : getHttpStatus(
                            request))));
        }
    }

    public static Throwable getError(RequestAttributes requestAttributes) {

        Throwable exception = getAttribute(requestAttributes, RequestErrorController.ERROR_ATTRIBUTE);
        if (exception == null) {
            exception = getAttribute(requestAttributes, "javax.servlet.error.exception");
        }
        return exception;
    }

    public static <T> T getAttribute(RequestAttributes requestAttributes, String name) {
        //noinspection unchecked
        return (T) requestAttributes.getAttribute(name, RequestAttributes.SCOPE_REQUEST);
    }

    public static Pair<HttpStatus, String> getResourceAccessExceptionMsg(
        ResourceAccessException resourceAccessException, String url) {

        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;

        Throwable cause = resourceAccessException.getCause();
        if (cause instanceof SocketTimeoutException) {
            httpStatus = HttpStatus.REQUEST_TIMEOUT;
            return new ImmutablePair<>(httpStatus, String.format(RestErrorCodes.REQUEST_TIMED_OUT.message(), url));
        } else if (cause instanceof UnknownHostException) {
            UnknownHostException unknownHostException = (UnknownHostException) cause;
            httpStatus = HttpStatus.SERVICE_UNAVAILABLE;
            return new ImmutablePair<>(httpStatus,
                String.format(RestErrorCodes.SERVER_UNAVAILABLE.message(), unknownHostException.getMessage()));
        } else if (cause instanceof ConnectException) {
            ConnectException connectException = (ConnectException) resourceAccessException.getCause();
            if (connectException.getMessage().equalsIgnoreCase("Connection refused")) {
                httpStatus = HttpStatus.SERVICE_UNAVAILABLE;
                return new ImmutablePair<>(httpStatus, String.format(RestErrorCodes.SERVER_UNAVAILABLE.message(), url));
            } else if (connectException.getMessage().equalsIgnoreCase("Connection timed out")) {
                httpStatus = HttpStatus.REQUEST_TIMEOUT;
                return new ImmutablePair<>(httpStatus, String.format(RestErrorCodes.CONNECTION_TIMED_OUT.message(), url));
            } else {
                httpStatus = BAD_GATEWAY;
                return new ImmutablePair<>(httpStatus, connectException.getMessage());
            }
        } else {
            return new ImmutablePair<>(httpStatus, cause.getMessage());
        }
    }

    public static ServiceException getExceptionForRestRequest(String methodName, Logger LOGGER, String url,
        HttpMethod httpMethod, ResourceAccessException resourceAccessException) {

        Pair<HttpStatus, String> msgPair = getResourceAccessExceptionMsg(resourceAccessException, url);

        return getRestServiceErrorException(methodName, LOGGER, url, httpMethod.name(), msgPair.getLeft(),
            resourceAccessException, msgPair.getRight());
    }

    public static ServiceException getExceptionForRestRequest(String methodName, Logger LOGGER, String url,
        HttpMethod httpMethod, WebApplicationException exception) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        String errorMessage = null;
        if (exception.getResponse() != null) {
            Response response = exception.getResponse();
            if (response.hasEntity()) {
                errorMessage = response.getEntity().toString();
            }
            httpStatus = HttpStatus.valueOf(response.getStatus());
        }

        if (StringUtils.isEmpty(errorMessage)) {
            errorMessage = exception.getMessage();
        }

        return getRestServiceErrorException(methodName, LOGGER, url, httpMethod.name(), httpStatus, exception,
            errorMessage);
    }

    public static RestServiceErrorException getExceptionForRestRequest(String methodName, Logger LOGGER, String url,
        String httpMethod, HttpStatusCodeException actualException, List<IErrorDeserializer> errorDeserializers) {

        HttpStatus httpStatus = actualException.getStatusCode();
        Object traceIdObject = MDC.get("X-B3-TraceId");
        String traceId = traceIdObject != null ? (String) traceIdObject : "";

        // In some of the responses, we get the following string. We do not want to include this string in the response.
        // java.util.concurrent.ExecutionException: com.ge.aggregator.AggregatorException:
        String response = actualException.getResponseBodyAsString().trim().replace(
            "java.util.concurrent.ExecutionException: com.ge.aggregator.AggregatorException: ", "");

        RestServiceErrorException restServiceErrorException = getIfServiceErrorException(response, httpStatus);

        if (restServiceErrorException != null) {
            logException(methodName, LOGGER, restServiceErrorException);
            return restServiceErrorException;
        }

        String errorMessage = response;

        if (StringUtils.isEmpty(response)) {
            if (httpStatus == HttpStatus.NOT_FOUND) {
                errorMessage = String.format(RestErrorCodes.RESOURCE_NOT_FOUND.message(),
                    getUrlPath(methodName, LOGGER, url));
            } else {
                errorMessage = actualException.getStatusCode() + "::" + actualException.getStatusText();
            }
            return getRestServiceErrorException(methodName, LOGGER, url, httpMethod, httpStatus, actualException,
                errorMessage);
        }

        for (IErrorDeserializer errorDeserializer : errorDeserializers) {
            List<ErrorInfo> errorResponses = null;
            try {
                errorResponses = errorDeserializer.getErrorResponse(response);
            } catch (Exception ignored) { // NOSONAR
                // ignore the exceptions that are thrown by the de-serializer.
            }
            if (errorResponses != null && !errorResponses.isEmpty()) {
                RestServiceError restServiceError = new RestServiceError(errorResponses);
                restServiceError.setTraceId(traceId);
                restServiceError.setPath(url);

                restServiceErrorException = new RestServiceErrorException(DefaultErrorCode.create(SERVICE_ERROR, ""),
                    httpMethod, httpStatus, restServiceError);
                logException(methodName, LOGGER, restServiceErrorException);
                return restServiceErrorException;
            }
        }

        if (httpStatus == HttpStatus.NOT_FOUND) {
            if (StringUtils.isBlank(errorMessage) || errorMessage.equals("[]")) {
                errorMessage = String.format(RestErrorCodes.RESOURCE_NOT_FOUND.message(),
                    getUrlPath(methodName, LOGGER, url));
            } else {
                // if the host/route not found, then the error message will be
                // "404 Not Found: Requested route ('tenancy-stuf-apmpatch.run.asv-pr.ice.predix.io') does not exist."
                // we want to remove 404 Not Found:
                errorMessage = errorMessage.replace("404 Not Found: ", "");
            }
        }

        return getRestServiceErrorException(methodName, LOGGER, url, httpMethod, httpStatus, actualException,
            errorMessage);
    }

    public static void logHttpRequestError(Logger LOGGER, String url, String httpMethod, String statusCode,
        String statusText, Exception exception, String response) {

        if (!StringUtils.isEmpty(url)) {
            LOGGER.error("\n[{}] URL: '{}', Error_StatusCode: '{}', Error_StatusText: '{}', Response: '{}'\n",
                httpMethod, url, statusCode, statusText, response);
        } else {
            LOGGER.error("\nStatusCode: '{}', StatusText: '{}', Response: '{}'\n", statusCode, statusText, response);
        }
    }

    // some services throw ServiceError exception. In such situation, check if the current response is ServiceError
    // exception.
    private static RestServiceErrorException getIfServiceErrorException(String response, HttpStatus httpStatus) {

        ServiceError serviceError = null;
        try {
            // checking if the current response is of type RestServiceError.
            serviceError = JsonHelper.fromJsonNoExcpLog(response, ServiceError.class, false /*unwrapRootValue*/,
                false /*failOnUnknownProperties*/);
        } catch (Exception exception) { // NOSONAR
            // ignore...
        }

        if (serviceError != null && !StringUtils.isEmpty(serviceError.getErrorMessage())) {
            return new RestServiceErrorException(DefaultErrorCode.create(SERVICE_ERROR, ""), "UNKNOWN", httpStatus,
                new RestServiceError(serviceError));
        }

        RestServiceError restServiceError = null;
        try {
            // checking if the current response is of type RestServiceError.
            restServiceError = JsonHelper.fromJsonNoExcpLog(response, RestServiceError.class, false /*unwrapRootValue*/,
                false
                    /*failOnUnknownProperties*/);
        } catch (Exception exception) { // NOSONAR
            // ignore...
        }

        if (restServiceError != null && !restServiceError.getErrors().isEmpty()) {
            return new RestServiceErrorException(DefaultErrorCode.create(SERVICE_ERROR, ""), "UNKNOWN", httpStatus,
                restServiceError);
        }

        return null;
    }
}
