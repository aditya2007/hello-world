/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.exception.handler;

import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.ConversionNotSupportedException;
import org.springframework.beans.TypeMismatchException;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.web.WebMvcAutoConfiguration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.NestedRuntimeException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException;

import com.ge.apm.common.support.RequestContext;
import com.ge.apm.rest.util.RestExceptionHelper;
import com.ge.apm.util.exceptions.ExceptionHelper;
import com.ge.apm.util.exceptions.RestServiceErrorException;

import static com.ge.apm.util.exceptions.ExceptionHelper.logException;
import static com.ge.apm.util.servlets.HttpServletUtils.getHttpMethod;
import static com.ge.apm.util.servlets.HttpServletUtils.getHttpStatus;
import static com.ge.apm.util.servlets.HttpServletUtils.getRequestUrl;
import static com.ge.apm.util.servlets.HttpServletUtils.getServletRequest;

@EnableWebMvc
@ControllerAdvice
@ConditionalOnWebApplication
@AutoConfigureAfter(WebMvcAutoConfiguration.class)
@Primary
@Order(Ordered.HIGHEST_PRECEDENCE)
public class ControllerExcpHandler extends ResponseEntityExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ControllerExcpHandler.class);

    public static ResponseEntity<Object> getResponseEntity(RestServiceErrorException exception) {
        final String methodName = "ControllerExcpHandler.getResponseEntity";
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(exception.getRestServiceError(),
            exception.getHttpStatus());

        logException(methodName, LOGGER, exception);
        return responseEntity;
    }

    public static ResponseEntity<Object> handleExceptionInternal(Exception exception, HttpStatus status,
        WebRequest webRequest) {
        final String methodName = "ControllerExcpHandler.handleExceptionInternal";
        HttpServletRequest servletRequest = getServletRequest(webRequest);

        RestServiceErrorException restServiceErrorException;
        if (servletRequest == null) {
            String requestUrl = "UNKNOWN_URL";
            String httpMethod = "UNKNOWN_HTTP_METHOD";

            restServiceErrorException = RestExceptionHelper.getRestServiceErrorException(methodName, LOGGER, requestUrl, httpMethod, status,
                exception, exception.getMessage());
        } else {
            restServiceErrorException = getErrorMessageForExcptionType(servletRequest, status, exception);
        }

        return getResponseEntity(restServiceErrorException);
    }

    public static RestServiceErrorException getErrorMessageForExcptionType(HttpServletRequest servletRequest,
        HttpStatus status, Exception exception) {

        final String methodName = "ControllerExcpHandler.getErrorMessageForExcptionType";

        // in the error situation, we do not care about NEXT_PAGE_LINK link info. If we have this, then,
        // PageNavigationFilter is kicking in and sending 206 status as that filter is executing after this
        // controller advice.
        RequestContext.remove(RequestContext.NEXT_PAGE_LINK);

        String errorMessage;
        String requestUrl = getRequestUrl(methodName, LOGGER, servletRequest);

        if (exception instanceof BindException) {
            BindException actualExcp = (BindException) exception;
            List<ObjectError> allErrors = actualExcp.getAllErrors();

            StringBuilder errors = new StringBuilder();
            allErrors.forEach(error -> errors.append(error.toString()));

            errorMessage = StringUtils.join(errors, System.lineSeparator());
        } else if (exception instanceof ConversionNotSupportedException) {
            ConversionNotSupportedException actualExcp = (ConversionNotSupportedException) exception;
            errorMessage = getErrorMessage(actualExcp);
        } else if (exception instanceof HttpMediaTypeNotAcceptableException) {
            HttpMediaTypeNotAcceptableException actualExcp = (HttpMediaTypeNotAcceptableException) exception;
            errorMessage = actualExcp.getMessage() + System.lineSeparator() + "Supported accept types: " + MediaType
                .toString(actualExcp.getSupportedMediaTypes());
        } else if (exception instanceof HttpMediaTypeNotSupportedException) {
            HttpMediaTypeNotSupportedException actualExcp = (HttpMediaTypeNotSupportedException) exception;

            errorMessage = actualExcp.getMessage() + System.lineSeparator() + "Supported content types: '" + MediaType
                .toString(actualExcp.getSupportedMediaTypes()) + "'";
        } else if (exception instanceof HttpMessageNotReadableException) {
            HttpMessageNotReadableException httpMessageNotReadableException
                = (HttpMessageNotReadableException) exception;
            errorMessage = httpMessageNotReadableException.getMessage();
        } else if (exception instanceof HttpMessageNotWritableException) {
            HttpMessageNotWritableException actualExcp = (HttpMessageNotWritableException) exception;
            errorMessage = getErrorMessage(actualExcp);
        } else if (exception instanceof HttpRequestMethodNotSupportedException) {

            HttpRequestMethodNotSupportedException actualExcp = (HttpRequestMethodNotSupportedException) exception;

            errorMessage = actualExcp.getMessage() + System.lineSeparator() + "Request method '" + actualExcp
                .getMethod() + "' not supported." + System.lineSeparator() + "Supported methods: '" + StringUtils.join(
                actualExcp.getSupportedHttpMethods(), ", ");
        } else if (exception instanceof MethodArgumentNotValidException) {
            MethodArgumentNotValidException actualExcp = (MethodArgumentNotValidException) exception;
            errorMessage = actualExcp.getMessage();
        } else if (exception instanceof MissingServletRequestParameterException) {
            MissingServletRequestParameterException actualExcp = (MissingServletRequestParameterException) exception;
            errorMessage = actualExcp.getMessage();
        } else if (exception instanceof MissingServletRequestPartException) {
            MissingServletRequestPartException actualExcp = (MissingServletRequestPartException) exception;
            errorMessage = actualExcp.getMessage();
        } else if (exception instanceof NoHandlerFoundException) {
            errorMessage = String.format("The URI '%s' is not found.", servletRequest.getRequestURI());
        } else if (exception instanceof NoSuchRequestHandlingMethodException) {
            NoSuchRequestHandlingMethodException actualExcp = (NoSuchRequestHandlingMethodException) exception;
            errorMessage = actualExcp.getMessage();
        } else if (exception instanceof ServletRequestBindingException) {
            ServletRequestBindingException actualExcp = (ServletRequestBindingException) exception;
            errorMessage = ExceptionHelper.getRootCauseMessage(actualExcp);
        } else if (exception instanceof TypeMismatchException) {
            TypeMismatchException actualExcp = (TypeMismatchException) exception;
            errorMessage = actualExcp.getMessage();
        } else if (exception instanceof ResourceAccessException) {
            ResourceAccessException actualExcp = (ResourceAccessException) exception;
            Pair<HttpStatus, String> msgPair = RestExceptionHelper.getResourceAccessExceptionMsg(actualExcp,
                requestUrl);
            errorMessage = msgPair.getRight();
        } else if (exception instanceof IllegalStateException) {
            IllegalStateException actualExcp = (IllegalStateException) exception;
            Throwable rootCause = ExceptionUtils.getRootCause(exception);

            errorMessage = rootCause == null ? actualExcp.getMessage() : rootCause.getMessage();
        } else {
            return RestExceptionHelper.getExceptionForNonControllerAdviceExcp(methodName, LOGGER, exception, servletRequest);
        }

        if (status == null) {
            status = getHttpStatus(servletRequest);
        }

        String httpMethod = getHttpMethod(methodName, LOGGER, servletRequest);

        return RestExceptionHelper.getRestServiceErrorException(methodName, LOGGER, requestUrl, httpMethod, status, exception,
            errorMessage);
    }

    private static <T extends NestedRuntimeException> String getErrorMessage(T ex) {
        Throwable mostSpecificCause = ex.getMostSpecificCause();
        String errorMessage;
        if (mostSpecificCause != null) {
            errorMessage = mostSpecificCause.getMessage();
        } else {
            errorMessage = ex.getMessage();
        }

        return errorMessage;
    }

    @Override
    public ResponseEntity<Object> handleBindException(BindException excp, HttpHeaders headers, HttpStatus status,
        WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleConversionNotSupported(ConversionNotSupportedException excp,
        HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleHttpMediaTypeNotAcceptable(HttpMediaTypeNotAcceptableException excp,
        HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException excp,
        HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException excp,
        HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleHttpMessageNotWritable(HttpMessageNotWritableException excp,
        HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException excp,
        HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException excp,
        HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException excp,
        HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleMissingServletRequestPart(MissingServletRequestPartException excp,
        HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException excp, HttpHeaders headers,
        HttpStatus status, WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleNoSuchRequestHandlingMethod(NoSuchRequestHandlingMethodException excp,
        HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleServletRequestBindingException(ServletRequestBindingException excp,
        HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @Override
    public ResponseEntity<Object> handleTypeMismatch(TypeMismatchException excp, HttpHeaders headers, HttpStatus status,
        WebRequest request) {
        return handleExceptionInternal(excp, status, request);
    }

    @ExceptionHandler({ Exception.class })
    @ResponseBody
    public ResponseEntity<Object> handleException(HttpServletRequest request, Exception exception) {
        return getResponseEntity(getErrorMessageForExcptionType(request, null /* httpStatus */, exception));
    }
}
