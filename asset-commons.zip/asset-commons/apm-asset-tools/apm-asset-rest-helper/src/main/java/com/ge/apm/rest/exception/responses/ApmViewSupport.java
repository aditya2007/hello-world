/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.rest.exception.responses;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.StringUtils;

import com.ge.apm.util.JsonHelper;
import com.ge.apm.util.exceptions.model.RestServiceError.ErrorInfo;

@Getter
@Setter
@ToString
public class ApmViewSupport implements IErrorDeserializer {

    // Expected error responses:
    //
    //    {
    //        "name": "Error",
    //        "status": 404,
    //        "message": "Unknown Deck id VkLpeWy.",
    //        "statusCode": 404,
    //        "code": "MODEL_NOT_FOUND"
    //    }

    private String name;

    private String status;

    private String message;

    private String statusCode;

    private String code;

    @Override
    public List<ErrorInfo> getErrorResponse(String responseJson) {

        ApmViewSupport apmViewSupport = null;

        try {
            apmViewSupport = JsonHelper.fromJsonNoExcpLog(responseJson, ApmViewSupport.class,
                false /*unwrapRootValue*/, false /*failOnUnknownProperties*/, null /*registerModules*/);
        } catch (Exception excp) { // NOSONAR
            // Rest Util calls all the registered classes to check if the input json matches the given class.
            // if the current input json is not of this class, then JsonHelper might throw an error. We can
            // ignore these exceptions and initialize message as null;
        }

        if (apmViewSupport == null) {
            return null;
        }

        List<ErrorInfo> errorResponses = new ArrayList<>();
        if (!StringUtils.isBlank(apmViewSupport.getMessage())
            && !StringUtils.isBlank(apmViewSupport.getStatusCode())) {

            ErrorInfo errorInfo = new ErrorInfo();
            errorInfo.setCode(apmViewSupport.getCode());
            errorInfo.setHttpStatusCode(apmViewSupport.getStatusCode());
            errorInfo.setMessage(apmViewSupport.getMessage());

            errorResponses.add(errorInfo);
        }

        if (!errorResponses.isEmpty()) {
            return errorResponses;
        }

        return null;
    }
}
