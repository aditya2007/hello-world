/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.properties;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes;
import com.ge.apm.util.exceptions.ExceptionHelper;

@Aspect
@Component
public class ApmPropertiesAspect {
    private static final Logger logger = LoggerFactory.getLogger(ApmPropertiesAspect.class);

    @Around("execution(public * com.ge.apm.service.properties.ApmProperties.get*(..)) "
        + "|| execution(public * com.ge.apm.service.properties.ApmProperties.ServiceConfigProperties.get*(..) )")
    public Object getAroundAdvice(ProceedingJoinPoint pjp) throws Throwable {
        Object response = pjp.proceed();
        String methodName = pjp.getSignature().getName();

        // we will not do checks for optional value methods.
        if (methodName.contains("getOptional")) {
            return response;
        }

        if (response == null) {
            throw ExceptionHelper.getException(methodName, logger, ServiceInstancesErrorCodes.PROPERTY_IS_EMPTY, methodName.replace("get", ""));
        }

        if (response instanceof String) {
            String value = (String) response;

            if (StringUtils.isBlank(value)) {
                throw ExceptionHelper.getException(methodName, logger, ServiceInstancesErrorCodes.PROPERTY_IS_EMPTY,
                    methodName.replace("get", ""));
            }
        }
        return response;
    }
}
