/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.instances;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.common.config.IServiceInfoProvider;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class PxAssetInfoProvider implements IServiceInfoProvider {

    private String instanceId;

    private String uri;

    private Zone zone;

    private String label;

    private String name;

    private String serviceName;

    @Override
    public String getUri() {
        return this.uri;
    }

    @Override
    public String getZoneHeaderName() {
        return this.zone.getHttpHeaderName();
    }

    @Override
    public String getZoneHeaderValue() {
        return this.zone.getHttpHeaderValue();
    }

    @Override
    public String[] getZoneTokenScopes() {
        return new String[] { this.zone.getOauthScope() };
    }

    @Override
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    @Getter
    @Setter
    @ToString
    public static class Zone {
        @JsonProperty("http-header-name")
        private String httpHeaderName;

        @JsonProperty("http-header-value")
        private String httpHeaderValue;

        @JsonProperty("oauth-scope")
        private String oauthScope;
    }
}
