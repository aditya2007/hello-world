/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.tenants;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ForkJoinPool;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.resource.OAuth2AccessDeniedException;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ge.apm.common.support.RequestContext;
import com.ge.apm.service.instances.ServiceInstances;
import com.ge.apm.service.instances.ServiceInstances.TenantInfo;
import com.ge.apm.service.instances.filter.ServiceInstancesFilter;
import com.ge.apm.service.properties.ApmProperties;
import com.ge.apm.rest.config.HttpConfig;
import com.ge.apm.rest.oauth2.client.OAuth2PwdRestTemplate;
import com.ge.apm.rest.util.BearerTokenUtil;
import com.ge.apm.rest.util.BearerTokenUtil.BearerTokenGenInput;
import com.ge.apm.rest.util.BearerTokenUtil.GrantType;
import com.ge.apm.rest.util.RestUtil;
import com.ge.apm.service.instances.ServiceInstanceInfo;
import com.ge.apm.util.JsonHelper;

import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.ARRAY_DATA_OBJECT_NOT_FOUND_IN_TENANTS_JSON;
import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.CANNOT_FIND_TENANT_INFO;
import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.STUF_INSTANCE_ID_IS_NOT_FOUND;
import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.STUF_TOKEN_SCOPES_ARE_EMPTY;
import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.TENANT_ALIAS_NOT_FOUND;
import static com.ge.apm.service.instances.ServiceInstances.getJsonPathNode;
import static com.ge.apm.util.exceptions.ExceptionHelper.getException;

@SuppressWarnings("SpringAutowiredFieldsWarningInspection")
@Component
@Setter
public class TenantsUtil {

    private static final Logger logger = LoggerFactory.getLogger(TenantsUtil.class);

    @Autowired
    private RestUtil restUtil;

    @Autowired
    private ApmProperties apmProperties;

    @Autowired
    private HttpConfig httpConfig;

    private OAuth2RestTemplate oAuth2RestTemplate;

    @Getter
    private String stufInstanceId;

    @Value("${service.instance.uom.uri:}")
    private String uomJsonPath;

    private ForkJoinPool forkJoinPool;

    @PostConstruct
    public void initializeTenantsUtil() {
        forkJoinPool = new ForkJoinPool(10);
    }

    public List<TenantInfo> getAllTenantServiceInfo() {
        String methodName = "TenantsUtil.getAllTenantServiceInfo";
        stufInstanceId = "";

        ArrayNode tenantsJsonArrayNode = getAllTenantsJsonArrayNode();

        String originalAuthorization = (String) RequestContext.get(RequestContext.AUTHORIZATION);

        List<TenantInfo> allTenantInfo = new ArrayList<>();

        try {
            String stufToken = getStufToken();
            RequestContext.put(RequestContext.AUTHORIZATION, stufToken);

            Stream<JsonNode> tenantsJsonArrayNodeStream = IntStream.range(0, tenantsJsonArrayNode.size()).mapToObj(
                tenantsJsonArrayNode::get);

            ServiceInstances serviceInstances = apmProperties.getServiceInstances();

            Map<String, Object> requestContext = RequestContext.copy();
            forkJoinPool.submit(() -> tenantsJsonArrayNodeStream.parallel().forEach(tenantJsonNode -> {

                RequestContext.initialize(requestContext);
                JsonNode tenantUuidJsonNode = ServiceInstances
                    .getJsonPathNode(tenantJsonNode, ServiceInstances.TENANT_UUID_JSON_PATH);
                JsonNode tenantNameJsonNode = ServiceInstances
                    .getJsonPathNode(tenantJsonNode, ServiceInstances.TENANT_NAME_JSON_PATH);

                if (tenantNameJsonNode.textValue().equalsIgnoreCase("admin")) {
                    stufInstanceId = ServiceInstances
                        .getJsonPathNode(tenantJsonNode, ServiceInstances.INSTANCE_IDENTIFIER_JSON_PATH).textValue();
                    return;
                }

                // every time we run this method, we want to force update the instance info. The intention is to
                // capture any newly added tenants and tenant services.
                String tenantUuid = tenantUuidJsonNode.textValue();

                // we need to make the following call because the above tenant info json does not have
                // tenancyApplications. The tenancyApplications will have the information about defaultIdP.
                String tenantCompleteJson = getTenantCompleteJson(tenantUuid);

                TenantInfo tenantInfo = serviceInstances.initializeServiceInstances(tenantUuid, tenantCompleteJson,
                    true /*forceInitialization*/,
                    false /*throwOnServiceNotFound*/);

                if (tenantInfo != null) {
                    allTenantInfo.add(tenantInfo);
                }
            })).join();
        } finally {
            RequestContext.put(RequestContext.AUTHORIZATION, originalAuthorization);
        }

        if (StringUtils.isEmpty(stufInstanceId)) {
            throw getException(methodName, logger, STUF_INSTANCE_ID_IS_NOT_FOUND);
        }

        return allTenantInfo;
    }

    public TenantInfo getTenantServiceInfoByTenantId(String tenantId) {
        String methodName = "TenantsUtil.getAllTenantServiceInfo";
        stufInstanceId = "";

        String originalAuthorization = (String) RequestContext.get(RequestContext.AUTHORIZATION);
        Map<String, Object> requestContextCopy = RequestContext.copy();
        try {
            String stufToken = getStufToken();
            RequestContext.put(RequestContext.AUTHORIZATION, stufToken);

            ServiceInstances serviceInstances = apmProperties.getServiceInstances();

            RequestContext.initialize(RequestContext.copy());

            String tenantCompleteJson = getTenantCompleteJson(tenantId);

            return serviceInstances.initializeServiceInstances(tenantId, tenantCompleteJson, true , false);
        } finally {
            RequestContext.initialize(requestContextCopy);
            RequestContext.put(RequestContext.AUTHORIZATION, originalAuthorization);
        }
    }

    public String getTenantUuid(ArrayNode allTenantsJsonArrayNode, String tenantAliasName) {
        String methodName = "TenantsUtil.getTenantUuid";

        String tenantUuid = getTenantUuidNoThrow(allTenantsJsonArrayNode, tenantAliasName);

        if (StringUtils.hasText(tenantUuid)) {
            return tenantUuid;
        }

        throw getException(methodName, logger, TENANT_ALIAS_NOT_FOUND, tenantAliasName);
    }

    public String getStufInstanceId(ArrayNode allTenantsJsonArrayNode) {
        String methodName = "TenantsUtil.getStufInstanceId";
        ArrayNode tenantsJsonArrayNode = getAllTenantsJsonArrayNode();

        for (JsonNode tenantJsonNode : tenantsJsonArrayNode) {
            JsonNode tenantNameJsonNode = ServiceInstances
                .getJsonPathNode(tenantJsonNode, ServiceInstances.TENANT_NAME_JSON_PATH);

            if (tenantNameJsonNode.textValue().equalsIgnoreCase("admin")) {
                return ServiceInstances.getJsonPathNode(tenantJsonNode, ServiceInstances.INSTANCE_IDENTIFIER_JSON_PATH).textValue();
            }
        }

        throw getException(methodName, logger, STUF_INSTANCE_ID_IS_NOT_FOUND);
    }

    public String getTenantUuidNoThrow(ArrayNode allTenantsJsonArrayNode, String tenantAliasName) {
        for (JsonNode tenantJsonNode : allTenantsJsonArrayNode) {
            JsonNode tenantNameJsonNode = ServiceInstances
                .getJsonPathNode(tenantJsonNode, ServiceInstances.TENANT_NAME_JSON_PATH);

            if (tenantNameJsonNode.textValue().equalsIgnoreCase(tenantAliasName)) {
                return ServiceInstances.getJsonPathNode(tenantJsonNode, ServiceInstances.TENANT_UUID_JSON_PATH).textValue();
            }
        }

        return null;
    }

    private void initializeApmPropertiesWithInstancesJsonPath() {
        if (StringUtils.isEmpty(apmProperties.getOptionalUomJsonPath())) {
            apmProperties.setUomJsonPath(uomJsonPath);
        }
    }

    private String getStufToken() {
        String methodName = "TenantsUtil.getStufToken";
        initOAuth2RestTemplate();
        synchronized (this) {
            OAuth2AccessToken oauth2AccessToken;
            try {
                oauth2AccessToken = oAuth2RestTemplate.getAccessToken();
            } catch (OAuth2AccessDeniedException e) {
                String errorMessage = MessageFormat.format("Access token denied for the following resource. ''{0}''",
                    JsonHelper.toJson(oAuth2RestTemplate.getResource()));
                logger.error(errorMessage, e);
                throw getException(methodName, logger, errorMessage);
            }
            return oauth2AccessToken.getTokenType() + " " + oauth2AccessToken.getValue();
        }
    }

    @SuppressWarnings("Duplicates")
    private synchronized void initOAuth2RestTemplate() {

        if (oAuth2RestTemplate != null) {
            return;
        }

        BearerTokenGenInput bearerTokenGenInput = getStufTokenBearerTokenGenInput();

        ClientCredentialsResourceDetails resourceDetails = BearerTokenUtil.getClientTypeResourceDetails(
            bearerTokenGenInput);

        oAuth2RestTemplate = httpConfig.getOauth2RestTemplate(resourceDetails);
    }

    public BearerTokenGenInput getStufTokenBearerTokenGenInput() {
        String methodName = "TenantsUtil.getStufTokenBearerTokenGenInput";
        BearerTokenGenInput bearerTokenGenInput = new BearerTokenGenInput();

        bearerTokenGenInput.setGrantType(GrantType.GRANT_TYPE_CLIENT_CREDENTIALS);
        bearerTokenGenInput.setRestUtil(this.restUtil);

        bearerTokenGenInput.setUaaUrl(apmProperties.getServiceConfigProperties().getTrustedIssuer());
        bearerTokenGenInput.setClientId(apmProperties.getServiceConfigProperties().getClientId());
        bearerTokenGenInput.setClientSecret(apmProperties.getServiceConfigProperties().getClientSecret());

        if (!StringUtils.hasText(apmProperties.getStufTokenScopes())) {
            throw getException(methodName, logger, STUF_TOKEN_SCOPES_ARE_EMPTY);
        }

        String[] stufScopes = StringUtils.split(apmProperties.getStufTokenScopes(), ",");

        if (stufScopes == null) {
            stufScopes = new String[] {apmProperties.getStufTokenScopes()};
        }

        bearerTokenGenInput.setScopes(stufScopes);

        return bearerTokenGenInput;
    }

    private TenantsJsonInfo getAllTenantsJson(int limit, int offset) {

        String tenantUuid = (String) RequestContext.get(RequestContext.TENANT_UUID);

        try {
            RequestContext.remove(RequestContext.TENANT_UUID);
            Map<String, Object> queryParams = new HashMap<>();
            queryParams.put("limit", limit);
            queryParams.put("offset", offset);

            String url = apmProperties.getServiceConfigProperties().getTenantServiceUrl() + "/v1/tenants";
            //noinspection SpellCheckingInspection
            return restUtil.doGet(url, TenantsJsonInfo.class, queryParams);
        } finally {
            RequestContext.put(RequestContext.TENANT_UUID, tenantUuid);
        }
    }

    @Getter
    @Setter
    private static class TenantsJsonInfo {

        private JsonNode dataObject;

        private int offset;

        private int total;
    }

    public ArrayNode getAllTenantsJsonArrayNode() {
        String methodName = "TenantsUtil.getAllTenantServiceInfo";
        stufInstanceId = "";
        String originalAuthorization = (String) RequestContext.get(RequestContext.AUTHORIZATION);

        try {
            initializeApmPropertiesWithInstancesJsonPath();

            String stufToken = getStufToken();
            RequestContext.put(RequestContext.AUTHORIZATION, stufToken);

            ArrayNode allTenantsArrayNode = null;
            int totalRetrieved = 0;
            int limit = 50;
            int offset = 0;
            while (true) {
                TenantsJsonInfo tenantsJsonInfo = getAllTenantsJson(limit, offset);

                JsonNode dataObjectNode = tenantsJsonInfo.dataObject;

                if (!(dataObjectNode instanceof ArrayNode)) {
                    logger.error("Invalid Json: '{}'", JsonHelper.toJson(tenantsJsonInfo));
                    throw getException(methodName, logger, ARRAY_DATA_OBJECT_NOT_FOUND_IN_TENANTS_JSON);
                }

                if (allTenantsArrayNode == null) {
                    allTenantsArrayNode = (ArrayNode) dataObjectNode;
                } else {
                    allTenantsArrayNode.addAll((ArrayNode) dataObjectNode);
                }

                totalRetrieved = totalRetrieved + limit;

                if (tenantsJsonInfo.getTotal() < totalRetrieved) {
                    break;
                }
                // in the first iteration totalRetrieved will be 50. If the total is more than 50, then we are asking
                // to get from 51
                offset = totalRetrieved + 1;
            }

            return allTenantsArrayNode;
        } finally {
            RequestContext.put(RequestContext.AUTHORIZATION, originalAuthorization);
        }
    }

    private String getTenantCompleteJson(String tenantUuid) {
        RequestContext.put(RequestContext.TENANT_UUID, tenantUuid);
        String url = apmProperties.getServiceConfigProperties().getTenantServiceUrl() + "/v1/tenants/" + tenantUuid;
        return restUtil.doGet(url, String.class);
    }


}
