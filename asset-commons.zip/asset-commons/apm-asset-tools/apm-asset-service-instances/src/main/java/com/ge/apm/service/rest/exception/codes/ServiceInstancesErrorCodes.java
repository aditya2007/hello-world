/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.rest.exception.codes;

import com.ge.apm.common.exception.IErrorCode;

public enum ServiceInstancesErrorCodes implements IErrorCode {
    INTERNAL_SERVER_ERROR("Internal Server error. Please contact support."),
    TENANT_NOT_FOUND("Tenant identifier is not found in tenant context"),
    TENANT_DOES_NOT_CONTAIN_SERVICE_INSTANCES("The tenant '%s' does not have value for the property '%s'."),
    INVALID_INSTANCE_JSON_PATH("The service instances JSON does not contain data for the property '%s'."),
    INSTANCE_JSON_PATH_VALUE_IS_EMPTY("The service instance '%s' JSON has empty value for the property '%s'."),
    INSTANCE_PATH_NOT_PROVIDED("The property '%s' value is empty for the service instance '%s'."),
    ERROR_CONVERTING_JSON_TO_NODE("Error converting the JSON into JsonNode."),
    SERVICE_INSTANCE_PROPS_ALREADY_REGISTERED("Service instance properties for '%s' has already been registered."),
    VALUE_NOT_FOUND_FOR_SERVICE_PATH("The service instance '%s' does not have value for the path '%s'."),
    SERVICE_INSTANCE_INFO_NOT_AVAILABLE("The tenant '%s' does not have service instance information for '%s'."),
    SERVICE_INSTANCES_INFO_NOT_INITIALIZED(
        "Service instances information has not been initialized for the " + "tenant '%s'."),
    SERVICE_INSTANCE_INFO_NOT_INITIALIZED(
        "Service instance information has not been initialized for the " + "service '%s' in the tenant '%s'."),
    CANNOT_FIND_PROPERTY_IN_TENANT_INFO("Cannot find value for the property '%s' in tenant information."),
    PROPERTY_IS_EMPTY("The value for the property '%s' is empty."),
    STUF_INSTANCE_ID_IS_NOT_FOUND("Stuf instance identifier is not found."),
    ARRAY_DATA_OBJECT_NOT_FOUND_IN_TENANTS_JSON(
        "Invalid data object node. The data object node in tenants Json is " + "supposed to be array node."),
    TENANT_ALIAS_NOT_FOUND("Tenant alias name '%s' is not found in all tenants information."),
    CANNOT_FIND_TENANT_INFO("Unable to find the tenant information for the tenant '%s'."),
    STUF_TOKEN_SCOPES_ARE_EMPTY("Stuf token scope values are not provided.");

    private String message;

    ServiceInstancesErrorCodes(String s) {
        this.message = s;
    }

    @Override
    public String message() {
        return this.message;
    }
}
