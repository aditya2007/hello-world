/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.properties;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ge.apm.rest.config.HttpConfig;
import com.ge.apm.service.instances.ServiceInstances;

@SuppressWarnings({ "WeakerAccess", "unused" })
@Component
@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApmProperties {

    private static final Logger logger = LoggerFactory.getLogger(ApmProperties.class);

    public static final String SPACE_NAME = "space.name";

    public static final String URL_DOMAIN = "url.domain";

    public static final String PREDIX_ANALYTIC_URL_DOMAIN = "preidx.analytic.url.domain";

    public static final String TENANT_UUID = "tenant.uuid";

    public static final String HTTP_PROTOCOL = "http.protocol";

    public static final String CONFIG_COMPONENT_NAME = "config.component.name";

    public static final String ADMIN_AUTHORIZATION = "admin.authorization";

    public static final String MGR_AUTHORIZATION = "mgr.authorization";

    public static final String INGESTOR_AUTHORIZATION = "ingestor.authorization";

    public static final String INGESTOR_USER_NAME = "ingestor.user.name";

    public static final String INGESTOR_CLIENT_ID = "ingestor.client.id";

    public static final String WEB_APP_CLIENT_ID = "web.app.client.id";

    public static final String UAA_URL = "uaa.url";

    public static final String WEB_APP_URL = "web.app.url";

    public static final String ADMIN_USER_NAME = "admin.user.name";

    public static final String ADMIN_PASSWORD = "admin.password"; //NOSONAR

    public static final String MGR_USER_NAME = "mgr.user.name";

    public static final String USE_PROXY = "use.proxy";

    public static final String PROXY_HOST = "proxy.host";

    public static final String PROXY_PORT = "proxy.port";

    public static final String MGR_PASSWORD = "mgr.password"; //NOSONAR

    public static final String AUTH_TOKEN_ISSUER = "authTokenIssuer";

    public static final String ACS_SERVICE_NAME = "acsServiceName";

    public static final String SERVICE_INSTANCE_PX_ACS_NAME = "service.instance.px_acs.name";

    public static final String INGESTOR_PASSWORD = "ingestor.password"; // NOSONAR

    public static final String STUF_CLIENT_ID = "stuf.clientId";

    public static final String STUF_CLIENT_SECRET = "stuf.clientSecret";

    public static final String STUF_SERVICE_INSTANCE_ID = "stuf.serviceInstanceId";

    public static final String STUF_AUTHORIZATIONS = "stuf.%s.zone,stuf.read";

    public static final String STUF_TENANT_SERVICE_URL = "stuf.tenantServiceUrl";

    public static final String TENANT_ALIAS = "tenant.alias";

    public static final String APM_ASSET_QUERY_ENABLE_FLAG = "apm.asset.query.enabled";

    private static ApmProperties apmProperties;

    @JsonIgnore
    private ServiceInstances serviceInstances;

    // provides uaaUrl, userServiceUrl, configServiceUrl, tenantServiceUrl, clientId, clientSecret etc.
    @Autowired
    private ServiceConfigProperties serviceConfigProperties;

    @Value("${assets.page.size:1000}")
    private int assetsPageSize;

    @Value("${spring.redis.port:-1}")
    private int redisPortNo;

    @Value("${service.instance.px_acs.name:}")
    private String acsServiceName;

    @Value("${apm.asset.url:}")
    private String assetUrl;

    @Value("${apm.timeseries.url:}")
    private String timeseriesUrl;

    @Value("${apm.alarm.url:}")
    private String alarmMgmtUrl;

    @Value("${apm.alert.template.url:}")
    private String alertTemplateUrl;

    @Value("${apm.analytic.url:}")
    private String analyticUrl;

    @Value("${apm.orchestration.url:}")
    private String orchestrationUrl;

    @Value("${ss.deployments.url:}")
    private String ssDeploymentsUrl;

    @Value("${space.name}")
    private String spaceName;

    @Value("${apm.asset.adapter.url:}")
    private String assetAdapterUrl;

    @Value("${apm.adapter.config.provider:}")
    private String adapterConfigUrl;

    @Value("${uaa.host.name:}")
    private String uaaHostName;

    @Value("${uaa.instance.id:}")
    private String uaaInstanceId;

    @Value("${url.domain:}")
    private String urlDomain;

    @Value("${predix.analytic.url.domain:}")
    private String predixAnalyticUrlDomain;

    @Value("${tenant.uuid:}")
    private String tenantUuid;

    @Value("${service.instance.px_eventhub.name:}")
    private String pxEventHubServiceName;

    @Value("${service.instance.px_eventhub.uri:}")
    private String pxEventHubUri;

    @Value("${service.instance.px_eventhub.uri.json.path:}")
    private String pxEventHubUriJsonPath;

    @Value("${service.instance.px_eventhub.zone.header.name:}")
    private String pxEventHubZoneHeaderName;

    @Value("${service.instance.px_eventhub.zone.header.value:}")
    private String pxEventHubZoneHeaderValue;

    @Value("${service.instance.px_eventhub.oauth.scope:}")
    private String pxEventHubOauthScope;

    @Value("${service.instance.px_eventhub.protocol:}")
    private String pxEventHubProtocol;

    @Value("${service.instance.px_blob.name:}")
    private String pxBlobServiceName;

    @Value("${service.instance.px_blob.url.path:}")
    private String pxBlobServiceUrlPath;

    @Value("${service.instance.px_blob.bucket_name.path:}")
    private String pxBlobServiceBucketNamePath;

    @Value("${service.instance.px_blob.host.path:}")
    private String pxBlobServiceHostPath;

    @Value("${service.instance.px_blob.access_key_id.path:}")
    private String pxBlobServiceAccessKeyIdPath;

    @Value("${service.instance.px_blob.secret_access_key.path:}")
    private String pxBlobServiceSecretAccessKeyPath;

    @Value("${service.instance.px_timeseries.name:}")
    private String pxTsServiceName;

    @Value("${service.instance.px_timeseries.uri:}")
    private String pxTsUri;

    // we are initializing the original paths in a different variable because the variables that were initialized with
    // json paths will be replaced with the values corresponding to the path. However, there are situations
    // where we would like to refer to the original paths. So, creating new variables which contains the original
    // json path.
    @Value("${service.instance.px_timeseries.uri.json.path:}")
    private String pxTsUriJsonPath;

    @Value("${service.instance.px_timeseries.zone.header.name:}")
    private String pxTsZoneHeaderName;

    @Value("${service.instance.px_timeseries.zone.header.value:}")
    private String pxTsZoneHeaderValue;

    @Value("${service.instance.px_timeseries.oauth.scope:}")
    private String pxTsOauthScope;

    @Value("${service.instance.uom.name:}")
    private String uomServiceName;

    @Value("${service.instance.uom.uri:}")
    private String uomUri;

    // we are initializing the original paths in a different variable because the variables that were initialized with
    // json paths will be replaced with the values corresponding to the path. However, there are situations
    // where we would like to refer to the original paths. So, creating new variables which contains the original
    // json path.
    @Value("${service.instance.uom.uri.json.path:}")
    private String uomJsonPath;

    @Value("${service.instance.uom.zone.header.name:}")
    private String uomZoneHeaderName;

    @Value("${service.instance.uom.zone.header.value:}")
    private String uomZoneHeaderValue;

    @Value("${service.instance.uom.oauth.scope:}")
    private String uomOauthScope;

    @Value("${service.instance.px_catalog.name:}")
    private String pxCatalogServiceName;

    @Value("${service.instance.px_catalog.uri:}")
    private String pxCatalogUri;

    // we are initializing the original paths in a different variable because the variables that were initialized with
    // json paths will be replaced with the values corresponding to the path. However, there are situations
    // where we would like to refer to the original paths. So, creating new variables which contains the original
    // json path.
    @Value("${service.instance.px_catalog.uri.json.path:}")
    private String pxCatalogUriJsonPath;

    @Value("${service.instance.px_catalog.zone.header.name:}")
    private String pxCatalogZoneHeaderName;

    @Value("${service.instance.px_catalog.zone.header.value:}")
    private String pxCatalogZoneHeaderValue;

    @Value("${service.instance.px_catalog.oauth.scope:}")
    private String pxCatalogOauthScope;

    @Value("${service.instance.px_runtime.name:}")
    private String pxRuntimeServiceName;

    @Value("${service.instance.px_runtime.config.uri:}")
    private String pxRuntimeConfigUri;

    // we are initializing the original paths in a different variable because the variables that were initialized with
    // json paths will be replaced with the values corresponding to the path. However, there are situations
    // where we would like to refer to the original paths. So, creating new variables which contains the original
    // json path.
    @Value("${service.instance.px_runtime.config.uri.json.path:}")
    private String pxRuntimeConfigUriJsonPath;

    @Value("${service.instance.px_runtime.execution.uri:}")
    private String pxRuntimeExecutionUri;

    // we are initializing the original paths in a different variable because the variables that were initialized with
    // json paths will be replaced with the values corresponding to the path. However, there are situations
    // where we would like to refer to the original paths. So, creating new variables which contains the original
    // json path.
    @Value("${service.instance.px_runtime.execution.uri.json.path:}")
    private String pxRuntimeExecutionUriJsonPath;

    @Value("${service.instance.px_runtime.monitoring.uri:}")
    private String pxRuntimeMonitoringUri;

    // we are initializing the original paths in a different variable because the variables that were initialized with
    // json paths will be replaced with the values corresponding to the path. However, there are situations
    // where we would like to refer to the original paths. So, creating new variables which contains the original
    // json path.
    @Value("${service.instance.px_runtime.monitoring.uri.json.path:}")
    private String pxRuntimeMonitoringUriJsonPath;

    @Value("${service.instance.px_runtime.scheduler.uri:}")
    private String pxRuntimeSchedulerUri;

    // we are initializing the original paths in a different variable because the variables that were initialized with
    // json paths will be replaced with the values corresponding to the path. However, there are situations
    // where we would like to refer to the original paths. So, creating new variables which contains the original
    // json path.
    @Value("${service.instance.px_runtime.scheduler.uri.json.path:}")
    private String pxRuntimeSchedulerUriJsonPath;

    @Value("${service.instance.px_runtime.zone.header.name:}")
    private String pxRuntimeZoneHeaderName;

    @Value("${service.instance.px_runtime.zone.header.value:}")
    private String pxRuntimeZoneHeaderValue;

    @Value("${service.instance.px_runtime.oauth.scope:}")
    private String pxRuntimeOauthScope;

    @Value("${analytics.runtime.client.secret:}")
    private String pxAnalyticExecuteClientSecret;

    @Value("${apm.user.password:}")
    private String apmUserPassword;

    @Value("${stuf.adminUrl}")
    private String stufAdminUrl;

    @Value("${stuf.serviceInstanceId}")
    private String stufServiceInstanceId;

    @Value("${stuf.token.scopes:}")
    private String stufTokenScopes;

    @Value("${apm.alerts.gateway.url:}")
    private String alertsGatewayUrl;

    @Value("${" + WEB_APP_CLIENT_ID + ":}")
    private String adminAuthorization;

    @Value("${" + MGR_AUTHORIZATION + ":}")
    private String mgrAuthorization;

    @Value("${" + INGESTOR_AUTHORIZATION + ":}")
    private String ingestorAuthorization;

    @Value("${" + INGESTOR_USER_NAME + ":}")
    private String ingestorUserName;

    @Value("${" + INGESTOR_PASSWORD + ":}")
    private String ingestorPassword;

    @Value("${" + WEB_APP_CLIENT_ID + ":}")
    private String webAppClientId;

    @Value("${" + INGESTOR_CLIENT_ID + ":}")
    private String ingestorClientId;

    @Value("${" + TENANT_ALIAS + ":}")
    private String tenantAlias;

    @Value("${" + HTTP_PROTOCOL + ":}")
    private String httpProtocol;

    @PostConstruct
    public void initialize() {

        if (!StringUtils.isEmpty(alertsGatewayUrl)) {
            alertsGatewayUrl = alertsGatewayUrl.replace("v1", "");
        }
    }

    public static void set(ApmProperties apmProperties) {
        ApmProperties.apmProperties = apmProperties;
    }

    @SuppressWarnings("unused")
    @Component
    @Getter
    @Setter
    public static class ServiceConfigProperties {

        @Value("${stuf.uaaUrl:}")
        private String uaaUrl;

        @Value("${stuf.userServiceUrl:}")
        private String userServiceUrl;

        @Value("${stuf.configServiceUrl:}")
        private String configServiceUrl;

        @Value("${stuf.tenantServiceUrl:}")
        private String tenantServiceUrl;

        @Value("${stuf.securityServiceUrl:}")
        private String securityServiceUrl;

        @Value("${stuf.adminUrl:}")
        private String adminUrl;

        @Value("${stuf.serviceInstanceId:}")
        private String stufServiceInstanceId;

        @Value("${stuf.clientId:}")
        private String clientId;

        @Value("${stuf.clientSecret:}")
        private String clientSecret;

        @JsonIgnore
        @Autowired
        private final HttpConfig httpConfig;

        public ServiceConfigProperties(HttpConfig httpConfig) {
            this.httpConfig = httpConfig;
        }

        public ServiceConfigProperties() {
            httpConfig = null;
        }

        public String getClientId() {
            return clientId;
        }

        public String getClientSecret() {
            return clientSecret;
        }

        public String getTenantServiceUrl() {
            return tenantServiceUrl;
        }

        public String getUserServiceUrl() {
            return userServiceUrl;
        }

        public String getSecurityServiceUrl() {
            return securityServiceUrl;
        }

        public String getTrustedIssuer() {
            return this.uaaUrl + "/oauth/token";
        }

        public String getConfigServiceUrl() {
            return configServiceUrl;
        }
    }

    public String getOptionalAcsServiceName() {
        return acsServiceName;
    }

    public String getOptionalAssetUrl() {
        return assetUrl;
    }

    public String getOptionalTimeseriesUrl() {
        return timeseriesUrl;
    }

    public String getOptionalAlarmMgmtUrl() {
        return alarmMgmtUrl;
    }

    public String getOptionalAlertProfileUrl() {
        return alertTemplateUrl;
    }

    public String getOptionalAnalyticUrl() {
        return analyticUrl;
    }

    public String getOptionalOrchestrationUrl() {
        return orchestrationUrl;
    }

    public String getOptionalSsDeploymentsUrl() {
        return ssDeploymentsUrl;
    }

    public String getOptionalSpaceName() {
        return spaceName;
    }

    public String getOptionalAssetAdapterUrl() {
        return assetAdapterUrl;
    }

    public String getOptionalAdapterConfigUrl() {
        return adapterConfigUrl;
    }

    public String getOptionalUaaHostName() {
        return uaaHostName;
    }

    public String getOptionalUrlDomain() {
        return urlDomain;
    }

    public String getOptionalTenantUuid() {
        return tenantUuid;
    }

    public String getOptionalPxEventHubServiceName() {
        return pxEventHubServiceName;
    }

    public String getOptionalPxEventHubUri() {
        return pxEventHubUri;
    }

    public String getOptionalPxEventHubUriJsonPath() {
        return pxEventHubUriJsonPath;
    }

    public String getOptionalPxEventHubZoneHeaderName() {
        return pxEventHubZoneHeaderName;
    }

    public String getOptionalPxEventHubZoneHeaderValue() {
        return pxEventHubZoneHeaderValue;
    }

    public String getOptionalPxEventHubOauthScope() {
        return pxEventHubOauthScope;
    }

    public String getOptionalPxEventHubProtocol() {
        return pxEventHubProtocol;
    }

    public String getOptionalPxBlobServiceName() {
        return pxBlobServiceName;
    }

    public String getOptionalPxBlobServiceUrlPath() {
        return pxBlobServiceUrlPath;
    }

    public String getOptionalPxBlobServiceBucketNamePath() {
        return pxBlobServiceBucketNamePath;
    }

    public String getOptionalPxBlobServiceHostPath() {
        return pxBlobServiceHostPath;
    }

    public String getOptionalPxBlobServiceAccessKeyIdPath() {
        return pxBlobServiceAccessKeyIdPath;
    }

    public String getOptionalPxBlobServiceSecretAccessKeyPath() {
        return pxBlobServiceSecretAccessKeyPath;
    }

    public String getOptionalPxTsServiceName() {
        return pxTsServiceName;
    }

    public String getOptionalPxTsUri() {
        return pxTsUri;
    }

    public String getOptionalPxTsUriJsonPath() {
        return pxTsUriJsonPath;
    }

    public String getOptionalPxTsZoneHeaderName() {
        return pxTsZoneHeaderName;
    }

    public String getOptionalPxTsZoneHeaderValue() {
        return pxTsZoneHeaderValue;
    }

    public String getOptionalPxTsOauthScope() {
        return pxTsOauthScope;
    }

    public String getOptionalUomServiceName() {
        return uomServiceName;
    }

    public String getOptionalUomUri() {
        return uomUri;
    }

    public String getOptionalUomJsonPath() {
        return uomJsonPath;
    }

    public String getOptionalUomZoneHeaderName() {
        return uomZoneHeaderName;
    }

    public String getOptionalUomZoneHeaderValue() {
        return uomZoneHeaderValue;
    }

    public String getOptionalUomOauthScope() {
        return uomOauthScope;
    }

    public String getOptionalPxCatalogServiceName() {
        return pxCatalogServiceName;
    }

    public String getOptionalPxCatalogUri() {
        return pxCatalogUri;
    }

    public String getOptionalPxCatalogUriJsonPath() {
        return pxCatalogUriJsonPath;
    }

    public String getOptionalPxCatalogZoneHeaderName() {
        return pxCatalogZoneHeaderName;
    }

    public String getOptionalPxCatalogZoneHeaderValue() {
        return pxCatalogZoneHeaderValue;
    }

    public String getOptionalPxCatalogOauthScope() {
        return pxCatalogOauthScope;
    }

    public String getOptionalPxRuntimeServiceName() {
        return pxRuntimeServiceName;
    }

    public String getOptionalPxRuntimeConfigUri() {
        return pxRuntimeConfigUri;
    }

    public String getOptionalPxRuntimeConfigUriJsonPath() {
        return pxRuntimeConfigUriJsonPath;
    }

    public String getOptionalPxRuntimeExecutionUri() {
        return pxRuntimeExecutionUri;
    }

    public String getOptionalPxRuntimeExecutionUriJsonPath() {
        return pxRuntimeExecutionUriJsonPath;
    }

    public String getOptionalPxRuntimeMonitoringUri() {
        return pxRuntimeMonitoringUri;
    }

    public String getOptionalPxRuntimeMonitoringUriJsonPath() {
        return pxRuntimeMonitoringUriJsonPath;
    }

    public String getOptionalPxRuntimeSchedulerUri() {
        return pxRuntimeSchedulerUri;
    }

    public String getOptionalPxRuntimeSchedulerUriJsonPath() {
        return pxRuntimeSchedulerUriJsonPath;
    }

    public String getOptionalPxRuntimeZoneHeaderName() {
        return pxRuntimeZoneHeaderName;
    }

    public String getOptionalPxRuntimeZoneHeaderValue() {
        return pxRuntimeZoneHeaderValue;
    }

    public String getOptionalPxRuntimeOauthScope() {
        return pxRuntimeOauthScope;
    }

    public String getOptionalStufAdminUrl() {
        return stufAdminUrl;
    }

    public String getOptionalStufServiceInstanceId() {
        return stufServiceInstanceId;
    }

    public String getOptionalStufTokenScopes() {
        return stufTokenScopes;
    }

    public String getOptionalAlertsGatewayUrl() {
        return alertsGatewayUrl;
    }

    public String getOptionalIngestorAuthorization() {
        return ingestorAuthorization;
    }

    public String getOptionalAdminAuthorization() {
        return adminAuthorization;
    }

    public String getOptionalMgrAuthorization() {
        return mgrAuthorization;
    }

    public String getOptionalIngestorUserName() {
        return ingestorUserName;
    }

    public String getOptionalIngestorPassword() {
        return ingestorPassword;
    }

    public String getOptionalWebAppClientId() {
        return webAppClientId;
    }

    public String getOptionalIngestorClientId() {
        return ingestorClientId;
    }

    public String getOptionalTenantAlias() {
        return tenantAlias;
    }

    public String getOptionalHttpProtocol() {
        return httpProtocol;
    }
}
