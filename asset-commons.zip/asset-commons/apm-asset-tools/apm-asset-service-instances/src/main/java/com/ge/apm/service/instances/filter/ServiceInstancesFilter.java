/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.instances.filter;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.ge.apm.common.support.RequestContext;
import com.ge.apm.service.instances.ServiceInstances;
import com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes;
import com.ge.apm.service.tenants.TenantsUtil;
import com.ge.apm.util.exceptions.ExceptionHelper;
import com.ge.apm.util.servlets.HttpServletUtils;

@SuppressWarnings("SpringAutowiredFieldsWarningInspection")
@Component
public class ServiceInstancesFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(ServiceInstancesFilter.class);

    public static final String AUTHENTICATION = "Authentication";

    @Autowired
    private ServiceInstances serviceInstances;

    @Autowired
    private TenantsUtil tenantsUtil;

    @Value("${initialize.service.instances.filter:true}")
    private Boolean initializeServiceInstances;

    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
        FilterChain filterChain) throws ServletException, IOException {
        try {

            httpServletResponse.addHeader("Server", "none");

            String requestUri = HttpServletUtils.getRequestUri(httpServletRequest);

            RequestContext.put(RequestContext.AUTHORIZATION, httpServletRequest.getHeader(HttpHeaders.AUTHORIZATION));
            RequestContext.put(RequestContext.TENANT_UUID, httpServletRequest.getHeader(RequestContext.TENANT));
            RequestContext.put(RequestContext.HTTP_SERVLET_REQUEST, httpServletRequest);
            RequestContext.put(RequestContext.HTTP_SERVLET_RESPONSE, httpServletResponse);

            RequestContext.put(AUTHENTICATION, SecurityContextHolder.getContext().getAuthentication());

            if (initializeServiceInstances) {
                this.serviceInstances.initializeServiceInstances(getTenantUuid());
            }
            filterChain.doFilter(httpServletRequest, httpServletResponse);
        } finally {
            RequestContext.remove(RequestContext.AUTHORIZATION);
            RequestContext.remove(RequestContext.TENANT_UUID);
            RequestContext.remove(RequestContext.HTTP_SERVLET_REQUEST);
            RequestContext.remove(RequestContext.HTTP_SERVLET_RESPONSE);
            RequestContext.remove(AUTHENTICATION);
        }
    }

    public static String getTenantUuid() {
        String methodName = "ServiceInstances.getTenantUuid";
        String tenantUuid = (String) RequestContext.get(RequestContext.TENANT_UUID);

        if (tenantUuid == null) {
            throw ExceptionHelper.getException(methodName, logger, ServiceInstancesErrorCodes.TENANT_NOT_FOUND);
        }
        return tenantUuid;
    }
}
