/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.instances;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.TextNode;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.rest.config.HttpConfig;
import com.ge.apm.rest.oauth2.client.OAuth2PwdRestTemplate;
import com.ge.apm.rest.util.RestUtil;
import com.ge.apm.service.properties.ApmProperties;
import com.ge.apm.service.properties.ApmProperties.ServiceConfigProperties;
import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.CANNOT_FIND_PROPERTY_IN_TENANT_INFO;
import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.ERROR_CONVERTING_JSON_TO_NODE;
import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.INSTANCE_JSON_PATH_VALUE_IS_EMPTY;
import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.INVALID_INSTANCE_JSON_PATH;
import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.SERVICE_INSTANCES_INFO_NOT_INITIALIZED;
import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.SERVICE_INSTANCE_INFO_NOT_AVAILABLE;
import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.SERVICE_INSTANCE_INFO_NOT_INITIALIZED;
import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes
    .SERVICE_INSTANCE_PROPS_ALREADY_REGISTERED;
import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes
    .TENANT_DOES_NOT_CONTAIN_SERVICE_INSTANCES;

@SuppressWarnings({ "WeakerAccess", "Duplicates", "SpringAutowiredFieldsWarningInspection" })
@Component
public class ServiceInstances {

    public static final String SERVICE_INSTANCES_KEYWD = "serviceInstances";

    public static final String TENANCY_APPLICATIONS_KEYWD = "tenancyApplications";

    public static final String ALIAS_KEYWD = "alias";

    public static final String IS_DEFAULT_IDP_JSON_PATH = "/defaultIdP";

    public static final String DEFAULT_IDP_UUID_JSON_PATH = "/identityProvider/uuid";

    public static final String DEFAULT_IDP_URL_JSON_PATH = "/identityProvider/uaaZone/url";

    public static final String DEFAULT_IDP_ORIGIN_JSON_PATH = "/identityProvider/origin";

    public static final String TENANT_UUID_JSON_PATH = "/uuid";

    public static final String TENANT_NAME_JSON_PATH = "/name";

    public static final String INSTANCE_IDENTIFIER_JSON_PATH = "/instance/uuid";

    private static final Logger logger = LoggerFactory.getLogger(ServiceInstances.class);

    // tenant uuid to tenant info.
    private final ConcurrentHashMap<String, TenantInfo> mapTenantInfo = new ConcurrentHashMap<>();

    // service name to its corresponding properties.
    private Map<String, ServiceInstanceProperties> serviceInstancePropertiesMap = new ConcurrentHashMap<>();

    @Autowired
    private ApmProperties apmProperties;

    @SuppressWarnings("FieldCanBeLocal")
    private boolean skipInitOfServiceInstances = false;

    @Autowired
    private RestUtil restUtil;

    @Autowired
    private HttpConfig httpConfig;

    @Autowired
    private ServiceConfigProperties serviceConfigProperties;

    @Value("${skip.analytics.user.token:false}")
    private boolean skipAnalyticsUserToken = false;

    @Value("#{'${service.instance.optional.services:}'.split(',')}")
    private List<String> optionalServices;

    @PostConstruct
    public void initialize() {
        apmProperties.setServiceInstances(this);
    }

    public void initializeServiceInstances(String tenantUuid) {
        initializeServiceInstances(tenantUuid, null /* tenantInfoJson */, false /*forceInitialization*/, true
            /*throwOnServiceNotFound*/);
    }

    public TenantInfo initializeServiceInstances(String tenantUuid, String tenantInfoJson, boolean forceInitialization,
        boolean throwOnServiceNotFound) {

        TenantInfo tenantInfo = null;

        if (!this.skipInitOfServiceInstances) {

            this.serviceInstancePropertiesMap.values().stream().filter(serviceInstanceProperty ->
                // If the service instance info. is not found for the current service instance, then initialize it.
                // Since we are checking if it exists or not, we do not want to throw exception. So, by default
                // sending false to throwOnServiceNotFound without using input parameter. If the response is null,
                // we will get calling initIfNotExistAndGetServiceInstanceInfo
                getServiceInstanceInfo(tenantUuid, serviceInstanceProperty.getServiceName(), false /*
                throwOnServiceNotFound */) == null).forEach(
                serviceInstanceProperty -> initIfNotExistAndGetServiceInstanceInfo(tenantUuid, tenantInfoJson,
                    forceInitialization, serviceInstanceProperty, throwOnServiceNotFound));

            tenantInfo = getTenantInfo(tenantUuid, throwOnServiceNotFound);

            // tenantInfo will be null only when throwOnServiceNotFound = false and service not found
            if (tenantInfo == null) {
                return null;
            }
        }

        return tenantInfo;
    }

    public synchronized ServiceInstanceInfo initIfNotExistAndGetServiceInstanceInfo(String tenantUuid,
        String tenantInfoJson, boolean forceInitialization, ServiceInstanceProperties instanceProperties,
        boolean throwOnServiceNotFound) {

        String methodName = "ServiceInstances.initIfNotExistAndGetServiceInstanceInfo";

        TenantInfo tenantInfo = mapTenantInfo.get(tenantUuid);

        String serviceInstanceName = instanceProperties.getServiceName();
        if (optionalServices.contains(serviceInstanceName)) {
            throwOnServiceNotFound = false;
        }

        boolean newTenantInfoCreated = false;
        if (tenantInfo == null || forceInitialization) {
            if (tenantInfoJson == null) {
                tenantInfoJson = getInstancesJson(this.restUtil, serviceConfigProperties.getTenantServiceUrl(),
                    tenantUuid);
            }
            if (tenantInfo == null) {
                tenantInfo = new TenantInfo();
            }
            tenantInfo = createTenantInfoFromJson(tenantInfoJson, tenantInfo, throwOnServiceNotFound);

            // tenantInfo will be null only when throwOnServiceNotFound = false and service not found
            if (tenantInfo == null) {
                return null;
            }

            newTenantInfoCreated = true;
        } else {
            Map<String, ServiceInstanceInfo> serviceInstanceInfoMap = tenantInfo.getServiceNameToInfo();

            ServiceInstanceInfo foundServiceInstanceInfo = serviceInstanceInfoMap.get(serviceInstanceName);

            if (foundServiceInstanceInfo != null) {
                return foundServiceInstanceInfo;
            }
        }

        JsonNode serviceInstanceJsonNode = getServiceInstanceNodeNoThrow(tenantInfo.getServiceInstancesJsonNode(),
            serviceInstanceName);

        // if we have initialized tenantInfo object using tenantInfoJon in the current method and still could
        // not find service instance information for the given service instance name, then it is an error.
        if (newTenantInfoCreated && serviceInstanceJsonNode == null) {

            // if throwOnServiceNotFound is false, then we will return null if we cannot find info. about
            // serviceInstanceName.
            if (!throwOnServiceNotFound) {
                return null;
            }

            throw ExceptionHelper.getException(methodName, logger, SERVICE_INSTANCE_INFO_NOT_AVAILABLE, tenantUuid,
                serviceInstanceName);
        }

        // if we are here in this method, it implies that new tenant info object has not been initialized in this
        // method. If we cannot find service instance node, then try to get latest tenant information and check if
        // it exists.
        if (serviceInstanceJsonNode == null) {

            // If the service instance info we are looking for is optional and we are not trying to forceInitialize
            // then avoid initialization.
            if (optionalServices.contains(serviceInstanceName)) {
                return null;
            }
            // if the service instance is null, we will check the tenant instance service to check if any new
            // service instance with the value of the variable 'serviceInstanceName' has been added or not.
            // If we still cannot find it, then we would throw an exception.
            tenantInfoJson = getInstancesJson(this.restUtil, serviceConfigProperties.getTenantServiceUrl(), tenantUuid);

            tenantInfo = createTenantInfoFromJson(tenantInfoJson, tenantInfo, throwOnServiceNotFound);

            // tenantInfo will be null only when throwOnServiceNotFound = false and service not found
            if (tenantInfo == null) {
                return null;
            }

            // check once again to see if the service instance is available or not. The following call will throw an
            // exception if service instance json node is not found.
            serviceInstanceJsonNode = getServiceInstanceNode(tenantUuid, tenantInfo.getServiceInstancesJsonNode(),
                serviceInstanceName);
        }

        ServiceInstanceInfo serviceInstanceInfo = initializeServiceInstanceInfoFromJsonNode(instanceProperties,
            serviceInstanceJsonNode, throwOnServiceNotFound);

        tenantInfo.getServiceNameToInfo().put(serviceInstanceName, serviceInstanceInfo);

        if (newTenantInfoCreated) {
            mapTenantInfo.put(tenantUuid, tenantInfo);
        }

        return serviceInstanceInfo;
    }

    public static TenantInfo createTenantInfoFromJson(String tenantInfoJson, TenantInfo tenantInfo,
        boolean throwOnServiceNotFound) {
        String methodName = "ServiceInstances.createTenantInfoFromJson";

        JsonNode tenantInfoJsonNode = convertJsonToJsonNode(tenantInfoJson);

        JsonNode tenantUuidJsonNode = getJsonPathNode(tenantInfoJsonNode, TENANT_UUID_JSON_PATH,
            throwOnServiceNotFound);

        assert tenantUuidJsonNode != null;
        String tenantUuid = "";
        if (tenantUuidJsonNode != null) {
            tenantUuid = tenantUuidJsonNode.textValue();
        }

        JsonNode instancesJsonNode = getJsonNodeFieldValue(tenantInfoJson, tenantInfoJsonNode, SERVICE_INSTANCES_KEYWD,
            throwOnServiceNotFound);

        if (!(instancesJsonNode instanceof ArrayNode)) {
            if (throwOnServiceNotFound) {
                throw ExceptionHelper.getException(methodName, logger, TENANT_DOES_NOT_CONTAIN_SERVICE_INSTANCES,
                    tenantUuid, SERVICE_INSTANCES_KEYWD);
            } else {
                return null;
            }
        }

        final ArrayNode serviceInstancesJsonNode = (ArrayNode) instancesJsonNode;

        TextNode tenantAliasName = getJsonNodeFieldValue(tenantInfoJson, tenantInfoJsonNode, ALIAS_KEYWD,
            throwOnServiceNotFound);

        if (tenantAliasName == null) {
            return null;
        }

        tenantInfo.setTenantUuid(tenantUuid);
        tenantInfo.setTenantAliasName(tenantAliasName.textValue());
        tenantInfo.setServiceInstancesJsonNode(serviceInstancesJsonNode);
        if (!initUaaInfo(tenantInfoJson, tenantInfoJsonNode, tenantInfo)) {
            return null;
        }

        return tenantInfo;
    }

    private ServiceInstanceInfo initializeServiceInstanceInfoFromJsonNode(ServiceInstanceProperties instanceProperties,
        JsonNode serviceInstanceJsonNode, boolean throwOnServiceNotFound) {

        String serviceInstanceName = instanceProperties.getServiceName();
        List<String> uriPaths = instanceProperties.getUriPaths();
        List<String> customPropertyPaths = instanceProperties.getCustomPropertyPaths();

        ServiceInstanceInfo serviceInstanceInfo = new ServiceInstanceInfo(serviceConfigProperties, instanceProperties);

        uriPaths.forEach(uriPath -> serviceInstanceInfo.addUri(uriPath, String.join(",",
            getInstancePropertyValues(serviceInstanceName, serviceInstanceJsonNode, uriPath, throwOnServiceNotFound))));

        customPropertyPaths.forEach(customPropertyPath -> serviceInstanceInfo.addCustomProperty(customPropertyPath,
            String.join(",", getInstancePropertyValues(serviceInstanceName, serviceInstanceJsonNode, customPropertyPath,
                throwOnServiceNotFound))));

        serviceInstanceInfo.setServiceName(instanceProperties.getServiceName());

        if (!serviceInstanceInfo.getServiceName().equals(apmProperties.getOptionalPxBlobServiceName())) {
            serviceInstanceInfo.setZoneHeaderName(String.join(",",
                getInstancePropertyValues(serviceInstanceName, serviceInstanceJsonNode,
                    instanceProperties.getZoneHeaderNamePath(), throwOnServiceNotFound)));

            serviceInstanceInfo.setZoneHeaderValue(String.join(",",
                getInstancePropertyValues(serviceInstanceName, serviceInstanceJsonNode,
                    instanceProperties.getZoneHeaderValuePath(), throwOnServiceNotFound)));

            Set<String> allScopes = getInstancePropertyValues(serviceInstanceName, serviceInstanceJsonNode,
                instanceProperties.getScopePath(), throwOnServiceNotFound);

            serviceInstanceInfo.setZoneTokenScopes(allScopes.toArray(new String[allScopes.size()]));

            serviceInstanceInfo.setRestTemplate(ServiceInstanceInfo.getOauth2RestTemplate(serviceInstanceInfo));
        }

        if (serviceInstanceInfo.getServiceName().equals(apmProperties.getOptionalPxEventHubServiceName())) {
            JsonNode protocolNode = getJsonPathNode(serviceInstanceJsonNode, instanceProperties.getProtocolPath(),
                throwOnServiceNotFound);
            serviceInstanceInfo.setProtocolDetails(protocolNode);
        }

        return serviceInstanceInfo;
    }

    public TenantInfo getTenantInfo(String tenantUuid, boolean throwOnServiceNotFound) {
        String methodName = "ServiceInstances.getServiceNameToInfo";

        TenantInfo tenantInfo = mapTenantInfo.get(tenantUuid);

        if (tenantInfo == null) {
            if (throwOnServiceNotFound) {
                throw ExceptionHelper.getException(methodName, logger, SERVICE_INSTANCES_INFO_NOT_INITIALIZED,
                    tenantUuid);
            } else {
                return null;
            }
        }

        return tenantInfo;
    }

    public ServiceInstanceInfo getServiceInstanceInfo(String tenantUuid, String serviceName) {
        return getServiceInstanceInfo(tenantUuid, serviceName, true /*throwOnServiceNotFound*/);
    }

    public ServiceInstanceInfo getServiceInstanceInfo(String tenantUuid, String serviceName,
        boolean throwOnServiceNotFound) {

        TenantInfo tenantInfo = getTenantInfo(tenantUuid, throwOnServiceNotFound);

        // tenantInfo will be null only when throwOnServiceNotFound = false and service not found
        if (tenantInfo == null) {
            return null;
        }

        return getServiceInstanceInfo(tenantInfo, serviceName, throwOnServiceNotFound);
    }

    public static ServiceInstanceInfo getServiceInstanceInfo(TenantInfo tenantInfo, String serviceName,
        boolean throwOnServiceNotFound) {

        String methodName = "ServiceInstances.getServiceInstanceInfoNoThrow";

        Map<String, ServiceInstanceInfo> serviceInstanceInfMap = tenantInfo.getServiceNameToInfo();

        if (serviceInstanceInfMap == null) {
            if (throwOnServiceNotFound) {
                throw ExceptionHelper.getException(methodName, logger, SERVICE_INSTANCE_INFO_NOT_INITIALIZED,
                    serviceName, tenantInfo.getTenantUuid());
            } else {
                return null;
            }
        }

        ServiceInstanceInfo serviceInstanceInfo = serviceInstanceInfMap.get(serviceName);

        if (serviceInstanceInfo == null) {
            if (throwOnServiceNotFound) {
                throw ExceptionHelper.getException(methodName, logger, SERVICE_INSTANCE_INFO_NOT_INITIALIZED,
                    serviceName, tenantInfo.getTenantUuid());
            } else {
                return null;
            }
        }

        return serviceInstanceInfo;
    }

    public static String getInstancesJson(RestUtil restUtil, String tenantInfoUrl, String tenantUuid) {
        String url = tenantInfoUrl + "/v1/tenants/" + tenantUuid;
        return restUtil.doGet(url, String.class);
    }

    public static JsonNode convertJsonToJsonNode(String tenantInfoJson) {
        String methodName = "ServiceInstances.convertJsonToJsonNode";
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.readTree(tenantInfoJson);
        } catch (IOException exception) {
            String logMsg = "Error converting the JSON into JsonNode." + System.lineSeparator() + exception.getMessage()
                + System.lineSeparator() + "Json:" + System.lineSeparator() + tenantInfoJson;
            logger.error(logMsg, exception);
            throw ExceptionHelper.getException(methodName, logger, ERROR_CONVERTING_JSON_TO_NODE);
        }
    }

    public static <T> T getJsonNodeFieldValue(String tenantInfoJson, JsonNode tenantInfoJsonNode, String propertyName,
        boolean throwOnServiceNotFound) {
        String methodName = "ServiceInstances.getJsonNodeFieldValue";
        //noinspection unchecked
        T fieldValueNode = getJsonNodeFieldValueNoThrow(tenantInfoJsonNode, propertyName);

        if (fieldValueNode == null) {
            if (throwOnServiceNotFound) {
                ServiceException serviceException = ExceptionHelper.getException(methodName, logger,
                    CANNOT_FIND_PROPERTY_IN_TENANT_INFO, propertyName);

                logger.error(serviceException.getMessage());
                logger.error("TenantInfoJon: '{}'", tenantInfoJson);

                throw serviceException;
            } else {
                return null;
            }
        }

        return fieldValueNode;
    }

    public static <T> T getJsonNodeFieldValueNoThrow(JsonNode tenantInfoJsonNode, String propertyName) {
        //noinspection unchecked
        return (T) tenantInfoJsonNode.get(propertyName);
    }

    public static Set<String> getInstancePropertyValues(String serviceName, JsonNode instanceJsonNode,
        String jsonPathsSeparatedByComa, boolean throwOnServiceNotFound) {
        String methodName = "ServiceInstances.getInstancePropertyValue";

        String[] jsonPaths = jsonPathsSeparatedByComa.split(",");

        Set<String> propertyValues = new HashSet<>();
        // trim the strings
        for (String jsonPath : jsonPaths) {
            String currJsonPath = jsonPath.trim();

            JsonNode fieldNode = getJsonPathNode(instanceJsonNode, currJsonPath, throwOnServiceNotFound);

            if (fieldNode == null) {
                continue;
            }

            if (fieldNode instanceof ArrayNode) {
                ArrayNode arrayFieldNode = (ArrayNode) fieldNode;

                for (int idx = 0; idx < arrayFieldNode.size(); idx++) {
                    String propertyValue = arrayFieldNode.get(idx).textValue().trim();
                    if (!StringUtils.hasText(propertyValue)) {
                        throw ExceptionHelper.getException(methodName, logger, INSTANCE_JSON_PATH_VALUE_IS_EMPTY,
                            serviceName, currJsonPath);
                    }
                    propertyValues.add(propertyValue);
                }
            } else {
                if (fieldNode.textValue() == null || !StringUtils.hasText(fieldNode.textValue())) {
                    throw ExceptionHelper.getException(methodName, logger, INSTANCE_JSON_PATH_VALUE_IS_EMPTY,
                        serviceName, currJsonPath);
                }

                propertyValues.add(fieldNode.textValue().trim());
            }
        }

        return propertyValues;
    }

    public static JsonNode getJsonPathNode(JsonNode jsonNode, String jsonPath) {
        return getJsonPathNode(jsonNode, jsonPath, true /* throwOnServiceNotFound */);
    }

    public static JsonNode getJsonPathNode(JsonNode jsonNode, String jsonPath, boolean throwOnServiceNotFound) {
        String methodName = "ServiceInstances.getJsonPathNode";

        JsonNode fieldNode = getJsonPathNodeNoThrow(jsonNode, jsonPath);

        if (fieldNode.isMissingNode()) {
            if (throwOnServiceNotFound) {
                logger.error("{}", jsonNode.asText());
                throw ExceptionHelper.getException(methodName, logger, INVALID_INSTANCE_JSON_PATH, jsonPath);
            } else {
                return null;
            }
        }

        return fieldNode;
    }

    public static JsonNode getJsonPathNodeNoThrow(JsonNode jsonNode, String jsonPath) {
        return jsonNode.at(jsonPath);
    }

    public static JsonNode getServiceInstanceNode(String tenantUuid, ArrayNode instancesNode,
        String serviceInstanceName) {
        String methodName = "ServiceInstances.getServiceInstanceNode";
        JsonNode jsonNode = getServiceInstanceNodeNoThrow(instancesNode, serviceInstanceName);

        if (jsonNode == null) {
            logger.error("{}", instancesNode.asText());
            throw ExceptionHelper.getException(methodName, logger, SERVICE_INSTANCE_INFO_NOT_AVAILABLE, tenantUuid,
                serviceInstanceName);
        }

        return jsonNode;
    }

    public static JsonNode getServiceInstanceNodeNoThrow(ArrayNode instancesNode, String instanceName) {
        for (int idx = 0; idx < instancesNode.size(); ++idx) {
            JsonNode instanceNode = instancesNode.get(idx);
            JsonNode serviceNameNode = instanceNode.get("serviceName");
            if (serviceNameNode != null && instanceName.equals(serviceNameNode.asText())) {
                return instanceNode;
            }
        }

        return null;
    }

    public static boolean initUaaInfo(String tenantInfoJson, JsonNode tenantInfoJsonNode, TenantInfo tenantInfo) {

        ArrayNode applications = getJsonNodeFieldValue(tenantInfoJson, tenantInfoJsonNode, TENANCY_APPLICATIONS_KEYWD,
            true /*throwOnServiceNotFound*/);

        //noinspection ConstantConditions
        for (int idx = 0; idx < applications.size(); idx++) {

            JsonNode applicationJsonNode = applications.get(idx);

            if (applicationJsonNode == null) {
                continue;
            }

            JsonNode isDefaultIdpValueNode = applicationJsonNode.at(IS_DEFAULT_IDP_JSON_PATH);
            if (isDefaultIdpValueNode.isMissingNode()) {
                continue;
            }

            // if the current application is default idp value provider, then get the UAA IDP uuid value.
            if (isDefaultIdpValueNode.asBoolean()) {

                JsonNode idpOriginJsonNode = getJsonPathNode(applicationJsonNode, DEFAULT_IDP_ORIGIN_JSON_PATH);

                // we want to consider IDPs that are UAA origin. We should not consider GE SSO IDP.
                if (!idpOriginJsonNode.textValue().trim().equalsIgnoreCase("uaa")) {
                    continue;
                }

                JsonNode defaultIdpUuidJsonNode = getJsonPathNode(applicationJsonNode, DEFAULT_IDP_UUID_JSON_PATH);

                JsonNode uaaUrlJsonNode = getJsonPathNode(applicationJsonNode, DEFAULT_IDP_URL_JSON_PATH);

                tenantInfo.setUaaIdpUuid(defaultIdpUuidJsonNode.textValue().trim());
                tenantInfo.setUaaUrl(uaaUrlJsonNode.textValue().trim());
                return true;
            }
        }

        return false;
        // logger.error(tenantInfoJson);
        // throw ExceptionHelper.getException(methodName, logger, CANNOT_FIND_PROPERTY_IN_TENANT_INFO, "UAA IDP Uuid");
    }

    public void registerServiceInstanceProperties(ServiceInstanceProperties serviceInstanceProperties) {
        String methodName = "ServiceInstancesFilter.registerServiceInstanceProperties";
        serviceInstanceProperties.validate(serviceConfigProperties);

        if (this.serviceInstancePropertiesMap.containsKey(serviceInstanceProperties.getServiceName())) {
            throw ExceptionHelper.getException(methodName, logger, SERVICE_INSTANCE_PROPS_ALREADY_REGISTERED,
                serviceInstanceProperties.getServiceName());
        }
        this.serviceInstancePropertiesMap.put(serviceInstanceProperties.getServiceName(), serviceInstanceProperties);
    }

    public static String getPxAnalyticExecuteClientId(String tenantAliasName) {
        return "analytics." + tenantAliasName;
    }

    public static String getApmAnalyticsUser(String tenantAliasName) {
        return "analytics.user." + tenantAliasName;
    }

    @Getter
    @Setter
    public static class TenantInfo {

        private String tenantUuid;

        private String tenantAliasName;

        private String uaaIdpUuid;

        private String uaaUrl;

        private ArrayNode serviceInstancesJsonNode;

        // for the current tenant, this map contains instance information of the services.
        private Map<String, ServiceInstanceInfo> serviceNameToInfo = new ConcurrentHashMap<>();

        @SuppressWarnings("unused")
        public String getTrustedIssuer() {
            return this.uaaUrl + "/oauth/token";
        }
    }
}
