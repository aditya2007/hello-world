/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.instances.register;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.service.instances.ServiceInstanceProperties;
import com.ge.apm.service.properties.ApmProperties;
import com.ge.apm.service.instances.ServiceInstances;

@Component
public class RegisterServiceProperties {

    @Autowired
    private ApmProperties apmProperties;

    @Autowired
    private ServiceInstances serviceInstances;

    @PostConstruct
    public void register() {
        registerPxEventHubInstanceProperties();
        registerPxBlobInstanceProperties();
        //registerPxCatalogInstanceProperties();
        //registerPxRuntimeInstanceProperties();
        //registerPxTsInstanceProperties();
        registerUomInstanceProperties();
    }

    private void registerPxEventHubInstanceProperties() {
        ServiceInstanceProperties serviceInstanceProperties = new ServiceInstanceProperties();

        if (StringUtils.isBlank(this.apmProperties.getOptionalPxEventHubServiceName())) {
            return;
        }

        serviceInstanceProperties.setServiceName(this.apmProperties.getPxEventHubServiceName());
        serviceInstanceProperties.getUriPaths().add(this.apmProperties.getPxEventHubUri());
        serviceInstanceProperties.setZoneHeaderNamePath(this.apmProperties.getPxEventHubZoneHeaderName());
        serviceInstanceProperties.setZoneHeaderValuePath(this.apmProperties.getPxEventHubZoneHeaderValue());
        serviceInstanceProperties.setScopePath(this.apmProperties.getPxEventHubOauthScope());
        serviceInstanceProperties.setProtocolPath(this.apmProperties.getPxEventHubProtocol());

        this.serviceInstances.registerServiceInstanceProperties(serviceInstanceProperties);
    }

    private void registerPxBlobInstanceProperties() {
        ServiceInstanceProperties serviceInstanceProperties = new ServiceInstanceProperties();

        if (StringUtils.isBlank(this.apmProperties.getOptionalPxBlobServiceName())) {
            return;
        }

        serviceInstanceProperties.setServiceName(this.apmProperties.getPxBlobServiceName());
        serviceInstanceProperties.getUriPaths().add(this.apmProperties.getPxBlobServiceUrlPath());
        serviceInstanceProperties.getCustomPropertyPaths().add(this.apmProperties.getPxBlobServiceBucketNamePath());
        serviceInstanceProperties.getCustomPropertyPaths().add(this.apmProperties.getPxBlobServiceAccessKeyIdPath());
        serviceInstanceProperties.getCustomPropertyPaths().add(
            this.apmProperties.getPxBlobServiceSecretAccessKeyPath());
        serviceInstanceProperties.getCustomPropertyPaths().add(this.apmProperties.getPxBlobServiceHostPath());

        String path = "/NA";
        serviceInstanceProperties.setZoneHeaderNamePath(path);
        serviceInstanceProperties.setZoneHeaderValuePath(path);
        serviceInstanceProperties.setScopePath(path);

        this.serviceInstances.registerServiceInstanceProperties(serviceInstanceProperties);
    }

    private void registerUomInstanceProperties() {

        if (StringUtils.isBlank(this.apmProperties.getOptionalUomServiceName())) {
            return;
        }

        ServiceInstanceProperties serviceInstanceProperties = new ServiceInstanceProperties();

        serviceInstanceProperties.setServiceName(this.apmProperties.getUomServiceName());
        serviceInstanceProperties.getUriPaths().add(this.apmProperties.getUomUri());
        serviceInstanceProperties.setZoneHeaderNamePath(this.apmProperties.getUomZoneHeaderName());
        serviceInstanceProperties.setZoneHeaderValuePath(this.apmProperties.getUomZoneHeaderValue());
        serviceInstanceProperties.setScopePath(this.apmProperties.getUomOauthScope());

        this.serviceInstances.registerServiceInstanceProperties(serviceInstanceProperties);
    }

    private void registerPxCatalogInstanceProperties() {

        if (StringUtils.isBlank(this.apmProperties.getOptionalPxCatalogServiceName())) {
            return;
        }

        ServiceInstanceProperties serviceInstanceProperties = new ServiceInstanceProperties();

        serviceInstanceProperties.setServiceName(this.apmProperties.getPxCatalogServiceName());
        serviceInstanceProperties.getUriPaths().add(this.apmProperties.getPxCatalogUri());
        serviceInstanceProperties.setZoneHeaderNamePath(this.apmProperties.getPxCatalogZoneHeaderName());
        serviceInstanceProperties.setZoneHeaderValuePath(this.apmProperties.getPxCatalogZoneHeaderValue());
        serviceInstanceProperties.setScopePath(this.apmProperties.getPxCatalogOauthScope());

        this.serviceInstances.registerServiceInstanceProperties(serviceInstanceProperties);
    }

    private void registerPxRuntimeInstanceProperties() {

        if (StringUtils.isBlank(this.apmProperties.getOptionalPxRuntimeServiceName())) {
            return;
        }

        ServiceInstanceProperties serviceInstanceProperties = new ServiceInstanceProperties();

        serviceInstanceProperties.setServiceName(this.apmProperties.getPxRuntimeServiceName());
        serviceInstanceProperties.getUriPaths().add(this.apmProperties.getPxRuntimeConfigUri());
        serviceInstanceProperties.getUriPaths().add(this.apmProperties.getPxRuntimeExecutionUri());
        serviceInstanceProperties.getUriPaths().add(this.apmProperties.getPxRuntimeMonitoringUri());
        serviceInstanceProperties.getUriPaths().add(this.apmProperties.getPxRuntimeSchedulerUri());
        serviceInstanceProperties.setZoneHeaderNamePath(this.apmProperties.getPxRuntimeZoneHeaderName());
        serviceInstanceProperties.setZoneHeaderValuePath(this.apmProperties.getPxRuntimeZoneHeaderValue());
        serviceInstanceProperties.setScopePath(this.apmProperties.getPxRuntimeOauthScope());

        this.serviceInstances.registerServiceInstanceProperties(serviceInstanceProperties);
    }

    private void registerPxTsInstanceProperties() {

        if (StringUtils.isBlank(this.apmProperties.getOptionalPxTsServiceName())) {
            return;
        }

        ServiceInstanceProperties serviceInstanceProperties = new ServiceInstanceProperties();

        serviceInstanceProperties.setServiceName(this.apmProperties.getPxTsServiceName());
        serviceInstanceProperties.getUriPaths().add(this.apmProperties.getPxTsUri());
        serviceInstanceProperties.setZoneHeaderNamePath(this.apmProperties.getPxTsZoneHeaderName());
        serviceInstanceProperties.setZoneHeaderValuePath(this.apmProperties.getPxTsZoneHeaderValue());
        serviceInstanceProperties.setScopePath(this.apmProperties.getPxTsOauthScope());

        this.serviceInstances.registerServiceInstanceProperties(serviceInstanceProperties);
    }
}
