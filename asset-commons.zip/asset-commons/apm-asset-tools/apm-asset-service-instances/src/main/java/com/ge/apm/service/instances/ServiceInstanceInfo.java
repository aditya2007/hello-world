/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.instances;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordResourceDetails;
import org.springframework.security.oauth2.common.AuthenticationScheme;
import org.springframework.web.client.RestTemplate;

import com.ge.apm.service.properties.ApmProperties.ServiceConfigProperties;
import com.ge.apm.rest.oauth2.client.OAuth2PwdRestTemplate;
import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.VALUE_NOT_FOUND_FOR_SERVICE_PATH;

@SuppressWarnings({ "WeakerAccess" })
@Getter
@Setter
@ToString
public class ServiceInstanceInfo implements IServiceInstanceInfoProvider {
    private static final Logger logger = LoggerFactory.getLogger(ServiceInstanceInfo.class);

    private ServiceInstanceProperties instanceProperties;

    // stores uri path to url.
    // example: /credentials/uri to actual uri value.
    private Map<String, String> uris;

    private Map<String, String> customProperties;

    private String serviceName;

    private String zoneHeaderName;

    private String zoneHeaderValue;

    private String[] zoneTokenScopes;

    private RestTemplate restTemplate;

    private JsonNode protocolDetails;

    public ServiceInstanceInfo() {

    }

    public ServiceInstanceInfo(ServiceConfigProperties serviceConfigProperties,
        ServiceInstanceProperties instanceProperties) {
        instanceProperties.validate(serviceConfigProperties);
        this.instanceProperties = instanceProperties;
    }

    public String getUri(String uriPath) {
        String methodName = "ServiceInstanceInfoProvider.getUri";
        String uri = this.uris.get(uriPath);

        if (StringUtils.isBlank(uri)) {
            throw ExceptionHelper.getException(methodName, logger, VALUE_NOT_FOUND_FOR_SERVICE_PATH, this.serviceName,
                uriPath);
        }
        return uri;
    }

    public String getCustomProperty(String propertyPath) {
        String methodName = "ServiceInstanceInfoProvider.getCustomProperty";
        String property = this.customProperties.get(propertyPath);

        if (StringUtils.isBlank(property)) {
            throw ExceptionHelper.getException(methodName, logger, VALUE_NOT_FOUND_FOR_SERVICE_PATH, this.serviceName,
                propertyPath);
        }
        return property;
    }

    @Override
    public Map<String, String> getUris() {
        if (this.uris == null) {
            this.uris = new HashMap<>();
        }

        return this.uris;
    }

    @Override
    public Map<String, String> getCustomProperties() {
        if (this.customProperties == null) {
            this.customProperties = new HashMap<>();
        }

        return this.customProperties;
    }

    public void addUri(String path, String value) {
        getUris().put(path, value);
    }

    public void addCustomProperty(String path, String value) {
        getCustomProperties().put(path, value);
    }

    public static OAuth2RestTemplate getOauth2RestTemplate(ServiceInstanceInfo serviceInstanceInfo) {
        ClientCredentialsResourceDetails resourceDetails = getClientTypeResourceDetails(serviceInstanceInfo);
        return serviceInstanceInfo.getInstanceProperties().getHttpConfig().getOauth2RestTemplate(resourceDetails);
    }

    public static OAuth2PwdRestTemplate getOauth2PwdRestTemplate(ServiceInstanceInfo serviceInstanceInfo) {
        ResourceOwnerPasswordResourceDetails resourceDetails = getPasswordTypeResourceDetails(serviceInstanceInfo);
        return serviceInstanceInfo.getInstanceProperties().getHttpConfig().getOauth2PwdRestTemplate(resourceDetails);
    }

    @SuppressWarnings("Duplicates")
    public static ClientCredentialsResourceDetails getClientTypeResourceDetails(
        ServiceInstanceInfo serviceInstanceInfo) {

        ServiceInstanceProperties serviceInstanceProperties = serviceInstanceInfo.getInstanceProperties();

        ClientCredentialsResourceDetails resourceDetails = new ClientCredentialsResourceDetails();

        resourceDetails.setAuthenticationScheme(AuthenticationScheme.header);
        resourceDetails.setAccessTokenUri(serviceInstanceProperties.getUaaUrl());

        resourceDetails.setClientId(serviceInstanceProperties.getClientId());
        resourceDetails.setClientSecret(serviceInstanceProperties.getClientSecret());

        resourceDetails.setScope(Arrays.asList(serviceInstanceInfo.getZoneTokenScopes()));
        return resourceDetails;
    }

    public static ResourceOwnerPasswordResourceDetails getPasswordTypeResourceDetails(
        ServiceInstanceInfo serviceInstanceInfo) {

        ServiceInstanceProperties serviceInstanceProperties = serviceInstanceInfo.getInstanceProperties();

        ResourceOwnerPasswordResourceDetails resourceOwnerPasswordResourceDetails
            = new ResourceOwnerPasswordResourceDetails();

        resourceOwnerPasswordResourceDetails.setAccessTokenUri(serviceInstanceProperties.getUaaUrl());
        resourceOwnerPasswordResourceDetails.setClientId(serviceInstanceProperties.getClientId());
        resourceOwnerPasswordResourceDetails.setClientSecret(serviceInstanceProperties.getClientSecret());
        resourceOwnerPasswordResourceDetails.setUsername(serviceInstanceProperties.getUserName());
        resourceOwnerPasswordResourceDetails.setPassword(serviceInstanceProperties.getPassword());
        if (serviceInstanceInfo.getZoneTokenScopes() != null) {
            resourceOwnerPasswordResourceDetails.setScope(Arrays.asList(serviceInstanceInfo.getZoneTokenScopes()));
        }

        return resourceOwnerPasswordResourceDetails;
    }
}
