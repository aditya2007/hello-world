/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.instances;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.ge.apm.service.properties.ApmProperties.ServiceConfigProperties;
import com.ge.apm.rest.config.HttpConfig;
import com.ge.apm.util.exceptions.ExceptionHelper;

import static com.ge.apm.service.rest.exception.codes.ServiceInstancesErrorCodes.INSTANCE_PATH_NOT_PROVIDED;

@SuppressWarnings("WeakerAccess")
@Getter
@Setter
public class ServiceInstanceProperties {
    private static final Logger logger = LoggerFactory.getLogger(ServiceInstanceProperties.class);

    // example: predix-asset
    private String serviceName;

    //    // example: /credentials/uri
    //    private String uriPath;
    // example: /credentials/uri
    private List<String> uriPaths;

    private List<String> customPropertyPaths;

    // example: /credentials/zone/http-header-name
    private String zoneHeaderNamePath;

    // example: /credentials/zone/http-header-value
    private String zoneHeaderValuePath;

    // example: /credentials/zone/oauth-scope
    private String scopePath;

    private String protocolPath;

    private HttpConfig httpConfig;

    private String uaaUrl;

    private String clientId;

    private String clientSecret;

    private String userName;

    private String password;

    public void validate(ServiceConfigProperties serviceConfigProperties) {
        String methodName = "ServiceInstanceProperties.validate";
        validateProperty("ServiceName", this.serviceName);

        if (this.uriPaths == null || this.uriPaths.isEmpty()) {
            throw ExceptionHelper.getException(methodName, logger, INSTANCE_PATH_NOT_PROVIDED, "UriPath",
                this.serviceName);
        }

        this.uriPaths.forEach(uriPath -> validateProperty("UriPath", uriPath));
        validateProperty("ZoneHeaderNamePath", this.zoneHeaderNamePath);
        validateProperty("ZoneHeaderValuePath", this.zoneHeaderValuePath);
        validateProperty("Scope", this.scopePath);

        this.uaaUrl = serviceConfigProperties.getTrustedIssuer();
        this.clientId = serviceConfigProperties.getClientId();
        this.clientSecret = serviceConfigProperties.getClientSecret();
        this.httpConfig = serviceConfigProperties.getHttpConfig();

        validateProperty("UaaUrl", this.uaaUrl);
        validateProperty("ClientId", this.clientId);
        validateProperty("ClientSecret", this.clientSecret);

    }

    public void validateProperty(String propertyName, String propertyPath) {
        String methodName = "ServiceInstanceProperties.validate";
        if (StringUtils.isEmpty(propertyPath)) {
            throw ExceptionHelper.getException(methodName, logger, INSTANCE_PATH_NOT_PROVIDED, propertyName,
                this.serviceName);
        }
    }

    public List<String> getUriPaths() {
        if (this.uriPaths == null) {
            this.uriPaths = new ArrayList<>();
        }

        return this.uriPaths;
    }

    public List<String> getCustomPropertyPaths() {
        if (this.customPropertyPaths == null) {
            this.customPropertyPaths = new ArrayList<>();
        }

        return this.customPropertyPaths;
    }
}
