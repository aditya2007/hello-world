/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.rest.util;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.util.MultiValueMap;

import com.ge.apm.rest.util.RestUtil;
import com.ge.apm.service.instances.ServiceInstanceInfo;
import com.ge.apm.service.instances.ServiceInstances;
import com.ge.apm.service.instances.filter.ServiceInstancesFilter;

@SuppressWarnings("WeakerAccess")
@Getter
@Setter
@ToString
public class PxServiceRestUtil extends RestUtil {

    protected ServiceInstanceInfo serviceInstanceInfo;

    public PxServiceRestUtil(ServiceInstances serviceInstances, String serviceName) {
        super(null);
        this.serviceInstanceInfo = serviceInstances.getServiceInstanceInfo(
            ServiceInstancesFilter.getTenantUuid(), serviceName);
        this.restTemplate = this.serviceInstanceInfo.getRestTemplate();
    }

    @Override
    public MultiValueMap<String, String> getHeaders(boolean hasContent, String contentType,
        MultiValueMap<String, String> overrideHeaders) {

        MultiValueMap<String, String> headers = super.getHeaders(hasContent, contentType, null);
        headers.add(this.serviceInstanceInfo.getZoneHeaderName(), this.serviceInstanceInfo.getZoneHeaderValue());
        return headers;
    }
}
