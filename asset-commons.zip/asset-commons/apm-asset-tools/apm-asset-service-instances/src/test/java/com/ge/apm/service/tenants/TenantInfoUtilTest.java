/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.tenants;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ge.apm.service.instances.ServiceInstanceInfo;
import com.ge.apm.service.instances.ServiceInstances;
import com.ge.apm.service.instances.ServiceInstances.TenantInfo;
import com.ge.apm.service.instances.register.RegisterServiceProperties;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.spy;

public class TenantInfoUtilTest {

    @InjectMocks
    TenantInfoUtil tenantInfoUtil;

    @Mock
    private RegisterServiceProperties registerServiceProperties;

    @Mock
    private ServiceInstances serviceInstances;

    @Mock
    private TenantsUtil tenantsUtil;

    String tenantUuid = "501a5f1b-2b74-4ebe-8a64-aefa580ae3c0";

    String serviceName = "predix-blobstore";

    @Before
    public void setUp() throws Exception {
        tenantInfoUtil = spy(new TenantInfoUtil());
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetServiceInstanceInfo_DoesNotExist() {
        Assert.assertNull(tenantInfoUtil.getServiceInstanceInfo(tenantUuid, serviceName));
    }

    @Test
    public void testGetServiceInstanceInfo_EmptyServiceMap() {
        TenantInfo tenantInfo = new TenantInfo();
        tenantInfo.setTenantUuid(tenantUuid);
        doReturn(tenantInfo).when(tenantsUtil).getTenantServiceInfoByTenantId(eq(tenantUuid));

        Assert.assertNull(tenantInfoUtil.getServiceInstanceInfo(tenantUuid, serviceName));
    }

    @Test
    public void testGetServiceInstanceInfo_ServiceDoesNotExist() {
        TenantInfo tenantInfo = new TenantInfo();
        tenantInfo.setTenantUuid(tenantUuid);
        Map<String, ServiceInstanceInfo> serviceMap = new HashMap<>();
        serviceMap.put("database", new ServiceInstanceInfo());
        tenantInfo.setServiceNameToInfo(serviceMap);
        doReturn(tenantInfo).when(tenantsUtil).getTenantServiceInfoByTenantId(eq(tenantUuid));

        Assert.assertNull(tenantInfoUtil.getServiceInstanceInfo(tenantUuid, serviceName));
    }

    @Test
    public void testGetServiceInstanceInfo_ServiceExists() {
        TenantInfo tenantInfo = new TenantInfo();
        tenantInfo.setTenantUuid(tenantUuid);
        Map<String, ServiceInstanceInfo> serviceMap = new HashMap<>();
        serviceMap.put("database", new ServiceInstanceInfo());
        ServiceInstanceInfo serviceInfo = new ServiceInstanceInfo();
        serviceInfo.setServiceName(serviceName);
        serviceMap.put(serviceName, serviceInfo);
        tenantInfo.setServiceNameToInfo(serviceMap);
        doReturn(tenantInfo).when(tenantsUtil).getTenantServiceInfoByTenantId(eq(tenantUuid));

        Assert.assertEquals(tenantInfoUtil.getServiceInstanceInfo(tenantUuid, serviceName).getServiceName(),
            serviceName);
    }
}