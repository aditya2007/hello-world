/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.service.tenants;

import org.cloudfoundry.identity.uaa.oauth.token.OpenIdToken;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.test.util.ReflectionTestUtils;

import com.ge.apm.common.support.RequestContext;
import com.ge.apm.rest.config.HttpConfig;
import com.ge.apm.rest.util.RestUtil;
import com.ge.apm.service.properties.ApmProperties;
import com.ge.apm.service.properties.ApmProperties.ServiceConfigProperties;
import com.ge.apm.service.instances.ServiceInstances;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

public class TenantsUtilTest {

    @InjectMocks
    TenantsUtil tenantsUtil;

    @Mock
    private RestUtil restUtil;

    @Mock
    private ApmProperties apmProperties;

    @Mock
    private HttpConfig httpConfig;

    @Mock
    private OAuth2RestTemplate oAuth2RestTemplate;

    @Before
    public void setUp() throws Exception {
        tenantsUtil = spy(new TenantsUtil());
        ClientCredentialsResourceDetails resourceDetails = new ClientCredentialsResourceDetails();
        oAuth2RestTemplate = new OAuth2RestTemplate(resourceDetails);
        ReflectionTestUtils.setField(tenantsUtil, "oAuth2RestTemplate", oAuth2RestTemplate);
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getTenantServiceInfoByTenantId_ValidateRequestContextState() {
        RequestContext.put("Name", "Asset123");
        RequestContext.put(RequestContext.TENANT_UUID, "tenantid2");
        RequestContext.put(RequestContext.AUTHORIZATION, "myauth");
        ServiceInstances serviceInstances = new ServiceInstances();
        doReturn(serviceInstances).when(apmProperties).getServiceInstances();
        ServiceConfigProperties serviceConfigProperties = new ServiceConfigProperties();
        serviceConfigProperties.setTenantServiceUrl("tenantServiceUrl");
        doReturn(serviceConfigProperties).when(apmProperties).getServiceConfigProperties();
        String sampleJson = "{\"serviceInstances\":[{\"uuid\":\"8e4b60ef-9b26-43b3-a848-a5c45f3ee882\","
            + "\"serviceName\":\"predix-blobstore\",\"credentials\":{\"access_key_id\":\"A\",\"bucket_name\":\"b\","
            + "\"host\":\"s\",\"secret_access_key\":\"L\",\"url\":\"h\"},\"managed\":true}]}";
        doReturn(sampleJson).when(restUtil).doGet(eq("tenantServiceUrl/v1/tenants/tenantid1"), any());
        doReturn("scope,scope").when(apmProperties).getStufTokenScopes();
        OAuth2AccessToken accessToken = new OpenIdToken("dummy");
        doReturn(accessToken).when(oAuth2RestTemplate).getAccessToken();
        tenantsUtil.getTenantServiceInfoByTenantId("tenantid1");

        Assert.assertEquals(RequestContext.get("Name", String.class), "Asset123");
        Assert.assertEquals(RequestContext.get(RequestContext.TENANT_UUID, String.class), "tenantid2");
        Assert.assertEquals(RequestContext.get(RequestContext.AUTHORIZATION, String.class), "myauth");
        Assert.assertEquals(RequestContext.copy().size(), 3);
    }
}