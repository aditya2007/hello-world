package com.ge.apm.common.support;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.http.HttpServletRequest;

import com.ge.apm.common.util.IdGenerator;

@Deprecated
public class RequestIdListener implements ServletRequestListener {
    public static final String requestIdHeader = "x-request-id";

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        RequestContext.remove(RequestContext.REQUEST_ID);
        org.slf4j.MDC.remove(RequestContext.REQUEST_ID);
    }

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        String requestId = IdGenerator.generateAsString();
        if (sre.getServletRequest() instanceof HttpServletRequest) {
            String headerValue = ((HttpServletRequest) sre.getServletRequest()).getHeader(requestIdHeader);
            if (headerValue != null && !headerValue.trim().isEmpty()) {
                requestId = headerValue.trim();
            }
        }

        RequestContext.put(RequestContext.REQUEST_ID, requestId);
        org.slf4j.MDC.put(RequestContext.REQUEST_ID, requestId);
    }
}
