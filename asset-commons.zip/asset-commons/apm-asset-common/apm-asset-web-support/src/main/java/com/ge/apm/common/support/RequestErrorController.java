/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.common.support;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.SearchStrategy;
import org.springframework.boot.autoconfigure.web.DefaultErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.ge.apm.common.exception.CommonErrorCodes;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.model.ServiceError;

@Controller
@ConditionalOnMissingBean(
    value = {ErrorController.class},
    search = SearchStrategy.CURRENT
)
public class RequestErrorController implements ErrorController {

    public static final String ERROR_ATTRIBUTE = DefaultErrorAttributes.class.getName() + ".ERROR";

    private static final Logger logger = LoggerFactory.getLogger(RequestErrorController.class);

    private final boolean enableLogging;

    public RequestErrorController() {
        this(false);
    }

    public RequestErrorController(boolean enableLogging) {
        this.enableLogging = enableLogging;
    }

    @Override
    public String getErrorPath() {

        return "/error";
    }

    @RequestMapping(value = "/error")
    @ResponseBody
    public ResponseEntity<ServiceError> error(HttpServletRequest request) {

        RequestAttributes requestAttributes = new ServletRequestAttributes(request);
        Throwable error = getError(requestAttributes);
        HttpStatus status = getStatus(request, error);

        String path = getAttribute(requestAttributes, "javax.servlet.error.request_uri");

        if (enableLogging) {
            // Logback checks if the last parameter is of type Throwable.
            // If so, it logs the Throwable as per its exception-logging format specification.
            logger.error("HTTP request returned status code {}", status, error);
        }

        ServiceException serviceException = ExceptionUtil.wrapException(error, CommonErrorCodes.UNKNOWN_ERROR,
                error == null ? CommonErrorCodes.UNKNOWN_ERROR.toString() : error.getMessage());

        ServiceError serviceError = new ServiceError();
        serviceError.setTimestamp(new Date());
        serviceError.setRequestId(RequestContext.get(RequestContext.REQUEST_ID, String.class));
        serviceError.setPath(path);
        serviceError.setErrorId(serviceException.getCode());
        serviceError.setErrorMessage(serviceException.getMessage());

        return new ResponseEntity<>(serviceError, status);
    }

    private Throwable getError(RequestAttributes requestAttributes) {

        Throwable exception = getAttribute(requestAttributes, ERROR_ATTRIBUTE);
        if (exception == null) {
            exception = getAttribute(requestAttributes, "javax.servlet.error.exception");
        }
        return exception;
    }

    private HttpStatus getStatus(HttpServletRequest request, Throwable throwable) {
        if (throwable != null) {
            ResponseStatus responseStatus = throwable.getClass().getAnnotation(ResponseStatus.class);
            if (responseStatus != null) {
                return responseStatus.value();
            }
        }

        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        if (statusCode != null) {
            try {
                return HttpStatus.valueOf(statusCode);
            } catch (Exception ex) {
                logger.error(ex.getMessage(), ex);
                return HttpStatus.INTERNAL_SERVER_ERROR;
            }
        }
        return HttpStatus.INTERNAL_SERVER_ERROR;
    }

    @SuppressWarnings("unchecked")
    private <T> T getAttribute(RequestAttributes requestAttributes, String name) {

        return (T) requestAttributes.getAttribute(name, RequestAttributes.SCOPE_REQUEST);
    }
}
