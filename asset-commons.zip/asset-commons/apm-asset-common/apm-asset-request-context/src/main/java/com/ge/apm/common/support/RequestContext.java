package com.ge.apm.common.support;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.MDC;

import com.ge.stuf.security.context.SecurityContext;
import com.ge.stuf.tenant.context.TenantContext;

public abstract class RequestContext {

    public static final String REQUEST_ID = "requestId";
    public static final String AUTHORIZATION = "authorization";
    public static final String TENANT_UUID = "tenantUuid";
    public static final String TENANT_FOR_TIMESERIES = "Tenant";
    public static final String X_TENANT = "x-tenant";
    public static final String TENANT = "tenant";
    public static final String SERVICE_INFO = "serviceInfo";
    public static final String SERVICE_REST_TEMPLATE = "serviceRestTemplate";
    public static final String LINK_HEADER = "Link";
    public static final String NEXT_PAGE_LINK = "nextPageLink";
    public static final String REQUEST_URL = "RequestUrl";
    public static final String ACCESS_CTRL_EXPOSE_HEADERS = "Access-Control-Expose-Headers";
    public static final String HTTP_SERVLET_REQUEST = "httpServletRequest";
    public static final String HTTP_SERVLET_RESPONSE = "httpServletResponse";

    private static ThreadLocal<Map<String, Object>> valueHolder = ThreadLocal.withInitial(() -> new HashMap<>());

    public static Object get(String key) {
        //If the key exists already in the RequestContextMap use it.
        if (getValue().containsKey(key)) {
            return getValue().get(key);
        } else {
            //Query the stuf TenantContext to get the information
            if (TENANT_UUID.equals(key)) {
                if (TenantContext.getInstance() != null) {
                    String tenantId = TenantContext.getInstance().getTenantUuid();
                    getValue().put(TENANT_UUID, tenantId);
                    MDC.put(TENANT, tenantId);
                    return getValue().get(key);
                }
            }
            if (AUTHORIZATION.equals(key)) {
                if (SecurityContext.getInstance() != null) {
                    getValue().put(AUTHORIZATION, SecurityContext.getInstance().getAuthorization());
                    return getValue().get(key);
                }
            }
            if (REQUEST_ID.equals(key)){
                String traceId = MDC.get("X-B3-TraceId");
                getValue().put(REQUEST_ID, traceId);
                return getValue().get(key);
            }
        }
        return null;
    }

    public static <T> T get(String key, Class<T> type) {
        Object value = get(key);
        if (value == null) {
            if (boolean.class.isAssignableFrom(type)) {
                return (T) Boolean.FALSE;
            }
            return null;
        }
        return type.cast(value);
    }

    public static void put(String key, Object value) {
        getValue().put(key, value);
    }

    public static boolean contains(String key) {
        return getValue().containsKey(key);
    }

    public static Object remove(String key) {
        return getValue().remove(key);
    }

    public static void clear() {
        getValue().clear();
    }

    public static void destroy() {
        valueHolder.remove();
    }

    public static Map<String, Object> copy() {
        return new HashMap<>(getValue());
    }

    public static void initialize(Map<String, Object> localValueHolder) {
        valueHolder.set(new HashMap<>(localValueHolder));
    }

    private static Map<String, Object> getValue() {
        return valueHolder.get();
    }
}
