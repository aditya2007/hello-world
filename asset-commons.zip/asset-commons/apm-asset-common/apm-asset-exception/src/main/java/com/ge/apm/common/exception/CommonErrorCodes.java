/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.common.exception;

public enum CommonErrorCodes implements IErrorCode {

    UNKNOWN_ERROR("Unknown error: %s"),
    NO_DATA_FOUND("No data found"),
    TENANT_NOT_FOUND("Tenant not found"),
    SERVICE_INSTANCE_NOT_FOUND("Service instance not found with the name: %s"),
    INTERNAL_ERROR("An internal error occured. Please check the service logs for details.");

    private String message;

    CommonErrorCodes(String s) {
        message = s;
    }

    public String message() {
        return message;
    }
}
