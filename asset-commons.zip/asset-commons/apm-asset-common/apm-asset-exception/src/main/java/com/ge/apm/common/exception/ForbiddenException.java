/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.common.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FORBIDDEN)
public class ForbiddenException extends ServiceException {

    // Implicit code constructors

    public ForbiddenException(String message, Object... messageArgs) {
        super(HttpStatus.FORBIDDEN.name(), message, messageArgs);
    }

    public ForbiddenException(String message, Throwable cause, Object... messageArgs) {
        super(HttpStatus.FORBIDDEN.name(), message, cause, messageArgs);
    }

    // IErrorCode constructors

    public ForbiddenException(IErrorCode errorCode, Object... messageArgs) {
        super(errorCode, messageArgs);
    }

    public ForbiddenException(IErrorCode errorCode, Throwable cause, Object... messageArgs) {
        super(errorCode, cause, messageArgs);
    }
}
