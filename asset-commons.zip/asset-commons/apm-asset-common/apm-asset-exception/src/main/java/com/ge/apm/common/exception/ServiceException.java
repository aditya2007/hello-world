/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.common.exception;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.util.DefaultIndenter;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
public class ServiceException extends RuntimeException {

    private static final long serialVersionUID = 7369710483103222481L;

    private final String code;

    private boolean isExceptionLogged;

    private static final Logger logger = LoggerFactory.getLogger(ServiceException.class);

    public String getCode() {
        return this.code;
    }

    // Implicit code constructors

    public ServiceException(String message, Object... messageArgs) {
        this(HttpStatus.INTERNAL_SERVER_ERROR.name(), message, messageArgs);
    }

    public ServiceException(String message, Throwable cause, Object... messageArgs) {
        this(HttpStatus.INTERNAL_SERVER_ERROR.name(), message, cause, messageArgs);
    }

    // IErrorCode constructors

    public ServiceException(IErrorCode errorCode, Object... messageArgs) {
        this(errorCode.name(), errorCode.message(), messageArgs);
    }

    public ServiceException(IErrorCode errorCode, Throwable cause, Object... messageArgs) {
        this(errorCode.name(), errorCode.message(), cause, messageArgs);
    }

    // Core constructors

    protected ServiceException(String code, String message, Object... messageArgs) {
        super(String.format(message, messageArgs));
        this.code = code;
    }

    protected ServiceException(String code, String message, Throwable cause, Object... messageArgs) {
        super(String.format(message, messageArgs), cause);
        this.code = code;
    }

    @Override
    public String toString() {
        String output = getCode();
        if (output == null || output.isEmpty()) {
            output = super.toString();
        } else {
            output = "[" + output + "] " + super.toString();
        }
        return output;
    }

    public boolean isExceptionLogged() {
        return isExceptionLogged;
    }

    public void setExceptionLogged(boolean exceptionLogged) {
        isExceptionLogged = exceptionLogged;
    }

    @SuppressWarnings("unused")
    @JsonIgnore
    public String getFormattedMessage() {
        ObjectMapper objectMapper = new ObjectMapper();
        DefaultPrettyPrinter defaultPrettyPrinter = new DefaultPrettyPrinter();
        defaultPrettyPrinter.indentArraysWith(new DefaultIndenter());
        ObjectWriter writer = objectMapper.writer(defaultPrettyPrinter);

        try {
            return writer.writeValueAsString(this);
        } catch (JsonProcessingException exception) {
            logger.error("Error converting JSON to object. " + exception.getMessage(), exception);
            throw new ServiceException("Error converting JSON to object. " + exception.getMessage());
        }
    }

    @JsonIgnore
    public StackTraceElement[] getStackTrace() {
        return super.getStackTrace();
    }
}
