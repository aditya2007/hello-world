/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.common.exception;

public class DefaultErrorCode implements IErrorCode {
    private final String name;
    private final String message;

    private DefaultErrorCode(String name, String message) {
        this.name = name;
        this.message = message;
    }

    public static DefaultErrorCode create(String name, String message) {
        return new DefaultErrorCode(name, message);
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public String message() {
        return message;
    }
}
