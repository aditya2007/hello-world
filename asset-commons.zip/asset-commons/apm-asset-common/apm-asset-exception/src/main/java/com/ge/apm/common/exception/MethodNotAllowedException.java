package com.ge.apm.common.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
public class MethodNotAllowedException extends ServiceException {

    // Implicit code constructors
    public MethodNotAllowedException(String message, Object... messageArgs) {
        super(HttpStatus.METHOD_NOT_ALLOWED.name(), message, messageArgs);
    }

    public MethodNotAllowedException(String message, Throwable cause, Object... messageArgs) {
        super(HttpStatus.METHOD_NOT_ALLOWED.name(), message, cause, messageArgs);
    }

    // IErrorCode constructors
    public MethodNotAllowedException(IErrorCode errorCode, Object... messageArgs) {
        super(errorCode, messageArgs);
    }

    public MethodNotAllowedException(IErrorCode errorCode, Throwable cause, Object... messageArgs) {
        super(errorCode, cause, messageArgs);
    }

}
