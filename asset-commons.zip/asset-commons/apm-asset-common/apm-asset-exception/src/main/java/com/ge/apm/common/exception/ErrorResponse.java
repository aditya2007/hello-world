package com.ge.apm.common.exception;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;


@JsonSerialize
public class ErrorResponse {

	private String requestId;
	private Date timestamp;
	private String errorId;
	private String message;

	public ErrorResponse(String requestId, String message) {
		super();
		this.requestId = requestId;
		this.timestamp = new Date();
		this.message = message;
	}

	public ErrorResponse(String requestId, String errorId, String message) {
		super();
		this.requestId = requestId;
		this.timestamp = new Date();
		this.errorId = errorId;
		this.message = message;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public String getErrorId() {
		return errorId;
	}

	public void setErrorId(String errorId) {
		this.errorId = errorId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
