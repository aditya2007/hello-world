/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.common.exception;

import javax.ws.rs.WebApplicationException;

import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpStatusCodeException;

public abstract class ExceptionUtil {

    public static ServiceException wrapException(Throwable e, IErrorCode errorCode, Object... args) {

        if (e instanceof ServiceException) {
            return (ServiceException) e;
        }
        if (e instanceof HttpStatusCodeException) {
            return wrapException((HttpStatusCodeException) e, errorCode, args);
        }
        if (e instanceof WebApplicationException) {
            return wrapException((WebApplicationException) e, errorCode, args);
        }
        return new ServiceException(errorCode, e, args);
    }

    public static ServiceException wrapException(Throwable e, String message, Object... args) {

        if (e instanceof ServiceException) {
            return (ServiceException) e;
        }
        if (e instanceof HttpStatusCodeException) {
            return wrapException((HttpStatusCodeException) e, message, args);
        }
        if (e instanceof WebApplicationException) {
            return wrapException((WebApplicationException) e, message, args);
        }
        return new ServiceException(message, e, args);
    }

    private static ServiceException wrapException(HttpStatusCodeException e, IErrorCode errorCode, Object... args) {

        return getServiceException(e.getStatusCode(), errorCode, e, args);
    }

    private static ServiceException wrapException(HttpStatusCodeException e, String message, Object... args) {

        return getServiceException(e.getStatusCode(), message, e, args);
    }

    private static ServiceException wrapException(WebApplicationException e, IErrorCode errorCode, Object... args) {

        return getServiceException(HttpStatus.valueOf(e.getResponse().getStatus()), errorCode, e, args);
    }

    private static ServiceException wrapException(WebApplicationException e, String message, Object... args) {

        return getServiceException(HttpStatus.valueOf(e.getResponse().getStatus()), message, e, args);
    }

    private static ServiceException getServiceException(HttpStatus status, IErrorCode errorCode, Exception e,
                                                        Object[] args) {
        switch (status) {
            case UNAUTHORIZED:
                return new UnauthorizedException(errorCode, e, args);
            case FORBIDDEN:
                return new ForbiddenException(errorCode, e, args);
            case NOT_FOUND:
                return new NotFoundException(errorCode, e, args);
            case BAD_REQUEST:
                return new BadRequestException(errorCode, e, args);
            default:
                return new ServiceException(errorCode, e, args);
        }
    }

    private static ServiceException getServiceException(HttpStatus status, String message, Exception e,
                                                        Object[] args) {
        switch (status) {
            case UNAUTHORIZED:
                return new UnauthorizedException(message, e, args);
            case FORBIDDEN:
                return new ForbiddenException(message, e, args);
            case NOT_FOUND:
                return new NotFoundException(message, e, args);
            case BAD_REQUEST:
                return new BadRequestException(message, e, args);
            default:
                return new ServiceException(message, e, args);
        }
    }
}
