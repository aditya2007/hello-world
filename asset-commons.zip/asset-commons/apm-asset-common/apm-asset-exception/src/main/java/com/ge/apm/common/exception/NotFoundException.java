/******************************************************************************
 * Copyright (c) 2015 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.common.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class NotFoundException extends ServiceException {

    // Implicit code constructors

    public NotFoundException(String message, Object... messageArgs) {
        super(HttpStatus.NOT_FOUND.name(), message, messageArgs);
    }

    public NotFoundException(String message, Throwable cause, Object... messageArgs) {
        super(HttpStatus.NOT_FOUND.name(), message, cause, messageArgs);
    }

    // IErrorCode constructors

    public NotFoundException(IErrorCode errorCode, Object... messageArgs) {
        super(errorCode, messageArgs);
    }

    public NotFoundException(IErrorCode errorCode, Throwable cause, Object... messageArgs) {
        super(errorCode, cause, messageArgs);
    }
}
