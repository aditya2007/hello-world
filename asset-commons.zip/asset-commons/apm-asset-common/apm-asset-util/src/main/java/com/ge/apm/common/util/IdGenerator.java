package com.ge.apm.common.util;

import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.util.Random;
import java.util.UUID;

import org.apache.commons.codec.binary.Base64;

public class IdGenerator {

    private IdGenerator() { }

    public static String generateAsBase64EncodedString() {

        UUID uuid = UUID.randomUUID();
        byte[] array = ByteBuffer.allocate(16)
                                 .putLong(0, uuid.getMostSignificantBits())
                                 .putLong(8, uuid.getLeastSignificantBits())
                                 .array();
        return Base64.encodeBase64URLSafeString(array);
    }

    public static String generateAsString() {
        return UUID.randomUUID().toString();
    }

    /**
     * Generates a deterministic identifier from a list of arguments. The arguments will be converted to their string
     * representation, separated by the delimiter. For example, a delimiter of <code>/</code> and an argument list of
     * <code>a, b, c</code> will generate an ID based on <code>"a/b/c"</code>.
     *
     * The number of arguments will also be taken into account in the ID generation algorithm to ensure that two
     * different set of arguments that happen to have the same concatenated string representation will still generate
     * different ID.
     *
     * @param delimiter
     * @param args
     *            an array of arguments to be prefixed with the delimiter, then concatenated to generate the
     *            deterministic ID
     * @return a deterministic identifier string
     */
    public static String generateFrom(String delimiter, Object... args) {
        StringBuilder buf = new StringBuilder();
        for (int i = 0, len = args.length; i < len; i++) {
            if (i > 0) {
                buf.append(delimiter);
            }
            buf.append(args[i]);
        }

        // this ensures same delimiter and args generate the same ID
        // for example, ("/", "a", "b", "c") and ("/", "a/b/c") will generate different ID
        buf.append(delimiter).append(args.length);

        return UUID.nameUUIDFromBytes(buf.toString().getBytes()).toString();
    }

    public static String generateShortId(int length) {

        char[] idChars = new char[length];
        for (int i = 0; i < idChars.length; i++) {
            idChars[i] = ID_LOOKUP[ID_RANDOM.nextInt(ID_LOOKUP.length)];
        }
        return new String(idChars);
    }

    private static final Random ID_RANDOM = new SecureRandom();
    private static final char[] ID_LOOKUP = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
}
