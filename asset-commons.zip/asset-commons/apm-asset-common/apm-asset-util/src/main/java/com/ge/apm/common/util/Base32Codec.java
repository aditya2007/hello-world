/******************************************************************************
 * Copyright (c) 2016 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.common.util;

import org.apache.commons.codec.binary.Base32;
import org.apache.commons.codec.binary.StringUtils;

/**
 * Contains helper methods to encode/decode strings using the Base32 algorithm.
 *
 * @author Pushkaraj Shirgaonkar
 */
public class Base32Codec {

    private Base32 base32 = new Base32();

    private Base32Codec() { }

    public String encode(String raw, boolean usePadding) {

        byte[] rawBytes = StringUtils.getBytesUtf8(raw);
        byte[] encodedBytes = base32.encode(rawBytes);
        String encoded = StringUtils.newStringUtf8(encodedBytes);
        if (!usePadding) {
            encoded = encoded.replaceFirst("=+$", "");
        }
        return encoded;
    }

    public String decode(String encoded) {

        byte[] encodedBytes = StringUtils.getBytesUtf8(encoded);
        byte[] rawBytes = base32.decode(encodedBytes);
        String raw = StringUtils.newStringUtf8(rawBytes);
        return raw;
    }

    public static final Base32Codec INSTANCE = new Base32Codec();
}
