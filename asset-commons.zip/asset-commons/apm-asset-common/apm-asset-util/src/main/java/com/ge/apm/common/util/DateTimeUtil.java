package com.ge.apm.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public final class DateTimeUtil {
    public static final String GMT_TIME_ZONE = "GMT";
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd\'T\'HH:mm:ssZ";

    public static Date newDate() {
        return new Date();
    }

    public static SimpleDateFormat getUtcSimpleDateFormat() {
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT);
        sdf.setTimeZone(TimeZone.getTimeZone(GMT_TIME_ZONE));
        return sdf;
    }

    public static String formatUtcDate(Date dateTime) {
        return getUtcSimpleDateFormat().format(dateTime);
    }

    public static Date parseUtcDate(String dateTime) throws ParseException {
        return getUtcSimpleDateFormat().parse(dateTime);
    }

    public static Date getDate(String dateTime) throws DatatypeConfigurationException {
        DatatypeFactory factory = DatatypeFactory.newInstance();
        XMLGregorianCalendar xmlGregorianCalendar = factory.newXMLGregorianCalendar(dateTime);
        GregorianCalendar gregorianCalendar = xmlGregorianCalendar.toGregorianCalendar();
        return gregorianCalendar.getTime();
    }

    public static TimeZone getTimeZone(String dateTime) throws DatatypeConfigurationException {
        DatatypeFactory factory = DatatypeFactory.newInstance();
        XMLGregorianCalendar xmlGregorianCalendar = factory.newXMLGregorianCalendar(dateTime);
        GregorianCalendar gregorianCalendar = xmlGregorianCalendar.toGregorianCalendar();
        return gregorianCalendar.getTimeZone();
    }
}
