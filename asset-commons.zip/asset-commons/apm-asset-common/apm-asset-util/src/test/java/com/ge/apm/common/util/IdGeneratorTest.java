/******************************************************************************
 * Copyright (c) 2016 GE Global Research. All rights reserved.                *
 *                                                                            *
 * The computer software herein is the property of GE Global Research. The    *
 * software may be used and/or copied only with the written permission of     *
 * GE Global Research or in accordance with the terms and conditions          *
 * stipulated in the agreement/contract under which the software has been     *
 * supplied.                                                                  *
 ******************************************************************************/

package com.ge.apm.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Description of IdGeneratorTest
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Jun 28, 2016
 * @since 1.0
 */
public class IdGeneratorTest {

    @Test
    public void generateFrom() {
        // verify same delimiter, args will generate same ID, i.e., it is indeed deterministic
        String id1 = IdGenerator.generateFrom("/", "a", "b", "c");
        // hard-coding the expected value unnecessarily couples this test to generateFrom(...) implementation too
        // tightly
        String id2 = "3046453e-0c56-346b-8281-8249c159e333"; //IdGenerator.generateFrom("/", "a", "b", "c");
        assertEquals(id2, id1);

        // different args, different ID
        String id3 = IdGenerator.generateFrom("/", "A", "b", "c");
        assertNotEquals(id1, id3);

        // different delimiter, same args, different ID
        String id4 = IdGenerator.generateFrom(":", "a", "b", "c");
        assertNotEquals(id1, id4);

        // verify delimiters, if present in args, are not stripped off
        String id5 = IdGenerator.generateFrom("/", "a/", "b/", "c");
        assertNotEquals(id1, id5);

        // able to handle null's
        String id6 = IdGenerator.generateFrom("/", null, "a", null);
        String id7 = IdGenerator.generateFrom("/", null, "a", null);
        assertEquals(id6, id7);

        // handle disambiguation of different # of args, but same string representation
        String id8 = IdGenerator.generateFrom("/", "a/b/c");
        assertNotEquals(id1, id8);

        // verify ability to handle corner cases without blowing up
        assertNotNull(IdGenerator.generateFrom("/", (Object)null));
        assertNotNull(IdGenerator.generateFrom("/", null, null));
        assertNotNull(IdGenerator.generateFrom("/", ""));
    }

}
