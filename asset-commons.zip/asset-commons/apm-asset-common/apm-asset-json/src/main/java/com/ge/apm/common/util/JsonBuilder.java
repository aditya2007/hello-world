package com.ge.apm.common.util;

import java.lang.reflect.Type;

import com.google.gson.Gson;

public class JsonBuilder {
    public static String toJson(Object src) {
        Gson jsonBuilder = GsonFactory.getGson();
        return jsonBuilder.toJson(src);
    }

    public static String toPrettyPrintJson(Object src) {
        Gson jsonBuilder = GsonFactory.getPrettyPrintGson();
        return jsonBuilder.toJson(src);
    }

    public static String toNullExcludedJson(Object src) {
        Gson jsonBuilder = GsonFactory.getNullExcludedGson();
        return jsonBuilder.toJson(src);
    }

    public static <T> T fromJson(String srcJson, Class<T> clazz) {
        return GsonFactory.getGson().fromJson(srcJson, clazz);
    }

    public static <T> T fromJson(String srcJson, Type type) {
        return GsonFactory.getGson().fromJson(srcJson, type);
    }
}
