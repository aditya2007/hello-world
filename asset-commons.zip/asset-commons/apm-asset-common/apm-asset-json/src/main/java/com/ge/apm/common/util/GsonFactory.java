package com.ge.apm.common.util;

import java.lang.reflect.Type;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

public class GsonFactory {
    private static final JDOExclusionStrategy JDO_FIELD_EXCLUSION_STRATEGY = new JDOExclusionStrategy();
    private static final IdExclusionStrategy ID_EXCLUSION_STRATEGY = new IdExclusionStrategy();

    public static Gson getGson() {
        GsonBuilder builder = new GsonBuilder().serializeNulls();
        registerTypeAdapters(builder);
        addExclusionStrategies(builder);
        return builder.create();
    }

    public static Gson getNullExcludedGson() {
        GsonBuilder builder = new GsonBuilder();
        registerTypeAdapters(builder);
        addExclusionStrategies(builder);
        return builder.create();
    }

    public static Gson getPrettyPrintGson() {
        GsonBuilder builder = new GsonBuilder().setPrettyPrinting();
        registerTypeAdapters(builder);
        addExclusionStrategies(builder);
        return builder.create();
    }

    private static void registerTypeAdapters(GsonBuilder builder) {
        builder.registerTypeAdapter(Timestamp.class, new SqlTimestampConverter());
        builder.registerTypeAdapter(Date.class, new DateSerializer());
        builder.registerTypeAdapter(Date.class, new DateDeserializer());
        builder.registerTypeAdapter(BigInteger.class, new BigIntegerSerializer());
    }

    private static void addExclusionStrategies(GsonBuilder builder) {
        builder.addSerializationExclusionStrategy(JDO_FIELD_EXCLUSION_STRATEGY);
        builder.addSerializationExclusionStrategy(ID_EXCLUSION_STRATEGY);
    }

    public static class JDOExclusionStrategy implements ExclusionStrategy {
        public boolean shouldSkipField(FieldAttributes f) {
            return f.getName().equals("jdoDetachedState");
        }

        public boolean shouldSkipClass(Class<?> clazz) {
            return false;
        }
    }

    public static class IdExclusionStrategy implements ExclusionStrategy {
        public boolean shouldSkipField(FieldAttributes f) {
            return f.getAnnotations().stream()
                .anyMatch(a -> "javax.persistence.Id".equals(a.annotationType().getCanonicalName()));
        }

        public boolean shouldSkipClass(Class<?> clazz) {
            return false;
        }
    }

    private static class DateSerializer implements JsonSerializer<Date> {
        @Override
        public JsonElement serialize(Date src, Type srcType, JsonSerializationContext context) {
            return new JsonPrimitive(src.getTime());
        }
    }

    private static class DateDeserializer implements JsonDeserializer<Date> {
        @Override
        public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws
            JsonParseException {
            return new Date(json.getAsLong());
        }
    }

    private static class SqlTimestampConverter implements JsonSerializer<Timestamp> {
        private SimpleDateFormat sdf = new SimpleDateFormat(DateTimeUtil.DATE_TIME_FORMAT);

        public JsonElement serialize(Timestamp src, Type srcType, JsonSerializationContext context) {
            return new JsonPrimitive(sdf.format(src));
        }
    }

    /**
     * Addresses error where BigInteger value was converted to String rather than Double.
     * If we later introduce attributes that are BigIntegers we need to change this method.
     */
    private static class BigIntegerSerializer implements JsonSerializer<BigInteger> {
        public JsonElement serialize(BigInteger src, Type srcType, JsonSerializationContext context) {
            return new JsonPrimitive(src.doubleValue());
        }
    }
}
