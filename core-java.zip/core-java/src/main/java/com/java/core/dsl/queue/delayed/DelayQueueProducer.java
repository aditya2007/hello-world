package com.java.core.dsl.queue.delayed;

import java.util.UUID;
import java.util.concurrent.BlockingQueue;

public class DelayQueueProducer implements Runnable {

	private BlockingQueue<DelayedObject> queue;
	private Integer nOfElmntsToProduce;
	private Integer delayOfEachProducedMsgMilliSec;

	public DelayQueueProducer(BlockingQueue<DelayedObject> queue,
								Integer nOfElmntsToProduce, Integer delayOfEachProducedMsgMilliSec) {
		this.queue = queue;
		this.nOfElmntsToProduce = nOfElmntsToProduce;
		this.delayOfEachProducedMsgMilliSec = delayOfEachProducedMsgMilliSec;
	}

	@Override
	public void run() {
		for (int i = 0; i < nOfElmntsToProduce; i++) {
			DelayedObject object
				= new DelayedObject(
				UUID.randomUUID().toString(), delayOfEachProducedMsgMilliSec);
			System.out.println("Put object: " + object);
			try {
				queue.put(object);
				Thread.sleep(500);
			} catch (InterruptedException ie) {
				ie.printStackTrace();
			}
		}
	}
}
