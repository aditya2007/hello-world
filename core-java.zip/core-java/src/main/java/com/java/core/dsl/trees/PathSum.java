package com.java.core.dsl.trees;

import java.util.ArrayList;
import java.util.List;

public class PathSum {

	/**
	 * Given a binary tree and a sum, find all root-to-leaf paths where each path's sum equals the given sum.

	 For example:
	 Given the below binary tree and sum = 22,
	  5
	 /  \
	4    8
	/   /   \
   11  13     4
  /  \       / \
 7    2     5   1
	 return
	 [
	 [5,4,11,2],
	 [5,8,4,5]
	 ]
 	 *
	 * https://leetcode.com/problems/path-sum-ii/discuss/36683/DFS-with-one-LinkedList-accepted-java-solution
	 */
	public List<List<Integer>> pathSum(TreeNode root, int sum) {
		List<List<Integer>> nodesPathList = new ArrayList<>();
		List<Integer> nodesList = new ArrayList<>();
		pathSum(root, sum, nodesList, nodesPathList);
		return nodesPathList;
	}

	void pathSum(TreeNode root, int sum, List<Integer> nodesList, List<List<Integer>> nodesPathList) {
		if (root == null) return;

		nodesList.add(root.val);
		if (root.left == null && root.right == null && root.val == sum) {
			nodesPathList.add(new ArrayList<Integer>(nodesList));
		} else {
			pathSum(root.left, sum - root.val, nodesList, nodesPathList);
			pathSum(root.right, sum - root.val, nodesList, nodesPathList);
		}

		nodesList.remove(nodesList.size() - 1);
	}

	public static void main(String[] args) {
		PathSum pathSum = new PathSum();

		TreeNode node5 = new TreeNode(5);
		TreeNode node4 = new TreeNode(4);
		TreeNode node8 = new TreeNode(8);
		TreeNode node11 = new TreeNode(11);
		TreeNode node13 = new TreeNode(13);
		TreeNode node4_1 = new TreeNode(4);
		TreeNode node7 = new TreeNode(7);
		TreeNode node2 = new TreeNode(2);
		TreeNode node5_1 = new TreeNode(5);
		TreeNode node1 = new TreeNode(1);

		/*node5.left = node4;
		node5.right = node8;
		node4.left = node11;
		node8.left = node13;
		node8.right = node4_1;
		node11.left = node7;
		node11.right = node2;
		node4_1.left = node5_1;
		node4_1.right = node1;

		TreesUtil.printTree(node5);
		List<List<Integer>> nodesPathList = pathSum.pathSum(node5, 22);
		System.out.println(nodesPathList);*/

		node5.left = node4;
		node5.right = node8;
		node4.left = node11;
		node8.left = node13;
		node8.right = node4_1;
		node11.left = node7;
		node11.right = node2;
		node4_1.right = node1;
		TreesUtil.printTree(node5);
		System.out.println(pathSum.hasPathSum(node5, 22));

	}

	/**
	 *Given a binary tree and a sum, determine if the tree has a root-to-leaf path such that adding up all the
	 * values along the path equals the given sum.

	 For example:
	 Given the below binary tree and sum = 22,

	 5
	 / \
	 4   8
	/   / \
  11  13  4
 /  \      \
7    2      1
	 return true, as there exist a root-to-leaf path 5->4->11->2 which sum is 22.
	 *
	 */
	public boolean hasPathSum(TreeNode root, int sum) {
		if (root == null) return false;

		if (root.left == null && root.right == null) {
			return sum == root.val;
		}

		return hasPathSum(root.left, sum - root.val) || hasPathSum(root.right, sum - root.val);
	}
}
