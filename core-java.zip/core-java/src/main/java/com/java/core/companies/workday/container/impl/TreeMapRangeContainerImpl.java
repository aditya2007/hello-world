package com.java.core.companies.workday.container.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.LongStream;

import com.java.core.companies.workday.container.Ids;
import com.java.core.companies.workday.container.RangeContainer;

/**
 * Uses Java's TreeMap data structure to keep track of the data and the index of the data.
 *  Then to find the range, simply use subMap method that comes with the TreeMap.
 */
public class TreeMapRangeContainerImpl implements RangeContainer {
	private TreeMap<Long, Short> rangeToIndex;

	public TreeMapRangeContainerImpl(long[] data) {
		this.rangeToIndex = new TreeMap<>();
		for (short i = 0; i < data.length; i++) {
			rangeToIndex.put(data[i], i);
		}
	}

	@Override
	public Ids findIdsInRange(long fromValue, long toValue, boolean fromInclusive, boolean toInclusive) {
		System.out.println(rangeToIndex.firstKey());
		System.out.println(rangeToIndex.lastKey());
		SortedMap<Long, Short> headMap = rangeToIndex.headMap(12l);
		NavigableMap<Long, Short> subMap = rangeToIndex.subMap(fromValue, fromInclusive, toValue, toInclusive);
		List<Short> sortedList = new ArrayList<>(subMap.values());
		Collections.sort(sortedList);
		return new IdsImpl(sortedList.iterator());
	}

}
