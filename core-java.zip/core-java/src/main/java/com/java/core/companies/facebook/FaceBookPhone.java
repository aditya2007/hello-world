package com.java.core.companies.facebook;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

public class FaceBookPhone {
	public static void main(String[] args) {
		FaceBookPhone fb = new FaceBookPhone();
		possiblePatterns();
		//String[] arr = {"1", "6", "0", "9", "1"};
		String[] arr = {"1", "7", "1"};
		//System.out.println(check180(arr));
		//fb.calculateMovingAverage(10);
		String[] words = {"cc", "cb", "bb", "ac", "ab"};
		//String[] words = {"bb", "cb", "cc", "ac"};
		char[] ordering = {'c', 'b', 'a'};
		//System.out.println(checkOrder(words, ordering));
	}

	/**
	 * Given two input arrays, return true if the words array is sorted according to the ordering array
	 Input:
	 words = ['cc', 'cb', 'bb', 'ac']
	 ordering = ['c', 'b', 'a']
	 Output: True

	 Input:
	 words = ['cc', 'cb', 'bb', 'ac']
	 ordering = ['b', 'c', 'a']
	 Output: False
	 */
	static boolean checkOrder(String[] words, char[] ordering) {
		int idx = 0;
		for (int i = 0; i < words.length - 1; i++) {

			if (words[i].charAt(0) == words[i + 1].charAt(0)) {
				continue;
			} else if (words[i].charAt(0) != ordering[idx]) {
				return false;
			}
			idx++;
		}//end of for loop

		if (words[words.length - 1].charAt(0) != ordering[idx]) {
			return false;
		}
		return true;
	}

	static void possiblePatterns() {
		Map<String, char[]> map = new HashMap<>();
		char arr1[]={'A', 'B', 'C'};
		map.put("1", arr1);
		char arr2[]={'D', 'E'};
		map.put("2", arr2);
		char arr3[]={'X'};
		map.put("12", arr3);
		char arr4[]={'P', 'Q'};
		map.put("3", arr4);
		char arr5[]={'Y', 'Z'};
		map.put("123", arr5);

		StringBuilder pattern = new StringBuilder();
		List<String> result = new ArrayList<>();

		String input = "1234";
		possiblePatterns(input, map, pattern, result, 0);
		System.out.println(result);

		for (int idx = 2; idx < input.length(); idx++) {
			String subStr = input.substring(0, idx);
			if (subStr != null && map.containsKey(subStr)) {
				for (char c : map.get(subStr)) {
					pattern.append(c);
					possiblePatterns(input, map, pattern, result, idx);
					pattern.deleteCharAt(pattern.length() - 1);
				} //end of inner for loop
			} //end of contains check
		} //end of outer for loop

		if (map.containsKey(input)) {
			for (char c : map.get(input)) {
				result.add(c + "");
			}
		}

		System.out.println(result);
	}

	static void possiblePatterns(String input, Map<String, char[]> stringMap,
											StringBuilder pattern, List<String> result, int startIdx) {
		if (startIdx >= input.length()) {
			result.add(pattern.toString());
			return;
		}

		char[] inputPatterns = stringMap.get(input.charAt(startIdx) + "");
		if (inputPatterns != null && inputPatterns.length > 0) {
			for (char c : inputPatterns) {
				pattern.append(c);
				possiblePatterns(input, stringMap, pattern, result, startIdx + 1);
				pattern.deleteCharAt(pattern.length() - 1);
			} //end of for loop
		} else {//end of if loop
			result.add(pattern.toString());
			return;
		}
	}

	/**
	 * Given an input array of verify if it turned 180 degrees it is the same
	 *
	 * input = {1, 6, 0, 9, 1} return true
	 * input = {1, 7, 1} return true
	 */
	private static boolean check180(String[] arr) {
		int length = arr.length;
		Map<String,String> matcher = new HashMap<String, String>();
		matcher.put("0","0");
		matcher.put("1","1");
		matcher.put("6","9");
		matcher.put("8","8");
		matcher.put("9","6");

		boolean oddLength = (length % 2 != 0);
		if(oddLength && !arr[length/2].equals("8") && !arr[length/2].equals("0")) {
			return false;
		}

		int half = oddLength ? (length/2)+1 : length/2;
		int i = 0;
		int j=length-1;
		for(;i<length/2;i++,j--) {
			if(!matcher.get(arr[i]).equals(arr[j])) {
				return false;
			}
		}
		return true;
	}

	int[] queue;
	int head;
	int tail;
	int size;
	int sum;

	private void calculateMovingAverage(int capacity) {
		queue = new int[capacity];

		Random random = new Random();
		// random.ints(1,10)
		// 	.forEach(num -> System.out.println(movingAverage(num)));
		for (int i = 0; i <= capacity; i++) {
			System.out.println(movingAverage((i + 1) * 2));
		}

	}


	private double movingAverage(int num) {
		sum += num;

		if (size == queue.length) {
			sum -= queue[head];
			head = (head + 1) % queue.length;
		} else {
			size++;
		}
		queue[tail] = num;
		tail = (tail + 1) % queue.length;
		System.out.println(Arrays.toString(queue));
		return 1.0 * sum / size;
	}
}
