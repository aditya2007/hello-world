package com.java.core.dsl.arrays;

import java.util.*;

public class ArraysAndString {

	static Map<String, String> treeMap =  new TreeMap<String, String>();

	public static void main(String[] args) {
		//System.out.println(computeBinary(5));
		//toBinary();
		//testBitwiseOperators();
		//testEqualObjectEqualMethod();
		/*String reptCharsStr = "aaaccbaaaaaddddf";
		sortDescRepeatedCharsSequence(reptCharsStr);

		List<String> list = new ArrayList<String>();
		list.addAll(treeMap.values());

		for (String key : treeMap.keySet() ) {
			System.out.println(key + ":" + treeMap.get(key));
		}

		for (int i = list.size() - 1; i >= 0; i-- ) {
			System.out.println(list.get(i));
		}*/
		// List<Integer> fibList = new ArrayList<>();
		// fibRecurssion(10, fibList);
		// generateFibLoop(5);
		// System.out.println(fibList);

		reverseTheVowels();

		//System.out.println(isIsomorphic("paper", "title"));

		//System.out.println(isAnagram("abc", "cab"));
		// Max Contegious subsequence array
		int[] input = {6,2,3,1,5};
		//System.out.println(maxSubArray(input));
	}

	protected static void sortDescRepeatedCharsSequence(String reptCharsStr) {
		System.out.println(reptCharsStr);
		char last = reptCharsStr.charAt(0);
		String nextReptCharsStr = last +"";
		int count = 1;
		String reptCharsCount = count +""+ last;
		
		for( int i = 1; i < reptCharsStr.length(); i++ ) {
			if( reptCharsStr.charAt(i) == last ) {
				nextReptCharsStr += reptCharsStr.charAt(i);
				//System.out.println("Next Repeated Chars  **** " + nextReptCharsStr );
				count++;
				if( reptCharsStr.length()-1 == i ) {
					reptCharsCount = count +""+ last;
					//System.out.println("Repeated Chars Count >>> " + reptCharsCount );
					treeMap.put(reptCharsCount, nextReptCharsStr);
				}
			} //end of if condition
			else {
				reptCharsCount = count +""+ last;
				treeMap.put(reptCharsCount, nextReptCharsStr);
				count = 1;
				//System.out.println("Repeated Chars Count >>> " + reptCharsCount );
				last = reptCharsStr.charAt(i);
				//System.out.println("Last visited character >>>> " + last);
				nextReptCharsStr = last +"";
				if( reptCharsStr.length()-1 == i ) {
					reptCharsCount = count +""+ last;
					treeMap.put(reptCharsCount, nextReptCharsStr);
				}
			}// end of else
		}//end of for loop
	}

	static Map<Integer, String> recValMap = new HashMap<>();

	public static String computeBinary(int val) {
		// This is to avoid, repeating of recurrsion call, which reduce time complexity, even though it increase space
		if (recValMap.containsKey(val)) {
			return recValMap.get(val);
		}
		// Base case: value is less than 2
		else if (val < 2) {
			String str = Integer.toString(val);
			System.out.println("str value :: " + str);
			recValMap.put(val, str);
			return str;
		}
		// Recursive case: binary rep = binary of the header + last digit (odd/even)
		else {
			String str1 = computeBinary(val/2) + computeBinary(val%2);
			System.out.println("str1 value :: " + str1);
			return str1;
		}
	}

	private static void toBinary() {
		int number = -8; //0010
		/*System.out.println(" value of number on left shift : " + (8 << 1));
		System.out.println(" value of number on left shift : " + (-8 << 1));
		System.out.println(" value of number on right shift : " + (8 >> 1));
		System.out.println(" value of number on right shift : " + (-8 >> 1));
		System.out.println(" value of number on right shift : " + (8 >>> 1));
		System.out.println(" value of number on right shift : " + (-8 >>> 1));
		System.out.println(" value of number after negation: " + ~number);*/


		System.out.println("1 :: " + Integer.toBinaryString(-12));
		System.out.println("1 << 4 :: " + Integer.toBinaryString(4 << 1));
		System.out.println("1 >> 4 :: " + Integer.toBinaryString(1 >> 4));
		System.out.println("2 :: " + Integer.toBinaryString(2));
		System.out.println("2 << 2 :: " + Integer.toBinaryString(2 << 2));
		System.out.println("2 >> 4 :: " + Integer.toBinaryString(2 >> 4));
		System.out.println("16 :: " + Integer.toBinaryString(16));
		System.out.println("32 << 1 :: " + Integer.toBinaryString(32 << 1));
		System.out.println("32 >> 1 :: " + Integer.toBinaryString(32 >> 1));
		System.out.println("32 << 2 :: " + Integer.toBinaryString(32 << 2));
		System.out.println("32 >> 2 :: " + Integer.toBinaryString(32 >> 2));
		/*System.out.println(Integer.toBinaryString(11));
		System.out.println(Integer.toBinaryString(2 << 11));
		System.out.println(Integer.toBinaryString(11 >> 2));
		System.out.println(Integer.toBinaryString(2 << 22));
		System.out.println(Integer.toBinaryString(2 << 33));
		System.out.println(Integer.toBinaryString(2 << 44));
		System.out.println(Integer.toBinaryString(2 << 55));*/
	}
	
	private static void testBitwiseOperators() {
		int a = 60;	    /* 60 = 0011 1100 */
	     int b = 13;	/* 13 = 0000 1101 */
	     int c = 0;
	     int checker = 65;
	     c = a & b;       /* 12 = 0000 1100 */ 
	     System.out.println("a & b = " + c );

	     c = a | b;       /* 61 = 0011 1101 */
	     System.out.println("a | b = " + c );

	     c = a ^ b;       /* 49 = 0011 0001 */
	     System.out.println("a ^ b = " + c );

	     c = ~a;          /*-61 = 1100 0011 */
	     System.out.println("~a = " + c );

	     c = a << 2;     /* 240 = 1111 0000 */
	     System.out.println("a << 2 = " + c );

	     c = a >> 2;     /* 15 = 1111 */
	     System.out.println("a >> 2  = " + c );

	     c = a >>> 2;     /* 15 = 0000 1111 */
	     System.out.println("a >>> 2 = " + c );
	     
	}
	
	private static void testEqualObjectEqualMethod() {
		Object1 obj1 = new Object1();
		Object1 obj2 = new Object1();
		
		System.out.println("obj1 == obj2 >>>> " + (obj1 == obj2)); //return false
		System.out.println("obj1.equals(obj2) >>>> "  + (obj1.equals(obj2))); //return false
		
		System.out.println("obj1 == obj1 >>>> " + (obj1 == obj1)); // return true
		System.out.println("obj2.equals(obj2) >>>> "  + (obj2.equals(obj2))); //return true
		
		System.out.println("obj1 hascode >>>>> " + Objects.hashCode(obj1)); // return 2133927002
		System.out.println("obj2 hascode >>>>> " + Objects.hashCode(obj2)); // return 1836019240
		
		String str1 = "abc";
		String str2 = "abc";
		String str3 = str1;
		String str4 = new String("abc");
		System.out.println(" str1 == str2 >>>>>> " + (str1 == str2));
		System.out.println(" str1.equals(str2) >>>>>> " + (str1.equals(str2)));
		
		System.out.println(" str1 == str3 >>>>>> " + (str1 == str3));
		System.out.println(" str1.equals(str3) >>>>>> " + (str1.equals(str3)));
		
		System.out.println(" str1 == str4 >>>>>> " + (str1 == str4));
		System.out.println(" str1.equals(str4) >>>>>> " + (str1.equals(str4)));
		
		System.out.println("str1 hascode >>>>> " + Objects.hashCode(str1)); // return 96354
		System.out.println("str2 hascode >>>>> " + Objects.hashCode(str2)); // return 96534
		System.out.println("str3 hascode >>>>> " + Objects.hashCode(str3)); // return 96534
		System.out.println("str4 hascode >>>>> " + Objects.hashCode(str4)); // return 96534
	}

	private static int fibRecurssion (int n, List<Integer> fibList) {
		if (n == 0) {
			fibList.add(0);
			return 0;
		} else if (n == 1) {
			fibList.add(1);
			return 1;
		} else {
			int fib = fibRecurssion(n-1, fibList) + fibRecurssion(n-2, fibList);
			fibList.add(fib);
			return fib;
		}
	}

	private static void fibLoop(int n) {
		int prev = 0;
		int fibonacci = 0;
		int current = 1;
		StringBuilder builder = new StringBuilder();
		builder.append(prev).append(",").append(current).append(",");

		for( int i = 2; i < n; i++ ) {
			fibonacci = prev + current;
			//fibonacci += current;
			if( i < n-1 ) {
				builder.append(fibonacci).append(",");
			} else {
				builder.append(fibonacci);
			}
			prev = current;
			current = fibonacci;
		}
		System.out.println(builder);
	}

	public static void generateFibLoop(Integer n) {
		int prev = 0;
		int current = 1;
		int fib;

		List<Integer> fibList = new ArrayList<>();
		fibList.add(prev);
		fibList.add(current);
		while ((n - 2) > 0) {
			fib = prev + current;
			fibList.add(fib);
			prev = current;
			current = fib;
			n--;
		}
		System.out.println(fibList);
	}

	/**
	 * Given a string, identify the vowels and reverse the vowels in their position.
	 * For eg.
	 	Input: education
	 	Output: odicatuen
	 */
	static void reverseTheVowels() {
		String word = "realtor";
		System.out.println(word);

		List<Character> charsList = new ArrayList<>(10);
		charsList.add('a');
		charsList.add('e');
		charsList.add('i');
		charsList.add('o');
		charsList.add('u');
		charsList.add('A');
		charsList.add('E');
		charsList.add('I');
		charsList.add('O');
		charsList.add('U');

		int bIdx = 0;
		int eIdx = word.length() - 1;
		char[] input = word.toCharArray();
		while (bIdx < eIdx) {
			if (!charsList.contains(input[bIdx])) {
				bIdx++;
				continue;
			}
			if (!charsList.contains(input[eIdx])) {
				eIdx--;
				continue;
			}

			if (bIdx < eIdx) {
				char temp = input[bIdx];
				input[bIdx++] = input[eIdx];
				input[eIdx--] = temp;
			}
		}
		System.out.println(new String(input));
	}

	static boolean isVowel(Character c) {
		return (c=='a' || c=='A' || c=='e' ||
				c=='E' || c=='i' || c=='I' ||
				c=='o' || c=='O' || c=='u' ||
				c=='U');
	}

	/**
	 * Given two strings s1 and s2, determine if they are isomorphic.

	 Two strings are isomorphic if the characters in s can be replaced to get t.

	 All occurrences of a character must be replaced with another character
	 while preserving the order of characters.
	 No two characters may map to the same character but a character may map to itself.

	 For example,
	 Given "egg", "add", return true.

	 Given "foo", "bar", return false.

	 Given "paper", "title", return true.

	 Note:
	 You may assume both s and t have the same length.
	 * @param s1
	 * @param s2
	 * @return
	 */
	static boolean isIsomorphic(String s1, String s2) {
		int[] m1 = new int[128];
		int[] m2 = new int[128];

		for (int i = 0; i < s1.length(); i++) {
			if (m1[s1.charAt(i)] != m2[s2.charAt(i)]) return false;
				m1[s1.charAt(i)] = m2[s2.charAt(i)] = i + 1;
		}
		return true;
	}

	static boolean isAnagram(String input1, String input2) {
		if(input1 == null || input2 == null || (input1.length() != input2.length())){
			return false;
		} else {
			int[] buffer = new int[26];
			for(int i=0; i < input1.length(); i++){
				buffer[input1.charAt(i) - 'a']++;
				buffer[input2.charAt(i) - 'a']--;
			}
			for(int j=0; j < buffer.length; j++){
				if(buffer[j] != 0) return false;
			}
			return true;
		}


		//Which uses more space instead of 26 array size, it uses 256
		 /*int[] allLetters = new int[256];

		for(int i=0; i<input1.length(); i++){
			allLetters[input1.charAt(i)]++;
			allLetters[input2.charAt(i)]--;
		}

		for(Integer e: allLetters){
			if(e!=0){
				return false;
			}
		}
		return true;*/
	}

	static int maxSubArray(int[] input) {
		int n = input.length;
		int[] dp = new int[n];//dp[i] means the maximum subarray ending with A[i];
		dp[0] = input[0];
		int max = dp[0];

		for(int i = 1; i < n; i++){
			dp[i] = input[i] + (dp[i - 1] > 0 ? dp[i - 1] : 0);
			max = Math.max(max, dp[i]);
		}

		return max;
	}
}
