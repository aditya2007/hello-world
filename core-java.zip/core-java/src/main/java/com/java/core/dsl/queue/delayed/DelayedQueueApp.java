package com.java.core.dsl.queue.delayed;

import java.util.PriorityQueue;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;

public class DelayedQueueApp {

	public static void main(String[] args) throws Exception {
		DelayedQueueApp app = new DelayedQueueApp();
		app.givenDelayQueue_whenProduceElement_thenShouldConsumeAfterGivenDelay();
	}

	public void givenDelayQueue_whenProduceElement_thenShouldConsumeAfterGivenDelay() throws InterruptedException {
		// given
		ExecutorService executor = Executors.newFixedThreadPool(2);

		//BlockingQueue<DelayedObject> queue = new DelayQueue<>();
		/*PriorityBlockingQueue<DelayedObject> queue =  new PriorityBlockingQueue();
		int numberOfElementsToProduce = 2;
		int delayOfEachProducedMessageMilliseconds = 500;
		DelayQueueConsumer consumer = new DelayQueueConsumer(
			queue, numberOfElementsToProduce);
		DelayQueueProducer producer = new DelayQueueProducer(
			queue, numberOfElementsToProduce, delayOfEachProducedMessageMilliseconds);

		// when
		executor.submit(producer);
		executor.submit(consumer);

		// then
		executor.awaitTermination(5, TimeUnit.SECONDS);
		executor.shutdown();

		//assertEquals(consumer.numberOfConsumedElements.get(), numberOfElementsToProduce);
		System.out.println(consumer.numberOfConsumedElements.get() + " = " + numberOfElementsToProduce);*/

		PriorityQueue<DelayedObject> queue = new PriorityQueue<>();
		DelayedObject object1 = new DelayedObject(
								"object1", 60000);
		DelayedObject object2 = new DelayedObject(
			"object2", 30000);
		DelayedObject object3 = new DelayedObject(
			"object3", 15000);

		queue.offer(object1);
		queue.offer(object2);
		queue.offer(object3);

		queue.stream().forEach(q -> System.out.println(q.getData() + " @time " + q.getDelay(TimeUnit.MILLISECONDS)));
	}
}
