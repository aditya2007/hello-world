package com.java.core.companies.workday.container.impl;

import java.util.Iterator;

import com.java.core.companies.workday.container.Ids;

public class IdsImpl implements Ids {

	private Iterator<Short> iterator;

	public IdsImpl(Iterator<Short> iterator) {
		this.iterator = iterator;
	}

	public short nextId() {
		return iterator.hasNext() ? iterator.next() : END_OF_IDS;
	}
}
