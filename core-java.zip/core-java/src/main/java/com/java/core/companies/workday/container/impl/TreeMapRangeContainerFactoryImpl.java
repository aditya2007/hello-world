package com.java.core.companies.workday.container.impl;

import com.java.core.companies.workday.container.RangeContainer;
import com.java.core.companies.workday.container.RangeContainerFactory;

public class TreeMapRangeContainerFactoryImpl implements RangeContainerFactory {

	@Override
	public RangeContainer createContainer(long[] data) {
		return new TreeMapRangeContainerImpl(data);
	}
}
