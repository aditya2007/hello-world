package com.java.core.leetcode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class StringToNumber {

	public static void main(String[] args) {
		String str = "213";
		//System.out.println(atoi(str) + 87);
		int num = 1234;
		System.out.println(itoa(num));
		//String product = multiplyMyApproach("10", "20");
		// System.out.println("Product of 10 * 20 :: " + product);
		//System.out.println("Sum of 17 + 18 :: " + add(17, 18));
		double n = 25.0;
		//System.out.println("Square root of " + n + " is :: " + sqrt1(25));
		//int num = 10;
		//System.out.println(num + " Is power Of 2 :: " + isPowOfTwo(num) );

		//System.out.println("Reverse a number :: " + reverseANumber(12345));
		//System.out.println(isPrime(21));
		/*List<Integer> list1 = new ArrayList<>();
		List<Integer> list2 = new ArrayList<>();
		Arrays.stream(new Random().ints(100000000,1, 100000000)
								.toArray()).forEach(i -> list1.add(1));
		Arrays.stream(new Random().ints(1000,1, 1000)
			.toArray()).forEach(i -> list2.add(i));

		List<Integer> result = findCommon1(list1, list2);
		System.out.println(result);*/
	}

	public static int atoi(String str) {
		if (str == null || str.length() < 1)
			return 0;
	 
		// trim white spaces
		str = str.trim();
	 
		char flag = '+';
	 
		// check negative or positive
		int idx = 0;
		if (str.charAt(0) == '-') {
			flag = '-';
			idx++;
		} else if (str.charAt(0) == '+') {
			idx++;
		}
		int result = 0;
		// calculate value
		while (idx < str.length() && str.charAt(idx) >= '0' && str.charAt(idx) <= '9') {
			result = result * 10 + (str.charAt(idx) - '0');
			idx++;
		}
	 
		if (flag == '-')
			result = -result;
	 
		// handle max and min
		if (result > Integer.MAX_VALUE)
			return Integer.MAX_VALUE;
	 
		if (result < Integer.MIN_VALUE)
			return Integer.MIN_VALUE;
	 
		//return (int) result;
		return result;
	}

	static String itoa(int num) {
		int arrSize = 0;
		int temp = num;
		// This is just get the array size for final result.
		while (temp != 0) {
			temp = temp / 10;
			++arrSize;
		}
		System.out.println(arrSize);
		char[] resultArr = new char[arrSize];
		int idx = 0;
		while (num != 0) {
			char ch = (char) (num % 10 + '0');
			resultArr[idx++] = ch;
			System.out.println("Char Value :: " + ch);
			num = num / 10;
		}

		int bIdx = 0;
		int eIdx = resultArr.length - 1;
		System.out.println(resultArr.length / 2);
		while (bIdx < resultArr.length / 2) {
			char temp1 = resultArr[bIdx];
			resultArr[bIdx++] = resultArr[eIdx];
			resultArr[eIdx--] = temp1;
		}
		System.out.println(Arrays.toString(resultArr));
		return new String(resultArr);
	}
	/**
	 * Given two non-negative integers num1 and num2 represented as strings,
	 * return the product of num1 and num2.

	 Note:

	 The length of both num1 and num2 is < 110.
	 Both num1 and num2 contains only digits 0-9.
	 Both num1 and num2 does not contain any leading zero.
	 You must not use any built-in BigInteger library or convert the inputs to integer directly.
	 * @return
	 */
	public static String multiplyMyApproach(String num1, String num2) {
		int convNum1 = atoi(num1);
		int convNum2 = atoi(num2);
		if (convNum1 > 109 || convNum2 > 109) {
			return Integer.MAX_VALUE + "";
		}
		return convNum1 * convNum2 + "";
	}

	public static String multiply(String num1, String num2) {
		int m = num1.length(), n = num2.length();
		int[] pos = new int[m + n];

		for(int i = m - 1; i >= 0; i--) {
			for(int j = n - 1; j >= 0; j--) {
				int mul = (num1.charAt(i) - '0') * (num2.charAt(j) - '0');
				int p1 = i + j, p2 = i + j + 1;
				int sum = mul + pos[p2];

				pos[p1] += sum / 10;
				pos[p2] = (sum) % 10;
			}
		}

		StringBuilder sb = new StringBuilder();
		for(int p : pos) if(!(sb.length() == 0 && p == 0)) sb.append(p);
		return sb.length() == 0 ? "0" : sb.toString();
	}

	/**
	 * Write a function that adds two numbers. You should not use +
	 * or any airthmetic operators
	 *
	 */
	static int add(int a, int b) {
		if( b == 0 ) return a;
		System.out.println("XOR value of a ^ b ::: " + Integer.toBinaryString(a ^ b));
		int sum = a ^ b; // add without carrying ==> Use XOR binary operator
		System.out.println("Sum without carrry : " + sum);
		int carry = (a & b) << 1; // carry, but don't add ==> Use AND and SHIFT to do carry
		System.out.println("Carry without sum : " + carry);
		return add(sum, carry);
		//return sum;
	}


	static int sqrt1(int x) {
		if ( x < 1 )return x;
		int r = x;
		while (r * r > x)
			r = (r + x / r) / 2;
		return r ;
	}

	/**
	 * Square Root equation to calculate the square root of a given number.
	 *
	 *  sqrt_n+1 = (sqrt_n + ( num / sqrt_n)) / 2;
	 * @param num
	 */
	private static double sqrt(double num) {
		System.out.println(" MATH.Square Root for a given number " + num + " is " + Math.sqrt(num));
		double t;
		double sqrRoot = num/2;

		do {
			t = sqrRoot;
			System.out.println("#### 't' value :: " + t);
			sqrRoot = (t + (num/sqrRoot)) / 2;
			System.out.println("#### 'sqrRoot' value :: " + sqrRoot);
		} while( (t - sqrRoot ) != 0 );

		System.out.println(" #Square Root for a given number " + num + " is " + sqrRoot);
		return sqrRoot;
	}

	/**
	 * Write a method - isPowOfTwo to test whether or not a given positive integer is a power of 2.
	 * Your method should run in constant O(1) time and use O(1) space.
	 *
	 * Examples:
		 isPowOfTwo(5) ==> false
		 isPowOfTwo(8) ==> true
	 * @param num
	 * @return
	 */
	public static boolean isPowOfTwo(int num) {
		/** If a number n is a power of 2, bitwise & of n and n-1 will be zero
		 *  num = 8
		 *  num ->  8 -> 1000
		 *  num - 1 7 -> 0111
		 *  ==================
		 *  &         -> 0000
		 *
		 *  num = 5
		 *  num ->   5 -> 101
		 *  num-1 -> 7 -> 100
		 *  ==================
		 *  &          -> 001
		 */
		if (((num & (num - 1)) == 0) || (num == 0))
			return true;
		else
			return false;
	}

	/**
	 * Reverse a number and find whether its a Palindrome or not
	 *
	 * @param num
	 * @return
	 */
	static int reverseANumber(int num) {
		//if (num < 0) return false;
		int result = 0;
		int x = num;
		while (x != 0) {
			result = result * 10 + x % 10;
			x = x /10;
		}
		System.out.println(result);
		return result;
	}

	static boolean isPrime(int n) {
		//check if n is a multiple of 2
		if (n%2 == 0) return false;
		//if not, then just check the odds
		for (int i = 3; i*i <= n; i += 2) {
			if (n%i == 0)
				return false;
		}
		return true;
	}

	static List findCommon(Set<Integer> set, List<Integer> lists) {
		List result = new ArrayList();
		for(Integer i : lists) {
			if(set.contains(i))
				result.add(i);
		}
		return result;
	}

	static List findCommon1(List<Integer> list1, List<Integer> list2) {
		List result = new ArrayList();
		for(Integer idx : list2) {
			if(list1.contains(idx))
				result.add(idx);
		}
		return result;
	}

}
