package com.java.core.concurrent.forkjoin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveTask;

public class CustomRecursiveTask extends RecursiveTask<Integer> {

	private int[] arr;
	private static final int THRESHOLD = 20;

	public CustomRecursiveTask(int[] arr) {
		this.arr = arr;
	}

	@Override
	protected Integer compute() {

		if (arr.length > THRESHOLD) {
			Integer sum = ForkJoinTask.invokeAll(createSubTasks())
				.stream()
				.mapToInt(ForkJoinTask::join)
				.sum();
			System.out.println("Sum of arr inside if" + Arrays.toString(arr) + " is " + sum);
			return sum;
		} else {
			Integer sum = processing(arr);
			System.out.println("Sum of arr inside else " + Arrays.toString(arr) + " is " + sum);
			return sum;
		}
	}

	private Collection<CustomRecursiveTask> createSubTasks() {
		List<CustomRecursiveTask> dividedTasks = new ArrayList<>();
		dividedTasks.add(
			new CustomRecursiveTask(Arrays.copyOfRange(arr, 0, arr.length / 2)));
		dividedTasks.add(
			new CustomRecursiveTask(Arrays.copyOfRange(arr, arr.length / 2, arr.length)));
		return dividedTasks;
	}

	private Integer processing(int[] arr) {
		return Arrays.stream(arr).filter(a -> a > 10 && a < 27)
			.map(a -> a * 10)
			.sum();
	}

	public static void main(String[] args) {
		int[] arr = {5,7,2,1,9,32,12,24,18,6,11,16,23,28,19,29,15,8,17,13,30,14,4};
		CustomRecursiveTask customRecursiveTask = new CustomRecursiveTask(arr);
		System.out.println(customRecursiveTask.compute());
	}
}
