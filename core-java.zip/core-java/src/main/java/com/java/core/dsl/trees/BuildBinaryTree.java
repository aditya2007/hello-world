package com.java.core.dsl.trees;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * https://articles.leetcode.com/construct-binary-tree-from-inorder-and-preorder-postorder-traversal/
 * https://bloggerplugnplay.blogspot.in/2012/11/construction-of-binary-tree-from.html
 *
 * Given preorder and inorder traversal of a tree, construct the binary tree.

 Note:
 You may assume that duplicates do not exist in the tree.

 For example, given

 preorder = [3,9,20,15,7]
 inorder = [9,3,15,20,7]
 Return the following binary tree:

  3
 / \
 9  20
   /  \
  15   7

 The basic idea is here:
 Say we have 2 arrays, PRE and IN.
 Preorder traversing implies that PRE[0] is the root node.
 Then we can find this PRE[0] in IN, say it’s IN[5].
 Now we know that IN[5] is root, so we know that IN[0] - IN[4] is on the left side,
 	IN[6] to the end is on the right side.
 Recursively doing this on subarrays, we can build a tree out of it :)
 */
public class BuildBinaryTree {

	/**
	 * https://leetcode.com/problems/construct-binary-tree-from-preorder-and-inorder-traversal/discuss/34538/My-Accepted-Java-Solution
	 */
	public TreeNode buildPreAndInOrderTree(int[] preOrder, int[] inOrder) {
		Map<Integer, Integer> inOrderMap = new HashMap<>();
		for (int i = 0; i < inOrder.length; i++) {
			inOrderMap.put(inOrder[i], i);
		}

		return buildPreAndInOrderTree(preOrder, 0,
							0, inOrder.length - 1, inOrderMap);
	}

	private TreeNode buildPreAndInOrderTree(int[] preOrder, int preStartIdx,
								int inStartIdx, int inEndIdx, Map<Integer, Integer> inOrderMap) {

		if (preStartIdx > preOrder.length - 1 || inStartIdx > inEndIdx) return null;

		TreeNode root = new TreeNode(preOrder[preStartIdx]);
		int inCurrIdx = inOrderMap.get(root.val);

		root.left = buildPreAndInOrderTree(preOrder, preStartIdx + 1,
								inStartIdx, inCurrIdx - 1, inOrderMap);
		root.right = buildPreAndInOrderTree(preOrder, preStartIdx + inCurrIdx - inStartIdx + 1,
								inCurrIdx + 1, inEndIdx, inOrderMap);
		return root;
	}

	public static void main(String[] args) {
		BuildBinaryTree buildTree = new BuildBinaryTree();
		int[] preOrder = {3,9,20,15,7};
		int[] inOrder = {9,3,15,20,7};
		int[] postOrder = {9,15,7,20,3};
		TreeNode preOrderRoot = buildTree.buildPreAndInOrderTree(preOrder, inOrder);
		System.out.println("Pre Order Tree ::: ");
		TreesUtil.printTree(preOrderRoot);
		TreeNode postOrderRoot = buildTree.buildTreePostAndInOrderTree(postOrder, inOrder);
		System.out.println("Post Order Tree ::: ");
		TreesUtil.printTree(postOrderRoot);
	}

	/**
	 *https://leetcode.com/problems/construct-binary-tree-from-inorder-and-postorder-traversal/discuss/34782/My-recursive-Java-code-with-O(n)-time-and-O(n)-space

	 */
	public TreeNode buildTreePostAndInOrderTree(int[] postOrder, int[] inOrder) {
		Map<Integer, Integer> inOrderMap = new HashMap<>();

		for (int i = 0; i < inOrder.length; i++) {
			inOrderMap.put(inOrder[i], i);
		}
		return buildTreePostAndInOrderTree(postOrder, 0, postOrder.length - 1,
													0, inOrder.length - 1, inOrderMap);
	}

	private TreeNode buildTreePostAndInOrderTree(int[] postOrder, int postStartIdx, int postEndIdx,
										int inStartIdx, int inEndIdx, Map<Integer, Integer> inOrderMap) {
		if (postStartIdx > postEndIdx || inStartIdx < inEndIdx) return null;

		TreeNode root = new TreeNode(postOrder[postEndIdx]);
		int inCurrIdx = inOrderMap.get(root.val);
		root.left = buildTreePostAndInOrderTree(postOrder, postStartIdx, (postStartIdx + inCurrIdx - inStartIdx - 1),
			inStartIdx, inCurrIdx  + 1, inOrderMap);
		root.right = buildTreePostAndInOrderTree(postOrder, (postStartIdx + inCurrIdx - inStartIdx),
											postEndIdx - 1, inCurrIdx + 1, inEndIdx, inOrderMap);
		return root;
	}

}
