package com.java.core.dsl.trees;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

import apple.laf.JRSUIUtils.Tree;

/**
 * https://leetcode.com/problems/serialize-and-deserialize-binary-tree/description/
 *
 * Serialization is the process of converting a data structure or object into a sequence of bits
 * so that it can be stored in a file or memory buffer, or transmitted across a network connection
 * link to be reconstructed later in the same or another computer environment.

 Design an algorithm to serialize and deserialize a binary tree.
 There is no restriction on how your serialization/deserialization algorithm should work.
 You just need to ensure that a binary tree can be serialized to a string
 and this string can be deserialized to the original tree structure.

 For example, you may serialize the following tree

    1
  /  \
 2    3
     / \
    4   5
 as "[1,2,3,null,null,4,5]"
 */
public class SerializeAndDeSerializeTree {

	private static final String DELIMITER = ",";
	private static final String NODE_NULL = "X";

	/**
	 * The idea is simple: print the tree in pre-order traversal and use “X” to denote null node
	 * and split node with “,”. We can use a StringBuilder for building the string on the fly.
	 * For deserializing, we use a Queue to store the pre-order traversal and since we have “X” as null node,
	 * we know exactly how to where to end building subtress.
	 *
	 */
	public static void main(String[] args) {
		SerializeAndDeSerializeTree szTree = new SerializeAndDeSerializeTree();
		TreeNode node1 = new TreeNode(1);
		TreeNode node2 = new TreeNode(2);
		TreeNode node3 = new TreeNode(3);
		TreeNode node4 = new TreeNode(4);
		TreeNode node5 = new TreeNode(5);

		node1.left = node2;
		node1.right = node3;
		node3.left = node4;
		node3.right = node5;

		TreesUtil.printTree(node1);
		String serializedData = szTree.serialize(node1);
		System.out.println(serializedData);
		TreeNode deSzNode = szTree.deserialize(serializedData);
		TreesUtil.printTree(deSzNode);
	}

	//Encodes a tree to a single String
	public String serialize(TreeNode root) {
		StringBuilder builder = new StringBuilder();
		buildString(root, builder);
		return builder.toString();
	}

	private void buildString(TreeNode node, StringBuilder builder) {
		if (node == null) {
			builder.append(NODE_NULL).append(DELIMITER);
		} else {
			builder.append(node.val).append(DELIMITER);
			buildString(node.left, builder);
			buildString(node.right, builder);
		}
	}

	//Decodes your encoded data to tree
	public TreeNode deserialize(String data) {
		Queue<String> nodes = new LinkedList<>();
		nodes.addAll(Arrays.asList(data.split(DELIMITER)));
		return buildTree(nodes);
	}

	private TreeNode buildTree(Queue<String> nodes) {
		String val = nodes.poll();
		if (val.equals(NODE_NULL)) {
			return null;
		} else {
			TreeNode node = new TreeNode(Integer.valueOf(val));
			node.left = buildTree(nodes);
			node.right = buildTree(nodes);
			return node;
		}
	}

}
