package com.java.core.dsl.queue.delayed;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

public class DelayedObject implements Delayed, Comparable<Delayed> {

	private String data;
	private long startTime;

	public DelayedObject(String data, long delayInMilliSec) {
		this.data = data;
		this.startTime = System.currentTimeMillis() + delayInMilliSec;
	}

	@Override
	public int compareTo(Delayed o) {
		long diff = this.startTime - ((DelayedObject) o).startTime;
		return (int) diff;
	}

	@Override
	public long getDelay(TimeUnit unit) {
		long elapsedTime = startTime - System.currentTimeMillis();
		return unit.convert(elapsedTime, TimeUnit.MILLISECONDS);
	}

	public String getData() {
		return data;
	}

	public long getStartTime() {
		return startTime;
	}
}
