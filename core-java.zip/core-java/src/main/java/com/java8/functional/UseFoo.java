package com.java8.functional;

import java.util.function.Function;

public class UseFoo {

	public String concat(String message, Foo foo) {
		return foo.append(message);
	}

	public String concat(String message, Function<String, String> fn) {
		return fn.apply(message);
	}

	public static void main(String[] args) {
		UseFoo useFoo = new UseFoo();

		//Custom Functional Interface
		Foo foo = parameter -> parameter + " from lambda";
		String customFunMsg = useFoo.concat("Custom Function", foo);
		System.out.println(customFunMsg);

		//Available Functional Interfaces from java.util.Function package
		Function<String, String> fn = p -> p + " from lambda";
		String avaFunMsg = useFoo.concat("Available Function", fn);
		System.out.println(avaFunMsg);
	}
}
