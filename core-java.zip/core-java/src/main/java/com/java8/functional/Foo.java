package com.java8.functional;

@FunctionalInterface
public interface Foo {
	String append(String message);

	//Just to verify the Functional interface can have other methods
	default String build() {
		return "test";
	}

	//Just to verify the Functional interface can have other methods
	static String getString() {
		return "test";
	}

	static Integer getInt() {
		return 1;
	}

}
