package com.com.sw.assignment;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import com.com.sw.assignment.model.Range;

public class ZipRange {
	private static List<Range> rangeList = new ArrayList<>();
	private List<Range> monatizedRanges = new ArrayList<>();

	public static void main(String[] args) {

		//input : [3,5] [10,13] [8,11] [15,19] [13,16]
		//output : [3,5] [8,19]
		Range a = new Range(3, 5);
		Range b = new Range(10, 13);
		Range c = new Range(8, 11);
		Range d = new Range(15, 19);
		Range e = new Range(13, 16);

		//input : [94133,94133] [94200,94299] [94600,94699]
		//output : [94133,94133] [94200,94299] [94600,94699]
		Range a1 = new Range(94133, 94133);
		Range b1 = new Range(94200, 94200);
		Range c1 = new Range(94600, 94699);

		//input : [94133,94133] [94200,94299] [94226,94399]
		//output : [94133,94133] [94200, 94399]
		Range a2 = new Range(94133, 94133);
		Range b2 = new Range(94200, 94299);
		Range c2 = new Range(94226, 94699);

		addRange(a);
		addRange(b);
		addRange(c);
		addRange(d);
		addRange(e);
		showRange() ;

		addRange(a1);
		addRange(b1);
		addRange(c1);
		showRange() ;

		addRange(a2);
		addRange(b2);
		addRange(c2);
		showRange() ;

	}

	public static synchronized void addRange(Range toAdd) {
		if(rangeList.size()==0)
			rangeList.add(toAdd);
		else {
			//Add new Range, if the range overlaps with existing range, merge them
			ListIterator<Range> iter = rangeList.listIterator();
			boolean add = true; //flag
			while( iter.hasNext()) {
				Range range = iter.next();
				//new range within existing range, no need to add
				if(range.getLower()<=toAdd.getLower() && range.getUpper()>=toAdd.getUpper()) {
					add = false;
				}
				//new range is out of existing range, add it
				else if(range.getLower()>toAdd.getUpper() || range.getUpper()<toAdd.getLower()) {
					add = true;
				}
				//Range overlaps, remove existing, update toAdd
				else {
					if(range.getLower()<toAdd.getLower())
						toAdd.setLower(range.getLower());
					if(range.getUpper()>toAdd.getUpper())
						toAdd.setUpper(range.getUpper());
					iter.remove();
					add = true;
				}
			}//end of while
			if(add)
				rangeList.add(toAdd);
		}//end of else
	}

	public List<Range> monatizeZipRanges(List<Range> ranges) {
		for (Range range : ranges) {
			monatize(range);
		}
		return monatizedRanges;
	}
	private synchronized void monatize(Range currRange) {
		if(monatizedRanges.size()==0)
			monatizedRanges.add(currRange);
		else {
			//Add new Range, if the range overlaps with existing range, merge them
			Iterator<Range> iterator = monatizedRanges.listIterator();
			boolean canMonatize = false;
			while( iterator.hasNext()) {
				Range prevRange = iterator.next();
				//new range within existing range, no need to add
				if(prevRange.getLower() <= currRange.getLower() && prevRange.getUpper() >= currRange.getUpper()) {
					canMonatize = false;
				}
				//new range is out of existing range, add it
				else if(prevRange.getLower() > currRange.getUpper() || prevRange.getUpper() < currRange.getLower()) {
					canMonatize = true;
				}
				//Range overlaps, remove existing, update toAdd
				else {
					if(prevRange.getLower() < currRange.getLower())
						currRange.setLower(prevRange.getLower());
					if(prevRange.getUpper() > currRange.getUpper())
						currRange.setUpper(prevRange.getUpper());
					iterator.remove();
					canMonatize = true;
				}
			}//end of while
			if (canMonatize)
				monatizedRanges.add(currRange);
		}//end of else

	}

	public static void showRange() {
		/*if(rangeList.size()>0) {
			for(Range range :rangeList) {
				System.out.println(range.toString());
			}
		}*/
		System.out.println(rangeList);
		clear();
	}

	public static int size() {
		return rangeList.size();
	}

	public static List<Range> getZipRanges() {
		return rangeList;
	}


	public static void clear() {
		rangeList.clear();
	}
}
