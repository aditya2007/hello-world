# APM Datasource

Given a Tenant ID it provides database connection.

**Version : 0.0.1-SNAPSHOT** 

**Features**
- Supports tenant specific datasource configuration using application properties or environment variables

**Prerequisite**
- Default datasource configuration using "spring.datasource" must exists

**Notes**
- Datasource lookup precedence is Environment variables specific datasource and then the Default datasource

**Usage**
1. Include this project as a dependency for your Spring Boot application.
2. Include "com.ge.apm.datasource" in your component scan path. 
3. Configure your default datasource based on the version of your spring-boot.
   - This project uses spring-boot 1.2.3.RELEASE. Its datasource configuration is documented at https://docs.spring.io/spring-boot/docs/1.2.3.RELEASE/reference/html/common-application-properties.html.
     - All the datasource settings are configured via properties prefixed with "spring.datasource".     
   - The spring version can be overridden by your main project pom. For spring boot 1.5.x:
     - The general datasource settings are configured via properties prefixed with "spring.datasource".
     - The tomcat connection pool settings are configured via properties prefixed with "spring.datasource.tomcat".
4. This implementation has a very basic mechanism for configuring the datasource for a specific tenant based on application properties or environment variables.
   - The connection URL is set via the property "DATABASE_{tenantId}\_URL", where dash can be replaced by underscore in the tenant id.
   - The username can be set separately from the URL via the property "DATABASE_{tenantId}_USERNAME".
   - The password can be set separately from the URL via the property "DATABASE_{tenantId}_PASSWORD".
   - The other settings are copied from those of the default datasource.
         
**Version : 1.0.0.RELEASE**

**Features**
- Supports tenant specific datasource configuration using TMS API

**Notes**
- Datasource lookup precedence is TMS and then Environment variables specific datasource and then the Default datasource
- Tenant specific Database should be configured in TMS using API
https://devcloud.swcoe.ge.com/devspace/display/RMOCM/TMS+-+Tenant+Service+Instances#TMS-TenantServiceInstances-AddingexistingserviceinstancesinTMSDB
- This project use TMS API to get Postgres Service instance details for all tenants
  https://devcloud.swcoe.ge.com/devspace/display/RMOCM/TMS+-+Tenant+Service+Instances#TMS-TenantServiceInstances-GETAPI-Gettingserviceinstancedetailsofalltenant 
- This project use TMS API to Tenant specific database credentials
  https://devcloud.swcoe.ge.com/devspace/display/RMOCM/TMS+-+Tenant+Service+Instances#TMS-TenantServiceInstances-GETAPI-Gettingserviceinstancesforatenant 
- This project use UAA API to obtain an OAuth2 token using client credentials grant using Application Client Id which must have these scopes/authorities configured
  - stuf.\<instanceUuid>.zone
  - stuf.read
  - stuf.app.\<origin-name>
- This project uses spring-boot 1.5.7.RELEASE

**Usage**

Every Application must obtain its unique OAuth2 Client ID / Secret with following scopes:
 - stuf.app.\<origin-name>
 - stuf.read
 - stuf.\<stuf-instance-id>.stuf
 
 These scopes comma separated must be configured in app.scope property as mentioned below.
 
 1. Must configure the followings in your application properties or environment variables
      - app.client.id = 
      - app.client.secret =
      - app.scope = stuf.app.<origin-name>,stuf.read,stuf.${stuf.zone.id}.zone
      - stuf.zone.id = 
      - stuf.uaaUrl =
      - stuf.tenantServiceUrl =
 2. Create a RestTemplate Spring Bean   
 

***Disable TMS*** 
- During the local development TMS can be disabled by setting in application properties disable.tms=true or environment variables -Ddisable.tms=true

**Version : 1.0.1.RELEASE**

A bug fix to mask the database url and username

**Version : 1.0.2.RELEASE**

The com.ge.apm.datasource.impl.TenantDataSource flush(String tenantId) method access level is made public 