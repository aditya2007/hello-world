/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.datasource.impl;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.StreamSupport;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Slf4j
@Component
public class EnvTenantDataSourceLookup {

    public Set<String> getTenants() {
        return cache.keySet();
    }

    private static final String CONFIG_PREFIX = "DATABASE_";

    private static final String DEFAULT_DATABASE = "DATABASE_URL";

    private static final String CONFIG_URL = "_URL";

    private static final String CONFIG_USERNAME = "_USERNAME";

    private static final String CONFIG_PASS = "_PASSWORD";

    private final Map<String, TenantDataSourceInfo> cache = new ConcurrentHashMap<>();

    private final ConfigurableEnvironment environment;

    @Autowired
    protected EnvTenantDataSourceLookup(ConfigurableEnvironment environment) {
        this.environment = environment;
        initLookup();
    }

    TenantDataSourceInfo lookup(String tenantId) {
        return cache.get(tenantId);
    }

    Map<String, TenantDataSourceInfo> getTenantDataSources() {
        return cache;
    }

    private void initLookup() {
        MutablePropertySources propSrcs = environment.getPropertySources();
        StreamSupport.stream(propSrcs.spliterator(), false).filter(ps -> ps instanceof EnumerablePropertySource).map(
            ps -> ((EnumerablePropertySource) ps).getPropertyNames()).flatMap(Arrays::<String>stream).forEach(
            this::addTenantDatabaseFromProperty);
    }

    private void addTenantDatabaseFromProperty(String property) {
        if (property.compareTo(DEFAULT_DATABASE) != 0 && property.startsWith(CONFIG_PREFIX) && property.endsWith(
            CONFIG_URL)) {
            String url = environment.getProperty(property);
            if (StringUtils.isEmpty(url)) {
                return;
            }

            String tenant = property.substring(CONFIG_PREFIX.length());
            tenant = tenant.substring(0, tenant.length() - CONFIG_URL.length());
            log.info("environment variable configuration found for tenant:{}", tenant);
            if (StringUtils.isEmpty(tenant)) {
                return;
            }

            String keyPrefix = CONFIG_PREFIX + tenant;
            TenantDataSourceInfo info = new TenantDataSourceInfo(tenant, url,
                environment.getProperty(keyPrefix + CONFIG_USERNAME), environment.getProperty(keyPrefix + CONFIG_PASS));

            cache.put(tenant.replace('_', '-'), info);
        }
    }
}
