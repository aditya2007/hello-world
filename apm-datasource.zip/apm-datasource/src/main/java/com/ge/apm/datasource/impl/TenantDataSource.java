/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.datasource.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.StreamSupport;

import com.google.common.base.CaseFormat;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.endpoint.PublicMetrics;
import org.springframework.boot.actuate.metrics.Metric;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.stereotype.Component;

import com.ge.apm.common.support.RequestContext;
import com.ge.apm.datasource.ConnectionException;
import com.ge.apm.datasource.TenantDataSourceService;

@Component
@Primary
@Slf4j
public class TenantDataSource extends AbstractRoutingDataSource implements PublicMetrics {

    private final DataSource defaultDataSource;

    private static final Map<String, DataSource> cache = new ConcurrentHashMap<>();

    private final EnvTenantDataSourceLookup envTenantDataSourceLookup;

    private final TmsTenantDataSourceLookup tmsDataSourceLookup;

    private final ConfigurableEnvironment environment;

    private static final String TENANT_SPRING_DATASOURCE_CONFIG = ".spring.datasource.";

    private static final Map<String, PoolProperties> tenantDataSourceConfig = new HashMap<>();

    @Value("${disable.tms:false}")
    private boolean disableTms;

    @Autowired
    protected TenantDataSource(@Qualifier("defaultDataSource") DataSource defaultDataSource,
        EnvTenantDataSourceLookup envTenantDataSourceLookup, TmsTenantDataSourceLookup tmsDataSourceLookup,
        ConfigurableEnvironment environment) {
        log.info("Configured default datasource {}", printDataSource(defaultDataSource.toString()));
        this.defaultDataSource = defaultDataSource;
        this.envTenantDataSourceLookup = envTenantDataSourceLookup;
        this.tmsDataSourceLookup = tmsDataSourceLookup;
        this.environment = environment;
        initLookup();
    }

    @Override
    public void afterPropertiesSet() {
        setDefaultTargetDataSource(defaultDataSource);
        setTargetDataSources(new HashMap<>());
        super.afterPropertiesSet();
    }

    @Override
    protected DataSource determineTargetDataSource() {
        final String tenantId = determineCurrentLookupKey();

        String message = "Provided DB Connection Tenant={} Database={}";
        if (tenantId == null) {
            log.trace(message, tenantId, defaultDataSource.getUrl());
            return defaultDataSource;
        }

        // if tenant id is default datasource then return default datasource
        if (StringUtils.equalsIgnoreCase(TenantDataSourceService.DEFAULT_DATASOURCE, tenantId)) {
            return defaultDataSource;
        }

        //Old tenantId format which is not a UUID also need to be supported
        // if not UUID
        // if (!isUUID(tenantId)) {
        //     String msg = String.format("Tenant Id %s must be UUID", tenantId);
        //     throw new ConnectionException(msg, new IllegalArgumentException(msg));
        // }

        // check cache
        DataSource dataSource = cache.get(tenantId);
        if (dataSource != null) {
            log.trace(message, tenantId, dataSource.getUrl());
            return dataSource;
        }

        // not in cache
        // there is scope to synchronize multiple requests for the same tenant id such that
        // When multiple thread for the same Tenant request for its Data Source concurrently it will result in
        // multiple remote calls to TMS to fetch the tenant datasource details
        TenantDataSourceInfo info;
        if (disableTms) {
            log.warn("TMS is disabled with property disable.tms=true");
            log.info("Looking up datasource for Tenant={} in Environment Variables", tenantId);
            // lookup environment variables
            info = envTenantDataSourceLookup.lookup(tenantId);
            if (info == null) {
                log.info(
                    "Datasource for Tenant={} not found in Environment Variables defaulting to default " + "datasource",
                    tenantId);
                // default to default datasource
                dataSource = defaultDataSource;
            } else {
                log.info("Datasource={} for Tenant={} found in Environment Variables", tenantId, info.getUrl());
                // initialize the environment variables datasource
                dataSource = initializeDataSource(tenantId, info);
            }
        } else {
            log.info("Looking up datasource for Tenant={} in Environment Variables", tenantId);
            // lookup environment variables
            info = envTenantDataSourceLookup.lookup(tenantId);
            if (info == null) {
                log.info("Datasource for Tenant={} not found in Environment Variables", tenantId);
                log.info("Looking up datasource for Tenant={} in TMS", tenantId);
                // lookup TMS
                info = tmsDataSourceLookup.lookup(tenantId);
                if (info == null) {
                    log.info("Datasource for Tenant={} not found in TMS defaulting to default " + "datasource",
                        tenantId);
                    // default to default datasource
                    dataSource = defaultDataSource;
                } else {
                    log.info("Datasource={} for Tenant={} found in TMS", tenantId, info.getUrl());
                    // initialize the environment variables datasource
                    dataSource = initializeDataSource(tenantId, info);
                }
            } else {
                log.info("Datasource={} for Tenant={} found in Environment Variables", tenantId, info.getUrl());
                // initialize TMS datasource
                dataSource = initializeDataSource(tenantId, info);
            }
        }

        cache.putIfAbsent(tenantId, dataSource);

        log.trace(message, tenantId, dataSource.getUrl());
        return dataSource;
    }

    @Override
    protected String determineCurrentLookupKey() {
        return (String) RequestContext.get(RequestContext.TENANT_UUID);
    }

    private DataSource initializeDataSource(String tenantId, TenantDataSourceInfo info) {

        // no need to be synchronized before putting into cache
        PoolProperties poolProperties = new PoolProperties();
        TomcatDataSourceUtil.copy((PoolProperties) defaultDataSource.getPoolProperties(), poolProperties);
        if (tenantDataSourceConfig.containsKey(tenantId)) {
            TomcatDataSourceUtil.copy(tenantDataSourceConfig.get(tenantId), poolProperties);
        }
        DataSource dataSource = new DataSource(poolProperties);
        TomcatDataSourceUtil.resetConnectionInfo(dataSource, getUrl(info), info.getUsername(), info.getPassword());

        log.info("Configured tenant:{} datasource:{}", tenantId, printDataSource(dataSource.toString()));

        return dataSource;
    }

    private String getUrl(TenantDataSourceInfo info) {
        StringBuilder url = new StringBuilder(info.getUrl());
        if (defaultDataSource.getDbProperties() != null && !defaultDataSource.getDbProperties().isEmpty()) {
            if (!StringUtils.contains(url.toString(), "?")) {
                url.append("?");
            } else {
                url.append("&");
            }
            defaultDataSource.getDbProperties().forEach((k, v) -> {
                if (!StringUtils.equalsIgnoreCase(k.toString(), "user") && !StringUtils.equalsIgnoreCase(k.toString(),
                    "password")) {
                    url.append(k).append("=").append(v).append(",");
                }
            });
            url.deleteCharAt(url.length() - 1);
        }
        return url.toString();
    }

    @Override
    public Collection<Metric<?>> metrics() {
        ArrayList<Metric<?>> data = new ArrayList<>();
        cache.forEach((k, v) -> {
            // The number of active connections (datasource.xxx.active)
            data.add(new Metric<Number>("datasource." + k + ".active", v.getNumActive()));
            // The current usage of the connection pool (datasource.xxx.usage)
            data.add(new Metric<Number>("datasource." + k + ".usage", getUsage(v)));
        });
        return data;
    }

    /**
     * Refer
     * org.springframework.boot.actuate.endpoint.DataSourcePublicMetrics
     * org.springframework.boot.autoconfigure.jdbc.metadata.AbstractDataSourcePoolMetadata
     */
    private Float getUsage(DataSource ds) {
        Integer maxSize = ds.getMaxActive();
        Integer currentSize = ds.getActive();
        return maxSize != null && currentSize != null ? (maxSize.intValue() < 0 ? Float.valueOf(-1.0F)
            : (currentSize.intValue() == 0 ? Float.valueOf(0.0F) : Float.valueOf(
                (float) currentSize.intValue() / (float) maxSize.intValue()))) : null;
    }

    private boolean isUUID(String input) {
        try {
            UUID.fromString(input);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    private void initLookup() {
        MutablePropertySources propSrcs = environment.getPropertySources();
        StreamSupport.stream(propSrcs.spliterator(), false).filter(ps -> ps instanceof EnumerablePropertySource).map(
            ps -> ((EnumerablePropertySource) ps).getPropertyNames()).flatMap(Arrays::<String>stream).forEach(
            this::addTenantDatabaseFromProperty);
        log.info("Environment variables datasource configuration");
        tenantDataSourceConfig.forEach(
            (k, v) -> log.info("tenantId={} configuration={}", k, printDataSource(v.toString())));
    }

    private void addTenantDatabaseFromProperty(String property) {
        if (property.contains(TENANT_SPRING_DATASOURCE_CONFIG)) {
            String tenantId = property.substring(0, property.indexOf(TENANT_SPRING_DATASOURCE_CONFIG));
            if (!tenantDataSourceConfig.containsKey(tenantId)) {
                tenantDataSourceConfig.put(tenantId, new PoolProperties());
                TomcatDataSourceUtil.copy((PoolProperties) defaultDataSource.getPoolProperties(),
                    tenantDataSourceConfig.get(tenantId));
            }
            PoolProperties poolProperties = tenantDataSourceConfig.get(tenantId);
            String key = StringUtils.substringAfterLast(property, TENANT_SPRING_DATASOURCE_CONFIG);
            String value = environment.getProperty(property);
            try {
                if (StringUtils.contains(key, "-")) {
                    key = CaseFormat.LOWER_HYPHEN.to(CaseFormat.LOWER_CAMEL, key);
                }
                BeanUtils.setProperty(poolProperties, key, value);
            } catch (Exception e) {
                String message = String.format(
                    "Error in setting Tenant:%s specific database configuration property key:%s value:%s", tenantId,
                    key, value);
                log.error(message, e);
                throw new ConnectionException(message, e);
            }
        }
    }

    void flush() {
        cache.clear();
    }

    public void flush(String tenantId) {
        cache.remove(tenantId);
        log.info("The datasource for tenantId = {} is evicted from Cache.", tenantId);
    }

    private String printDataSource(final String ds) {
        return ds.replaceFirst("(?<=username=)(.*?);", "********;");
    }
}
