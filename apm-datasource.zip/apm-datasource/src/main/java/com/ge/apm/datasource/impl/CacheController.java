/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.datasource.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class CacheController {

    private final TenantDataSource tenantDataSource;

    private final TmsTenantDataSourceLookup tmsDataSourceLookup;

    @Value("${flush.cache.enabled: false}")
    private boolean flushCacheEnabled;

    @Autowired
    protected CacheController(TenantDataSource tenantDataSource, TmsTenantDataSourceLookup tmsDataSourceLookup) {
        this.tenantDataSource = tenantDataSource;
        this.tmsDataSourceLookup = tmsDataSourceLookup;
    }

    public static final String ERR_MESSAGE_1
        = "Flush cache for Tenant {}, but flush.cache.enabled is configured to false throwing Forbidden error";

    @PostMapping("/dbCredentialsCache/flush/{tenantId}")
    public ResponseEntity flush(@PathVariable("tenantId") String tenantId) {
        if (!flushCacheEnabled) {
            log.error(ERR_MESSAGE_1, tenantId);
            return new ResponseEntity(HttpStatus.FORBIDDEN);
        }
        log.info("Flushed cache for Tenant {}", tenantId);
        tenantDataSource.flush(tenantId);
        tmsDataSourceLookup.flush(tenantId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @PostMapping("/dbCredentialsCache/flushAll")
    public ResponseEntity flushAll() {
        if (!flushCacheEnabled) {
            log.error(ERR_MESSAGE_1);
            return new ResponseEntity(HttpStatus.FORBIDDEN);
        }
        log.info("Flushed all cache");
        tenantDataSource.flush();
        tmsDataSourceLookup.flush();
        return new ResponseEntity(HttpStatus.OK);
    }
}
