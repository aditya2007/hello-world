/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.datasource.impl;

import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.NullNode;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.ge.apm.datasource.ConnectionException;

/**
 * This implementation look up the tenant database from the Predix Platform TMS Service
 */

@Slf4j
@Component
class TmsTenantDataSourceLookup {

    @Autowired
    TmsTenantDataSourceLookup(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    /**
     * Returns IDs of the tenants that have dedicated database configured <p> The usage pattern is
     * mostly application call this on startup to initialize the tenant databases <p> Hence this
     * method cache the data obtained from the TMS to avoid calls to TMS on subsequent invocation
     *
     * @return IDs of the tenants that have dedicated database configured
     */
    Set<String> getTenants() {
        if (cacheInitialized) {
            return cache.keySet();
        } else {
            try {
                writeLock.lock();
                if (!cacheInitialized) { //NOSONAR
                    Set<TenantDataSourceInfo> set = getDatabases();
                    set.forEach(e -> cache.computeIfAbsent(e.getTenantId(), k -> e));
                }
            } finally {
                if (!cacheInitialized) {
                    cacheInitialized = true;
                }
                writeLock.unlock();
            }
            return cache.keySet();
        }
    }

    /**
     * Returns the tenant dedicated database credentials if exists otherwise null Look up in the
     * cache if does not exists get from the TMS and cache it
     *
     * @return <code>TenantDataSourceInfo</code>
     */
    TenantDataSourceInfo lookup(String tenantId) {
        TenantDataSourceInfo temp = cache.get(tenantId);
        if (temp == null) {
            temp = getTenantDatabase(tenantId);
            if (temp != null) {
                TenantDataSourceInfo value = temp;
                cache.computeIfAbsent(tenantId, k -> value);
            }
        }
        return temp;
    }

    @Value("${app.client.id}")
    private String appClientId;

    @Value("${app.client.secret}")
    private String appClientSecret;

    @Value("${app.scope}")
    private String appScope;

    @Value("${stuf.uaaUrl}")
    private String stufUaaUrl;

    @Value("${stuf.tenantServiceUrl}")
    private String stufTenantServiceUrl;

    @Value("${canonicalServiceName:postgres}")
    private String canonicalServiceName;

    private final RestTemplate restTemplate;

    private boolean cacheInitialized = false;

    private final Map<String, TenantDataSourceInfo> cache = new ConcurrentHashMap<>();

    private final Lock writeLock = new ReentrantReadWriteLock().writeLock();

    private static final String CREDENTIALS = "credentials";

    private static final String AUTHORIZATION = "Authorization";

    private static final String ERROR_IN_JSON_PARSING = "Error in JSON parsing";

    public static final String CALLING_WEB_SERVICE = "Calling Web Service {}";

    @PostConstruct
    private void init() {
        stufUaaUrl += "/oauth/token";
    }

    private String getToken() {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.add(AUTHORIZATION,
            "Basic " + Base64.getEncoder()
                .encodeToString((appClientId + ":" + appClientSecret).getBytes()));

        HttpEntity<String> request = new HttpEntity<>(
            "grant_type=client_credentials&scope=" + appScope, headers);

        ResponseEntity<String> response = null;
        StopWatch stopWatch = new StopWatch("POST " + stufUaaUrl);
        try {
            stopWatch.start();
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode;
            try {
                log.info(CALLING_WEB_SERVICE, stopWatch.getId());
                response = restTemplate.exchange(stufUaaUrl, HttpMethod.POST, request,
                    String.class);
                rootNode = objectMapper.readTree(response.getBody());
            } catch (HttpStatusCodeException excp) {
                String errorMsg = String.format("Error in getting App Token using "
                        + "client-credentials grant from UAA=%s, Error: %s", stufUaaUrl,
                    excp.getResponseBodyAsString());
                log.error(errorMsg, excp);
                throw new ConnectionException(errorMsg, excp);
            } catch (JsonProcessingException jsonex) {
                log.error("Parsing Error in getting token", jsonex);
                throw new ConnectionException(ERROR_IN_JSON_PARSING, jsonex);
            } catch (Exception ex) {
                log.error("Error in getting token", ex);
                throw new ConnectionException("Error in getting token ", ex);
            }
            return rootNode.path("access_token").asText();
        } finally {
            stopWatch.stop();
            log.info(stopWatch.toString());
        }
    }

    private Set<TenantDataSourceInfo> getDatabases() {

        Set<TenantDataSourceInfo> result = new HashSet<>();
        String token = getToken();
        String url =
            stufTenantServiceUrl + "/v1/serviceinstances/" + canonicalServiceName + "?offset=0";
        String next = "";
        String response;
        while (next != null) {
            response = getDatabases(url, token);
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode;
            try {
                rootNode = objectMapper.readTree(response);
            } catch (Exception excp) {
                throw new ConnectionException(ERROR_IN_JSON_PARSING, excp);
            }
            ArrayNode array = (ArrayNode) rootNode.path("dataObject");
            TenantDataSourceInfo item;

            for (int index = 0; index < array.size(); index++) {
                item = new TenantDataSourceInfo(array.get(index).path("tenantUuid").asText(),
                    getJdbcURL(array.get(index).path(CREDENTIALS)), array.get(index).path(
                    CREDENTIALS).path("username")
                    .asText(), array.get(index).path(CREDENTIALS).path("password").asText());
                result.add(item);
            }
            if (rootNode.path("next") instanceof NullNode) {
                next = null;
            } else {
                next = rootNode.path("next").toString();
            }
            if (next != null) {
                if (StringUtils.isBlank(next) || StringUtils.equalsIgnoreCase(next, "0")) {
                    next = null;
                } else {
                    url = stufTenantServiceUrl + "/v1/serviceinstances/" + canonicalServiceName
                        + "?offset=" + next;
                }
            }
        }

        return result;
    }

    /**
     * This function make the JDBC URL it as per the specifications https://jdbc.postgresql
     * .org/documentation/head/connect.html
     */
    private String getJdbcURL(JsonNode jsonNode) {
        StringBuilder jdbcUrl = new StringBuilder();
        jdbcUrl.append("jdbc:postgresql://").append(jsonNode.path("hostname").asText());
        jdbcUrl.append(":").append(jsonNode.path("port").asText());
        jdbcUrl.append("/").append(jsonNode.path("database").asText());
        return jdbcUrl.toString();
    }

    private String getDatabases(String url, String token) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.add(AUTHORIZATION, "Bearer " + token);

        HttpEntity<HashMap> request = new HttpEntity<>(headers);

        ResponseEntity<String> response;
        StopWatch stopWatch = new StopWatch("GET " + url);
        try {
            stopWatch.start();
            log.info(CALLING_WEB_SERVICE, stopWatch.getId());
            response = restTemplate.exchange(url, HttpMethod.GET, request, String.class);
        } catch (Exception excp) {
            throw new ConnectionException(
                String.format(
                    "Error in getting all Tenants with dedicated database credentials url=%s", url),
                excp);
        } finally {
            stopWatch.stop();
            log.info(stopWatch.toString());
        }

        if (!response.getStatusCode().equals(HttpStatus.OK)) {
            throw new ConnectionException(String
                .format(
                    "Error in getting all Tenants with dedicated database credentials url=%s "
                        + "status=%s",
                    url,
                    response.getStatusCode()));
        }

        return response.getBody();
    }

    private TenantDataSourceInfo getTenantDatabase(String tenantId) {

        String token = getToken();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.add(AUTHORIZATION, "Bearer " + token);

        HttpEntity<HashMap> request = new HttpEntity<>(headers);

        String url = stufTenantServiceUrl + "/v1/tenants/" + tenantId + "/serviceinstances/"
            + canonicalServiceName;
        ResponseEntity<String> response;
        StopWatch stopWatch = new StopWatch("GET " + url);
        int status = 0;
        try {
            stopWatch.start();
            log.info(CALLING_WEB_SERVICE, stopWatch.getId());
            response = restTemplate.exchange(url, HttpMethod.GET, request, String.class);
            status = response.getStatusCodeValue();
        } catch (HttpClientErrorException excp) {
            if (excp.getStatusCode().equals(HttpStatus.NOT_FOUND)) {
                status = HttpStatus.NOT_FOUND.value();
                log.info("Tenant={} does not have a dedicated database, so using default database",
                    tenantId);
                return null;
            }
            log.error("Error in making REST call to TMS", excp);
            throw excp;
        } catch (Exception excp) {
            throw new ConnectionException(
                String.format("Error in getting Tenant=%s Service=%s credentials", tenantId,
                    canonicalServiceName),
                excp);
        } finally {
            stopWatch.stop();
            log.info(stopWatch.toString() + " response status={}", status);
        }

        if (response.getStatusCode().equals(HttpStatus.OK)) {

            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode;
            try {
                rootNode = objectMapper.readTree(response.getBody());
            } catch (Exception excp) {
                throw new ConnectionException(ERROR_IN_JSON_PARSING, excp);
            }

            return new TenantDataSourceInfo(rootNode.path("uuid").asText(),
                getJdbcURL(rootNode.path(CREDENTIALS)),
                rootNode.path(CREDENTIALS).path("username").asText(), rootNode.path(CREDENTIALS)
                .path("password").asText());
        } else {
            throw new ConnectionException(String
                .format("Error in getting Tenant=%s database credentials url=%s status=%s",
                    tenantId, url,
                    response.getStatusCode()));
        }
    }

    void flush() {
        cache.clear();
        cacheInitialized = false;
    }

    void flush(String tenantId) {
        cache.remove(tenantId);
    }
}
