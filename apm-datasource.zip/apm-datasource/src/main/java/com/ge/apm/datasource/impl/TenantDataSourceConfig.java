/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.datasource.impl;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.CloudFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.Ordered;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

/**
 * Configuration to support database per tenant.
 *
 * The application using this should exclude DataSourceAutoConfiguration.class from
 * SpringBootApplication and @EnableAutoConfiguration.
 */
@Slf4j
public class TenantDataSourceConfig {

    private TenantDataSourceConfig() {
    }

    @Configuration
    @Profile("!cloud")
    @PropertySource("classpath:tenant-datasource.properties")
    protected static class LocalDataSourceConfig {

        @ConfigurationProperties(prefix = "spring.datasource")
        @Bean
        public DataSource defaultDataSource() {
            log.info("Setting up non-cloud data source");
            return (DataSource) DataSourceBuilder.create().build();
        }
    }

    @Configuration
    @Profile("cloud")
    @Getter(AccessLevel.PACKAGE)
    @PropertySource("classpath:tenant-datasource.properties")
    protected static class CloudDataSourceConfig {

        private String url;

        private String username;

        private String password;

        private DataSource dataSource;

        public String getUrl() {
            return url;
        }

        public String getUsername() {
            return username;
        }

        public String getPassword() {
            return password;
        }

        public DataSource getDataSource() {
            return dataSource;
        }

        @Bean
        @ConfigurationProperties("spring.datasource")
        public DataSource defaultDataSource(CloudFactory cloudFactory) {
            // see https://dzone.com/articles/binding-data-services-spring
            // but its first example would make datasource working while breaking auto-configuration
            // for redis etc.

            log.info("Setting up cloud data source");
            dataSource = (DataSource) cloudFactory.getCloud().getSingletonServiceConnector(
                javax.sql.DataSource.class, null);
            log.info("Spring cloud got data source: {}", dataSource);

            // remember the info to be restored later as the use of
            // @ConfigurationProperties("spring.datasource") will make properties defined
            // in application.properties to override.
            url = dataSource.getUrl();
            username = dataSource.getUsername();
            password = dataSource.getPassword();

            return dataSource;
        }

        @Bean
        public BeanPostProcessor defaultDataSourceBinder() {
            return new CloudDataSourceRebinder(this);
        }
    }

    @Configuration
    protected static class DataSourceSupportConfig {

        @Bean
        @Primary
        JdbcTemplate jdbcTemplate(TenantDataSource dataSource) {
            return new JdbcTemplate(dataSource);
        }

        @Bean
        @Primary
        NamedParameterJdbcTemplate namedParameterJdbcTemplate(TenantDataSource dataSource) {
            return new NamedParameterJdbcTemplate(dataSource);
        }
    }

    private static class CloudDataSourceRebinder implements BeanPostProcessor, Ordered {

        private final CloudDataSourceConfig config;

        private CloudDataSourceRebinder(CloudDataSourceConfig config) {
            this.config = config;
        }

        @Override
        public Object postProcessBeforeInitialization(Object bean, String beanName) {
            return bean;
        }

        @Override
        public Object postProcessAfterInitialization(Object bean, String beanName) {

            DataSource dataSource = config.getDataSource();
            if (bean != null && bean == dataSource) {
                TomcatDataSourceUtil.resetConnectionInfo(dataSource, config.getUrl(),
                    config.getUsername(), config.getPassword());
            }

            return bean;
        }

        @Override
        public int getOrder() {
            return Ordered.LOWEST_PRECEDENCE;
        }
    }
}
