/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.datasource.impl;

import java.util.HashSet;
import java.util.Set;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.apm.datasource.TenantDataSourceService;

@Slf4j
@Component
public class TenantDataSourceServiceImpl implements TenantDataSourceService {

    private final EnvTenantDataSourceLookup envTenantDataSourceLookup;

    private final TmsTenantDataSourceLookup tmsDataSourceLookup;

    @Value("${disable.tms:false}")
    private boolean disableTms;

    @Autowired
    protected TenantDataSourceServiceImpl(EnvTenantDataSourceLookup envTenantDataSourceLookup,
        TmsTenantDataSourceLookup tmsDataSourceLookup) {
        this.envTenantDataSourceLookup = envTenantDataSourceLookup;
        this.tmsDataSourceLookup = tmsDataSourceLookup;
    }

    @Override
    public Set<String> getTenantsOfDatabase() {
        return getTenants();
    }

    @Override
    public Set<String> getTenants() {
        Set<String> result = new HashSet<>();
        if (disableTms) {
            log.warn("TMS is disabled with property disable.tms=true");
            result.addAll(envTenantDataSourceLookup.getTenants());
        } else {
            result.addAll(tmsDataSourceLookup.getTenants());
            result.addAll(envTenantDataSourceLookup.getTenants());
        }

        return result;
    }
}
