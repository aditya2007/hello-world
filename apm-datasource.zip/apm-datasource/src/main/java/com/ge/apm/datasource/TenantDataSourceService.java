/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.datasource;

import java.util.Set;

public interface TenantDataSourceService {

    /**
     * If default datasource connection is required then set this constant explicitly
     * <p>
     * For ex: RequestContext.put(RequestContext.TENANT_UUID, TenantDataSourceService.DEFAULT_DATASOURCE);
     */
    String DEFAULT_DATASOURCE = "default_datasource";

    /**
     * @deprecated use {@link #getTenants()} instead.
     *
     * @return Tenant IDs of the tenants that has dedicated databases
     */
    @Deprecated
    Set<String> getTenantsOfDatabase();

    /**
     * Returns IDs of the tenants that have dedicated database configured
     *
     * @return IDs of the tenants that have dedicated database configured
     */
    Set<String> getTenants();
}
