/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.datasource.impl;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolProperties;
import org.springframework.beans.BeanUtils;

interface TomcatDataSourceUtil {

    static void resetConnectionInfo(DataSource dataSource, String url, String username, String password) {

        dataSource.getDbProperties().remove("user");
        try {
            dataSource.setUsername(username);
        } catch (NullPointerException nullKey) {
            // ignore
        }

        dataSource.getDbProperties().remove("password");
        try {
            dataSource.setPassword(password);
        } catch (NullPointerException nullKey) {
            // ignore
        }

        dataSource.setUrl(url);
    }

    static void copy(PoolProperties source, PoolProperties target) {
        BeanUtils.copyProperties(source, target, "dbProperties");
        target.getDbProperties().putAll(source.getDbProperties());
    }
}
