package com.ge.apm.datasource.impl;

import java.lang.reflect.Field;
import java.util.Map;
import javax.sql.DataSource;

import com.jayway.restassured.RestAssured;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ReflectionUtils;

import com.ge.apm.common.support.RequestContext;
import com.ge.apm.datasource.TenantDataSourceService;
import com.ge.apm.datasource.TestApp;

import static com.jayway.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = TestApp.class)
@Profile("test")
@ActiveProfiles("test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DatabasesTest {

    @Value("${local.server.port}")
    protected int port;

    @Value("${stuf.uaaUrl}")
    private String stufUaaUrl;

    @Value("${stuf.tenantServiceUrl}")
    private String stufTenantServiceUrl;

    @Autowired
    private DataSource dataSource;

    private TenantDataSource tenantDataSource;

    @Autowired
    private TenantDataSourceService tenantDataSourceService;

    @Autowired
    private TmsTenantDataSourceLookup tmsTenantDataSourceLookup;

    public static final String SHARED_DB = "a1730ade-7c0d-4652-8d44-cb563fcc1e27";

    public static final String DEDICATED_DB_ENV = "b2730ade-7c0d-4652-8d44-cb563fcc1e27";

    public static final String DEDICATED_DB_TMS = "c2730ade-7c0d-4652-8d44-cb563fcc1e27";

    @Before
    public void setUp() throws Exception {
        RestAssured.port = port;
        RestAssured.basePath = "";

        assertThat(dataSource).isInstanceOf(TenantDataSource.class);
        tenantDataSource = (TenantDataSource) dataSource;
        stufUaaUrl = stufUaaUrl.replace("{local.server.port}", String.valueOf(port)) + "/oauth/token";
        stufTenantServiceUrl = stufTenantServiceUrl.replace("{local.server.port}", String.valueOf(port));

        Field field = ReflectionUtils.findField(TmsTenantDataSourceLookup.class, "stufUaaUrl");
        ReflectionUtils.makeAccessible(field);
        ReflectionUtils.setField(field, tmsTenantDataSourceLookup, stufUaaUrl);

        field = ReflectionUtils.findField(TmsTenantDataSourceLookup.class, "stufTenantServiceUrl");
        ReflectionUtils.makeAccessible(field);
        ReflectionUtils.setField(field, tmsTenantDataSourceLookup, stufTenantServiceUrl);

        field = ReflectionUtils.findField(TenantDataSourceServiceImpl.class, "disableTms");
        ReflectionUtils.makeAccessible(field);
        ReflectionUtils.setField(field, tenantDataSourceService, false);

        field = ReflectionUtils.findField(TenantDataSource.class, "disableTms");
        ReflectionUtils.makeAccessible(field);
        ReflectionUtils.setField(field, tenantDataSource, false);

        tenantDataSource.flush();
        tmsTenantDataSourceLookup.flush();

        RequestContext.clear();
    }

    //@Test
    public void tenantIDNotUUIDTest() {
        RequestContext.put(RequestContext.TENANT_UUID, "non-uuid");
        tenantDataSource.determineTargetDataSource();
    }

    @Test
    public void sharedDBConstant() {

        assertThat(tenantDataSourceService.getTenants()).hasSize(4);

        RequestContext.put(RequestContext.TENANT_UUID, TenantDataSourceService.DEFAULT_DATASOURCE);

        DataSource ds = tenantDataSource.determineTargetDataSource();
        assertThat(ds).isInstanceOf(org.apache.tomcat.jdbc.pool.DataSource.class);

        org.apache.tomcat.jdbc.pool.DataSource tomcatDs = (org.apache.tomcat.jdbc.pool.DataSource) ds;
        assertThat(tomcatDs.getUrl()).isEqualTo("jdbc:postgresql://example.com:123/sharedDb");
        assertThat(tomcatDs.getUsername()).isEqualTo("scott1");
        assertThat(tomcatDs.getDbProperties().getProperty("stringtype")).isEqualTo("unspecified");
        assertThat(tomcatDs.getMaxWait()).isEqualTo(999);

        assertThat(tomcatDs.getInitialSize()).isEqualTo(1);
        assertThat(tomcatDs.getMinIdle()).isEqualTo(2);
        assertThat(tomcatDs.getMaxIdle()).isEqualTo(4);
        assertThat(tomcatDs.getMaxActive()).isEqualTo(6);
        assertThat(tomcatDs.getValidationQuery()).isEqualTo("SELECT 1");

        assertThat(tenantDataSourceService.getTenants()).hasSize(4);
    }

    @Test
    public void sharedDB() {

        assertThat(tenantDataSourceService.getTenants()).hasSize(4);

        RequestContext.put(RequestContext.TENANT_UUID, SHARED_DB);

        DataSource ds = tenantDataSource.determineTargetDataSource();
        assertThat(ds).isInstanceOf(org.apache.tomcat.jdbc.pool.DataSource.class);

        org.apache.tomcat.jdbc.pool.DataSource tomcatDs = (org.apache.tomcat.jdbc.pool.DataSource) ds;
        assertThat(tomcatDs.getUrl()).isEqualTo("jdbc:postgresql://example.com:123/sharedDb");
        assertThat(tomcatDs.getUsername()).isEqualTo("scott1");
        assertThat(tomcatDs.getDbProperties().getProperty("stringtype")).isEqualTo("unspecified");
        assertThat(tomcatDs.getMaxWait()).isEqualTo(999);

        assertThat(tomcatDs.getInitialSize()).isEqualTo(1);
        assertThat(tomcatDs.getMinIdle()).isEqualTo(2);
        assertThat(tomcatDs.getMaxIdle()).isEqualTo(4);
        assertThat(tomcatDs.getMaxActive()).isEqualTo(6);
        assertThat(tomcatDs.getValidationQuery()).isEqualTo("SELECT 1");

        assertThat(tenantDataSourceService.getTenants()).hasSize(4);
    }

    @Test
    public void dedicatedDBEnv() {

        assertThat(tenantDataSourceService.getTenants()).hasSize(4);

        RequestContext.put(RequestContext.TENANT_UUID, DEDICATED_DB_ENV);

        DataSource ds = tenantDataSource.determineTargetDataSource();
        assertThat(ds).isInstanceOf(org.apache.tomcat.jdbc.pool.DataSource.class);

        org.apache.tomcat.jdbc.pool.DataSource tomcatDs = (org.apache.tomcat.jdbc.pool.DataSource) ds;
        assertThat(tomcatDs.getUrl()).isEqualTo(
            "jdbc:postgresql://example.com:789/envDb?stringtype=unspecified&stringtype=unspecified");
        assertThat(tomcatDs.getUsername()).isEqualTo("scottb");
        assertThat(tomcatDs.getDbProperties().getProperty("stringtype")).isEqualTo("unspecified");
        assertThat(tomcatDs.getDbProperties().getProperty("alice")).isEqualTo("wonderland");
        assertThat(tomcatDs.getValidationQuery()).isEqualTo("SELECT 111");
        assertThat(tomcatDs.getInitialSize()).isEqualTo(111);
        assertThat(tomcatDs.getMinIdle()).isEqualTo(121);
        assertThat(tomcatDs.getMaxIdle()).isEqualTo(141);
        assertThat(tomcatDs.getMaxActive()).isEqualTo(161);
        assertThat(tomcatDs.getMaxWait()).isEqualTo(181);

        assertThat(tenantDataSourceService.getTenants()).hasSize(4);
    }

    @Test
    public void dedicatedDBTms() {

        assertThat(tenantDataSourceService.getTenants()).hasSize(4);

        RequestContext.put(RequestContext.TENANT_UUID, DEDICATED_DB_TMS);

        DataSource ds = tenantDataSource.determineTargetDataSource();
        assertThat(ds).isInstanceOf(org.apache.tomcat.jdbc.pool.DataSource.class);

        org.apache.tomcat.jdbc.pool.DataSource tomcatDs = (org.apache.tomcat.jdbc.pool.DataSource) ds;
        assertThat(tomcatDs.getUrl()).isEqualTo(
            "jdbc:postgresql://db-0bee8589-e626-464e-af05-cc58de9cc8f4.cnwizakaxf1c.aus-central-1.rds.amazonaws.com"
                + ":5432/postgres?stringtype=unspecified");
        assertThat(tomcatDs.getUsername()).isEqualTo("ucrfz1591lzo0tzt");
        assertThat(tomcatDs.getDbProperties().getProperty("stringtype")).isEqualTo("unspecified");
        assertThat(tomcatDs.getMaxWait()).isEqualTo(999);
        assertThat(tomcatDs.getValidationQuery()).isEqualTo("SELECT 1");

        assertThat(tenantDataSourceService.getTenants()).hasSize(5);
    }

    @Test
    public void cacheFlushTest() {
        assertThat(tenantDataSourceService.getTenants()).hasSize(4);
        given().when().post("/dbCredentialsCache/flush/d1730ade-7c0d-4652-8d44-cb563fcc1e27").prettyPeek().then()
            .statusCode(200);
        assertThat(tenantDataSourceService.getTenants()).hasSize(3);
        given().when().post("/dbCredentialsCache/flushAll").then().statusCode(200);
        Field field = ReflectionUtils.findField(TmsTenantDataSourceLookup.class, "cache");
        ReflectionUtils.makeAccessible(field);
        Map cache = (Map) ReflectionUtils.getField(field, tmsTenantDataSourceLookup);
        assertThat(cache.size()).isEqualTo(0);
        assertThat(tenantDataSourceService.getTenants()).hasSize(4);
        sharedDB();
        dedicatedDBEnv();
        dedicatedDBTms();
    }

    @Test
    public void disableTmsTest() {

        Field field = ReflectionUtils.findField(TenantDataSourceServiceImpl.class, "disableTms");
        ReflectionUtils.makeAccessible(field);
        ReflectionUtils.setField(field, tenantDataSourceService, true);

        field = ReflectionUtils.findField(TenantDataSource.class, "disableTms");
        ReflectionUtils.makeAccessible(field);
        ReflectionUtils.setField(field, tenantDataSource, true);

        assertThat(tenantDataSourceService.getTenants()).hasSize(1);

        // shared DB Constant
        RequestContext.put(RequestContext.TENANT_UUID, TenantDataSourceService.DEFAULT_DATASOURCE);

        DataSource ds = tenantDataSource.determineTargetDataSource();
        assertThat(ds).isInstanceOf(org.apache.tomcat.jdbc.pool.DataSource.class);
        org.apache.tomcat.jdbc.pool.DataSource tomcatDs = (org.apache.tomcat.jdbc.pool.DataSource) ds;
        assertThat(tomcatDs.getUrl()).isEqualTo("jdbc:postgresql://example.com:123/sharedDb");
        assertThat(tomcatDs.getUsername()).isEqualTo("scott1");
        assertThat(tomcatDs.getDbProperties().getProperty("stringtype")).isEqualTo("unspecified");
        assertThat(tomcatDs.getMaxWait()).isEqualTo(999);
        assertThat(tomcatDs.getInitialSize()).isEqualTo(1);
        assertThat(tomcatDs.getMinIdle()).isEqualTo(2);
        assertThat(tomcatDs.getMaxIdle()).isEqualTo(4);
        assertThat(tomcatDs.getMaxActive()).isEqualTo(6);
        assertThat(tomcatDs.getValidationQuery()).isEqualTo("SELECT 1");

        // shared DB Variant
        RequestContext.put(RequestContext.TENANT_UUID, SHARED_DB);
        ds = tenantDataSource.determineTargetDataSource();
        assertThat(ds).isInstanceOf(org.apache.tomcat.jdbc.pool.DataSource.class);
        tomcatDs = (org.apache.tomcat.jdbc.pool.DataSource) ds;
        assertThat(tomcatDs.getUrl()).isEqualTo("jdbc:postgresql://example.com:123/sharedDb");
        assertThat(tomcatDs.getUsername()).isEqualTo("scott1");
        assertThat(tomcatDs.getDbProperties().getProperty("stringtype")).isEqualTo("unspecified");
        assertThat(tomcatDs.getMaxWait()).isEqualTo(999);
        assertThat(tomcatDs.getInitialSize()).isEqualTo(1);
        assertThat(tomcatDs.getMinIdle()).isEqualTo(2);
        assertThat(tomcatDs.getMaxIdle()).isEqualTo(4);
        assertThat(tomcatDs.getMaxActive()).isEqualTo(6);
        assertThat(tomcatDs.getValidationQuery()).isEqualTo("SELECT 1");

        // dedicated DB Env
        RequestContext.put(RequestContext.TENANT_UUID, DEDICATED_DB_ENV);
        ds = tenantDataSource.determineTargetDataSource();
        assertThat(ds).isInstanceOf(org.apache.tomcat.jdbc.pool.DataSource.class);
        tomcatDs = (org.apache.tomcat.jdbc.pool.DataSource) ds;
        assertThat(tomcatDs.getUrl()).isEqualTo(
            "jdbc:postgresql://example.com:789/envDb?stringtype=unspecified&stringtype=unspecified");
        assertThat(tomcatDs.getUsername()).isEqualTo("scottb");
        assertThat(tomcatDs.getDbProperties().getProperty("stringtype")).isEqualTo("unspecified");
        assertThat(tomcatDs.getDbProperties().getProperty("alice")).isEqualTo("wonderland");
        assertThat(tomcatDs.getValidationQuery()).isEqualTo("SELECT 111");
        assertThat(tomcatDs.getInitialSize()).isEqualTo(111);
        assertThat(tomcatDs.getMinIdle()).isEqualTo(121);
        assertThat(tomcatDs.getMaxIdle()).isEqualTo(141);
        assertThat(tomcatDs.getMaxActive()).isEqualTo(161);
        assertThat(tomcatDs.getMaxWait()).isEqualTo(181);

        // dedicated DB Tms but will fall back to shared db
        RequestContext.put(RequestContext.TENANT_UUID, DEDICATED_DB_TMS);
        ds = tenantDataSource.determineTargetDataSource();
        assertThat(ds).isInstanceOf(org.apache.tomcat.jdbc.pool.DataSource.class);
        tomcatDs = (org.apache.tomcat.jdbc.pool.DataSource) ds;
        assertThat(tomcatDs.getUrl()).isEqualTo("jdbc:postgresql://example.com:123/sharedDb");
        assertThat(tomcatDs.getUsername()).isEqualTo("scott1");
        assertThat(tomcatDs.getDbProperties().getProperty("stringtype")).isEqualTo("unspecified");
        assertThat(tomcatDs.getMaxWait()).isEqualTo(999);
        assertThat(tomcatDs.getInitialSize()).isEqualTo(1);
        assertThat(tomcatDs.getMinIdle()).isEqualTo(2);
        assertThat(tomcatDs.getMaxIdle()).isEqualTo(4);
        assertThat(tomcatDs.getMaxActive()).isEqualTo(6);
        assertThat(tomcatDs.getValidationQuery()).isEqualTo("SELECT 1");

        assertThat(tenantDataSourceService.getTenants()).hasSize(1);
    }
}
