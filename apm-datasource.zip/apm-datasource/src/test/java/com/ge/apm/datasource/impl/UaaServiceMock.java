/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.datasource.impl;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UaaServiceMock {

    @Value("${app.client.id}")
    private String appClientId;

    @Value("${app.client.secret}")
    private String appClientSecret;

    @RequestMapping(method = RequestMethod.POST, value = "/stuf-uaa/oauth/token")
    public String token(@RequestHeader(value = "Authorization") String authorization,
        @RequestParam(value = "grant_type") String grantType, @RequestParam(value = "scope") String[] scope) {
        assert authorization.contains("Basic");
        assert "client_credentials".equals(grantType);
        assert scope != null && scope.length == 3;
        assert "stuf.app.microservice-dev".equals(scope[0]);
        assert "stuf.read".equals(scope[1]);
        assert "stuf.496bb641-78b5-4a18-b1b7-fde29788db38.zone".equals(scope[2]);
        String encoded = authorization.substring(authorization.indexOf("Basic") + 5);
        String decoded = new String(Base64.getDecoder().decode(encoded.trim()));
        assert decoded.equals(appClientId + ":" + appClientSecret);
        return "{\n" + "  \"access_token\": \"a.b.c\",\n" + "  \"jti\": \"1b2b69e266694d268e993692319fc3a6\"\n" + "}";
    }
}
