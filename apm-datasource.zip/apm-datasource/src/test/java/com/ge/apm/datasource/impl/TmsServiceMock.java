/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.datasource.impl;

import java.nio.charset.Charset;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TmsServiceMock {

    @Value("classpath:firstPageDedicatedDBs.json")
    private Resource firstPageDedicatedDBs;

    @Value("classpath:secondPageDedicatedDBs.json")
    private Resource secondPageDedicatedDBs;

    @Value("classpath:c2730ade-7c0d-4652-8d44-cb563fcc1e27.json")
    private Resource c2730ade_7c0d_4652_8d44_cb563fcc1e27;

    @RequestMapping(value = "/tenancy-stuf/v1/serviceinstances/{canonicalServiceName}")
    public String getServiceDetails(@PathVariable(value = "canonicalServiceName") String canonicalServiceName,
        @PathParam(value = "offset") int offset) throws Exception {
        assert "postgres".equals(canonicalServiceName);
        String output = null;
        if (offset == 0) {
            output = StreamUtils.copyToString(firstPageDedicatedDBs.getInputStream(), Charset.defaultCharset());
        } else if (offset == 50) {
            output = StreamUtils.copyToString(secondPageDedicatedDBs.getInputStream(), Charset.defaultCharset());
        } else {
            throw new RuntimeException("offset " + offset + "not supported !");
        }
        return output;
    }

    @RequestMapping(value = "/tenancy-stuf/v1/tenants/{tenantId}/serviceinstances/{canonicalServiceName}")
    public ResponseEntity getServiceDetails(@PathVariable(value = "tenantId") String tenantId,
        @PathVariable(value = "canonicalServiceName") String canonicalServiceName) throws Exception {
        assert "postgres".equals(canonicalServiceName);
        if (DatabasesTest.SHARED_DB.equalsIgnoreCase(tenantId)) {
            return new ResponseEntity(HttpStatus.NOT_FOUND);
        }

        if (DatabasesTest.DEDICATED_DB_TMS.equalsIgnoreCase(tenantId)) {
            return new ResponseEntity(StreamUtils
                .copyToString(c2730ade_7c0d_4652_8d44_cb563fcc1e27.getInputStream(), Charset.defaultCharset()),
                HttpStatus.OK);
        }

        return new ResponseEntity(HttpStatus.BAD_REQUEST);
    }
}
