rm -vrf ${WORKSPACE}/../.m2ApmDatasource/repository/com/ge/apm/apm-datasource

mkdir -p ${WORKSPACE}/../.m2ApmDatasource
export MAVEN_OPTS="-Dmaven.repo.local=${WORKSPACE}/../.m2ApmDatasource/repository"
export JAVA_HOME=${JAVA_HOME_ORACLEJDK8}
export PATH=${JAVA_HOME}/bin:${PATH}
mvn -U clean deploy -s menlo_settings.xml
