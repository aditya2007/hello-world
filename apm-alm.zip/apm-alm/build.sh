export uniqId=`openssl rand -hex 24`
export MVN_REPO=“${WORKSPACE}/.m2ApmAlm_${BUILD_NUMBER}_${uniqId}”
mkdir -p ${MVN_REPO}
export MAVEN_OPTS="-Dmaven.repo.local=${MVN_REPO}"
export JAVA_HOME=${JAVA_HOME_ORACLEJDK8}
export PATH=${JAVA_HOME}/bin:${PATH}

# temp change to lower and percentage to unblock QE
expectedCoverage=88
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'
#JQ=${WORKSPACE}/utils/linux/jq

# run sonar 
mvn clean verify -DskipTests=true sonar:sonar -Dsonar.analysis.mode=preview -Dsonar.issuesReport.json.enable=true -Dsonar.report.export.path=report.json -Dsonar.host.url=http://3.39.73.153:9000 -Dsonar.login=apm-dev -Dsonar.password=Pa55w0rd -s menlo_settings.xml -Denv=jenkins

# check sonar report
blockers=`jq ".issues" target/sonar/report.json | grep severity | grep BLOCKER | wc -l`
criticals=`jq ".issues" target/sonar/report.json | grep severity | grep CRITICAL | wc -l`
totalViolations=$(( $blockers + $criticals ))
if [ $totalViolations -ge 1 ]; then
    printf "%b" "${RED}Please fix the sonar report(http://3.39.73.153:9000/): There are $(( $blockers * 1 )) blocker issues and $(( $criticals * 1 )) critical issues.\n${NC}"
    exit 1
fi

# run clover report
mvn -U clean -Dcheckstyle.skip=true -Dexcludes=**/target/**/* -Pclover.report clover2:setup verify clover2:check clover2:aggregate clover2:clover -s menlo_settings.xml -Denv=jenkins
if [ $? -ne 0 ]; then
    printf "${RED}There are errors when generating clover report for code coverage.\n${NC}"
    exit 1
fi

# get code coverage
jenkinsDir=${WORKSPACE}/target/site/clover
data=`cat $jenkinsDir/project.js`
echo $data | tr -d ' ' | sed 's/.\{2\}$//' | sed 's/^.\{14\}//' > $jenkinsDir/formatted.json
#actualCoverage=`${JQ} ".stats.TotalPercentageCovered" $jenkinsDir/formatted.json | cut -d "." -f1`
actualCoverage=`jq ".stats.TotalPercentageCovered" $jenkinsDir/formatted.json | cut -d "." -f1`

# check coverage
if [ $actualCoverage -ge $expectedCoverage ]; then
    printf "%b" "${GREEN}Code coverage check is successful. Code coverage is $actualCoverage, which is above $expectedCoverage.\n${NC}"
else
    printf "%b" "${RED}Code coverage check is failed. Code coverage is $actualCoverage, which is below $expectedCoverage.\n${NC}"
    # clean up
    rm -rf ${MVN_REPO}
    exit 1
fi

mvn clean deploy -s menlo_settings.xml -Denv=jenkins
RET=$?
rm -rf ${MVN_REPO}
if [ $RET -eq 0 ]; then
	exit 0
else
	echo "Build Failed"
	exit 1
fi
