/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.rest.controller;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import com.google.common.base.Splitter;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.rest.controller.model.AssetModel;
import com.ge.apm.alm.rest.controller.model.OOTBTypeNameMapping;
import com.ge.apm.alm.service.AssetService;

//@RestController
//@RequestMapping("/v1")
/*
  @EnableResourceServer - Experimental to do OAuth2 using standard libraries
  @Configuration
**/
@Slf4j
public class AssetController {

    private static final Collection<String> ACCESSIBLE_RESOURCES = Arrays.asList("825229df-93e9-3433-a7d8-b13f7a6585bc",
        "e6114962-297c-38b1-b633-51a8f251648b", "d38b2a84-0daa-3cd5-8162-15dc43b66fc1");
    @Autowired
    private AssetService assetService;

    /*
    Collection REST Resource for all types
     */

    @RequestMapping(method = RequestMethod.GET, value = "/{coretype:(?:enterprises|sites|segments|assets)}",
        produces = MediaType.APPLICATION_JSON_VALUE)
    public Object getAssets(@RequestHeader(value = "tenant") String tenantId,
        @PathVariable String coretype,
        @RequestParam(value = "components", defaultValue = "BASIC") Optional<String> components,
        @RequestParam(value = "pageSize") Optional<Integer> pageSize,
        @RequestParam(value = "offset") Optional<Integer> offset,
        @RequestParam(value = "name") Optional<String> name,
        @RequestParam(value = "sourceKey") Optional<String> sourceKey,
        @RequestParam(value = "description") Optional<String> description,
        @RequestParam(value = "attributes") Optional<String> attributes,
        @RequestParam(value = "type") Optional<String> typeId,
        @RequestParam(value = "deepSearch", defaultValue = "false") Optional<Boolean> deepSearch) {
        try {
            //access to E1_MyEnterpriseType_I1, E2_S1_MySiteType_I1, E3_MyEnterpriseType_I1
            String coreTypeName = OOTBTypeNameMapping.valueOf(coretype).getValue();
            if (sourceKey.isPresent()) {
                //passing type is required due to v1 contract
                return new ResponseEntity<>(
                    assetService.getAssetBySourceKey(tenantId, ACCESSIBLE_RESOURCES, coreTypeName, sourceKey.get()),
                    HttpStatus.OK);
            }
            AssetPredicate queryPredicate =
                getQueryPredicate(components, pageSize, offset, name, description, attributes, typeId, coreTypeName);
            List<? extends Asset> assets = assetService.getAssets(tenantId, ACCESSIBLE_RESOURCES, queryPredicate);
            return new ResponseEntity<>(assets, HttpStatus.OK);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{type:(?:enterprises|sites|segments|assets)}/{id}",
        produces = MediaType.APPLICATION_JSON_VALUE)
    public Object getAsset(@RequestHeader(value = "tenant") String tenantId,
        @PathVariable String type, @PathVariable("id") String id) {
        //access to E1_MyEnterpriseType_I1, E2_S1_MySiteType_I1, E3_MyEnterpriseType_I1
        Asset asset;
        try {
            asset = assetService.getAssetById(tenantId, ACCESSIBLE_RESOURCES, id);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        if (asset == null) {
            return new ResponseEntity(HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(asset, HttpStatus.OK);
        }
    }

    @RequestMapping(method = RequestMethod.GET,
        value = "/{coretype:(?:enterprises|sites|segments|assets)}/{id}/children",
        produces = MediaType.APPLICATION_JSON_VALUE)
    public Object getAssetChildren(@RequestHeader(value = "tenant") String tenantId,
        @PathVariable String coretype, @PathVariable("id") String id,
        @RequestParam(value = "components", defaultValue = "BASIC") Optional<String> components,
        @RequestParam(value = "pageSize") Optional<Integer> pageSize,
        @RequestParam(value = "offset") Optional<Integer> offset,
        @RequestParam(value = "name") Optional<String> name,
        @RequestParam(value = "description") Optional<String> description,
        @RequestParam(value = "attributes") Optional<String> attributes,
        @RequestParam(value = "type") Optional<String> typeId,
        @RequestParam(value = "deepSearch", defaultValue = "false") Optional<Boolean> deepSearch) {

        try {
            //access to E1_MyEnterpriseType_I1, E2_S1_MySiteType_I1, E3_MyEnterpriseType_I1
            AssetPredicate childPredicate =
                getQueryPredicate(components, pageSize, offset, name, description, attributes, typeId, null);
            List<? extends Asset> assets =
                assetService.getChildAssets(tenantId, ACCESSIBLE_RESOURCES, id, childPredicate);
            return new ResponseEntity<>(assets, HttpStatus.OK);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/{type:(?:enterprises|sites|segments|assets)}/{id}/children",
        consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Object createAsset(@RequestHeader(value = "tenant") String tenantId,
        @PathVariable String type, @PathVariable("id") String id,
        @RequestBody AssetModel asset) {
        //access to E1_MyEnterpriseType_I1, E2_S1_MySiteType_I1, E3_MyEnterpriseType_I1
        try {
            Asset newAsset = assetService.createAsset(tenantId, ACCESSIBLE_RESOURCES, id, asset);
            return new ResponseEntity<>(newAsset, HttpStatus.CREATED);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/{type:(?:enterprises|sites|segments|assets)}",
        consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Object createOrphanedAsset(@RequestHeader(value = "tenant") String tenantId,
        @PathVariable String type,
        @RequestBody AssetModel asset) {

        //access to E1_MyEnterpriseType_I1, E2_S1_MySiteType_I1, E3_MyEnterpriseType_I1
        try {
            Asset newAsset = assetService.createAsset(tenantId, ACCESSIBLE_RESOURCES, asset);
            return new ResponseEntity<>(newAsset, HttpStatus.CREATED);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private AssetPredicate getQueryPredicate(Optional<String> components,
        Optional<Integer> pageSize,
        Optional<Integer> offset,
        Optional<String> name,
        Optional<String> description,
        Optional<String> attributes,
        Optional<String> typeId,
        String coreTypeName //, Optional<Boolean> deepSearch
    ) {

        Optional<Map<String, String>> attributeFilterMap = getAttributeFilters(attributes);
        AttributeSelectEnum attributeSelectEnum = AttributeSelectEnum.valueOf(components.orElse("BASIC"));
        boolean includeSubTypeInstances = StringUtils.isEmpty(coreTypeName) ? false : true;
        Set<String> ids = typeId.isPresent() ? Sets.newHashSet(typeId.get()) : Collections.emptySet();
        return AssetPredicate.builder().attributeSelectEnum(attributeSelectEnum).pageSize(pageSize.orElse(250))
            .offset(offset.orElse(0)).type(TypePredicate.builder().name(coreTypeName)
                .parent(ParentPredicate.builder().ids(ids).build())
                .deepSearch(includeSubTypeInstances).build())
            .name(name.orElse(null)).description(description.orElse(null))
            .attributes(attributeFilterMap.orElse(null)).build();
    }

    private Optional<Map<String, String>> getAttributeFilters(
        @RequestParam(value = "attributes") Optional<String> attributes) {
        Optional<Map<String, String>> attributeFilterMap = Optional.empty();
        if (attributes.isPresent()) {
            attributeFilterMap = Optional.of(Splitter.on(":").withKeyValueSeparator("=").split(attributes.get()));
        }
        return attributeFilterMap;
    }
}
