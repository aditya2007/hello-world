/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.rest.controller.model;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.TemplateInfo;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LimitedAssetModel implements Asset {

  private String id;
  private String sourceKey;
  private String name;
  private String description;
  private String tenantId;

  private String assetType;
  @JsonIgnore
  private List<String> superTypesArray;
  private String parentId;
  @JsonIgnore
  private JsonNode attributes;
  @JsonIgnore
  private JsonNode geolocation;
  private List<String> ancestorsArray;
  @JsonIgnore
  private TemplateInfo templateInfo;
  @JsonIgnore
  private String templateId;
  @JsonIgnore
  private String createdBy;
  @JsonIgnore
  private OffsetDateTime createdDate;
  @JsonIgnore
  private String lastModifiedBy;
  @JsonIgnore
  private OffsetDateTime lastModifiedDate;

  @JsonIgnore
  private LimitedAssetModel parent;
  @JsonIgnore
  private String coreAssetTypeName;
  @JsonIgnore
  private AssetType type;
  @JsonIgnore
  private List<Tag> tags;

  private String parentUri;
  private String uri;
  private String childResourcesUri;
  @JsonInclude(Include.NON_NULL)
  private Set<LimitedAssetModel> children;
  private boolean hasPermission;
}
