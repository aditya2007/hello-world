/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.rest.controller;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.rest.controller.model.LimitedAssetModel;
import com.ge.apm.alm.rest.controller.model.TreeNodeModel;
import com.ge.apm.alm.rest.controller.utils.AssetCollectionUtil;
import com.ge.apm.common.support.RequestContext;

/**
 * TODO: Document what RootInstancesController is.
 *
 * @author <<<your name>>> <<<your SSO>>>
 * @version 1.0 Apr 23, 2018
 * @since 1.0
 */
@RestController
@RequestMapping("/v3/root-instances")
@Slf4j
public class RootInstancesController {

  private static final String ALL_ACCESSIBLE_RESOURCES = "AllAccessibleResources";

  @Autowired
  private AssetPersistencyService assetService;

  @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
  @RequestMapping(method = RequestMethod.GET)
  public ResponseEntity getRootInstances(@RequestHeader(value = "tenant") String tenant,
      @RequestParam(required = false, value = "pageSize") Optional<Integer> pageSize,
      @RequestParam(required = false, value = "offset") Optional<Integer> offset,
      @RequestParam(required = false, value = "tenantId") Optional<String> tenantId,
      @RequestParam(required = false, value = "includeTenants") Optional<Boolean> includeTenants) {
    try {

      //getting accessible resources for all or a single tenant
      Map<String, Set<String>> accessibleResources = RequestContext.get(ALL_ACCESSIBLE_RESOURCES, Map.class);

      if (includeTenants.isPresent() && includeTenants.get()) {
        return getTenantsResponse(tenantId, accessibleResources);
      }

      Set<LimitedAssetModel> assetListResponse =
          AssetCollectionUtil.getAccessibleResources(assetService, tenant, pageSize, offset);

      return new ResponseEntity<>(assetListResponse, HttpStatus.OK);

    } catch (Exception e) {
      log.error(e.getMessage(), e);
      return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }


  //Tenants Nodes

  private ResponseEntity getTenantsResponse(Optional<String> tenantId, Map<String, Set<String>> accessibleResources) {
    //if include tenants, it will show the tenant level - No need for SQL query
    Set<String> accessibleTenantIds = accessibleResources.keySet();
    if (tenantId.isPresent() && !tenantId.get().isEmpty()) {
      //further filtering down to specific tenant,
      accessibleTenantIds.removeIf(s -> !s.equals(tenantId.get()));
    }
    return new ResponseEntity<>(createTenantNodes(accessibleTenantIds), HttpStatus.OK);
  }

  private List<TreeNodeModel> createTenantNodes(Set<String> tenantIds) {
    //TODO: Get tenant name
    return tenantIds.stream().map(tenantId -> TreeNodeModel.builder().id(tenantId).name("TenantName-TBD").
        description("TenantDesc-TBD").childResourcesUri("/v3/tenants/" + tenantId + "/children").
        uri("/v3/tenants/" + tenantId).children(new LinkedList<>()).openable(true).build())
        .collect(Collectors.toList());
  }

}
