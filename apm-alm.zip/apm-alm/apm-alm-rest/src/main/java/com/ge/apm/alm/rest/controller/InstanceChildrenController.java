/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.rest.controller;

import static com.ge.apm.alm.rest.controller.utils.AssetCollectionUtil.buildAssetInstanceUri;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.rest.controller.model.LimitedAssetModel;
import com.ge.apm.alm.rest.controller.utils.AssetCollectionUtil;

/**
 * This controller lists root nodes in a given tenant.
 *
 * @author Satyapal Reddy 212564021
 * @version 1.0 Apr 23, 2018
 * @since 1.0
 */
@RestController
@RequestMapping("/v3/tenants/{tenantId}/instances/{instanceUUId}/children")
@Slf4j
public class InstanceChildrenController {

  @Autowired
  private AssetPersistencyService assetService;

  @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity getTenantsChildren(@RequestHeader(value = "tenant") String tenant,
      @PathVariable("tenantId") Optional<String> tenantId,
      @PathVariable("instanceUUId") Optional<String> instanceUUId,
      @RequestParam(value = "pageSize") Optional<Integer> pageSize,
      @RequestParam(value = "offset") Optional<Integer> offset) {
    try {

      //return list of first nodes that the user has access to based on accessible resources
      AssetPredicate queryPredicate = getQueryPredicate(pageSize, offset);
      List<Asset> childAssets = assetService.getChildAssets(tenant, null, instanceUUId.get(), queryPredicate);

      List<LimitedAssetModel> assetListResponse = childAssets.stream()
          .map(asset -> AssetCollectionUtil.transform(asset, true))
          .peek(asset -> asset.setParentUri(buildAssetInstanceUri(asset.getParent())))
          .collect(Collectors.toList());

      return new ResponseEntity<>(assetListResponse, HttpStatus.OK);
    } catch (Exception e) {
      log.error(e.getMessage(), e);
      return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  private AssetPredicate getQueryPredicate(Optional<Integer> pageSize, Optional<Integer> offset) {

    AttributeSelectEnum attributeSelectEnum = AttributeSelectEnum.valueOf(("BASIC"));
    return AssetPredicate.builder().attributeSelectEnum(attributeSelectEnum).pageSize(pageSize.orElse(250))
        .offset(offset.orElse(0)).ignoreComponentAcl(false).build();
  }

}
