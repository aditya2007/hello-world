/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.rest.controller.utils;

import java.util.Locale;

import com.ge.apm.common.support.RequestContext;

public final class TenantUtil {

    private TenantUtil() {

    }

    public static String getId() {
        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        String formattedTenantId = tenantId;
        if (!tenantId.contains("-")) {
            tenantId = tenantId.toLowerCase(Locale.getDefault());
            formattedTenantId = String.format("%s-%s-%s-%s-%s", tenantId.substring(0, 8),
                tenantId.substring(8, 12), tenantId.substring(12, 16), tenantId.substring(16, 20),
                tenantId.substring(20));
        }

        return formattedTenantId;
    }
}
