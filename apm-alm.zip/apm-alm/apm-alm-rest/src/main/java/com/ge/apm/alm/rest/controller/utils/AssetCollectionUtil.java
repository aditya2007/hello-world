/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.rest.controller.utils;

import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.rest.controller.model.LimitedAssetModel;

/**
 * TODO: Document what AssetCollectionUtil is.
 *
 * @author Satyapal Reddy 212564021
 * @version 1.0 May 03, 2018
 * @since 1.0
 */
public class AssetCollectionUtil {

  public static Set<LimitedAssetModel> getAccessibleResources(AssetPersistencyService assetService,
      String tenant, Optional<Integer> pageSize, Optional<Integer> offset) {
    //return list of first nodes that the user has access to based on accessible resources
    Set<LimitedAssetModel> accessibleAssets =
        AssetCollectionUtil.getLimitedAssetModels(assetService, tenant, pageSize, offset);
    if (CollectionUtils.isEmpty(accessibleAssets)) {
      return accessibleAssets;
    }
    Set<String> accessibleAssetIds = accessibleAssets.stream().map(asset -> asset.getId())
        .collect(Collectors.toSet());

    Set<LimitedAssetModel> allAssets = new HashSet<>(accessibleAssets);

    //If the user has access to leaf nodes alone, we must build a merged tree to show parent hierarchy
    //we must do this operation in privileged mode.
    for (LimitedAssetModel accessibleAsset : accessibleAssets) {
      if (accessibleAsset.getAncestorsArray() != null && !accessibleAsset.getAncestorsArray().isEmpty()) {
        // check if any of the ancestor has access
        if (!Collections.disjoint(accessibleAssetIds, accessibleAsset.getAncestorsArray())) {
          // remove this asset from accessible resource list, since this asset's ancestor already exists in
          // all assets
          allAssets.remove(accessibleAsset);
        }
      }
    }
    //Building set of parent ids across all tenants..

    Map<String, Set<LimitedAssetModel>> parentIdToAssetsMap = new HashMap<>();
    for (LimitedAssetModel asset : allAssets) {
      buildParentChildMap(parentIdToAssetsMap, asset);
    }

    Set<LimitedAssetModel> assetListResponse = new HashSet<>(parentIdToAssetsMap.get(null));
    assetListResponse.forEach(rootNode -> AssetCollectionUtil.addChildren(parentIdToAssetsMap, rootNode));
    // Removing Parent to avoid stackoverflow error during Json serialization
    removeParent(assetListResponse);
    return assetListResponse;
  }

  private static void removeParent(Set<LimitedAssetModel> assetList) {
    if (CollectionUtils.isEmpty(assetList)) {
      return;
    }
    assetList.forEach(asset -> {
      asset.setParent(null);
      removeParent(asset.getChildren());
    });
  }

  private static void buildParentChildMap(Map<String, Set<LimitedAssetModel>> parentIdToAssetsMap,
      LimitedAssetModel asset) {
    Set<LimitedAssetModel> valueModels;
    // Check if there is an entry exists for parentId key.
    if (parentIdToAssetsMap.containsKey(asset.getParentId())) {
      valueModels = parentIdToAssetsMap.get(asset.getParentId());
      // If the current asset already added with ParentId key, then don't put duplicate entry.
      if (!valueModels.stream().map(limitedAssetModel -> limitedAssetModel.getId()).collect(Collectors.toSet())
          .contains(asset.getId())) {
        valueModels.add(asset);
      } else {
        return;
      }
    } else {
      valueModels = new HashSet<>();
      valueModels.add(asset);
    }
    parentIdToAssetsMap.put(asset.getParentId(), valueModels);
    if (asset.getParentId() != null) {
      buildParentChildMap(parentIdToAssetsMap, asset.getParent());
    }
  }

  private static Set<LimitedAssetModel> getLimitedAssetModels(AssetPersistencyService assetService,
      String tenant, Optional<Integer> pageSize, Optional<Integer> offset) {
    AssetPredicate queryPredicate = getQueryPredicate(pageSize, offset, true);
    return assetService.getAccessibleResources(tenant, null, queryPredicate).stream()
        .map(asset -> transform(asset, true))
        .collect(Collectors.toSet());
  }

  //Adding Tree structure recursively.
  private static void addChildren(final Map<String, Set<LimitedAssetModel>> parentIdAssetsMap,
      LimitedAssetModel parentAsset) {
    Set<LimitedAssetModel> childNodes = parentIdAssetsMap.get(parentAsset.getId());
    if (childNodes == null || childNodes.isEmpty()) {
      return;
    }
    parentAsset.setChildren(childNodes);
    for (LimitedAssetModel childNode : childNodes) {
      childNode.setParentUri(parentAsset.getUri());
      addChildren(parentIdAssetsMap, childNode);
    }
  }

  private static AssetPredicate getQueryPredicate(Optional<Integer> pageSize, Optional<Integer> offset,
      boolean privilegedMode) {
    AssetPredicate predicate = AssetPredicate.builder()
        .attributeSelectEnum(AttributeSelectEnum.FULL_WITHOUT_ATTRIBUTES)
        .pageSize(pageSize.orElse(251)).offset(offset.orElse(0)).components(EnumSet.of(AssetComponent.PARENT))
        .ignoreComponentAcl(privilegedMode).build();
    return predicate;
  }

  public static String buildAssetInstanceUri(Asset asset) {
    StringBuilder sb = new StringBuilder("/v3/tenants/");
    sb.append(asset.getTenantId()).append("/");
    //sb.append(getInstancesUriPath(asset.getCoreAssetTypeName())); //TODO: Should it go to regular URI or
    // instance URI?
    sb.append("instances");
    sb.append("/").append(asset.getId());
    return sb.toString();
  }

  public static LimitedAssetModel transform(Asset asset, boolean permissible) {
    if (asset == null) {
      return null;
    }
    LimitedAssetModel limitedAssetModel = new LimitedAssetModel();
    BeanUtils.copyProperties(asset, limitedAssetModel);
    limitedAssetModel.setHasPermission(permissible);
    limitedAssetModel.setParent(transform(asset.getParent(), false));
    String selfUri = buildAssetInstanceUri(asset);
    limitedAssetModel.setUri(selfUri);
    limitedAssetModel.setChildResourcesUri(selfUri + "/children");
    return limitedAssetModel;
  }
}
