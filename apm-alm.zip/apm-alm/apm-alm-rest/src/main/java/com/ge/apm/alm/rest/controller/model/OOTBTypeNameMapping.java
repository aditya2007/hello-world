/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.rest.controller.model;

import java.util.EnumMap;
import java.util.Map;

import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;

public enum OOTBTypeNameMapping {
    enterpriseTypes("EnterpriseType"),
    siteTypes("SiteType"),
    segmentTypes("SegmentType"),
    assetTypes("AssetType"),
    tagTypes("TagType"),
    types(""),
    enterprises("EnterpriseType"),
    sites("SiteType"),
    segments("SegmentType"),
    assets("AssetType"),
    tags("TagType");

    private static final Map<OOTBCoreTypesIdLookup, OOTBTypeNameMapping> TYPE_LOOKUP =
        new EnumMap<>(OOTBCoreTypesIdLookup.class);

    private static final Map<OOTBCoreTypesIdLookup, OOTBTypeNameMapping> ASSET_LOOKUP =
        new EnumMap<>(OOTBCoreTypesIdLookup.class);

    static {
        TYPE_LOOKUP.put(OOTBCoreTypesIdLookup.EnterpriseType, enterpriseTypes);
        TYPE_LOOKUP.put(OOTBCoreTypesIdLookup.SiteType, siteTypes);
        TYPE_LOOKUP.put(OOTBCoreTypesIdLookup.SegmentType, segmentTypes);
        TYPE_LOOKUP.put(OOTBCoreTypesIdLookup.AssetType, assetTypes);
        TYPE_LOOKUP.put(OOTBCoreTypesIdLookup.TagType, tagTypes);

        ASSET_LOOKUP.put(OOTBCoreTypesIdLookup.EnterpriseType, enterprises);
        ASSET_LOOKUP.put(OOTBCoreTypesIdLookup.SiteType, sites);
        ASSET_LOOKUP.put(OOTBCoreTypesIdLookup.SegmentType, segments);
        ASSET_LOOKUP.put(OOTBCoreTypesIdLookup.AssetType, assets);
        ASSET_LOOKUP.put(OOTBCoreTypesIdLookup.TagType, tags);
    }

    private String value;

    OOTBTypeNameMapping(String type) {
        this.value = type;
    }

    public String getValue() {
        return value;
    }

    public OOTBTypeNameMapping fromType(OOTBCoreTypesIdLookup type) {
        return TYPE_LOOKUP.get(type);
    }

    public OOTBTypeNameMapping fromAsset(OOTBCoreTypesIdLookup assetType) {
        return TYPE_LOOKUP.get(assetType);
    }
}
