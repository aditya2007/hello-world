/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.rest.controller.utils;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.common.support.RequestContext;
import com.ge.stuf.security.context.SecurityContext;

public final class AccessibleResourceUtil {

    @Autowired
    SecurityContext securityContext;

    private static final String ACCESSIBLE_RESOURCES = "AccessibleResources";

    private static final String[] ALL_RESOURCES = new String[] {"*"};

    private AccessibleResourceUtil() {
        // doing nothing
    }

    public List<String> get(boolean ignore) {
        if (ignore) {
            return Collections.emptyList();
        }

        String[] accessibleResources = RequestContext.get(ACCESSIBLE_RESOURCES, String[].class);
        if (accessibleResources == null) {
            Set<String> secureResources = securityContext.getAccessibleResources();
            if (secureResources == null || secureResources.isEmpty()) {
                //TODO: 401 or 403
                throw new IllegalArgumentException("No accessible resource found");
            }

            String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
            if (secureResources.contains(tenantId)) {
                //All resources in the tenant accessible
                accessibleResources = ALL_RESOURCES;
            } else {
                //Specific resources accessible
                accessibleResources = secureResources.toArray(new String[secureResources.size()]);
            }
            RequestContext.put(ACCESSIBLE_RESOURCES, accessibleResources);
        }

        List<String> accessibleResourcesAsList = Arrays.asList(accessibleResources);
        return accessibleResourcesAsList.contains("*")
            ? Collections.emptyList()
            : accessibleResourcesAsList.stream().map(PrefixUtil::extractUuid).collect(Collectors.toList());

    }

    public static Map<String, Set<String>> getAccessibleResourcesMap() {
        Map<String, Set<String>> accessibleResourceMap = new HashMap<>();
        return accessibleResourceMap;
    }

    public static Map<String, Set<String>> getAccessibleResourcesMap(String tenantId) {
        Map<String, Set<String>> accessibleResourceMap = new HashMap<>();
        return accessibleResourceMap;
    }

}
