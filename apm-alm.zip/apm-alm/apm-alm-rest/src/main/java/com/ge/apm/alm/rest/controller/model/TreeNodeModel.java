/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.rest.controller.model;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.rest.controller.utils.TreeNode;

/**
 * TODO: Document what TreeNodeModel is.
 *
 * @author <<<Satyapal Reddy>>> <<<212564021>>>
 * @version 1.0 Apr 24, 2018
 * @since 1.0
 */
@Getter
@Setter
@ToString(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TreeNodeModel {
    private String id;
    private String name;
    private String description;
    private String uri;
    private String childResourcesUri;
    private String parent;
    private boolean openable;
    private List<TreeNodeModel> children;

    public void addChildren(List<TreeNodeModel> children) {
        this.children.addAll(children);
    }
}
