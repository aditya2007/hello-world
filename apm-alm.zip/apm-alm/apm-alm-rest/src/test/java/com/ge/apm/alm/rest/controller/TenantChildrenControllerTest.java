/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.rest.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.common.support.RequestContext;

import static com.ge.apm.alm.rest.controller.BaseControllerUtil.ALL_ACCESSIBLE_RESOURCES;
import static com.ge.apm.alm.rest.controller.BaseControllerUtil.TEST_TENANT1;
import static com.ge.apm.alm.rest.controller.BaseControllerUtil.TEST_TENANT2;

/**
 * TODO: Document what TenantChildrenControllerTest is.
 *
 * @author <<<Satyapal Reddy>>> <<<212564021>>>
 * @version 1.0 Apr 24, 2018
 * @since 1.0
 */
/*@RunWith(SpringRunner.class)
@WebMvcTest(value = TenantChildrenController.class, secure = false)
@ContextConfiguration(classes = { TenantChildrenControllerTest.class })
@ComponentScan({ "com.ge.apm" })*/
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { WebConfig.class })
public class TenantChildrenControllerTest {

    private static final String urlPath = "/v3/tenants/";

    @InjectMocks
    private TenantChildrenController tenantChildrenController;

    BaseControllerUtil baseControllerUtil;

    @MockBean
    protected AssetPersistencyService assetPersistencyService;

    @Before
    public void setUp() throws IllegalAccessException {
        MockitoAnnotations.initMocks(this);
        baseControllerUtil = new BaseControllerUtil(assetPersistencyService);
        baseControllerUtil.mockMvc = MockMvcBuilders.standaloneSetup(tenantChildrenController).build();
    }

    @Test
    /**
     * Scenario: /v3/tenants/<TENANT_ID>/children.
     * 1. User has access to multiple tenants.
     * 2. User has some access at non-root level (sites/segments/assets).
     * 3. User has access to multiple assets in same hierarchy.
     */
    public void getFirstLevelObjectsForSpecificTenant() throws Exception {

        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap
            .put(TEST_TENANT2, new HashSet<>(Arrays.asList("/assets/T2A7_id", "/segments/T2SEG7_id")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        baseControllerUtil.mockAssetObjects(TEST_TENANT1);

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);

        baseControllerUtil.validateSuccessResponse(urlPath + TEST_TENANT1 + "/children", mockHeaders, null,
            "/output/firstLevelObjectsSpecificTenant.json");
    }

    @Test
    /**
     * Scenario: /v3/tenants/<TENANT_ID>/children.
     * 1. User has access to multiple tenants.
     * 2. User has some access at non-root level (sites/segments/assets).
     * 3. User has access to multiple assets in same hierarchy.
     */
    public void getFirstLevelObjectsForHomeTenant() throws Exception {

        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap
            .put(TEST_TENANT1,
                new HashSet<>(Arrays.asList("/enterprises/T1E1_id", "/enterprises/T1E2_id", "/enterprises/T1E3_id")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        baseControllerUtil.mockAssetObjects(TEST_TENANT1);

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);

        baseControllerUtil.validateSuccessResponse(urlPath + TEST_TENANT1 + "/children", mockHeaders, null,
            "/output/firstLevelObjectsHomeTenant.json");
    }
}
