package com.ge.apm.alm.rest.controller;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.path.json.JsonPath;
import org.json.JSONArray;
import org.mockito.invocation.InvocationOnMock;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.rest.controller.model.LimitedAssetModel;
import com.ge.apm.common.support.RequestContext;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Created by 212438472 on 5/2/18.
 */

public class BaseControllerUtil {

    MockMvc mockMvc;

    protected static final String TEST_TENANT1 = "TEST_TENANT_1";
    protected static final String TEST_TENANT2 = "TEST_TENANT_2";
    protected static final String TEST_TENANT3 = "TEST_TENANT_3";
    protected static final String ALL_ACCESSIBLE_RESOURCES = "AllAccessibleResources";
    Map<String, LimitedAssetModel> assetHierarchies;

    BaseControllerUtil(AssetPersistencyService assetPersistencyService) {
        try {
            this.assetPersistencyService = assetPersistencyService;
            List<LimitedAssetModel> mockAssets =
                readObjectsFromResourceFile("/input/AssetModelHierarchy.json", LimitedAssetModel.class);
            assetHierarchies = Collections.unmodifiableMap(mockAssets.stream().collect(
                Collectors.toMap(LimitedAssetModel::getId, asset -> asset)));

            for (LimitedAssetModel assetModel : assetHierarchies.values()) {
                assetModel.setParent(assetHierarchies.get(assetModel.getParentId()));
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private AssetPersistencyService assetPersistencyService;

    protected <X> List<X> readObjectsFromResourceFile(String filePath, Class<X> clazz) throws IOException {
        ObjectMapper MAPPER = new ObjectMapper();
        return Arrays.asList(MAPPER.readerFor(Array.newInstance(clazz, 0).getClass()).readValue(
            this.getClass().getResourceAsStream(filePath)));
    }

    protected void validateSuccessResponse(String urlPath, Map<String, String> headers, Map<String, String> params,
        String outputFilePath) throws Exception {
        MockHttpServletRequestBuilder builder = get(urlPath);
        if (params != null) {
            params.forEach((key, value) -> builder.param(key, value));
        }
        if (headers != null) {
            headers.forEach((key, value) -> builder.header(key, value));
        }

        MockHttpServletResponse actualResponse = this.mockMvc.perform(builder)
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andReturn().getResponse();

        JSONArray expectedJsonArray;
        if (outputFilePath != null) {
            expectedJsonArray = new JSONArray((List) JSONReadFromExistingFile(outputFilePath).get());
        } else {
            expectedJsonArray = new JSONArray();
        }
        JSONArray actualJsonArray = new JSONArray(actualResponse.getContentAsString());
        JSONAssert.assertEquals(expectedJsonArray, actualJsonArray, JSONCompareMode.LENIENT);
    }

    private JsonPath JSONReadFromExistingFile(String fileName) {
        JsonPath jasonPath = new JsonPath(this.getClass().getResourceAsStream(fileName));
        return jasonPath;
    }

    protected void mockAssetObjects(String tenant) {
        given(assetPersistencyService.getAccessibleResources(eq(tenant), any(), any())).willAnswer(this::answer);
    }

    private List<LimitedAssetModel> answer(InvocationOnMock invocationOnMock) {

        Map<String, Set<String>> accessibleResources = RequestContext.get(ALL_ACCESSIBLE_RESOURCES, Map.class);
        List<LimitedAssetModel> assetModels = new ArrayList<>();
        for (Entry<String, Set<String>> accessibleResource : accessibleResources.entrySet()) {
            if (accessibleResource.getValue().contains("*")) {
                assetModels.addAll(assetHierarchies.values().stream().filter(
                    assetModel -> assetModel.getTenantId().equals(accessibleResource.getKey()) && assetModel
                        .getAssetType().equals("edf150de-d869-3741-8141-6f4c7f80254e") && StringUtils
                        .isEmpty(assetModel.getParentId())).collect(Collectors.toList()));
            } else {
                assetModels.addAll(accessibleResource.getValue().stream()
                    .map(id -> assetHierarchies.get(id.substring(id.lastIndexOf('/') + 1)))
                    .collect(Collectors.toList()));
            }
        }
        return assetModels;
    }
}
