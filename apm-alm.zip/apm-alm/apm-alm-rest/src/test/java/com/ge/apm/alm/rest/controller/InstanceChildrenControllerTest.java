/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.rest.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.common.support.RequestContext;

import static com.ge.apm.alm.rest.controller.BaseControllerUtil.ALL_ACCESSIBLE_RESOURCES;
import static com.ge.apm.alm.rest.controller.BaseControllerUtil.TEST_TENANT1;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;

/**
 * TODO: Document what TenantChildrenControllerTest is.
 *
 * @author <<<Satyapal Reddy>>> <<<212564021>>>
 * @version 1.0 Apr 24, 2018
 * @since 1.0
 */

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { WebConfig.class })
public class InstanceChildrenControllerTest {

    private static final String urlPath = "/v3/tenants/";

    @InjectMocks
    private InstanceChildrenController instanceChildrenController;

    BaseControllerUtil baseControllerUtil;

    @MockBean
    protected AssetPersistencyService assetPersistencyService;

    @Before
    public void setUp() throws IllegalAccessException {
        MockitoAnnotations.initMocks(this);
        baseControllerUtil =  new BaseControllerUtil(assetPersistencyService);
        baseControllerUtil.mockMvc = MockMvcBuilders.standaloneSetup(instanceChildrenController).build();
    }

    @Test
    public void testGetInstanceChildren() throws Exception {
        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap
            .put(TEST_TENANT1, new HashSet<>(Arrays.asList("/sites/T1S4_id", "/sites/T1S3_id")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        mockGetChildAssets(TEST_TENANT1, "T1SEG3_id");

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);

        baseControllerUtil
            .validateSuccessResponse(urlPath + TEST_TENANT1 + "/instances/T1SEG3_id/children", mockHeaders, null,
                "/output/instanceChildrenObjects.json");
    }

    @Test
    public void testGetInaccessibleChildren() throws Exception {
        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap
            .put(TEST_TENANT1, new HashSet<>(Arrays.asList("/segments/T1SEG3_id")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        mockGetChildAssets(TEST_TENANT1, "T1SEG3_id");

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);
        baseControllerUtil
            .validateSuccessResponse(urlPath + TEST_TENANT1 + "/instances/T1SEG5_id/children", mockHeaders, null,
                "/output/empty_array.json");
    }

    private void mockGetChildAssets(String tenant, String parentId) {
        given(assetPersistencyService.getChildAssets(eq(tenant), any(), eq(parentId), any()))
            .willAnswer(invocationOnMock -> {
                String parentArgumentValue = invocationOnMock.getArgument(2);
                if (StringUtils.isEmpty(parentArgumentValue)) {
                    return null;
                } else {
                    return baseControllerUtil.assetHierarchies.values().stream()
                        .filter(asset -> asset.getParentId() != null && asset.getParentId().equals(parentId))
                        .collect(Collectors.toList());
                }
            });
    }
}
