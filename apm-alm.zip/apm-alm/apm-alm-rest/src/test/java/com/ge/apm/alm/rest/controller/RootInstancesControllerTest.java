package com.ge.apm.alm.rest.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.common.support.RequestContext;

import static com.ge.apm.alm.rest.controller.BaseControllerUtil.ALL_ACCESSIBLE_RESOURCES;
import static com.ge.apm.alm.rest.controller.BaseControllerUtil.TEST_TENANT1;
import static com.ge.apm.alm.rest.controller.BaseControllerUtil.TEST_TENANT2;
import static com.ge.apm.alm.rest.controller.BaseControllerUtil.TEST_TENANT3;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { WebConfig.class })
/*@RunWith(SpringRunner.class)
@WebMvcTest(RootInstancesController.class)*/
public class RootInstancesControllerTest {

    private static final String urlPath = "/v3/root-instances";

    BaseControllerUtil baseControllerUtil;

    @InjectMocks
    private RootInstancesController rootInstancesController;

    @MockBean
    protected AssetPersistencyService assetPersistencyService;

    @Before
    public void setUp() throws IllegalAccessException {
        MockitoAnnotations.initMocks(this);
        baseControllerUtil = new BaseControllerUtil(assetPersistencyService);
        baseControllerUtil.mockMvc = MockMvcBuilders.standaloneSetup(rootInstancesController).build();
    }

    @Test
    /**
     * Scenario: /root-instances?includeTenants=true.
     * 1. User has access to multiple tenants.
     * 2. User has some access at non-root level (sites/segments/assets).
     * 3. User has access to multiple assets in same hierarchy.
     */
    public void getAllTenantObjects() throws Exception {
        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap.put(TEST_TENANT1, new HashSet<>(Arrays.asList("/enterprises/T1E1_id")));
        mockAccessibleResourceMap
            .put(TEST_TENANT2, new HashSet<>(Arrays.asList("/assets/T2A7_id", "/segments/T2SEG7_id")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);
        Map<String, String> mockParams = new HashMap<>();
        mockParams.put("includeTenants", "true");
        baseControllerUtil.validateSuccessResponse(urlPath, mockHeaders, mockParams, "/output/multiple_tenants.json");
    }

    @Test
    /**
     * Scenario: /root-instances?includeTenants=true.
     * 1. User has access to multiple tenants.
     * 2. User is an admin in one of the tenant.
     * 3. User has some access at non-root level (sites/segments/assets).
     * 4. User has access to multiple assets in same hierarchy.
     */
    public void getAllTenantObjectsIncludingAdminTenant() throws Exception {
        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap.put(TEST_TENANT1, new HashSet<>(Arrays.asList("*")));
        mockAccessibleResourceMap
            .put(TEST_TENANT2, new HashSet<>(Arrays.asList("/assets/T2A7_id", "/segments/T2SEG7_id")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);
        Map<String, String> mockParams = new HashMap<>();
        mockParams.put("includeTenants", "true");
        baseControllerUtil.validateSuccessResponse(urlPath, mockHeaders, mockParams, "/output/multiple_tenants.json");
    }

    @Test
    /**
     * Scenario: /root-instances?includeTenants=true&tenantId=<TENANT_ID>.
     * 1. User has access to multiple tenants.
     * 2. User has some access at non-root level (sites/segments/assets).
     * 3. User has access to multiple assets in same hierarchy.
     */
    public void getSpecificTenantObject() throws Exception {
        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap.put(TEST_TENANT1, new HashSet<>(Arrays.asList("/enterprises/T1E1_id")));
        mockAccessibleResourceMap
            .put(TEST_TENANT2, new HashSet<>(Arrays.asList("/assets/T2A7_id", "/segments/T2SEG7_id")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);
        Map<String, String> mockParams = new HashMap<>();
        mockParams.put("includeTenants", "true");
        mockParams.put("tenantId", TEST_TENANT2);
        baseControllerUtil.validateSuccessResponse(urlPath, mockHeaders, mockParams, "/output/single_tenant.json");
    }

    @Test
    /**
     * Scenario: /root-instances?includeTenants=true&tenantId=<TENANT_ID>.
     * 1. User has access to multiple tenants.
     * 2. User is an admin in one of the tenant.
     * 3. User has some access at non-root level (sites/segments/assets).
     * 4. User has access to multiple assets in same hierarchy.
     */
    public void getSpecificTenantObjectForNonAdminTenant() throws Exception {
        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap.put(TEST_TENANT1, new HashSet<>(Arrays.asList("*")));
        mockAccessibleResourceMap
            .put(TEST_TENANT2, new HashSet<>(Arrays.asList("/assets/T2A7_id", "/segments/T2SEG7_id")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);
        Map<String, String> mockParams = new HashMap<>();
        mockParams.put("includeTenants", "true");
        mockParams.put("tenantId", TEST_TENANT2);
        baseControllerUtil.validateSuccessResponse(urlPath, mockHeaders, mockParams, "/output/single_tenant.json");
    }

    @Test
    /**
     * Negative Scenario: /root-instances?includeTenants=true&tenantId=<TENANT_ID>.
     * 1. User is trying to access tenant that he doesn't has access.
     */
    public void getSpecificTenantObjectNotInTheAccessibleResources() throws Exception {
        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap.put(TEST_TENANT1, new HashSet<>(Arrays.asList("/enterprises/T1E1_id")));
        mockAccessibleResourceMap
            .put(TEST_TENANT2, new HashSet<>(Arrays.asList("/assets/T2A7_id", "/segments/T2SEG7_id")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);
        Map<String, String> mockParams = new HashMap<>();
        mockParams.put("includeTenants", "true");
        mockParams.put("tenantId", TEST_TENANT3);
        baseControllerUtil.validateSuccessResponse(urlPath, mockHeaders, mockParams, "/output/empty_array.json");
    }

    @Test
    /**
     * Scenario: /root-instances?includeTenants=false.
     * 1. User has access to multiple tenants.
     * 2. User has some access at non-root level (sites/segments/assets).
     * 3. User has access to multiple assets in same hierarchy.
     */
    public void getFirstLevelObjects() throws Exception {

        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap.put(TEST_TENANT1, new HashSet<>(Arrays.asList("/enterprises/T1E1_id")));
        mockAccessibleResourceMap
            .put(TEST_TENANT2, new HashSet<>(Arrays.asList("/assets/T2A7_id", "/segments/T2SEG7_id")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        baseControllerUtil.mockAssetObjects(TEST_TENANT1);

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);

        baseControllerUtil.validateSuccessResponse(urlPath, mockHeaders, null, "/output/firstLevelObjects.json");
    }

    @Test
    /**
     * Scenario: /root-instances?includeTenants=false&tenantId=<TENANT_ID>.
     * 1. User has access to multiple tenants.
     * 2. User has some access at non-root level (sites/segments/assets).
     * 3. User has access to multiple assets in same hierarchy.
     */
    public void getFirstLevelObjectsForSpecificTenant() throws Exception {

        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap
            .put(TEST_TENANT2, new HashSet<>(Arrays.asList("/assets/T2A7_id", "/segments/T2SEG7_id")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        baseControllerUtil.mockAssetObjects(TEST_TENANT1);

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);
        Map<String, String> mockParams = new HashMap<>();
        mockParams.put("includeTenants", "false");
        mockParams.put("tenantId", TEST_TENANT2);

        baseControllerUtil
            .validateSuccessResponse(urlPath, mockHeaders, mockParams, "/output/firstLevelObjectsSpecificTenant.json");
    }

    @Test
    /**
     * Negative Scenario: /root-instances?includeTenants=false&tenantId=<TENANT_ID>.
     * 1. User has access to multiple tenants.
     * 2. User has some access at non-root level (sites/segments/assets).
     * 3. User has access to multiple assets in same hierarchy.
     */
    public void getFirstLevelObjectsForTenantNotHaveAccess() throws Exception {

        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap.put(TEST_TENANT3, new HashSet<>(Arrays.asList("")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);

        Map<String, String> mockParams = new HashMap<>();
        mockParams.put("tenantId", TEST_TENANT3);
        baseControllerUtil.validateSuccessResponse(urlPath, mockHeaders, mockParams, "/output/empty_array.json");
    }

    @Test
    /**
     * Scenario: /root-instances?includeTenants=false.
     * 1. User has access to multiple tenants.
     * 2. User is an admin in one of the tenant.
     * 3. User has some access at non-root level (sites/segments/assets).
     * 4. User has access to multiple assets in same hierarchy.
     */
    public void getFirstLevelObjectsIncludingAdminTenant() throws Exception {

        Map<String, Set<String>> mockAccessibleResourceMap = new HashMap<>();
        mockAccessibleResourceMap.put(TEST_TENANT1, new HashSet<>(Arrays.asList("*")));
        mockAccessibleResourceMap
            .put(TEST_TENANT2, new HashSet<>(Arrays.asList("/assets/T2A7_id", "/segments/T2SEG7_id")));
        RequestContext.put(ALL_ACCESSIBLE_RESOURCES, mockAccessibleResourceMap);

        baseControllerUtil.mockAssetObjects(TEST_TENANT1);

        Map<String, String> mockHeaders = new HashMap<>();
        mockHeaders.put("tenant", TEST_TENANT1);
        baseControllerUtil
            .validateSuccessResponse(urlPath, mockHeaders, null, "/output/firstLevelObjectsIncludingAdminTenant.json");
    }
}
