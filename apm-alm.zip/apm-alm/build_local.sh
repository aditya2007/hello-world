#!/bin/bash
# This is the script to check sonar and clover and run the local build

expectedCoverage=90
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

# run sonar 
mvn clean verify -DskipTests=true sonar:sonar -Dsonar.analysis.mode=preview -Dsonar.issuesReport.json.enable=true -Dsonar.report.export.path=report.json -Dsonar.host.url=http://3.39.73.153:9000 -Dsonar.login=apm-dev -Dsonar.password=Pa55w0rd -s menlo_settings.xml

# check sonar report
blockers=`jq ".issues" target/sonar/report.json | grep severity | grep BLOCKER | wc -l`
criticals=`jq ".issues" target/sonar/report.json | grep severity | grep CRITICAL | wc -l`
totalViolations=$(( $blockers + $criticals ))
if [ $totalViolations -ge 1 ]; then
    printf "%b" "${RED}Please fix the sonar report(http://3.39.73.153:9000/): There are $(( $blockers * 1 )) blocker issues and $(( $criticals * 1 )) critical issues.\n${NC}"
    return 1
fi

# run clover report
mvn -U clean -Dcheckstyle.skip=true -Dexcludes=**/target/**/* -Pclover.report clover2:setup verify clover2:check clover2:aggregate clover2:clover -s menlo_settings.xml
if [ $? -ne 0 ]; then
    printf "${RED}There are errors when generating clover report for code coverage.\n${NC}"
    return 0
fi

# get code coverage
localDir=./target/site/clover
data=`cat $localDir/project.js`
echo $data | tr -d ' ' | sed 's/.\{2\}$//' | sed 's/^.\{14\}//' > $localDir/formatted.json
actualCoverage=`jq ".stats.TotalPercentageCovered" $localDir/formatted.json | cut -d "." -f1`

# check coverage
if [ $actualCoverage -ge $expectedCoverage ]; then
    printf "%b" "${GREEN}Code coverage check is successful. Code coverage is $actualCoverage, which is above $expectedCoverage.\n${NC}"
    return 0
else
    printf "%b" "${RED}Code coverage check is failed. Code coverage is $actualCoverage, which is below $expectedCoverage.\n${NC}"
    return 1
fi

mvn -U clean install -s menlo_settings.xml
