#Jenkins build script for code coverage
export uniqId=`openssl rand -hex 24`
export MVN_REPO=“${WORKSPACE}/.m2ApmAlm-code-coverage_${BUILD_NUMBER}_${uniqId}”
mkdir -p ${MVN_REPO}
export MAVEN_OPTS="-Dmaven.repo.local=${MVN_REPO}"
export JAVA_HOME=${JAVA_HOME_ORACLEJDK8}
export PATH=${JAVA_HOME}/bin:${PATH}
mvn -U clean -Dcheckstyle.skip=true -Pclover.report clover2:setup verify clover2:check clover2:aggregate clover2:clover -s menlo_settings.xml -Denv=jenkins
RET=$?
rm -rf ${MVN_REPO}
if [ $RET -eq 0 ]; then
        exit 0
else
        echo "Build Failed"
        exit 1
fi

