/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.service;

import java.util.Collection;
import java.util.List;

import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;

public interface TagService {

    //create
    Tag createTag(String tenantId, Collection<String> accessibleResources, Tag tag)
        throws PersistencyServiceException;

    int deleteTag(String tenantId, Collection<String> accessibleResources, String tagId)
        throws PersistencyServiceException;

    Tag getTagById(String tenantId, Collection<String> accessibleResources, String id);

    Tag getTagBySourceKey(String tenantId, Collection<String> accessibleResources, String sourceKey);

    //collections
    List<Tag> getTags(String tenantId, Collection<String> accessibleResources, TagPredicate tagPredicate);

    List<Tag> getTagsForAsset(String tenantId, Collection<String> accessibleResources, String assetId,
        boolean deepSearch, TagPredicate tagPredicate);
}
