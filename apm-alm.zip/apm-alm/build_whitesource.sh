#!/usr/bin/env bash
export JAVA_HOME=${JAVA_HOME_ORACLEJDK8}
export PATH=${JAVA_HOME}/bin:${PATH}

mvn clean install whitesource:update -DskipTests -DskipPlugins -Dpmd.skip=true -Dwss.url=https://ws.ci.build.ge.com/agent -s menlo_settings.xml