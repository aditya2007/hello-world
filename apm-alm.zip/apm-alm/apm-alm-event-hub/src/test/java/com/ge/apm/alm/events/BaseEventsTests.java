/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.events;

import java.io.IOException;
import java.io.InputStream;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;

import com.ge.apm.alm.events.handler.EventhubHelper;
import com.ge.apm.alm.events.handler.ProtocolDetails;
import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.persistence.jpa.entity.AssetEventEntity;
import com.ge.apm.service.instances.ServiceInstanceInfo;
import com.ge.apm.service.instances.ServiceInstances;
import com.ge.predix.eventhub.EventHubClientException;
import com.ge.predix.eventhub.configuration.EventHubConfiguration;
import com.ge.predix.eventhub.configuration.PublishAsyncConfiguration;

/**
 * Created by Yogananda Gowda - 212590467 on 7/12/17.
 */
@Slf4j
public class BaseEventsTests {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    protected static final String TEST_USER = "test-admin";
    protected static final String TEST_OBJ_NAME = "test-event";
    protected static final String TEST_SRC_KEY = "test-event-src-key";
    protected static final String TEST_TENANT = "f743b7ef-42df-4d7e-89dd-90dc3b53b0ac";
    protected static final String TEST_TENANT1 = "a111b1ce-42df-4d7e-89dd-90dc3b53b1ac";
    protected static final String TEST_EVENT = "a83d1532-eacf-455c-8200-6a245a820010";
    protected static final String ASSET_TYPE = "963068c7-1181-451a-9750-e61f6dacb339";
    protected static final String OBJECT_TYPE_ASSET = "Asset";
    protected static final String OBJECT_TYPE_TAG = "Tag";
    protected static final String TAG_TYPE = "963068c7-1181-451a-9750-e61f6dacb338";
    protected static final String MODIFIED = "-modified";
    protected static final String SERVICE_NAME = "predix-event-hub";
    protected static final String PUBLISH_PATH = "/credentials/publish";
    protected static final String PROTOCOL_PATH = "/credentials/publish/protocol_details";
    protected static final String ZONE_VALUE_PATH = "/credentials/publish/zone-http-header-value";
    protected static final String TENANTINFO_FILE_NAME = "/sample2_tenant_info.json";
    protected static final String PROTOCOL = "grpc";
    protected String UAA_URI = "https://stuf-rc.run.asv-pr.ice.predix.io/admin-mtmkh5jep/oauth/token";
    protected String CLIENT_ID = "12pspvp704hwlacshcbvfwe7mn5qaj90t3kepi";
    protected String CLIENT_SECRET = "zwu8eiug1yvwdxyh6rkdt8rgjdfnjfeu40hyy";


    public List<AssetEvent> createEvents(String id, String type) {
        List<AssetEvent> events = new ArrayList<>();
        String objectId = newUuid();
        JsonNode preModifiedObject = convertBizObjToJsonNode(
                                        createAssetInstance(id, TEST_OBJ_NAME, TEST_SRC_KEY));
        JsonNode modifiedObject = convertBizObjToJsonNode(
                                        updateAssetInstance(id, TEST_OBJ_NAME + MODIFIED, TEST_SRC_KEY));
        AssetEvent createEvent = createEvent(TEST_TENANT, objectId, type, AssetEvent.Type.CREATE,
                                                                                         null, preModifiedObject);
        AssetEvent updateEvent = createEvent(TEST_TENANT,objectId,type,AssetEvent.Type.UPDATE,
                                                                                 preModifiedObject,modifiedObject);
        AssetEvent deleteEvent =  createEvent(TEST_TENANT,objectId,type,AssetEvent.Type.DELETE,
                                                                       preModifiedObject, null);
        events.add(createEvent);
        events.add(updateEvent);
        events.add(deleteEvent);
        return events;
    }



    protected AssetEvent createEvent(String tenantId, String objectId, String objectType,
                                     AssetEvent.Type eventType, JsonNode preModifiedObject,
                                     JsonNode  modifiedBizObject) {
        return AssetEventEntity.builder()
                .id(newUuid())
                .tenantId(tenantId)
                .objectId(objectId)
                .objectType(objectType)
                .eventType(eventType)
                .preModifiedObject(preModifiedObject)
                .modifiedBizObject(modifiedBizObject)
                .objectLastModifiedDate(OffsetDateTime.now())
                .createdBy(TEST_USER)
                .lastModifiedBy(TEST_USER)
                .predixPubStatus(AssetEvent.EventStatus.QUEUED)
                .auditPubStatus(AssetEvent.EventStatus.QUEUED)
                .eventhubPubStatus(AssetEvent.EventStatus.QUEUED)
                .build();
    }

    public Asset createAssetInstance(String assetType, String name, String srcKey) {
        return AssetInstance.builder().
                id(newUuid()).tenantId(TEST_TENANT).sourceKey(srcKey).
                name(name).label(name).description(name).
                assetType(ASSET_TYPE).build();
    }

    public Asset updateAssetInstance(String assetType, String name, String srcKey) {
        return AssetInstance.builder().
                id(newUuid()).tenantId(TEST_TENANT).sourceKey(srcKey).
                name(name).label(name).description(name).
                assetType(ASSET_TYPE).build();
    }

    protected String newUuid() {
        return UUID.randomUUID().toString();
    }

    private JsonNode convertBizObjToJsonNode(Asset asset) {
        return OBJECT_MAPPER.convertValue(asset, JsonNode.class);
    }

    private JsonNode createJsonNode(String objectId) {
        try {
            return OBJECT_MAPPER.reader().readTree("{objectId}");
        } catch (IOException ex) {
            log.error("Exception while creating JsonNode {}, ", ex);
        }
        return null;
    }

    public JsonNode getProtocolDetails(String fileName, String nodePath) {
        JsonNode serviceInstanceNode = null;
        try {
            JsonNode root = OBJECT_MAPPER.readTree(readEventHubInfoFromFile(fileName));
            ArrayNode serviceInstancesNode = (ArrayNode) root.get("serviceInstances");

            for (int nodeIdx = 0; nodeIdx < serviceInstancesNode.size(); ++nodeIdx) {
                JsonNode ex = serviceInstancesNode.get(nodeIdx);
                JsonNode serviceNameNode = ex.get("serviceName");
                if (serviceNameNode != null && SERVICE_NAME.equals(serviceNameNode.asText())) {
                    serviceInstanceNode = ex;
                    break;
                }
            }
        } catch (Exception ex ) {
            log.error("Exception while getting ProtocolDetails {}, ", ex);
        }
        return serviceInstanceNode.at(nodePath) != null ? serviceInstanceNode.at(nodePath) : null;
    }

    public ServiceInstanceInfo getServiceInstanceInfo(String fileName, String nodePath) {
        JsonNode serviceInstanceNode = null;
        try {
            JsonNode root = OBJECT_MAPPER.readTree(readEventHubInfoFromFile(fileName));
            ArrayNode serviceInstancesNode = (ArrayNode) root.get("serviceInstances");

            for (int nodeIdx = 0; nodeIdx < serviceInstancesNode.size(); ++nodeIdx) {
                JsonNode ex = serviceInstancesNode.get(nodeIdx);
                JsonNode serviceNameNode = ex.get("serviceName");
                if (serviceNameNode != null && SERVICE_NAME.equals(serviceNameNode.asText())) {
                    serviceInstanceNode = ex;
                    break;
                }
            }
        } catch (Exception ex ) {
            log.error("Exception while getting ServiceInstanceInfo {}, ", ex);
        }

        ServiceInstanceInfo instanceInfo = new ServiceInstanceInfo();
        if (serviceInstanceNode != null) {
            instanceInfo.setZoneHeaderValue(serviceInstanceNode.at(ZONE_VALUE_PATH).asText());
            instanceInfo.setProtocolDetails(serviceInstanceNode.at(nodePath));
        }
        return instanceInfo;
    }

    private InputStream readEventHubInfoFromFile(String filePath ) throws IOException {
        return this.getClass().getResourceAsStream(filePath);
    }

    protected EventHubConfiguration constructEventHubConfig() {
        EventHubConfiguration configuration = null;
        try{
            String[] hostPort = null;
            String authScopes = null;

            ServiceInstanceInfo serviceInstanceInfo = getServiceInstanceInfo(TENANTINFO_FILE_NAME, PROTOCOL_PATH);

            ProtocolDetails[] protocolDetails = EventhubHelper.convert(serviceInstanceInfo.getProtocolDetails());
            for (ProtocolDetails protocol : protocolDetails) {
                if (EventhubHelper.PROTOCOL.equals(protocol.getProtocol())) {
                    hostPort = EventhubHelper.getHostAndPort(protocol.getUri());
                    authScopes = (protocol.getTokenScopes() != null
                            && !protocol.getTokenScopes().isEmpty() )
                            ? String.join(",", protocol.getTokenScopes()) : null;
                }
            }

            if (null != hostPort && hostPort.length > 1 && StringUtils.isNotEmpty(authScopes)) {
                configuration = new EventHubConfiguration.Builder()
                        .host(hostPort[0])
                        .port(Integer.parseInt(hostPort[1]))
                        .zoneID(serviceInstanceInfo.getZoneHeaderValue())
                        .clientID(CLIENT_ID)
                        .clientSecret(CLIENT_SECRET)
                        .authURL(UAA_URI)
                        .authScopes(authScopes)
                        .publishConfiguration(
                                new PublishAsyncConfiguration.Builder()
                                        .ackType(PublishAsyncConfiguration.AcknowledgementOptions.ACKS_AND_NACKS)
                                        .cacheAckIntervalMillis(100).build())
                        .build();
            }
        } catch (EventHubClientException.InvalidConfigurationException eh) {
            log.error("EventHubClientException while construction EventhubConfiguration {}", eh);
        } catch (Exception e) {
            log.error("Exception while construction EventhubConfiguration {}", e);
        }
        //if (log.isDebugEnabled()) {
        log.debug("Event Hub Credentials {} ", configuration);
        //}
        return configuration;
    }

    protected List<ServiceInstances.TenantInfo> getTenants() {
        List<ServiceInstances.TenantInfo> tenants = new ArrayList<>();
        ServiceInstances.TenantInfo tenant = new ServiceInstances.TenantInfo();
        tenant.setTenantUuid(TEST_TENANT);
        tenants.add(tenant);
        return tenants;
    }

}
