/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.events;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.ge.apm.alm.events.handler.EventhubHelper;
import com.ge.apm.alm.events.handler.EventhubJob;
import com.ge.apm.alm.events.services.AssetEventhubService;
import com.ge.apm.alm.events.services.AssetEventhubServiceImpl;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.EventsJobType;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.AssetEventPersistencyServiceImpl;
import com.ge.apm.alm.persistence.jpa.AssetPersistencyServiceImpl;
import com.ge.apm.datasource.TenantDataSourceService;
import com.ge.predix.eventhub.EventHubClientException;
import com.ge.predix.eventhub.Messages;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

/**
 * Created by Yogananda Gowda - 212590467 on 7/13/17.
 */
@Slf4j
public class EventhubJobTests extends BaseEventsTests {

    private EventhubJob job;

    private AssetEventPersistencyService assetEventPersistencyService;

    private AssetPersistencyService assetPersistencyService;

    private AssetEventhubService eventHubService;

    private TenantDataSourceService tenantDataSourceService;

    private EventhubHelper helper;

    private String query;

    public static final ObjectMapper MAPPER = new ObjectMapper();

    @Before
    public void setupMock() {
        mockStatic(EventhubHelper.class);
        assetEventPersistencyService = mock(AssetEventPersistencyServiceImpl.class);
        assetPersistencyService = mock(AssetPersistencyServiceImpl.class);
        eventHubService = mock(AssetEventhubServiceImpl.class);
        tenantDataSourceService = mock(TenantDataSourceService.class);
        job = new EventhubJob();

        ReflectionTestUtils.setField( job, "assetEventPersistencyService", assetEventPersistencyService );
        ReflectionTestUtils.setField( job, "assetPersistencyService", assetPersistencyService );
        ReflectionTestUtils.setField( job, "eventHubService", eventHubService );
        ReflectionTestUtils.setField(job, "tenantDataSourceService", tenantDataSourceService);
        ReflectionTestUtils.setField( job, "jobSize", 100 );
        ReflectionTestUtils.setField( job, "jobTimeoutMillis", 60000l );
        ReflectionTestUtils.setField( job, "expiredTimeoutMillis", 864000000l );
    }

    @Test
    public void testDoExecute() throws PersistencyServiceException, EventHubClientException {
        when(assetEventPersistencyService.getPendingEventBatch(any(), anyInt(), anyLong(), anyLong()))
                .thenReturn(createEvents(ASSET_TYPE, OBJECT_TYPE_ASSET));
        when(assetPersistencyService.getAssetById(anyString(), anyList(), anyString()))
                                            .thenReturn(createAssetInstance(ASSET_TYPE,TEST_OBJ_NAME, TEST_SRC_KEY));

        job.doExecute();

        Map<String, Messages.Builder> tenantBuilderMap = EventhubHelper.getEventMessages(
                assetEventPersistencyService.getPendingEventBatch(EventsJobType.EVENTHUB, 100, 60000l,864000000l),
            assetPersistencyService);
        Assert.assertNotNull(tenantBuilderMap);
        Assert.assertTrue("Size of Messages and Tenant less than 1, ", tenantBuilderMap.size() == 1);
        Assert.assertTrue("Number of messages not equal to 3, ",
                                        tenantBuilderMap.get(TEST_TENANT).build().getMsgCount() == 3);
        for (Map.Entry<String, Messages.Builder> entry : tenantBuilderMap.entrySet()) {
             Messages messages = entry.getValue().build();
            messages.getMsgList().forEach(m -> {
                try {
                    Message messageBody = MAPPER.readValue(m.getBody().toStringUtf8(), Message.class);
                    System.out.println(messageBody.getModifiedData());
                } catch (IOException e) {
                    e.printStackTrace();
                }

            });
        }
    }

    @Test
    public void testDoExecuteForNoEvents() throws PersistencyServiceException, EventHubClientException {
        when(assetEventPersistencyService.getPendingEventBatch(any(), anyInt(), anyLong(), anyLong()))
            .thenReturn(new ArrayList<AssetEvent>());
        when(assetPersistencyService.getAssetById(anyString(), anyList(), anyString()))
            .thenReturn(createAssetInstance(ASSET_TYPE,TEST_OBJ_NAME, TEST_SRC_KEY));

        job.doExecute();

        Map<String, Messages.Builder> tenantBuilderMap = EventhubHelper.getEventMessages(
            assetEventPersistencyService.getPendingEventBatch(
                    EventsJobType.EVENTHUB, 100, 60000l, 864000000l), assetPersistencyService);
        Assert.assertNotNull(tenantBuilderMap);
        Assert.assertTrue("Size of Messages and Tenant greater than 0, ", tenantBuilderMap.size() == 0);
    }

    @Test
    public void testDoExecuteException() throws PersistencyServiceException, EventHubClientException {
        when(assetEventPersistencyService.getPendingEventBatch
            (any(), anyInt(), anyLong(), anyLong())).thenThrow(new PersistencyServiceException("Testing"));
        when(assetPersistencyService.getAssetById(anyString(), anyList(), anyString()))
            .thenReturn(createAssetInstance(ASSET_TYPE,TEST_OBJ_NAME, TEST_SRC_KEY));
        job.doExecute();
    }

    @Getter
    @Setter
    static class Message {

        private String objectId;
        private String tenantId;
        private String sourceKey;
        private String monitoredEntityUri;
        private String monitoredEntitySourceKey;
        private JsonNode modifiedData;
        private String objectType;
        private String eventType;
        private String user;
        private String createOrUpdatedDate;
    }
}
