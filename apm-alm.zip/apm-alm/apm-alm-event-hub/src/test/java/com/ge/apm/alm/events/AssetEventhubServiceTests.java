/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.events;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.IntStream;

import com.google.protobuf.ByteString;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.ge.apm.alm.events.handler.EventhubHelper;
import com.ge.apm.alm.events.services.AssetEventhubServiceImpl;
import com.ge.apm.alm.model.AssetEvent.EventsJobType;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.AssetEventPersistencyServiceImpl;
import com.ge.apm.service.properties.ApmProperties;
import com.ge.apm.service.instances.ServiceInstances;
import com.ge.apm.service.tenants.TenantsUtil;
import com.ge.predix.eventhub.Ack;
import com.ge.predix.eventhub.EventHubClientException;
import com.ge.predix.eventhub.Message;
import com.ge.predix.eventhub.Messages;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by Yogananda Gowda - 212590467 on 7/13/17.
 */
@Slf4j
public class AssetEventhubServiceTests extends BaseEventsTests {

    private AssetEventhubServiceImpl assetEventhubService;

    private AssetEventPersistencyService assetEventPersistencyService;

    private ServiceInstances serviceInstances;

    private TenantsUtil tenantsUtil;

    private ApmProperties apmProperties;

    private String query;

    AssetEventhubServiceImpl assetEventSvcImpl;

    @Before
    public void setUpMock() {
        assetEventPersistencyService = mock(AssetEventPersistencyServiceImpl.class);
        serviceInstances = mock(ServiceInstances.class);
        tenantsUtil = mock(TenantsUtil.class);
        apmProperties = mock(ApmProperties.class);
        assetEventhubService = new AssetEventhubServiceImpl();
        ReflectionTestUtils.setField( assetEventhubService, "serviceInstances", serviceInstances );
        ReflectionTestUtils.setField( assetEventhubService, "tenantsUtil", tenantsUtil );
        ReflectionTestUtils.setField(
                assetEventhubService, "assetEventPersistencyService", assetEventPersistencyService );
        ReflectionTestUtils.setField( assetEventhubService, "uaaUri", UAA_URI );
        ReflectionTestUtils.setField( assetEventhubService, "clientId", CLIENT_ID );
        ReflectionTestUtils.setField( assetEventhubService, "clientSecret", CLIENT_SECRET );
		Map<String, String> messageIdsToTenantMap = new ConcurrentHashMap<>();
		messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820010", TEST_TENANT);
		messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820011", TEST_TENANT);
		messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820012", TEST_TENANT);
		messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820013", TEST_TENANT);
		messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820014", TEST_TENANT);
		messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820015", TEST_TENANT);
		messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820016", TEST_TENANT);
		messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820017", TEST_TENANT);
		messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820018", TEST_TENANT);
		messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820019", TEST_TENANT);
		messageIdsToTenantMap.put("b83d1532-eacf-455c-8200-6a245a830010", TEST_TENANT1);
		messageIdsToTenantMap.put("b83d1532-eacf-455c-8200-6a245a830011", TEST_TENANT1);
		messageIdsToTenantMap.put("b83d1532-eacf-455c-8200-6a245a830012", TEST_TENANT1);
		ReflectionTestUtils.setField( assetEventhubService, "messageIdsToTenantMap", messageIdsToTenantMap);
		Map<String, List<String>> tenantIdToMessageIdsMap = new HashMap<>();
		ReflectionTestUtils.setField( assetEventhubService, "tenantIdToMessageIdsMap", tenantIdToMessageIdsMap);
    }

    @Test
    public void testPublishToEventhub()
            throws PersistencyServiceException, EventHubClientException {

        when(tenantsUtil.getAllTenantServiceInfo()).thenReturn(getTenants());

        when(serviceInstances.getServiceInstanceInfo(anyString(), anyString()))
                    .thenReturn(getServiceInstanceInfo(TENANTINFO_FILE_NAME, PROTOCOL_PATH));

        when(assetEventPersistencyService.getPendingEventBatch(EventsJobType.EVENTHUB, 100, 5000l, 864000000l))
                .thenReturn(createEvents(ASSET_TYPE, OBJECT_TYPE_ASSET));

        Map<String, Messages.Builder> tenantBuilderMap = EventhubHelper.getEventMessages(
                assetEventPersistencyService.getPendingEventBatch(
                        EventsJobType.EVENTHUB, 100, 5000l, 864000000l), null);

        assetEventhubService.publishToEventhub(TEST_TENANT, tenantBuilderMap.get(TEST_TENANT).build());

        assertNotNull("There are no event messages ", tenantBuilderMap);
        assertTrue(tenantBuilderMap.size() == 1);
        assertTrue(tenantBuilderMap.get(TEST_TENANT).getMsgCount() == 3);

        //Test using eventHubClient which is populated already
        assetEventhubService.publishToEventhub(TEST_TENANT, tenantBuilderMap.get(TEST_TENANT).build());
        assertNotNull("There are no event messages ", tenantBuilderMap);
        assertTrue(tenantBuilderMap.size() == 1);
        assertTrue(tenantBuilderMap.get(TEST_TENANT).getMsgCount() == 3);

    }

    @Test(expected = RuntimeException.class)
    public void testPublishToEventhubException()
        throws PersistencyServiceException, EventHubClientException {

        when(tenantsUtil.getAllTenantServiceInfo()).thenReturn(getTenants());

        when(serviceInstances.getServiceInstanceInfo(anyString(), anyString()))
            .thenThrow(new RuntimeException("Testing"));

        when(assetEventPersistencyService.getPendingEventBatch(
                EventsJobType.EVENTHUB, 100, 5000l, 864000000l)).thenReturn(createEvents(ASSET_TYPE,
            OBJECT_TYPE_ASSET));

        Map<String, Messages.Builder> tenantBuilderMap = EventhubHelper.getEventMessages(
            assetEventPersistencyService.getPendingEventBatch(EventsJobType.EVENTHUB, 100, 5000l, 864000000l), null);

        assetEventhubService.publishToEventhub(TEST_TENANT, tenantBuilderMap.get(TEST_TENANT).build());
    }

    @Test
    public void testPublishToEventhubEmptyMessages()
        throws PersistencyServiceException, EventHubClientException {
        Messages messages = null;
        assetEventhubService.publishToEventhub(TEST_TENANT, messages);
        assertNull(messages);
    }

    @Test
    public void testPublishToEventhubMessageLimit()
        throws PersistencyServiceException, EventHubClientException {

        when(tenantsUtil.getAllTenantServiceInfo()).thenReturn(getTenants());

        when(serviceInstances.getServiceInstanceInfo(anyString(), anyString()))
            .thenReturn(getServiceInstanceInfo(TENANTINFO_FILE_NAME, PROTOCOL_PATH));

        when(assetEventPersistencyService.getPendingEventBatch(
                EventsJobType.EVENTHUB, 100, 5000l, 864000000l)).thenReturn
            (createEvents
            (ASSET_TYPE,
            OBJECT_TYPE_ASSET));

        Messages.Builder builder  = Messages.newBuilder().addMsg(Message.newBuilder().setId("1").setBody(ByteString
            .copyFromUtf8("Testing")));
        for (int i = 0; i<1024; i++){
            builder.addMsg(Message.newBuilder().setId("1").setBody(ByteString
                .copyFromUtf8("Testing")));
        }
        Messages messages = builder.build();
        assetEventhubService.publishToEventhub(TEST_TENANT, messages);
    }

    @Test
    public void testUpdateEventhubPubStatus() throws PersistencyServiceException {
        when(assetEventPersistencyService.updateEvent(anyString(), anyObject(), anyString())).thenReturn(1);
        int updatedCnt = assetEventhubService.updateEventhubPubStatus(TEST_EVENT);
        assertTrue("Number of events updated are less than 1 ", updatedCnt == 1);
    }

    @Test
    public void testEventHubAck() throws Exception {
        List<Ack> list = new ArrayList<>();
        Method method = assetEventhubService.getClass().getDeclaredMethod("eventHubAck", List.class);
        method.setAccessible(true);
        method.invoke(assetEventhubService, list);

		Ack ack = Ack.newBuilder().setId("1").setStatusCodeValue(1).build();
		list.add(ack);
		method.invoke(assetEventhubService, list);

		list.clear();
		Ack ack0 = Ack.newBuilder().setId("a83d1532-eacf-455c-8200-6a245a820010").setStatusCodeValue(1).build();
		list.add(ack0);
		Ack ack1 = Ack.newBuilder().setId("a83d1532-eacf-455c-8200-6a245a820012").setStatusCodeValue(1).build();
		list.add(ack1);
        method.invoke(assetEventhubService, list);

		list.clear();
		Ack ack2 = Ack.newBuilder().setId("b83d1532-eacf-455c-8200-6a245a830010").setStatusCodeValue(1).build();
		list.add(ack2);
		Ack ack3 = Ack.newBuilder().setId("b83d1532-eacf-455c-8200-6a245a830011").setStatusCodeValue(1).build();
		list.add(ack3);
		Ack ack4 = Ack.newBuilder().setId("a83d1532-eacf-455c-8200-6a245a820011").setStatusCodeValue(1).build();
		list.add(ack4);
		method.invoke(assetEventhubService, list);

	}

    @Test
    public void testEventHubAcks() throws Exception {
        List<Ack> list = new ArrayList<>();
        Method method = assetEventhubService.getClass().getDeclaredMethod("eventHubAck", List.class);
        method.setAccessible(true);
        method.invoke(assetEventhubService, list);

        method.invoke(assetEventhubService, createAcks());
    }

    private List<Ack> createAcks() {
        List<Ack> list = new ArrayList<>();
        IntStream.range(0,10).forEach(idx -> {
            Ack ack = Ack.newBuilder().setId("a83d1532-eacf-455c-8200-6a245a82001" + idx).setStatusCodeValue(1)
				.build();
            list.add(ack);
        });
        return list;
    }

    @Test
    public void testEventHubAckException() throws Exception {
        when(assetEventPersistencyService.updateEvent(anyString(), anyObject(), anyString())).thenThrow(new
            PersistencyServiceException("Testing"));
        List<Ack> list = new ArrayList<>();
        Method method = assetEventhubService.getClass().getDeclaredMethod("eventHubAck", List.class);
        method.setAccessible(true);
        Ack ack = Ack.newBuilder().setId("1").setStatusCodeValue(1).build();
        list.add(ack);
        method.invoke(assetEventhubService, list);
    }
}
