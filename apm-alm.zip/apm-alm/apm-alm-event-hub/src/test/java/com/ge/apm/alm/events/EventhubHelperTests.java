/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.events;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.mockito.Mockito;

import com.ge.apm.alm.events.handler.EventhubHelper;
import com.ge.apm.alm.events.handler.ProtocolDetails;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.predix.eventhub.Message;
import com.ge.predix.eventhub.Messages;
import com.ge.predix.eventhub.Messages.Builder;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;


/**
 * Created by Yogananda Gowda - 212590467 on 7/12/17.
 */
public class EventhubHelperTests extends BaseEventsTests {

    @Test
    public void testGetEventMessages() {
        Map<String, Messages.Builder> tenantBuilderMap = EventhubHelper.getEventMessages(createEvents(ASSET_TYPE,
            OBJECT_TYPE_ASSET),
            null);
        assertNotNull("There are no Events found, events map is null", tenantBuilderMap);

        verify(tenantBuilderMap);
    }

    private void verify(Map<String, Builder> tenantBuilderMap) {
        tenantBuilderMap.forEach((tenantId, builder) -> {
            Messages messages = builder.build();
            assertTrue(messages.getMsgCount() == 3);
            List<Message> msgList = messages.getMsgList();
            assertNotNull("There are no eventhub messages, msgList is null", msgList);
            msgList.stream().forEach(message -> {
                assertNotNull("Event Message Body is null", message.getBody());
            });
        });
    }

    @Test
    public void testGetEventMessagesForTag() {
        AssetPersistencyService assetPersistencyService = Mockito.mock(AssetPersistencyService.class);
        AssetInstance asset = new AssetInstance();
        asset.setSourceKey("testKey");
        Mockito.doReturn(asset).when(assetPersistencyService).getAssetById(Mockito.anyString(), Mockito
            .anyCollectionOf(String.class), Mockito
            .anyString());
        Map<String, Messages.Builder> tenantBuilderMap = EventhubHelper.getEventMessages(createEvents(TAG_TYPE,
            OBJECT_TYPE_TAG),
            assetPersistencyService);
        assertNotNull("There are no Events found, events map is null", tenantBuilderMap);
        verify(tenantBuilderMap);
    }

    @Test
    public void testCovert() {
        ProtocolDetails[] protocolDetails =
                EventhubHelper.convert(getProtocolDetails(TENANTINFO_FILE_NAME, PROTOCOL_PATH));
        for (ProtocolDetails protocol : protocolDetails) {
            if (PROTOCOL.equals(protocol.getProtocol())) {
                assertEquals("Eventhub GRPC URI is not matching ",
                        "event-hub-asv-pr.data-services.predix.io:443", protocol.getUri() );
                assertEquals("GRPC Prtocol is not matching", PROTOCOL,protocol.getProtocol());
                assertEquals("Eventhub number of Scopes are not matching", 2, protocol.getTokenScopes().size());
            } else {
                assertEquals("Eventhub WSS URI is not matching ",
                        "wss://event-hub-asv-pr.data-services.predix.io/v1/stream/messages/", protocol.getUri() );
                assertEquals("WSS Prtocol is not matching", "wss",protocol.getProtocol());
                assertEquals("Eventhub number of Scopes are not matching", 2, protocol.getTokenScopes().size());
            }
        }
    }

    @Test
    public void testGetHostAndPort() {
        ProtocolDetails[] protocolDetails =
                EventhubHelper.convert(getProtocolDetails(TENANTINFO_FILE_NAME, PROTOCOL_PATH));
        Arrays.stream(protocolDetails).filter(protocol -> protocol.equals(PROTOCOL)).forEach(protocol -> {
            String[] hostAndPort = EventhubHelper.getHostAndPort(protocol.getUri());
            assertEquals("GRPC Host is not matching ", "event-hub-asv-pr.data-services.predix.io", hostAndPort[0]);
            assertEquals("GRPC Port is not matching ", "443", hostAndPort[1]);
        });

        String[] values = EventhubHelper.getHostAndPort(null);
        assertTrue(values == null);
    }

}
