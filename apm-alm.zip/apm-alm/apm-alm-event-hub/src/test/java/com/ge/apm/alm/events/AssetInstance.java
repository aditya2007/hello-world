/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.events;

import java.time.OffsetDateTime;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.jpa.entity.TemplateInfoEntity;

/**
 * Created by Yogananda Gowda - 212590467 on 7/12/17.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString(callSuper = true)
public class AssetInstance implements Asset {

    private String id;
    private String name;
    private String tenantId;
    private String sourceKey;
    private String label;
    private String description;

    private String assetType;
    private String parentId;
    private JsonNode attributes;
    private JsonNode geolocation;
    private List<String> ancestorsArray;
    private List<String> superTypesArray;

    private TemplateInfoEntity templateInfo;
    private Asset parent;
    private AssetType type;
    private List<Tag> tags;

    private String createdBy;
    private OffsetDateTime createdDate;
    private String lastModifiedBy;
    private OffsetDateTime lastModifiedDate;
}
