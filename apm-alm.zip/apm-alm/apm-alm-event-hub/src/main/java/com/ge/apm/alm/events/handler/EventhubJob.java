/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.events.handler;

import java.util.HashSet;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.events.services.AssetEventhubService;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.EventsJobType;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.datasource.TenantDataSourceService;
import com.ge.predix.eventhub.Messages.Builder;

/**
 * Created by Yogananda Gowda - 212590467 on 6/28/17.
 *
 */
@ConditionalOnProperty("apm.asset.eventhub.job.enabled")
@Component
@Slf4j
public class EventhubJob {

    @Autowired
    private AssetEventPersistencyService assetEventPersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    AssetEventhubService eventHubService;

    @Value("${apm.asset.eventhub.job.size:100}")
    private Integer jobSize;

    @Value("${apm.asset.eventhub.job.timeout:60000}")
    private Long jobTimeoutMillis;

    @Value("${apm.asset.cleanup.job.timeout:864000000}")
    private Long expiredTimeoutMillis;

    @Autowired
    private TenantDataSourceService tenantDataSourceService;

    @Scheduled(fixedRateString = "${apm.asset.eventhub.schedule.interval}")
    public void doExecute() {

        for (String tenantId : getDatabases()) {
            tenantJob(tenantId);
        }
    }

    private void tenantJob(String tenantId) {
        RequestContext.put(RequestContext.TENANT_UUID, tenantId);
        RequestContext.put("AccessibleResources", new String[] {"*"});
        log.debug("Running Eventhub job for tenant {} ", tenantId);
        boolean canInterupt = false;
        List<AssetEvent> events = null;
        try {
            events = assetEventPersistencyService.getPendingEventBatch(EventsJobType.EVENTHUB, jobSize,
                jobTimeoutMillis, expiredTimeoutMillis);
            if (CollectionUtils.isEmpty(events)) {
                log.debug("No Eventhub events found for tenant {} ", tenantId);
                return;
            } else {
                log.debug("Processing Eventhub job with {} events for tenant {} ", events.size(), tenantId);
                Map<String, Builder> tenantBuilderMap = EventhubHelper.getEventMessages(events,
                    assetPersistencyService);

                for (Map.Entry<String, Builder> entry : tenantBuilderMap.entrySet()) {
                    eventHubService.publishToEventhub(entry.getKey(), entry.getValue().build());
                }
            }
        } catch (Exception ex) {
            log.error("Exception while processing eventhub events {}, for tenant {} ", ex, tenantId);
            canInterupt = true;
        } finally {
            if (canInterupt) {
                Thread.currentThread().interrupt();
            }
            RequestContext.destroy();
        }
    }

    private HashSet<String> getDatabases() {
        HashSet<String> set = new HashSet<>();
        set.add(TenantDataSourceService.DEFAULT_DATASOURCE);
        set.addAll(tenantDataSourceService.getTenants());
        return set;
    }
}
