/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.events.handler;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

/**
 * Created by 212590467 on 1/24/17.
 */

@ToString
@Getter
public class MessageBody {

    private final String objectId;
    private final String tenantId;
    private final String sourceKey;
    private final String monitoredEntityUri;
    private final String monitoredEntitySourceKey;
    private final JsonNode modifiedData;
    private final String objectType;
    private final String eventType;
    private final String user;
    private final String createOrUpdatedDate;

    @Builder
    private MessageBody(String objectId, String tenantId,
                        String sourceKey, String monitoredEntityUri,
                        String monitoredEntitySourceKey,
                        JsonNode modifiedData,
                        String objectType,String eventType,
                        String user, String createOrUpdatedDate) {
        this.objectId = objectId;
        this.tenantId = tenantId;
        this.sourceKey = sourceKey;
        this.monitoredEntityUri = monitoredEntityUri;
        this.monitoredEntitySourceKey = monitoredEntitySourceKey;
        this.modifiedData = modifiedData;
        this.objectType = objectType;
        this.eventType = eventType;
        this.user = user;
        this.createOrUpdatedDate = createOrUpdatedDate;
    }
}
