/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.events.services;

import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.predix.eventhub.EventHubClientException;
import com.ge.predix.eventhub.Messages;

/**
 * Created by Yogananda Gowda - 212590467 on 7/4/17.
 */
public interface AssetEventhubService {

    void publishToEventhub(String tenantId, Messages messages) throws EventHubClientException;

    int updateEventhubPubStatus(String eventId) throws PersistencyServiceException;
}
