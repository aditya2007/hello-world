/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.events.services;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.events.handler.EventhubHelper;
import com.ge.apm.alm.events.handler.ProtocolDetails;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.service.instances.ServiceInstanceInfo;
import com.ge.apm.service.instances.ServiceInstances;
import com.ge.apm.service.instances.filter.ServiceInstancesFilter;
import com.ge.apm.service.tenants.TenantsUtil;
import com.ge.predix.eventhub.Ack;
import com.ge.predix.eventhub.EventHubClientException;
import com.ge.predix.eventhub.Messages;
import com.ge.predix.eventhub.client.Client;
import com.ge.predix.eventhub.configuration.EventHubConfiguration;
import com.ge.predix.eventhub.configuration.PublishAsyncConfiguration;

/**
 * Created by Yogananda Gowda - 212590467 on 7/4/17.
 */
@ConditionalOnProperty("apm.asset.eventhub.job.enabled")
@Service
@Slf4j
public class AssetEventhubServiceImpl implements AssetEventhubService {

    @Value("${predix.eventhub.service.name}")
    private String eventhubSvcInstanceName;

    @Value("${stuf.trustedIssuer}")
    private String uaaUri;

    @Value("${stuf.clientId}")
    private String clientId;

    @Value("${stuf.clientSecret}")
    private String clientSecret;

    @Autowired
    private ServiceInstances serviceInstances;

    @Autowired
    private TenantsUtil tenantsUtil;

    @Autowired
    private AssetEventPersistencyService assetEventPersistencyService;

    private final Object client = new Object();
    private final Object ack = new Object();
    private final Map<String, Client> eventHubClientMap = new ConcurrentHashMap<>();
    private final Set<String> downloadedTenants = new HashSet<>();
    private final Lock tenantsLock = new ReentrantLock();
    private final Map<String, String> messageIdsToTenantMap = new ConcurrentHashMap<>();
    private final Map<String, List<String>> tenantIdToMessageIdsMap = new HashMap<>();

    @Override
    public void publishToEventhub(String tenantId, Messages messages) throws EventHubClientException {
        if (Objects.nonNull(messages)) {
            log.debug("Processing Eventhub messages of size {} ", messages.getMsgCount());
            Messages subMessages = messages.getMsgCount() > 999
                ? Messages.newBuilder().addAllMsg(messages.getMsgList().subList(0, 999)).build() : messages;
            if (Objects.nonNull(subMessages) && !CollectionUtils.isEmpty(subMessages.getMsgList())) {
                synchronized (client) {
                    if (!downloadedTenants.contains(tenantId)
                            && !downloadedTenants.contains(unFormatTenantId(tenantId))) {
                        populateTenants();
                    }

                    Client eventHubClient = getClient(tenantId);
                    subMessages.getMsgList().stream().forEach(m ->
                        messageIdsToTenantMap.put(m.getId(), tenantId)
                    );
                    eventHubClient.addMessages(subMessages).flush();
                    log.info("After sending message to EventHub, thread Id : [{}] ",
                        Thread.currentThread().getId());
                }
            }
        }
    }

    private String unFormatTenantId(String tenantId) {
        return StringUtils.isNotEmpty(tenantId)
            ? tenantId.replaceAll("-", "").toUpperCase() : tenantId;
    }

    @Override
    public int updateEventhubPubStatus(String eventId) throws PersistencyServiceException {
        return assetEventPersistencyService.updateEvent(
                eventId, AssetEvent.EventsJobType.EVENTHUB, AssetEvent.EventStatus.COMPLETED.name());
    }

    private void updateEventsStatus(List<String> events) throws PersistencyServiceException {
        if (!messageIdsToTenantMap.keySet().containsAll(events)) {
            return;
        }

        Map<String, List<String>> tenantToEvents = events.stream().collect(Collectors.groupingBy(eventId ->
            messageIdsToTenantMap.get(eventId)));

        synchronized (ack) {
            tenantIdToMessageIdsMap.putAll(tenantToEvents);
            for (Map.Entry<String, List<String>> entry : tenantIdToMessageIdsMap.entrySet()) {
                try {
                    RequestContext.put(RequestContext.TENANT_UUID, entry.getKey());
                    assetEventPersistencyService.updateEventsStatus(entry.getValue(),
                        AssetEvent.EventsJobType.EVENTHUB, AssetEvent.EventStatus.COMPLETED.name());
                } finally {
                    messageIdsToTenantMap.keySet().removeAll(tenantIdToMessageIdsMap.get(entry.getKey()));
                    RequestContext.destroy();
                }
            } //End of for loop
            tenantIdToMessageIdsMap.clear();
        } //End of sync
    }

    private void registerCallback(Client eventHubClient) throws EventHubClientException {
        eventHubClient.registerPublishCallback(new Client.PublishCallback() {
            @Override
            public void onAck(List<Ack> acks) {
                eventHubAck(acks);
            }

            @Override
            public void onFailure(Throwable throwable) {
                log.error("Received Nack {} ", throwable.getMessage());
            }
        }); //end of registerPublishCallback
    }

    private void eventHubAck(List<Ack> acks) {
        if (acks != null && !acks.isEmpty()) {
            int updateCnt = 0;
            try {
                log.debug("Updating the Eventhub acks status with batch size {} : ", acks.size());
                updateEventsStatus(acks.stream().map(Ack::getId).collect(Collectors.toList()));
            } catch (PersistencyServiceException pse) {
                log.error("Exception while updating Asset Event status for Eventhub ack {} ", pse);
            }
            log.debug("Number of Eventhub status records get updated :: ", updateCnt);
        }
    }

    private Client getClient(String tenantId) throws EventHubClientException {
        Client eventHubClient;
        if (eventHubClientMap.get(tenantId) == null) {
            eventHubClient = createEventHubClient(tenantId);
            eventHubClientMap.putIfAbsent(tenantId, eventHubClient);
            registerCallback(eventHubClient);
        } else {
            eventHubClient = eventHubClientMap.get(tenantId);
        }
        log.debug("Eventhub Client {}, for Tenant Id {} ", eventHubClient, tenantId);
        return eventHubClient;
    }

    private Client createEventHubClient(String tenantId) {
        return new Client(constructEventHubConfig(tenantId));
    }

    private EventHubConfiguration constructEventHubConfig(String tenantId) {
        EventHubConfiguration configuration = null;
        try {
            String[] hostPort = null;
            String authScopes = null;
            ServiceInstanceInfo serviceInstanceInfo = getServiceInstanceInfo(tenantId);

            if (Objects.isNull(serviceInstanceInfo)) {
                RequestContext.put(RequestContext.TENANT_UUID, unFormatTenantId(tenantId));
                log.debug("Old Tenant Id {} ", ServiceInstancesFilter.getTenantUuid());
                serviceInstanceInfo = serviceInstances.getServiceInstanceInfo(
                        ServiceInstancesFilter.getTenantUuid(), eventhubSvcInstanceName);
            }

            ProtocolDetails[] protocolDetails = EventhubHelper.convert(serviceInstanceInfo.getProtocolDetails());
            for (ProtocolDetails protocol : protocolDetails) {
                if (EventhubHelper.PROTOCOL.equals(protocol.getProtocol())) {
                    hostPort = EventhubHelper.getHostAndPort(protocol.getUri());
                    authScopes = (protocol.getTokenScopes() != null
                            && !protocol.getTokenScopes().isEmpty())
                            ? String.join(",", protocol.getTokenScopes()) : null;
                }
            }

            if (null != hostPort && hostPort.length > 1 && StringUtils.isNotEmpty(authScopes)) {
                configuration = new EventHubConfiguration.Builder()
                        .host(hostPort[0])
                        .port(Integer.parseInt(hostPort[1]))
                        .zoneID(serviceInstanceInfo.getZoneHeaderValue())
                        .clientID(clientId)
                        .clientSecret(clientSecret)
                        .authURL(uaaUri)
                        .authScopes(authScopes)
                        .publishConfiguration(
                                new PublishAsyncConfiguration.Builder()
                                        .ackType(PublishAsyncConfiguration.AcknowledgementOptions.ACKS_AND_NACKS)
                                        .cacheAckIntervalMillis(100).build())
                        .build();
            }
        } catch (EventHubClientException.InvalidConfigurationException eh) {
            log.error("EventHubClientException while construction EventhubConfiguration {}", eh);
        } catch (Exception ex) {
            log.error("Exception while construction EventhubConfiguration {}", ex);
        }
        log.debug("Event Hub Credentials {} ", configuration);
        return configuration;
    }

    private ServiceInstanceInfo getServiceInstanceInfo(String tenantId) {
        ServiceInstanceInfo serviceInstanceInfo = null;
        try {
            RequestContext.put(RequestContext.TENANT_UUID, tenantId);
            serviceInstanceInfo = serviceInstances.getServiceInstanceInfo(
                    ServiceInstancesFilter.getTenantUuid(), eventhubSvcInstanceName);
        } catch (Exception ex) {
            log.error("Exception while getting TenantInfo from ServiceInstance {} ", ex);
            RequestContext.put(RequestContext.TENANT_UUID, unFormatTenantId(tenantId));
            log.debug("Old Tenant Id {} ", ServiceInstancesFilter.getTenantUuid());
            serviceInstanceInfo = serviceInstances.getServiceInstanceInfo(
                    ServiceInstancesFilter.getTenantUuid(), eventhubSvcInstanceName);
        }
        return serviceInstanceInfo;
    }

    private void populateTenants() {
        downloadedTenants.clear();

        List<ServiceInstances.TenantInfo> tenants = tenantsUtil.getAllTenantServiceInfo();
        for (ServiceInstances.TenantInfo tenantInfo : tenants) {
            downloadedTenants.add(tenantInfo.getTenantUuid());
        }
    }
}
