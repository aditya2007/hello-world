/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.events.handler;

import java.util.concurrent.ScheduledThreadPoolExecutor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

/**
 * Created by Yogananda Gowda - 212590467 on 6/28/17.
 */
@ConditionalOnProperty("apm.asset.eventhub.job.enabled")
@Configuration
@EnableScheduling
public class EventhubSchedulerConfig implements SchedulingConfigurer {

    @Value("${apm.asset.eventhub.consumers:5}")
    private Integer numOfConcConsumer;

    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
        taskRegistrar.setScheduler(eventhubPoolScheduler());
    }

    @Bean
    public TaskScheduler eventhubPoolScheduler() {
        return new ConcurrentTaskScheduler(new ScheduledThreadPoolExecutor(numOfConcConsumer));
    }
}
