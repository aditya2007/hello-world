/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.events.handler;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.predix.eventhub.Message;
import com.ge.predix.eventhub.Messages;

import com.google.protobuf.ByteString;


/**
 * Created by Yogananda Gowda - 212590467 on 6/30/17.
 */
@Slf4j
public class EventhubHelper {

    public static final ObjectMapper MAPPER = new ObjectMapper();
    public static final String PROTOCOL = "grpc";

    private EventhubHelper() {}

    public static Map<String, Messages.Builder> getEventMessages(List<AssetEvent> events,
                                            AssetPersistencyService assetPersistencyService) {
        Map<String, Messages.Builder> tenantBuilderMap = new HashMap<>();

        events.stream().forEach(event -> {
            if (tenantBuilderMap.containsKey(event.getTenantId())) {
                tenantBuilderMap.get(event.getTenantId()).addMsg(Message.newBuilder()
                                           .setId(event.getId())
                                           .setBody(ByteString.copyFromUtf8(
                                           convertToJsonNode(getEventMessage(event,
                                                 assetPersistencyService)))));
            } else {
                Messages.Builder builder = Messages.newBuilder().addMsg(
                                                Message.newBuilder().setId(event.getId())
                                                .setBody(ByteString.copyFromUtf8(
                                                convertToJsonNode(getEventMessage(event,
                                                 assetPersistencyService)))));

                tenantBuilderMap.put(event.getTenantId(), builder);
            }
        });
        return tenantBuilderMap;

    }

    public static String convertToJsonNode(MessageBody param) {
        try {
            JsonNode node = MAPPER.convertValue(param, JsonNode.class);
            return Objects.nonNull(node) ?
                    MAPPER.writeValueAsString(MAPPER.readValue(node.toString(), Object.class)) : "";
        } catch (Exception ex) {
            log.error("Error while converting to Json Node " + ex);
        }
        return "";
    }

    private static MessageBody getEventMessage(AssetEvent event,
                                               AssetPersistencyService assetPersistencyService) {
        String sourceKey = getValue(event.getPreModifiedObject(),
                                event.getModifiedObject(),
                                "sourceKey", event.getEventType());

        JsonNode modifiedData = event.getModifiedObject();

        String moniteredEntityUri = null;
        String moniteredEntitySrcKey = null;
        if (Objects.equals("Tag", event.getObjectType())) {
            moniteredEntityUri = getValue(event.getPreModifiedObject(), event.getModifiedObject(),
                                                                    "assetId", event.getEventType());
            moniteredEntitySrcKey = getMoniteredSourceKey(moniteredEntityUri,
                                                          event.getTenantId(),
                                                          assetPersistencyService);
        }

        return MessageBody.builder().objectId(event.getObjectId())
                .tenantId(event.getTenantId()).sourceKey(sourceKey)
                .monitoredEntityUri(moniteredEntityUri)
                .monitoredEntitySourceKey(moniteredEntitySrcKey)
                .modifiedData(event.getEventType() == AssetEvent.Type.DELETE ? null : modifiedData)
                .objectType(event.getObjectType())
                .eventType(event.getEventType().name())
                .user(event.getLastModifiedBy())
                .createOrUpdatedDate(Objects.nonNull(event.getLastModifiedDate())
                        ? event.getLastModifiedDate().toString() : OffsetDateTime.now().toString()).build();
    }

    private static String getValue(JsonNode existingNode, JsonNode modifiedNode,
                                    String nodeName, AssetEvent.Type eventType) {

        return eventType == AssetEvent.Type.DELETE
                            ? getValue(existingNode, nodeName)
                            : getValue(modifiedNode, nodeName);
    }

    private static String getValue(JsonNode node, String nodeName) {
        return Objects.isNull(node) ? "" : node.path(nodeName).asText();
    }

    private static String getMoniteredSourceKey(String assetId, String tenantId,
                                                AssetPersistencyService assetPersistencyService) {
        Asset asset = assetPersistencyService.getAssetById(tenantId, new ArrayList<>(), assetId);
        return Objects.nonNull(asset) ? asset.getSourceKey() : "";
    }

    public static ProtocolDetails[] convert(JsonNode node) {
        ProtocolDetails[] protocols = new ProtocolDetails[2];
        int idx = 0;
        for (JsonNode arrayNode : node) {
            protocols[idx++] = MAPPER.convertValue(arrayNode, ProtocolDetails.class);
        }
        return protocols;
    }

    public static String[] getHostAndPort(String uri) {
        return uri == null ? null : uri.split(":");
    }
}
