# apm-alm

1. Import the main pom.xml (apm-alm/pom.xml) in any IDE (IntelliJ)
2. Change PostgreSQL connection details apm-alm/apm-alm-persistence-jpa/src/main/resources/application-default.properties
3. Run test to populate few enterprises, sites, segements : apm-alm/apm-alm-persistence-jpa/src/test/java/com/ge/apm/alm/persistence/jpa/AssetTypeRepositoryTests.java
4. Run the App apm-alm/apm-alm-app/src/main/java/com/ge/apm/alm/Application.java
5. Use Postman to call following APIs:
    - http://localhost:8080/v1/assets/
    - http://localhost:8080/v1/assets/825229df-93e9-3433-a7d8-b13f7a6585bc
    - http://localhost:8080/v1/assets/825229df-93e9-3433-a7d8-b13f7a6585bc/children
