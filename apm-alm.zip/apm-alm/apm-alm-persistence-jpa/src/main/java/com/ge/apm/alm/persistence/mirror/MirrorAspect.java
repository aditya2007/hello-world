/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.mirror;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.ObjectType;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.AssetGroupAssociationPersistencyService;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.NetworkPersistencyService;
import com.ge.apm.alm.persistence.PlaceholderPersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.TemplatePersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;

@Slf4j
@Aspect
@Component
public class MirrorAspect {

    private final ThreadLocal<Map<AssetEvent.Type,Collection<AssetEvent>>> updateEventsThreadLocal
        = new ThreadLocal<>();

    private final Map<String, Object> persistencyServices = new HashMap<>();

    @Autowired
    private AssetEventPersistencyService eventService;

    @Autowired
    private GroupPersistencyService groupService;

    @Autowired
    private AssetPersistencyService assetService;

    @Autowired
    private AssetTypePersistencyService assetTypeService;

    @Autowired
    private TagPersistencyService tagService;

    @Autowired
    private PlaceholderPersistencyService placeholderService;

    @Autowired
    private TemplatePersistencyService templatePersistencyService;

    @Autowired
    private AssetGroupAssociationPersistencyService assetGroupAssociationPersistencyService;

    @Autowired
    private NetworkPersistencyService networkPersistencyService;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    @Value("${apm.asset.auditlog.job.enabled}")
    private boolean isAuditlogEnabled;

    @Value("${apm.asset.eventhub.job.enabled}")
    private boolean isEventhubEnabled;

    @Value("${apm.asset.events.create}")
    private boolean isEventsCreateEnabled;

    @Value("#{'${apm.asset.exclude.types.auditlog}'.split(',')}")
    private List<String> ignorableTypesForAuditLog;

    @Value("#{'${apm.asset.exclude.types.eventhub}'.split(',')}")
    private List<String> ignorableTypesForEventHub;


    @PostConstruct
    public void onPostConstruct() {
        log.debug("onPostConstruct() of MirrorAspect here");
        persistencyServices.put(ObjectType.ENTERPRISE, assetService);
        persistencyServices.put(ObjectType.SITE, assetService);
        persistencyServices.put(ObjectType.SEGMENT, assetService);
        persistencyServices.put(ObjectType.ASSET, assetService);
        persistencyServices.put(ObjectType.TAG, tagService);

        persistencyServices.put(ObjectType.ENTERPRISE_TYPE, assetTypeService);
        persistencyServices.put(ObjectType.SITE_TYPE, assetTypeService);
        persistencyServices.put(ObjectType.SEGMENT_TYPE, assetTypeService);
        persistencyServices.put(ObjectType.ASSET_TYPE, assetTypeService);
        persistencyServices.put(ObjectType.TAG_TYPE, assetTypeService);

        persistencyServices.put(ObjectType.ASSET_GROUP, groupService);
        persistencyServices.put(ObjectType.ASSET_GROUP_ITEM, groupService);
        persistencyServices.put(ObjectType.TEMPLATE, templatePersistencyService);
        persistencyServices.put(ObjectType.PLACEHOLDER, placeholderService);

        persistencyServices.put(ObjectType.NETWORK, networkPersistencyService);
        persistencyServices.put(ObjectType.EDGE, networkPersistencyService);
        persistencyServices.put(ObjectType.NODE, networkPersistencyService);
        persistencyServices.put(ObjectType.ASSET_GROUP_ASSOCIATION, assetGroupAssociationPersistencyService);
        persistencyServices.put(ObjectType.ASSET_USER_POLICY, assetPolicyPersistencyService);

        if (ignorableTypesForAuditLog != null) {
            AssetEventHelper.setIgnorableTypesForAuditLog(ignorableTypesForAuditLog);
        }
        if (ignorableTypesForEventHub != null) {
            AssetEventHelper.setIgnorableTypesForEventHub(ignorableTypesForEventHub);
        }
        AssetEventHelper.setIsEventhubEnabled(isEventhubEnabled);
        AssetEventHelper.setIsAuditlogEnabled(isAuditlogEnabled);
    }

    @Before("execution(* *.*(.., @com.ge.apm.alm.persistence.mirror.Mirror (*), ..))")
    public void beforePersistence(JoinPoint joinPoint) throws PersistencyServiceException {
        if (!isEventsCreateEnabled) return;
        log.debug("beforePersistence() of MirrorAspect here");
        try {
            Collection<MirrorableParam> params = collectMirrorableParams(joinPoint, null).stream()
                    .filter(param -> !param.isCreateOrRecursiveDeleteType()).collect(Collectors.toList());
            Collection<AssetEvent> events = new ArrayList<>();
            AssetEvent.Type persistType = null;
            for (MirrorableParam param : params) {
                events.addAll(resolveToEvents(param));
                persistType = param.getPersistType();
            }

            if (persistType == AssetEvent.Type.UPDATE) {
                Map<AssetEvent.Type, Collection<AssetEvent>> updatedEventsMap = new EnumMap<>(AssetEvent.Type.class);
                updatedEventsMap.put(persistType, events);
                updateEventsThreadLocal.set(updatedEventsMap);
            } else {
                // only attempt to persist if this is reached (no exception thrown)
                eventService.createEvents(events);
            }
        } catch (PersistencyServiceException pse) {
            updateEventsThreadLocal.remove();
            throw pse;
        }
    }

    @AfterReturning(value = "execution(* *.*(.., @com.ge.apm.alm.persistence.mirror.Mirror (*), ..))",
        returning = "result")
    public void afterPersistence(JoinPoint joinPoint, Object result) throws PersistencyServiceException {
        if (!isEventsCreateEnabled) return;
        log.debug("afterPersistence() of MirrorAspect here");
        try {
            if (Objects.nonNull(updateEventsThreadLocal.get())
                    && updateEventsThreadLocal.get().containsKey(AssetEvent.Type.UPDATE)) {
                Collection<AssetEvent> events = updateEventsThreadLocal.get().get(Type.UPDATE);
                eventService.createEvents(events);
            } else {
                Collection<MirrorableParam> params = collectMirrorableParams(joinPoint, result).stream()
                        .filter(param -> param.isCreateOrRecursiveDeleteType()).collect(Collectors.toList());

                Collection<AssetEvent> events = new ArrayList<>();
                for (MirrorableParam param : params) {
                    events.addAll(resolveToEvents(param));
                }
                eventService.createEvents(events);
            }
        } catch (PersistencyServiceException pse) {
            updateEventsThreadLocal.remove();
            throw pse;
        }
        updateEventsThreadLocal.remove();
    }


    /**
     * Scans executed method and crawls its arguments to collect persistence information.
     */
    Collection<MirrorableParam> collectMirrorableParams(JoinPoint joinPoint, Object result)
        throws PersistencyServiceException {

        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Annotation[][] annotations = methodSignature.getMethod().getParameterAnnotations();
        Object[] args = joinPoint.getArgs();

        String tenantId;
        if (args[0] instanceof String) {
            tenantId = (String) args[0];
        } else {
            throw new PersistencyServiceException("Expected first parameter to be tenant ID (String)");
        }

        Collection<String> accessibleResources = extractAccessibleResources(args, annotations);
        Collection<MirrorableParam> params = new ArrayList<>();

        // by annotated method
        Mirror mirrorAnnotation = methodSignature.getMethod().getAnnotation(Mirror.class);
        if (mirrorAnnotation != null && result != null) {
            params.add(new MirrorableParam(tenantId, methodSignature.getName(), mirrorAnnotation,
                result, result, accessibleResources));
        }
        // Get annotated arguments
        params.addAll(
            getArgumentsMirrorParams(result, methodSignature, annotations, args, tenantId, accessibleResources));

        setSubTypes(params);

        params.forEach(p -> {
            p.setJoinPoint(joinPoint);
        });
        params.stream()
            .filter(p -> p.getPersistType() == Type.RECURSIVE_ASSET_DELETE)
            .forEach(p -> p.setDeletedReason());
        return params;
    }

    private Collection<MirrorableParam> getArgumentsMirrorParams(Object result, MethodSignature methodSignature,
        Annotation[][] annotations, Object[] args, String tenantId, Collection<String> accessibleResources)
        throws PersistencyServiceException {
        Collection<MirrorableParam> params = new ArrayList<>();
        for (int i = 0; i < args.length && i < annotations.length; i++) {
            for (Annotation annotation : annotations[i]) {
                if (!(annotation instanceof Mirror)) {
                    continue;
                }
                params.addAll(getArgumentMirrorParams(result, methodSignature, args[i], tenantId, accessibleResources,
                    annotation));
            }
        }
        return params;
    }

    private Collection<MirrorableParam> getArgumentMirrorParams(Object result, MethodSignature methodSignature,
        Object arg, String tenantId,
        Collection<String> accessibleResources, Annotation annotation)
        throws PersistencyServiceException {
        Collection<MirrorableParam> params = new ArrayList<>();
        if (arg instanceof Collection) {
            for (Object obj : (Collection) arg) {
                params.add(new MirrorableParam(tenantId, methodSignature.getName(),
                    (Mirror) annotation, obj, result, accessibleResources));
            }
        } else {
            params.add(new MirrorableParam(tenantId, methodSignature.getName(),
                (Mirror) annotation, arg, result, accessibleResources));
        }
        return params;
    }

    private Collection<String> extractAccessibleResources(Object[] args, Annotation[]... annotations) {
        Collection<String> accessibleResources = null;
        for (int i = 0; i < args.length && i < annotations.length; i++) {
            for (Annotation annotation : annotations[i]) {
                if (annotation instanceof Accessible && args[i] instanceof Collection) {
                    return (Collection) args[i];
                }
            }
        }
        return accessibleResources;
    }

    private void setSubTypes(Collection<MirrorableParam> params) {

        for (MirrorableParam param : params) {
            switch (param.getObjectType()) {
                case ObjectType.ASSET:
                    setAssetSubType(param);
                    break;
                case ObjectType.ASSET_TYPE:
                    setAssetTypeSubType(param);
                    break;
                case ObjectType.ASSET_GROUP:
                    setGroupSubType(param);
                    break;
                default:
                    break;
            }
        }
    }

    private void setAssetSubType(MirrorableParam param) {
        Asset asset = null;
        if (param.getArg() instanceof Asset) {
            asset = (Asset) param.getArg();
        }
        if (asset == null || asset.getCoreAssetTypeName() == null) {
            asset = assetService.getAssetById(
                param.getTenantId(), param.getAccessibleResources(), param.getObjectId());
        }
        if (asset != null) {
            param.setRealObjectType(asset.getCoreAssetTypeName().split("Type")[0]);
        }
    }

    private void setAssetTypeSubType(MirrorableParam param) {
        AssetType type = null;
        if (param.getArg() instanceof AssetType) {
            type = (AssetType) param.getArg();
        }
        if ((type == null || type.getCoreAssetTypeName() == null)
            && !StringUtils.isEmpty(param.getTenantId()) && !StringUtils.isEmpty(param.getObjectId())) {
            type = assetTypeService.getAssetTypeById(param.getTenantId(), param.getObjectId());
        }
        if (type != null) {
            param.setRealObjectType(type.getCoreAssetTypeName());
        }
    }

    private void setGroupSubType(MirrorableParam param) {
        AssetGroup group = null;
        if (param.getArg() instanceof AssetGroup) {
            group = (AssetGroup) param.getArg();
        }
        if (group == null || group.getCategory() == null) {
            group = groupService.getAssetGroupById(param.getTenantId(), param.getObjectId());
        }
        if (group != null) {
            if (AssetGroupCategory.TAG_CORRELATION.equals(group.getCategory())) {
                param.setRealObjectType(ObjectType.TAG_CORRELATION);
            } else {
                param.setRealObjectType(ObjectType.ASSET_GROUP);
            }
        }
    }


    Collection<AssetEvent> resolveToEvents(MirrorableParam param)
        throws PersistencyServiceException {
        Collection<AssetEvent> events = new ArrayList<>();

        switch (param.getPersistType()) {
            case CREATE:
            case UPDATE:
            case DELETE:
                events.add(AssetEventHelper.createEvent(param, persistencyServices.get(param.getObjectType()),
                    persistencyServices));
                break;
            case DELETE_TAGS:
                events.addAll(AssetEventHelper.createEventsForDeleteTags(param, tagService, persistencyServices));
                break;
            case RECURSIVE_ASSET_DELETE:
                events.addAll(
                    AssetEventHelper.createEventsForDeleteAssetRecursively(param, persistencyServices));
                break;
            case DELETE_TYPE_RECURSIVELY:
                events.addAll(AssetEventHelper
                    .createEventsForDeleteAssetTypeRecursively(param, assetTypeService, persistencyServices));
                break;
            case DELETE_GROUP_ITEMS:
                events.addAll(
                    AssetEventHelper.createEventsForDeleteGroupItems(param, groupService, persistencyServices));
                break;
            case DELETE_GROUP_AND_ITEMS:
                events.addAll(
                    AssetEventHelper.createEventsForDeleteGroupAndGroupItems(param, groupService, persistencyServices));
                break;
            case DELETE_TEMPLATE:
                events.addAll(AssetEventHelper
                    .createEventsForDeleteTemplateAndPlaceholders(param, placeholderService,
                        templatePersistencyService, persistencyServices));
                break;
            case DELETE_NETWORK:
                events.addAll(AssetEventHelper
                    .createEventsForDeleteNetwork(param, networkPersistencyService, persistencyServices));
                break;
            case DELETE_ASSET_GROUP_ASSOCIATION:
                events.addAll(
                    AssetEventHelper.createEventsForDeleteAssetGroupAssociation(param,
                        assetGroupAssociationPersistencyService, persistencyServices));
                break;
            default:
                throw new PersistencyServiceException(
                    "Unsupported persist type: " + param.getPersistType());
        }

        return events;
    }

    /**
     * For tests only.
     */
    void setEnabled(boolean enabled) {
        this.isEventsCreateEnabled = enabled;
    }
}
