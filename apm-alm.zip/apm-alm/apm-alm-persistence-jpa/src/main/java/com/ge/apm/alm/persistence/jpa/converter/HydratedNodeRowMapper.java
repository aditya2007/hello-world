/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.converter;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.ConversionService;
import org.springframework.jdbc.core.RowMapper;

import com.ge.apm.alm.model.Network;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.NetworkEntity;

/**
 * @author Suban Asif 212448111
 * @version 1.0 Aug 01, 2017
 * @since 1.0
 */
public class HydratedNodeRowMapper implements RowMapper<Network> {

    private final ConversionService conversionService;

    private final JsonbAttributeConverter jsonbAttributeConverter;

    private final ListToTextArrayAttributeConverter listToTextArrayAttributeConverter;

    public HydratedNodeRowMapper(JsonbAttributeConverter jsonbAttributeConverter,
        ListToTextArrayAttributeConverter listToTextArrayAttributeConverter, ConversionService conversionService) {
        this.jsonbAttributeConverter = jsonbAttributeConverter;
        this.listToTextArrayAttributeConverter = listToTextArrayAttributeConverter;
        this.conversionService = conversionService;
    }

    @Override
    public Network mapRow(ResultSet rs, int rowNum) throws SQLException {
        NetworkEntity networkEntity = new NetworkEntity();
        networkEntity.setId(rs.getString("id"));
        networkEntity.setTenantId(rs.getString("tenant_id"));
        networkEntity.setName(rs.getString("name"));
        networkEntity.setAssetId(rs.getString("asset_id"));
        if (StringUtils.isNotEmpty(networkEntity.getAssetId())) {
            networkEntity.setAsset(AssetInstanceEntity.builder().id(networkEntity.getAssetId()).sourceKey(
                rs.getString("asset_source_key")).name(rs.getString("asset_name")).description(
                rs.getString("asset_description")).attributes(
                jsonbAttributeConverter.convertToEntityAttribute(rs.getObject("asset_attributes"))).superTypesArray(
                listToTextArrayAttributeConverter.convertToEntityAttribute(rs.getObject("asset_super_types_array")))
                .build());
        } else {
            networkEntity.setAttributes(jsonbAttributeConverter.convertToEntityAttribute(rs.getObject("attributes")));
        }
        networkEntity.setSourceKey(rs.getString("source_key"));
        networkEntity.setDescription(rs.getString("description"));
        return networkEntity;
    }
}
