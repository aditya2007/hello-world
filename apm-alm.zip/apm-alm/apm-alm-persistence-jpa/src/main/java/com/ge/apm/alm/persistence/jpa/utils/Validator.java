/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public final class Validator {

    private static final String ALL_ITEMS_MUST_BELONG_TO_THE_SAME = "All item(s) must belong to the same ";

    private Validator() {
    }

    public static void validateAllIdsAreUniform(String category, String matchingId, Set<String> ids) {
        Set<String> nonNullIdSet = ids.stream().filter(Objects::nonNull).collect(Collectors.toSet());
        if (nonNullIdSet.isEmpty()) {
            return;
        }
        if (nonNullIdSet.size() > 1 || !nonNullIdSet.iterator().next().equals(matchingId)) {
            throw new IllegalArgumentException(ALL_ITEMS_MUST_BELONG_TO_THE_SAME + category + ": " + matchingId);
        }
    }

    public static void assertMatchingTenantId(String tenantId, String objTenantId) {
        if (objTenantId != null && !objTenantId.equals(tenantId)) {
            throw new IllegalArgumentException(ALL_ITEMS_MUST_BELONG_TO_THE_SAME + "Tenant" + ": " + tenantId);
        }
    }

    public static void assertMatchingTenantId(String tenantId, Set<String> objTenantIds) {
        validateAllIdsAreUniform("Tenant", tenantId, objTenantIds);
    }
}
