/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital. The software may be
 * used and/or copied only with the written permission of GE Digital or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.model.view.TagComponent;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.crosstenancy.CrossTenancyGet;
import com.ge.apm.alm.persistence.exceptions.IncompatibleItemsException;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entitylistener.PostLoadHandler;
import com.ge.apm.alm.persistence.jpa.repository.TagInstanceRepository;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.sql.TagInstanceSQL;
import com.ge.apm.alm.persistence.jpa.utils.TypeJsonUtils;
import com.ge.apm.alm.persistence.mirror.Accessible;

import static com.ge.apm.alm.persistence.jpa.sql.QueryUtils.isUber;
import static com.ge.apm.alm.persistence.jpa.sql.SQLConstants.AND;
import static com.ge.apm.alm.persistence.jpa.utils.Validator.assertMatchingTenantId;

@Service
@Slf4j
public class TagPersistencyServiceImpl implements TagPersistencyService {

    @Autowired
    private DataSource dataSource;

    @Autowired
    private TagInstanceRepository tagInstanceRepository;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    @Autowired
    private ConversionService conversionService;

    @Autowired
    private JsonbAttributeConverter jsonbAttributeConverter;

    @Autowired
    private ListToTextArrayAttributeConverter listToTextArrayAttributeConverter;

    @Autowired
    private OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter;

    @Autowired
    private List<PostLoadHandler<TagInstanceEntity, TagComponent>> postLoadHandlers;

    private EntityBeanPropertyRowMapper<TagInstanceEntity> tagInstanceBeanPropertyRowMapper;

    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initializeConvertionService() {
        tagInstanceBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(TagInstanceEntity.class, conversionService);
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    // Create API's
    @Override
    @Transactional
    public Tag createTag(String tenantId, Collection<String> accessibleResources, Tag tag)
        throws PersistencyServiceException {
        assertMatchingTenantId(tenantId, tag.getTenantId());
        if (StringUtils.isEmpty(tag.getAssetId())) {
            throw new IllegalArgumentException("Tag must be associated with an asset: assetId is empty");
        }

        if (!isUber(accessibleResources) && assetPersistencyService.getAssetById(tenantId, accessibleResources,
            tag.getAssetId()) == null) {
            throw new ObjectNotFoundException(
                String.format("Cannot find asset %s for tenant %s.", tag.getAssetId(), tenantId));
        }

        if (!assetTypePersistencyService.isTypeASuperType(tenantId, OOTBCoreTypesIdLookup.TagType.getId(),
            tag.getTagType())) {
            throw new IllegalArgumentException("Invalid tag type: " + tag.getTagType());
        }

        TagInstanceEntity tagInstanceEntity;
        if (tag instanceof TagInstanceEntity) {
            tagInstanceEntity = (TagInstanceEntity) tag;
        } else {
            tagInstanceEntity = new TagInstanceEntity();
            BeanUtils.copyProperties(tag, tagInstanceEntity);
        }

        tagInstanceEntity.setTenantId(tenantId);
        List<String> superTypes = TypeJsonUtils.getSuperTypes(assetTypePersistencyService, tenantId, tag.getTagType());
        tagInstanceEntity.setSuperTypesArray(superTypes);
        return tagInstanceRepository.saveAndFlush(tagInstanceEntity);
    }

    @Override
    @Transactional
    public int createTags(final String tenantId, Collection<String> accessibleResources, final List<Tag> tags)
        throws PersistencyServiceException {

        validateTagsForBulkOperation(tenantId, accessibleResources, tags);

        Set<String> typeIds = tags.stream().map(Tag::getTagType).collect(Collectors.toSet());
        Map<String, List<String>> superTypesByTypeId = TypeJsonUtils.getSuperTypesByTypeIdWithTypeId(
            assetTypePersistencyService, tenantId, typeIds);
        int[] updateCounts = jdbcTemplate.batchUpdate(TagInstanceSQL.getBatchCreateSQL(),
            new TagBatchCreatePreparedStatementSetter(tenantId, tags, superTypesByTypeId, jsonbAttributeConverter,
                listToTextArrayAttributeConverter, offsetDateTimeAttributeConverter));

        return Arrays.stream(updateCounts).sum();
    }

    // Update API's
    @Override
    @Transactional
    public Tag updateTag(String tenantId, Collection<String> accessibleResources, Tag tag)
        throws PersistencyServiceException {
        try {
            return createTag(tenantId, accessibleResources, tag);
        } catch (JpaSystemException jse) {
            // e.g., this happens when API is invoked to update the assets assocated with the instances
            // the disable_tag_asset_update trigger will barf
            throw new PersistencyServiceException("Tag update failed.", jse);
        }
    }

    @Override
    @Transactional
    public int updateTags(String tenantId, Collection<String> accessibleResources, List<Tag> tags)
        throws PersistencyServiceException {

        validateTagsForBulkOperation(tenantId, accessibleResources, tags);

        Set<String> typeIds = tags.stream().map(Tag::getTagType).collect(Collectors.toSet());
        Map<String, List<String>> superTypesByTypeId = TypeJsonUtils.getSuperTypesByTypeIdWithTypeId(
            assetTypePersistencyService, tenantId, typeIds);

        try {
            int[] updateCounts = jdbcTemplate.batchUpdate(TagInstanceSQL.getBatchUpdateSQL(),
                new TagBatchUpdatePreparedStatementSetter(tenantId, tags, superTypesByTypeId, jsonbAttributeConverter,
                    listToTextArrayAttributeConverter, offsetDateTimeAttributeConverter));

            return Arrays.stream(updateCounts).sum();
        } catch (UncategorizedSQLException use) {
            // e.g., this happens when API is invoked to update the assets assocated with the instances
            // the disable_tag_asset_update trigger will barf
            throw new PersistencyServiceException("Bulk update for instances failed.", use);
        }
    }

    // Delete API's
    @Override
    @Transactional
    public int deleteTag(String tenantId, Collection<String> accessibleResources, String tagId)
        throws PersistencyServiceException {
        if (StringUtils.isEmpty(tagId)) {
            throw new IllegalArgumentException("Tag ID cannot be null");
        }

        String deleteQuery = TagInstanceSQL.buildDeleteTagQuery(tenantId, accessibleResources);
        int rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, tagId);
        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("Tag does not exist or user does not have access to it." + tagId);
        }
        return rowsDeleted;
    }

    @Override
    @Transactional
    public int deleteTags(String tenantId, Collection<String> accessibleResources, String assetId, Set<String> tagIds)
        throws PersistencyServiceException {
        int rowsDeleted = jdbcTemplate.update(
            TagInstanceSQL.buildDeleteTagsQuery(tenantId, assetId, accessibleResources, tagIds), tenantId, assetId);
        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("Tags do not exist or user does not have access to them.");
        }

        return rowsDeleted;
    }

    @Override
    @Transactional
    public int deleteTagsForAsset(String tenantId, Collection<String> accessibleResources, String assetId)
        throws PersistencyServiceException {
        String query = TagInstanceSQL.buildDeleteAllTagsForAssetQuery(tenantId, assetId, accessibleResources);
        int rowsDeleted = jdbcTemplate.update(query, tenantId, assetId);
        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("Tags do not exist or user does not have access to them " + assetId);
        }

        return rowsDeleted;
    }

    // Query API's
    @Override
    @CrossTenancyGet
    public Tag getTagById(String tenantId, Collection<String> accessibleResources, String id) {
        String query = TagInstanceSQL.getSelectById(AttributeSelectEnum.FULL, tenantId, accessibleResources);
        return getTagByIdOrSourceKey(tenantId, accessibleResources, id, query, null);
    }

    @Override
    @CrossTenancyGet
    public Tag getTagById(String tenantId, @Accessible Collection<String> accessibleResources, String id,
        Set<TagComponent> components) {
        String query = TagInstanceSQL.getSelectById(AttributeSelectEnum.FULL, tenantId,
            accessibleResources);
        return getTagByIdOrSourceKey(tenantId, accessibleResources, id, query, components);
    }

    @Override
    @Transactional
    public List<Tag> getTagsByIdsForUpdate(String tenantId, Collection<String> accessibleResources, List<String> ids) {
        String query = TagInstanceSQL.getSelectByIdsForUpdate(AttributeSelectEnum.BASIC, tenantId, accessibleResources,
            ids);
        return Collections.unmodifiableList(jdbcTemplate.query(query, tagInstanceBeanPropertyRowMapper, tenantId));
    }

    @Override
    @Transactional
    public Tag getTagBySourceKey(String tenantId, Collection<String> accessibleResources, String sourceKey) {
        if (StringUtils.isEmpty(sourceKey)) {
            return null;
        }
        String query = TagInstanceSQL.getSelectBySourceKey(AttributeSelectEnum.FULL, tenantId, accessibleResources);
        return getTagByIdOrSourceKey(tenantId, accessibleResources, sourceKey.toLowerCase(Locale.getDefault()),
            query, null);
    }

     private Tag getTagByIdOrSourceKey(String tenantId, Collection<String> accessibleResources,
        String idOrSrcKey, String query, Set<TagComponent> components) {
        try {
            TagInstanceEntity tag = jdbcTemplate.queryForObject(query,
                tagInstanceBeanPropertyRowMapper, tenantId, idOrSrcKey);
            if (tag != null) {
                postLoadHandlers.forEach(handler -> handler.postLoad(tenantId, accessibleResources, tag,
                    AttributeSelectEnum.FULL, components));
            }

            return tag;
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("Tag not found with identifier: {}", idOrSrcKey);
            return null;
        }
    }

    @Override
    @Transactional
    public List<Tag> getTagsBySourceKeys(String tenantId, Collection<String> accessibleResources,
        List<String> sourceKeys) {
        if (CollectionUtils.isEmpty(sourceKeys)) {
            return Collections.emptyList();
        }
        String query = TagInstanceSQL.getSelectBySourceKeys(AttributeSelectEnum.FULL, tenantId, accessibleResources,
            sourceKeys);
        return Collections.unmodifiableList(jdbcTemplate.query(query, tagInstanceBeanPropertyRowMapper, tenantId));
    }

    @Override
    @CrossTenancyGet
    public List<Tag> getTags(String tenantId, @Accessible Collection<String> accessibleResources, TagPredicate
        tagPredicate) {
        String andFilter = TagInstanceSQL.getFilterPredicate(tenantId, accessibleResources, tagPredicate);
        andFilter = StringUtils.isEmpty(andFilter) ? "" : " and " + andFilter;
        StringBuilder query = new StringBuilder(
            TagInstanceSQL.getSelectForCollection(tagPredicate.getAttributeSelectEnum()));
        query.append(andFilter);
        String greaterThan = QueryUtils.getNextPageSortKeyFilter(tagPredicate);
        if (!StringUtils.isEmpty(greaterThan)) {
            query.append(AND).append(greaterThan);
        }
        query.append(QueryUtils.getPagination(tagPredicate));
        List<TagInstanceEntity> tags = jdbcTemplate.query(query.toString(), tagInstanceBeanPropertyRowMapper, tenantId);
        if (!tags.isEmpty()) {
            postLoadHandlers.forEach(handler -> handler.postLoad(tenantId,
                QueryUtils.getComponentAccessibleResources(tagPredicate, accessibleResources), tags,
                tagPredicate.getAttributeSelectEnum(), tagPredicate.getComponents()));
        }

        return Collections.unmodifiableList(tags);
    }

    @Override
    @CrossTenancyGet
    public List<Tag> getCorrelatedTagsById(String tenantId, @Accessible Collection<String> accessibleResources, String id) {
        String query = TagInstanceSQL.getCorrelatedTagsById(tenantId, accessibleResources);
        return Collections.unmodifiableList(
            jdbcTemplate.query(query, tagInstanceBeanPropertyRowMapper, tenantId, tenantId, tenantId, id));
    }

    /**
     * Returns all instances associated with the given asset, filtered by the ACL and predicate.
     *
     * @param accessibleResources ACL
     * @param assetId id of the given asset
     * @param tagPredicate predicate to filter the instances
     *
     * @return list of instances associated with the give asset
     */
    @Override
    @Transactional
    public List<Tag> getTagsForAsset(String tenantId, Collection<String> accessibleResources, String assetId,
        boolean deepSearch, TagPredicate tagPredicate) {
        tagPredicate.setParent(ParentPredicate.builder().ids(Sets.newHashSet(assetId)).deepSearch(deepSearch).build());
        return getTags(tenantId, accessibleResources, tagPredicate);
    }

    private void validateTagsForBulkOperation(String tenantId, Collection<String> accessibleResources, List<Tag> tags)
        throws ObjectNotFoundException, IncompatibleItemsException {
        assertMatchingTenantId(tenantId, tags.stream().map(Tag::getTenantId).collect(Collectors.toSet()));
        if (!isUber(accessibleResources)) {
            Set<String> assetIds = tags.stream().map(Tag::getAssetId).collect(Collectors.toSet());
            try {
                assetPersistencyService.getAssetsByIds(tenantId, accessibleResources, assetIds);
            } catch (ObjectNotFoundException onfe) {
                throw new ObjectNotFoundException(
                    String.format("Cannot find all assets associated with the instances for tenant %s.", tenantId),
                    onfe);
            }
        }

        Set<String> typeIds = tags.stream().map(Tag::getTagType).collect(Collectors.toSet());
        if (!assetTypePersistencyService.allTypesAreCompatibleSuperType(tenantId, OOTBCoreTypesIdLookup.TagType.getId(),
            typeIds)) {
            throw new IncompatibleItemsException("Not all instances are compatible with tag type");
        }
    }
}
