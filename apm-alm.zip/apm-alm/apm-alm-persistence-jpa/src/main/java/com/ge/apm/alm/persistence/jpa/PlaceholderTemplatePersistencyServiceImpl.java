/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import static com.ge.apm.alm.persistence.jpa.utils.Validator.assertMatchingTenantId;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.PlaceholderTemplate;
import com.ge.apm.alm.persistence.PlaceholderTemplatePersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderTemplateEntity;
import com.ge.apm.alm.persistence.jpa.repository.PlaceholderTemplateRepository;
import com.ge.apm.alm.persistence.jpa.sql.PlaceholderTemplateSQL;

@Service
@Slf4j
@Transactional
public class PlaceholderTemplatePersistencyServiceImpl implements PlaceholderTemplatePersistencyService {

    private static final int QUERY_BATCH_SIZE = 500;

    @Autowired
    private DataSource dataSource;
    @Autowired
    private ConversionService conversionService;
    @Autowired
    private PlaceholderTemplateRepository placeholderTemplateRepository;

    private EntityBeanPropertyRowMapper<PlaceholderTemplateEntity> placeholderTemplateBeanPropertyRowMapper;
    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initializeConvertionService() {
        placeholderTemplateBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(PlaceholderTemplateEntity.class,
            conversionService);
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public PlaceholderTemplate createPlaceholderTemplate(String tenantId, PlaceholderTemplate placeholderTemplate) {
        assertMatchingTenantId(tenantId, placeholderTemplate.getTenantId());
        validatePlaceholderTemplate(placeholderTemplate);

        PlaceholderTemplateEntity entity = toPlaceholderTemplateEntity(tenantId, placeholderTemplate, true);
        return placeholderTemplateRepository.saveAndFlush(entity);
    }

    @Override
    public int createPlaceholderTemplates(String tenantId, List<PlaceholderTemplate> placeholderTemplates) {
        if (CollectionUtils.isEmpty(placeholderTemplates)) {
            return 0;
        }

        List<PlaceholderTemplateEntity> entities = new ArrayList<>();
        placeholderTemplates.stream().forEach(placeholderTemplate -> {
            assertMatchingTenantId(tenantId, placeholderTemplate.getTenantId());
            entities.add(toPlaceholderTemplateEntity(tenantId, placeholderTemplate, true));
        });

        int[] updateCounts = jdbcTemplate
            .batchUpdate(PlaceholderTemplateSQL.getBatchCreateSQL(), new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int index) throws SQLException {
                    PlaceholderTemplateEntity entity = entities.get(index);
                    ps.setString(1, entity.getId());
                    ps.setString(2, tenantId);
                    ps.setString(3, entity.getPlaceholderId());
                    ps.setString(4, entity.getTemplateId());
                    ps.setObject(5, entity.getStatus());
                    ps.setString(6, entity.getCreatedBy());
                    ps.setString(7, entity.getLastModifiedBy());
                }

                @Override
                public int getBatchSize() {
                    return placeholderTemplates.size();
                }
            });
        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public PlaceholderTemplate updatePlaceholderTemplate(String tenantId, PlaceholderTemplate placeholderTemplate)
        throws PersistencyServiceException {
        assertMatchingTenantId(tenantId, placeholderTemplate.getTenantId());

        PlaceholderTemplateEntity entity = toPlaceholderTemplateEntity(tenantId, placeholderTemplate, true);
        return placeholderTemplateRepository.saveAndFlush(entity);
    }

    @Override
    public int updatePlaceholderTemplates(String tenantId, List<PlaceholderTemplate> placeholderTemplates)
        throws PersistencyServiceException {
        if (placeholderTemplates.isEmpty()) {
            return 0;
        }

        int updateCounts = 0;
        for (PlaceholderTemplate placeholderTemplate : placeholderTemplates) {
            updatePlaceholderTemplate(tenantId, placeholderTemplate);
            updateCounts++;
        }
        return updateCounts;
    }

    @Override
    public int deletePlaceholderTemplateById(String tenantId, String id) throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderTemplateSQL.getDeleteByIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, id);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                "PlaceholderTemplate has references to it. Hence cannot be deleted", ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException(id);
        }
        return rowsDeleted;
    }

    @Override
    public int deletePlaceholderTemplateByPlaceholderIdAndTemplateId(String tenantId, String placeholderId,
        String templateId)
        throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderTemplateSQL.getDeleteByPlaceholderIdAndTemplateIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, placeholderId, templateId);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                "PlaceholderType has references to it. Hence cannot be deleted", ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("placeholderId:" + placeholderId + ", templateId:" + templateId);
        }
        return rowsDeleted;
    }

    @Override
    public int deletePlaceholderTemplateByPlaceholderId(String tenantId, String placeholderId)
        throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderTemplateSQL.getDeleteByPlaceholderIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, placeholderId);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                "PlaceholderType has references to it. Hence cannot be deleted", ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("placeholderId:" + placeholderId);
        }
        return rowsDeleted;
    }

    @Override
    public PlaceholderTemplate getPlaceholderTemplateById(String tenantId, String id) {
        try {
            String query = PlaceholderTemplateSQL.getSelectSingleObjectById();
            return jdbcTemplate.queryForObject(query, placeholderTemplateBeanPropertyRowMapper, tenantId, id);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("PlaceholderTemplate not found with identifier: {}", id);
            return null;
        }
    }

    @Override
    public PlaceholderTemplate getPlaceholderTemplateByPlaceholderId(String tenantId, String placeholderId) {
        try {
            String query = PlaceholderTemplateSQL.getSelectCollectionObjectsByPlaceholderId();
            return jdbcTemplate.queryForObject(query, placeholderTemplateBeanPropertyRowMapper,
                tenantId, placeholderId);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("PlaceholderTemplate not found with identifier: {}", placeholderId);
            return null;
        }
    }

    @Override
    public List<PlaceholderTemplate> getPlaceholderTemplateByTemplateId(String tenantId, String templateId) {
        String query = PlaceholderTemplateSQL.getSelectCollectionObjectsByTemplateId();
        return Collections.unmodifiableList(jdbcTemplate.query(query, placeholderTemplateBeanPropertyRowMapper,
            tenantId, templateId));
    }

    @Override
    public List<PlaceholderTemplate> getPlaceholderTemplates(String tenantId, List<String> placeholderIds) {
        if (placeholderIds.isEmpty()) {
            return Collections.emptyList();
        }

        List<PlaceholderTemplateEntity> placeholderTemplateEntities = new ArrayList<>();
        int counter = 0;
        int size = placeholderIds.size();

        while (counter < size) {
            int endIndex = counter + QUERY_BATCH_SIZE < size ? counter + QUERY_BATCH_SIZE : size;
            List<String> batchPlaceholderIdList = placeholderIds.subList(counter, endIndex);
            String query = PlaceholderTemplateSQL
                .getSelectCollectionObjectsByPlaceholderIds(batchPlaceholderIdList);
            placeholderTemplateEntities.addAll(jdbcTemplate.query(query, placeholderTemplateBeanPropertyRowMapper,
                tenantId));

            counter = endIndex;
        }
        return Collections.unmodifiableList(placeholderTemplateEntities);
    }

    @Override
    public List<PlaceholderTemplate> getPlaceholderTemplates(String tenantId, String compositeTemplateId) {
        String query = PlaceholderTemplateSQL.getSelectCollectionObjectsByCompositeTemplateId();
        return Collections.unmodifiableList(jdbcTemplate.query(query, placeholderTemplateBeanPropertyRowMapper,
            tenantId, compositeTemplateId));
    }

    private void validatePlaceholderTemplate(PlaceholderTemplate placeholderTemplate) {
        StringBuilder builder = new StringBuilder();
        if (StringUtils.isEmpty(placeholderTemplate.getId())) {
            builder.append("PlaceholderTemplate Id is empty. ");
        }
        if (StringUtils.isEmpty(placeholderTemplate.getPlaceholderId())) {
            builder.append("PlaceholderTemplate placeholderId is empty. ");
        }
        if (StringUtils.isEmpty(placeholderTemplate.getTemplateId())) {
            builder.append("PlaceholderTemplate templateId is empty. ");
        }
        if (StringUtils.isEmpty(placeholderTemplate.getStatus())) {
            builder.append("PlaceholderTemplate Status is empty. ");
        }

        if (!builder.toString().isEmpty()) {
            throw new IllegalArgumentException(builder.toString());
        }
    }

    private PlaceholderTemplateEntity toPlaceholderTemplateEntity(String tenantId,
        PlaceholderTemplate placeholderTemplate,
        boolean isAdd) {
        PlaceholderTemplateEntity entity = new PlaceholderTemplateEntity();
        entity.setId(placeholderTemplate.getId());
        entity.setTenantId(tenantId);
        entity.setPlaceholderId(placeholderTemplate.getPlaceholderId());
        entity.setTemplateId(placeholderTemplate.getTemplateId());
        entity.setStatus(placeholderTemplate.getStatus());
        if (isAdd) {
            entity.setCreatedBy(placeholderTemplate.getCreatedBy());
        }
        entity.setLastModifiedBy(placeholderTemplate.getLastModifiedBy());
        return entity;
    }
}
