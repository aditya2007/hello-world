/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.AssetGroupItem;

@Entity
@Table(name = "asset_group_tag_instance", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class TagInstanceGroupItemEntity extends BaseEntity implements AssetGroupItem {

    @Column(name = "group_id")
    private String groupId;

    @Column(name = "object_id")
    private String objectId;

    @Transient
    @JsonIgnore
    private TagInstanceEntity object;

    @Builder
    private TagInstanceGroupItemEntity(String id, String groupId, String objectId, String tenantId) {
        super(id, tenantId);
        this.groupId = groupId;
        this.objectId = objectId;
    }

    @Override
    public int getPosition() {
        return 0;
    }
}

