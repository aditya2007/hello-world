/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.sql;

import java.util.List;

import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.PlaceholderPredicate;

public final class PlaceholderSQL {

    private static final String DELETE_PLACEHOLDER = "delete from apm_alm.placeholder ";
    private static final String ID_COLUMN = "select id from apm_alm.placeholder ";
    private static final String ALL_COLUMNS = "select * from apm_alm.placeholder ";
    private static final String BASIC_COLUMNS = "select id, source_key, name, description, tenant_id, "
        + " template_id, part_position_number, parent_id, created_by, created_date, last_modified_by,"
        + " last_modified_date from apm_alm.placeholder";
    private static final String BASIC_COLUMNS_WITH_ATTRIBUTES = "select id, source_key, name, description, "
        + " tenant_id, template_id, part_position_number, parent_id, attributes, created_by, created_date, "
        + " last_modified_by, last_modified_date from apm_alm.placeholder";
    private static final String WHERE_TENANT_ID = " where tenant_id = ? ";
    private static final String WHERE_TENANT_ID_AND_ID = " where tenant_id = ? and id = ? ";
    private static final String WHERE_TENANT_ID_AND_TEMPLATE_ID = " where tenant_id = ? and template_id = ? ";

    private static final String WHERE_TENANT_ID_AND_TEMPLATE_ID_AND_PPN = " where tenant_id = ? and template_id = ? "
        + " and part_position_number = ? ";

    private static final String BATCH_CREATE_SQL = "insert into apm_alm.placeholder(id, source_key, name, "
        + " description, tenant_id, template_id, part_position_number, parent_id, attributes, created_by, "
        + " last_modified_by) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private PlaceholderSQL() {
    }

    public static String getBatchCreateSQL() {
        return BATCH_CREATE_SQL;
    }

    public static String getDeletePlaceholderByIdSQL() {
        return DELETE_PLACEHOLDER + WHERE_TENANT_ID + " and id = ? ";
    }

    public static String getSelectSingleObjectById(AttributeSelectEnum attributeSelectEnum) {
        return getSelectAttributes(attributeSelectEnum) + WHERE_TENANT_ID_AND_ID;
    }

    public static String getSelectSingleObjectByTemplateIdAndPpn(AttributeSelectEnum attributeSelectEnum) {
        return getSelectAttributes(attributeSelectEnum) + WHERE_TENANT_ID_AND_TEMPLATE_ID_AND_PPN;
    }

    public static String getSelectCollectionObjectsByTemplateId(AttributeSelectEnum attributeSelectEnum) {
        return getSelectAttributes(attributeSelectEnum) + WHERE_TENANT_ID_AND_TEMPLATE_ID;
    }

    public static String getSelectCollectionObjects(AttributeSelectEnum attributeSelectEnum) {
        return getSelectAttributes(attributeSelectEnum) + WHERE_TENANT_ID;
    }

    public static String getSelectAttributes(AttributeSelectEnum attributeSelectEnum) {
        if (attributeSelectEnum == null) {
            return BASIC_COLUMNS;
        }

        String query;
        switch (attributeSelectEnum) {
            case ID:
                query = ID_COLUMN;
                break;
            case FULL:
                query = ALL_COLUMNS;
                break;
            case ATTRIBUTES:
                query = BASIC_COLUMNS_WITH_ATTRIBUTES;
                break;
            default:
                query = BASIC_COLUMNS;
                break;
        }
        return query;
    }

    public static String getFilterPredicate(PlaceholderPredicate placeholderPredicate) {
        if (placeholderPredicate == null) {
            return "";
        }

        // current template context
        List<String> expressions =
            QueryUtils
                .getEqualOrLikeFilterExpressions(placeholderPredicate, placeholderPredicate.getAttributes(),
                    placeholderPredicate.getReservedAttributes());

        final String partPositionNumber = placeholderPredicate.getPartPositionNumber();
        if (!StringUtils.isEmpty(partPositionNumber) && QueryUtils.hasWildcard(partPositionNumber)) {
            expressions.add(QueryUtils.getFilterExpForTerm("part_position_number", partPositionNumber));
        } else if (!StringUtils.isEmpty(partPositionNumber)) {
            expressions.add("part_position_number = ?");
        }

        if (!StringUtils.isEmpty(placeholderPredicate.getTemplateId())) {
            expressions.add("template_id = ?");
        }
        if (!StringUtils.isEmpty(placeholderPredicate.getParentId())) {
            expressions.add("parent_id = ?");
        }

        String predicate = QueryUtils.flattenExpressions(expressions, Operand.AND);
        return predicate.length() > 0 ? " and " + predicate : "";
    }
}

