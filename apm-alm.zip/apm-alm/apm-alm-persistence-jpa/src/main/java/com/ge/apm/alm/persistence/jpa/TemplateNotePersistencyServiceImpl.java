/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.querydsl.QPageRequest;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.Notes;
import com.ge.apm.alm.model.TemplateNotes;
import com.ge.apm.alm.model.query.TemplateNotesPredicate;
import com.ge.apm.alm.persistence.TemplateNotePersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.entity.NotesEntity;
import com.ge.apm.alm.persistence.jpa.entity.TemplateNotesEntity;
import com.ge.apm.alm.persistence.jpa.repository.TemplateNotesRepository;
import com.ge.apm.alm.persistence.jpa.sql.TemplateNotesSQL;

import static com.ge.apm.alm.persistence.jpa.utils.Validator.assertMatchingTenantId;

@Service
@Slf4j
@Transactional
public class TemplateNotePersistencyServiceImpl implements TemplateNotePersistencyService {

    @Autowired
    private DataSource dataSource;
    @Autowired
    private TemplateNotesRepository templateNotesRepository;

    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initializeConvertionService() {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public TemplateNotes createTemplateNote(String tenantId, TemplateNotes templateNote) {
        assertMatchingTenantId(tenantId, templateNote.getTenantId());
        validateTemplateNotes(templateNote);

        TemplateNotesEntity templateNotesEntity = toTemplateNotesEntity(tenantId, templateNote);
        return templateNotesRepository.saveAndFlush(templateNotesEntity);
    }

    @Override
    public int createTemplateNotes(String tenantId, List<TemplateNotes> templateNotes) {
        if (CollectionUtils.isEmpty(templateNotes)) {
            return 0;
        }

        List<TemplateNotesEntity> templateNotesList = new ArrayList<>();
        templateNotes.forEach(t -> {
            assertMatchingTenantId(tenantId, t.getTenantId());
            validateTemplateNotes(t);
            templateNotesList.add(toTemplateNotesEntity(tenantId, t));
        });

        int[] updateCounts = jdbcTemplate
            .batchUpdate(TemplateNotesSQL.getBatchCreateSQL(), new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int index) throws SQLException {
                    TemplateNotesEntity entity = templateNotesList.get(index);
                    ps.setString(1, entity.getId());
                    ps.setString(2, tenantId);
                    ps.setString(3, entity.getTemplateId());
                    ps.setString(4, entity.getNotes().getId());
                }

                @Override
                public int getBatchSize() {
                    return templateNotes.size();
                }
            });

        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public TemplateNotes updateTemplateNote(String tenantId, TemplateNotes templateNote)
        throws PersistencyServiceException {
        assertMatchingTenantId(tenantId, templateNote.getTenantId());

        TemplateNotesEntity notesEntity = toTemplateNotesEntity(tenantId, templateNote);
        return templateNotesRepository.saveAndFlush(notesEntity);
    }

    @Override
    public int deleteTemplateNotesByTemplateId(String tenantId, String templateId) throws PersistencyServiceException {
        int rowsDeleted;
        try {
            String deleteQuery = TemplateNotesSQL.getDeleteByTemplateIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, templateId);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                "TemplateNotes has references to it. Hence cannot be deleted", ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException(templateId);
        }
        return rowsDeleted;
    }

    @Override
    public int deleteTemplateNoteById(String tenantId, String id) throws PersistencyServiceException {
        int rowsDeleted;
        try {
            String deleteQuery = TemplateNotesSQL.getDeleteByIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, id);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                "TemplateNotes has references to it. Hence cannot be deleted", ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException(id);
        }
        return rowsDeleted;
    }

    @Override
    public TemplateNotes getTemplateNoteById(String tenantId, String id) {
        return templateNotesRepository.findByTenantIdAndId(tenantId, id);
    }

    @Override
    public List<TemplateNotes> getTemplateNotes(String tenantId, TemplateNotesPredicate queryPredicate) {

        int page = queryPredicate.getOffset() > 0 ? queryPredicate.getOffset() : 0;
        int size = queryPredicate.getPageSize() > 0 ? queryPredicate.getPageSize() : 250;
        QPageRequest pageRequest = new QPageRequest(page, size);

        boolean isTemplateIdExistFlag = !StringUtils.isEmpty(queryPredicate.getTemplateId());
        boolean isNotesIdExistFlag = !StringUtils.isEmpty(queryPredicate.getNoteId());

        if (isTemplateIdExistFlag && isNotesIdExistFlag) {
            return Collections.unmodifiableList(templateNotesRepository.findByTenantIdAndTemplateIdAndNotesId(tenantId,
                queryPredicate.getTemplateId(), queryPredicate.getNoteId(), pageRequest));
        } else if (isTemplateIdExistFlag) {
            return Collections.unmodifiableList(templateNotesRepository.findByTenantIdAndTemplateId(
                tenantId, queryPredicate.getTemplateId(), pageRequest));
        } else if (isNotesIdExistFlag) {
            return Collections.unmodifiableList(templateNotesRepository.findByTenantIdAndNotesId(
                tenantId, queryPredicate.getNoteId(), pageRequest));
        } else {
            return Collections.unmodifiableList(templateNotesRepository.findByTenantId(tenantId));
        }
    }

    private void validateTemplateNotes(TemplateNotes templateNotes) {
        StringBuilder builder = new StringBuilder();
        if (StringUtils.isEmpty(templateNotes.getTemplateId())) {
            builder.append("templateId is empty. ");
        }
        if (templateNotes.getNotes() == null || StringUtils.isEmpty(templateNotes.getNotes().getId())) {
            builder.append("notes is empty. ");
        }

        if (!builder.toString().isEmpty()) {
            throw new IllegalArgumentException(builder.toString());
        }
    }

    private TemplateNotesEntity toTemplateNotesEntity(String tenantId, TemplateNotes templateNotes) {
        TemplateNotesEntity entity = new TemplateNotesEntity();
        entity.setId(templateNotes.getId());
        entity.setTenantId(tenantId);
        entity.setTemplateId(templateNotes.getTemplateId());
        entity.setNotes(toNotesEntity(tenantId, templateNotes.getNotes()));
        return entity;
    }

    private NotesEntity toNotesEntity(String tenantId, Notes notes) {
        NotesEntity notesEntity = new NotesEntity();
        notesEntity.setTenantId(tenantId);
        notesEntity.setId(notes.getId());
        notesEntity.setName(notes.getName());
        notesEntity.setContent(notes.getContent());
        notesEntity.setCreatedBy(notes.getCreatedBy());
        notesEntity.setLastModifiedBy(notes.getLastModifiedBy());
        return notesEntity;
    }
}
