/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.apm.alm.model.Context;
import com.ge.apm.alm.persistence.ContextPersistencyService;
import com.ge.apm.alm.persistence.jpa.repository.IContextRepository;

@Service
public class ContextPersistencyServiceImpl implements ContextPersistencyService {

    @Autowired
    private IContextRepository contextRepository;

    @Override
    public Context findByContextName(String name) {
        return contextRepository.findByContextName(name);
    }
}
