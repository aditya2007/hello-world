/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.sql;

import java.text.MessageFormat;
import java.util.Collection;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.AttributeSelectEnum;

public final class AssetGroupAssociationSQL {

    private static final String DELETE_FROM_GROUP_ITEM = "delete from {0} ";

    private static final String SELECT_FROM_GROUP_ITEM = "select * from {0} ";

    private static final String WHERE_TENANT_ID = " where tenant_id = ? ";

    private static final String AND_OBJECT_ID_IN = " and object_id in ";

    private static final String AND_A_OBJECT_ID_IN = " and a.object_id in ";

    private static final String AND_OBJECT_ID_CLAUSE = " and object_id = ?";

    private static final String AND_GROUP_ID_CLAUSE = " and group_id = ?";

    private static final String SELECT_ALL_FROM = "select * from {0}";

    private static final String AND_CATEGORY_IS = " and category = ?";

    private static final String AND_G_CATEGORY_IS = " and g.category = ?";

    private static final String AND_ID_IN = " and id in ";

    private static final String SELECT_GROUP_ID_FROM_GROUP_ASSOCIATION = " select group_id from {1}";

    private static final String SELECT_ASSET_ID_FROM_GROUP_ASSOCIATION = " select object_id from {1}";

    private static final String WHERE_ASSET_ID_IS = " where object_id = ?";

    private static final String WHERE_GROUP_ID_IS = " where group_id = ?";

    private static final String DELETE_ASSET_GROUP_ASSOCIATIONS_BY_OBJECT_ID = DELETE_FROM_GROUP_ITEM + WHERE_TENANT_ID
        + AND_OBJECT_ID_CLAUSE;

    private static final String DELETE_ASSET_GROUP_ASSOCIATIONS_BY_GROUP_ID = DELETE_FROM_GROUP_ITEM + WHERE_TENANT_ID
        + AND_GROUP_ID_CLAUSE;

    private static final String DELETE_ASSET_GROUP_ASSOCIATIONS_BY_GROUP_ID_AND_OBJECT_ID = DELETE_FROM_GROUP_ITEM
        + WHERE_TENANT_ID + AND_GROUP_ID_CLAUSE + AND_OBJECT_ID_CLAUSE;

    private static final String SELECT_ASSET_GROUP_ASSOCIATIONS_BY_GROUP_ID = SELECT_FROM_GROUP_ITEM + WHERE_TENANT_ID
        + AND_GROUP_ID_CLAUSE;

    private static final String SELECT_ASSET_GROUP_ASSOCIATIONS_BY_OBJECT_ID = SELECT_FROM_GROUP_ITEM + WHERE_TENANT_ID
        + AND_OBJECT_ID_CLAUSE;

    private static final String SELECT_ASSET_GROUP_ASSOCIATIONS_BY_GROUP_ID_AND_OBJECT_ID = SELECT_FROM_GROUP_ITEM
        + WHERE_TENANT_ID + AND_GROUP_ID_CLAUSE + AND_OBJECT_ID_CLAUSE;

    private static final String SELECT_GROUPS_BY_ASSET_OBJECT_ID = SELECT_ALL_FROM + WHERE_TENANT_ID + AND_ID_IN + "("
        + SELECT_GROUP_ID_FROM_GROUP_ASSOCIATION + WHERE_ASSET_ID_IS;

    private static final String SELECT_GROUPS_BY_ASSET_OBJECT_ID_NO_CATEGORY = SELECT_ALL_FROM + WHERE_TENANT_ID
        + AND_ID_IN + "(" + SELECT_GROUP_ID_FROM_GROUP_ASSOCIATION + WHERE_ASSET_ID_IS;

    private static final String SELECT_GROUPS_BY_ASSET_OBJECT_IDS = "select g.*, a.object_id from {0} g join {1} a"
        + " on g.tenant_id = a.tenant_id and g.id = a.group_id where g.tenant_id = ? and a.object_id in ({2}) ";

    private static final String SELECT_ASSETS_BY_GROUP_ID = SELECT_ALL_FROM + WHERE_TENANT_ID + AND_ID_IN + "("
        + SELECT_ASSET_ID_FROM_GROUP_ASSOCIATION + WHERE_GROUP_ID_IS;

    private static final String ASSET_GROUP_ASSOCIATIONS_TABLE = "apm_alm.asset_group_association";

    private static final String ASSET_GROUP_TABLE = "apm_alm.asset_group";

    private static final String ASSET_INSTANCE_TABLE = "apm_alm.asset_instance";

    private AssetGroupAssociationSQL() {
    }

    public static String getSelectAssetGroupAssociationsByGroupId(Collection<String> accessibleResources) {
        String selectSql = MessageFormat.format(SELECT_ASSET_GROUP_ASSOCIATIONS_BY_GROUP_ID,
            ASSET_GROUP_ASSOCIATIONS_TABLE);
        return getSecuredSQLForAssetGroupAssociations(accessibleResources, selectSql, AND_OBJECT_ID_IN);
    }

    public static String getSelectAssetGroupAssociationsByObjectId(Collection<String> accessibleResources) {
        String selectSql = MessageFormat.format(SELECT_ASSET_GROUP_ASSOCIATIONS_BY_OBJECT_ID,
            ASSET_GROUP_ASSOCIATIONS_TABLE);
        return getSecuredSQLForAssetGroupAssociations(accessibleResources, selectSql, AND_OBJECT_ID_IN);
    }

    public static String getSelectAssetGroupAssociationsByGroupIdAndObjectId(Collection<String> accessibleResources) {
        String selectSql = MessageFormat.format(SELECT_ASSET_GROUP_ASSOCIATIONS_BY_GROUP_ID_AND_OBJECT_ID,
            ASSET_GROUP_ASSOCIATIONS_TABLE);
        return getSecuredSQLForAssetGroupAssociations(accessibleResources, selectSql, AND_OBJECT_ID_IN);
    }

    public static String getDeleteAssetGroupAssociationsByGroupId(Collection<String> accessibleResources) {
        String deleteSql = MessageFormat.format(DELETE_ASSET_GROUP_ASSOCIATIONS_BY_GROUP_ID,
            ASSET_GROUP_ASSOCIATIONS_TABLE);
        return getSecuredSQLForAssetGroupAssociations(accessibleResources, deleteSql, AND_OBJECT_ID_IN);
    }

    public static String getDeleteAssetGroupAssociationsByObjectId(Collection<String> accessibleResources) {
        String deleteSql = MessageFormat.format(DELETE_ASSET_GROUP_ASSOCIATIONS_BY_OBJECT_ID,
            ASSET_GROUP_ASSOCIATIONS_TABLE);
        return getSecuredSQLForAssetGroupAssociations(accessibleResources, deleteSql, AND_OBJECT_ID_IN);
    }

    public static String getDeleteAssetGroupAssociationsByGroupIdAndObjectId(Collection<String> accessibleResources) {
        String deleteSql = MessageFormat.format(DELETE_ASSET_GROUP_ASSOCIATIONS_BY_GROUP_ID_AND_OBJECT_ID,
            ASSET_GROUP_ASSOCIATIONS_TABLE);
        return getSecuredSQLForAssetGroupAssociations(accessibleResources, deleteSql, AND_OBJECT_ID_IN);
    }

    public static String getGroupsByAssetId(Collection<String> accessibleResources, String category) {
        String getGroupsSql;
        if (!StringUtils.isEmpty(category)) {
            getGroupsSql = MessageFormat.format(SELECT_GROUPS_BY_ASSET_OBJECT_ID, ASSET_GROUP_TABLE,
                ASSET_GROUP_ASSOCIATIONS_TABLE);
            return getSecuredSQLForAssetGroupAssociations(accessibleResources, getGroupsSql, AND_OBJECT_ID_IN) + ")"
                + AND_CATEGORY_IS;
        } else {
            getGroupsSql = MessageFormat.format(SELECT_GROUPS_BY_ASSET_OBJECT_ID_NO_CATEGORY, ASSET_GROUP_TABLE,
                ASSET_GROUP_ASSOCIATIONS_TABLE);
            return getSecuredSQLForAssetGroupAssociations(accessibleResources, getGroupsSql, AND_OBJECT_ID_IN) + ")";
        }
    }

    public static String getGroupsByAssetIds(Collection<String> accessibleResources, String category,
        Collection<String> assetIds) {
        String getGroupsSql;
        if (!StringUtils.isEmpty(category)) {
            getGroupsSql = MessageFormat.format(SELECT_GROUPS_BY_ASSET_OBJECT_IDS, ASSET_GROUP_TABLE,
                ASSET_GROUP_ASSOCIATIONS_TABLE, QueryUtils.getSqlListOfResources(assetIds));
            return getSecuredSQLForAssetGroupAssociations(accessibleResources, getGroupsSql, AND_A_OBJECT_ID_IN)
                + AND_G_CATEGORY_IS;
        } else {
            getGroupsSql = MessageFormat.format(SELECT_GROUPS_BY_ASSET_OBJECT_IDS, ASSET_GROUP_TABLE,
                ASSET_GROUP_ASSOCIATIONS_TABLE, QueryUtils.getSqlListOfResources(assetIds));
            return getSecuredSQLForAssetGroupAssociations(accessibleResources, getGroupsSql, AND_A_OBJECT_ID_IN);
        }
    }

    public static String getAssetsByGroupId(Collection<String> accessibleResources) {
        String getAssetsSql = MessageFormat.format(SELECT_ASSETS_BY_GROUP_ID, ASSET_INSTANCE_TABLE,
            ASSET_GROUP_ASSOCIATIONS_TABLE);
        return getSecuredSQLForAssetGroupAssociations(accessibleResources, getAssetsSql, AND_OBJECT_ID_IN) + ")";
    }

    private static String getSecuredSQLForAssetGroupAssociations(Collection<String> accessibleResources, String sql,
        String andCondition) {
        if (CollectionUtils.isEmpty(accessibleResources) && !AssetInstanceSQL.hasApplicablePolicies(
            accessibleResources)) {
            return sql;
        }
        String aclClause = AssetInstanceSQL.getSelectWithAccessControlSqlForCollection(AttributeSelectEnum.ID,
            accessibleResources);
        return sql + andCondition + " ( " + aclClause + " ) ";
    }
}
