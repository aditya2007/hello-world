/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.ge.apm.alm.model.PlaceholderGroupTagType;

@Entity
@Table(name = "placeholder_group_tag_type", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class PlaceholderGroupTagTypeEntity extends AuditableEntity implements PlaceholderGroupTagType {

    @Column(name = "group_id")
    private String groupId;

    @Column(name = "placeholder_id")
    private String placeholderId;

    @Column(name = "category")
    private String category;

    @Builder
    private PlaceholderGroupTagTypeEntity(String id, String placeholderId, String groupId, String category,
        String tenantId, String createdBy, String lastModifiedBy) {
        super(id, tenantId, createdBy, lastModifiedBy);
        this.groupId = groupId;
        this.placeholderId = placeholderId;
        this.category = category;
    }
}

