/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import lombok.Getter;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetHierarchy;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.persistence.jpa.entity.AssetGroupEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceGroupItemEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagCorrelationItemEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceGroupItemEntity;

/**
 * A default implementation of the {@link com.ge.apm.alm.model.AssetHierarchy}.
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Jun 1, 2017
 * @since 1.0
 */
@Getter
public class AssetHierarchyImpl implements AssetHierarchy {

    private final OOTBCoreTypesIdLookup coreType;
    private final Asset asset;
    private final int assetCount;
    private final List<AssetHierarchy> children;
    private final Map<AssetGroup, AssetGroupItem> assetGroups;
    private final Map<AssetGroup, List<AssetGroupItem>> tagGroups;
    private final Map<AssetGroup, List<AssetGroupItem>> tagCorrelations;
    private final List<Tag> tags;

    public AssetHierarchyImpl(String assetId, List<AssetInstanceEntity> assets, List<AssetGroup> groups,
        List<AssetInstanceGroupItemEntity> assetGroupItems, List<TagInstanceGroupItemEntity> tagGroupItems,
        List<TagCorrelationItemEntity> tagCorrelationItems, List<AssetGroupEntity> tagCorrelationGroups,
        List<TagInstanceEntity> tags) {
        this.assetCount = assets.size();
        if (this.assetCount > 0) {
            this.asset = assets.stream().filter(a -> a.getId().equals(assetId)).collect(rootCollector());
            this.coreType = AssetJsonUtils.getCoreType(asset);
            Map<String, AssetGroup> groupMap = groups.stream().collect(Collectors.toMap(AssetGroup::getId, x -> x));
            this.assetGroups =
                assetGroupItems.stream().filter(a -> a.getObjectId().equals(assetId))
                    .collect(Collectors.toMap(x -> groupMap.get(x.getGroupId()), x -> x));
            this.tags = tags.stream().filter(a -> a.getAssetId().equals(assetId)).collect(Collectors.toList());
            Set<String> myTagIds = this.tags.stream().map(Tag::getId).collect(Collectors.toSet());
            Map<String, List<AssetGroupItem>> tagGroupItemsByGroupId =
                tagGroupItems.stream().filter(a -> myTagIds.contains(a.getObjectId()))
                    .collect(Collectors.groupingBy(AssetGroupItem::getGroupId));
            this.tagGroups = new HashMap<>();
            for (Map.Entry<String, List<AssetGroupItem>> e : tagGroupItemsByGroupId.entrySet()) {
                this.tagGroups.put(groupMap.get(e.getKey()), e.getValue());
            }
            Map<String, List<AssetGroupItem>> tagCorrelationsByGroupId =
                tagCorrelationItems.stream().filter(a -> myTagIds.contains(a.getObjectId()))
                    .collect(Collectors.groupingBy(AssetGroupItem::getGroupId));
            Set<String> myTagCorrelationGroupIds = tagCorrelationsByGroupId.keySet();

            Map<String, List<AssetGroup>> tagCorrelationGroupsByGroupId =
                tagCorrelationGroups.stream().filter(a -> myTagCorrelationGroupIds.contains(a.getId()))
                    .collect(Collectors.groupingBy(AssetGroup::getId));
            this.tagCorrelations = new HashMap<>();
            for (Map.Entry<String, List<AssetGroupItem>> e : tagCorrelationsByGroupId.entrySet()) {
                this.tagCorrelations.put(tagCorrelationGroupsByGroupId.get(e.getKey()).get(0), e.getValue());
            }
            this.children = new ArrayList<>();
            List<AssetInstanceEntity> immediateChildren =
                assets.stream().filter(a -> AssetJsonUtils.isImmediateChild(assetId, a)).collect(Collectors.toList());
            for (AssetInstanceEntity child : immediateChildren) {
                List<AssetInstanceEntity> all = new ArrayList<>();
                all.add(child);
                all.addAll(
                    assets.stream().filter(a -> AssetJsonUtils.isAChild(child.getId(), a))
                        .collect(Collectors.toList()));
                this.children.add(
                    new AssetHierarchyImpl(child.getId(), all, groups, assetGroupItems, tagGroupItems,
                        tagCorrelationItems,
                        tagCorrelationGroups, tags));
            }
        } else {
            this.coreType = null;
            this.asset = null;
            this.children = Collections.emptyList();
            this.assetGroups = Collections.emptyMap();
            this.tagGroups = Collections.emptyMap();
            this.tagCorrelations = Collections.emptyMap();
            this.tags = Collections.emptyList();
        }
    }

    private <T> Collector<T, ?, T> rootCollector() {
        return Collectors.collectingAndThen(
            Collectors.toList(),
            list -> {
                if (list.size() != 1) {
                    throw new IllegalStateException("Root asset not found in hierarchy.");
                }
                return list.get(0);
            }
        );
    }
}
