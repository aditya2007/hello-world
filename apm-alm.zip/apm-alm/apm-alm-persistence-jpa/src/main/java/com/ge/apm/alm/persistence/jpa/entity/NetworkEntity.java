/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entity;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.Edge;
import com.ge.apm.alm.model.Network;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;

/**
 * @author Albert H. Yu 212365823
 * @version 1.0 July 15, 2017
 * @since 1.0
 */
@Entity
@Table(name = "network_node", schema = "apm_alm")
@Getter
@Setter
@NoArgsConstructor
@ToString(callSuper = true)
public class NetworkEntity extends SourceableEntity implements Network {

    @Column(name = "attributes")
    @Convert(converter = JsonbAttributeConverter.class)
    private JsonNode attributes;

    @Column(name = "asset_id")
    private String assetId;

    @Transient
    private Asset asset;
    @Transient
    private List<Network> nodes;

    @Transient
    private List<Edge> edges;

    @Transient
    private List<Network> networks;

    @Builder
    private NetworkEntity(String id, String name, String tenantId, String createdBy,
        String lastModifiedBy,
        String sourceKey, String description, JsonNode attributes, String assetId) {
        super(id, name, tenantId, createdBy, lastModifiedBy, sourceKey, description);
        this.attributes = attributes;
        this.assetId = assetId;
    }
}

