/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.persistence.jpa.entity.SourceableEntity;

/**
 * Entity event listener similar to JPA's @PostLoad handler
 */
public interface PostLoadHandler<T extends SourceableEntity, C extends Enum<C>> {

    void postLoad(String tenantId, Collection<String> accessibleResources, T entity,
        AttributeSelectEnum selectEnum, Set<C> components);

    void postLoad(String tenantId, Collection<String> accessibleResources, List<T> entities,
        AttributeSelectEnum selectEnum, Set<C> components);
}
