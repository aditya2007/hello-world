/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;

class AssetTypeBatchCreatePreparedStatementSetter extends AssetBatchPreparedStatementSetter<AssetType> {

    AssetTypeBatchCreatePreparedStatementSetter(String tenantId, List<AssetType> types,
        Map<String, List<String>> superTypesById, JsonbAttributeConverter jsonbAttributeConverter,
        ListToTextArrayAttributeConverter listToTextArrayAttributeConverter,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter) {
        super(tenantId, types, superTypesById, jsonbAttributeConverter, listToTextArrayAttributeConverter,
            offsetDateTimeAttributeConverter);
    }

    @Override
    protected String getTypeId(AssetType assetType) {
        return assetType.getSuperTypeId();
    }

    @Override
    public void setValues(PreparedStatement ps, int index) throws SQLException {
        AssetType type = instances.get(index);
        ps.setString(1, type.getId());
        ps.setString(2, type.getSourceKey());
        ps.setString(3, type.getName());
        ps.setString(4, type.getDescription());
        ps.setString(5, tenantId);
        ps.setString(6, type.getSuperTypeId());
        ps.setObject(7, jsonbAttributeConverter.convertToDatabaseColumn(type.getJsonSchema()));
        ps.setObject(8, jsonbAttributeConverter.convertToDatabaseColumn(type.getAttributeSchema()));
        ps.setObject(9, jsonbAttributeConverter.convertToDatabaseColumn(type.getTypeSemantics()));
        ps.setObject(10,
            listToTextArrayAttributeConverter.convertToDatabaseColumn(superTypesByTypeId.get(type.getSuperTypeId())));
        ps.setString(11, type.getCreatedBy());
        ps.setTimestamp(12, now);
        ps.setString(13, type.getLastModifiedBy());
        ps.setTimestamp(14, now);
        //setting computed values back to bean for client's convenience
        setCreatedDate(type);
        setLastModifiedDate(type);
        setSetSuperTypesArray(type);
    }
}