/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.Notes;
import com.ge.apm.alm.model.query.NotesPredicate;
import com.ge.apm.alm.persistence.NotesPersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.NotesEntity;
import com.ge.apm.alm.persistence.jpa.repository.NotesRepository;
import com.ge.apm.alm.persistence.jpa.sql.NotesSQL;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;

import static com.ge.apm.alm.persistence.jpa.sql.SQLConstants.AND;
import static com.ge.apm.alm.persistence.jpa.utils.Validator.assertMatchingTenantId;

@Service
@Slf4j
@Transactional
public class NotesPersistencyServiceImpl implements NotesPersistencyService {

    @Autowired
    private DataSource dataSource;
    @Autowired
    private NotesRepository notesRepository;
    @Autowired
    private ConversionService conversionService;

    private EntityBeanPropertyRowMapper<NotesEntity> notesBeanPropertyRowMapper;
    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initializeConvertionService() {
        notesBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(NotesEntity.class, conversionService);
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public Notes createNote(String tenantId, Notes notes) {
        assertMatchingTenantId(tenantId, notes.getTenantId());
        validateNotes(notes);

        NotesEntity notesEntity = toNotesEntity(tenantId, notes, true);
        return notesRepository.saveAndFlush(notesEntity);
    }

    @Override
    public int createNotes(String tenantId, List<Notes> notes) {
        if (CollectionUtils.isEmpty(notes)) {
            return 0;
        }

        List<NotesEntity> notesEntities = new ArrayList<>();
        notes.forEach(t -> {
            assertMatchingTenantId(tenantId, t.getTenantId());
            notesEntities.add(toNotesEntity(tenantId, t, true));
        });

        int[] updateCounts = jdbcTemplate
            .batchUpdate(NotesSQL.getBatchCreateSQL(), new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int i) throws SQLException {
                    NotesEntity entity = notesEntities.get(i);
                    ps.setString(1, entity.getId());
                    ps.setString(2, entity.getName());
                    ps.setString(3, entity.getContent());
                    ps.setString(4, tenantId);
                    ps.setString(5, entity.getCreatedBy());
                    ps.setString(6, entity.getLastModifiedBy());
                }

                @Override
                public int getBatchSize() {
                    return notes.size();
                }
            });

        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public Notes updateNote(String tenantId, Notes notes) {
        assertMatchingTenantId(tenantId, notes.getTenantId());

        NotesEntity notesEntity = toNotesEntity(tenantId, notes, false);
        return notesRepository.saveAndFlush(notesEntity);
    }

    @Override
    public int deleteNote(String tenantId, String noteId) throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = NotesSQL.getDeleteByIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, noteId);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                "Notes has references to it. Hence cannot be deleted", ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException(noteId);
        }
        return rowsDeleted;
    }

    @Override
    public Notes getNoteById(String tenantId, String id) {
        try {
            String query = NotesSQL.getSelectSingleObjectById();
            return jdbcTemplate.queryForObject(query, notesBeanPropertyRowMapper, tenantId, id);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("Note not found with identifier: {}", id);
            return null;
        }
    }

    @Override
    public List<Notes> getNotes(String tenantId, NotesPredicate queryPredicate) {
        String filterPredicate = NotesSQL.getFilterPredicate(queryPredicate);
        String pagination = QueryUtils.getPagination(queryPredicate);
        String query = NotesSQL.getSelectCollectionObjects() + filterPredicate;

        String greaterThan = QueryUtils.getNextPageSortKeyFilter(queryPredicate);
        if (!StringUtils.isEmpty(greaterThan)) {
            query += AND + greaterThan;
        }

        query += pagination;
        log.info("****" + queryPredicate.getAttributeSelectEnum() + ", query: " + query);
        return Collections.unmodifiableList(jdbcTemplate.query(query, notesBeanPropertyRowMapper, tenantId));
    }

    private void validateNotes(Notes notes) {
        StringBuilder builder = new StringBuilder();
        if (StringUtils.isEmpty(notes.getContent())) {
            builder.append("Notes Content is empty. ");
        }

        if (!builder.toString().isEmpty()) {
            throw new IllegalArgumentException(builder.toString());
        }
    }

    private NotesEntity toNotesEntity(String tenantId, Notes notes, boolean isAdd) {
        NotesEntity notesEntity = new NotesEntity();
        notesEntity.setTenantId(tenantId);
        notesEntity.setId(notes.getId());
        notesEntity.setName(notes.getName());
        notesEntity.setContent(notes.getContent());
        if (isAdd) {
            notesEntity.setCreatedBy(notes.getCreatedBy());
        }
        notesEntity.setLastModifiedBy(notes.getLastModifiedBy());

        return notesEntity;
    }
}
