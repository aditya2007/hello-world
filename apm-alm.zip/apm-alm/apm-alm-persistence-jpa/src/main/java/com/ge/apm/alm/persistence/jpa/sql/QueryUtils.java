/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.sql;

import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.postgresql.core.Utils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.BasicPredicate;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.Sort;
import com.ge.apm.alm.model.query.Sortable;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.jpa.utils.ConfigUtils;

public final class QueryUtils {

    private static final String SOURCE_KEY = "source_key";

    private static final String TEXT_JSONB_RESERVED_ATTRIBUTES = "::text)::jsonb @> '{\"reservedattributes\": ";

    private static final String LOWER = "lower(";

    private static final String LOWER_ATTRIBUTES_TEXT_JSONB_RESERVEDATTRIBUTES
        = "(lower(%s::text)::jsonb #>> '{reservedattributes,";

    private QueryUtils() {
    }

    public static String getSqlListOfResources(Collection<String> resources) {
        StringBuilder stringBuilder = new StringBuilder();
        int i = 0;
        for (String accessibleResource : resources) {
            if (i > 0) {
                stringBuilder.append(",");
            }
            //This api is used for many IN clause building. So all the resource needs to be escaped.
            stringBuilder.append("'").append(QueryUtils.escapeLiteral(accessibleResource)).append("'");
            i++;
        }
        return stringBuilder.toString();
    }

    public static String getPagination(BasicPredicate queryPredicate) {
        return getPagination(queryPredicate, true);
    }

    public static String getPagination(BasicPredicate queryPredicate, boolean orderBy) {
        if (queryPredicate.getPageSize() <= 0) {
            return "";
        }
        String pagination;
        if (ConfigUtils.isOrderByIdDisabled) {
            pagination = "";
        } else {
            pagination = orderBy ? getOrderBy(queryPredicate) : "";
        }
        if (queryPredicate.getPageSize() > 0) {
            pagination = pagination + " limit " + queryPredicate.getPageSize();
        } else {
            return pagination;
        }

        if (queryPredicate.getOffset() > 0) {
            pagination = pagination + " offset " + queryPredicate.getOffset();
        }
        return pagination;
    }

    private static String getOrderBy(BasicPredicate queryPredicate) {
        if (!(queryPredicate instanceof Sortable)) {
            return "";
        }

        List<Sort> sorts = ((Sortable) queryPredicate).getSorts();
        if (CollectionUtils.isEmpty(sorts)) {
            return "";
        }

        StringBuilder orderBy = new StringBuilder(" order by ");
        for (int i = 0; i < sorts.size(); i++) {
            Sort sort = sorts.get(i);
            if (i > 0) {
                orderBy.append(", ");
            }
            orderBy.append(sort.getProperty());
            if (!sort.isAsc()) {
                orderBy.append(" desc");
            }
        }

        return orderBy.toString();
    }

    public static String getNextPageSortKeyFilter(BasicPredicate queryPredicate) {
        if (ConfigUtils.isOrderByIdDisabled || queryPredicate.getNextPageSortValues() == null
            || !(queryPredicate instanceof Sortable) || queryPredicate.getPageSize() <= 0) {
            return "";
        }

        List<Sort> sorts = ((Sortable) queryPredicate).getSorts();
        if (CollectionUtils.isEmpty(sorts)) {
            return "";
        }
        String[] values = queryPredicate.getNextPageSortValues();
        if (values.length != sorts.size()) {
            throw new IllegalArgumentException("The sort key cannot be modified");
        }

        StringBuilder filter = new StringBuilder(" (");
        for (int i = 0; i < sorts.size(); i++) {
            Sort sort = sorts.get(i);
            if (i > 0) {
                filter.append(", ");
            }
            filter.append(sort.getProperty());
        }
        filter.append(") > (");
        for (int i = 0; i < values.length; i++) {
            if (i > 0) {
                filter.append(", ");
            }
            filter.append('\'').append(escapeLiteral(values[i])).append('\'');
        }
        filter.append(") ");

        return filter.toString();
    }

    public static String getNextPageSortKey(Sortable sorts, BaseDataModel lastItemOnPage) {
        List<Sort> orderBy = sorts.getSorts();
        if (CollectionUtils.isEmpty(orderBy) || lastItemOnPage == null) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        Encoder encoder = Base64.getEncoder();
        BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(lastItemOnPage);
        for (int i = 0; i < orderBy.size(); i++) {
            if (i > 0) {
                builder.append(':');
            }
            byte[] property = wrapper.getPropertyValue(orderBy.get(i).getProperty()).toString().getBytes(
                StandardCharsets.UTF_8);
            builder.append(encoder.encodeToString(property));
        }

        return encoder.encodeToString(builder.toString().getBytes(StandardCharsets.UTF_8));
    }


    public static boolean isUber(Collection<String> accessibleResources) {
        return accessibleResources == null || accessibleResources.isEmpty();
    }

    public static boolean isNotUber(Collection<String> accessibleResources) {
        return !isUber(accessibleResources);
    }

    public static boolean hasWildcard(String value) {
        return value.indexOf('*') >= 0;
    }

    public static List<String> getEqualOrLikeFilterExpressions(BasicPredicate predicate, Map<String, String> attributes,
        Map<String, String> reservedAttributes, String columnPrefix) {
        String columnName = predicate instanceof TypePredicate ? "attribute_schema" : "attributes";
        columnName = columnPrefix + columnName;
        List<String> expressions = new ArrayList<>();
        expressions.add(
            getFilterExpForTerm(columnPrefix + SOURCE_KEY, QueryUtils.escapeLiteral(predicate.getSourceKey())));
        expressions.add(getFilterExpForTerm(columnPrefix + "name", QueryUtils.escapeLiteral(predicate.getName())));
        expressions.add(
            getFilterExpForTerm(columnPrefix + "description", QueryUtils.escapeLiteral(predicate.getDescription())));
        if (!CollectionUtils.isEmpty(attributes)) {
            expressions.addAll(getCustomAttributeExpressions(attributes, columnName));
        }
        if (!CollectionUtils.isEmpty(reservedAttributes)) {
            expressions.addAll(getReservedAttributeExpressions(reservedAttributes, columnName));
        }
        return expressions.stream().filter(e -> !StringUtils.isEmpty(e)).collect(Collectors.toList());
    }

    public static List<String> getEqualOrLikeFilterExpressions(BasicPredicate predicate, Map<String, String> attributes,
        Map<String, String> reservedAttributes) {
        return getEqualOrLikeFilterExpressions(predicate, attributes, reservedAttributes, "");
    }

    private static List<String> getCustomAttributeExpressions(Map<String, String> attributes, String columnName) {
        List<String> expressions = new ArrayList<>();
        for (Map.Entry<String, String> entry : attributes.entrySet()) {
            String lowerCaseKey = QueryUtils.escapeLiteral(entry.getKey().toLowerCase(Locale.getDefault()));
            String value = QueryUtils.escapeLiteral(entry.getValue());
            String exp;
            if (value == null) {
                exp = "(lower(" + columnName + "::text)::jsonb #> '{attributes," + lowerCaseKey + "}') is not null";
            } else {
                value = value.toLowerCase(Locale.getDefault());
                if (hasWildcard(value)) {
                    exp = getLikeCustomAttributeExpression(columnName, entry.getKey(), value);
                } else {
                    // TODO: revisit the OR query to handle number/boolean/etc, and to tighen up the OR
                    exp = addOrForCustomNumberBoolean(columnName, lowerCaseKey, value) + LOWER + columnName
                        + "::text)::jsonb @> '{\"attributes\": {\"" + lowerCaseKey + "\": {\"value\": [\"" + value
                        + "\"]}}}'";
                }
            }
            expressions.add(exp);
        }
        return expressions;
    }

    private static String addOrForCustomNumberBoolean(String columnName, String lowerCaseKey, String value) {
        if (isNumberic(value) || "true".equals(value) || "false".equals(value)) {
            String patched = value;
            if (isNumberic(value)) {
                patched = String.valueOf(convertToNumber(value));
            }
            return LOWER + columnName + "::text)::jsonb @> '{\"attributes\": {\"" + lowerCaseKey + "\": {\"value\": ["
                + patched + "]}}}' or ";
        }
        return "";
    }

    private static boolean isNumberic(String value) {
        try {
            Long.parseLong(value);
            return true;
        } catch (NumberFormatException nfe) {
            try {
                Double.parseDouble(value); //NOSONAR
                return true;
            } catch (NumberFormatException nfe2) {
                return false;
            }
        }
    }

    private static Number convertToNumber(String value) {
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException nfe) {
            return Double.parseDouble(value);
        }
    }

    private static String getLikeCustomAttributeExpression(String columnName, String key, String value) {
        StringBuilder token = new StringBuilder(value.replaceAll("\\*", "%"));
        if (!token.toString().startsWith("%")) {
            token.insert(0, "%\""); // right like
        } else if (!token.toString().endsWith("%")) {
            token.append("\"%"); // left like
        }
        return "lower((" + columnName + " #>> '{attributes," + key + ",value}')) like '" + token + "'";
    }

    private static List<String> getReservedAttributeExpressions(Map<String, String> reservedAttributes,
        String columnName) {
        List<String> expressions = new ArrayList<>();
        for (Map.Entry<String, String> entry : reservedAttributes.entrySet()) {
            String lowerCaseKey = QueryUtils.escapeLiteral(entry.getKey().toLowerCase(Locale.getDefault()));
            String value = QueryUtils.escapeLiteral(entry.getValue());
            String exp;
            if (value == null) {
                exp = "(lower(attributes::text)::jsonb #> '{reservedattributes," + lowerCaseKey + "}') is not null";
            } else {
                value = value.toLowerCase(Locale.getDefault());
                if (hasWildcard(value)) {
                    exp = getLikeReservedAttributeExpression(columnName, lowerCaseKey, value);
                } else {
                    exp = getEqualsReservedAttributeExpression(columnName, lowerCaseKey, value);
                }
            }
            expressions.add(exp);
        }
        return expressions;
    }

    private static String getEqualsReservedAttributeExpression(String columnName, String lowerCaseKey, String value) {
        StringBuilder closingBraces = new StringBuilder();
        StringBuilder keyPath = new StringBuilder();
        for (String key : lowerCaseKey.split(",")) {
            keyPath.append("{\"").append(key).append("\": ");
            closingBraces.append("}");
        }
        String exp = "";
        // TODO: revisit the OR query to handle number/boolean/etc and to tighten up the OR
        if (isNumberic(value) || "true".equals(value) || "false".equals(value)) {
            String patched = value;
            if (isNumberic(value)) {
                patched = String.valueOf(convertToNumber(value));
            }
            exp = LOWER + columnName + TEXT_JSONB_RESERVED_ATTRIBUTES + keyPath + patched + "}" + closingBraces
                + "' or lower(" + columnName + TEXT_JSONB_RESERVED_ATTRIBUTES + keyPath + "[" + patched + "]}"
                + closingBraces + "' or ";
        }
        exp = exp + LOWER + columnName + TEXT_JSONB_RESERVED_ATTRIBUTES + keyPath + "\"" + value + "\"}" + closingBraces
            + "' or lower(" + columnName + TEXT_JSONB_RESERVED_ATTRIBUTES + keyPath + "[\"" + value + "\"]}"
            + closingBraces + "'";
        return exp;
    }

    private static String getLikeReservedAttributeExpression(String columnName, String key, String value) {
        String exp = "";
        String token = value.replaceAll("\\*", "%");
        if (!token.startsWith("%")) {  // right like
            exp = String.format(LOWER_ATTRIBUTES_TEXT_JSONB_RESERVEDATTRIBUTES, columnName) + key + "}') like '%\""
                + token + "' or ";
        } else if (!token.endsWith("%")) { // left like
            exp = String.format(LOWER_ATTRIBUTES_TEXT_JSONB_RESERVEDATTRIBUTES, columnName) + key + "}') like '" + token
                + "\"%' or ";
        }
        exp = exp + String.format(LOWER_ATTRIBUTES_TEXT_JSONB_RESERVEDATTRIBUTES, columnName) + key + "}') like '"
            + token + "'";
        return exp;
    }

    static String getFilterExpForTerm(String attributeName, String attributeValue) {
        if (StringUtils.isEmpty(attributeValue)) {
            return "";
        }
        if (hasWildcard(attributeValue)) {
            // use ilike with trgm index to speed up case-insensitive like search
            return "" + attributeName + " ilike '" + attributeValue.toLowerCase(Locale.getDefault()).replaceAll("\\*",
                "%") + "'";
        } else {
            return LOWER + attributeName + ") = '" + attributeValue.toLowerCase(Locale.getDefault()) + "'";
        }
    }

    static String flattenExpressions(List<String> expressions, Operand operand) {
        List<String> filtered = expressions.stream().filter(e -> !StringUtils.isEmpty(e)).collect(Collectors.toList());
        String op = " " + operand.name().toLowerCase(Locale.getDefault()) + " ";
        StringBuilder flattened = new StringBuilder();
        int i = 0;
        for (String e : filtered) {
            if (i > 0) {
                flattened.append(op);
            }
            flattened.append(e);
            i++;
        }
        if (flattened.length() > 0) {
            flattened.insert(0, "(").append(")");
        }

        return flattened.toString();
    }

    static String flattenAssetInstanceSqlExpressions(List<String> expressions, Operand operand) {
        List<String> filtered = expressions.stream().filter(e -> !StringUtils.isEmpty(e)).collect(Collectors.toList());
        String op = " " + operand.name().toLowerCase(Locale.getDefault()) + " ";
        StringBuilder flattened = new StringBuilder();
        int i = 0;

        for (String e : filtered) {
            flattened.append("(");
            flattened.append(e);
            flattened.append(")");
            if (i < filtered.size() - 1) {
                flattened.append(op);
                i++;
            }
        }

        return flattened.toString();
    }

    /**
     * Escaping single quote in values.
     */
    public static String escapeLiteral(String value) {
        if (StringUtils.isEmpty(value)) {
            return value;
        }

        try {
            StringBuilder builder = new StringBuilder(value.length());
            Utils.escapeLiteral(builder, value, true);

            return builder.toString();
        } catch (SQLException quoteError) {
            throw new IllegalArgumentException("Unable to escape query value", quoteError);
        }
    }

    public static Collection<String> getComponentAccessibleResources(AssetPredicate assetPredicate,
        Collection<String> accessibleResources) {
        return getComponentAccessibleResources(assetPredicate.isIgnoreComponentAcl(), accessibleResources);
    }

    public static Collection<String> getComponentAccessibleResources(boolean ignoreComponentAcl,
        Collection<String> accessibleResources) {
        return ignoreComponentAcl || QueryUtils.isUber(accessibleResources)
            ? Collections.emptySet() : accessibleResources;
    }

    public static Collection<String> getComponentAccessibleResources(TagPredicate tagPredicate,
        Collection<String> accessibleResources) {
        return tagPredicate.isIgnoreComponentAcl() || QueryUtils.isUber(accessibleResources)
            ? Collections.emptySet() : accessibleResources;
    }
}
