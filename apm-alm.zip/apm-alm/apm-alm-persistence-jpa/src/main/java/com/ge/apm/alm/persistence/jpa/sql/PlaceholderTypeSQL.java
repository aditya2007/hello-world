/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.sql;

import java.text.MessageFormat;
import java.util.Collection;

public final class PlaceholderTypeSQL {

    public static final String DELETE_PLACEHOLDER_TYPE = "delete from apm_alm.placeholder_type ";
    private static final String ALL_COLUMNS = "select id, tenant_id, placeholder_id, type_id, primary_flag as primary,"
        + " status, created_by, created_date, last_modified_by, last_modified_date from apm_alm.placeholder_type ";
    private static final String WHERE_TENANT_ID = " where tenant_id = ? ";
    private static final String WHERE_TENANT_ID_AND_ID = WHERE_TENANT_ID + "and id = ? ";
    private static final String WHERE_TENANT_ID_AND_PLACEHOLDER_ID = WHERE_TENANT_ID + "and placeholder_id = ? ";
    private static final String WHERE_TENANT_ID_AND_PLACEHOLDER_ID_AND_TYPE_ID = WHERE_TENANT_ID +
        " and placeholder_id = ? and type_id = ? ";
    private static final String WHERE_TENANT_ID_AND_PLACEHOLDER_ID_AND_STATUS = WHERE_TENANT_ID
        + " and placeholder_id = ? and status = ? ";
    private static final String WHERE_TENANT_ID_AND_PLACEHOLDER_IDS = WHERE_TENANT_ID
        + " and placeholder_id in ({0}) ";

    private static final String ALL_COLUMNS_WHERE_TENANT_ID_AND_TEMPLATE_ID =
        "select pt.id, pt.tenant_id, pt.placeholder_id, pt.type_id, pt.primary_flag as primary, pt.status,"
            + " pt.created_by, pt.created_date, pt.last_modified_by, pt.last_modified_date"
            + " from apm_alm.placeholder_type pt, apm_alm.placeholder p, apm_alm.template t "
            + " where  t.tenant_id = ? and t.id = ? and pt.placeholder_id = p.id and p.template_id = t.id";

    private static final String BATCH_CREATE_SQL =
        "insert into apm_alm.placeholder_type (id, tenant_id, placeholder_id, type_id," +
            " primary_flag, status, created_by, last_modified_by) values (?, ?, ?, ?, ?, ?, ?, ?)";


    private PlaceholderTypeSQL() {
    }

    public static String getBatchCreateSQL() {
        return BATCH_CREATE_SQL;
    }

    public static String getDeleteByIdSQL() {
        return DELETE_PLACEHOLDER_TYPE + WHERE_TENANT_ID_AND_ID;
    }

    public static String getDeleteByPlaceholderIdAndTypeIdSQL() {
        return DELETE_PLACEHOLDER_TYPE + WHERE_TENANT_ID_AND_PLACEHOLDER_ID_AND_TYPE_ID;
    }

    public static String getDeleteByPlaceholderIdSQL() {
        return DELETE_PLACEHOLDER_TYPE + WHERE_TENANT_ID_AND_PLACEHOLDER_ID;
    }

    public static String getSelectSingleObjectById() {
        return ALL_COLUMNS + WHERE_TENANT_ID_AND_ID;
    }

    public static String getSelectSingleObjectByPlaceholderIdAndTypeId() {
        return ALL_COLUMNS + WHERE_TENANT_ID_AND_PLACEHOLDER_ID_AND_TYPE_ID;
    }

    public static String getSelectCollectionObjectsByPlaceholderId() {
        return ALL_COLUMNS + WHERE_TENANT_ID_AND_PLACEHOLDER_ID;
    }

    public static String getSelectCollectionObjectsByPlaceholderIdAndStatus() {
        return ALL_COLUMNS + WHERE_TENANT_ID_AND_PLACEHOLDER_ID_AND_STATUS;
    }

    public static String getSelectCollectionObjectsByPlaceholderIs(Collection<String> placeholderIds) {
        return ALL_COLUMNS + MessageFormat.format(WHERE_TENANT_ID_AND_PLACEHOLDER_IDS,
            QueryUtils.getSqlListOfResources(placeholderIds));
    }

    public static String getSelectCollectionObjectsByTemplateId() {
        return ALL_COLUMNS_WHERE_TENANT_ID_AND_TEMPLATE_ID;
    }
}
