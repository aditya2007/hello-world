/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.repository;

import java.util.List;

import javax.persistence.QueryHint;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;

import com.ge.apm.alm.model.AssetUserPolicy;
import com.ge.apm.alm.persistence.jpa.entity.AssetUserPolicyEntity;

/**
 * Created by Yogananda Gowda - 212590467 on 10/2/17.
 */
public interface AssetPolicyRepository extends JpaRepository<AssetUserPolicyEntity, String> {

    AssetUserPolicy findByTenantIdAndId(String tenantId, String featureId);

    List<AssetUserPolicy> findByTenantIdAndFeatureId(String tenantId, String featureId);

    List<AssetUserPolicy> findByTenantId(String tenantId);

    @QueryHints(value = { @QueryHint(name = org.eclipse.persistence.config.QueryHints.FLUSH, value = "FALSE") })
    List<AssetUserPolicy> findByTenantIdAndSubjectIdAndSubjectType(
                                                     String tenantId, String subjectId, String subjectType);

    @Query("select aup from AssetUserPolicyEntity aup where aup.tenantId=:tenantId and aup.subjectId in :subjectIds")
    @QueryHints(value = { @QueryHint(name = org.eclipse.persistence.config.QueryHints.FLUSH, value = "FALSE") })
    List<AssetUserPolicy> findByTenantIdAndSubjectIds(
            @Param("tenantId") String tenantId, @Param("subjectIds") List<String> subjectIds);

    void deleteByTenantIdAndId(String tenantId, String id);

    void deleteByTenantId(String tenantId);
}
