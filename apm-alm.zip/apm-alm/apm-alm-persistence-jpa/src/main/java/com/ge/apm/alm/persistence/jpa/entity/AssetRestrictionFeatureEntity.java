/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import org.eclipse.persistence.annotations.Array;
import org.eclipse.persistence.annotations.Struct;

import com.ge.apm.alm.model.AssetRestrictionFeature;

/**
 * Created by Yogananda Gowda - 212590467 on 9/28/17.
 */
@Struct(name = "apm")
@Entity
@Table(name = "asset_feature_metadata", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class AssetRestrictionFeatureEntity extends AuditableEntity implements AssetRestrictionFeature {

    @Column(name = "feature_code")
    private String featureCode;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "category")
    private String category;

    @Column(name = "filter_on")
    private String  filterOn;

    @Column(name = "applicable_super_types")
    @Array(databaseType = "TEXT[]")
    private List<String> applicableSuperTypes;

    @Column(name = "action")
    private String action;

    @Column(name = "filter_scope")
    private String filterScope;

    @Column(name = "default_filter_criteria")
    private String defaultFilterCriteria;

    @Column(name = "is_active")
    private boolean isFeatureActive;
}
