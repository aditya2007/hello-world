/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.PlaceholderGroupTagType;
import com.ge.apm.alm.persistence.PlaceholderGroupTagTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderGroupTagTypeEntity;
import com.ge.apm.alm.persistence.jpa.repository.PlaceholderGroupTagTypeRepository;
import com.ge.apm.alm.persistence.jpa.sql.PlaceholderGroupTagTypeSQL;

import static com.ge.apm.alm.persistence.jpa.utils.Validator.assertMatchingTenantId;

@Service
@Slf4j
@Transactional
public class PlaceholderGroupTagTypePersistencyServiceImpl implements PlaceholderGroupTagTypePersistencyService {

    private static final int QUERY_BATCH_SIZE = 500;
    private static final String PLACEHOLDER_GROUP_TAG_TYPE_HAS_REFERENCES_TO_IT_HENCE_CANNOT_BE_DELETED =
        "PlaceholderGroupTagType has references to it. Hence cannot be deleted";

    @Autowired
    private DataSource dataSource;
    @Autowired
    private PlaceholderGroupTagTypeRepository placeholderGroupTagTypeRepository;
    @Autowired
    private ConversionService conversionService;

    private EntityBeanPropertyRowMapper<PlaceholderGroupTagTypeEntity> placeholderGroupTagTypeBeanPropertyRowMapper;
    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initializeConvertionService() {
        placeholderGroupTagTypeBeanPropertyRowMapper = new EntityBeanPropertyRowMapper(
            PlaceholderGroupTagTypeEntity.class, conversionService);
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public PlaceholderGroupTagType createPlaceholderGroupTagType(String tenantId,
        PlaceholderGroupTagType placeholderGroupTagType) {
        assertMatchingTenantId(tenantId, placeholderGroupTagType.getTenantId());
        validatePlaceholderGroupTagType(placeholderGroupTagType);

        PlaceholderGroupTagTypeEntity entity = toPlaceholderGroupTagTypeEntity(tenantId, placeholderGroupTagType, true);
        return placeholderGroupTagTypeRepository.saveAndFlush(entity);
    }

    @Override
    public int createPlaceholderGroupTagTypes(String tenantId, List<PlaceholderGroupTagType> placeholderGroupTagTypes) {
        if (CollectionUtils.isEmpty(placeholderGroupTagTypes)) {
            return 0;
        }

        List<PlaceholderGroupTagTypeEntity> entities = new ArrayList<>();
        placeholderGroupTagTypes.stream().forEach(placeholderGroupTagType -> {
            assertMatchingTenantId(tenantId, placeholderGroupTagType.getTenantId());
            entities.add(toPlaceholderGroupTagTypeEntity(tenantId, placeholderGroupTagType, true));
        });

        int[] updateCounts = jdbcTemplate
            .batchUpdate(PlaceholderGroupTagTypeSQL.getBatchCreateSQL(), new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int index) throws SQLException {
                    PlaceholderGroupTagTypeEntity entity = entities.get(index);
                    ps.setString(1, entity.getId());
                    ps.setString(2, tenantId);
                    ps.setString(3, entity.getPlaceholderId());
                    ps.setString(4, entity.getGroupId());
                    ps.setString(5, entity.getCategory());
                    ps.setString(6, entity.getCreatedBy());
                    ps.setString(7, entity.getLastModifiedBy());
                }

                @Override
                public int getBatchSize() {
                    return placeholderGroupTagTypes.size();
                }
            });
        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public PlaceholderGroupTagType updatePlaceholderGroupTagType(String tenantId,
        PlaceholderGroupTagType placeholderGroupTagType)
        throws PersistencyServiceException {
        assertMatchingTenantId(tenantId, placeholderGroupTagType.getTenantId());
        validatePlaceholderGroupTagType(placeholderGroupTagType);

        PlaceholderGroupTagTypeEntity entity = toPlaceholderGroupTagTypeEntity(tenantId, placeholderGroupTagType, true);
        return placeholderGroupTagTypeRepository.saveAndFlush(entity);
    }

    @Override
    public int updatePlaceholderGroupTagTypes(String tenantId, List<PlaceholderGroupTagType> placeholderGroupTagTypes)
        throws PersistencyServiceException {
        if (CollectionUtils.isEmpty(placeholderGroupTagTypes)) {
            return 0;
        }

        int updateCounts = 0;
        for (PlaceholderGroupTagType placeholderGroupTagType : placeholderGroupTagTypes) {
            updatePlaceholderGroupTagType(tenantId, placeholderGroupTagType);
            updateCounts++;
        }
        return updateCounts;
    }

    @Override
    public int deletePlaceholderGroupTagTypeById(String tenantId, String id)
        throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderGroupTagTypeSQL.getDeleteByIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, id);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                PLACEHOLDER_GROUP_TAG_TYPE_HAS_REFERENCES_TO_IT_HENCE_CANNOT_BE_DELETED, ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException(id);
        }
        return rowsDeleted;
    }

    @Override
    public int deletePlaceholderGroupTagTypeByPlaceholderIdAndGroupId(String tenantId, String placeholderId,
        String groupId)
        throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderGroupTagTypeSQL.getDeleteByPlaceholderIdAndGroupIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, placeholderId, groupId);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                PLACEHOLDER_GROUP_TAG_TYPE_HAS_REFERENCES_TO_IT_HENCE_CANNOT_BE_DELETED, ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("placeholderId:" + placeholderId + ", groupId:" + groupId);
        }
        return rowsDeleted;
    }

    @Override
    public int deletePlaceholderGroupTagTypeByPlaceholderId(String tenantId, String placeholderId)
        throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderGroupTagTypeSQL.getDeleteByPlaceholderIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, placeholderId);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                PLACEHOLDER_GROUP_TAG_TYPE_HAS_REFERENCES_TO_IT_HENCE_CANNOT_BE_DELETED, ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException(placeholderId);
        }
        return rowsDeleted;
    }

    @Override
    public PlaceholderGroupTagType getPlaceholderGroupTagTypeById(String tenantId, String id) {
        try {
            String query = PlaceholderGroupTagTypeSQL.getSelectSingleObjectById();
            return jdbcTemplate.queryForObject(query, placeholderGroupTagTypeBeanPropertyRowMapper, tenantId, id);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("PlaceholderGroupTagType not found with identifier: {}", id);
            return null;
        }
    }

    @Override
    public PlaceholderGroupTagType getPlaceholderGroupTagTypeByPlaceholderIdAndGroupId(String tenantId,
        String placeholderId,
        String tagTypeId) {
        try {
            String query = PlaceholderGroupTagTypeSQL.getSelectSingleObjectByPlaceholderIdAndGroupId();
            return jdbcTemplate.queryForObject(query, placeholderGroupTagTypeBeanPropertyRowMapper, tenantId,
                placeholderId, tagTypeId);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug(
                "PlaceholderGroupTagType not found with identifier: {} and tag type {}", placeholderId, tagTypeId);
            return null;
        }
    }

    @Override
    public List<PlaceholderGroupTagType> getPlaceholderGroupTagTypeByPlaceholderId(String tenantId,
        String placeholderId) {
        String query = PlaceholderGroupTagTypeSQL.getSelectCollectionObjectsByPlaceholderId();
        return Collections.unmodifiableList(
            jdbcTemplate.query(query, placeholderGroupTagTypeBeanPropertyRowMapper, tenantId, placeholderId));
    }

    @Override
    public List<PlaceholderGroupTagType> getPlaceholderGroupTagTypeByTemplateId(String tenantId, String templateId) {
        String query = PlaceholderGroupTagTypeSQL.getSelectCollectionObjectsByTemplateId();
        return Collections.unmodifiableList(jdbcTemplate.query(query, placeholderGroupTagTypeBeanPropertyRowMapper,
            tenantId, templateId));
    }

    @Override
    public List<PlaceholderGroupTagType> getPlaceholderGroupTagTypeByPlaceholderIds(String tenantId,
        List<String> placeholderIds) {
        if (CollectionUtils.isEmpty(placeholderIds)) {
            return Collections.emptyList();
        }

        List<PlaceholderGroupTagTypeEntity> placeholderGroupTagTypeEntities = new ArrayList<>();
        int counter = 0;
        int size = placeholderIds.size();

        while (counter < size) {
            int endIndex = counter + QUERY_BATCH_SIZE < size ? counter + QUERY_BATCH_SIZE : size;
            List<String> batchPlaceholderIdList = placeholderIds.subList(counter, endIndex);
            String query = PlaceholderGroupTagTypeSQL.getSelectCollectionObjectsByPlaceholderIs(batchPlaceholderIdList);

            List<PlaceholderGroupTagTypeEntity> foundEnties = jdbcTemplate.query(query,
                placeholderGroupTagTypeBeanPropertyRowMapper, tenantId);
            placeholderGroupTagTypeEntities.addAll(foundEnties);

            counter = endIndex;
        }

        return Collections.unmodifiableList(placeholderGroupTagTypeEntities);
    }

    private void validatePlaceholderGroupTagType(PlaceholderGroupTagType placeholderGroupTagType) {
        StringBuilder builder = new StringBuilder();
        if (StringUtils.isEmpty(placeholderGroupTagType.getId())) {
            builder.append("PlaceholderGroupTagType Id is empty. ");
        }
        if (StringUtils.isEmpty(placeholderGroupTagType.getPlaceholderId())) {
            builder.append("PlaceholderGroupTagType placeholderId is empty. ");
        }
        if (StringUtils.isEmpty(placeholderGroupTagType.getGroupId())) {
            builder.append("PlaceholderGroupTagType groupId is empty. ");
        }

        if (!builder.toString().isEmpty()) {
            throw new IllegalArgumentException(builder.toString());
        }
    }

    private PlaceholderGroupTagTypeEntity toPlaceholderGroupTagTypeEntity(String tenantId,
        PlaceholderGroupTagType placeholderGroupTagType,
        boolean isAdd) {
        PlaceholderGroupTagTypeEntity entity = new PlaceholderGroupTagTypeEntity();
        entity.setId(placeholderGroupTagType.getId());
        entity.setTenantId(tenantId);
        entity.setPlaceholderId(placeholderGroupTagType.getPlaceholderId());
        entity.setGroupId(placeholderGroupTagType.getGroupId());
        entity.setCategory(placeholderGroupTagType.getCategory());

        if (isAdd) {
            entity.setCreatedBy(placeholderGroupTagType.getCreatedBy());
        }
        entity.setLastModifiedBy(placeholderGroupTagType.getLastModifiedBy());
        return entity;
    }
}
