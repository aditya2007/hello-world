/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.ConfigContextQuery;
import com.ge.apm.alm.persistence.jpa.entity.ContextEntity;
import com.ge.apm.alm.persistence.jpa.entity.ReservedAttributeContextConfigEntity;
import com.ge.apm.alm.persistence.jpa.utils.ConfigQuerySpecification;

public interface IReservedAttributeContextConfigRepository
    extends JpaRepository<ReservedAttributeContextConfigEntity, Long>,
    JpaSpecificationExecutor<ReservedAttributeContextConfigEntity> {

    @Override
    List<ReservedAttributeContextConfigEntity> findAll();

    @Query("SELECT r FROM ReservedAttributeContextConfigEntity r where r.tenantId = ?1 or r.tenantId = '" +
        SeedOOTBData.SYSTEM_TENANT_ID + "' order by r.context.contextName, r.semanticName")
    List<ReservedAttributeContextConfigEntity> findAllByTenantId(String tenantId);

    @Query("SELECT raConfig FROM ReservedAttributeContextConfigEntity raConfig "
        + "WHERE raConfig.context = (SELECT context FROM ContextEntity context WHERE context.contextName = ?1)"
        + "AND (raConfig.tenantId = ?2 OR raConfig.tenantId = '" + SeedOOTBData.SYSTEM_TENANT_ID + "')")
    List<ReservedAttributeContextConfigEntity> findAllByContextAndTenantId(String contextName, String tenantId);

    @Query("SELECT raConfig FROM ReservedAttributeContextConfigEntity raConfig "
        + "WHERE raConfig.context = (SELECT context FROM ContextEntity context WHERE context.contextName = ?1)"
        + "AND raConfig.tenantId = ?2 AND raConfig.code = ?3")
    ReservedAttributeContextConfigEntity findByContextAndTenantIdAndCode(String contextName, String tenantId,
        String code);

    @Query("SELECT raConfig FROM ReservedAttributeContextConfigEntity raConfig "
        + "WHERE raConfig.context = (SELECT context FROM ContextEntity context WHERE context.contextName = ?1)"
        + "AND raConfig.tenantId = ?2 AND raConfig.isDefault = true")
    ReservedAttributeContextConfigEntity findByContextAndTenantIdAndIsDefaultTrue(String contextName,
        String tenantId);

    void delete(ReservedAttributeContextConfigEntity deleted);

    @Override
    void flush();

    ReservedAttributeContextConfigEntity saveAndFlush(ReservedAttributeContextConfigEntity persisted);

    @Query("SELECT raConfig FROM ReservedAttributeContextConfigEntity raConfig "
        + "WHERE raConfig.context = (SELECT context FROM ContextEntity context WHERE context.contextName = ?1)"
        + "AND (raConfig.tenantId = ?2 OR raConfig.tenantId = '" + SeedOOTBData.SYSTEM_TENANT_ID + "') AND "
        + "(raConfig.code = ?3 or CAST(?3 as text) is null) order by raConfig.tenantId")
    List<ReservedAttributeContextConfigEntity> findAllByContextAndCodeAndTenantId(String contextName,
        String tenantId, String code);

    default List<ReservedAttributeContextConfigEntity> findAllByQuerySpecs(String tenantId,
        ConfigContextQuery configContextQuery) {
        return findAll(ConfigQuerySpecification.filterReservedAttributeConfigBy(tenantId, configContextQuery));
    }
}
