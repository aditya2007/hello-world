/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.core.convert.ConversionService;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.view.TagComponent;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.TagCorrelationItemEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceEntity;
import com.ge.apm.alm.persistence.jpa.utils.BaseDataModelUtil;

@Component
@Order(20) // load after TagCorrelatedItemsLoader
public class TagCorrelatedTagsLoader implements PostLoadHandler<TagInstanceEntity, TagComponent> {

    //why is it always a seq scan on asset_group_tag_correlation?
    private static final String QUERY = "SELECT t.*, c.group_id FROM apm_alm.tag_instance t"
        + " JOIN apm_alm.asset_group_tag_correlation c"
        + " ON t.id = c.object_id AND t.tenant_id = c.tenant_id"
        + " WHERE c.group_id IN (SELECT group_id FROM apm_alm.asset_group_tag_correlation"
        + " WHERE tenant_id=:tenantId AND object_id IN (:ids)) ORDER BY c.position ASC";

    private final EntityBeanPropertyRowMapper<TagInstanceEntity> tagInstanceBeanPropertyRowMapper;

    @Autowired
    private NamedParameterJdbcTemplate jdbcParameterTemplate;

    @Autowired
    protected TagCorrelatedTagsLoader(ConversionService conversionService) {
        tagInstanceBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(
            TagInstanceEntity.class, conversionService);
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources,
        TagInstanceEntity entity, AttributeSelectEnum selectEnum,
        Set<TagComponent> components) {
        if (entity == null || components == null || !components.contains(
            TagComponent.CORRELATED_TAGS)) {
            return;
        }

        Map<String, TagInstanceEntity> tagIdMap = BaseDataModelUtil.toIdMap(entity, null);
        Map<String, List<AssetGroupItem>> tagIdToGroupItems;
        if (components.contains(TagComponent.CORRELATED_ITEMS)) {
            tagIdToGroupItems = new HashMap<>();
            addCorrelatedItems(entity, tagIdToGroupItems);
        } else {
            tagIdToGroupItems = TagCorrelatedItemsLoader.loadAssetGroups(tenantId, tagIdMap);
        }

        if (!CollectionUtils.isEmpty(tagIdToGroupItems)) {
            loadCorrelations(tenantId, tagIdMap, tagIdToGroupItems);
        }
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources, List<TagInstanceEntity> tags,
        AttributeSelectEnum selectEnum, Set<TagComponent> components) {
        if (CollectionUtils.isEmpty(tags) || components == null || !components.contains(
            TagComponent.CORRELATED_TAGS)) {
            return;
        }

        Map<String, TagInstanceEntity> tagIdMap = BaseDataModelUtil.toIdMap(tags, null);
        Map<String, List<AssetGroupItem>> tagIdToGroupItems;
        if (components.contains(TagComponent.CORRELATED_ITEMS)) {
            tagIdToGroupItems = new HashMap<>();
            tags.forEach(tag -> addCorrelatedItems(tag, tagIdToGroupItems));
        } else {
            tagIdToGroupItems = TagCorrelatedItemsLoader.loadAssetGroups(tenantId, tagIdMap);
        }

        if (!CollectionUtils.isEmpty(tagIdToGroupItems)) {
            loadCorrelations(tenantId, tagIdMap, tagIdToGroupItems);
        }
    }

    private void addCorrelatedItems(Tag tag, Map<String, List<AssetGroupItem>> tagIdToGroupItems) {
        AssetGroup group = findAssetGroup(tag, AssetGroupCategory.TAG_CORRELATION);
        if (group != null) {
            tagIdToGroupItems.put(tag.getId(), group.getItems());
        }
    }

    private AssetGroup findAssetGroup(Tag tag, AssetGroupCategory category) {
        List<AssetGroup> groups = tag.getAssetGroups();
        if (groups != null) {
            for (AssetGroup group : groups) {
                if (group.getCategory().equals(category)) {
                    return group;
                }
            }
        }

        return null;
    }

    private void loadCorrelations(String tenantId, Map<String, TagInstanceEntity> tagIdMap,
        Map<String, List<AssetGroupItem>> tagIdToGroupItem) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("tenantId", tenantId);
        params.addValue("ids", tagIdToGroupItem.keySet());

        Map<String, List<Tag>> tagsByGroupId = new HashMap<>();
        Map<String, List<Tag>> tagsById = new HashMap<>();
        Map<String, TagInstanceEntity> tagsFoundById = new HashMap<>();

        jdbcParameterTemplate.query(QUERY, params,
            (rs, rowNum) -> {
                TagInstanceEntity tag = tagInstanceBeanPropertyRowMapper.mapRow(rs, rowNum);
                String groupId = rs.getString("group_id");
                List<Tag> group = tagsByGroupId.computeIfAbsent(groupId, k -> new ArrayList<>());
                group.add(tag);
                tagsFoundById.put(tag.getId(), tag);
                tagsById.put(tag.getId(), group);

                return tag;
            });

        tagsById.forEach((id, list) -> {
            TagInstanceEntity tag = tagIdMap.get(id);
            if (tag != null) {
                AssetGroup group = findAssetGroup(tag, AssetGroupCategory.TAG_CORRELATION);
                group.getItems().forEach(item -> ((TagCorrelationItemEntity) item)
                    .setObject(tagsFoundById.get(item.getObjectId())));
            }

        });
    }
}
