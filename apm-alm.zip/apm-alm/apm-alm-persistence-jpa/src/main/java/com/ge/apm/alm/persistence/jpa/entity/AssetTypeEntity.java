/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entity;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;

@Entity
@Table(name = "asset_type", schema = "apm_alm")
@Getter
@Setter
@NoArgsConstructor
@ToString(callSuper = true)
public class AssetTypeEntity extends SourceableEntity implements AssetType {

    @Column(name = "super_type_id")
    private String superTypeId;

    @Column(name = "json_schema")
    @Convert(converter = JsonbAttributeConverter.class)
    private JsonNode jsonSchema;

    @Column(name = "attribute_schema")
    @Convert(converter = JsonbAttributeConverter.class)
    private JsonNode attributeSchema;

    @SuppressWarnings("JpaAttributeTypeInspection")
    @Column(name = "super_types_array")
    @Convert(converter = ListToTextArrayAttributeConverter.class)
    private List<String> superTypesArray;

    @Column(name = "type_semantics")
    @Convert(converter = JsonbAttributeConverter.class)
    private JsonNode typeSemantics;

    @Transient
    @JsonIgnore
    private AssetTypeEntity superType;

    @Builder
    private AssetTypeEntity(String id, String sourceKey, String name, String description, String tenantId,
        String createdBy, String lastModifiedBy, String superTypeId, JsonNode jsonSchema, JsonNode attributeSchema,
        JsonNode typeSemantics, List<String> superTypesArray) {
        super(id, name, tenantId, createdBy, lastModifiedBy, sourceKey, description);
        this.superTypeId = superTypeId;
        this.jsonSchema = jsonSchema;
        this.attributeSchema = attributeSchema;
        this.typeSemantics = typeSemantics;
        this.superTypesArray = superTypesArray;
    }
}

