/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;

@Slf4j
class AssetBatchUpdatePreparedStatementSetter extends AssetBatchPreparedStatementSetter<Asset> {

    private final Map<String, List<String>> ancestorsByParentId;

    private final String lastModifiedBy;

    AssetBatchUpdatePreparedStatementSetter(String tenantId, List<Asset> assets,
        Map<String, List<String>> ancestorsByParentId, Map<String, List<String>> superTyptesById,
        JsonbAttributeConverter jsonbAttributeConverter,
        ListToTextArrayAttributeConverter listToTextArrayAttributeConverter,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter, String lastModifiedBy) {
        super(tenantId, assets, superTyptesById, jsonbAttributeConverter, listToTextArrayAttributeConverter,
            offsetDateTimeAttributeConverter);
        this.ancestorsByParentId = ancestorsByParentId;
        this.lastModifiedBy = lastModifiedBy;
    }

    @Override
    public void setValues(PreparedStatement ps, int index) throws SQLException {
        Asset asset = instances.get(index);
        ps.setString(1, asset.getSourceKey());
        ps.setString(2, asset.getName());
        ps.setString(3, asset.getDescription());
        ps.setString(4, asset.getAssetType());
        ps.setString(5, asset.getParentId());
        ps.setObject(6, jsonbAttributeConverter.convertToDatabaseColumn(asset.getAttributes()));
        ps.setObject(7,
            listToTextArrayAttributeConverter.convertToDatabaseColumn(getMyAncestors(asset, ancestorsByParentId)));
        ps.setObject(8,
            listToTextArrayAttributeConverter.convertToDatabaseColumn(superTypesByTypeId.get(asset.getAssetType())));
        ps.setObject(9, jsonbAttributeConverter.convertToDatabaseColumn(asset.getGeolocation()));
        ps.setString(10, lastModifiedBy);
        ps.setTimestamp(11, now);
        //setting computed values back to bean for client's convenience
        ps.setString(12, tenantId);
        ps.setString(13, asset.getId());
        setLastModifiedDate(asset);
        setSetSuperTypesArray(asset);
    }

    private List<String> getMyAncestors(Asset asset, Map<String, List<String>> ancestorsByParentId) {
        String parentId = asset.getParentId();
        List<String> parentsAncestors = ancestorsByParentId.get(parentId);
        List<String> myAncestors;
        if (parentsAncestors == null) {
            myAncestors = new ArrayList<>();
        } else {
            // must clone to make each asset's ancestors independent of each other
            myAncestors = new ArrayList<>(parentsAncestors);
        }
        if (asset.getParentId() != null) {
            myAncestors.add(asset.getParentId());
        }
        // put the current asset ancestors in to be used by its children in subsequent calls
        ancestorsByParentId.put(asset.getId(), myAncestors);
        return myAncestors;
    }

    @Override
    protected String getTypeId(Asset asset) {
        return asset.getAssetType();
    }
}