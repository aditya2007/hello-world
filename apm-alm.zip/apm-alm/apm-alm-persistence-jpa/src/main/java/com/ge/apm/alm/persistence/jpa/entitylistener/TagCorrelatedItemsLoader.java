/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.view.TagComponent;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.jpa.entity.AssetGroupEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceEntity;
import com.ge.apm.alm.persistence.jpa.utils.BaseDataModelUtil;

@Component
@Order(10) // load before TagCorrelatedTagsLoader
public class TagCorrelatedItemsLoader implements PostLoadHandler<TagInstanceEntity, TagComponent>,
    ApplicationListener<ContextRefreshedEvent> {

    private static final List<String> UBER = Collections.emptyList();
    private static GroupPersistencyService groupPersistencyService;

    static Map<String, List<AssetGroupItem>> loadAssetGroups(String tenantId,
        Map<String, TagInstanceEntity> tagIdMap) {
        if (tagIdMap.isEmpty()) {
            return null;
        }

        Map<String, AssetGroup> tagToGroup = groupPersistencyService
            .getCorrelationsForTags(tenantId, UBER, tagIdMap.keySet());
        if (tagToGroup.isEmpty()) {
            return null;
        }

        Map<String, List<AssetGroupItem>> correlatedTags = groupPersistencyService
            .getCorrelatedTags(tenantId, UBER, tagToGroup.keySet());
        tagToGroup.forEach((tagId, items) -> {
            if (items != null) {
                TagInstanceEntity tag = tagIdMap.get(tagId);
                List<AssetGroup> groups = tag.getAssetGroups();
                if (groups == null) {
                    groups = new ArrayList<>();
                    tag.setAssetGroups(groups);
                }

                AssetGroupEntity group = (AssetGroupEntity) tagToGroup.get(tagId);
                groups.add(group);
                group.setItems(correlatedTags.get(tagId));
            }
        });

        return correlatedTags;
    }

    private static void init(ApplicationContext applicationContext) {
        groupPersistencyService = applicationContext.getBean(GroupPersistencyService.class);
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources,
        TagInstanceEntity entity, AttributeSelectEnum selectEnum, Set<TagComponent> components) {
        if (entity == null || components == null || !components.contains(
            TagComponent.CORRELATED_ITEMS)) {
            return;
        }

        Map<String, TagInstanceEntity> tagIdMap = BaseDataModelUtil.toIdMap(entity, null);
        loadAssetGroups(tenantId, tagIdMap);
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources, List<TagInstanceEntity> tags,
        AttributeSelectEnum selectEnum, Set<TagComponent> components) {
        if (CollectionUtils.isEmpty(tags) || components == null || !components.contains(
            TagComponent.CORRELATED_ITEMS)) {
            return;
        }

        Map<String, TagInstanceEntity> tagIdMap = BaseDataModelUtil.toIdMap(tags, null);
        loadAssetGroups(tenantId, tagIdMap);
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        init(event.getApplicationContext());
    }
}
