/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;

class AssetBatchUpdateAncestorsPreparedStatementSetter extends AssetBatchPreparedStatementSetter<Asset> {

    private final String lastModifiedBy;

    AssetBatchUpdateAncestorsPreparedStatementSetter(String tenantId, List<Asset> assets, String lastModifiedBy,
        ListToTextArrayAttributeConverter listToTextArrayAttributeConverter,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter) {
        super(tenantId, assets, Collections.emptyMap(), null, listToTextArrayAttributeConverter,
            offsetDateTimeAttributeConverter);
        this.lastModifiedBy = lastModifiedBy;
    }

    @Override
    public void setValues(PreparedStatement ps, int idx) throws SQLException {
        Asset asset = instances.get(idx);
        ps.setObject(1, listToTextArrayAttributeConverter.convertToDatabaseColumn(asset.getAncestorsArray()));
        ps.setString(2, lastModifiedBy);
        ps.setTimestamp(3, now);
        ps.setString(4, tenantId);
        ps.setString(5, asset.getId());
    }

    @Override
    protected String getTypeId(Asset asset) {
        return asset.getAssetType();
    }
}