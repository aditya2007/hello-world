/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;

@Slf4j
public final class TypeJsonUtils {

    private TypeJsonUtils() {
    }

    private static List<String> appendSuperTypes(AssetType type) {
        if (type == null) {
            throw new IllegalArgumentException("type is null");
        }
        List<String> superTypes = new ArrayList<>(
            type.getSuperTypesArray()); //cloning, otherwise it will change the source.
        superTypes.add(type.getId());
        return superTypes;
    }

    public static Map<String, List<String>> getSuperTypesByTypeIdWithTypeId(
        AssetTypePersistencyService assetTypePersistencyService, String tenantId, Set<String> typeIds) {
        final Map<String, List<String>> rslt = new HashMap<>();
        rslt.put(null, new ArrayList<>());
        if (!CollectionUtils.isEmpty(typeIds)) {
            Map<String, List<String>> superTypesByTypeId = assetTypePersistencyService.getSuperTypesByIds(tenantId,
                typeIds);
            // add self to denormalize for instances/assets
            typeIds.forEach(id -> {
                List<String> superTypes = superTypesByTypeId.get(id) == null ? new ArrayList<>() : new ArrayList<>(
                    superTypesByTypeId.get(id));
                superTypes.add(id);
                rslt.put(id, superTypes);
            });
        }
        return rslt;
    }

    public static List<String> getSuperTypes(AssetTypePersistencyService assetTypePersistencyService, String tenantId,
        String typeId) throws ObjectNotFoundException {
        AssetType type = assetTypePersistencyService.getAssetTypeById(tenantId, typeId);
        if (type == null) {
            throw new ObjectNotFoundException("Type does not exist: " + typeId);
        }
        return TypeJsonUtils.appendSuperTypes(type);
    }

    public static List<String> getDenormalizedSuperTypes(AssetType parentType) {
        List<String> superTypes;
        if (parentType == null) { //for creating root types..
            superTypes = new ArrayList<>();
        } else {
            superTypes = new ArrayList<>(parentType.getSuperTypesArray());
            superTypes.add(parentType.getId());
        }
        return superTypes;
    }
}
