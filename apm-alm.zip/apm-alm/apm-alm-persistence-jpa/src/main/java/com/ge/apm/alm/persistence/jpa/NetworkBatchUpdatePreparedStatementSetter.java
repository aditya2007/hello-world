/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import com.ge.apm.alm.model.Network;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;

@Slf4j
class NetworkBatchUpdatePreparedStatementSetter extends BaseBatchPreparedStatementSetter<Network> {

    NetworkBatchUpdatePreparedStatementSetter(String tenantId, List<Network> networks,
        JsonbAttributeConverter jsonbAttributeConverter,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter) {
        super(tenantId, networks, jsonbAttributeConverter, offsetDateTimeAttributeConverter);
    }

    @Override
    public void setValues(PreparedStatement ps, int i) throws SQLException {
        Network instance = instances.get(i);
        if (StringUtils.isEmpty(instance.getAssetId())) {
            ps.setString(1, null);
            ps.setString(2, instance.getSourceKey());
            ps.setString(3, instance.getName());
            ps.setString(4, instance.getDescription());
            ps.setObject(5, jsonbAttributeConverter.convertToDatabaseColumn(instance.getAttributes()));
        } else {
            ps.setString(1, instance.getAssetId());
            ps.setString(2, null);
            ps.setObject(3, null);
            ps.setString(4, null);
            ps.setObject(5, null);
        }
        ps.setString(6, instance.getLastModifiedBy());
        ps.setTimestamp(7, now);
        ps.setString(8, tenantId);
        ps.setString(9, instance.getId());
        //setting computed values back to bean for client's convenience
        setLastModifiedDate(instance);
    }
}