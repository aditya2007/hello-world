/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.sql;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.jpa.utils.ConfigUtils;
import com.ge.apm.alm.persistence.jpa.utils.DatabaseUtil;
import com.ge.apm.alm.persistence.jpa.utils.UserPolicyInterpreter;

public final class AssetInstanceSQL {

    public static final UUID NULL_UUID = new UUID(0L, 0L);

    private static final String DELETE_FROM_APM_ALM_ASSET_INSTANCE = "delete from apm_alm.asset_instance ";

    private static final String WHERE_TENANT_ID = " where tenant_id = ? ";

    private static final String WHERE_TENANT_ID_AND_ID_CLAUSE = WHERE_TENANT_ID + " and id = ? ";

    private static final String WHERE_TENANT_ID_AND_SRC_KEY_CLAUSE = WHERE_TENANT_ID + " and lower(source_key) = ? ";

    private static final String WHERE_TENANT_ID_AND_SRC_KEY_IN_CLAUSE = WHERE_TENANT_ID
        + " and lower(source_key) in ({0}) ";

    private static final String ID_IN_0 = " id in ({0}) ";

    private static final String ALL_CHILDREN_CLAUSE = " ancestors_array @> array[''{0}''] ";

    static final String ID_OR_ANCESTORS_CLAUSE = "(id = ''{0}'' or " + ALL_CHILDREN_CLAUSE + ")";

    private static final String ACCESS_CONTROL_CLAUSE = "(" + ID_IN_0 + " or ancestors_array && array[{0}])";

    private static final String ACCESS_CONTROL_CLAUSE_2 = "(id in ({1}) or ancestors_array && array[{1}])";

    private static final String WHERE_TENANT_ID_AND_ID_AND_ACL_FOR_SINGLE_OBJECT = WHERE_TENANT_ID_AND_ID_CLAUSE
        + SQLConstants.AND + ACCESS_CONTROL_CLAUSE;

    private static final String ACCESS_CONTROL_SQL_PATTERN_FOR_SINGLE_OBJECT_BY_SRC_KEY =
        WHERE_TENANT_ID_AND_SRC_KEY_CLAUSE + SQLConstants.AND + ACCESS_CONTROL_CLAUSE;

    private static final String ACCESS_CONTROL_SQL_PATTERN_BY_SRC_KEYS = WHERE_TENANT_ID_AND_SRC_KEY_IN_CLAUSE
        + SQLConstants.AND + ACCESS_CONTROL_CLAUSE_2;

    private static final String PARENT_ACL_CLAUSE =
        "select id from apm_alm.asset_instance where tenant_id = ''{0}'' and id in ({1}) and (id"
            + " in ({2}) or ancestors_array && array[{2}])";

    private static final String PARENT_CLAUSE = "parent_id in ({0})";

    private static final String PARENT_NULL_CLAUSE = "parent_id is null";

    private static final String ANCESTOR_CLAUSE = "ancestors_array && array[{0}]";

    // {0} is tenantId
    // {1} is additional parent filtering criteria without ACL
    // {2} is empty for Uber or otherwise the and-ACL clause
    private static final String PARENT_IN_CLAUSE
        = "parent_id in (select id from apm_alm.asset_instance where tenant_id = ''{0}'' {1} {2})";

    private static final String ANCESTORS_IN_CLAUSE =
        "ancestors_array && array(select cast(id as text) from apm_alm.asset_instance where tenant_id = ''{0}'' "
            + "{1} {2})";

    private static final String ID_COLUMN = "select id from apm_alm.asset_instance";

    private static final String ID_WITH_ANCESTORS_COLUMNS
        = "select id, tenant_id, ancestors_array from apm_alm.asset_instance";

    private static final String BASIC_COLUMNS =
        "select id, source_key, name, description, asset_type, super_types_array, tenant_id, created_by, created_date, "
            + "last_modified_by, last_modified_date from apm_alm.asset_instance";

    private static final String BASIC_COLUMNS_WITH_ATTRIBUTES = "select id, source_key, name, description, "
        + "asset_type, super_types_array, attributes, tenant_id, created_by, created_date, last_modified_by, "
        + "last_modified_date " + "from apm_alm.asset_instance";

    private static final String DELETE_ASSET_SQL = DELETE_FROM_APM_ALM_ASSET_INSTANCE + WHERE_TENANT_ID_AND_ID_CLAUSE;

    private static final String DELETE_ASSET_SQL_RECURSIVE = DELETE_FROM_APM_ALM_ASSET_INSTANCE + WHERE_TENANT_ID
        + " and ( " + ALL_CHILDREN_CLAUSE + " or id = ? " + ")";

    private static final String DELETE_ASSET_SQL_WITH_ACL = DELETE_FROM_APM_ALM_ASSET_INSTANCE
        + WHERE_TENANT_ID_AND_ID_AND_ACL_FOR_SINGLE_OBJECT;

    private static final String DELETE_ASSET_SQL_WITH_ACL_RECURSIVE = DELETE_ASSET_SQL_RECURSIVE + SQLConstants.AND
        + ACCESS_CONTROL_CLAUSE_2;

    private static final String BATCH_CREATE_SQL =
        "insert into apm_alm.asset_instance (id, source_key, name, description, tenant_id," + " asset_type, "
            + "parent_id, attributes, ancestors_array, super_types_array, geolocation, " + "created_by, "
            + "created_date, " + "last_modified_by, last_modified_date) values (?, ?, ?, ?, ?, ?,"
            + " ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String BATCH_UPDATE_SQL =
        "update apm_alm.asset_instance set source_key = ?, name = ?, description = ?, " + "asset_type = ?, "
            + "parent_id = ?, attributes = ?, ancestors_array = ?, " + "super_types_array = ?, geolocation = ?, "
            + "last_modified_by = ?, " + "last_modified_date = ? where tenant_id = ? and id = ?";

    private static final String BATCH_UPDATE_ANCESTORS_SQL =
        "update apm_alm.asset_instance set ancestors_array = ?, last_modified_by = ?, "
            + "last_modified_date = ? where tenant_id = ? and id = ?";

    private static final String ANCESTORS_BY_ID_SQL =
        "select id, ancestors_array from apm_alm.asset_instance where tenant_id = ? and " + ID_IN_0;

    private static final String ORDER_BY_HIERARCHY_WITH_ORDER_BY_ID = " order by (apm_alm.map_asset_type"
        + "(super_types_array), id) asc ";

    private static final String ORDER_BY_HIERARCHY = " order by apm_alm.map_asset_type(super_types_array) asc ";

    private static final AtomicReference<String> ALL_COLUMNS = new AtomicReference<>();
    private static final AtomicReference<String> ALL_WITHOUT_ATTRIBUTES = new AtomicReference<>();

    private AssetInstanceSQL() {
    }

    public static String getOrderByHierarchy() {
        if (ConfigUtils.isOrderByIdDisabled) {
            return ORDER_BY_HIERARCHY;
        } else {
            return ORDER_BY_HIERARCHY_WITH_ORDER_BY_ID;
        }
    }

    public static String getBatchCreateSQL() {
        return BATCH_CREATE_SQL;
    }

    public static String getBatchUpdateSQL() {
        return BATCH_UPDATE_SQL;
    }

    public static String getBatchUpdateAncestorsSql() {
        return BATCH_UPDATE_ANCESTORS_SQL;
    }

    public static boolean hasApplicablePolicies(Collection<String> accessibleResources) {
        return QueryUtils.isNotUber(accessibleResources) && !CollectionUtils.isEmpty(UserPolicyInterpreter
            .filterPolicies(Arrays.asList(SeedOOTBData.ROOT_ASSET_TYPE_ID, SeedOOTBData.ROOT_SEGMENT_TYPE_ID,
                SeedOOTBData.ROOT_SITE_TYPE_ID, SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID)));
    }

    public static String buildUserPolicyAccessControlSql(Collection<String> accessibleResources) {
        if (QueryUtils.isUber(accessibleResources)) {
            return "";
        }
        String policyPredicate = UserPolicyInterpreter.filterPolicies(Arrays
            .asList(SeedOOTBData.ROOT_ASSET_TYPE_ID, SeedOOTBData.ROOT_SEGMENT_TYPE_ID, SeedOOTBData.ROOT_SITE_TYPE_ID,
                SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID)).stream().collect(Collectors.joining(" AND "));
        return StringUtils.isEmpty(policyPredicate) ? "" : " AND (" + policyPredicate + ") ";
    }

    private static String buildAccessControlSqlForCollection(String andFilterExpression,
        Collection<String> accessibleResources) {
        if (QueryUtils.isUber(accessibleResources)) {
            return WHERE_TENANT_ID + andFilterExpression + buildUserPolicyAccessControlSql(
                accessibleResources); //NO ACLs
        }
        return WHERE_TENANT_ID + andFilterExpression + SQLConstants.AND + MessageFormat.format(ACCESS_CONTROL_CLAUSE,
            QueryUtils.getSqlListOfResources(accessibleResources)) + buildUserPolicyAccessControlSql(
            accessibleResources);
    }

    private static String buildAccessControlSqlForSingleObject(Collection<String> accessibleResources) {
        if (QueryUtils.isUber(accessibleResources)) {
            return WHERE_TENANT_ID_AND_ID_CLAUSE + buildUserPolicyAccessControlSql(accessibleResources); //NO ACLs
        }
        return MessageFormat.format(WHERE_TENANT_ID_AND_ID_AND_ACL_FOR_SINGLE_OBJECT,
            QueryUtils.getSqlListOfResources(accessibleResources)) + buildUserPolicyAccessControlSql(
            accessibleResources);
    }

    private static String buildAccessControlSqlForSingleObjectForUpdate(Collection<String> accessibleResources,
        boolean isParentObject) {
        String rowLockClause = isParentObject ? " FOR SHARE" : " FOR UPDATE";
        if (QueryUtils.isUber(accessibleResources)) {
            return WHERE_TENANT_ID_AND_ID_CLAUSE + buildUserPolicyAccessControlSql(accessibleResources)
                + rowLockClause; //" FOR UPDATE"; //NO ACLs
        }
        return MessageFormat.format(WHERE_TENANT_ID_AND_ID_AND_ACL_FOR_SINGLE_OBJECT,
            QueryUtils.getSqlListOfResources(accessibleResources)) + buildUserPolicyAccessControlSql(
            accessibleResources) + rowLockClause; // " FOR " + "UPDATE";
    }

    private static String buildAccessControlSqlForSingleObjectBySrcKey(Collection<String> accessibleResources) {
        if (QueryUtils.isUber(accessibleResources)) {
            return WHERE_TENANT_ID_AND_SRC_KEY_CLAUSE + buildUserPolicyAccessControlSql(accessibleResources); //NO ACLs
        }
        return MessageFormat.format(ACCESS_CONTROL_SQL_PATTERN_FOR_SINGLE_OBJECT_BY_SRC_KEY,
            QueryUtils.getSqlListOfResources(accessibleResources)) + buildUserPolicyAccessControlSql(
            accessibleResources);
    }

    private static String buildAccessControlSqlBySrcKeys(Collection<String> accessibleResources,
        List<String> sourceKeys) {
        String listOfLowerCaseSrcKeys = QueryUtils.getSqlListOfResources(
            sourceKeys.stream().map(String::toLowerCase).collect(Collectors.toList()));
        if (QueryUtils.isUber(accessibleResources)) {
            return MessageFormat.format(WHERE_TENANT_ID_AND_SRC_KEY_IN_CLAUSE, listOfLowerCaseSrcKeys)
                + buildUserPolicyAccessControlSql(accessibleResources); //NO ACLs
        }
        return MessageFormat.format(ACCESS_CONTROL_SQL_PATTERN_BY_SRC_KEYS, listOfLowerCaseSrcKeys,
            QueryUtils.getSqlListOfResources(accessibleResources)) + buildUserPolicyAccessControlSql(
            accessibleResources);
    }

    public static String buildDeleteAssetQuery(String assetId, boolean recursive) {
        //global tenant level deletion. Very powerful..So be careful
        if (recursive) {
            return MessageFormat.format(DELETE_ASSET_SQL_RECURSIVE, assetId) + SQLConstants.RETURNING_FULL;
        }
        return DELETE_ASSET_SQL + buildUserPolicyAccessControlSql(Collections.emptyList())
            + SQLConstants.RETURNING_FULL;
    }

    public static String buildDeleteAssetQuery(Collection<String> accessibleResources, String assetId,
        boolean recursive) {
        //Within a context of accessible resources..
        if (recursive) {
            return MessageFormat.format(DELETE_ASSET_SQL_WITH_ACL_RECURSIVE, assetId,
                QueryUtils.getSqlListOfResources(accessibleResources)) + SQLConstants.RETURNING_FULL;
        }
        return MessageFormat.format(DELETE_ASSET_SQL_WITH_ACL, QueryUtils.getSqlListOfResources(accessibleResources))
            + buildUserPolicyAccessControlSql(accessibleResources) + SQLConstants.RETURNING_FULL;
    }

    private static String getSelectAttributes(AttributeSelectEnum attributeSelectEnum) {
        if (attributeSelectEnum == null) {
            return BASIC_COLUMNS;
        }
        switch (attributeSelectEnum) {
            case ID:
                return ID_COLUMN;
            case ID_WITH_ANCESTORS:
                return ID_WITH_ANCESTORS_COLUMNS;
            case FULL:
                return getSelectAll();
            case ATTRIBUTES:
                return BASIC_COLUMNS_WITH_ATTRIBUTES;
            case FULL_WITHOUT_ATTRIBUTES:
                return getSelectAllButAttributes();
            default:
                return BASIC_COLUMNS;
        }
    }

    private static String getSelectAll() {
        String select = ALL_COLUMNS.get();
        if (select == null) {
            List<String> columns = new ArrayList<>(
                DatabaseUtil.getAllQueryColumns("asset_instance"));
            select = "select " + columns.stream().collect(Collectors.joining(","))
                + " from apm_alm.asset_instance";
            ALL_COLUMNS.set(select);
        }

        return select;
    }

    private static String getSelectAllButAttributes() {
        String select = ALL_WITHOUT_ATTRIBUTES.get();
        if (select == null) {
            List<String> columns = new ArrayList<>(
                DatabaseUtil.getAllQueryColumns("asset_instance"));
            columns.remove("attributes");
            select = "select " + columns.stream().collect(Collectors.joining(","))
                + " from apm_alm.asset_instance";
            ALL_WITHOUT_ATTRIBUTES.set(select);
        }

        return select;
    }

    public static String getSelectAssetForTags(Collection<String> accessibleResources, Collection<String> tagIds) {
        String query = getSelectAttributes(AttributeSelectEnum.BASIC) + WHERE_TENANT_ID
            + " and id in (select asset_id from apm_alm.tag_instance where tenant_id = ? and " + ID_IN_0 + ") ";
        if (QueryUtils.isUber(accessibleResources)) {
            return MessageFormat.format(query, QueryUtils.getSqlListOfResources(tagIds));
        } else {
            query += SQLConstants.AND + ACCESS_CONTROL_CLAUSE_2;
            return MessageFormat.format(query, QueryUtils.getSqlListOfResources(tagIds),
                QueryUtils.getSqlListOfResources(accessibleResources));
        }
    }

    public static String getSelectWithAccessControlSqlForCollection(AttributeSelectEnum attributeSelectEnum,
        Collection<String> accessibleResources) {
        return getSelectWithAccessControlSqlForCollection(attributeSelectEnum, "", accessibleResources);
    }

    public static String getSelectWithAccessControlSqlForCollection(AttributeSelectEnum attributeSelectEnum,
        String andFilterExpression, Collection<String> accessibleResources) {
        return getSelectAttributes(attributeSelectEnum) + buildAccessControlSqlForCollection(andFilterExpression,
            accessibleResources);
    }

    public static String getSelectWithAccessControlSqlForSingleObjectById(AttributeSelectEnum attributeSelectEnum,
        Collection<String> accessibleResources, boolean selectForUpdate, boolean isParentObject) {
        if (selectForUpdate) {
            return getSelectAttributes(attributeSelectEnum) + buildAccessControlSqlForSingleObjectForUpdate(
                accessibleResources, isParentObject);
        }
        return getSelectAttributes(attributeSelectEnum) + buildAccessControlSqlForSingleObject(accessibleResources);
    }

    public static String getSelectWithAccessControlSqlForSingleObjectByIdForUpdate(
        AttributeSelectEnum attributeSelectEnum, Collection<String> accessibleResources, boolean isParentObject) {
        return getSelectAttributes(attributeSelectEnum) + buildAccessControlSqlForSingleObjectForUpdate(
            accessibleResources, isParentObject);
    }

    public static String getSelectWithAccessControlSqlForSingleObjectBySourceKey(
        AttributeSelectEnum attributeSelectEnum, Collection<String> accessibleResources) {
        return getSelectAttributes(attributeSelectEnum) + buildAccessControlSqlForSingleObjectBySrcKey(
            accessibleResources);
    }

    public static String getBySourceKeys(AttributeSelectEnum attributeSelectEnum,
        Collection<String> accessibleResources, List<String> sourceKeys) {
        return getSelectAttributes(attributeSelectEnum) + buildAccessControlSqlBySrcKeys(accessibleResources,
            sourceKeys);
    }

    public static String getTypeIdPredicate(String typeId, boolean includeSubTypeInstances) {
        String clause = includeSubTypeInstances ? "(asset_type = ''{0}'' or super_types_array @> array[''{0}''])"
            : "asset_type = ''{0}''";
        return MessageFormat.format(clause, typeId);
    }

    private static String getTypeInPredicate(String tenantId, String filterExpression,
        boolean includeSubTypeInstances) {
        // {0} is tenantId
        // {1} is additional type filtering criteria without ACL
        String clause = includeSubTypeInstances ?
            "super_types_array && array(select cast(id as text) from apm_alm.asset_type where tenant_id = ''{0}'' "
                + "{1})" : "asset_type in (select id from apm_alm.asset_type where tenant_id = ''{0}'' {1})";
        return MessageFormat.format(clause, tenantId, filterExpression);
    }

    private static String getParentIdPredicate(String tenantId, Collection<String> accessibleResources,
        Set<String> parentIds, boolean includeAncestors) {
        // TODO: not yet handling mixture of NULL_UUID and other UUIDs
        if (parentIds.size() == 1 && parentIds.contains(NULL_UUID.toString())) {
            return PARENT_NULL_CLAUSE + (QueryUtils.isUber(accessibleResources) ? "" : " and " + MessageFormat.format(
                ACCESS_CONTROL_CLAUSE, QueryUtils.getSqlListOfResources(accessibleResources)));
        } else {
            String parentClause = includeAncestors ? ANCESTOR_CLAUSE : PARENT_CLAUSE;
            String parentACL = QueryUtils.isUber(accessibleResources) ? ""
                : SQLConstants.AND + "exists(" + MessageFormat.format(PARENT_ACL_CLAUSE, tenantId,
                    QueryUtils.getSqlListOfResources(parentIds), QueryUtils.getSqlListOfResources(accessibleResources))
                    + ")";
            return MessageFormat.format(parentClause, QueryUtils.getSqlListOfResources(parentIds)) + parentACL;
        }
    }

    private static String getParentInPredicate(String tenantId, Collection<String> accessibleResources,
        String filterExpression, boolean includeAncestors) {
        String clause = includeAncestors ? ANCESTORS_IN_CLAUSE : PARENT_IN_CLAUSE;
        String andAclClause = QueryUtils.isUber(accessibleResources) ? "" : SQLConstants.AND + MessageFormat.format(
            ACCESS_CONTROL_CLAUSE, QueryUtils.getSqlListOfResources(accessibleResources));
        return MessageFormat.format(clause, tenantId, filterExpression, andAclClause);
    }

    public static String getSelectAncestorsByIds(Collection<String> accessibleResources, Collection<String> assetIds) {
        String query = MessageFormat.format(ANCESTORS_BY_ID_SQL, QueryUtils.getSqlListOfResources(assetIds));
        if (QueryUtils.isUber(accessibleResources)) {
            return query;
        }
        return query + SQLConstants.AND + MessageFormat.format(ACCESS_CONTROL_CLAUSE,
            QueryUtils.getSqlListOfResources(accessibleResources));
    }

    public static String getFilterPredicate(String tenantId, AssetPredicate predicate,
        Collection<String> accessibleResources) {
        if (predicate == null) {
            return "";
        }

        boolean missingChildPredicates = predicate.getChildOperand() == null || !CollectionUtils.isEmpty(
            predicate.getChildPredicates());
        assert missingChildPredicates : "Predicate with child operand must have non-empty list of child predicates.";

        //current asset's asset_type context
        List<String> expressions = getTypePredicateExpressions(tenantId, predicate.getType());

        // current asset's context
        expressions.addAll(getAssetContextFilters(predicate));

        // current asset's parent_id context
        expressions.addAll(getParentContextFilters(tenantId, accessibleResources, predicate.getParent()));
        expressions = expressions.stream().filter(e -> !StringUtils.isEmpty(e)).collect(Collectors.toList());

        StringBuilder rslt = new StringBuilder();
        if (!CollectionUtils.isEmpty(expressions)) {
            rslt.append(QueryUtils.flattenAssetInstanceSqlExpressions(expressions, Operand.AND));
            if (predicate.getChildOperand() != null) {
                rslt.append(" ").append(predicate.getChildOperand().name().toLowerCase(Locale.getDefault()));
            }
        }

        if (!CollectionUtils.isEmpty(predicate.getChildPredicates())) {
            rslt.append(" (");
            int lastIndex = predicate.getChildPredicates().size() - 1;
            int i = 0;
            for (AssetPredicate ap : predicate.getChildPredicates()) {
                rslt.append(getFilterPredicate(tenantId, ap, accessibleResources));
                if (ap.getPeerOperand() != null && i < lastIndex) {
                    rslt.append(" ").append(ap.getPeerOperand().name().toLowerCase(Locale.getDefault())).append(" ");
                }
                i++;
            }
            rslt.append(")");
        }

        if (rslt.length() == 0) {
            return "";
        }
        return rslt.insert(0, "(").append(")").toString();
    }

    private static List<String> getAssetContextFilters(AssetPredicate assetPredicate) {
        List<String> expressions = QueryUtils.getEqualOrLikeFilterExpressions(assetPredicate,
            assetPredicate.getAttributes(), assetPredicate.getReservedAttributes());

        Set<String> ids = assetPredicate.getIds();
        if (!CollectionUtils.isEmpty(ids)) {
            expressions.add(MessageFormat.format(ID_IN_0, QueryUtils.getSqlListOfResources(ids)));
        }

        if (isTemplateInfoFilterExist(assetPredicate)) {
            expressions.add(getTemplateInfoFilter(assetPredicate));
        }

        return expressions;
    }

    public static List<String> getTypePredicateExpressions(String tenantId, TypePredicate typePredicate) {
        if (typePredicate == null) {
            return new ArrayList<>();
        }

        List<String> expressions = QueryUtils.getEqualOrLikeFilterExpressions(typePredicate,
            typePredicate.getAttributes(), typePredicate.getReservedAttributes());
        Set<String> typeParentIds = typePredicate.getParent() == null ? null : typePredicate.getParent().getIds();
        if (CollectionUtils.isEmpty(typeParentIds)) {
            Set<String> typeIds = typePredicate.getIds();
            if (CollectionUtils.isEmpty(typeIds)) {
                String filterExp;
                if (!CollectionUtils.isEmpty(expressions)) {
                    filterExp = "and " + QueryUtils.flattenExpressions(expressions, Operand.AND);
                    expressions.clear();
                    expressions.add(getTypeInPredicate(tenantId, filterExp, typePredicate.isDeepSearch()));
                }
            } else if (expressions.isEmpty()) {
                expressions.add(MessageFormat.format(typePredicate.isDeepSearch()
                        ? "(asset_type in ({0}) or super_types_array && array[{0}])"
                        : "asset_type in ({0})", QueryUtils.getSqlListOfResources(typeIds)));
            } else {
                String clause = typePredicate.isDeepSearch() ? "(id in ({0}) or super_types_array && array[{0}])"
                    : "id in ({0})";
                expressions.add(MessageFormat.format(clause, QueryUtils.getSqlListOfResources(typeIds)));
                String filterExp = QueryUtils.flattenExpressions(expressions, Operand.AND);
                expressions.clear();
                expressions.add(MessageFormat
                    .format("asset_type in (select id from apm_alm.asset_type where tenant_id = ''{0}'' and ", tenantId)
                    + filterExp + ")");
            }
        } else {
            String clause = typePredicate.getParent().isDeepSearch() ? "super_types_array && array[{0}]"
                : "super_type_id in ({0})";
            expressions.add(MessageFormat.format(clause, QueryUtils.getSqlListOfResources(typeParentIds)));
            String filterExp = QueryUtils.flattenExpressions(expressions, Operand.AND);
            expressions.clear();
            expressions.add(MessageFormat
                .format("asset_type in (select id from apm_alm.asset_type where tenant_id = ''{0}'' and ", tenantId)
                + filterExp + ")");
        }

        return expressions;
    }

    public static List<String> getParentContextFilters(String tenantId, Collection<String> accessibleResources,
        ParentPredicate parent) {
        if (parent == null) {
            return Collections.emptyList();
        }
        List<String> expressions = getParentTypePredicateExpressions(tenantId, accessibleResources, parent);

        if (!CollectionUtils.isEmpty(parent.getIds())) {
            expressions.add(
                getParentIdPredicate(tenantId, accessibleResources, parent.getIds(), parent.isDeepSearch()));
        }

        List<String> parentExpressions = QueryUtils.getEqualOrLikeFilterExpressions(parent, parent.getAttributes(),
            parent.getReservedAttributes());
        if (!CollectionUtils.isEmpty(parentExpressions)) {
            String filterExp = "and " + QueryUtils.flattenExpressions(parentExpressions, Operand.AND);
            expressions.add(getParentInPredicate(tenantId, accessibleResources, filterExp, parent.isDeepSearch()));
        }

        return expressions.stream().filter(e -> !StringUtils.isEmpty(e)).collect(Collectors.toList());
    }

    public static List<String> getParentTypePredicateExpressions(String tenantId,
        Collection<String> accessibleResources, ParentPredicate parent) {
        if (parent == null) {
            return new ArrayList<>();
        }
        List<String> typeFilters = getTypePredicateExpressions(tenantId, parent.getType());
        if (!CollectionUtils.isEmpty(typeFilters)) {
            String filter = "and " + QueryUtils.flattenExpressions(typeFilters, Operand.AND);
            typeFilters.clear();
            typeFilters.add(getParentInPredicate(tenantId, accessibleResources, filter, parent.isDeepSearch()));
        }

        return typeFilters;
    }

    public static String getSelectAssetsByIds(Collection<String> accessibleResources, Set<String> assetIds,
        AttributeSelectEnum attributeSelectEnum) {
        String query = getSelectAttributes(attributeSelectEnum) + WHERE_TENANT_ID + " and id in ({0}) ";
        if (QueryUtils.isUber(accessibleResources)) {
            return MessageFormat.format(query, QueryUtils.getSqlListOfResources(assetIds))
                + buildUserPolicyAccessControlSql(accessibleResources);
        } else {
            query += SQLConstants.AND + ACCESS_CONTROL_CLAUSE_2;
            return MessageFormat.format(query, QueryUtils.getSqlListOfResources(assetIds),
                QueryUtils.getSqlListOfResources(accessibleResources)) + buildUserPolicyAccessControlSql(
                accessibleResources);
        }
    }

    private static String getTemplateInfoFilter(AssetPredicate predicate) {
        String tid = QueryUtils.escapeLiteral(predicate.getTemplateId());
        String ppn = QueryUtils.escapeLiteral(predicate.getPpn());
        String subTid = QueryUtils.escapeLiteral(predicate.getEmbeddedTemplateId());
        String subPpn = QueryUtils.escapeLiteral(predicate.getEmbeddedPpn());

        String sql = "id in (select asset_placeholder.asset_id" + " from apm_alm.asset_placeholder"
            + " join apm_alm.placeholder placeholder1" + " on (asset_placeholder.placeholder_id = placeholder1.id"
            + andTemplateInfoTerm("placeholder1.template_id", subTid) + andTemplateInfoTerm(
            "placeholder1.part_position_number", subPpn) + ") join apm_alm.placeholder_template"
            + " on placeholder1.id = placeholder_template.placeholder_id" + " join apm_alm.placeholder placeholder2"
            + " on (placeholder_template.template_id = placeholder2.template_id and placeholder2.parent_id is null"
            + andTemplateInfoTerm("placeholder2.template_id ", tid) + andTemplateInfoTerm(
            "placeholder2.part_position_number", ppn) + ')';

        if ((!StringUtils.isEmpty(tid) || !StringUtils.isEmpty(ppn)) && StringUtils.isEmpty(subTid) && StringUtils
            .isEmpty(subPpn)) {
            sql += " union all" + " select asset_placeholder.asset_id" + " from apm_alm.asset_placeholder"
                + " join apm_alm.placeholder placeholder1" + " on (asset_placeholder.placeholder_id = placeholder1.id"
                + andTemplateInfoTerm("placeholder1.template_id", tid) + andTemplateInfoTerm(
                "placeholder1.part_position_number", ppn)
                + " and placeholder1.id not in (select placeholder_id from apm_alm.placeholder_template))";
        }

        return sql + ')';
    }

    private static String andTemplateInfoTerm(String column, String value) {
        return StringUtils.isEmpty(value) ? "" : SQLConstants.AND + column + " = '" + value + '\'';
    }

    private static boolean isTemplateInfoFilterExist(AssetPredicate predicate) {
        boolean isTemplateIdEmpty = StringUtils.isEmpty(predicate.getTemplateId());
        boolean isPpnEmpty = StringUtils.isEmpty(predicate.getPpn());
        boolean isEmbeddedTemplateIdEmpty = StringUtils.isEmpty(predicate.getEmbeddedTemplateId());
        boolean isEmbeddedPpnEmpty = StringUtils.isEmpty(predicate.getEmbeddedPpn());
        Boolean conformanceFlag = predicate.getConformanceFlag();

        boolean isTemplateEmpty = isTemplateIdEmpty && isPpnEmpty;
        boolean isEmbeddedTemplateEmpty = isEmbeddedTemplateIdEmpty && isEmbeddedPpnEmpty;
        return !isTemplateEmpty || !isEmbeddedTemplateEmpty || conformanceFlag != null;
    }
}
