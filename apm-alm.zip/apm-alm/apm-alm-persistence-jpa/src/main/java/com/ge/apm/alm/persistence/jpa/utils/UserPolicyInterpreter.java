/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.utils;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AssetUserPolicy;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.persistence.jpa.entity.AssetUserPolicyEntity;
import com.ge.apm.alm.utils.AlmRequestContext;
import com.ge.apm.alm.utils.AlmRequestContext.AlmRequestContextEnum;

public class UserPolicyInterpreter {

    private static final String ATTRIBUTE_DELIM = "\\.";

    private static final String KEY_VALUE_DELIM = "=";

    private static final String SUPER_TYPE_FILTER_CLAUSE = " super_types_array && array[{0}] ";

    private static final String DECOMMISSION_FILTER_CRITERIA = "reservedAttributes.state.key=\"10\"";

    private static final String VIEW_DECOMMISSIONED_ASSETS_FEATURE_CODE = "VIEW_DECOMMISSIONED_ASSETS";

    private UserPolicyInterpreter() {
    }

    public static List<AssetUserPolicy> getApplicablePolicies(List<String> applicableTypes) {
        if (isPoliciesDisabled()) {
            return Collections.emptyList();
        }
        List<AssetUserPolicy> policies = AlmRequestContext.get(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_AS_LIST,
            List.class);
        if (CollectionUtils.isEmpty(policies)) {
            return Collections.emptyList();
        }
        return policies.stream().filter(p -> applicableTypes.contains(p.getSuperType())).collect(Collectors.toList());
    }

    public static List<String> filterPolicies(List<String> applicableTypes) {
        if (isPoliciesDisabled()) {
            return Collections.emptyList();
        }
        List<AssetUserPolicy> policies = AlmRequestContext.get(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_AS_LIST,
            List.class);
        policies = (policies == null) ? new ArrayList<>() : new ArrayList<>(policies);

        //User does not have view decommission policy
        if (!hasViewDecommissionedAssetPolicy(policies)) {
            policies.add(createHideDecommissionedAssetPolicy());
        } else {
            policies = policies.stream().filter(
                policy -> !VIEW_DECOMMISSIONED_ASSETS_FEATURE_CODE.equals(policy.getFeatureCode())).collect(
                Collectors.toList());
            if (CollectionUtils.isEmpty(policies)) {
                return Collections.emptyList();
            }
        }

        // Added for Hide Tag by Classification.
        /*if (!hasViewDecommissionedAssetPolicy(policies)) {
            return Collections.emptyList();
        }*/

        Map<String, List<AssetUserPolicy>> applicablePolicies = policies.stream().filter(
            p -> applicableTypes.contains(p.getSuperType())).collect(Collectors
            .groupingBy(AssetUserPolicy::getFilterCriteria, HashMap::new, Collectors.toCollection(ArrayList::new)));

        return applicablePolicies.entrySet().stream().map(map -> constructFilterPredicate(map.getKey(),
            map.getValue().stream().map(AssetUserPolicy::getSuperType).collect(Collectors.toList()))).filter(
            str -> !StringUtils.isEmpty(str)).collect(Collectors.toList());
    }

    public static String constructFilterPredicate(String filterCriteria, List<String> superTypes) {
        return constructAttributeBasedFilter(filterCriteria, superTypes);
    }

    private static boolean hasViewDecommissionedAssetPolicy(List<AssetUserPolicy> policies) {
        return policies.stream().anyMatch(
            assetUserPolicy -> VIEW_DECOMMISSIONED_ASSETS_FEATURE_CODE.equals(assetUserPolicy.getFeatureCode()));
    }

    private static AssetUserPolicy createHideDecommissionedAssetPolicy() {
        AssetUserPolicyEntity assetUserPolicyEntity = new AssetUserPolicyEntity();
        assetUserPolicyEntity.setFilterCriteria(DECOMMISSION_FILTER_CRITERIA);
        assetUserPolicyEntity.setSuperType(SeedOOTBData.ROOT_ASSET_TYPE_ID);
        return assetUserPolicyEntity;
    }

    private static String constructAttributeBasedFilter(String filterCriteria, List<String> superTypes) {
        if (StringUtils.isEmpty(filterCriteria)) {
            return "";
        }
        String attributePath = org.apache.commons.lang3.StringUtils.substringBefore(filterCriteria, KEY_VALUE_DELIM);
        String attributeValue = org.apache.commons.lang3.StringUtils.substringAfter(filterCriteria, KEY_VALUE_DELIM);
        List<String> attributeKeys = Arrays.asList(attributePath.split(ATTRIBUTE_DELIM));

        String attributeSql = "attributes @> '" + constructJsonBPredicate(attributeKeys, attributeValue) + "'";

        String formattedTypes = IntStream.range(0, superTypes.size()).mapToObj(i -> "'" + superTypes.get(i) + "'")
            .collect(Collectors.joining(", "));
        String superTypeSql = MessageFormat.format(SUPER_TYPE_FILTER_CLAUSE, formattedTypes);

        return " NOT (" + attributeSql + " AND " + superTypeSql + ") ";
    }

    private static String constructJsonBPredicate(List<String> attributeKeys, String value) {
        if (CollectionUtils.isEmpty(attributeKeys)) {
            return value;
        } else {
            return "{" + wrapInQuotes(attributeKeys.get(0)) + ": " + constructJsonBPredicate(
                attributeKeys.subList(1, attributeKeys.size()), value) + "}";
        }
    }

    private static String wrapInQuotes(String str) {
        return "\"" + str + "\"";
    }

    public static List<String> getSubjectIds() {
        List<String> subjectIds = new ArrayList<>();

        String userId = AlmRequestContext.get(AlmRequestContextEnum.SUBJECT_UUID, String.class);
        if (!StringUtils.isEmpty(userId)) {
            subjectIds.add(userId);
        }

        List<String> groupIds = AlmRequestContext.get(AlmRequestContextEnum.SUBJECT_ASSOCIATED_GROUP_UUID_AS_LIST,
            List.class);
        if (!CollectionUtils.isEmpty(groupIds)) {
            subjectIds.addAll(groupIds);
        }
        return subjectIds;
    }

    private static boolean isPoliciesDisabled() {
        Boolean policiesEnabled = AlmRequestContext.get(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_ENABLED,
            Boolean.class);
        return (policiesEnabled == null || !policiesEnabled);
    }
}