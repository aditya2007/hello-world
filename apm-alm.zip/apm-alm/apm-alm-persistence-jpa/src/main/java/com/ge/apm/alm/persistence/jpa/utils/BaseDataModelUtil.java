/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.ge.apm.alm.model.BaseDataModel;

public final class BaseDataModelUtil {

    private BaseDataModelUtil() {
        // nothing
    }

    @SuppressWarnings("unchecked")
    public static <T extends BaseDataModel> Map<String, T> toIdMap(
        List<? extends BaseDataModel> models, Map<String, T> map) {

        Map<String, T> theMap = map;
        if (theMap == null) {
            theMap = new LinkedHashMap<>(models.size());
        }

        for (BaseDataModel model : models) {
            theMap.put(model.getId(), (T) model);
        }

        return theMap;
    }

    public static <T extends BaseDataModel> Map<String, T> toIdMap(T model, Map<String, T> map) {
        Map<String, T> theMap = map;
        if (theMap == null) {
            theMap = new LinkedHashMap<>();
        }
        theMap.put(model.getId(), model);

        return theMap;
    }

}
