/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entity;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;

@Entity
@Table(name = "asset_group", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class AssetGroupEntity extends SourceableEntity implements AssetGroup {

    @Column(name = "category")
    @Enumerated(EnumType.STRING)
    private AssetGroupCategory category;

    @Column(name = "attributes")
    @Convert(converter = JsonbAttributeConverter.class)
    private JsonNode attributes;

    @Transient
    @JsonIgnore
    private List<AssetGroupItem> items;

    @Builder
    private AssetGroupEntity(String id, String sourceKey, String name, String description,
        String tenantId, AssetGroupCategory category, JsonNode attributes, String createdBy, String lastModifiedBy) {
        super(id, name, tenantId, createdBy, lastModifiedBy, sourceKey, description);
        this.category = category;
        this.attributes = attributes;
    }
}

