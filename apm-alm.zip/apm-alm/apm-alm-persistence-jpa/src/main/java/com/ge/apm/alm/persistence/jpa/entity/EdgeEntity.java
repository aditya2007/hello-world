/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.Direction;
import com.ge.apm.alm.model.Edge;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;

/**
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 July 15, 2017
 * @since 1.0
 */
@Entity
@Table(name = "edge", schema = "apm_alm")
@Getter
@Setter
@NoArgsConstructor
@ToString(callSuper = true)
public class EdgeEntity extends AuditableEntity implements Edge {

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "source")
    private String source;

    @Column(name = "target")
    private String target;

    @Column(name = "direction")
    @Enumerated(EnumType.STRING)
    private Direction direction;

    @Column(name = "attributes")
    @Convert(converter = JsonbAttributeConverter.class)
    private JsonNode attributes;

    @Column(name = "asset_id")
    private String assetId;

    @Transient
    private Asset asset;

    @Transient
    private NetworkEntity sourceNetwork;

    @Transient
    private NetworkEntity targetNetwork;

    @Builder
    private EdgeEntity(String id, String tenantId, String createdBy, String lastModifiedBy, String name,
        String description, String source, String target, Direction direction, JsonNode attributes,
        String assetId) {
        super(id, tenantId, createdBy, lastModifiedBy);
        this.name = name;
        this.description = description;
        this.source = source;
        this.target = target;
        this.direction = direction;
        this.attributes = attributes;
        this.assetId = assetId;
    }
}

