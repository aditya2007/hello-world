/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.ReservedAttributeContextConfig;

@Entity
@Table(name = "reserved_attribute_context_config", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
public class ReservedAttributeContextConfigEntity extends IdEntity implements
    ReservedAttributeContextConfig{

    @Column(name = "tenant_id")
    private String tenantId;

    @Column(name = "code", nullable = false)
    private String code;

    @Column(name = "semantic_name")
    private String semanticName;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "description")
    private String description;

    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    @Column(name = "is_default", nullable = false)
    private Boolean isDefault;

    @ManyToOne
    @JoinColumn(name = "context_id", referencedColumnName = "id", nullable = false, updatable = false,
        insertable = true)
    private ContextEntity context;
}
