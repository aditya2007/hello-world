/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.model.view.AssetTypeComponent;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.entity.AssetTypeEntity;
import com.ge.apm.alm.persistence.jpa.utils.BaseDataModelUtil;

@Component
@Order(10)
public class AssetTypeParentLoader
    implements PostLoadHandler<AssetTypeEntity, AssetTypeComponent>,
    ApplicationListener<ContextRefreshedEvent> {

    private AssetTypePersistencyService typePersistencyService;

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources, AssetTypeEntity entity,
        AttributeSelectEnum selectEnum, Set<AssetTypeComponent> components) {
        if (entity == null || ignoreParentComponent(components)) {
            return;
        }

        if (!CollectionUtils.isEmpty(entity.getSuperTypesArray())) {
            Set<String> typeIds = new HashSet<>(entity.getSuperTypesArray());
            loadTypes(tenantId, components, typeIds, BaseDataModelUtil.toIdMap(entity, null));
        }
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources, List<AssetTypeEntity> types,
        AttributeSelectEnum selectEnum, Set<AssetTypeComponent> components) {
        if (types.isEmpty() || ignoreParentComponent(components)) {
            return;
        }

        Set<String> typeIds = new HashSet<>();
        types.forEach(type -> {
            if (type.getSuperTypesArray() != null) {
                typeIds.addAll(type.getSuperTypesArray());
            }
        });

        Map<String, AssetType> existingTypes = BaseDataModelUtil.toIdMap(types, null);
        typeIds.removeAll(existingTypes.keySet());

        loadTypes(tenantId, components, typeIds, existingTypes);
    }

    private boolean ignoreParentComponent(Set<AssetTypeComponent> components) {
        return components == null || !components.contains(AssetTypeComponent.PARENT)
            && !components.contains(AssetTypeComponent.PARENT_ATTRIBUTES);
    }

    private void loadTypes(String tenantId, Set<AssetTypeComponent> components,
        Set<String> idsToLoad, Map<String, AssetType> existingMap) {
        removeSystemTypes(idsToLoad);

        Map<String, AssetType> allIdMap = existingMap;
        if (!idsToLoad.isEmpty()) {
            TypePredicate typePredicate = TypePredicate.builder()
                .ids(idsToLoad)
                .attributeSelectEnum(components.contains(AssetTypeComponent.PARENT_ATTRIBUTES)
                    ? AttributeSelectEnum.FULL : AttributeSelectEnum.FULL_WITHOUT_ATTRIBUTES)
                .build();
            List<AssetType> typesFound = typePersistencyService.findAllAssetTypes(tenantId, typePredicate);
            allIdMap = BaseDataModelUtil.toIdMap(typesFound, allIdMap);
        }

        setTypes(allIdMap);
    }

    private void setTypes(Map<String, AssetType> idMap) {
        idMap.forEach((id, type) -> {
            String parentId = type.getSuperTypeId();
            if (!StringUtils.isEmpty(parentId)) {
                AssetType parentType = idMap.get(parentId);
                if (parentType != null) {
                    ((AssetTypeEntity) type).setSuperType((AssetTypeEntity) parentType);
                }
            }
        });
    }

    private void removeSystemTypes(Set<String> ids) {
        if (!ids.isEmpty()) {
            for (OOTBCoreTypesIdLookup lookup : OOTBCoreTypesIdLookup.values()) {
                ids.remove(lookup.getId());
            }
        }
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        typePersistencyService = event.getApplicationContext().getBean(AssetTypePersistencyService.class);
    }
}
