/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.crosstenancy;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;

import lombok.Getter;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.utils.AlmRequestContext;
import com.ge.apm.alm.utils.AlmRequestContext.AlmRequestContextEnum;
import com.ge.apm.common.support.RequestContext;

/**
 * @author Shu W. Yu 212614203
 * @version 1.0 Mar 22, 2018
 * @since 1.0
 */
@Getter
abstract class AbstractCrossTenancyCall {

    static final String ACCESSIBLE_RESOURCES = "AccessibleResources";
    static final String ALL_ACCESSIBLE_RESOURCES = "AllAccessibleResources";
    private final String tenantId;
    private final boolean contextTenant;
    private Collection<String> accessibleResourceIds;
    private Map<String, Object> requestContextMap;
    private Map<AlmRequestContextEnum, Object> almRequestContext;

    AbstractCrossTenancyCall(String tenantId, boolean contextTenant, AbstractCrossTenancyCall prevCall) {
        this.tenantId = tenantId;
        this.contextTenant = contextTenant;

        if (prevCall == null) {
            this.requestContextMap = RequestContext.copy();
            this.almRequestContext = AlmRequestContext.copy();
        } else {
            this.requestContextMap = prevCall.getRequestContextMap();
            this.almRequestContext = prevCall.getAlmRequestContext();
        }

        String[] aclArray = getAccessibleResources(tenantId);
        if (aclArray != null) {
            Collection<String> acls = Arrays.asList(aclArray);
            this.accessibleResourceIds = acls.contains("*") || acls.contains(tenantId)
                ? Collections.emptySet()
                : acls.stream().map(AbstractCrossTenancyCall::extractUuid).collect(Collectors.toSet());
        }
    }

    private static String extractUuid(String uri) {
        String uuid = null;
        if (!StringUtils.isEmpty(uri)) {
            uuid = uri.substring(uri.lastIndexOf('/') + 1);
        }
        return uuid;
    }

    void saveContext() {
        this.requestContextMap = RequestContext.copy();
        this.almRequestContext = AlmRequestContext.copy();
    }

    void clean() {
        if (!isContextTenant()) {
            RequestContext.destroy();
            AlmRequestContext.destroy();
        }
    }

    String[] getAccessibleResources(String tenantId) {
        if (contextTenant) {
            return (String[]) requestContextMap.get(ACCESSIBLE_RESOURCES);
        }

        Map allAcls = (Map) requestContextMap.get(ALL_ACCESSIBLE_RESOURCES);
        return allAcls == null ? null : (String[]) allAcls.get(tenantId);
    }

    static String formatTenantId(String tenantId) {
        String formattedTenantId = tenantId;
        if (!tenantId.contains("-")) {
            tenantId = tenantId.toLowerCase();
            formattedTenantId = String.format("%s-%s-%s-%s-%s", tenantId.substring(0, 8), tenantId.substring(8, 12),
                tenantId.substring(12, 16), tenantId.substring(16, 20), tenantId.substring(20));
        }
        return formattedTenantId;
    }

    boolean hasOp() {
        return accessibleResourceIds != null;
    }

    void setupCallContext() {
        if (!isContextTenant()) {
            RequestContext.initialize(getRequestContextMap());
            RequestContext.put(RequestContext.TENANT_UUID, tenantId);
            RequestContext.put(ACCESSIBLE_RESOURCES, getAccessibleResources(tenantId));

            AlmRequestContext.initialize(getAlmRequestContext());
            AlmRequestContext.put(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_ENABLED, true);
            AlmRequestContext.put(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_AS_LIST, Collections.emptyList());
        }
        RequestContext.remove(ALL_ACCESSIBLE_RESOURCES);
    }
}
