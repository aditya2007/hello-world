/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa;

import java.sql.Timestamp;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Edge;
import com.ge.apm.alm.model.Network;
import com.ge.apm.alm.model.NetworkHierarchy;
import com.ge.apm.alm.model.query.NetworkPredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.NetworkPersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectAlreadyExistsException;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.config.EntityAuditor;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.converter.HydratedEdgeRowMapper;
import com.ge.apm.alm.persistence.jpa.converter.HydratedNodeRowMapper;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;
import com.ge.apm.alm.persistence.jpa.entity.EdgeEntity;
import com.ge.apm.alm.persistence.jpa.entity.NetworkEntity;
import com.ge.apm.alm.persistence.jpa.entity.NetworkHierarchyEntity;
import com.ge.apm.alm.persistence.jpa.sql.NetworkSQL;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.sql.SQLConstants;
import com.ge.apm.alm.persistence.jpa.utils.Validator;

/**
 * @author Albert H. Yu 212365823
 * @version 1.0 July 15, 2017
 * @since 1.0
 */
@Service
@Slf4j
@Transactional
@PropertySource("classpath:alm_jpa.properties")
public class NetworkPersistencyServiceImpl implements NetworkPersistencyService {

    private static final String NETWORK_DOES_NOT_EXIST = "Network %s does not exist";

    @Autowired
    private DataSource dataSource;

    @Autowired
    private ConversionService conversionService;

    @Autowired
    private JsonbAttributeConverter jsonbAttributeConverter;

    @Autowired
    private ListToTextArrayAttributeConverter listToTextArrayAttributeConverter;

    @Autowired
    private OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private EntityAuditor entityAuditor;

    private EntityBeanPropertyRowMapper<NetworkEntity> networkBeanPropertyRowMapper;

    private EntityBeanPropertyRowMapper<EdgeEntity> edgeBeanPropertyRowMapper;

    private HydratedEdgeRowMapper hydratedEdgeRowMapper;

    private HydratedNodeRowMapper hydratedNodeRowMapper;

    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initializeConvertionService() {
        jdbcTemplate = new JdbcTemplate(dataSource);
        networkBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(NetworkEntity.class, conversionService);
        edgeBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(EdgeEntity.class, conversionService);
        hydratedEdgeRowMapper = new HydratedEdgeRowMapper(jsonbAttributeConverter, listToTextArrayAttributeConverter,
            conversionService);
        hydratedNodeRowMapper = new HydratedNodeRowMapper(jsonbAttributeConverter, listToTextArrayAttributeConverter,
            conversionService);
    }

    @Override
    public Network createNetwork(String tenantId, Collection<String> accessibleResources, Network network)
        throws PersistencyServiceException {
        validateEditNetwork(tenantId, accessibleResources, network);

        String insertSql = NetworkSQL.getCreateNetworkSQL();
        Timestamp now = offsetDateTimeAttributeConverter.convertToDatabaseColumn(OffsetDateTime.now());
        Object[] params = new Object[] { network.getId(), tenantId, network.getAssetId(), network.getSourceKey(),
            network.getName(), network.getDescription(), jsonbAttributeConverter.convertToDatabaseColumn(
            network.getAttributes()), network.getCreatedBy(), now, network.getLastModifiedBy(), now };
        if (StringUtils.isNotEmpty(network.getAssetId())) {
            params[3] = params[4] = params[5] = params[6] = null;
        }

        List<NetworkEntity> networks = jdbcTemplate.query(insertSql, networkBeanPropertyRowMapper, params);
        if (networks.size() != 1) {
            throw new PersistencyServiceException(
                "Failed to create network[" + network.getId() + "]: " + network.getName());
        }

        return networks.get(0);
    }

    @Override
    public int createNetworks(String tenantId, Collection<String> accessibleResources, List<Network> networks)
        throws PersistencyServiceException {
        validateEditNetworks(tenantId, accessibleResources, networks);

        int[] updateCounts = jdbcTemplate.batchUpdate(NetworkSQL.getBatchCreateNetworkSQL(),
            new NetworkBatchCreatePreparedStatementSetter(tenantId, networks, jsonbAttributeConverter,
                offsetDateTimeAttributeConverter));
        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public Network updateNetwork(String tenantId, Collection<String> accessibleResources, Network network)
        throws PersistencyServiceException {
        validateEditNetwork(tenantId, accessibleResources, network);
        String sql = NetworkSQL.getUpdateNetworkSQL() + SQLConstants.RETURNING_FULL;
        Timestamp now = offsetDateTimeAttributeConverter.convertToDatabaseColumn(OffsetDateTime.now());
        Object[] params = new Object[] { network.getAssetId(), network.getSourceKey(), network.getName(),
            network.getDescription(), jsonbAttributeConverter.convertToDatabaseColumn(network.getAttributes()),
            network.getLastModifiedBy(), now, tenantId, network.getId() };
        if (StringUtils.isNotEmpty(network.getAssetId())) {
            params[1] = params[2] = params[3] = params[4] = null;
        }
        List<Network> rslts = Collections.unmodifiableList(
            jdbcTemplate.query(sql, networkBeanPropertyRowMapper, params));
        if (rslts.size() != 1) {
            throw new PersistencyServiceException(
                "Failed to update network[" + network.getId() + "]: " + network.getName());
        }
        return rslts.get(0);
    }

    @Override
    public int updateNetworks(String tenantId, Collection<String> accessibleResources, List<Network> networks)
        throws PersistencyServiceException {
        validateEditNetworks(tenantId, accessibleResources, networks);
        int[] updateCounts = jdbcTemplate.batchUpdate(NetworkSQL.getUpdateNetworkSQL(),
            new NetworkBatchUpdatePreparedStatementSetter(tenantId, networks, jsonbAttributeConverter,
                offsetDateTimeAttributeConverter));
        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public Network getNetworkById(String tenantId, Collection<String> accessibleResources, String networkId)
        throws PersistencyServiceException {
        String sql = NetworkSQL.getNetworkByIdOrSourceKeySQL(AttributeSelectEnum.FULL, "id");
        try {
            NetworkEntity rslt = jdbcTemplate.queryForObject(sql, networkBeanPropertyRowMapper, tenantId, networkId);
            if (rslt.getAssetId() != null) {
                Asset asset = assetPersistencyService.getAssetById(tenantId, accessibleResources, rslt.getAssetId());
                if (asset == null) {
                    throw new ObjectNotFoundException("Network " + networkId + " not found.");
                }
                rslt.setAsset(asset);
            }
            return rslt;
        } catch (EmptyResultDataAccessException ex) { // NOSONAR
            log.debug("Network not found with identifier: {}", networkId);
            return null;
        }
    }

    @Override
    public List<Network> getNetworksByIds(String tenantId, Collection<String> accessibleResources,
        Set<String> networkIds, AttributeSelectEnum selectEnum) {
        if (selectEnum == AttributeSelectEnum.FULL) {
            throw new IllegalArgumentException(
                "Network collection API does not support query for full network details");
        }
        String sql = NetworkSQL.getNetworksByIdsSQL(tenantId, accessibleResources, networkIds, selectEnum);
        return Collections.unmodifiableList(jdbcTemplate.query(sql, networkBeanPropertyRowMapper, tenantId));
    }

    @Override
    public Network getNetworkBySourceKey(String tenantId, String sourceKey) {
        // TODO: support full to include immediate children (nodes and sub-networks)
        String sql = NetworkSQL.getNetworkByIdOrSourceKeySQL(AttributeSelectEnum.ATTRIBUTES, "source_key");
        try {
            return jdbcTemplate.queryForObject(sql, networkBeanPropertyRowMapper, tenantId, sourceKey);
        } catch (EmptyResultDataAccessException ex) { // NOSONAR
            log.debug("Network not found with sourceKey: {}", sourceKey);
            return null;
        }
    }

    @Override
    public List<Network> getNetworksBySourceKeys(String tenantId, Set<String> sourceKeys,
        AttributeSelectEnum selectEnum) {
        if (selectEnum == AttributeSelectEnum.FULL) {
            throw new IllegalArgumentException(
                "Network collection API does not support query for full network details");
        }
        String sql = NetworkSQL.getNetworksBySourceKeysSQL(selectEnum, sourceKeys);
        return Collections.unmodifiableList(jdbcTemplate.query(sql, networkBeanPropertyRowMapper, tenantId));
    }

    @Override
    public Map<String, List<Network>> getNodesByAssetIds(String tenantId, Collection<String> accessibleResources,
        Set<String> assetIds) {
        List<Network> networks = Collections.unmodifiableList(jdbcTemplate
            .query(NetworkSQL.getNetworkNodesByAssetsSQL(tenantId, accessibleResources, assetIds),
                networkBeanPropertyRowMapper, tenantId));
        return networks.stream().collect(Collectors.groupingBy(Network::getAssetId));
    }

    @Override
    public Map<String, List<Network>> getNodesByAssetIdsForNetwork(String tenantId,
        Collection<String> accessibleResources, String networkId, Set<String> assetIds) {

        List<Network> networks = Collections.unmodifiableList(jdbcTemplate
            .query(NetworkSQL.getNetworkNodesByAssetsSQLForNetwork(tenantId, networkId, accessibleResources, assetIds),
                networkBeanPropertyRowMapper, tenantId));
        return networks.stream().collect(Collectors.groupingBy(Network::getAssetId));
    }

    @Override
    public List<Network> getNodesByNetworkId(String tenantId, Collection<String> accessibleResources, String networkId,
        NetworkPredicate queryPredicate) {
        return Collections.unmodifiableList(jdbcTemplate
            .query(NetworkSQL.getNodesByNetworkIdSQL(tenantId, accessibleResources, queryPredicate),
                hydratedNodeRowMapper, networkId));
    }

    @Override
    public List<Network> getRootNetworks(String tenantId, NetworkPredicate predicate) {
        if (predicate.getAttributeSelectEnum() == AttributeSelectEnum.FULL) {
            throw new IllegalArgumentException("Network collection API does not support full details query.");
        }
        StringBuilder query = new StringBuilder(NetworkSQL.getRootNetworksSQL(predicate));
        String filterPredicate = NetworkSQL.getFilterPredicate(predicate);
        query.append(StringUtils.isEmpty(filterPredicate) ? "" : " and " + filterPredicate);
        appendPagination(query, predicate);
        return Collections.unmodifiableList(
            jdbcTemplate.query(query.toString(), networkBeanPropertyRowMapper, tenantId));
    }

    @Override
    public List<Network> getNetworksByNode(String tenantId, NetworkPredicate predicate) {
        if (predicate.getAttributeSelectEnum() == AttributeSelectEnum.FULL) {
            throw new IllegalArgumentException("Network collection API does not support full details query.");
        }
        String assetInstanceTableAlias = "asset"; //Used in SQL queries and filter predicate clause
        StringBuilder parentNetworksOfNodeSql = new StringBuilder(
            NetworkSQL.getParentNetworksOfNodeSQL(assetInstanceTableAlias, tenantId));

        String filterPredicate = NetworkSQL.getFilterPredicate(predicate, assetInstanceTableAlias + ".");
        parentNetworksOfNodeSql.append(StringUtils.isEmpty(filterPredicate) ? "" : " and " + filterPredicate);

        StringBuilder query = new StringBuilder(
            NetworkSQL.getNetworksByNodeSQL(predicate, parentNetworksOfNodeSql.toString()));
        appendPagination(query, predicate);

        return Collections.unmodifiableList(jdbcTemplate.query(query.toString(), networkBeanPropertyRowMapper, tenantId));
    }

    private void appendPagination(StringBuilder builder, NetworkPredicate predicate) {
        if (predicate.getPageSize() > 0) {
            String[] values = predicate.getNextPageSortValues();
            if (values != null && values.length == 1) {
                builder.append(" and a.id > '").append(QueryUtils.escapeLiteral(values[0])) .append("' ");
            }
            builder.append(NetworkSQL.getOrderByAId());
            builder.append(QueryUtils.getPagination(predicate, false));
        }
    }

    @Override
    public int addAssetsToNetwork(String tenantId, Collection<String> accessibleResources, String parentNetworkId,
        List<Asset> childAssets) throws PersistencyServiceException {
        Validator.assertMatchingTenantId(tenantId,
            childAssets.stream().map(Asset::getTenantId).collect(Collectors.toSet()));
        validateNetworkExists(tenantId, accessibleResources, parentNetworkId);
        List<Network> assetNodes = childAssets.stream().map(a -> newNetworkNode(a)).collect(Collectors.toList());
        createNetworks(tenantId, accessibleResources, assetNodes);
        return addChildrenToNetwork(tenantId, accessibleResources, parentNetworkId, assetNodes);
    }

    @Override
    public int addChildrenToNetwork(String tenantId, Collection<String> accessibleResources, String parentNetworkId,
        List<Network> children) throws PersistencyServiceException {
        Validator.assertMatchingTenantId(tenantId,
            children.stream().map(Network::getTenantId).collect(Collectors.toSet()));
        validateNetworkExists(tenantId, accessibleResources, parentNetworkId);
        validateAccessibleAssets(tenantId, accessibleResources, children.stream().map(Network::getAssetId)
            .filter(Objects::nonNull).collect(Collectors.toSet()));
        List<NetworkHierarchy> networkHierarchies = newNetworkHierarchies(parentNetworkId, children);
        try {
            int[] updateCounts = jdbcTemplate.batchUpdate(NetworkSQL.getBatchCreateNetworkHierarchySQL(),
                new NetworkHierarchyBatchCreatePreparedStatementSetter(tenantId, networkHierarchies,
                    offsetDateTimeAttributeConverter));
            return Arrays.stream(updateCounts).sum();
        } catch (UncategorizedSQLException use) {
            log.error(use.getMessage(), use);
            String assetIds = StringUtils.substringBetween(use.getMessage(), "Asset [", "] is");
            throw new ObjectAlreadyExistsException(
                String.format("Object %s is already added to the network", assetIds));
        }
    }

    @Override
    public int createEdges(String tenantId, Collection<String> accessibleResources, List<Edge> edges)
        throws PersistencyServiceException {
        try {
            validateEdges(tenantId, accessibleResources, edges);
            int[] updateCounts = jdbcTemplate.batchUpdate(NetworkSQL.getBatchCreateEdgeSQL(),
                new EdgeBatchCreatePreparedStatementSetter(tenantId, edges, jsonbAttributeConverter,
                    offsetDateTimeAttributeConverter));
            return Arrays.stream(updateCounts).sum();
        } catch (DuplicateKeyException use) {
            log.error(use.getMessage(), use);
            throw new PersistencyServiceException("One or more edge(s) already exists in the network");
        }
    }

    @Override
    public Edge getNetworkEdgeById(String tenantId, Collection<String> accessibleResources, String parentNetworkId,
        String edgeId) {

        String sql = NetworkSQL.getEdgeByIdForParentNetworkSQL(tenantId, accessibleResources);
        try {
            return jdbcTemplate.queryForObject(sql, hydratedEdgeRowMapper, tenantId, parentNetworkId, edgeId);
        } catch (EmptyResultDataAccessException ex) {  // NOSONAR
            log.debug("Edge not found with identifier in network {}: {}", parentNetworkId, edgeId);
            return null;
        }
    }

    @Override
    public Edge getNetworkEdgeById(String tenantId, Collection<String> accessibleResources, String edgeId) {
        String sql = NetworkSQL.getEdgeByIdSQL(tenantId, accessibleResources);
        try {
            return jdbcTemplate.queryForObject(sql, edgeBeanPropertyRowMapper, tenantId, edgeId);
        } catch (EmptyResultDataAccessException ex) {  //NOSONAR
            log.debug("Edge not found with identifier in network {}: {}", edgeId);
            return null;
        }
    }

    @Override
    public int deleteEdgeById(String tenantId, Collection<String> accessibleResources, String edgeId)
        throws PersistencyServiceException {

        if (org.springframework.util.StringUtils.isEmpty(edgeId)) {
            throw new IllegalArgumentException("Edge ID cannot be null");
        }

        String deleteQuery = NetworkSQL.getDeleteEdgeByIdSQL(accessibleResources);
        int rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, edgeId);
        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("Edge does not exist or user does not have access to it." + edgeId);
        }
        return rowsDeleted;
    }

    @Override
    public List<Edge> getNetworkEdges(String tenantId, Collection<String> accessibleResources, String parentNetworkId,
        NetworkPredicate queryPredicate) {
        // TODO: handle different components, introduce object graph loader to handle the hydration
        String sql = NetworkSQL.getEdgesByParentNetworkIdSQL(tenantId, accessibleResources, queryPredicate);
        return Collections.unmodifiableList(jdbcTemplate.query(sql, hydratedEdgeRowMapper, tenantId, parentNetworkId));
    }

    @Override
    public int updateEdge(String tenantId, Collection<String> accessibleResources, Edge edge)
        throws PersistencyServiceException {
        return updateEdges(tenantId, accessibleResources, Collections.singletonList(edge));
    }

    @Override
    public int updateEdges(String tenantId, Collection<String> accessibleResources, List<Edge> edges)
        throws PersistencyServiceException {
        validateEdges(tenantId, accessibleResources, edges);
        int[] updateCounts = jdbcTemplate.batchUpdate(NetworkSQL.getUpdateEdgeSQL(),
            new EdgeBatchUpdatePreparedStatementSetter(tenantId, edges, jsonbAttributeConverter,
                offsetDateTimeAttributeConverter));
        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public List<Network> deleteNetworkById(String tenantId, Collection<String> accessibleResources, String networkId)
        throws PersistencyServiceException {

        List<Network> deletedNetworkList = new ArrayList<>();
        deleteNetworkById(tenantId, accessibleResources, networkId, deletedNetworkList);
        if (deletedNetworkList.isEmpty()) {
            throw new ObjectNotFoundException(String.format(NETWORK_DOES_NOT_EXIST, networkId));
        }
        return deletedNetworkList;
    }

    private void deleteNetworkById(String tenantId, Collection<String> accessibleResources, String networkId,
        List<Network> deletedNetworkList) {

        //TODO: Handle ACL
        //Default DELETE is RECURSIVE
        List<Edge> edges = getNetworkEdges(tenantId, accessibleResources, networkId, null);
        List<Network> nodes = getNodesByNetworkId(tenantId, accessibleResources, networkId, null);
        List<Network> assetNodes = nodes.stream().filter(node -> node.getAsset() != null).collect(Collectors.toList());
        List<Network> immediateSubnetworks = nodes.stream().filter(node -> node.getAsset() == null).collect(
            Collectors.toList());
        NetworkEntity networkEntity = new NetworkEntity();
        networkEntity.setNodes(assetNodes);
        networkEntity.setEdges(edges);
        networkEntity.setNetworks(immediateSubnetworks);
        immediateSubnetworks.forEach(network ->
            deleteNetworkById(tenantId, accessibleResources, network.getId(), deletedNetworkList));

        //Deletion of edges is taken care by DB cascade
        if (!nodes.isEmpty()) {
            Set<String> networkIds = nodes.stream().map(Network::getId).collect(Collectors.toSet());
            String deleteNodesSql = NetworkSQL.getDeleteNetworksSQL(networkIds);
            jdbcTemplate.update(deleteNodesSql, tenantId);
        }

        String networkDeleteSQL = NetworkSQL.getDeleteNetworkSQL() + SQLConstants.RETURNING_FULL;
        try {
            NetworkEntity deletedNetwork = jdbcTemplate.queryForObject(networkDeleteSQL, networkBeanPropertyRowMapper,
                tenantId, networkId);
            networkEntity.setName(deletedNetwork.getName());
            networkEntity.setSourceKey(deletedNetwork.getSourceKey());
            networkEntity.setId(deletedNetwork.getId());
            deletedNetworkList.add(networkEntity);
        } catch (EmptyResultDataAccessException ex) { // NOSONAR
            log.debug("Network not found with identifier: {}", networkId);
        }
    }

    @Override
    public int removeAssetsFromNetwork(String tenantId, Collection<String> accessibleResources, String parentNetworkId,
        Set<String> assetIds) throws PersistencyServiceException {
        if (assetIds.isEmpty()) {
            throw new IllegalArgumentException("AssetIds cannot be empty");
        }
        validateNetworkExists(tenantId, accessibleResources, parentNetworkId);

        Map<String, List<Network>> nodesMap = getNodesByAssetIdsForNetwork(tenantId, accessibleResources,
            parentNetworkId, assetIds);

        List<String> foundIDs = new ArrayList<>(nodesMap.keySet());
        List<String> nodesNotFound = new ArrayList<>(assetIds);
        nodesNotFound.removeAll(foundIDs);

        if (!nodesNotFound.isEmpty()) {
            throw new ObjectNotFoundException(
                String.format("Unable to find following Assets(s) in this network: %s", nodesNotFound.toString()));
        }

        Set<Network> nodesList = nodesMap.values().stream().flatMap(List::stream).collect(Collectors.toSet());
        Set<String> nodeIds = nodesList.stream().map(Network::getId).collect(Collectors.toSet());
        String deleteNodesSql = NetworkSQL.getDeleteNetworksSQL(nodeIds);
        return jdbcTemplate.update(deleteNodesSql, tenantId);
    }

    @Override
    public int removeChildrenFromNetwork(String tenantId, Collection<String> accessibleResources,
        String parentNetworkId, Set<String> networkIds) throws PersistencyServiceException {
        if (networkIds.isEmpty()) {
            throw new IllegalArgumentException("NetworkIds cannot be empty");
        }
        validateNetworkExists(tenantId, accessibleResources, parentNetworkId);
        validateNetworksExists(tenantId, accessibleResources, networkIds);

        String edgeSql = NetworkSQL.getDeletEdgeBySourceOrTargetId(networkIds);
        jdbcTemplate.update(edgeSql, tenantId);
        String sql = NetworkSQL.getDeleteNetworkHierarchySQL(networkIds);
        return jdbcTemplate.update(sql, tenantId, parentNetworkId);
    }

    private Network newNetworkNode(Asset asset) {
        String currentAuditor = entityAuditor.getCurrentAuditor();
        return NetworkEntity.builder().id(UUID.randomUUID().toString()).tenantId(asset.getTenantId()).createdBy(
            currentAuditor).lastModifiedBy(currentAuditor).assetId(asset.getId()).build();
    }

    private List<NetworkHierarchy> newNetworkHierarchies(String parentNetworkId, List<Network> childNetworks) {
        String currentAuditor = entityAuditor.getCurrentAuditor();
        return childNetworks.stream().map(x -> NetworkHierarchyEntity.builder().id(UUID.randomUUID().toString())
            .tenantId(x.getTenantId()).parentNetworkId(parentNetworkId).networkNodeId(x.getId()).createdBy(
                currentAuditor).lastModifiedBy(currentAuditor).build()).collect(Collectors.toList());
    }

    private void validateEditNetwork(String tenantId, Collection<String> accessibleResources, Network network)
        throws ObjectNotFoundException {
        Validator.assertMatchingTenantId(tenantId, network.getTenantId());
        if (StringUtils.isNotEmpty(network.getAssetId()) && QueryUtils.isNotUber(accessibleResources)
            && assetPersistencyService.getAssetById(tenantId, accessibleResources, network.getAssetId()) == null) {
            throw new ObjectNotFoundException("Network asset " + network.getAssetId() + " not found.");
        }
    }

    private void validateEditNetworks(String tenantId, Collection<String> accessibleResources, List<Network> networks)
        throws ObjectNotFoundException {
        Validator.assertMatchingTenantId(tenantId,
            networks.stream().map(Network::getTenantId).collect(Collectors.toSet()));
        validateAccessibleAssets(tenantId, accessibleResources, networks.stream().map(Network::getAssetId)
            .filter(Objects::nonNull).collect(Collectors.toSet()));
    }

    private void validateEdge(String tenantId, Collection<String> accessibleResources, Edge edge)
        throws PersistencyServiceException {
        validateEdges(tenantId, accessibleResources, Collections.singletonList(edge));
    }

    private void validateEdges(String tenantId, Collection<String> accessibleResources, List<Edge> edges)
        throws PersistencyServiceException {

        Set<String> tenantIdsToValidate = edges.stream().map(Edge::getTenantId).collect(Collectors.toSet());
        Set<String> assetIdsToValidate = edges.stream().map(Edge::getAssetId).filter(Objects::nonNull).collect(
            Collectors.toSet());
        Set<String> networkIdsToValidate = edges.stream().map(Edge::getSource).filter(Objects::nonNull).collect(
            Collectors.toSet());
        networkIdsToValidate.addAll(edges.stream().map(Edge::getTarget).filter(Objects::nonNull)
            .collect(Collectors.toSet()));

        Validator.assertMatchingTenantId(tenantId, tenantIdsToValidate);

        if (!CollectionUtils.isEmpty(assetIdsToValidate)) {
            // throws ObjectNotFoundException if some assets are not accessible
            assetPersistencyService.getAssetsByIds(tenantId, accessibleResources, assetIdsToValidate);
        }

        if (!CollectionUtils.isEmpty(networkIdsToValidate)) {
            List<Network> accessibleNetworks = getNetworksByIds(tenantId, accessibleResources, networkIdsToValidate,
                AttributeSelectEnum.ID);

            if (networkIdsToValidate.size() != accessibleNetworks.size()) {
                throw new ObjectNotFoundException("Failed to find all networks for the given edges.");
            }
        }
    }

    private void validateAccessibleAssets(String tenantId, Collection<String> accessibleResources, Set<String> assetIds)
        throws ObjectNotFoundException {
        if (QueryUtils.isNotUber(accessibleResources)) {
            // this call throws ObjectNotFoundException if any of the assetIds cannot be found, i.e., not accessible
            assetPersistencyService.getAssetsByIds(tenantId, accessibleResources, assetIds);
        }
    }

    private void validateNetworkExists(String tenantId, Collection<String> accessibleResources, String parentNetworkId)
        throws PersistencyServiceException {
        Network network = getNetworkById(tenantId, accessibleResources, parentNetworkId);
        if (network == null) {
            throw new ObjectNotFoundException("Failed to find an existing parent network: " + parentNetworkId);
        }
    }

    private void validateNetworksExists(String tenantId, Collection<String> accessibleResources, Set<String> networkIDs)
        throws PersistencyServiceException {

        List<Network> foundNetworks = getNetworksByIds(tenantId, accessibleResources, networkIDs,
            AttributeSelectEnum.ID);
        List<String> foundIDs = foundNetworks.stream().map(Network::getId).collect(Collectors.toList());
        List<String> nodesNotFound = new ArrayList<>(networkIDs);
        nodesNotFound.removeAll(foundIDs);

        if (!nodesNotFound.isEmpty()) {
            throw new ObjectNotFoundException(
                String.format("Unable to find following network(s): %s", nodesNotFound.toString()));
        }
    }
}
