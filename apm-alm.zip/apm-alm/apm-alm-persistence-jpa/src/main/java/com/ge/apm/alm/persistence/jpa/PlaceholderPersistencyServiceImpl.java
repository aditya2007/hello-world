/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.PlaceholderGroupTagType;
import com.ge.apm.alm.model.PlaceholderTagType;
import com.ge.apm.alm.model.PlaceholderTemplate;
import com.ge.apm.alm.model.PlaceholderType;
import com.ge.apm.alm.model.query.PlaceholderPredicate;
import com.ge.apm.alm.persistence.PlaceholderGroupTagTypePersistencyService;
import com.ge.apm.alm.persistence.PlaceholderPersistencyService;
import com.ge.apm.alm.persistence.PlaceholderTagTypePersistencyService;
import com.ge.apm.alm.persistence.PlaceholderTemplatePersistencyService;
import com.ge.apm.alm.persistence.PlaceholderTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderEntity;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderGroupTagTypeEntity;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderTagTypeEntity;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderTemplateEntity;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderTypeEntity;
import com.ge.apm.alm.persistence.jpa.repository.PlaceholderRepository;
import com.ge.apm.alm.persistence.jpa.sql.PlaceholderSQL;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;

import static com.ge.apm.alm.persistence.jpa.sql.SQLConstants.AND;
import static com.ge.apm.alm.persistence.jpa.utils.Validator.assertMatchingTenantId;

@Service
@Slf4j
@Transactional
public class PlaceholderPersistencyServiceImpl implements PlaceholderPersistencyService {

    @Autowired
    private DataSource dataSource;
    @Autowired
    private PlaceholderRepository placeholderRepository;
    @Autowired
    private ConversionService conversionService;
    @Autowired
    private JsonbAttributeConverter jsonbAttributeConverter;
    @Autowired
    private PlaceholderTypePersistencyService placeholderTypePersistencyService;
    @Autowired
    private PlaceholderTemplatePersistencyService placeholderTemplatePersistencyService;
    @Autowired
    private PlaceholderTagTypePersistencyService placeholderTagTypePersistencyService;
    @Autowired
    private PlaceholderGroupTagTypePersistencyService placeholderGroupTagTypePersistencyService;

    private EntityBeanPropertyRowMapper<PlaceholderEntity> placeholderBeanPropertyRowMapper;
    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initializeConvertionService() {
        placeholderBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(PlaceholderEntity.class, conversionService);
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public Placeholder createPlaceholder(String tenantId, String templateId, Placeholder placeholder) {
        assertMatchingTenantId(tenantId, placeholder.getTenantId());
        assertMatchingTemplateId(templateId, placeholder.getTemplateId());
        validatePlaceholder(placeholder);

        PlaceholderEntity placeholderEntity = toPlaceholderEntity(tenantId, templateId, placeholder, true);
        return placeholderRepository.saveAndFlush(placeholderEntity);
    }

    @Override
    public int createPlaceholders(String tenantId, String templateId, List<Placeholder> placeholders) {
        if (CollectionUtils.isEmpty(placeholders)) {
            return 0;
        }

        List<PlaceholderEntity> placeholderEntities = new ArrayList<>();
        placeholders.stream().forEach(placeholder -> {
            assertMatchingTenantId(tenantId, placeholder.getTenantId());
            assertMatchingTemplateId(templateId, placeholder.getTemplateId());
            placeholderEntities.add(toPlaceholderEntity(tenantId, templateId, placeholder, true));
        });

        int[] updateCounts = jdbcTemplate.batchUpdate(PlaceholderSQL.getBatchCreateSQL(),
            new PlaceholderBatchCreatePreparedStatementSetter(tenantId, placeholderEntities,
                jsonbAttributeConverter));

        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public Placeholder updatePlaceholder(String tenantId, String templateId, Placeholder placeholder) {
        assertMatchingTenantId(tenantId, placeholder.getTenantId());
        assertMatchingTemplateId(templateId, placeholder.getTemplateId());

        PlaceholderEntity entity = toPlaceholderEntity(tenantId, templateId, placeholder, false);
        return placeholderRepository.saveAndFlush(entity);
    }

    @Override
    public int updatePlaceholders(String tenantId, String templateId, List<Placeholder> placeholders) {
        if (CollectionUtils.isEmpty(placeholders)) {
            return 0;
        }

        int updateCounts = 0;
        for (Placeholder placeholder : placeholders) {
            updatePlaceholder(tenantId, templateId, placeholder);
            updateCounts++;
        }
        return updateCounts;
    }

    @Override
    public int deletePlaceholderById(String tenantId, String id) throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderSQL.getDeletePlaceholderByIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, id);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                "Placeholder has references to it. Hence cannot be deleted", ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("id:" + id);
        }
        return rowsDeleted;
    }

    @Override
    public Placeholder getPlaceholderById(String tenantId, String id) {
        try {
            String query = PlaceholderSQL.getSelectSingleObjectById(AttributeSelectEnum.FULL);
            PlaceholderEntity entity = jdbcTemplate.queryForObject(query, placeholderBeanPropertyRowMapper,
                tenantId, id);
            if (entity != null) {
                setAssociations(tenantId, entity);
                setTagAssociations(tenantId, entity);
            }
            return entity;
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("Placeholder not found with identifier: {}", id);
            return null;
        }
    }

    @Override
    public Placeholder getPlaceholderForEventsById(String tenantId, String id) {
        try {
            String query = PlaceholderSQL.getSelectSingleObjectById(AttributeSelectEnum.FULL);
            PlaceholderEntity entity = jdbcTemplate.queryForObject(query, placeholderBeanPropertyRowMapper,
                    tenantId, id);
            return entity;
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("Placeholder not found with identifier: {}", id);
            return null;
        }
    }

    @Override
    public Placeholder getPlaceholderByTemplateIdAndPartPositionNumber(String tenantId, String templateId,
        String partPositionNumber) {
        try {
            String query = PlaceholderSQL.getSelectSingleObjectByTemplateIdAndPpn(AttributeSelectEnum.FULL);
            PlaceholderEntity entity = jdbcTemplate.queryForObject(query, placeholderBeanPropertyRowMapper,
                tenantId, templateId, partPositionNumber);
            if (entity != null) {
                setAssociations(tenantId, entity);
                setTagAssociations(tenantId, entity);
            }
            return entity;
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("Placeholder not found with templateId {} and part position number {}", templateId,
                partPositionNumber);
            return null;
        }
    }

    @Override
    public List<Placeholder> getPlaceholdersByTemplateId(String tenantId, String templateId) {
        String query = PlaceholderSQL.getSelectCollectionObjectsByTemplateId(AttributeSelectEnum.FULL);
        List<PlaceholderEntity> entities = jdbcTemplate.query(query, placeholderBeanPropertyRowMapper,
            tenantId, templateId);
        if (!CollectionUtils.isEmpty(entities)) {
            setAssociations(tenantId, entities);
            setTagAssociations(tenantId, entities);
        }
        return Collections.unmodifiableList(entities);
    }

    @Override
    public List<Placeholder> getPlaceholders(String tenantId, PlaceholderPredicate queryPredicate) {
        String filterPredicate = PlaceholderSQL.getFilterPredicate(queryPredicate);
        String query = PlaceholderSQL.getSelectCollectionObjects(queryPredicate.getAttributeSelectEnum())
            + filterPredicate;

        String greaterThan = QueryUtils.getNextPageSortKeyFilter(queryPredicate);
        if (!StringUtils.isEmpty(greaterThan)) {
            query += AND + greaterThan;
        }
        query += QueryUtils.getPagination(queryPredicate);

        log.debug("****" + queryPredicate.getAttributeSelectEnum() + ", query: " + query);

        final String partPositionNumber = queryPredicate.getPartPositionNumber();
        final String templateId = queryPredicate.getTemplateId();
        final String parentId = queryPredicate.getParentId();

        boolean isPpnWildCard = !StringUtils.isEmpty(partPositionNumber) && QueryUtils.hasWildcard(partPositionNumber);

        List<PlaceholderEntity> placeholders;
        if (isPpnWildCard) {
            placeholders = searchPlaceholdersWithWildCard(tenantId, query, partPositionNumber, templateId, parentId);
        } else {
            placeholders = searchPlaceholders(tenantId, query, partPositionNumber, templateId, parentId);
        }

        setAssociations(tenantId, placeholders);
        setTagAssociations(tenantId, placeholders);

        return Collections.unmodifiableList(placeholders);
    }

    private List<PlaceholderEntity> searchPlaceholders(String tenantId, String query, String partPositionNumber,
        String templateId, String parentId) {
        boolean isPpnExistFlag = !StringUtils.isEmpty(partPositionNumber);
        boolean isTemplateIdExistFlag = !StringUtils.isEmpty(templateId);
        boolean isParentIdExistFlag = !StringUtils.isEmpty(parentId);

        List<PlaceholderEntity> placeholders;
        if (isPpnExistFlag) {
            placeholders = searchWithExistingPpn(tenantId, query, partPositionNumber, templateId, parentId,
                isTemplateIdExistFlag, isParentIdExistFlag);
        } else {
            placeholders = searchWithoutExistingPpn(tenantId, query, templateId, parentId, isTemplateIdExistFlag,
                isParentIdExistFlag);
        }
        return placeholders == null ? Collections.emptyList() : Collections.unmodifiableList(placeholders);
    }

    private List<PlaceholderEntity> searchWithExistingPpn(String tenantId, String query, String partPositionNumber,
        String templateId, String parentId, boolean isTemplateIdExistFlag, boolean isParentIdExistFlag) {
        if (isTemplateIdExistFlag && isParentIdExistFlag) {
            return jdbcTemplate.query(query, placeholderBeanPropertyRowMapper, tenantId, partPositionNumber, templateId,
                parentId);
        } else if (isTemplateIdExistFlag) {
            return jdbcTemplate.query(query, placeholderBeanPropertyRowMapper, tenantId, partPositionNumber,
                templateId);
        } else if (isParentIdExistFlag) {
            return jdbcTemplate.query(query, placeholderBeanPropertyRowMapper, tenantId, partPositionNumber, parentId);
        }
        return Collections.emptyList();
    }

    private List<PlaceholderEntity> searchWithoutExistingPpn(String tenantId, String query, String templateId,
        String parentId, boolean isTemplateIdExistFlag, boolean isParentIdExistFlag) {
        if (isTemplateIdExistFlag && isParentIdExistFlag) {
            return jdbcTemplate.query(query, placeholderBeanPropertyRowMapper, tenantId, templateId, parentId);
        } else if (isTemplateIdExistFlag) {
            return jdbcTemplate.query(query, placeholderBeanPropertyRowMapper, tenantId, templateId);
        } else if (isParentIdExistFlag) {
            return jdbcTemplate.query(query, placeholderBeanPropertyRowMapper, tenantId, parentId);
        }
        return Collections.emptyList();
    }

    private List<PlaceholderEntity> searchPlaceholdersWithWildCard(String tenantId, String query,
        String partPositionNumber, String templateId, String parentId) {
        boolean isPpnExistFlag = !StringUtils.isEmpty(partPositionNumber) && QueryUtils.hasWildcard(partPositionNumber);
        boolean isTemplateIdExistFlag = !StringUtils.isEmpty(templateId);
        boolean isParentIdExistFlag = !StringUtils.isEmpty(parentId);

        if (isPpnExistFlag && isTemplateIdExistFlag && isParentIdExistFlag) {
            return Collections.unmodifiableList(jdbcTemplate.query(query, placeholderBeanPropertyRowMapper,
                tenantId, templateId, parentId));
        } else if (isPpnExistFlag && isParentIdExistFlag) {
            return Collections.unmodifiableList(jdbcTemplate.query(query, placeholderBeanPropertyRowMapper,
                tenantId, parentId));
        } else if (isPpnExistFlag && isTemplateIdExistFlag || isTemplateIdExistFlag) {
            return Collections.unmodifiableList(jdbcTemplate.query(query, placeholderBeanPropertyRowMapper,
                tenantId, templateId));
        } else {
            return Collections.unmodifiableList(jdbcTemplate.query(query, placeholderBeanPropertyRowMapper,
                tenantId));
        }
    }

    private void validatePlaceholder(Placeholder placeholder) {
        StringBuilder builder = new StringBuilder();
        if (StringUtils.isEmpty(placeholder.getId())) {
            builder.append("Placeholder Id is empty. ");
        }
        if (StringUtils.isEmpty(placeholder.getSourceKey())) {
            builder.append("Placeholder SourceKey is empty. ");
        }
        if (StringUtils.isEmpty(placeholder.getPartPositionNumber())) {
            builder.append("Placeholder partPositionNumber is empty. ");
        }
        if (StringUtils.isEmpty(placeholder.getTemplateId())) {
            builder.append("Placeholder templateId State is empty. ");
        }

        if (!builder.toString().isEmpty()) {
            throw new IllegalArgumentException(builder.toString());
        }
    }

    private void assertMatchingTemplateId(String templateId, String... objTemplateIds) {
        if (Arrays.stream(objTemplateIds).anyMatch(objTemplateId ->
            objTemplateId != null && !templateId.equals(objTemplateId))) {
            throw new IllegalArgumentException("Template ID mismatch.");
        }
    }

    private void setAssociations(String tenantId, PlaceholderEntity placeholderEntity) {
        if (placeholderEntity == null) {
            return;
        }

        List<PlaceholderType> placeholderTypes = placeholderTypePersistencyService.getPlaceholderTypes(tenantId,
            placeholderEntity.getId());
        if (!CollectionUtils.isEmpty(placeholderTypes)) {
            List<PlaceholderTypeEntity> placeholderTypeEntities = new ArrayList<>();
            for (PlaceholderType placeholderType : placeholderTypes) {
                placeholderTypeEntities.add(toPlaceholderTypeEntity(tenantId, placeholderType));
            }
            placeholderEntity.setPlaceholderTypes(placeholderTypeEntities);
        }

        PlaceholderTemplate placeholderTemplate = placeholderTemplatePersistencyService.
            getPlaceholderTemplateByPlaceholderId(tenantId, placeholderEntity.getId());
        if (placeholderTemplate != null) {
            placeholderEntity.setPlaceholderTemplates(toPlaceholderTemplateEntity(tenantId, placeholderTemplate));
        }
    }

    private void setAssociations(String tenantId, List<PlaceholderEntity> placeholderEntities) {
        if (CollectionUtils.isEmpty(placeholderEntities)) {
            return;
        }

        Set<String> idSet = new HashSet<>();
        Map<String, List<PlaceholderTypeEntity>> idPlaceholderTypeEntityMap = new HashMap<>();
        Map<String, PlaceholderTemplateEntity> idPlaceholderTemplateMap = new HashMap<>();

        placeholderEntities.stream().forEach(placeholderEntity -> {
            idSet.add(placeholderEntity.getId());
            idPlaceholderTypeEntityMap.put(placeholderEntity.getId(), new ArrayList<>());
        });

        //retrieve asset classifications from placeholder_type table
        List<String> placeholderIds = idSet.stream().collect(Collectors.toList());
        List<PlaceholderType> placeholderTypes = placeholderTypePersistencyService.getPlaceholderTypes(tenantId,
            placeholderIds);
        if (!CollectionUtils.isEmpty(placeholderTypes)) {
            for (PlaceholderType placeholderType : placeholderTypes) {
                PlaceholderTypeEntity placeholderTypeEntity = toPlaceholderTypeEntity(tenantId, placeholderType);
                idPlaceholderTypeEntityMap.get(placeholderType.getPlaceholderId()).add(placeholderTypeEntity);
            }
        }

        //retrieve sub-template from placeholder_template table
        List<PlaceholderTemplate> placeholderTemplates = placeholderTemplatePersistencyService.
            getPlaceholderTemplates(tenantId, placeholderIds);
        if (!placeholderTemplates.isEmpty()) {
            placeholderTemplates.stream().forEach(placeholderTemplate -> {
                    PlaceholderTemplateEntity entity = toPlaceholderTemplateEntity(tenantId, placeholderTemplate);
                    idPlaceholderTemplateMap.put(placeholderTemplate.getPlaceholderId(), entity);
                }
            );
        }

        for (PlaceholderEntity placeholderEntity : placeholderEntities) {
            String placeholderId = placeholderEntity.getId();
            placeholderEntity.setPlaceholderTypes(idPlaceholderTypeEntityMap.get(placeholderId));
            placeholderEntity.setPlaceholderTemplates(idPlaceholderTemplateMap.get(placeholderId));
        }
    }

    private void setTagAssociations(String tenantId, PlaceholderEntity placeholderEntity) {
        if (placeholderEntity == null) {
            return;
        }

        List<PlaceholderTagType> placeholderTagTypes = placeholderTagTypePersistencyService
            .getPlaceholderTagTypeByPlaceholderId(tenantId, placeholderEntity.getId());
        if (!CollectionUtils.isEmpty(placeholderTagTypes)) {
            List<PlaceholderTagTypeEntity> placeholderTagTypeEntities = new ArrayList<>();
            for (PlaceholderTagType placeholderTagType : placeholderTagTypes) {
                placeholderTagTypeEntities.add(toPlaceholderTagTypeEntity(tenantId, placeholderTagType));
            }
            placeholderEntity.setPlaceholderTagTypes(placeholderTagTypeEntities);
        }

        List<PlaceholderGroupTagType> groupTagTypes = placeholderGroupTagTypePersistencyService.
            getPlaceholderGroupTagTypeByPlaceholderId(tenantId, placeholderEntity.getId());
        if (groupTagTypes != null) {
            List<PlaceholderGroupTagTypeEntity> groupTagTypeList = new ArrayList<>();
            groupTagTypes.stream()
                .forEach(groupTagType -> groupTagTypeList.add(toPlaceholderGroupTagTypeEntity(tenantId, groupTagType)));
            placeholderEntity.setPlaceholderGroupTagTypes(groupTagTypeList);
        }
    }

    private void setTagAssociations(String tenantId, List<PlaceholderEntity> placeholderEntities) {
        if (CollectionUtils.isEmpty(placeholderEntities)) {
            return;
        }

        Set<String> idSet = new HashSet<>();
        Map<String, List<PlaceholderTagTypeEntity>> idPlaceholderTagTypeEntityMap = new HashMap<>();
        Map<String, List<PlaceholderGroupTagTypeEntity>> idPlaceholderGroupTagTypeEnityMap = new HashMap<>();

        placeholderEntities.stream().forEach(entity -> {
            idSet.add(entity.getId());
            idPlaceholderTagTypeEntityMap.put(entity.getId(), new ArrayList<>());
            idPlaceholderGroupTagTypeEnityMap.put(entity.getId(), new ArrayList<>());
        });

        //retrieve tag classification from placeholder_tag_type table
        List<String> placeholderIds = idSet.stream().collect(Collectors.toList());
        List<PlaceholderTagType> placeholderTagTypes = placeholderTagTypePersistencyService
            .getPlaceholderTagTypeByPlaceholderIds(tenantId, placeholderIds);
        if (!CollectionUtils.isEmpty(placeholderTagTypes)) {
            for (PlaceholderTagType placeholderTagType : placeholderTagTypes) {
                PlaceholderTagTypeEntity entity = toPlaceholderTagTypeEntity(tenantId, placeholderTagType);
                idPlaceholderTagTypeEntityMap.get(placeholderTagType.getPlaceholderId()).add(entity);
            }
        }

        //retrieve group tag classifications from placeholder_group_tag_type table
        List<PlaceholderGroupTagType> placeholderGroupTagTypes = placeholderGroupTagTypePersistencyService
            .getPlaceholderGroupTagTypeByPlaceholderIds(tenantId, placeholderIds);
        if (!CollectionUtils.isEmpty(placeholderGroupTagTypes)) {
            for (PlaceholderGroupTagType placeholderGroupTagType : placeholderGroupTagTypes) {
                PlaceholderGroupTagTypeEntity entity = toPlaceholderGroupTagTypeEntity(tenantId,
                    placeholderGroupTagType);
                idPlaceholderGroupTagTypeEnityMap.get(placeholderGroupTagType.getPlaceholderId()).add(entity);
            }
        }

        for (PlaceholderEntity placeholderEntity : placeholderEntities) {
            String placeholderId = placeholderEntity.getId();
            placeholderEntity.setPlaceholderTagTypes(idPlaceholderTagTypeEntityMap.get(placeholderId));
            placeholderEntity.setPlaceholderGroupTagTypes(idPlaceholderGroupTagTypeEnityMap.get(placeholderId));
        }
    }

    private PlaceholderEntity toPlaceholderEntity(String tenantId, String templateId, Placeholder placeholder,
        boolean isAdd) {
        PlaceholderEntity entity = new PlaceholderEntity();
        entity.setTenantId(tenantId);
        entity.setId(placeholder.getId());
        entity.setSourceKey(placeholder.getSourceKey());
        entity.setName(placeholder.getName());
        entity.setDescription(placeholder.getDescription());
        entity.setTemplateId(templateId);
        entity.setParentId(placeholder.getParentId());
        entity.setPartPositionNumber(placeholder.getPartPositionNumber());
        entity.setAttributes(placeholder.getAttributes());
        if (isAdd) {
            entity.setCreatedBy(placeholder.getCreatedBy());
        }
        entity.setLastModifiedBy(placeholder.getLastModifiedBy());
        return entity;
    }

    private PlaceholderTypeEntity toPlaceholderTypeEntity(String tenantId, PlaceholderType placeholderType) {
        PlaceholderTypeEntity entity = new PlaceholderTypeEntity();
        entity.setId(placeholderType.getId());
        entity.setTenantId(tenantId);
        entity.setPlaceholderId(placeholderType.getPlaceholderId());
        entity.setTypeId(placeholderType.getTypeId());
        entity.setStatus(placeholderType.getStatus());
        entity.setPrimary(placeholderType.getPrimary());
        entity.setCreatedBy(placeholderType.getCreatedBy());
        entity.setCreatedDate(placeholderType.getCreatedDate());
        entity.setLastModifiedBy(placeholderType.getLastModifiedBy());
        entity.setLastModifiedDate(placeholderType.getLastModifiedDate());
        return entity;
    }

    private PlaceholderTemplateEntity toPlaceholderTemplateEntity(String tenantId,
        PlaceholderTemplate placeholderTemplate) {
        PlaceholderTemplateEntity entity = new PlaceholderTemplateEntity();
        entity.setId(placeholderTemplate.getId());
        entity.setTenantId(tenantId);
        entity.setPlaceholderId(placeholderTemplate.getPlaceholderId());
        entity.setTemplateId(placeholderTemplate.getTemplateId());
        entity.setStatus(placeholderTemplate.getStatus());
        entity.setCreatedBy(placeholderTemplate.getCreatedBy());
        entity.setCreatedDate(placeholderTemplate.getCreatedDate());
        entity.setLastModifiedBy(placeholderTemplate.getLastModifiedBy());
        entity.setLastModifiedDate(placeholderTemplate.getLastModifiedDate());
        return entity;
    }

    private PlaceholderTagTypeEntity toPlaceholderTagTypeEntity(String tenantId,
        PlaceholderTagType placeholderTagType) {
        PlaceholderTagTypeEntity entity = new PlaceholderTagTypeEntity();
        entity.setId(placeholderTagType.getId());
        entity.setTenantId(tenantId);
        entity.setPlaceholderId(placeholderTagType.getPlaceholderId());
        entity.setTagTypeId(placeholderTagType.getTagTypeId());
        entity.setCategory(placeholderTagType.getCategory());
        entity.setExpressions(placeholderTagType.getExpressions());
        entity.setCreatedBy(placeholderTagType.getCreatedBy());
        entity.setCreatedDate(placeholderTagType.getCreatedDate());
        entity.setLastModifiedBy(placeholderTagType.getLastModifiedBy());
        entity.setLastModifiedDate(placeholderTagType.getLastModifiedDate());
        return entity;
    }

    private PlaceholderGroupTagTypeEntity toPlaceholderGroupTagTypeEntity(String tenantId,
        PlaceholderGroupTagType placeholderGroupTagType) {
        PlaceholderGroupTagTypeEntity entity = new PlaceholderGroupTagTypeEntity();
        entity.setId(placeholderGroupTagType.getId());
        entity.setTenantId(tenantId);
        entity.setPlaceholderId(placeholderGroupTagType.getPlaceholderId());
        entity.setGroupId(placeholderGroupTagType.getGroupId());
        entity.setCategory(placeholderGroupTagType.getCategory());
        entity.setCreatedBy(placeholderGroupTagType.getCreatedBy());
        entity.setCreatedDate(placeholderGroupTagType.getCreatedDate());
        entity.setLastModifiedBy(placeholderGroupTagType.getLastModifiedBy());
        entity.setLastModifiedDate(placeholderGroupTagType.getLastModifiedDate());
        return entity;
    }
}
