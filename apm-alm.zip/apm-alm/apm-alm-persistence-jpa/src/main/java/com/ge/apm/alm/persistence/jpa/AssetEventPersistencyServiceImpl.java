/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.ConversionService;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.EventStatus;
import com.ge.apm.alm.model.AssetEvent.EventsJobType;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.AssetEventEntity;
import com.ge.apm.alm.persistence.jpa.repository.AssetEventRepository;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;

@Slf4j
@Service
@Transactional
public class AssetEventPersistencyServiceImpl implements AssetEventPersistencyService {

    private static final String UPDATE_PENDING_EVENTS =
            "UPDATE apm_alm.asset_event SET job_start_date = NOW() WHERE tenant_object_id IN "
                + "(SELECT a.tenant_object_id FROM apm_alm.asset_event a, "
                + "(SELECT DISTINCT tenant_object_id FROM apm_alm.asset_event WHERE tenant_object_id NOT IN "
                + "(SELECT DISTINCT tenant_object_id FROM apm_alm.asset_event WHERE "
                + "(job_start_date IS NOT NULL) AND "
                + "(job_start_date >= (NOW() - INTERVAL ''{0}''))) "
                + "LIMIT ?) AS b WHERE (a.tenant_object_id = b.tenant_object_id)) RETURNING *";

    public static final String EVENTS_CLEANUP_QUERY =
            "DELETE from apm_alm.asset_event where id in("
                + "select id from apm_alm.asset_event where ( "
                + "eventhub_pub_status = ''{0}'' "
                + "AND audit_pub_status = ''{0}'') "
                + "OR (created_date <= (NOW() - INTERVAL ''{1}'')) "
                + "FOR UPDATE SKIP LOCKED LIMIT ?)";

    public static final String EVENTS_CLEANUP_QUERY_OLD_V =
            "DELETE from apm_alm.asset_event where id in("
                    + "select id from apm_alm.asset_event where ( "
                    + "eventhub_pub_status = ''{0}'' "
                    + "AND audit_pub_status = ''{0}'') "
                    + "OR (created_date <= (NOW() - INTERVAL ''{1}'')) and "
                    + "pg_try_advisory_xact_lock(1) FOR UPDATE LIMIT ?)";

    public static final String GET_PENDING_EVENTS_FOR_EVENTHUB =
        "UPDATE apm_alm.asset_event a SET eventhub_pub_status = ''{0}'', eventhub_job_start_date = now() "
            + "FROM (SELECT id FROM apm_alm.asset_event e WHERE e.eventhub_pub_status = ''{1}'' "
            + "or (e.created_date >= (NOW() - INTERVAL ''{3}'') and e.eventhub_pub_status=''{0}'' "
            + "and e.eventhub_job_start_date <= (NOW() - INTERVAL ''{2}'')) "
            + "ORDER BY e.id FOR UPDATE SKIP LOCKED LIMIT ?) upd where upd.id=a.id returning *";

    public static final String GET_PENDING_EVENTS_FOR_EVENTHUB_OLD_V =
            "UPDATE apm_alm.asset_event a SET eventhub_pub_status = ''{0}'', eventhub_job_start_date = now() "
                    + "FROM (SELECT id FROM apm_alm.asset_event e WHERE e.eventhub_pub_status = ''{1}'' "
                    + "or (e.created_date >= (NOW() - INTERVAL ''{3}'') and e.eventhub_pub_status=''{0}'' "
                    + "and e.eventhub_job_start_date <= (NOW() - INTERVAL ''{2}'')) and "
                    + "pg_try_advisory_xact_lock(1) "
                    + "ORDER BY e.id FOR UPDATE LIMIT ?) upd where upd.id=a.id returning *";

    public static final String GET_PENDING_EVENTS_FOR_AUDITLOG =
        "UPDATE apm_alm.asset_event a SET audit_pub_status = ''{0}'', audit_job_start_date = now() "
            + "FROM (SELECT id FROM apm_alm.asset_event e WHERE e.audit_pub_status = ''{1}'' "
            + "or (e.created_date >= (NOW() - INTERVAL ''{3}'') and "
            + "e.audit_pub_status=''{0}'' and e.audit_job_start_date <= (NOW() - INTERVAL ''{2}'')) "
            + "ORDER BY e.id FOR UPDATE SKIP LOCKED LIMIT ?) upd where upd.id=a.id returning *";

    public static final String GET_PENDING_EVENTS_FOR_AUDITLOG_OLD_V =
            "UPDATE apm_alm.asset_event a SET audit_pub_status = ''{0}'', audit_job_start_date = now() "
                    + "FROM (SELECT id FROM apm_alm.asset_event e WHERE e.audit_pub_status = ''{1}'' "
                    + "or (e.created_date >= (NOW() - INTERVAL ''{3}'') and "
                    + "e.audit_pub_status=''{0}'' and e.audit_job_start_date <= (NOW() - INTERVAL ''{2}'')) and "
                    + "pg_try_advisory_xact_lock(1) "
                    + "ORDER BY e.id FOR UPDATE LIMIT ?) upd where upd.id=a.id returning *";

    public static final String GET_PENDING_EVENTS_FOR_PREDIX =
        "UPDATE apm_alm.asset_event a SET predix_pub_status = ''{0}'', job_start_date = now() "
            + "FROM (SELECT * FROM apm_alm.asset_event e WHERE e.predix_pub_status = ''{1}'' "
            + "or (e.predix_pub_status=''{0}'' and e.job_start_date <= (NOW() - INTERVAL ''{2}'')) and "
            + "pg_try_advisory_xact_lock(1) "
            + "ORDER BY e.tenant_object_id FOR UPDATE SKIP LOCKED LIMIT ?) upd where upd.id=a.id returning *";

    public static final String GET_PENDING_EVENTS_FOR_PREDIX_OLD_V =
            "UPDATE apm_alm.asset_event a SET predix_pub_status = ''{0}'', job_start_date = now() "
                    + "FROM (SELECT * FROM apm_alm.asset_event e WHERE e.predix_pub_status = ''{1}'' "
                    + "or (e.predix_pub_status=''{0}'' and e.job_start_date <= (NOW() - INTERVAL ''{2}'')) and "
                    + "pg_try_advisory_xact_lock(1) "
                    + "ORDER BY e.tenant_object_id FOR UPDATE LIMIT ?) upd where upd.id=a.id returning *";

    private static final String WHERE_CLAUSE = " WHERE id in("
            + "SELECT id from apm_alm.asset_event where id in(?) FOR UPDATE SKIP LOCKED)";
    private static final String WHERE_CLAUSE_OLD_V = " WHERE id in("
            + "SELECT id from apm_alm.asset_event where id in(?) FOR UPDATE)";
    private static final String EVENTHUB_STATUS = "eventhub_pub_status";
    private static final String AUDIT_STATUS = "audit_pub_status";
    private static final String PREDIX_STATUS = "predix_pub_status";
    private static final Map<AssetEvent.EventsJobType, String> updateEventsQueries =
            new EnumMap<>(AssetEvent.EventsJobType.class);
    private static final String MILLI_SECONDS = " milliseconds";

    @Value("${apm.asset.cleanup.job.size:1000}")
    private long batchSize;

    static {
        StringBuilder updateEventQry = new StringBuilder();
        updateEventQry.append("UPDATE apm_alm.asset_event set last_modified_date = now(), ")
                                                    .append("{0} = ?");
        updateEventsQueries.put(AssetEvent.EventsJobType.EVENTHUB,
                MessageFormat.format(updateEventQry.toString(),EVENTHUB_STATUS));
        updateEventsQueries.put(AssetEvent.EventsJobType.AUDIT,
                MessageFormat.format(updateEventQry.toString(),AUDIT_STATUS));
        updateEventsQueries.put(AssetEvent.EventsJobType.PREDIX,
                MessageFormat.format(updateEventQry.toString(),PREDIX_STATUS));
    }

    @Autowired
    private AssetEventRepository eventRepo;
    @Autowired
    private ConversionService conversionService;
    @Autowired
    private DataSource dataSource;
    private JdbcTemplate jdbc;
    private EntityBeanPropertyRowMapper<AssetEventEntity> mapper;
    private String dataBaseVersion;


    @PostConstruct
    public void initializeConvertionService() {
        mapper = new EntityBeanPropertyRowMapper<>(AssetEventEntity.class, conversionService);
        jdbc = new JdbcTemplate(dataSource);
        Connection connection = null;
        try {
            connection = DataSourceUtils.getConnection(dataSource);
            dataBaseVersion = connection.getMetaData().getDatabaseProductVersion();
            log.debug("Database Version ::: {} " + dataBaseVersion );

        } catch (SQLException e) {
            log.error("SQLException while getting database version ", e);
        } finally {
            if (connection != null) {
                DataSourceUtils.releaseConnection(connection, dataSource);
            }
        }
    }

    private boolean isOldDBVersion() {
        return Objects.nonNull(dataBaseVersion) && dataBaseVersion.startsWith("9.4");
    }

    @Override
    public void createEvents(Collection<AssetEvent> events) {
        if (CollectionUtils.isEmpty(events)) {
            return;
        }

        List<AssetEventEntity> entities = new ArrayList<>();

        events.forEach(event -> {
            AssetEventEntity entity = new AssetEventEntity();
            BeanUtils.copyProperties(event, entity);
            entities.add(entity);
        });

        eventRepo.save(entities);
    }

    @Override
    @Transactional
    public int deleteEvents(Collection<AssetEvent> events) {
        int count = 0;
        if (!CollectionUtils.isEmpty(events)) {
            List<String> eventIds = events.stream().map(AssetEvent::getId).collect(Collectors.toList());
            String query = MessageFormat.format("DELETE FROM apm_alm.asset_event WHERE id IN ({0})",
                QueryUtils.getSqlListOfResources(eventIds));

            count = jdbc.update(query);
        }
        return count;
    }

    @Override
    @Transactional
    public int cleanupEvents(final String status ,final String timeout) throws PersistencyServiceException {
        String query = MessageFormat.format(isOldDBVersion()
                ? EVENTS_CLEANUP_QUERY_OLD_V : EVENTS_CLEANUP_QUERY, status, timeout + " milliseconds", batchSize);
        log.debug("Formated Query of Cleanup Query >>>> {} ", query);
        return jdbc.update(query, batchSize);
    }

    @Override
    @Transactional
    @SuppressWarnings("squid:S2077")
    public int updateEvents(final Collection<AssetEvent> events, final AssetEvent.EventsJobType jobType,
                            final String status) {
        if (CollectionUtils.isEmpty(events)) {
            return 0;
        }
        final List<String> eventIds = events.stream().map(AssetEvent::getId).collect(Collectors.toList());
        String query = updateEventsQueries.get(jobType) + (isOldDBVersion() ? WHERE_CLAUSE_OLD_V : WHERE_CLAUSE);
        return jdbc.batchUpdate(query, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int index) throws SQLException {
                ps.setString(1, status);
                ps.setString(2, eventIds.get(index));
            }

            @Override
            public int getBatchSize() {
                return eventIds.size();
            }
        }).length;
    }

    @Override
    @Transactional
    @SuppressWarnings("squid:S2077")
    public int updateEventsStatus(final List<String> events, final AssetEvent.EventsJobType jobType,
                            final String status) {
        if (CollectionUtils.isEmpty(events)) {
            return 0;
        }
        String query = updateEventsQueries.get(jobType) + (isOldDBVersion() ? WHERE_CLAUSE_OLD_V : WHERE_CLAUSE);
        log.debug("Update events Status Query >>>>>> {} ", query);
        return jdbc.batchUpdate(query, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int index) throws SQLException {
                ps.setString(1, status);
                ps.setString(2, events.get(index));
            }

            @Override
            public int getBatchSize() {
                return events.size();
            }
        }).length;
    }

    @Override
    @Transactional
    @SuppressWarnings("squid:S2077")
    public int updateEvent(final String eventId, final AssetEvent.EventsJobType jobType,
                                    final String status) throws PersistencyServiceException {
        String query = updateEventsQueries.get(jobType) + (isOldDBVersion() ? WHERE_CLAUSE_OLD_V : WHERE_CLAUSE);
        log.debug("Update event Query >>>>>> {} ", query);
        return jdbc.update(query, new PreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setString(1, status);
                ps.setString(2, eventId);
            }
        });
    }

    @Override
    @Transactional
    public List<AssetEvent> getPendingEventBatch(final EventsJobType job, final Integer jobSize,
                                                 Long timeoutMillis, Long expiredTimeoutMillis)
        throws PersistencyServiceException {
        String query = null;
        switch (job) {
            case EVENTHUB: query = MessageFormat.format(
                    (isOldDBVersion() ? GET_PENDING_EVENTS_FOR_EVENTHUB_OLD_V : GET_PENDING_EVENTS_FOR_EVENTHUB),
                AssetEvent.EventStatus.PROCESSING.name(), EventStatus.QUEUED.name(),
                    timeoutMillis + MILLI_SECONDS, expiredTimeoutMillis + MILLI_SECONDS);
                break;
            case AUDIT: query = MessageFormat.format(
                    (isOldDBVersion() ? GET_PENDING_EVENTS_FOR_AUDITLOG_OLD_V : GET_PENDING_EVENTS_FOR_AUDITLOG),
                AssetEvent.EventStatus.PROCESSING.name(), EventStatus.QUEUED.name(),
                    timeoutMillis + MILLI_SECONDS, expiredTimeoutMillis + MILLI_SECONDS);
                break;
            case PREDIX: query = MessageFormat.format(
                    (isOldDBVersion() ? GET_PENDING_EVENTS_FOR_PREDIX_OLD_V : GET_PENDING_EVENTS_FOR_PREDIX),
                AssetEvent.EventStatus.PROCESSING.name(), EventStatus.QUEUED.name(),
                    timeoutMillis + MILLI_SECONDS, expiredTimeoutMillis + MILLI_SECONDS);
                break;
            default: break;
        }
        log.debug("Formatted Query of Pending Events >>> {} ", query);
        List<AssetEventEntity> events = jdbc.query(query, mapper, jobSize);
        return Collections.unmodifiableList(events);
    }

    @Override
    public List<AssetEvent> getPendingEventBatch(Integer jobSize, Long timeoutMillis)
        throws PersistencyServiceException {

        Long count = eventRepo.count();
        log.info("Number of events to process: " + count);

        String query = MessageFormat.format(UPDATE_PENDING_EVENTS, timeoutMillis + " milliseconds");
        List<AssetEventEntity> events = jdbc.query(query, mapper, jobSize);
        return Collections.unmodifiableList(events);
    }

    @Override
    public List<AssetEvent> getEvents(String tenantId, Type eventType, Set<String> objectIds) {
        String query = MessageFormat.format(
            "select * from apm_alm.asset_event where tenant_id = ? and event_type = ? and object_id in ({0})",
            QueryUtils.getSqlListOfResources(objectIds));
        return Collections.unmodifiableList(jdbc.query(query, mapper, tenantId, eventType.name()));
    }
}
