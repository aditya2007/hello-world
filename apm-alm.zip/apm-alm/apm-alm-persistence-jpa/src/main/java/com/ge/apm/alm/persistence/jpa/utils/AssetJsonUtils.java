/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import java.util.List;

import lombok.extern.slf4j.Slf4j;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;

/**
 * @author Albert H. Yu 212365823
 * @version 1.0 Jun 1, 2017
 * @since 1.0
 */
@Slf4j
public final class AssetJsonUtils {

    private AssetJsonUtils() {
    }

    public static boolean isAChild(String parentId, Asset asset) {
        List<String> values = asset.getAncestorsArray();
        return values.contains(parentId);
    }

    /**
     * Returns <code>true</code> if the asset is an immediate child of the given parent identifier. That is, the
     * parent identifier is present as the last element of the asset's ancestors list.
     *
     * @param parentId parent identifier
     *
     * @return <code>true</code> if the parent identifier is the last entry in the ancestors node
     */
    public static boolean isImmediateChild(String parentId, Asset asset) {
        List<String> values = asset.getAncestorsArray();
        int size = values.size();
        return size > 0 && parentId.equals(values.get(size - 1));
    }

    public static OOTBCoreTypesIdLookup getCoreType(Asset asset) {
        List<String> values = asset.getSuperTypesArray();
        if (values.size() == 0) {
            throw new IllegalArgumentException(
                "Cannot find core type for asset[" + asset.getId() + "] with no super types.");
        }
        return OOTBCoreTypesIdLookup.fromId(values.get(0));
    }
}