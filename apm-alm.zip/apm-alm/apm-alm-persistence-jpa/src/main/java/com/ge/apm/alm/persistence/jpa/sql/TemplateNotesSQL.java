/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.sql;

public final class TemplateNotesSQL {

    public static final String DELETE_TEMPLATE_NOTES = "delete from apm_alm.template_notes ";
    private static final String WHERE_TENANT_ID_AND_ID = " where tenant_id = ? and id = ? ";
    private static final String WHERE_TENANT_ID_AND_TEMPLATE_ID = " where tenant_id = ? and template_id = ? ";

    private static final String BATCH_CREATE_SQL = "insert into apm_alm.template_notes (id, tenant_id, "
        + " template_id, notes_id) values (?, ?, ?, ?)";

    private TemplateNotesSQL() {
    }

    public static String getBatchCreateSQL() {
        return BATCH_CREATE_SQL;
    }

    public static String getDeleteByIdSQL() {
        return DELETE_TEMPLATE_NOTES + WHERE_TENANT_ID_AND_ID;
    }

    public static String getDeleteByTemplateIdSQL() {
        return DELETE_TEMPLATE_NOTES + WHERE_TENANT_ID_AND_TEMPLATE_ID;
    }
}
