/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.sql;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.jpa.utils.DatabaseUtil;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.SYSTEM_TENANT_ID;

/**
 * Created by 212564021 on 3/4/17.
 */
public final class AssetTypeSQL {

    private static final String ID_COLUMN = "select id from apm_alm.asset_type";

    private static final AtomicReference<String> ALL_COLUMNS = new AtomicReference<>();

    private static final String BASIC_COLUMNS = "select id, source_key, name, description, super_type_id, tenant_id, "
        + "created_by, created_date, last_modified_by, last_modified_date from apm_alm.asset_type";

    private static final String BASIC_COLUMNS_WITH_ATTRIBUTES =
        "select id, source_key, name, description, super_type_id, super_types_array, attribute_schema, tenant_id, "
            + "created_by, created_date, last_modified_by, last_modified_date from apm_alm.asset_type";

    private static final String BASIC_COLUMNS_WITH_ATTRIBUTES_AND_SUPERTYPES_COLUMNS = "select id, source_key, name,"
        + " description, super_type_id, attribute_schema, super_types_array, tenant_id from apm_alm.asset_type";

    private static final String ID_IN_0 = " id in ({0}) ";

    private static final String WHERE_TENANT_ID_OR_SYSTEM_TENANT_ID = " where (tenant_id = ? or tenant_id = '"
        + SYSTEM_TENANT_ID + "') ";

    private static final String WHERE_TENANT_ID = " where tenant_id = ? ";

    private static final String WHERE_TENANT_ID_AND_SUPER_TYPE = WHERE_TENANT_ID + " and super_type_id = ? ";

    private static final String WHERE_TENANT_ID_AND_ANY_SUPER_TYPE = WHERE_TENANT_ID
        + " and super_types_array @> array[''{0}''] ";

    private static final String WHERE_TENAND_ID_AND_ID_CLAUSE = WHERE_TENANT_ID + " and id = ?";

    private static final String SUPER_TYPE_ID_IN_CLAUSE = "super_type_id in ({0})";

    private static final String ANY_SUB_TYPE_IN_CLAUSE = " (super_types_array && array[{0}]) ";

    //following only used in the context of root types normally..
    private static final String TYPE_OR_SUB_TYPE_CLAUSE = " (id = ''{0}'' or super_types_array @> array[''{0}'']) ";

    private static final String TYPE_OR_SUB_TYPE_IN_CLAUSE = "(id in ({0}) or super_types_array && array[{0}])";

     //following is for specific type
    private static final String DELETE_ASSET_TYPE_SQL = "delete from apm_alm.asset_type "
        + WHERE_TENAND_ID_AND_ID_CLAUSE;

    private static final String AND = " and ";

    private static final String DELETE_ASSET_TYPE_SQL_RECURSIVE = "delete from apm_alm.asset_type " + WHERE_TENANT_ID
        + AND + TYPE_OR_SUB_TYPE_CLAUSE;

    private static final String SELECT_SUPER_TYPES_BY_IDS =
        "select id, super_types_array from apm_alm.asset_type where tenant_id = ? and " + ID_IN_0;

    private static final String BATCH_CREATE_SQL =
        "insert into apm_alm.asset_type (id, source_key, name, description, tenant_id, " + "super_type_id, "
            + "json_schema, attribute_schema, type_semantics, super_types_array, created_by, " + "created_date, "
            + "last_modified_by, last_modified_date) values (?, " + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String OR_ANY_SUB_TYPE_IN_CRITERIA =
        " or (super_types_array && array(select cast(id as text) from apm_alm.asset_type " + "where tenant_id = "
            + "''{0}'' and {1}))";

    private static final String PARENT_CLAUSE = "(super_type_id in ({0}))";

    private static final String PARENT_AND_SUPERTYPES_CLAUSE
        = "(super_type_id in ({0}) or super_types_array && array[{0}])";

    // {0} is tenantId
    // {1} is additional parent filtering criteria
    private static final String PARENT_IN_CLAUSE
        = "(super_type_id in (select id from apm_alm.asset_type where tenant_id = ''{0}'' {1}))";

    private static final String PARENT_AND_SUPERTYPES_IN_CLAUSE =
        "(super_type_id in (select id from apm_alm.asset_type where tenant_id = ''{0}'' {1} or "
            + "(super_types_array && array(select cast(id as text) from apm_alm.asset_type " + "where tenant_id = "
            + "''{0}'' {1}))))";

    private static final String ORDER_BY_CLAUSE = " order by {0} {1}";

    private AssetTypeSQL() {
    }

    public static String getOrderBy(TypePredicate typePredicate) {
        return StringUtils.isEmpty(typePredicate.getOrderBy()) ? "" : MessageFormat.format(ORDER_BY_CLAUSE,
            typePredicate.getOrderBy(), typePredicate.getOrder());
    }

    public static String getSpecificTypeSqlByTypeIdAndSuperTypesById(String typeId) {
        return MessageFormat.format(getSelectAll()
            + " where (tenant_id = ? or tenant_id = ''" + SYSTEM_TENANT_ID + "'') " + " and id = ? and "
            + TYPE_OR_SUB_TYPE_CLAUSE, typeId);
    }

    public static String getSelectChildAssetTypesRecursive(String tenantId, String superTypeId,
        TypePredicate childQueryPredicate) {
        String andFilter = getFilterPredicate(tenantId, childQueryPredicate);
        andFilter = StringUtils.isEmpty(andFilter) ? "" : AND + andFilter;
        String anySuperType = getSelectAttributes(
            childQueryPredicate == null ? AttributeSelectEnum.BASIC : childQueryPredicate.getAttributeSelectEnum())
            + WHERE_TENANT_ID_AND_ANY_SUPER_TYPE;
        return MessageFormat.format(anySuperType, superTypeId) + andFilter;
    }

    public static String getSelectChildAssetTypes(String tenantId, TypePredicate childQueryPredicate) {
        String andFilter = getFilterPredicate(tenantId, childQueryPredicate);
        andFilter = StringUtils.isEmpty(andFilter) ? "" : AND + andFilter;
        return getSelectAttributes(
            childQueryPredicate == null ? AttributeSelectEnum.BASIC : childQueryPredicate.getAttributeSelectEnum())
            + WHERE_TENANT_ID_AND_SUPER_TYPE + andFilter;
    }

    public static String getSpecificTypeSqlByTypeIdAndSuperTypesBySourceKey(String typeId) {
        return MessageFormat.format(getSelectAll() + WHERE_TENANT_ID
            + " and lower(source_key) = ? and " + TYPE_OR_SUB_TYPE_CLAUSE, typeId);
    }

    public static String getSpecificTypeSqlByTypeIdAndSuperTypesBySourceKeys(String typeId,
        Collection<String> sourceKeys) {
        String listOfLowerCaseSrcKeys = QueryUtils.getSqlListOfResources(
            sourceKeys.stream().map(String::toLowerCase).collect(Collectors.toList()));
        return MessageFormat.format(getSelectAll() + WHERE_TENANT_ID
                + " and lower(source_key) in ({1}) and " + TYPE_OR_SUB_TYPE_CLAUSE, typeId,
            listOfLowerCaseSrcKeys);
    }

    public static String buildDeleteAssetTypeQueryRecursive(String assetId) {
        //global tenant level deletion. Very powerful..So be careful
        return MessageFormat.format(DELETE_ASSET_TYPE_SQL_RECURSIVE, assetId);
    }

    public static String buildDeleteAssetTypeQuery() {
        return DELETE_ASSET_TYPE_SQL;
    }

    public static String getSelectSuperTypesByIds(Set<String> assetTypeIds) {
        return MessageFormat.format(SELECT_SUPER_TYPES_BY_IDS, QueryUtils.getSqlListOfResources(assetTypeIds));
    }

    public static String getBatchCreateSQL() {
        return BATCH_CREATE_SQL;
    }

    public static String getSelectWithNoPrefix(TypePredicate typePredicate) {
        String predicate = getSelectAttributes(typePredicate.getAttributeSelectEnum()) + WHERE_TENANT_ID;
        String orderBy = getOrderBy(typePredicate);
        predicate = predicate + orderBy + QueryUtils.getPagination(typePredicate, false);
        return predicate;
    }

    public static String getSelectAndFilterPredicate(String tenantId, TypePredicate typePredicate) {
        String predicate = getSelectAttributes(typePredicate.getAttributeSelectEnum()) + WHERE_TENANT_ID;
        String andFilter = getFilterPredicate(tenantId, typePredicate);
        andFilter = StringUtils.isEmpty(andFilter) ? "" : AND + andFilter;
        predicate = predicate + andFilter;
        String greaterThan = QueryUtils.getNextPageSortKeyFilter(typePredicate);
        if (!StringUtils.isEmpty(greaterThan)) {
            predicate += AND + greaterThan;
        }
        predicate += QueryUtils.getPagination(typePredicate);
        return predicate;
    }

    public static String getCompatibleSuperTypeSQL(String superTypeId, Set<String> typeIds) {
        return "select id from apm_alm.asset_type " + WHERE_TENANT_ID_OR_SYSTEM_TENANT_ID + AND + MessageFormat.format(
            ID_IN_0, QueryUtils.getSqlListOfResources(typeIds)) + AND + MessageFormat.format(TYPE_OR_SUB_TYPE_CLAUSE,
            superTypeId);
    }

    private static String getFilterPredicate(String tenantId, TypePredicate predicate) {
        if (predicate == null) {
            return "";
        }

        boolean missingChildPredicates = predicate.getChildOperand() == null || !CollectionUtils.isEmpty(
            predicate.getChildPredicates());
        assert missingChildPredicates : "Predicate with child operand must have non-empty list of child predicates.";

        List<String> expressions = getExpressionsFromPredicate(tenantId, predicate);

        StringBuilder rslt = new StringBuilder();
        if (!CollectionUtils.isEmpty(expressions)) {
            rslt.append(QueryUtils.flattenExpressions(expressions, Operand.AND));
            if (predicate.getChildOperand() != null) {
                rslt.append(" ").append(predicate.getChildOperand().name().toLowerCase(Locale.getDefault()));
            }
        }

        rslt.append(processChildPredicates(tenantId, predicate));

        if (rslt.length() == 0) {
            return "";
        }
        return rslt.insert(0, "(").append(")").toString();
    }

    private static String getTypeIdsInClause(Set<String> typeIds, boolean isDeepSearch) {
        String clause = isDeepSearch ? TYPE_OR_SUB_TYPE_IN_CLAUSE : ID_IN_0;
        return MessageFormat.format(clause, QueryUtils.getSqlListOfResources(typeIds));
    }

    private static String getTypeParentIdsInClause(Set<String> parentIds, boolean isDeepSearch) {
        String clause = isDeepSearch ? ANY_SUB_TYPE_IN_CLAUSE : SUPER_TYPE_ID_IN_CLAUSE;
        return MessageFormat.format(clause, QueryUtils.getSqlListOfResources(parentIds));
    }

    private static List<String> getExpressionsFromPredicate(String tenantId, TypePredicate predicate) {
        List<String> expressions = QueryUtils.getEqualOrLikeFilterExpressions(predicate, predicate.getAttributes(),
            predicate.getReservedAttributes());
        Set<String> typeParentIds = predicate.getParent() == null ? null : predicate.getParent().getIds();
        Set<String> ids = predicate.getIds();
        if (CollectionUtils.isEmpty(typeParentIds) && CollectionUtils.isEmpty(ids)) {
            expressions.addAll(getParentContextFilters(tenantId, predicate.getParent()));
            if (!CollectionUtils.isEmpty(expressions) && predicate.isDeepSearch()) {
                String filters = QueryUtils.flattenExpressions(expressions, Operand.AND);
                String query = filters + MessageFormat.format(OR_ANY_SUB_TYPE_IN_CRITERIA, tenantId, filters);
                expressions.clear();
                expressions.add(query);
            }
        } else {
            if (!CollectionUtils.isEmpty(ids)) {
                expressions.add(getTypeIdsInClause(ids, predicate.isDeepSearch()));
            }
            if (CollectionUtils.isEmpty(typeParentIds)) {
                expressions.addAll(getParentContextFilters(tenantId, predicate.getParent()));
            } else {
                expressions.add(getTypeParentIdsInClause(typeParentIds, predicate.getParent().isDeepSearch()));
            }
        }

        expressions = expressions.stream().filter(e -> !StringUtils.isEmpty(e)).collect(Collectors.toList());
        return expressions;
    }

    private static List<String> getParentContextFilters(String tenantId, ParentPredicate parent) {
        List<String> expressions = new ArrayList<>();
        if (parent != null) {
            List<String> parentExpressions = QueryUtils.getEqualOrLikeFilterExpressions(parent, parent.getAttributes(),
                parent.getReservedAttributes());
            expressions.add(getParentIdsInPredicate(parent.getIds(), parent.isDeepSearch()));
            if (!CollectionUtils.isEmpty(parentExpressions)) {
                String filterExp = "and " + QueryUtils.flattenExpressions(parentExpressions, Operand.AND);
                expressions.add(getParentInPredicate(tenantId, filterExp, parent.isDeepSearch()));
            }
        }
        return expressions.stream().filter(e -> !StringUtils.isEmpty(e)).collect(Collectors.toList());
    }

    private static String getParentInPredicate(String tenantId, String filterExpression, boolean includeAncestors) {
        String clause = includeAncestors ? PARENT_AND_SUPERTYPES_IN_CLAUSE : PARENT_IN_CLAUSE;
        return MessageFormat.format(clause, tenantId, filterExpression);
    }

    private static String getParentIdsInPredicate(Set<String> parentIds, boolean includeAncestors) {
        if (CollectionUtils.isEmpty(parentIds)) {
            return "";
        }
        String clause = includeAncestors ? PARENT_AND_SUPERTYPES_CLAUSE : PARENT_CLAUSE;
        return MessageFormat.format(clause, QueryUtils.getSqlListOfResources(parentIds));
    }

    private static String processChildPredicates(String tenantId, TypePredicate predicate) {
        if (predicate == null || CollectionUtils.isEmpty(predicate.getChildPredicates())) {
            return "";
        }
        StringBuilder rslt = new StringBuilder(" (");
        int lastIndex = predicate.getChildPredicates().size() - 1;
        int i = 0;
        for (TypePredicate tp : predicate.getChildPredicates()) {
            rslt.append(getFilterPredicate(tenantId, tp));
            if (tp != null && tp.getPeerOperand() != null && i < lastIndex) {
                rslt.append(" ").append(tp.getPeerOperand().name().toLowerCase(Locale.getDefault())).append(" ");
            }
            i++;
        }
        rslt.append(")");
        return rslt.toString();
    }

    private static String getSelectAttributes(AttributeSelectEnum attributeSelectEnum) {
        if (attributeSelectEnum == null) {
            return BASIC_COLUMNS;
        }
        switch (attributeSelectEnum) {
            case ID:
                return ID_COLUMN;
            case FULL:
            case FULL_WITHOUT_ATTRIBUTES:
                return getSelectAll();
            case ATTRIBUTES:
                return BASIC_COLUMNS_WITH_ATTRIBUTES;
            case ATTRIBUTES_WITH_SUPERTYPES:
                return BASIC_COLUMNS_WITH_ATTRIBUTES_AND_SUPERTYPES_COLUMNS;
            default:
                return BASIC_COLUMNS;
        }
    }

    private static String getSelectAll() {
        String select = ALL_COLUMNS.get();
        if (select == null) {
            List<String> columns = new ArrayList<>( DatabaseUtil.getAllQueryColumns("asset_type"));
            select = "select " + columns.stream().collect(Collectors.joining(","))
                + " from apm_alm.asset_type";
            ALL_COLUMNS.set(select);
        }

        return select;
    }
}
