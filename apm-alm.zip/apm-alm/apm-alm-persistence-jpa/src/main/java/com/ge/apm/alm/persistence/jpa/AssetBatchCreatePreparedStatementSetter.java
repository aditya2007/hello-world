/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;

class AssetBatchCreatePreparedStatementSetter extends AssetBatchPreparedStatementSetter<Asset> {

    private final Map<String, List<String>> ancestorsByParentId;

    AssetBatchCreatePreparedStatementSetter(String tenantId, List<Asset> assets,
        Map<String, List<String>> ancestorsByParentId, Map<String, List<String>> superTypesById,
        JsonbAttributeConverter jsonbAttributeConverter, ListToTextArrayAttributeConverter
        listToTextArrayAttributeConverter,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter) {
        super(tenantId, assets, superTypesById, jsonbAttributeConverter, listToTextArrayAttributeConverter,
            offsetDateTimeAttributeConverter);
        this.ancestorsByParentId = ancestorsByParentId;
    }

    @Override
    public void setValues(PreparedStatement ps, int index) throws SQLException {
        Asset asset = instances.get(index);
        ps.setString(1, asset.getId());
        ps.setString(2, asset.getSourceKey());
        ps.setString(3, asset.getName());
        ps.setString(4, asset.getDescription());
        ps.setString(5, tenantId);
        ps.setString(6, asset.getAssetType());
        ps.setString(7, asset.getParentId());
        ps.setObject(8, jsonbAttributeConverter.convertToDatabaseColumn(asset.getAttributes()));
        ps.setObject(9, listToTextArrayAttributeConverter.convertToDatabaseColumn(getMyAncestors(asset,
            ancestorsByParentId)));
        ps.setObject(10, listToTextArrayAttributeConverter.convertToDatabaseColumn(superTypesByTypeId.get(asset
            .getAssetType())));
        ps.setObject(11, jsonbAttributeConverter.convertToDatabaseColumn(asset.getGeolocation()));
        ps.setString(12, asset.getCreatedBy());
        ps.setTimestamp(13, now);
        ps.setString(14, asset.getLastModifiedBy());
        ps.setTimestamp(15, now);
        //setting computed values back to bean for client's convenience
        setCreatedDate(asset);
        setLastModifiedDate(asset);
        setSetSuperTypesArray(asset);
    }

    private List<String> getMyAncestors(Asset asset, Map<String, List<String>> ancestorsByParentId) {
        List<String> parentsAncestors = ancestorsByParentId.get(asset.getParentId());
        List<String> myAncestors;
        if (parentsAncestors == null) {
            myAncestors = new ArrayList<>();
        } else {
            // must clone to make each asset's ancestors independent of each other
            myAncestors = new ArrayList<>(parentsAncestors);
        }
        if (asset.getParentId() != null) {
            myAncestors.add(asset.getParentId());
        }
        // put the current asset ancestors in to be used by its children in subsequent calls
        ancestorsByParentId.put(asset.getId(), myAncestors);
        return myAncestors;
    }

    @Override
    protected String getTypeId(Asset asset) {
        return asset.getAssetType();
    }
}