/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.ge.apm.alm.model.Notes;

@Entity
@Table(name = "notes", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class NotesEntity extends AuditableEntity implements Notes {

    @Column(name = "content")
    private String content;

    @Column(name = "name")
    private String name;

    @Builder
    private NotesEntity(String id, String name, String tenantId, String createdBy,
        String lastModifiedBy, String content) {
        super(id, tenantId, createdBy, lastModifiedBy);
        this.content = content;
        this.name = name;
    }
}

