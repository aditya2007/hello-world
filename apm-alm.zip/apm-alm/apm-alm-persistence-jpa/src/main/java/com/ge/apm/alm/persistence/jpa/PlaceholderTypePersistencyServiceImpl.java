/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.PlaceholderType;
import com.ge.apm.alm.persistence.PlaceholderTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderTypeEntity;
import com.ge.apm.alm.persistence.jpa.repository.PlaceholderTypeRepository;
import com.ge.apm.alm.persistence.jpa.sql.PlaceholderTypeSQL;

import static com.ge.apm.alm.persistence.jpa.utils.Validator.assertMatchingTenantId;

@Service
@Slf4j
@Transactional
public class PlaceholderTypePersistencyServiceImpl implements PlaceholderTypePersistencyService {

    private static final int QUERY_BATCH_SIZE = 500;
    private static final String PLACEHOLDER_TYPE_HAS_REFERENCES_TO_IT_HENCE_CANNOT_BE_DELETED =
        "PlaceholderType has references to it. Hence cannot be deleted";
    @Autowired
    private DataSource dataSource;
    @Autowired
    private PlaceholderTypeRepository placeholderTypeRepository;
    @Autowired
    private ConversionService conversionService;

    private EntityBeanPropertyRowMapper<PlaceholderTypeEntity> placeholderTypeBeanPropertyRowMapper;
    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initializeConvertionService() {
        placeholderTypeBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(PlaceholderTypeEntity.class,
            conversionService);
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public PlaceholderType createPlaceholderType(String tenantId, PlaceholderType placeholderType) {
        assertMatchingTenantId(tenantId, placeholderType.getTenantId());
        validatePlaceholderType(placeholderType);

        PlaceholderTypeEntity entity = toPlaceholderTypeEntity(tenantId, placeholderType, true);
        return placeholderTypeRepository.saveAndFlush(entity);
    }

    @Override
    public int createPlaceholderTypes(String tenantId, List<PlaceholderType> placeholderTypes) {
        if (CollectionUtils.isEmpty(placeholderTypes)) {
            return 0;
        }

        List<PlaceholderTypeEntity> entities = new ArrayList<>();
        placeholderTypes.stream().forEach(placeholderType -> {
            assertMatchingTenantId(tenantId, placeholderType.getTenantId());
            entities.add(toPlaceholderTypeEntity(tenantId, placeholderType, true));
        });

        int[] updateCounts = jdbcTemplate
            .batchUpdate(PlaceholderTypeSQL.getBatchCreateSQL(), new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int index) throws SQLException {
                    PlaceholderTypeEntity entity = entities.get(index);
                    ps.setString(1, entity.getId());
                    ps.setString(2, tenantId);
                    ps.setString(3, entity.getPlaceholderId());
                    ps.setString(4, entity.getTypeId());
                    ps.setBoolean(5, entity.getPrimary() == null ? Boolean.FALSE : entity.getPrimary());
                    ps.setObject(6, entity.getStatus());
                    ps.setString(7, entity.getCreatedBy());
                    ps.setString(8, entity.getLastModifiedBy());
                }

                @Override
                public int getBatchSize() {
                    return placeholderTypes.size();
                }
            });
        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public PlaceholderType updatePlaceholderType(String tenantId, PlaceholderType placeholderType)
        throws PersistencyServiceException {
        assertMatchingTenantId(tenantId, placeholderType.getTenantId());

        PlaceholderTypeEntity entity = toPlaceholderTypeEntity(tenantId, placeholderType, false);
        return placeholderTypeRepository.saveAndFlush(entity);
    }

    @Override
    public int updatePlaceholderTypes(String tenantId, List<PlaceholderType> placeholderTypes)
        throws PersistencyServiceException {
        if (CollectionUtils.isEmpty(placeholderTypes)) {
            return 0;
        }

        int updateCounts = 0;
        for (PlaceholderType placeholderType : placeholderTypes) {
            updatePlaceholderType(tenantId, placeholderType);
            updateCounts++;
        }
        return updateCounts;
    }

    @Override
    public int deletePlaceholderType(String tenantId, String id) throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderTypeSQL.getDeleteByIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, id);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                PLACEHOLDER_TYPE_HAS_REFERENCES_TO_IT_HENCE_CANNOT_BE_DELETED, ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException(id);
        }
        return rowsDeleted;
    }

    @Override
    public int deletePlaceholderTypeByPlaceholderIdAndTypeId(String tenantId, String placeholderId, String typeId)
        throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderTypeSQL.getDeleteByPlaceholderIdAndTypeIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, placeholderId, typeId);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                PLACEHOLDER_TYPE_HAS_REFERENCES_TO_IT_HENCE_CANNOT_BE_DELETED, ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("placeholderId:" + placeholderId + ", typeId:" + typeId);
        }
        return rowsDeleted;
    }

    @Override
    public int deletePlaceholderTypeByPlaceholderId(String tenantId, String placeholderId)
        throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderTypeSQL.getDeleteByPlaceholderIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, placeholderId);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                PLACEHOLDER_TYPE_HAS_REFERENCES_TO_IT_HENCE_CANNOT_BE_DELETED, ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("placeholderId:" + placeholderId);
        }
        return rowsDeleted;
    }

    @Override
    public PlaceholderType getPlaceholderTypeById(String tenantId, String id) {
        try {
            String query = PlaceholderTypeSQL.getSelectSingleObjectById();
            return jdbcTemplate.queryForObject(query, placeholderTypeBeanPropertyRowMapper, tenantId, id);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("PlaceholderType not found with identifier: {}", id);
            return null;
        }
    }

    @Override
    public PlaceholderType getPlaceholderTypeByPlaceholderIdAndTypeId(String tenantId, String placeholderId,
        String typeId) {
        try {
            String query = PlaceholderTypeSQL.getSelectSingleObjectByPlaceholderIdAndTypeId();
            return jdbcTemplate.queryForObject(query, placeholderTypeBeanPropertyRowMapper, tenantId, placeholderId,
                typeId);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("PlaceholderType not found with identifier: {}", placeholderId);
            return null;
        }
    }

    @Override
    public List<PlaceholderType> getPlaceholderTypes(String tenantId, String placeholderId) {
        String query = PlaceholderTypeSQL.getSelectCollectionObjectsByPlaceholderId();
        return Collections.unmodifiableList(jdbcTemplate.query(query, placeholderTypeBeanPropertyRowMapper,
            tenantId, placeholderId));
    }

    @Override
    public List<PlaceholderType> getPlaceholderTypes(String tenantId, String placeholderId, String status) {
        String query = PlaceholderTypeSQL.getSelectCollectionObjectsByPlaceholderIdAndStatus();
        return Collections.unmodifiableList(jdbcTemplate.query(query, placeholderTypeBeanPropertyRowMapper,
            tenantId, placeholderId, status));
    }

    @Override
    public List<PlaceholderType> getPlaceholderTypes(String tenantId, List<String> placeholderIds) {
        if (CollectionUtils.isEmpty(placeholderIds)) {
            return Collections.emptyList();
        }

        List<PlaceholderTypeEntity> placeholderTypeEntities = new ArrayList<>();
        int counter = 0;
        int size = placeholderIds.size();

        while (counter < size) {
            int endIndex = counter + QUERY_BATCH_SIZE < size ? counter + QUERY_BATCH_SIZE : size;
            List<String> batchPlaceholderIdList = placeholderIds.subList(counter, endIndex);
            String query = PlaceholderTypeSQL.getSelectCollectionObjectsByPlaceholderIs(batchPlaceholderIdList);

            List<PlaceholderTypeEntity> foundEnties = jdbcTemplate.query(query,
                placeholderTypeBeanPropertyRowMapper, tenantId);
            placeholderTypeEntities.addAll(foundEnties);

            counter = endIndex;
        }

        return Collections.unmodifiableList(placeholderTypeEntities);
    }

    @Override
    public List<PlaceholderType> getPlaceholderTypeByTemplateId(String tenantId, String templateId) {
        String query = PlaceholderTypeSQL.getSelectCollectionObjectsByTemplateId();
        return Collections.unmodifiableList(jdbcTemplate.query(query, placeholderTypeBeanPropertyRowMapper,
            tenantId, templateId));
    }

    private void validatePlaceholderType(PlaceholderType placeholderType) {
        StringBuilder builder = new StringBuilder();
        if (StringUtils.isEmpty(placeholderType.getId())) {
            builder.append("PlaceholderType Id is empty. ");
        }
        if (StringUtils.isEmpty(placeholderType.getPlaceholderId())) {
            builder.append("PlaceholderType placeholderId is empty. ");
        }
        if (StringUtils.isEmpty(placeholderType.getTypeId())) {
            builder.append("PlaceholderType typeId is empty. ");
        }
        if (StringUtils.isEmpty(placeholderType.getStatus())) {
            builder.append("PlaceholderType Status is empty. ");
        }

        if (!builder.toString().isEmpty()) {
            throw new IllegalArgumentException(builder.toString());
        }
    }

    private PlaceholderTypeEntity toPlaceholderTypeEntity(String tenantId, PlaceholderType placeholderType,
        boolean isAdd) {
        PlaceholderTypeEntity entity = new PlaceholderTypeEntity();
        entity.setId(placeholderType.getId());
        entity.setTenantId(tenantId);
        entity.setPlaceholderId(placeholderType.getPlaceholderId());
        entity.setTypeId(placeholderType.getTypeId());
        entity.setStatus(placeholderType.getStatus());
        entity.setPrimary(placeholderType.getPrimary() == null ? Boolean.FALSE : placeholderType.getPrimary());
        if (isAdd) {
            entity.setCreatedBy(placeholderType.getCreatedBy());
        }
        entity.setLastModifiedBy(placeholderType.getLastModifiedBy());
        return entity;
    }
}
