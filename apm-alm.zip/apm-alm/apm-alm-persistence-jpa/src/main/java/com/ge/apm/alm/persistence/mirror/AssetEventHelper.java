/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.mirror;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;
import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.extern.slf4j.Slf4j;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.EventStatus;
import com.ge.apm.alm.model.AssetEvent.EventsJobType;
import com.ge.apm.alm.model.AssetEvent.ObjectType;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupAssociation;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetHierarchy;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Edge;
import com.ge.apm.alm.model.Network;
import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.PlaceholderGroupTagType;
import com.ge.apm.alm.model.PlaceholderTagType;
import com.ge.apm.alm.model.PlaceholderTemplate;
import com.ge.apm.alm.model.PlaceholderType;
import com.ge.apm.alm.model.Sourceable;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.query.NetworkPredicate;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.persistence.AssetGroupAssociationPersistencyService;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.NetworkPersistencyService;
import com.ge.apm.alm.persistence.PlaceholderPersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.TemplatePersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.entity.AssetEventEntity;

@Slf4j
public final class AssetEventHelper {

    private static final ObjectMapper CUSTOM_MAPPER = new ObjectMapper();

    public static final String SOURCE_KEY = "sourceKey";

    private static List<String> ignorableTypesForAuditLog = Collections.emptyList();

    private static List<String> ignorableTypesForEventHub = Collections.emptyList();

    private static boolean isAuditlogEnabled = false;

    private static boolean isEventhubEnabled = false;

    private static List<AssetGroupCategory> assetGroupTypes = Arrays.asList(AssetGroupCategory.ASSET_TYPE,
        AssetGroupCategory.ENTERPRISE_TYPE, AssetGroupCategory.SEGMENT_TYPE,
        AssetGroupCategory.SITE_TYPE, AssetGroupCategory.TAG_TYPE);

    static {
        CUSTOM_MAPPER.setAnnotationIntrospector(new JacksonAnnotationIntrospector() {
            @Override
            public boolean hasIgnoreMarker(final AnnotatedMember member) {
                return super.hasIgnoreMarker(member) || member.getName().contains("Mockito");
            }
        });
    }

    private AssetEventHelper() {
    }

    public static void setIgnorableTypesForAuditLog(List<String> ignorableTypesForAuditLog) {
        AssetEventHelper.ignorableTypesForAuditLog = ignorableTypesForAuditLog;
    }

    public static void setIgnorableTypesForEventHub(List<String> ignorableTypesForEventHub) {
        AssetEventHelper.ignorableTypesForEventHub = ignorableTypesForEventHub;
    }

    public static void setIsAuditlogEnabled(boolean isAuditlogEnabled) {
        AssetEventHelper.isAuditlogEnabled = isAuditlogEnabled;
    }

    public static void setIsEventhubEnabled(boolean isEventhubEnabled) {
        AssetEventHelper.isEventhubEnabled = isEventhubEnabled;
    }

    public static AssetEvent createEvent(MirrorableParam param, Object service, Map<String, Object> services) {
        return createEvent(param, param.getObjectType(), param.getObjectId(), service, null, services);
    }

    public static AssetEvent createEvent(MirrorableParam param, String objectType, String objectId,
        Object service, Object existingObj, Map<String, Object> services) {
        return createEvent(param, param.getPersistType(), objectType, objectId, service, existingObj, services);
    }

    public static AssetEvent createEvent(MirrorableParam param, Type eventType,
                                         String objectType, String objectId, Object service, Object existingObj,
        Map<String, Object> services) {
        return AssetEventEntity.builder()
            .id(UUID.randomUUID().toString())
            .tenantId(param.getTenantId())
            .createdBy(MirrorAspect.class.getSimpleName())
            .lastModifiedBy(MirrorAspect.class.getSimpleName())
            .eventType(eventType)
            .objectId(objectId)
            .objectType(objectType)
            .objectLastModifiedDate(param.getLastModified())
            .preModifiedObject(getExistingBizObj(service, param, services, existingObj))
            .modifiedBizObject(getBizObjAsJsonNode(param, services))
            .predixPubStatus(getEventStatus(objectType, EventsJobType.PREDIX))
            .eventhubPubStatus(getEventStatus(objectType, EventsJobType.EVENTHUB))
            .auditPubStatus(getEventStatus(objectType, EventsJobType.AUDIT))
            .build();
    }

    public static EventStatus getEventStatus(String objectType, EventsJobType type) {
        EventStatus status = EventStatus.QUEUED;
        switch (type) {
            case PREDIX:
                    status = EventStatus.COMPLETED;
                break;
            case AUDIT:
                if (!isAuditlogEnabled || ignorableTypesForAuditLog.contains(objectType)) {
                    status = EventStatus.COMPLETED;
                }
                break;
            case EVENTHUB:
                if (!isEventhubEnabled || ignorableTypesForEventHub.contains(objectType)) {
                    status = EventStatus.COMPLETED;
                }
                break;
            default: break;
        }
        return status;
    }

    public static Object getModifiedObject(MirrorableParam param, Map<String, Object> persistencyServices)
        throws PersistencyServiceException {
        final Map<String, Object> obj = new HashMap<>();
        if (param.getObjectType().equals(ObjectType.ASSET_GROUP)) {
            obj.putAll(getGroup(param, persistencyServices, false));
        }
        if (param.getObjectType().equals(ObjectType.NETWORK)) {
            NetworkPersistencyService service = (NetworkPersistencyService) persistencyServices.get(param
                .getObjectType());
            obj.putAll(getNetwork(param, service, persistencyServices, false));
        }
        return obj;
    }

    public static JsonNode convertBizObjToJsonNode(Object param) {
        JsonNode node = null;
        try {
            node = CUSTOM_MAPPER.convertValue(param, JsonNode.class);
        } catch (Exception ex) {
            log.error("Error while converting to Json Node " + ex);
        }
        return node;
    }

    private static JsonNode convertBizObjToJsonNode(MirrorableParam param) {
        Map<String, Object> existingObj = new HashMap<>();
        existingObj.put("id", param.getArg());
        existingObj.put("deletedReason", param.getDeletedReason());

        JsonNode node = null;
        try {
            node = CUSTOM_MAPPER.convertValue(existingObj, JsonNode.class);
        } catch (Exception ex) {
            log.error("Error while creating to Json Node " + ex);
        }
        return node;
    }

    private static JsonNode getExistingBizObj(Object service, MirrorableParam param, Map<String, Object> services,
        Object existingObj) {
        JsonNode node = null;
        if (param.getPersistType() != Type.CREATE && !StringUtils.isEmpty(param.getObjectId())) {
            try {
                Object oldObject = null;
                if (existingObj != null) {
                    oldObject = existingObj;
                } else if (Objects.nonNull(service)) {
                    oldObject = getExistingObject(service, param, services);
                }
                if (Objects.nonNull(oldObject)) {
                    node = CUSTOM_MAPPER.convertValue(oldObject, JsonNode.class);
                    setTemplatePlaceholder(param, node);
                }
            } catch (Exception ex) {
                log.error("Exception while getting existing object " + ex);
            }

        }
        return node;
    }

    private static void setTemplatePlaceholder(MirrorableParam param, JsonNode node) {
        if (ObjectType.TEMPLATE.equals(param.getObjectType()) && param.getPersistType() == Type.UPDATE && node
            instanceof ObjectNode) {
            ((ObjectNode)node).put("placeholders", (String)null);
        }
    }

    private static Object getExistingObject(Object service, MirrorableParam param, Map<String, Object> services)
        throws PersistencyServiceException {
        Object oldObject = null;
        if (service instanceof AssetPersistencyService) {
            oldObject = ((AssetPersistencyService) service).getAssetById(param.getTenantId(), param
                .getAccessibleResources(), param.getObjectId());
        } else if (service instanceof TagPersistencyService) {
            oldObject = ((TagPersistencyService) service).getTagById(param.getTenantId(), param
                .getAccessibleResources(), param.getObjectId());
        } else if (service instanceof AssetTypePersistencyService) {
            oldObject = ((AssetTypePersistencyService) service).getAssetTypeById(param.getTenantId(),
                param.getObjectId());
        } else if (service instanceof GroupPersistencyService) {
            oldObject = getExistingObject(param, services);
        } else if (service instanceof PlaceholderPersistencyService) {
            oldObject = ((PlaceholderPersistencyService) service).getPlaceholderForEventsById(param
                .getTenantId(), param.getObjectId());
        } else if (service instanceof TemplatePersistencyService) {
            oldObject = ((TemplatePersistencyService) service).getTemplateById(param.getTenantId(), param
                .getObjectId());
        } else if (service instanceof NetworkPersistencyService) {
            oldObject = getExistingObject(param, services);
        } else if (service instanceof AssetPolicyPersistencyService) {
            oldObject = ((AssetPolicyPersistencyService) service).getAssetUserPolicyById(param.getTenantId(),
                    param.getObjectId());
        }
        return oldObject;
    }

    public static Object getExistingObject(MirrorableParam param, Map<String, Object> services) throws
        PersistencyServiceException {
        Object existingObject = null;
        if (ObjectType.ASSET_GROUP.equals(param.getObjectType())) {
            existingObject = getExistingObjectForGroupUpdate(param, services);
        } else if (ObjectType.ASSET_GROUP_ITEM.equals(param.getObjectType()) && param.getPersistType() == Type.DELETE) {
            existingObject = getExistingObjectForGroupItemDelete(param, services);
        } else if (ObjectType.NETWORK.equals(param.getObjectType()) || ObjectType.EDGE.equals(param.getObjectType())) {
            existingObject = getExistingObjectForNetworkUpdate(param, services);
        }
        return existingObject;
    }

    private static Object getExistingObjectForGroupUpdate(MirrorableParam param, Map<String, Object> services) throws
        PersistencyServiceException {

        GroupPersistencyService service = (GroupPersistencyService) services.get(param.getObjectType());
        Object oldObject;
        if (param.getPersistType() == Type.UPDATE && param.getObjectId().equals(param.getArg())) {
            oldObject = getGroup(param, services, true);
        } else {
            oldObject = service.getAssetGroupById(param.getTenantId(), param
                .getObjectId());
        }
        return oldObject;
    }

    private static Object getExistingObjectForNetworkUpdate(MirrorableParam param, Map<String, Object> services)
        throws PersistencyServiceException {
        Object oldObject = null;
        NetworkPersistencyService service = (NetworkPersistencyService) services.get(param.getObjectType());
        if (ObjectType.NETWORK.equals(param.getObjectType())) {
            if (param.getPersistType() == Type.UPDATE && param.getObjectId().equals(param.getArg())) {
                oldObject = getNetwork(param, service, services, true);
            } else {
                oldObject = service.getNetworkById(param.getTenantId(),
                    param.getAccessibleResources(), param.getObjectId());
            }
        }
        if (ObjectType.EDGE.equals(param.getObjectType())) {
            oldObject = service.getNetworkEdgeById(param.getTenantId(), param.getAccessibleResources(),
                param.getObjectId());
        }
        return oldObject;
    }

    public static Object getExistingObjectForGroupItemDelete(MirrorableParam param,
        Map<String, Object> persistencyServices) throws PersistencyServiceException {

        Object[] args = param.getJoinPoint().getArgs();
        Map<String, Object> existingObj = new HashMap<>();

        if (ObjectType.ASSET_GROUP_ITEM.equals(param.getObjectType()) && param.getPersistType() == Type.DELETE) {
            String groupId = (String)args[2];
            GroupPersistencyService service = (GroupPersistencyService) persistencyServices.get(param.getObjectType());
            AssetGroup group = service.getAssetGroupById(param.getTenantId(), groupId);
            List<AssetGroupItem> items = service.getGroupItems(param.getTenantId(), param.getAccessibleResources(),
                groupId);
            AssetGroupItem obj =  items.stream().filter(i -> i.getId().equals(param.getObjectId()))
                .findAny().orElse(null);
            if (obj != null && group != null) {
                Sourceable model = getMemberOfGroup(param.getAccessibleResources(), param
                        .getTenantId(),
                    persistencyServices, group, obj);
                if (model != null) {
                    existingObj.put("name", group.getName());
                    existingObj.put(SOURCE_KEY, group.getSourceKey());
                    existingObj.put("member", model.getName());
                }
            }
        }
        return existingObj;
    }


    public static Map<String, Object> getNetwork(MirrorableParam param, NetworkPersistencyService service,
        Map<String, Object> services, boolean beforeUpdate) throws PersistencyServiceException {

        Map<String, Object> obj = new HashMap<>();
        Network network = service.getNetworkById(param.getTenantId(), param.getAccessibleResources(),
            param.getObjectId());
        if (Objects.nonNull(network)) {
            obj.put(SOURCE_KEY, network.getSourceKey());
            obj.put("name", network.getName());

            List<String> members = new ArrayList<>();

            List<Network> items = service.getNodesByNetworkId(param.getTenantId(), param.getAccessibleResources(),
                param.getObjectId(), new NetworkPredicate());

            members.addAll(items.stream()
                .filter(i -> i.getAsset() != null && !StringUtils.isEmpty(i.getAsset().getSourceKey()))
                .map(i -> i.getAsset().getSourceKey()).collect(Collectors.toList()));

            if (!beforeUpdate && param.getJoinPoint().getArgs().length > 3) {
                Object temp = param.getJoinPoint().getArgs()[3];
                if (temp instanceof List && !CollectionUtils.isEmpty((List) temp)
                    && ((List) temp).get(0) instanceof Asset) {
                    List<Asset> assets = (List<Asset>) temp;
                    List<String> sourceKeys = assets.stream().map(Asset::getSourceKey).collect(Collectors.toList());
                    members.addAll(sourceKeys);
                } else if (temp instanceof Set && !CollectionUtils.isEmpty((Set) temp)) {
                    Set<String> assetIds = (Set<String>) temp;
                    List<Asset> assets = ((AssetPersistencyService) services.get(ObjectType.ASSET))
                        .getAssetsByIds(param.getTenantId(), param.getAccessibleResources(), assetIds);
                    List<String> sourceKeys = assets.stream().map(Asset::getSourceKey).collect(Collectors.toList());
                    members.removeAll(sourceKeys);
                }
            }
            obj.put("nodes", members);
        }
        return obj;
    }

    public static Map<String, Object> getGroup(MirrorableParam param, Map<String, Object> persistencyServices,
        boolean beforeUpdate) throws PersistencyServiceException {

        Map<String, Object> obj = new HashMap<>();
        AssetGroup group = ((GroupPersistencyService)persistencyServices.get(param.getObjectType()))
            .getAssetGroupById(param.getTenantId(), param.getObjectId());
        if (Objects.nonNull(group)) {
            obj.put(SOURCE_KEY, group.getSourceKey());
            obj.put("name", group.getName());

            List<AssetGroupItem> items = new ArrayList<>();

            List<AssetGroupItem> temp = ((GroupPersistencyService)persistencyServices.get(param.getObjectType()))
                .getGroupItems(param.getTenantId(),param.getAccessibleResources(), param.getObjectId());
            items.addAll(temp);

            if (!beforeUpdate && param.getJoinPoint().getArgs().length > 3) {
                Object arg = param.getJoinPoint().getArgs()[3];
                if (arg instanceof AssetGroupItem) {
                    items.add((AssetGroupItem) arg);
                } else if (arg instanceof List) {
                    items.addAll((List<AssetGroupItem>) arg);
                }
            }

            List<Sourceable> groupObjects = getMembersOfGroup(param, persistencyServices, group, items);

            if (!CollectionUtils.isEmpty(groupObjects)) {
                List<String> memberNames = groupObjects.stream()
                    .filter(o -> o != null && o.getName() != null)
                    .map(Sourceable::getName)
                    .collect(Collectors.toList());
                obj.put("members", memberNames);
            }
        }
        return obj;
    }

    private static List<Sourceable> getMembersOfGroup(MirrorableParam param, Map<String, Object> persistencyServices,
        AssetGroup group, List<AssetGroupItem> items)
        throws PersistencyServiceException {
        List<Sourceable> groupObjects = new ArrayList<>();

        if (assetGroupTypes.contains(group.getCategory())) {
            for (AssetGroupItem item: items) {
                Sourceable model = ((AssetTypePersistencyService)persistencyServices.get(ObjectType.ASSET_TYPE))
                    .getAssetTypeById(param.getTenantId(), item.getObjectId());
                groupObjects.add(model);
            }
        }

        if (group.getCategory() == AssetGroupCategory.SITE || group.getCategory() == AssetGroupCategory
            .SEGMENT || group.getCategory() == AssetGroupCategory.ASSET
            || group.getCategory() == AssetGroupCategory.ENTERPRISE) {
            for (AssetGroupItem item: items) {
                Sourceable model = ((AssetPersistencyService)persistencyServices.get(ObjectType.ASSET))
                    .getAssetById(param.getTenantId(), param.getAccessibleResources(), item.getObjectId());
                groupObjects.add(model);
            }
        }

        if (group.getCategory() == AssetGroupCategory.TAG
            || group.getCategory() == AssetGroupCategory.TAG_CORRELATION) {
            for (AssetGroupItem item: items) {
                Sourceable model = ((TagPersistencyService)persistencyServices.get(ObjectType.TAG))
                    .getTagById(param.getTenantId(), param.getAccessibleResources(), item.getObjectId());
                groupObjects.add(model);
            }
        }
        return groupObjects;
    }

    public static Sourceable getMemberOfGroup(Collection<String> accessibleResources, String tenantId,
        Map<String, Object> persistencyServices, AssetGroup group, AssetGroupItem item)
        throws PersistencyServiceException {
        Sourceable model = null;
        if (assetGroupTypes.contains(group.getCategory())) {
            model = ((AssetTypePersistencyService)persistencyServices.get(ObjectType.ASSET_TYPE))
                .getAssetTypeById(tenantId, item.getObjectId());
        }
        if (group.getCategory() == AssetGroupCategory.SITE || group.getCategory() == AssetGroupCategory
            .SEGMENT || group.getCategory() == AssetGroupCategory.ASSET
            || group.getCategory() == AssetGroupCategory.ENTERPRISE) {
            model = ((AssetPersistencyService)persistencyServices.get(ObjectType.ASSET))
                .getAssetById(tenantId, accessibleResources, item.getObjectId());
        }
        if (group.getCategory() == AssetGroupCategory.TAG
            || group.getCategory() == AssetGroupCategory.TAG_CORRELATION) {
            model = ((TagPersistencyService)persistencyServices.get(ObjectType.TAG))
                .getTagById(tenantId, accessibleResources, item.getObjectId());
        }
        return model;
    }

    public static JsonNode getBizObjAsJsonNode(MirrorableParam param,  Map<String, Object> persistencyServices) {
        JsonNode node = null;
        try {
            boolean noBizObjPresentInParam = (ObjectType.ASSET_GROUP.equals(param.getObjectType())
                || ObjectType.NETWORK.equals(param.getObjectType()))
                && param.getPersistType() == Type.UPDATE && param.getObjectId().equals(param.getArg());
            if (noBizObjPresentInParam) {
                Object obj = getModifiedObject(param, persistencyServices);
                node = convertBizObjToJsonNode(obj);
            }
            if (!noBizObjPresentInParam && param.getPersistType() != Type.DELETE) {

                node = convertBizObjToJsonNode(param.getArg());
                processTemplateType(param, node, persistencyServices);
            }
            if (!StringUtils.isEmpty(param.getDeletedReason())) {
                node = convertBizObjToJsonNode(param);
            }
        } catch (Exception ex) {
            log.error("Error while converting to Json Node {} ", ex);
        }
        return node;
    }

    private static void processTemplateType(MirrorableParam param, JsonNode node,
        Map<String, Object> persistencyServices) {
        if (ObjectType.TEMPLATE.equals(param.getObjectType()) && param.getPersistType() == Type.UPDATE
            && node instanceof ObjectNode) {
            ((ObjectNode)node).put("placeholders", (String) null);
        }
        if (ObjectType.PLACEHOLDER.equals(param.getObjectType()) && param.getPersistType() == Type.UPDATE
            && node instanceof ObjectNode) {
            processPlaceholderAssociations(param, (ObjectNode) node, persistencyServices);
        }
    }

    private static void processPlaceholderAssociations(MirrorableParam param, ObjectNode node,
        Map<String, Object> persistencyServices) {
        Placeholder placeholder = (Placeholder)param.getArg();
        List<String> associations = new ArrayList<>();
        List<String> tagAssociations = new ArrayList<>();
        processPlaceholderAssociationTypes(param, persistencyServices, placeholder, associations);
        processPlaceholderTagAssociations(param, persistencyServices, placeholder, tagAssociations);
        node.put("placeholderTypes", (String) null);
        node.put("placeholderTagTypes", (String) null);
        node.put("placeholderTemplate", (String) null);
        node.put("placeholderTemplates", (String) null);
        node.put("placeholderGroupTagTypes", (String) null);
        if (!CollectionUtils.isEmpty(associations)) {
            node.put("associations", associations.toString());
        }
        if (!CollectionUtils.isEmpty(tagAssociations)) {
            node.put("tagAssociations", tagAssociations.toString());
        }
    }

    private static void processPlaceholderTagAssociations(MirrorableParam param,
        Map<String, Object> persistencyServices, Placeholder placeholder, List<String> tagAssociations) {
        List<PlaceholderTagType> tagTypes = placeholder.getPlaceholderTagTypes();
        if (!CollectionUtils.isEmpty(tagTypes)) {
            for (PlaceholderTagType type: tagTypes) {
                Sourceable sourceable = ((AssetTypePersistencyService)persistencyServices.get(ObjectType.ASSET_TYPE))
                    .getAssetTypeById(param
                        .getTenantId(), type.getTagTypeId());
                if (sourceable != null) {
                    tagAssociations.add(sourceable.getName());
                }
            }
        }

        List<PlaceholderGroupTagType> groupTypes = placeholder.getPlaceholderGroupTagTypes();
        if (!CollectionUtils.isEmpty(groupTypes)) {
            for (PlaceholderGroupTagType type: groupTypes) {
                Sourceable sourceable = ((GroupPersistencyService)persistencyServices.get(ObjectType.ASSET_GROUP))
                    .getAssetGroupById(param.getTenantId(), type.getGroupId());
                if (sourceable != null) {
                    tagAssociations.add(sourceable.getName());
                }
            }
        }
    }

    private static void processPlaceholderAssociationTypes(MirrorableParam param,
        Map<String, Object> persistencyServices, Placeholder placeholder, List<String> associations) {
        List<PlaceholderType> types = placeholder.getPlaceholderTypes();
        if (!CollectionUtils.isEmpty(types)) {
            for (PlaceholderType type: types) {
                Sourceable sourceable = ((AssetTypePersistencyService)persistencyServices.get(ObjectType.ASSET_TYPE))
                    .getAssetTypeById(param
                    .getTenantId(), type.getTypeId());
                if (sourceable != null) {
                    associations.add(sourceable.getName());
                }
            }
        }
        PlaceholderTemplate template = placeholder.getPlaceholderTemplate();
        if (template != null && !StringUtils.isEmpty(template.getTemplateId())) {
            Sourceable sourceable = ((TemplatePersistencyService)persistencyServices.get(ObjectType.TEMPLATE))
                .getTemplateById(param.getTenantId(), template.getTemplateId());
            if (sourceable != null) {
                associations.add(sourceable.getName());
            }
        }
    }

    public static Collection<AssetEvent> createEventsForDeleteTags(MirrorableParam param,
        TagPersistencyService tagService, Map<String, Object> services) {
        Collection<AssetEvent> events = new ArrayList<>();

        List<Tag> tags = tagService
            .getTagsForAsset(param.getTenantId(), param.getAccessibleResources(), param.getObjectId(), false,
                TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.ID).pageSize(-1).build());

        for (Tag tag : tags) {
            events.add(createEvent(param, Type.DELETE, ObjectType.TAG, tag.getId(), tagService, tag, services));
        }

        return events;
    }

    public static Collection<AssetEvent> createEventsForDeleteGroupItems(MirrorableParam param,
        GroupPersistencyService groupService, Map<String, Object> services)
        throws PersistencyServiceException {
        Collection<AssetEvent> events = new ArrayList<>();

        List<AssetGroupItem> items = groupService.getGroupItems(param.getTenantId(),
            param.getAccessibleResources(), param.getObjectId());

        for (AssetGroupItem item : items) {
            events.add(createEvent(param, Type.DELETE, ObjectType.ASSET_GROUP_ITEM, item.getId(), groupService, item,
                services));
        }

        return events;
    }

    public static Collection<AssetEvent> createEventsForDeleteAssetGroupAssociation(
        MirrorableParam param,
        AssetGroupAssociationPersistencyService associationPersistencyService, Map<String,Object> services)
        throws PersistencyServiceException {

        Collection<AssetEvent> events = new ArrayList<>();
        AssetGroupAssociation assetGroupAssociation = ((AssetGroupAssociation) param.getArg());
        List<AssetGroupAssociation> items =
            associationPersistencyService.getAssetGroupAssociationsByAssetAndGroupURI(
                param.getTenantId(), param.getAccessibleResources(),
                assetGroupAssociation.getGroupId(), assetGroupAssociation.getObjectId());

        for (AssetGroupAssociation item : items) {
            param.setObjectId(item.getObjectId());
            events.add(createEvent(param, Type.DELETE, ObjectType.ASSET_GROUP_ASSOCIATION, item.getId(),
                associationPersistencyService, item, services));
        }
        return events;
    }

    public static Collection<AssetEvent> createEventsForDeleteGroupAndGroupItems(MirrorableParam param,
        GroupPersistencyService groupService, Map<String, Object> services)
        throws PersistencyServiceException {
        Collection<AssetEvent> events = new ArrayList<>();

        List<AssetGroupItem> items = groupService
            .getGroupItems(param.getTenantId(), param.getAccessibleResources(), param.getObjectId());

        // murder
        for (AssetGroupItem item : items) {
            events.add(createEvent(param, Type.DELETE, ObjectType.ASSET_GROUP_ITEM, item.getId(), groupService, item,
                services));
        }
        // suicide
        events.add(createEvent(param, Type.DELETE, param.getObjectType(), param.getObjectId(), groupService,
            null, services));

        return events;
    }

    public static Collection<AssetEvent> createEventsForDeleteAssetRecursively(MirrorableParam param, Map<String,
        Object> services) {
        return createEvents(param, (AssetHierarchy) param.getResult(), services);
    }

    private static Collection<AssetEvent> createEvents(MirrorableParam param, AssetHierarchy assetHierarchy,
        Map<String, Object> services) {
        Collection<AssetEvent> events = new ArrayList<>();
        events.add(createEvent(param, Type.DELETE, assetHierarchy.getAsset().getCoreAssetTypeName().split("Type")[0],
            assetHierarchy.getAsset().getId(), null, assetHierarchy.getAsset(), services));
        // TODO: what lastModifiedDate should be passed via param???
        events.addAll(assetHierarchy.getAssetGroups().values().stream()
            .map(item -> createEvent(param, Type.DELETE, ObjectType.ASSET_GROUP_ITEM, item.getId(), null, item,
                services))
            .collect(Collectors.toList()));
        events.addAll(assetHierarchy.getTagGroups().values().stream()
            .flatMap(List::stream)
            .map(item -> createEvent(param, Type.DELETE, ObjectType.ASSET_GROUP_ITEM, item.getId(), null, item,
                services))
            .collect(Collectors.toList()));
        events.addAll(assetHierarchy.getTagCorrelations().values().stream()
            .flatMap(List::stream)
            .map(item -> createEvent(param, Type.DELETE, ObjectType.ASSET_GROUP_ITEM, item.getId(), null, item,
                services))
            .collect(Collectors.toList()));
        events.addAll(assetHierarchy.getTagCorrelations().keySet().stream()
            .map(item -> createEvent(param, Type.DELETE, ObjectType.TAG_CORRELATION, item.getId(), null, item,
                services))
            .collect(Collectors.toList()));
        events.addAll(assetHierarchy.getTags().stream()
            .map(tag -> createEvent(param, Type.DELETE, ObjectType.TAG, tag.getId(),null, tag, services))
            .collect(Collectors.toList()));
        for (AssetHierarchy childHierarchy : assetHierarchy.getChildren()) {
            events.addAll(createEvents(param, childHierarchy, services));
        }
        return events;
    }

    public static Collection<AssetEvent> createEventsForDeleteAssetTypeRecursively(MirrorableParam param,
        AssetTypePersistencyService assetTypeService, Map<String, Object> services) {
        Collection<AssetEvent> events = new ArrayList<>();

        List<AssetType> types = assetTypeService
            .findChildAssetTypes(param.getTenantId(), param.getObjectId(), true);

        // murder
        for (AssetType type : types) {
            events.add(createEvent(param, Type.DELETE, param.getObjectType(), type.getId(),
                                                                assetTypeService, param.getArg(), services));
        }
        // suicide
        events.add(createEvent(param, Type.DELETE, param.getObjectType(), param.getObjectId(),
                                                                assetTypeService, param.getArg(), services));

        return events;
    }

    public static Collection<AssetEvent> createEventsForDeleteTemplateAndPlaceholders(MirrorableParam param,
                                                 PlaceholderPersistencyService placeholderPersistencyService,
                                                 TemplatePersistencyService templatePersistencyService, Map<String,
        Object> services) {
        Collection<AssetEvent> events = new ArrayList<>();

        String tenantId = param.getTenantId();
        String templateId = param.getObjectId();
        //event for delete Template
        events.add(createEvent(param, Type.DELETE, param.getObjectType(), templateId,
                                            templatePersistencyService, null, services));
        List<Placeholder> placeholders = placeholderPersistencyService.getPlaceholdersByTemplateId(tenantId,
            templateId);
        if (!CollectionUtils.isEmpty(placeholders)) {
            for (Placeholder placeholder : placeholders) {
                param.setObjectId(placeholder.getId());
                events.add(createEvent(param, Type.DELETE, ObjectType.PLACEHOLDER, placeholder.getId(),
                    placeholderPersistencyService, placeholder, services));
            }
        }
        return events;
    }

    public static Collection<AssetEvent> createEventsForDeleteNetwork(MirrorableParam param,
        NetworkPersistencyService networkPersistencyService, Map<String, Object> persistencyServices) {
        Collection<AssetEvent> events = new ArrayList<>();
        List<Network> networks =  (List<Network>) param.getResult();
        if (!CollectionUtils.isEmpty(networks)) {
            for (Network network: networks) {
                events.add(createEvent(param, Type.DELETE, param.getObjectType(), network.getId(),
                    networkPersistencyService, network, persistencyServices));
                createEventForEdges(param, networkPersistencyService, persistencyServices, events, network);
            }
        }
        return events;
    }

    private static void createEventForEdges(MirrorableParam param, NetworkPersistencyService networkPersistencyService,
        Map<String, Object> persistencyServices, Collection<AssetEvent> events, Network network) {
        List<Edge> edges = network.getEdges();
        if (!CollectionUtils.isEmpty(edges)) {
            for (Edge edge: edges) {
                events.add(createEvent(param, Type.DELETE, ObjectType.EDGE, edge.getId(),
                    networkPersistencyService, edge, persistencyServices));
            }
        }
    }
}