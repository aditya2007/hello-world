/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.converter;

import java.sql.Array;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import org.postgresql.jdbc.PgArray;
import org.postgresql.util.PGobject;
import org.springframework.stereotype.Component;

/**
 * A converter to convert PostgresSQL UUID array to and from Java list of String.
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Jun 23, 2017
 * @since 1.0
 */
@Component
@Converter(autoApply = true)
public class ListToTextArrayAttributeConverter implements AttributeConverter<List<String>, Object> {

    @Override
    public Object convertToDatabaseColumn(List<String> attribute) {
        if (attribute == null) {
            return null;
        }
        try {
            PGobject out = new PGobject();
            out.setType("text[]");
            StringBuilder sb = new StringBuilder("{");
            sb.append(String.join(",", attribute));
            sb.append("}");
            out.setValue(sb.toString());
            return out;
        } catch (SQLException ex) {
            throw new IllegalArgumentException("Failed to convert " + String.join(",", attribute), ex);
        }
    }

    @Override
    public List<String> convertToEntityAttribute(Object dataValue) {
        try {
            if (dataValue == null) {
                return new ArrayList<>();
            }
            if (dataValue instanceof PgArray && "text".equals(((PgArray) dataValue).getBaseTypeName())) {
                Array arrayValues = (Array) dataValue;
                String[] values = (String[]) arrayValues.getArray();
                return Arrays.stream(values).collect(Collectors.toList());
            } else if (dataValue instanceof String[]) {
                String[] values = (String[]) dataValue;
                return Arrays.stream(values).collect(Collectors.toList());
            } else {
                throw new UnsupportedOperationException("Unsupported data type: " + dataValue.getClass().getTypeName());
            }
        } catch (SQLException ex) {
            throw new IllegalArgumentException("Failed to convert " + dataValue, ex);
        }
    }
}