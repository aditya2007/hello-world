/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.converter;

import java.beans.PropertyDescriptor;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.BeanWrapper;
import org.springframework.core.convert.ConversionService;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.support.JdbcUtils;

public class EntityBeanPropertyRowMapper<T> extends BeanPropertyRowMapper<T> {

    private final ConversionService conversionService;

    private static final Set<Class<?>> NOT_JDBC_SUPPORTED_TYPES = Collections.unmodifiableSet(new HashSet<>(
        Arrays.asList(JsonNode.class,List.class)));

    public EntityBeanPropertyRowMapper(Class<T> mappedClass, ConversionService conversionService) {
        super(mappedClass);
        this.conversionService = conversionService;
    }

    @Override
    protected void initBeanWrapper(BeanWrapper bw) {
        bw.setConversionService(conversionService);
    }

    @Override
    protected Object getColumnValue(ResultSet rs, int index, PropertyDescriptor pd) throws SQLException {
        Class<?> type = pd.getPropertyType();

        // each json property will cause a SQLException to be created by postgres jdbc but ignored by Spring.
        // fetching 2000 assets from APM cost 100-200 ms in creating the exceptions.
        return type == null || !NOT_JDBC_SUPPORTED_TYPES.contains(type)
            ? super.getColumnValue(rs, index, pd)
            : JdbcUtils.getResultSetValue(rs, index);
    }
}