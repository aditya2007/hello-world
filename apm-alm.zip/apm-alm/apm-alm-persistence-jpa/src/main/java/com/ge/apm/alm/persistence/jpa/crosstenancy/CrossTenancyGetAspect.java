/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.crosstenancy;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.BasicPredicate;
import com.ge.apm.alm.model.query.Sort;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.crosstenancy.CrossTenancyGet;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entitylistener.PostLoadHandler;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.common.support.RequestContext;

/**
 * @author Shu W. Yu 212614203
 * @version 1.0 Mar 06, 2018
 * @since 1.0
 */
@Slf4j
@Aspect
@Component
public class CrossTenancyGetAspect {

    @Autowired
    private List<PostLoadHandler<AssetInstanceEntity, AssetComponent>> postLoadHandlers;

    @Autowired
    private TransactionalRunner transactionalRunner;

    private final ThreadPoolExecutor executor = new ThreadPoolExecutor(4, 50, 30, TimeUnit.SECONDS,
        new LinkedBlockingQueue<>());

    @SuppressWarnings("unchecked")
    @Around("@annotation(com.ge.apm.alm.persistence.crosstenancy.CrossTenancyGet) && execution(* *(..))")
    public Object query(ProceedingJoinPoint joinPoint) throws Throwable {
        // during unit testing
        if (getContextTenantId() == null) {
            return joinPoint.proceed();
        }

        List<CrossTenancyCall> calls = createCrossTenancyCall(joinPoint);
        boolean needMerge = needMergeResults(calls, joinPoint);
        CrossTenancyCall contextTenantCall = calls.get(0);
        boolean deferPostLoading = needMerge && contextTenantCall.hasPaging();
        if (deferPostLoading) {
            calls.forEach(call -> call.setDeferComponentLoading(true));
        }

        long startTime = 0;
        if (needMerge) {
            startTime = System.currentTimeMillis();
            log.info("Start query crossing {} tenants", calls.size());
        }
        List<Future<Object>> futures = new ArrayList<>(calls.size());
        for (int i = 1; i < calls.size(); i++) {
            futures.add(executor.submit(calls.get(i)));
        }

        contextTenantCall.call();
        for (int i = 1; i < calls.size(); i++) {
            futures.get(i - 1).get();
        }

        Object ret;
        if (needMerge) {
            List<AssetInstanceEntity> merged = mergeResults(calls);
            if (deferPostLoading && !merged.isEmpty()) {
                invokePostLoader(calls, merged);
            }

            ret = merged;
            log.info("Done query crossing {} tenants in {} ms",  calls.size(), System.currentTimeMillis() - startTime);
        } else {
            ret = returnOneResult(calls);
        }

        return ret;
    }

    private Object returnOneResult(List<CrossTenancyCall> calls) {
        List<Object> results = calls.stream().filter(CrossTenancyCall::hasOp).map(CrossTenancyCall::getResults)
            .collect(Collectors.toList());
        if (results.size() != 1) {
            throw new IllegalStateException("Only one query result is expected but found " + results.size());
        }

        return results.get(0);
    }

    private boolean needMergeResults(List<CrossTenancyCall> calls, ProceedingJoinPoint joinPoint) {
        int count = 0;
        for (CrossTenancyCall call : calls) {
            if (call.hasOp()) {
                count++;
            }
        }
        if (count <= 1) {
            return false;
        }

        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        if (methodSignature.getMethod().getAnnotation(CrossTenancyGet.class).tenantified()) {
            throw new IllegalArgumentException("Cannot have have queries for more than one tenant on a tenantified "
                + "request.");

        }

        if (!List.class.isAssignableFrom(methodSignature.getReturnType())
            || !(calls.get(0).getBasicPredicate() instanceof AssetPredicate)) {
            throw new IllegalArgumentException("merging non-asset list is not supported");
        }

        return true;
    }

    @SuppressWarnings("unchecked")
    private List<CrossTenancyCall> createCrossTenancyCall(ProceedingJoinPoint joinPoint) {
        Set<String> tenants = getTenants();
        String contextTenantId = getContextTenantId();
        List<CrossTenancyCall> calls = new ArrayList<>(tenants.size());
        calls.add(new CrossTenancyCall(contextTenantId, true, joinPoint, transactionalRunner));
        getTenants().forEach(tnt -> {
            if (!tnt.equals(contextTenantId)) {
                calls.add(new CrossTenancyCall(tnt, false, joinPoint, transactionalRunner));
            }
        });

        return calls;
    }

    private String getContextTenantId() {
        return RequestContext.get(RequestContext.TENANT_UUID, String.class);
    }

    @SuppressWarnings("unchecked")
    private List<AssetInstanceEntity> mergeResults(List<CrossTenancyCall> calls) {
        List<AssetInstanceEntity> results = calls.stream()
            .map(call -> (List<AssetInstanceEntity>) call.getResults())
            .flatMap(Collection::stream)
            .collect(Collectors.toList());

        CrossTenancyCall contextTenantCall = calls.get(0);
        List<Sort> orders = contextTenantCall.getSorts();
        Sort order = orders.get(0);
        Comparator<Object> comparator = Comparator.comparing(p -> (Comparable<Object>) PropertyAccessorFactory
            .forBeanPropertyAccess(p).getPropertyValue(order.getProperty()));
        if (!order.isAsc()) {
            comparator = comparator.reversed();
        }
        for (int i = 1; i < orders.size(); i++) {
            Sort order2 = orders.get(i);
            comparator = comparator.thenComparing(p -> (Comparable<Object>) PropertyAccessorFactory
                .forBeanPropertyAccess(p).getPropertyValue(order2.getProperty()));
            if (!order2.isAsc()) {
                comparator = comparator.reversed();
            }
        }

        results = results.stream().sorted(comparator).collect(Collectors.toList());
        if (!contextTenantCall.hasPaging()) {
            return results;
        }

        BasicPredicate predicate = contextTenantCall.getBasicPredicate();
        List<AssetInstanceEntity> slice = new ArrayList<>(predicate.getPageSize());
        for (int i = predicate.getOffset(), ct = 0; i < results.size() && ct < predicate.getPageSize(); i++, ct++) {
            slice.add(results.get(i));
        }

        return slice;
    }

    @SuppressWarnings("unchecked")
    private void invokePostLoader(List<CrossTenancyCall> calls, List<AssetInstanceEntity> results)
        throws ExecutionException, InterruptedException {

        Map<String, List<AssetInstanceEntity>> assetsByTenant = results.stream().collect(Collectors.groupingBy
            (BaseDataModel::getTenantId));

        CrossTenancyCall contextTenantCall = calls.get(0);
        AssetPredicate predicate = (AssetPredicate) contextTenantCall.getBasicPredicate();
        List<Future<?>> futures = new ArrayList<>();
        for (int i = 1; i < calls.size(); i++) {
            CrossTenancyCall call = calls.get(i);
            List<AssetInstanceEntity> assets = assetsByTenant.get(AbstractCrossTenancyCall.formatTenantId(call
                .getTenantId()));
            if (assets != null) {
                CrossTenancyAssetComponentLoader loader = new CrossTenancyAssetComponentLoader(
                    call.getTenantId(), false,
                    QueryUtils.getComponentAccessibleResources(predicate, contextTenantCall.getAccessibleResourceIds()),
                    postLoadHandlers, assets, predicate.getAttributeSelectEnum(), predicate.getComponents(),
                    call, transactionalRunner);
                futures.add(executor.submit(loader));
            }
        }

        List<AssetInstanceEntity> assets = assetsByTenant.get(AbstractCrossTenancyCall.formatTenantId(
            contextTenantCall.getTenantId()));
        if (assets != null) {
            CrossTenancyAssetComponentLoader loader = new CrossTenancyAssetComponentLoader(
                contextTenantCall.getTenantId(), true,
                QueryUtils.getComponentAccessibleResources(predicate, contextTenantCall.getAccessibleResourceIds()),
                    postLoadHandlers, assets, predicate.getAttributeSelectEnum(), predicate.getComponents(),
                contextTenantCall, transactionalRunner);
            loader.run();
        }

        for (Future<?> future : futures) {
            future.get();
        }
    }

    @SuppressWarnings("unchecked")
    private Set<String> getTenants() {
        Map<String, ?> map = RequestContext.get(CrossTenancyCall.ALL_ACCESSIBLE_RESOURCES, Map.class);
        String contextTenant = getContextTenantId();
        if (map == null || map.isEmpty()) {
            return Collections.singleton(contextTenant);
        }

        final Set<String> tenantIds = new HashSet(map.keySet().size());
        map.forEach((tenant, acls) -> {
            if (acls != null) {
                tenantIds.add(tenant);
            }
        });

        if (!tenantIds.contains(contextTenant)) {
            tenantIds.add(contextTenant);
        }

        return Collections.unmodifiableSet(tenantIds);
    }
}
