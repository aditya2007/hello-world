/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entity;

import java.time.OffsetDateTime;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;

@Entity
@Table(name = "asset_event", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public final class AssetEventEntity extends AuditableEntity implements AssetEvent {

    @Column(name = "tenant_object_id")
    private String tenantObjectId;

    @Column(name = "event_type")
    @Enumerated(EnumType.STRING)
    private Type eventType;

    @Column(name = "object_id")
    private String objectId;

    @Column(name = "object_type")
    private String objectType;

    @Column(name = "object_last_modified_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd@HH:mm:ss.SSSZ")
    @Convert(converter = OffsetDateTimeAttributeConverter.class)
    private OffsetDateTime objectLastModifiedDate;

    @Column(name = "job_start_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd@HH:mm:ss.SSSZ")
    @Convert(converter = OffsetDateTimeAttributeConverter.class)
    private OffsetDateTime jobStartDate;

    @Column(name = "pre_modified_object")
    private JsonNode preModifiedObject;

    @Column(name = "modified_object")
    private JsonNode modifiedObject;

    @Column(name = "predix_pub_status")
    @Enumerated(EnumType.STRING)
    private EventStatus predixPubStatus;

    @Column(name = "eventhub_pub_status")
    @Enumerated(EnumType.STRING)
    private EventStatus eventhubPubStatus;

    @Column(name = "audit_pub_status")
    @Enumerated(EnumType.STRING)
    private EventStatus auditPubStatus;

    @Builder
    private AssetEventEntity(String id, String tenantId, String createdBy, String lastModifiedBy,
        Type eventType, String objectId, String objectType, OffsetDateTime objectLastModifiedDate,
        JsonNode preModifiedObject, JsonNode  modifiedBizObject, EventStatus predixPubStatus,
        EventStatus eventhubPubStatus, EventStatus auditPubStatus) {

        super(id, tenantId, createdBy, lastModifiedBy);

        this.tenantObjectId = tenantId + "|" + objectId;
        this.eventType = eventType;
        this.objectId = objectId;
        this.objectType = objectType;
        this.objectLastModifiedDate = objectLastModifiedDate;
        this.preModifiedObject = preModifiedObject;
        this.modifiedObject = modifiedBizObject;
        this.predixPubStatus = predixPubStatus;
        this.eventhubPubStatus = eventhubPubStatus;
        this.auditPubStatus = auditPubStatus;
    }

}
