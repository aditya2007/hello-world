/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.repository;

import javax.persistence.QueryHint;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;

import com.ge.apm.alm.persistence.jpa.entity.AssetTypeEntity;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.SYSTEM_TENANT_ID;
/*
Important: This interface should be ONLY visible to Persistency Service Impl for JPA. This is a powerful API,
therefore no one
should have access to since upper layers will do context and security checks.
 */

public interface AssetTypeRepository extends JpaRepository<AssetTypeEntity, String> {

    @QueryHints(value = { @QueryHint(name = org.eclipse.persistence.config.QueryHints.FLUSH, value = "FALSE") })
    @Query("select e from AssetTypeEntity e where (e.tenantId = ?1 or e.tenantId = '" + SYSTEM_TENANT_ID
        + "') and e.id = ?2")
    AssetTypeEntity findByTenantIdAndId(String tenantId, String id);
}
