/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.sql;

import java.text.MessageFormat;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.query.NetworkPredicate;
import com.ge.apm.alm.model.query.Operand;

/**
 * @author Albert H. Yu 212365823
 * @version 1.0 July 15, 2017
 * @since 1.0
 */
public final class NetworkSQL {

    private static final String AUDIT_COLUMNS = "created_by, created_date, last_modified_by, last_modified_date";

    private static final String A_AUDIT_COLUMNS
        = "a.created_by, a.created_date, a.last_modified_by, a.last_modified_date";

    private static final String ID_COLUMN = "id";

    // network
    private static final String NETWORK_BASIC_COLUMNS = "id, tenant_id, asset_id, source_key, name, description, "
        + AUDIT_COLUMNS;

    private static final String NETWORK_FULL_COLUMNS =
        "id, tenant_id, asset_id, source_key, name, description, attributes, " + AUDIT_COLUMNS;

    private static final String A_NETWORK_BASIC_COLUMNS =
        "a.id, a.tenant_id, a.asset_id, a.source_key, a.name, a.description, " + A_AUDIT_COLUMNS;

    private static final String A_NETWORK_FULL_COLUMNS =
        "a.id, a.tenant_id, a.asset_id, a.source_key, a.name, a.description, a.attributes, " + A_AUDIT_COLUMNS;

    private static final String BATCH_CREATE_NETWORK = "insert into apm_alm.network_node (" + NETWORK_FULL_COLUMNS
        + ") values " + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String CREATE_NETWORK = BATCH_CREATE_NETWORK + SQLConstants.RETURNING_FULL;

    private static final String SELECT_SINGLE_NETWORK_BY
        = "select {0} from apm_alm.network_node where tenant_id = ? and {1} = ?";

    private static final String SELECT_NETWORKS_IN
        = "select {0} from apm_alm.network_node where tenant_id = ? and {1} in ({2})";

    private static final String SELECT_ROOT_NETWORKS = "select {0} from apm_alm.network_node a where a.tenant_id = ? "
        + "and a.asset_id is null and not exists (select b.network_node_id from apm_alm" + ".network_hierarchy b where "
        + "b.tenant_id = a.tenant_id and b.network_node_id = a.id)";

    private static final String SELECT_PARENT_NETWORKS_OF_NODE =
        "select n.parent_network_id from apm_alm.network_hierarchy AS n "
            + "    INNER JOIN apm_alm.network_node AS node ON n.network_node_id = node.id "
            + "    INNER JOIN apm_alm.asset_instance AS {0} ON node.asset_id = {0}.id "
            + "  where asset.tenant_id = ''{1}''";

    private static final String SELECT_NETWORKS_BY_NODE =
        "select {0} from apm_alm.network_node a where a.tenant_id = ? " + "and a.asset_id is null and a.id in ( {1} )";

    private static final String UPDATE_NETWORK =
        "update apm_alm.network_node set asset_id = ?, source_key = ?, name = ?, description = ?," + " attributes = ?, "
            + "last_modified_by = ?, last_modified_date = ? where tenant_id = ? and id = ?";

    // asset node
    private static final String NETWORK_HIERARCHY_FULL_COLUMNS = "id, network_node_id, parent_network_id, tenant_id, "
        + AUDIT_COLUMNS;

    private static final String BATCH_CREATE_NETWORK_HIERARCHY_SQL = "insert into apm_alm.network_hierarchy ("
        + NETWORK_HIERARCHY_FULL_COLUMNS + ") values " + "(?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String SELECT_NODES_BY_ASSETS = "select " + NETWORK_FULL_COLUMNS
        + " from apm_alm.network_node where tenant_id = ? and asset_id in ({0})";

    private static final String SELECT_NODES_BY_ASSETS_AND_NETWORK_ID = "select " + A_NETWORK_FULL_COLUMNS
        + " from apm_alm.network_node a join apm_alm.network_hierarchy nh on a.id = "
        + "nh.network_node_id where a.tenant_id = ? and nh.parent_network_id = ''{0}'' and a.asset_id in ({1})";

    private static final String SELECT_NETWORKS_BY_PARENT =
        "select {0} from apm_alm.network_node where tenant_id = ? and id in (select " + "network_node_id from "
            + "apm_alm.network_hierarchy where tenant_id = '{1}' and parent_network_id = ?)";

    private static final String SELECT_NODES_BY_NETWORK_ID = "select " + A_NETWORK_FULL_COLUMNS
        + ", b.source_key as asset_source_key, " + " b.name as asset_name, b.description as asset_description, "
        + " b.super_types_array as asset_super_types_array, b.attributes as asset_attributes"
        + " from apm_alm.network_hierarchy as n " + " full outer join apm_alm.network_node as a"
        + "    on n.network_node_id = a.id" + " full outer join apm_alm.asset_instance as b"
        + "    on a.asset_id = b.id" + " where n.parent_network_id = ? ";

    private static final String ORDER_BY_A_ID = " order by a.id";

    // asset nodel edge
    private static final String EDGE_BASIC_COLUMNS =
        "id, name, description, tenant_id, source, target, direction, asset_id, " + AUDIT_COLUMNS;

    private static final String EDGE_WITH_ATTRIBUTES = EDGE_BASIC_COLUMNS + ", attributes ";

    private static final String EDGE_BY_ID = "select " + EDGE_WITH_ATTRIBUTES
        + " from apm_alm.edge where tenant_id = ? and id = ?";

    private static final String EDGE_FULL_COLUMNS =
        "id, name, description, tenant_id, source, target, direction, asset_id, attributes, " + AUDIT_COLUMNS;

    private static final String BATCH_CREATE_EDGE_SQL = "insert into apm_alm.edge (" + EDGE_FULL_COLUMNS
        + ") values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_EDGE = "update apm_alm.edge set name = ?, description = ?,"
        + " source = COALESCE(?, source), target = COALESCE(?, target), direction = ?, asset_id = COALESCE(?, "
        + "asset_id)," + " attributes = ?, last_modified_by = ?, last_modified_date = ? where tenant_id = ? and id = ?";

    private static final String SELECT_HYDRATED_EDGES_BY_PARENT_NETWORK_ID_SQL = "WITH hydrated_edge AS ("
        + "WITH edge_with_source_asset AS ("
        + " SELECT e.*, b.source_key edg_asset_source_key, b.name edg_asset_name, b.asset_type "
        + "     edg_asset_type, b.super_types_array edg_asset_super_types_array, n.name src_network_name, "
        + "     n.asset_id src_asset_id, a.source_key src_asset_source_key, a.name src_asset_name, "
        + "     a.asset_type src_asset_type, a.super_types_array src_asset_super_types_array " + " FROM apm_alm.edge e "
        + " JOIN apm_alm.network_node n " + "     ON e.tenant_id = n.tenant_id AND e.source = n.id "
        + " LEFT JOIN apm_alm.asset_instance a " + "     ON n.tenant_id = a.tenant_id AND n.asset_id = a.id "
        + " LEFT JOIN apm_alm.asset_instance b " + "     ON e.tenant_id = b.tenant_id AND e.asset_id = b.id "
        + " WHERE e.tenant_id = ''{0}''), " + "edge_with_target_asset AS ("
        + "   SELECT e.id, e.tenant_id, e.target, n.name tgt_network_name, n.asset_id tgt_asset_id, "
        + "     a.source_key tgt_asset_source_key, a.name tgt_asset_name, a.asset_type tgt_asset_type, "
        + "     a.super_types_array tgt_asset_super_types_array " + " FROM apm_alm.edge e " + " JOIN apm_alm"
        + ".network_node n " + "     ON e.tenant_id = n.tenant_id AND e.target = n.id "
        + " LEFT JOIN apm_alm.asset_instance a " + "     ON n.tenant_id = a.tenant_id AND n.asset_id = a.id "
        + " WHERE e.tenant_id = ''{0}'') "
        + "SELECT s.*, tgt_network_name, tgt_asset_id, tgt_asset_source_key, tgt_asset_name, "
        + "tgt_asset_type, tgt_asset_super_types_array " + "FROM edge_with_source_asset s " + "JOIN "
        + "edge_with_target_asset t " + " ON s.tenant_id = t.tenant_id AND s.id = t.id "
        + "WHERE s.tenant_id = ''{0}'') "
        + "SELECT DISTINCT he.id, he.tenant_id, he.name, he.description, he.direction, he.attributes, "
        + " nh.parent_network_id, he.asset_id, he.edg_asset_source_key, he.edg_asset_name, "
        + " he.edg_asset_type, he.edg_asset_super_types_array, he.source, he.src_network_name, "
        + " he.src_asset_id, he.src_asset_source_key, he.src_asset_name, he.src_asset_type, "
        + " he.src_asset_super_types_array, he.target, he.tgt_network_name, "
        + " he.tgt_asset_id, he.tgt_asset_source_key, he.tgt_asset_name, "
        + " he.tgt_asset_type, he.tgt_asset_super_types_array " + "FROM apm_alm.network_hierarchy nh JOIN "
        + "hydrated_edge he " + " ON nh.tenant_id = he.tenant_id "
        + "     AND (nh.network_node_id = he.source OR nh.network_node_id = he.target) "
        + "WHERE nh.tenant_id = ? AND nh.parent_network_id = ? ";

    private static final String SELECT_HYDRATED_EDGE_BY_PARENT_NETWORK_ID_AND_EDGE_ID_SQL =
        SELECT_HYDRATED_EDGES_BY_PARENT_NETWORK_ID_SQL + "AND he.id = ?";

    private static final String DELETE_EDGE_BY_ID = "DELETE from apm_alm.edge WHERE tenant_id = ? and id = ?";

    private static final String DELET_EDGE_BY_SOURCE_OR_TARGET_ID = "DELETE from apm_alm.edge where tenant_id = ? and"
        + " source IN ({0}) OR target IN ({1})";

    private static final String DELETE_NETWORK_BY_ID = "DELETE from apm_alm.network_node where tenant_id = ? AND id ="
        + " ?";

    private static final String DELETE_NETWORKS_IN = "DELETE from apm_alm.network_node where tenant_id = ? AND id in "
        + "({0})";

    private static final String DELETE_NETWORK_HIERARCHY_IN = "DELETE from apm_alm.network_hierarchy where tenant_id "
        + "= ? AND parent_network_id = ? and network_node_id IN ({0})";

    private NetworkSQL() {
    }

    public static String getCreateNetworkSQL() {
        return CREATE_NETWORK;
    }

    public static String getBatchCreateNetworkSQL() {
        return BATCH_CREATE_NETWORK;
    }

    public static String getUpdateNetworkSQL() {
        return UPDATE_NETWORK;
    }

    public static String getBatchCreateNetworkHierarchySQL() {
        return BATCH_CREATE_NETWORK_HIERARCHY_SQL;
    }

    public static String getBatchCreateEdgeSQL() {
        return BATCH_CREATE_EDGE_SQL;
    }

    public static String getOrderByAId() {
        return ORDER_BY_A_ID;
    }

    public static String getUpdateEdgeSQL() {
        return UPDATE_EDGE;
    }

    public static String getNetworkByIdOrSourceKeySQL(AttributeSelectEnum selectEnum, String column) {
        return MessageFormat.format(SELECT_SINGLE_NETWORK_BY, getSelectNetworkColumns(selectEnum), column);
    }

    public static String getNetworksByIdsSQL(String tenantId, Collection<String> accessibleResources,
        Set<String> networkIds, AttributeSelectEnum selectEnum) {
        String sql = MessageFormat.format(SELECT_NETWORKS_IN, getSelectNetworkColumns(selectEnum), "id",
            QueryUtils.getSqlListOfResources(networkIds));
        if (QueryUtils.isUber(accessibleResources) && !AssetInstanceSQL.hasApplicablePolicies(accessibleResources)) {
            return sql;
        }

        return sql + " and (asset_id is null or " + getAssetsACL(tenantId, accessibleResources) + ")";
    }

    public static String getDeleteEdgeByIdSQL(Collection<String> accessibleResources) {

        if (QueryUtils.isUber(accessibleResources)) {
            return DELETE_EDGE_BY_ID;
        }
        //TODO:Handle ACL
        return null;
    }

    public static String getDeletEdgeBySourceOrTargetId(Set<String> networkIds) {

        return MessageFormat.format(DELET_EDGE_BY_SOURCE_OR_TARGET_ID, QueryUtils.getSqlListOfResources(networkIds),
            QueryUtils.getSqlListOfResources(networkIds));
    }

    public static String getNetworkNodesByAssetsSQL(String tenantId, Collection<String> accessibleResources,
        Set<String> assetIds) {
        String sql = MessageFormat.format(SELECT_NODES_BY_ASSETS, QueryUtils.getSqlListOfResources(assetIds));
        if (QueryUtils.isNotUber(accessibleResources) || AssetInstanceSQL.hasApplicablePolicies(accessibleResources)) {
            sql += " and " + getAssetsACL(tenantId, accessibleResources);
        }
        return sql;
    }

    public static String getNetworkNodesByAssetsSQLForNetwork(String tenantId, String networkId,
        Collection<String> accessibleResources, Set<String> assetIds) {
        String sql = MessageFormat.format(SELECT_NODES_BY_ASSETS_AND_NETWORK_ID, networkId,
            QueryUtils.getSqlListOfResources(assetIds));
        if (QueryUtils.isNotUber(accessibleResources) || AssetInstanceSQL.hasApplicablePolicies(accessibleResources)) {
            sql += " and " + getAssetsACL(tenantId, accessibleResources);
        }
        return sql;
    }

    public static String getNodesByNetworkIdSQL(String tenantId, Collection<String> accessibleResources,
        NetworkPredicate queryPredicate) {
        String sql = SELECT_NODES_BY_NETWORK_ID;
        if (QueryUtils.isNotUber(accessibleResources) || AssetInstanceSQL.hasApplicablePolicies(accessibleResources)) {
            sql += " and " + getAssetsACL(tenantId, accessibleResources);
        }

        if (queryPredicate != null) {
            String[] values = queryPredicate.getNextPageSortValues();
            if (values != null && values.length == 1) {
                sql += " and a.id > '" + QueryUtils.escapeLiteral(values[0]) + "' ";
            }
        }

        sql += ORDER_BY_A_ID;
        if (queryPredicate != null) {
            sql += QueryUtils.getPagination(queryPredicate, false);
        }
        return sql;
    }

    public static String getNetworksBySourceKeysSQL(AttributeSelectEnum selectEnum, Set<String> sourceKeys) {
        return MessageFormat.format(SELECT_NETWORKS_IN, getSelectNetworkColumns(selectEnum), "source_key",
            QueryUtils.getSqlListOfResources(sourceKeys));
    }

    public static String getRootNetworksSQL(NetworkPredicate predicate) {
        String columns = AttributeSelectEnum.BASIC == predicate.getAttributeSelectEnum() ? A_NETWORK_BASIC_COLUMNS
            : A_NETWORK_FULL_COLUMNS;
        return MessageFormat.format(SELECT_ROOT_NETWORKS, columns);
    }

    public static String getNetworksByNodeSQL(NetworkPredicate predicate, String parentNetworksOfNodeSql) {
        String columns = AttributeSelectEnum.BASIC == predicate.getAttributeSelectEnum() ? A_NETWORK_BASIC_COLUMNS
            : A_NETWORK_FULL_COLUMNS;
        return MessageFormat.format(SELECT_NETWORKS_BY_NODE, columns, parentNetworksOfNodeSql);
    }

    public static String getParentNetworksOfNodeSQL(String assetInstanceTableAlias, String tenantId) {
        return MessageFormat.format(SELECT_PARENT_NETWORKS_OF_NODE, assetInstanceTableAlias, tenantId);
    }

    public static String getEdgesByParentNetworkIdSQL(String tenantId, Collection<String> accessibleResources,
        NetworkPredicate queryPredicate) {
        // TODO: handle ACL

        String sql = MessageFormat.format(SELECT_HYDRATED_EDGES_BY_PARENT_NETWORK_ID_SQL, tenantId);
        if (queryPredicate != null) {
            sql += QueryUtils.getPagination(queryPredicate, false);
        }
        return sql;
    }

    public static String getEdgeByIdForParentNetworkSQL(String tenantId, Collection<String> accesibleResources) {
        //TODO: handle ACL
        return MessageFormat.format(SELECT_HYDRATED_EDGE_BY_PARENT_NETWORK_ID_AND_EDGE_ID_SQL, tenantId);
    }

    public static String getEdgeByIdSQL(String tenantId, Collection<String> accesibleResources) {
        return EDGE_BY_ID;
    }

    public static String getDeleteNetworkSQL() {
        return DELETE_NETWORK_BY_ID;
    }

    public static String getDeleteNetworksSQL(Set<String> networkIds) {
        return MessageFormat.format(DELETE_NETWORKS_IN, QueryUtils.getSqlListOfResources(networkIds));
    }

    public static String getDeleteNetworkHierarchySQL(Set<String> networkIds) {
        return MessageFormat.format(DELETE_NETWORK_HIERARCHY_IN, QueryUtils.getSqlListOfResources(networkIds));
    }

    private static String getSelectNetworkColumns(AttributeSelectEnum selectEnum) {
        switch (selectEnum) {
            case ID:
                return ID_COLUMN;
            case BASIC:
                return NETWORK_BASIC_COLUMNS;
            case ATTRIBUTES:
            case FULL:
                return NETWORK_FULL_COLUMNS;
            default:
                throw new UnsupportedOperationException("Unsupproted attribute tselect: " + selectEnum);
        }
    }

    private static String getAssetsACL(String tenantId, Collection<String> accessibleResources) {
        StringBuilder aclClause = new StringBuilder();
        if (QueryUtils.isNotUber(accessibleResources) || AssetInstanceSQL.hasApplicablePolicies(accessibleResources)) {
            aclClause.append("asset_id in (").append(
                AssetInstanceSQL.getSelectWithAccessControlSqlForCollection(AttributeSelectEnum.ID, accessibleResources)
                    .replace("tenant_id = ?", "tenant_id = '" + tenantId + "'")).append(")");
        }
        return aclClause.toString();
    }

    public static String getFilterPredicate(NetworkPredicate predicate, String prefix) {
        if (predicate == null) {
            return "";
        }

        boolean missingChildPredicates = predicate.getChildOperand() == null || !CollectionUtils.isEmpty(
            predicate.getChildPredicates());
        assert missingChildPredicates : "Predicate with child operand must have non-empty list of child predicates.";

        List<String> expressions = QueryUtils.getEqualOrLikeFilterExpressions(predicate, predicate.getAttributes(),
            predicate.getReservedAttributes(), prefix);

        StringBuilder rslt = new StringBuilder();
        if (!CollectionUtils.isEmpty(expressions)) {
            rslt.append(QueryUtils.flattenExpressions(expressions, Operand.AND));
            if (predicate.getChildOperand() != null) {
                rslt.append(" ").append(predicate.getChildOperand().name().toLowerCase(Locale.getDefault()));
            }
        }

        if (!CollectionUtils.isEmpty(predicate.getChildPredicates())) {
            rslt.append(" (");
            int lastIndex = predicate.getChildPredicates().size() - 1;
            int i = 0;
            for (NetworkPredicate np : predicate.getChildPredicates()) {
                rslt.append(getFilterPredicate(np, prefix));
                if (np.getPeerOperand() != null && i < lastIndex) {
                    rslt.append(" ").append(np.getPeerOperand().name().toLowerCase(Locale.getDefault())).append(" ");
                }
                i++;
            }
            rslt.append(")");
        }

        if (rslt.length() == 0) {
            return "";
        }
        return rslt.insert(0, "(").append(")").toString();
    }

    public static String getFilterPredicate(NetworkPredicate predicate) {
        return getFilterPredicate(predicate, "");
    }
}
