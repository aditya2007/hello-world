/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.crosstenancy;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.concurrent.Callable;

import lombok.Getter;
import lombok.Setter;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;

import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.BasicPredicate;
import com.ge.apm.alm.model.query.Sort;
import com.ge.apm.alm.model.query.Sortable;
import com.ge.apm.alm.persistence.mirror.Accessible;
import com.ge.apm.common.support.RequestContext;

/**
 * @author Shu W. Yu 212614203
 * @version 1.0 Mar 07, 2018
 * @since 1.0
 */
@Getter
class CrossTenancyCall extends AbstractCrossTenancyCall implements Callable<Object> {

    private final ProceedingJoinPoint joinPoint;

    private BasicPredicate<?> basicPredicate = null;

    private Object results;

    private final TransactionalRunner transactionalRunner;

    @Setter
    @Getter
    private boolean deferComponentLoading;

    CrossTenancyCall(String tenantId, boolean contextTenant, ProceedingJoinPoint joinPoint, TransactionalRunner
        transactionalRunner) {
        super(tenantId, contextTenant, null);
        this.joinPoint = joinPoint;
        this.transactionalRunner = transactionalRunner;

        Object[] args = joinPoint.getArgs();
        if (args == null || args.length == 0 || !(args[0] instanceof String)) {
            throw new IllegalStateException("cross-tenant access must have tenantId as the first argument");
        }

        for (int i = 1; i < args.length; i++) {
            Object arg = args[i];
            if (arg instanceof BasicPredicate) {
                if (this.basicPredicate != null) {
                    throw new IllegalStateException("cross-tenant access can have at most one query predicate");
                }
                this.basicPredicate = (BasicPredicate<?>) arg;
            }
        }
    }


    @SuppressWarnings("unchecked")
    @Override
    public Object call() throws Exception {
        if (hasOp()) {
            setupCallContext();
            return transactionalRunner.invoke(this::doCall);
        }

        return null;
    }

    @SuppressWarnings({"unchecked", "squid:S00112"})
    private Object doCall() throws Exception {
        Object allAcls = getRequestContextMap().get(ALL_ACCESSIBLE_RESOURCES);
        try {
            MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
            results = methodSignature.getMethod().invoke(joinPoint.getTarget(), getArgs());

            saveContext();
            clean();

            return results;
        } catch (Exception e) {
            clean();
            throw unwrapException(e);
        } finally {
            getRequestContextMap().put(ALL_ACCESSIBLE_RESOURCES, allAcls);
            if (isContextTenant()) {
                RequestContext.put(ALL_ACCESSIBLE_RESOURCES, allAcls);
            }
        }
    }

    private Exception unwrapException(Exception ex) {
        Exception ret = ex;
        if (ex instanceof InvocationTargetException) {
            Throwable throwable = ((InvocationTargetException) ex).getTargetException();
            if (throwable instanceof Exception) {
                ret = (Exception) throwable;
            }
        }

        return ret;
    }

    private Object[] getArgs() {
        Object[] args = joinPoint.getArgs();
        Object[] newArgs = new Object[args.length];
        newArgs[0] = formatTenantId(getTenantId());
        for (int i = 1; i < args.length; i++) {
            Object arg = args[i];
            if (arg instanceof BasicPredicate) {
                newArgs[i] = getTenantAssetPredicate();
            } else if (isAccessible(i)) {
                newArgs[i] = getAccessibleResourceIds();
            } else {
                newArgs[i] = args[i];
            }
        }
        return newArgs;
    }

    private BasicPredicate<?> getTenantAssetPredicate() {
        if (basicPredicate == null) {
            return null;
        }

        BasicPredicate<?> newPredicate = basicPredicate.copy();
        if (deferComponentLoading && hasPaging()) {
            newPredicate.setPageSize(basicPredicate.getOffset() + basicPredicate.getPageSize());
            newPredicate.setOffset(0);
        }
        if (deferComponentLoading) {
            ((AssetPredicate) newPredicate).setComponents(null);
        }

        return newPredicate;
    }

    List<Sort> getSorts() {
        return basicPredicate instanceof Sortable ? ((Sortable) basicPredicate).getSorts() : null;
    }

    boolean hasPaging() {
        return basicPredicate != null && basicPredicate.getPageSize() > 0;
    }

    private boolean isAccessible(int paramIndex) {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Annotation[][] annotations = methodSignature.getMethod().getParameterAnnotations();
        for (Annotation annotation : annotations[paramIndex]) {
            if (annotation instanceof Accessible) {
                return true;
            }
        }

        return false;
    }
}
