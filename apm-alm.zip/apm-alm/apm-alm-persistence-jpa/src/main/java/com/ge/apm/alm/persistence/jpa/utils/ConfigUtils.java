/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author Saravanan Sankarasubbu - 212578721 on 3/25/18.
 */
@Component
@Slf4j
public final class ConfigUtils {

    public static boolean isOrderByIdDisabled; //NOSONAR

    @Autowired
    private ConfigUtils(@Value("${apm.asset.disable.orderbyid:false}") boolean disableOrderById) {
        isOrderByIdDisabled = disableOrderById; //NOSONAR
        log.info("Disable orderbyid = {}", isOrderByIdDisabled);
    }
}
