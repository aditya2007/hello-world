/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.sql;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.TemplatePredicate;

public final class TemplateSQL {

    private static final String DELETE_TEMPLATE = "delete from apm_alm.template ";
    private static final String ID_COLUMN = "select id from apm_alm.template ";
    private static final String ALL_COLUMNS = "select * from apm_alm.template ";
    private static final String BASIC_COLUMNS = "select id, tenant_id, source_key, name, description, state, status,"
        + " revision, default_value_expressions, created_by, created_date, last_modified_by,"
        + " last_modified_date from apm_alm.template";
    private static final String BASIC_COLUMNS_WITH_ATTRIBUTES =
        "select id, tenant_id, source_key, name, description, state, status,"
            + " revision, default_value_expressions, attributes, created_by, created_date, last_modified_by,"
            + " last_modified_date from apm_alm.template";
    private static final String WHERE_TENANT_ID = " where tenant_id = ? ";
    private static final String WHERE_TENANT_ID_AND_ID = WHERE_TENANT_ID + "and id = ? ";
    private static final String WHERE_TENANT_ID_AND_SOURCE_KEY = WHERE_TENANT_ID + "and lower(source_key) = ? ";
    private static final String WHERE_TENANT_ID_AND_SOURCE_KEYS_IN = WHERE_TENANT_ID + "and lower(source_key) in ({0})";
    private static final String BATCH_CREATE_SQL =
        "insert into apm_alm.template (id, source_key, name, description, tenant_id, "
            + "state, status, revision, default_value_expressions, attributes, created_by, last_modified_by) "
            + "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SEPARATOR = ",";

    private TemplateSQL() {
    }

    public static String getBatchCreateSQL() {
        return BATCH_CREATE_SQL;
    }

    public static String getDeleteTemplateByIdSQL() {
        return DELETE_TEMPLATE + WHERE_TENANT_ID + " and id = ? ";
    }

    public static String getSelectSingleObjectById(AttributeSelectEnum attributeSelectEnum) {
        return getSelectAttributes(attributeSelectEnum) + WHERE_TENANT_ID_AND_ID;
    }

    public static String getSelectSingleObjectBySourceKey(AttributeSelectEnum attributeSelectEnum) {
        return getSelectAttributes(attributeSelectEnum) + WHERE_TENANT_ID_AND_SOURCE_KEY;
    }

    public static String getSelectBySourceKeys(AttributeSelectEnum attributeSelectEnum, List<String> sourceKeys) {
        String listOfLowerCaseSrcKeys =
            QueryUtils.getSqlListOfResources(sourceKeys.stream().map(String::toLowerCase).collect(Collectors.toList()));
        return getSelectAttributes(attributeSelectEnum) + MessageFormat
            .format(WHERE_TENANT_ID_AND_SOURCE_KEYS_IN, listOfLowerCaseSrcKeys);
    }

    public static String getSelectCollectionObjects(AttributeSelectEnum attributeSelectEnum) {
        return getSelectAttributes(attributeSelectEnum) + WHERE_TENANT_ID;
    }

    public static String getSelectAttributes(AttributeSelectEnum attributeSelectEnum) {
        if (attributeSelectEnum == null) {
            return BASIC_COLUMNS;
        }

        String query;
        switch (attributeSelectEnum) {
            case ID:
                query = ID_COLUMN;
                break;
            case FULL:
                query = ALL_COLUMNS;
                break;
            case ATTRIBUTES:
                query = BASIC_COLUMNS_WITH_ATTRIBUTES;
                break;
            default:
                query = BASIC_COLUMNS;
                break;
        }
        return query;
    }

    public static String getFilterPredicate(TemplatePredicate templatePredicate) {
        if (templatePredicate == null) {
            return "";
        }

        // current template context
        List<String> expressions = new ArrayList<>();
        if (!StringUtils.isEmpty(templatePredicate.getReservedAttributes())) {
            if (templatePredicate.getReservedAttributes().get("state,key") != null) {
                String attributeValue = templatePredicate.getReservedAttributes().get("state,key");
                if (!StringUtils.isEmpty(attributeValue) && attributeValue.contains(",")) {
                    expressions.add(getFilterExpForReservedAttribute("state", attributeValue));
                } else {
                    expressions.add(QueryUtils.getFilterExpForTerm("state", attributeValue));
                }
                templatePredicate.getReservedAttributes().remove("state,key");
            }

            if (templatePredicate.getReservedAttributes().get("status,key") != null) {
                String attributeValue = templatePredicate.getReservedAttributes().get("status,key");
                if (!StringUtils.isEmpty(attributeValue) && attributeValue.contains(",")) {
                    expressions.add(getFilterExpForReservedAttribute("status", attributeValue));
                } else {
                    expressions.add(QueryUtils.getFilterExpForTerm("status", attributeValue));
                }
                templatePredicate.getReservedAttributes().remove("status,key");
            }
        }

        expressions
            .addAll(QueryUtils.getEqualOrLikeFilterExpressions(templatePredicate, templatePredicate.getAttributes(),
                templatePredicate.getReservedAttributes()));

        StringBuilder predicate = new StringBuilder();
        predicate.append(QueryUtils.flattenExpressions(expressions, Operand.AND));

        if (!CollectionUtils.isEmpty(templatePredicate.getChildPredicates())) {
            predicate.append(" (");
            int lastIndex = templatePredicate.getChildPredicates().size() - 1;
            int i = 0;
            for (TemplatePredicate tp : templatePredicate.getChildPredicates()) {
                predicate.append(getFilterPredicate(tp));
                if (tp.getPeerOperand() != null && i < lastIndex) {
                    predicate.append(" ").append(tp.getPeerOperand().name().toLowerCase(Locale.getDefault()))
                        .append(" ");
                }
                i++;
            }
            predicate.append(")");
        }

        if (predicate.length() == 0) {
            return "";
        }
        return predicate.insert(0, "(").append(")").toString();
        //return returnPredicate.length() > 0 ? " and " + returnPredicate : "";
    }

    private static String getFilterExpForReservedAttribute(String attributeName, String attributeValue) {
        // If reserved attribute wildcard value search returns multiple keys, then use IN clause to query DB.
        return "" + attributeName + " in (" + Arrays
            .stream(attributeValue.toLowerCase(Locale.getDefault()).split(SEPARATOR))
            .map(val -> "'" + val + "'").collect(Collectors.joining(SEPARATOR)) + ")";
    }
}
