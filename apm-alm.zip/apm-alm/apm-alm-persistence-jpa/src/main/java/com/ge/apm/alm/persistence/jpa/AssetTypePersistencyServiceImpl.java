/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.model.view.AssetTypeComponent;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.SuperTypeDoesNotExistsException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;
import com.ge.apm.alm.persistence.jpa.entity.AssetTypeEntity;
import com.ge.apm.alm.persistence.jpa.entitylistener.PostLoadHandler;
import com.ge.apm.alm.persistence.jpa.repository.AssetTypeRepository;
import com.ge.apm.alm.persistence.jpa.sql.AssetTypeSQL;
import com.ge.apm.alm.persistence.jpa.utils.TypeJsonUtils;

import static com.ge.apm.alm.persistence.jpa.utils.Validator.assertMatchingTenantId;

@Service
@Slf4j
@Transactional
public class AssetTypePersistencyServiceImpl implements AssetTypePersistencyService {

    @Autowired
    private DataSource dataSource;

    @Autowired
    private AssetTypeRepository assetTypeRepository;

    @Autowired
    private ConversionService conversionService;

    @Autowired
    private JsonbAttributeConverter jsonbAttributeConverter;

    @Autowired
    private ListToTextArrayAttributeConverter listToTextArrayAttributeConverter;

    @Autowired
    private OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter;

    @Autowired
    private List<PostLoadHandler<AssetTypeEntity, AssetTypeComponent>> postLoadHandlers;


    private EntityBeanPropertyRowMapper<AssetTypeEntity> assetTypeInstanceBeanPropertyRowMapper;

    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initializeConvertionService() {
        assetTypeInstanceBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(AssetTypeEntity.class,
            conversionService);
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public AssetType createAssetType(String tenantId, AssetType assetType) throws SuperTypeDoesNotExistsException {
        assertMatchingTenantId(tenantId, assetType.getTenantId());

        AssetTypeEntity assetTypeEntity = new AssetTypeEntity();
        BeanUtils.copyProperties(assetType, assetTypeEntity);
        //Denormalize
        AssetType superType = null;
        if (!StringUtils.isEmpty(assetType.getSuperTypeId())) {
            superType = assetTypeRepository.findByTenantIdAndId(tenantId, assetType.getSuperTypeId());
            if (superType == null) {
                throw new SuperTypeDoesNotExistsException(
                    "Super type " + assetType.getSuperTypeId() + " does not exist");
            }
        }
        List<String> superTypes = TypeJsonUtils.getDenormalizedSuperTypes(superType);
        assetTypeEntity.setSuperTypesArray(superTypes);
        assetTypeEntity.setTenantId(tenantId);
        return assetTypeRepository.saveAndFlush(assetTypeEntity);
    }

    @Override
    public int createAssetTypes(String tenantId, List<AssetType> assetTypes) {
        assertMatchingTenantId(tenantId, assetTypes.stream().map(AssetType::getTenantId).collect(Collectors.toSet()));

        // Recursively peel off types that either have no parents or have pre-existing parents
        // a type has pre-existing parent if its super_type_id does not match any type ID's the API is creating
        int rowsCreated = 0;
        List<AssetType> types = new ArrayList<>(assetTypes);
        while (!types.isEmpty()) {
            Set<String> idsToBeCreated = types.stream().map(AssetType::getId).collect(Collectors.toSet());
            Set<String> preexistingSuperTypeIds = types.stream().filter(
                t -> t.getSuperTypeId() != null && !idsToBeCreated.contains(t.getSuperTypeId())).map(
                AssetType::getSuperTypeId).collect(Collectors.toSet());

            // peel off types that have no parent or have existing parents so they can be created without FK violation
            List<AssetType> noOrHasPreexistingSuperTypes = types.stream().filter(
                t -> t.getSuperTypeId() == null || preexistingSuperTypeIds.contains(t.getSuperTypeId())).collect(
                Collectors.toList());
            rowsCreated += createAssetTypesWithNoOrExistingSuperTypes(tenantId, noOrHasPreexistingSuperTypes);
            // filter out those already created in the previous line
            types = types.stream().filter(t -> !(t.getSuperTypeId() == null || preexistingSuperTypeIds.contains(
                t.getSuperTypeId()))).collect(Collectors.toList());
        }

        return rowsCreated;
    }

    private int createAssetTypesWithNoOrExistingSuperTypes(String tenantId, final List<AssetType> types) {
        if (types.isEmpty()) {
            return 0;
        }
        Set<String> typeIds = types.stream().map(AssetType::getSuperTypeId).filter(Objects::nonNull).collect(
            Collectors.toSet());
        final Map<String, List<String>> superTypesByTypeIdWithTypeId = TypeJsonUtils.getSuperTypesByTypeIdWithTypeId(
            this, tenantId, typeIds);

        int[] updateCounts = jdbcTemplate.batchUpdate(AssetTypeSQL.getBatchCreateSQL(),
            new AssetTypeBatchCreatePreparedStatementSetter(tenantId, types, superTypesByTypeIdWithTypeId,
                jsonbAttributeConverter, listToTextArrayAttributeConverter, offsetDateTimeAttributeConverter));

        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public AssetType updateAssetType(String tenantId, AssetType assetType)
        throws SuperTypeDoesNotExistsException, ObjectNotFoundException {
        if (StringUtils.isEmpty(assetType.getId()) || assetTypeRepository.findByTenantIdAndId(tenantId,
            assetType.getId()) == null) {
            throw new ObjectNotFoundException(assetType.getId());
        }
        return createAssetType(tenantId, assetType);
    }

    @Override
    public int deleteAssetType(String tenantId, String assetTypeId) throws DataIntegrityViolationException {
        return deleteAssetType(tenantId, assetTypeId, false);
    }

    @Override
    public int deleteAssetTypeRecursively(String tenantId, String assetTypeId) throws DataIntegrityViolationException {
        return deleteAssetType(tenantId, assetTypeId, true);
    }

    private int deleteAssetType(String tenantId, String assetTypeId, boolean recursive)
        throws DataIntegrityViolationException {

        if (StringUtils.isEmpty(assetTypeId)) {
            throw new IllegalArgumentException("Asset Type ID cannot be null");
        }
        String deleteQuery;
        if (recursive) {
            deleteQuery = AssetTypeSQL.buildDeleteAssetTypeQueryRecursive(assetTypeId);
        } else {
            deleteQuery = AssetTypeSQL.buildDeleteAssetTypeQuery();
        }

        int rowsDeleted = 0;
        try { //TODO: Clean this up..
            if (recursive) {
                rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId);
            } else {
                rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, assetTypeId);
            }
        } catch (org.springframework.dao.DataIntegrityViolationException ex) {
            throw new DataIntegrityViolationException(
                "Asset Type has children or references to it. Hence cannot be deleted: " + assetTypeId, ex);
        }
        return rowsDeleted;
    }

    @Override
    public AssetType getAssetTypeById(String tenantId, String assetTypeId) {
        return assetTypeRepository.findByTenantIdAndId(tenantId, assetTypeId);
    }

    @Override
    public AssetType getAssetTypeById(String tenantId, String assetTypeId, Set<AssetTypeComponent> components) {
        AssetTypeEntity assetType = assetTypeRepository.findByTenantIdAndId(tenantId, assetTypeId);
        if (components != null && assetType != null) {
            postLoadHandlers.forEach(handler -> handler.postLoad(tenantId, null, assetType,
                AttributeSelectEnum.FULL, components));
        }

        return assetType;
    }

    @Override
    public Map<String, List<String>> getSuperTypesByIds(String tenantId, Set<String> assetTypeIds) {
        String query = AssetTypeSQL.getSelectSuperTypesByIds(assetTypeIds);
        return jdbcTemplate.query(query, assetTypeInstanceBeanPropertyRowMapper, tenantId).stream().collect(
            Collectors.toMap(AssetType::getId, AssetType::getSuperTypesArray));
    }

    @Override
    public AssetType getAssetTypeBySuperTypeAndId(String tenantId, String coreTypeName, String assetTypeId) {
        String typeId = OOTBCoreTypesIdLookup.valueOf(coreTypeName).getId();
        String query = AssetTypeSQL.getSpecificTypeSqlByTypeIdAndSuperTypesById(typeId);
        return getAssetType(tenantId, assetTypeId, query);
    }

    @Override
    public AssetType getAssetTypeBySuperTypeAndSourceKey(String tenantId, String coreTypeName, String sourceKey) {
        if (StringUtils.isEmpty(coreTypeName) || StringUtils.isEmpty(sourceKey)) {
            return null;
        }
        String typeId = OOTBCoreTypesIdLookup.valueOf(coreTypeName).getId();
        String query = AssetTypeSQL.getSpecificTypeSqlByTypeIdAndSuperTypesBySourceKey(typeId);
        return getAssetType(tenantId, sourceKey.toLowerCase(Locale.ENGLISH), query);
    }

    @Override
    public List<AssetType> getAssetTypesBySuperTypeAndSourceKeys(String tenantId, String coreTypeName,
        List<String> sourceKeys) {
        if (StringUtils.isEmpty(coreTypeName) || CollectionUtils.isEmpty(sourceKeys)) {
            return Collections.emptyList();
        }
        String typeId = OOTBCoreTypesIdLookup.valueOf(coreTypeName).getId();
        String query = AssetTypeSQL.getSpecificTypeSqlByTypeIdAndSuperTypesBySourceKeys(typeId, sourceKeys);

        return Collections.unmodifiableList(
            jdbcTemplate.query(query, assetTypeInstanceBeanPropertyRowMapper, tenantId));
    }

    private AssetType getAssetType(String tenantId, String idOrSrcKey, String query) {
        try {
            return jdbcTemplate.queryForObject(query, assetTypeInstanceBeanPropertyRowMapper, tenantId, idOrSrcKey);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { // NOSONAR
            log.debug("Asset Type not found with identifier: {}", idOrSrcKey);
            return null;
        }
    }

    @Override
    public List<AssetType> findChildAssetTypes(String tenantId, String superTypeId) {
        return findChildAssetTypes(tenantId, superTypeId, false);
    }

    @Override
    public List<AssetType> findChildAssetTypes(String tenantId, String superTypeId, boolean recursive) {
        return findChildAssetTypes(tenantId, superTypeId, recursive, null);
    }

    @Override
    public List<AssetType> findChildAssetTypes(String tenantId, String superTypeId, boolean recursive,
        TypePredicate childQueryPredicate) {
        List<AssetTypeEntity> types;
        if (recursive) {
            types = jdbcTemplate
                .query(AssetTypeSQL.getSelectChildAssetTypesRecursive(tenantId, superTypeId, childQueryPredicate),
                    assetTypeInstanceBeanPropertyRowMapper, tenantId);
        } else {
            types = jdbcTemplate
                .query(AssetTypeSQL.getSelectChildAssetTypes(tenantId, childQueryPredicate),
                    assetTypeInstanceBeanPropertyRowMapper, tenantId, superTypeId);
        }

        if (childQueryPredicate != null && !types.isEmpty()) {
            postLoadHandlers.forEach(handler -> handler.postLoad(tenantId, null, types,
                childQueryPredicate.getAttributeSelectEnum(), childQueryPredicate.getComponents()));
        }

        return Collections.unmodifiableList(types);
    }

    @Override
    public List<AssetType> findAllAssetTypes(String tenantId, TypePredicate queryPredicate) {
        String query = AssetTypeSQL.getSelectAndFilterPredicate(tenantId, queryPredicate);
        List<AssetTypeEntity> types = jdbcTemplate.query(query, assetTypeInstanceBeanPropertyRowMapper, tenantId);
        if (!types.isEmpty()) {
            postLoadHandlers.forEach(handler -> handler.postLoad(tenantId, null, types,
                queryPredicate.getAttributeSelectEnum(), queryPredicate.getComponents()));
        }

        return Collections.unmodifiableList(types);
    }

    @Override
    public List<AssetType> findAllAssetTypesWithNoPrefix(String tenantId, TypePredicate queryPredicate) {
        String query = AssetTypeSQL.getSelectWithNoPrefix(queryPredicate);
        List<AssetTypeEntity> types = jdbcTemplate.query(query, assetTypeInstanceBeanPropertyRowMapper, tenantId);
        if (!types.isEmpty()) {
            postLoadHandlers.forEach(handler -> handler.postLoad(tenantId, null, types,
                queryPredicate.getAttributeSelectEnum(), queryPredicate.getComponents()));
        }

        return Collections.unmodifiableList(types);
    }

    @Override
    public boolean isTypeASuperType(String tenantId, String superTypeId, String typeId) {
        if (StringUtils.isEmpty(superTypeId) || StringUtils.isEmpty(typeId)) {
            throw new IllegalArgumentException("Invalid empty super type or typeId.");
        }
        return allTypesAreCompatibleSuperType(tenantId, superTypeId, Collections.singleton(typeId));
    }

    @Override
    public boolean allTypesAreCompatibleSuperType(String tenantId, String superTypeId, Set<String> typeIds) {
        if (StringUtils.isEmpty(superTypeId) || typeIds.isEmpty()) {
            throw new IllegalArgumentException("Invalid empty super type or typeIds.");
        }
        String query = AssetTypeSQL.getCompatibleSuperTypeSQL(superTypeId, typeIds);
        List<AssetTypeEntity> types = jdbcTemplate.query(query, assetTypeInstanceBeanPropertyRowMapper, tenantId);
        return typeIds.size() == types.size();
    }
}
