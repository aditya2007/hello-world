/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.converter;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.ConversionService;
import org.springframework.jdbc.core.RowMapper;

import com.ge.apm.alm.model.Direction;
import com.ge.apm.alm.model.Edge;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.EdgeEntity;
import com.ge.apm.alm.persistence.jpa.entity.NetworkEntity;

/**
 * @author Albert H. Yu 212365823
 * @version 1.0 July 31, 2017
 * @since 1.0
 */
public class HydratedEdgeRowMapper implements RowMapper<Edge> {

    private final ConversionService conversionService;

    private final JsonbAttributeConverter jsonbAttributeConverter;

    private final ListToTextArrayAttributeConverter listToTextArrayAttributeConverter;

    public HydratedEdgeRowMapper(JsonbAttributeConverter jsonbAttributeConverter,
        ListToTextArrayAttributeConverter listToTextArrayAttributeConverter, ConversionService conversionService) {
        this.jsonbAttributeConverter = jsonbAttributeConverter;
        this.listToTextArrayAttributeConverter = listToTextArrayAttributeConverter;
        this.conversionService = conversionService;
    }

    @Override
    public Edge mapRow(ResultSet rs, int rowNum) throws SQLException {
        EdgeEntity ee = new EdgeEntity();

        ee.setId(rs.getString("id"));
        ee.setTenantId(rs.getString("tenant_id"));
        ee.setName(rs.getString("name"));
        ee.setDescription(rs.getString("description"));
        ee.setAssetId(rs.getString("asset_id"));
        ee.setDirection(Direction.valueOf(rs.getString("direction")));
        ee.setAttributes(jsonbAttributeConverter.convertToEntityAttribute(rs.getObject("attributes")));
        if (StringUtils.isNotEmpty(ee.getAssetId())) {
            ee.setAsset(AssetInstanceEntity.builder().id(ee.getAssetId()).sourceKey(
                rs.getString("edg_asset_source_key")).name(rs.getString("edg_asset_name")).assetType(
                rs.getString("edg_asset_type")).superTypesArray(
                listToTextArrayAttributeConverter.convertToEntityAttribute(rs.getObject("edg_asset_super_types_array")))
                .build());
        }
        ee.setSource(rs.getString("source"));
        ee.setSourceNetwork(NetworkEntity.builder().id(ee.getSource()).build());
        String srcAssetId = rs.getString("src_asset_id");
        if (StringUtils.isEmpty(srcAssetId)) {
            ee.getSourceNetwork().setName(rs.getString("src_network_name"));
        } else {
            ee.getSourceNetwork().setAsset(AssetInstanceEntity.builder().id(srcAssetId).sourceKey(
                rs.getString("src_asset_source_key")).name(rs.getString("src_asset_name")).assetType(
                rs.getString("src_asset_type")).superTypesArray(
                listToTextArrayAttributeConverter.convertToEntityAttribute(rs.getObject("src_asset_super_types_array")))
                .build());
        }
        ee.setTarget(rs.getString("target"));
        ee.setTargetNetwork(NetworkEntity.builder().id(ee.getTarget()).build());
        String tgtAssetId = rs.getString("tgt_asset_id");
        if (StringUtils.isEmpty(tgtAssetId)) {
            ee.getTargetNetwork().setName(rs.getString("tgt_network_name"));
        } else {
            ee.getTargetNetwork().setAsset(AssetInstanceEntity.builder().id(tgtAssetId).sourceKey(
                rs.getString("tgt_asset_source_key")).name(rs.getString("tgt_asset_name")).assetType(
                rs.getString("tgt_asset_type")).superTypesArray(
                listToTextArrayAttributeConverter.convertToEntityAttribute(rs.getObject("tgt_asset_super_types_array")))
                .build());
        }

        return ee;
    }
}
