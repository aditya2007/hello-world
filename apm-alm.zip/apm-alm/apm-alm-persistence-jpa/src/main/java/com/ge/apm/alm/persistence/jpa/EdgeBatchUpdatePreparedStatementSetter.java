/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.ge.apm.alm.model.Edge;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;


class EdgeBatchUpdatePreparedStatementSetter extends BaseBatchPreparedStatementSetter<Edge> {

    EdgeBatchUpdatePreparedStatementSetter(String tenantId, List<Edge> Edges,
        JsonbAttributeConverter jsonbAttributeConverter,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter) {
        super(tenantId, Edges, jsonbAttributeConverter, offsetDateTimeAttributeConverter);
    }

    @Override
    public void setValues(PreparedStatement ps, int i) throws SQLException {
        Edge instance = instances.get(i);
        int idx = 1;

        ps.setString(idx++, instance.getName());
        ps.setString(idx++, instance.getDescription());
        ps.setString(idx++, instance.getSource());
        ps.setString(idx++, instance.getTarget());
        ps.setString(idx++, instance.getDirection().toString());
        ps.setString(idx++, instance.getAssetId());
        ps.setObject(idx++, jsonbAttributeConverter.convertToDatabaseColumn(instance.getAttributes()));
        ps.setString(idx++, instance.getLastModifiedBy());
        ps.setTimestamp(idx++, now);
        ps.setString(idx++, tenantId);
        ps.setString(idx++, instance.getId());
        //setting computed values back to bean for client's convenience
        setLastModifiedDate(instance);
    }
}