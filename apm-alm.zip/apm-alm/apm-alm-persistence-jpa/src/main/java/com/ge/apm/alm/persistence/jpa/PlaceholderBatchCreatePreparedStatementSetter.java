/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;

import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderEntity;

class PlaceholderBatchCreatePreparedStatementSetter implements BatchPreparedStatementSetter {

    private final String tenantId;
    private final List<PlaceholderEntity> placeholderEntities;
    private final JsonbAttributeConverter jsonbAttributeConverter;

    PlaceholderBatchCreatePreparedStatementSetter(String tenantId, List<PlaceholderEntity> placeholderEntities,
        JsonbAttributeConverter jsonbAttributeConverter) {
        this.tenantId = tenantId;
        this.placeholderEntities = placeholderEntities;
        this.jsonbAttributeConverter = jsonbAttributeConverter;
    }

    @Override
    public void setValues(PreparedStatement ps, int index) throws SQLException {
        PlaceholderEntity entity = placeholderEntities.get(index);
        ps.setString(1, entity.getId());
        ps.setString(2, entity.getSourceKey());
        ps.setString(3, entity.getName());
        ps.setString(4, entity.getDescription());
        ps.setString(5, tenantId);
        ps.setString(6, entity.getTemplateId());
        ps.setString(7, entity.getPartPositionNumber());
        ps.setString(8, entity.getParentId());
        ps.setObject(9, jsonbAttributeConverter.convertToDatabaseColumn(entity.getAttributes()));
        ps.setString(10, entity.getCreatedBy());
        ps.setString(11, entity.getLastModifiedBy());
    }

    @Override
    public int getBatchSize() {
        return placeholderEntities.size();
    }
}
