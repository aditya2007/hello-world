/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.sql;

import java.util.List;

import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.query.NotesPredicate;
import com.ge.apm.alm.model.query.Operand;

public final class NotesSQL {

    private static final String DELETE_NOTES = "delete from apm_alm.notes ";
    private static final String ALL_COLUMNS = "select * from apm_alm.notes ";
    private static final String WHERE_TENANT_ID = " where tenant_id = ? ";
    private static final String WHERE_TENANT_ID_AND_ID = " where tenant_id = ? and id = ? ";
    private static final String BATCH_CREATE_SQL = "insert into apm_alm.notes (id, name, content, tenant_id, "
        + " created_by, last_modified_by) values (?, ?, ?, ?, ?, ?)";

    private static final String DELETE_NOTES_BY_TEMPLATE_ID =
        "delete from apm_alm.notes n " +
            " where n.id IN (select tn.notes_id from apm_alm.template_notes tn, apm_alm.template t "
            + " where t.tenant_id = ? and t.id = ? and tn.template_id = t.id)";

    private static final String DELETE_NOTES_BY_TEMPLATE_SOURCE_KEY =
        "delete from apm_alm.notes n " +
            " where n.id IN (select tn.notes_id from apm_alm.template_notes tn, apm_alm.template t "
            + " where t.tenant_id = ? and lower(t.source_key) = ? and tn.template_id = t.id)";

    private NotesSQL() {
    }

    public static String getBatchCreateSQL() {
        return BATCH_CREATE_SQL;
    }

    public static String getDeleteByIdSQL() {
        return DELETE_NOTES + WHERE_TENANT_ID_AND_ID;
    }

    public static String getDeleteByTemplateIdSQL() {
        return DELETE_NOTES_BY_TEMPLATE_ID;
    }

    public static String getDeleteByTemplateSourceKeySQL() {
        return DELETE_NOTES_BY_TEMPLATE_SOURCE_KEY;
    }

    public static String getSelectSingleObjectById() {
        return ALL_COLUMNS + WHERE_TENANT_ID_AND_ID;
    }

    public static String getSelectCollectionObjects() {
        return ALL_COLUMNS + WHERE_TENANT_ID;
    }

    public static String getFilterPredicate(NotesPredicate notesPredicate) {
        if (notesPredicate == null) {
            return "";
        }

        // current template context
        List<String> expressions = QueryUtils.getEqualOrLikeFilterExpressions(notesPredicate, null, null);
        if (!StringUtils.isEmpty(notesPredicate.getContent())) {
            expressions.add(QueryUtils.getFilterExpForTerm("content", notesPredicate.getContent()));
        }

        String predicate = QueryUtils.flattenExpressions(expressions, Operand.AND);
        return predicate.length() > 0 ? " and " + predicate : "";
    }
}
