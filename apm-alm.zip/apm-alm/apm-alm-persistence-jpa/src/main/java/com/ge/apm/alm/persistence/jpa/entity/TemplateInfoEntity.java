package com.ge.apm.alm.persistence.jpa.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.ge.apm.alm.model.TemplateInfo;

@Getter
@Setter
@NoArgsConstructor
public class TemplateInfoEntity implements TemplateInfo {

    private String assetId;
    private String templateId;
    private String ppn;
    private String embeddedTemplateId;
    private String embeddedPpn;
    private Boolean conformanceFlag;
}