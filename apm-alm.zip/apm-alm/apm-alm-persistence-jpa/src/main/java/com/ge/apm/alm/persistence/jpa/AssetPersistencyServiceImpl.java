/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetHierarchy;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.GroupPredicate;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.crosstenancy.CrossTenancyGet;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.config.EntityAuditor;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;
import com.ge.apm.alm.persistence.jpa.entity.AssetGroupEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceGroupItemEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagCorrelationItemEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceGroupItemEntity;
import com.ge.apm.alm.persistence.jpa.entitylistener.PostLoadHandler;
import com.ge.apm.alm.persistence.jpa.repository.AssetInstanceRepository;
import com.ge.apm.alm.persistence.jpa.sql.AssetInstanceSQL;
import com.ge.apm.alm.persistence.jpa.sql.GroupSQL;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.sql.TagInstanceSQL;
import com.ge.apm.alm.persistence.jpa.utils.AssetHierarchyImpl;
import com.ge.apm.alm.persistence.jpa.utils.TypeJsonUtils;
import com.ge.apm.alm.persistence.mirror.Accessible;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID;
import static com.ge.apm.alm.persistence.jpa.utils.Validator.assertMatchingTenantId;

@Service
@Slf4j
@PropertySource("classpath:alm_jpa.properties")
public class AssetPersistencyServiceImpl implements AssetPersistencyService {

    private static final String PARENT_DOES_NOT_EXIST = "Parent asset %s does not exist";

    private static final String ASSET_DOES_NOT_EXIST = "Asset %s does not exist";

    private static final String AND = " and ";

    private final Map<AssetGroupCategory, EntityBeanPropertyRowMapper> rowMapperMap = new EnumMap<>(
        AssetGroupCategory.class);

    @Autowired
    private DataSource dataSource;

    @Autowired
    private AssetInstanceRepository assetInstanceRepository;

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private GroupPersistencyService groupPersistencyService;

    @Autowired
    private ConversionService conversionService;

    @Autowired
    private List<PostLoadHandler<AssetInstanceEntity, AssetComponent>> postLoadHandlers;

    @Autowired
    private JsonbAttributeConverter jsonbAttributeConverter;

    @Autowired
    private ListToTextArrayAttributeConverter listToTextArrayAttributeConverter;

    @Autowired
    private EntityAuditor entityAuditor;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    @Autowired
    private OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter;

    private EntityBeanPropertyRowMapper<AssetInstanceEntity> assetInstanceBeanPropertyRowMapper;

    private EntityBeanPropertyRowMapper<TagInstanceEntity> tagInstanceBeanPropertyRowMapper;

    private EntityBeanPropertyRowMapper<AssetGroupEntity> groupBeanPropertyRowMapper;

    private JdbcTemplate jdbcTemplate;

    @Value("${apm.alm.persistence.jpa.maxFindChildAssetRetry}")
    private int maxFindChildAssetRetry = 4;

    @PostConstruct
    public void initializeConvertionService() {
        jdbcTemplate = new JdbcTemplate(dataSource);
        assetInstanceBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(AssetInstanceEntity.class,
            conversionService);
        tagInstanceBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(TagInstanceEntity.class,
            conversionService);
        groupBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(AssetGroupEntity.class, conversionService);
        EntityBeanPropertyRowMapper<AssetInstanceGroupItemEntity> assetItemBeanPropertyRowMapper
            = new EntityBeanPropertyRowMapper<>(AssetInstanceGroupItemEntity.class, conversionService);
        EntityBeanPropertyRowMapper<TagInstanceGroupItemEntity> tagItemBeanPropertyRowMapper
            = new EntityBeanPropertyRowMapper<>(TagInstanceGroupItemEntity.class, conversionService);
        EntityBeanPropertyRowMapper<TagCorrelationItemEntity> tagCorrelationItemBeanPropertyRowMapper
            = new EntityBeanPropertyRowMapper<>(TagCorrelationItemEntity.class, conversionService);
        rowMapperMap.put(AssetGroupCategory.ASSET, assetItemBeanPropertyRowMapper);
        rowMapperMap.put(AssetGroupCategory.TAG, tagItemBeanPropertyRowMapper);
        rowMapperMap.put(AssetGroupCategory.TAG_CORRELATION, tagCorrelationItemBeanPropertyRowMapper);
    }

    // Create API's
    @Override
    @Transactional
    public Asset createAsset(String tenantId, Collection<String> accessibleResources, Asset asset)
        throws ObjectNotFoundException {
        return createAsset(tenantId, accessibleResources, asset.getParentId(), asset);
    }

    @Override
    @Transactional
    public Asset createAsset(String tenantId, Collection<String> accessibleResources, String parentId, Asset child)
        throws ObjectNotFoundException {
        assertMatchingTenantId(tenantId, child.getTenantId());
        Asset parentObject = findParentAssetWithLock(tenantId, accessibleResources, parentId, true);
        //denormalizing the parent ids
        List<String> parentAncestors = getMyAncestors(parentObject);
        //denormalizing type information
        List<String> superTypes = TypeJsonUtils.getSuperTypes(assetTypePersistencyService, tenantId,
            child.getAssetType());

        AssetInstanceEntity assetInstanceEntity;
        if (child instanceof AssetInstanceEntity) {
            assetInstanceEntity = (AssetInstanceEntity) child;
        } else {
            assetInstanceEntity = new AssetInstanceEntity();
            BeanUtils.copyProperties(child, assetInstanceEntity);
        }
        assetInstanceEntity.setTenantId(tenantId);
        assetInstanceEntity.setParentId(parentId);
        assetInstanceEntity.setAncestorsArray(parentAncestors);
        assetInstanceEntity.setSuperTypesArray(superTypes);
        return assetInstanceRepository.saveAndFlush(assetInstanceEntity);
    }

    @Override
    @Transactional
    public int createAssets(final String tenantId, Collection<String> accessibleResources, List<Asset> assets)
        throws PersistencyServiceException {
        assertMatchingTenantId(tenantId, assets.stream().map(Asset::getTenantId).collect(Collectors.toSet()));
        if (QueryUtils.isNotUber(accessibleResources)) {
            Set<String> parentIds = assets.stream().map(Asset::getParentId).collect(Collectors.toSet());
            for (String parentId : parentIds) {
                if (parentId != null && findAssetById(tenantId, accessibleResources, parentId, null, false) == null) {
                    throw new ObjectNotFoundException(String.format(PARENT_DOES_NOT_EXIST, parentId));
                } else if (parentId == null) {
                    //if parent is null, it means non uber is attempting to create assets at
                    // tenant level
                    throw new PersistencyServiceException(
                        "Assets without parent cannot be added with constrained hierarchies");
                }
            }
        }

        // initialize denormalized ancestors and grow it as we go for proper denormalization of
        // each asset
        final Map<String, List<String>> ancestorsByParentId = getAncestorsByParentIds(tenantId, accessibleResources,
            assets);

        // Recursively peel off assets that either have no parents or have pre-existing parents
        // an asset has pre-existing parent if its parent ID's is not part of the asset ID's the
        // API is creating
        int rowsCreated = 0;
        List<Asset> data = new ArrayList<>(assets);
        while (!data.isEmpty()) {
            Set<String> idsToBeCreated = data.stream().map(Asset::getId).collect(Collectors.toSet());
            Set<String> preexisingParentIds = data.stream().filter(
                a -> a.getParentId() != null && !idsToBeCreated.contains(a.getParentId())).map(Asset::getParentId)
                .collect(Collectors.toSet());

            List<Asset> noOrHasPreexistingParents = data.stream().filter(
                a -> a.getParentId() == null || preexisingParentIds.contains(a.getParentId())).collect(
                Collectors.toList());
            rowsCreated += createAssetsWithNoOrExistingParents(tenantId, noOrHasPreexistingParents,
                ancestorsByParentId);
            data = data.stream().filter(a -> a.getParentId() != null && !preexisingParentIds.contains(a.getParentId()))
                .collect(Collectors.toList());
        }

        return rowsCreated;
    }

    private int createAssetsWithNoOrExistingParents(String tenantId, final List<Asset> assets,
        Map<String, List<String>> ancestorsByParentId) {

        if (assets.isEmpty()) {
            return 0;
        }
        Set<String> typeIds = assets.stream().map(Asset::getAssetType).collect(Collectors.toSet());
        final Map<String, List<String>> superTypesByTypeIdWithTypeId = TypeJsonUtils.getSuperTypesByTypeIdWithTypeId(
            assetTypePersistencyService, tenantId, typeIds);

        int[] updateCounts = jdbcTemplate.batchUpdate(AssetInstanceSQL.getBatchCreateSQL(),
            new AssetBatchCreatePreparedStatementSetter(tenantId, assets, ancestorsByParentId,
                superTypesByTypeIdWithTypeId, jsonbAttributeConverter, listToTextArrayAttributeConverter,
                offsetDateTimeAttributeConverter));

        return Arrays.stream(updateCounts).sum();
    }

    // Update API's
    @Override
    @Transactional
    public Asset updateAsset(String tenantId, Collection<String> accessibleResources, Asset asset)
        throws ObjectNotFoundException {
        assertMatchingTenantId(tenantId, asset.getTenantId());
        Asset existingObject = findAssetById(tenantId, accessibleResources, asset.getId(), AttributeSelectEnum.FULL,
            null, false, true, false);
        if (StringUtils.isEmpty(asset.getId()) || existingObject == null) {
            throw new ObjectNotFoundException(asset.getId());
        }
        String existingParentId = existingObject.getParentId();
        if (Objects.equals(existingParentId, asset.getParentId())) {
            //this is not a move.. just an update
            return updateAsset2(tenantId, accessibleResources, asset, false, false);
        }
        //This is move from one parent to another..
        //get original parents from asset to be moved - before updating it with new parents
        List<String> idsToBeRemoved = new ArrayList<>();
        if (existingParentId != null) {
            List<String> existingObjectAncestors = existingObject.getAncestorsArray();
            idsToBeRemoved.addAll(existingObjectAncestors);
        }

        //this update to asset involves changing the parent id, meaning moving to a new hierarchy
        // which the user may not have access to. So it would throw authorization exception
        Asset updatedAsset = updateAsset2(tenantId, accessibleResources, asset, true, true);
        if (updatedAsset != null) {
            denormalizeChildren(tenantId, accessibleResources, updatedAsset, idsToBeRemoved);
        }

        return updatedAsset;
    }

    private void denormalizeChildren(String tenantId, Collection<String> accessibleResources, Asset updatedAsset,
        List<String> idsToBeRemoved) {
        List<String> nodes = updatedAsset.getAncestorsArray();
        List<String> idsToBeAdded = new ArrayList<>(nodes);

        Collections.reverse(idsToBeAdded); //reversing it so that we insert immediate parent first

        List<Asset> assets = findChildAssetsWithLocks(tenantId, accessibleResources, updatedAsset.getId());
        for (Asset childAsset : assets) {
            //updating child asset's ancestors..
            for (String nodeToRemoved : idsToBeRemoved) {
                if (childAsset.getAncestorsArray().get(0).equals(nodeToRemoved)) {
                    childAsset.getAncestorsArray().remove(0);
                } else {
                    throw new IllegalStateException("Denormalization is not in expected order");
                }
            }
            for (String idToBeAdded : idsToBeAdded) {
                childAsset.getAncestorsArray().add(0, idToBeAdded);
            }
        }

        int[] updateCounts = jdbcTemplate.batchUpdate(AssetInstanceSQL.getBatchUpdateAncestorsSql(),
            new AssetBatchUpdateAncestorsPreparedStatementSetter(tenantId, assets, updatedAsset.getLastModifiedBy(),
                listToTextArrayAttributeConverter, offsetDateTimeAttributeConverter));
        log.debug("Number of children moved to new hierarchy " + updatedAsset.getParentId() + " : " + Arrays
            .stream(updateCounts).sum());
    }

    private Asset updateAsset2(String tenantId, Collection<String> accessibleResources, Asset child,
        boolean checkIfParentAccessible, boolean selectForUpdate) throws ObjectNotFoundException {

        Asset parentObject = findParentAssetWithLock(tenantId,
            checkIfParentAccessible ? accessibleResources : Collections.emptyList(), child.getParentId(),
            selectForUpdate);
        List<String> superTypes = TypeJsonUtils.getSuperTypes(assetTypePersistencyService, tenantId,
            child.getAssetType());
        final Map<String, List<String>> superTypesByTypeIdWithTypeId = new HashMap<>();
        superTypesByTypeIdWithTypeId.put(child.getAssetType(), superTypes);

        Map<String, List<String>> ancestorsByParentId = new HashMap<>();
        if (parentObject != null) {
            ancestorsByParentId.put(parentObject.getId(), parentObject.getAncestorsArray());
        }
        jdbcTemplate.batchUpdate(AssetInstanceSQL.getBatchUpdateSQL(),
            new AssetBatchUpdatePreparedStatementSetter(tenantId, Collections.singletonList(child), ancestorsByParentId,
                superTypesByTypeIdWithTypeId, jsonbAttributeConverter, listToTextArrayAttributeConverter,
                offsetDateTimeAttributeConverter, entityAuditor.getCurrentAuditor()));
        return findAssetById(tenantId, accessibleResources, child.getId(), null, false);
    }

    private Asset findParentAssetWithLock(String tenantId, Collection<String> accessibleResources, String parentId,
        boolean selectForUpdate) throws ObjectNotFoundException {
        Asset parentObject = findAssetById(tenantId, accessibleResources, parentId,
            AttributeSelectEnum.ID_WITH_ANCESTORS, null, false, selectForUpdate, true);
        if (!(StringUtils.isEmpty(parentId) || accessibleResources.isEmpty()) && parentObject == null) {
            throw new ObjectNotFoundException(String.format(PARENT_DOES_NOT_EXIST, parentId));
        }
        return parentObject;
    }

    private List<Asset> findChildAssetsWithLocks(String tenantId, Collection<String> accessibleResources,
        String assetId) {
        AssetPredicate assetPredicate = AssetPredicate.builder().parent(ParentPredicate.builder().ids(
            Sets.newHashSet(assetId)).deepSearch(true).build()).pageSize(-1).attributeSelectEnum(
            AttributeSelectEnum.ID_WITH_ANCESTORS).build();

        int previousSize = -1;
        int retryCount = 0;
        boolean foundWithLocks = false;
        List<Asset> assets = null;
        //We are looping through to make sure we don't miss any newly connected children.
        //so two subsequent count checks would gaurantee us we got the locks on all children and no one can
        //add any children to those child assets as we acquired lock on them.
        while (retryCount++ < maxFindChildAssetRetry) {
            assets = findChildAssets(tenantId, accessibleResources, assetId, assetPredicate, true);
            if (assets.size() == previousSize) {
                foundWithLocks = true;
                break;
            }
            previousSize = assets.size();
        }

        if (!foundWithLocks) {
            // allow try ingestion.
            throw new JpaSystemException(new RuntimeException("Too many retries to find asset children"));
        }

        return assets;
    }

    @Override
    @Transactional
    public int updateAssets(String tenantId, Collection<String> accessibleResources, List<Asset> assets)
        throws ObjectNotFoundException {
        //we are doing bulk update of assets one by one, since we need to denormalize one by one for ancestors.
        //especially when there is a move
        for (Asset asset : assets) {
            Asset updatedAsset = updateAsset(tenantId, accessibleResources, asset);
            //primarily meant to copy computed properties for event/aspect purpose.
            BeanUtils.copyProperties(updatedAsset, asset);
        }
        return assets.size();
    }

    // Delete API's
    @Override
    @Transactional
    public int deleteAsset(String tenantId, Collection<String> accessibleResources, String assetId)
        throws PersistencyServiceException {
        AssetHierarchy assetHierarchy = deleteAsset(tenantId, accessibleResources, assetId, false);
        return assetHierarchy.getAssetCount();
    }

    @Override
    @Transactional
    public AssetHierarchy deleteAssetRecursively(String tenantId, Collection<String> accessibleResources,
        String assetId, String deleteReason) throws PersistencyServiceException {
        return deleteAsset(tenantId, accessibleResources, assetId, true);
    }

    private AssetHierarchy deleteAsset(String tenantId, Collection<String> accessibleResources, String assetId,
        boolean recursive) throws PersistencyServiceException {
        //TODO: make sure decommission doesn't blow this up
        if (StringUtils.isEmpty(assetId)) {
            throw new IllegalArgumentException("Asset ID cannot be null");
        }

        AssetHierarchy assetHierarchy = null;
        try {
            List<AssetGroup> assetGroups = Collections.emptyList();
            List<AssetInstanceGroupItemEntity> deletedAssetGroupItems = Collections.emptyList();
            List<TagInstanceGroupItemEntity> deletedTagGroupItems = Collections.emptyList();
            List<TagCorrelationItemEntity> deletedTagCorrelationItems = Collections.emptyList();
            List<AssetGroupEntity> deletedTagCorrelationGroups = Collections.emptyList();
            List<TagInstanceEntity> deletedTags = Collections.emptyList();
            if (recursive) {
                // delete assetId from all group items
                String deleteAllGroupAssetInstancesQuery = GroupSQL.getRecursiveDeleteGroupAssetInstancesQuery(
                    accessibleResources, assetId);
                deletedAssetGroupItems = jdbcTemplate.query(deleteAllGroupAssetInstancesQuery,
                    rowMapperMap.get(AssetGroupCategory.ASSET), tenantId, tenantId);
                Set<String> groupIds = deletedAssetGroupItems.stream().map(AssetInstanceGroupItemEntity::getGroupId)
                    .collect(Collectors.toSet());
                // delete items in tag group for the given assetId
                String deleteAllGroupTagInstancesQuery = GroupSQL.getRecursiveDeleteGroupTagInstancesQuery(
                    accessibleResources, AssetGroupCategory.TAG, assetId);
                deletedTagGroupItems = jdbcTemplate.query(deleteAllGroupTagInstancesQuery,
                    rowMapperMap.get(AssetGroupCategory.TAG), tenantId, tenantId, tenantId);
                groupIds.addAll(deletedTagGroupItems.stream().map(TagInstanceGroupItemEntity::getGroupId)
                    .collect(Collectors.toSet()));
                GroupPredicate groupPredicate = GroupPredicate.builder().ids(groupIds).build();
                assetGroups = groupPersistencyService.getAssetGroups(tenantId, groupPredicate);

                // delete items in tag correlation for the given assetId
                String deleteAllCorrelatedTagInstancesQuery = GroupSQL.getRecursiveDeleteGroupTagInstancesQuery(
                    accessibleResources, AssetGroupCategory.TAG_CORRELATION, assetId);
                deletedTagCorrelationItems = jdbcTemplate.query(deleteAllCorrelatedTagInstancesQuery,
                    rowMapperMap.get(AssetGroupCategory.TAG_CORRELATION), tenantId, tenantId, tenantId);
                if (!CollectionUtils.isEmpty(deletedTagCorrelationItems)) {
                    Set<String> tagCorrelationGroupIds = deletedTagCorrelationItems.stream().map(
                        TagCorrelationItemEntity::getGroupId).collect(Collectors.toSet());
                    String deleteTagCorrelationGroupsQuery = GroupSQL.getDeleteAssetGroups(tagCorrelationGroupIds);
                    deletedTagCorrelationGroups = jdbcTemplate.query(deleteTagCorrelationGroupsQuery,
                        groupBeanPropertyRowMapper, tenantId);
                }

                //Delete tags for the given assetId
                String deleteAllTagsSQL = TagInstanceSQL.getRecursiveDeleteTagsQuery(accessibleResources, assetId);
                deletedTags = jdbcTemplate.query(deleteAllTagsSQL, tagInstanceBeanPropertyRowMapper, tenantId,
                    tenantId);
            }

            String deleteQuery;
            if (accessibleResources.isEmpty()) {
                deleteQuery = AssetInstanceSQL.buildDeleteAssetQuery(assetId, recursive);
            } else {
                deleteQuery = AssetInstanceSQL.buildDeleteAssetQuery(accessibleResources, assetId, recursive);
            }
            List<AssetInstanceEntity> deletedAssets = jdbcTemplate.query(deleteQuery,
                assetInstanceBeanPropertyRowMapper, tenantId, assetId);

            assetHierarchy = buildAssetHierarchy(assetId, deletedAssets, assetGroups, deletedAssetGroupItems,
                deletedTagGroupItems, deletedTagCorrelationItems, deletedTagCorrelationGroups, deletedTags);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                "Asset has children or references to it. Hence cannot be deleted", ex);
        }

        if (assetHierarchy.getAssetCount() == 0) {
            throw new ObjectNotFoundException(String.format(ASSET_DOES_NOT_EXIST, assetId));
        }
        return assetHierarchy;
    }

    private AssetHierarchy buildAssetHierarchy(String assetId, List<AssetInstanceEntity> assets,
        List<AssetGroup> assetGroups, List<AssetInstanceGroupItemEntity> assetGroupItems,
        List<TagInstanceGroupItemEntity> tagGroupItems, List<TagCorrelationItemEntity> tagCorrelationItems,
        List<AssetGroupEntity> deletedTagCorrelationGroups, List<TagInstanceEntity> tags) {
        return new AssetHierarchyImpl(assetId, assets, assetGroups, assetGroupItems, tagGroupItems, tagCorrelationItems,
            deletedTagCorrelationGroups, tags);
    }

    // Query API's
    @Override
    @CrossTenancyGet
    public Asset getAssetById(String tenantId, @Accessible Collection<String> accessibleResources, String id) {
        return findAssetById(tenantId, accessibleResources, id, null, false);
    }

    @Override
    @CrossTenancyGet
    public Asset getAssetById(String tenantId, @Accessible Collection<String> accessibleResources, String id,
        Set<AssetComponent> components, boolean ignoreComponentAcl) {
        return findAssetById(tenantId, accessibleResources, id, components, ignoreComponentAcl);
    }

    @Override
    @CrossTenancyGet
    public Asset getAssetBySourceKey(String tenantId, @Accessible Collection<String> accessibleResources, String typeName,
        String sourceKey) {
        if (StringUtils.isEmpty(typeName) || StringUtils.isEmpty(sourceKey)) {
            return null;
        }
        String typeId = OOTBCoreTypesIdLookup.valueOf(typeName).getId();
        String query = AssetInstanceSQL.getSelectWithAccessControlSqlForSingleObjectBySourceKey(
            AttributeSelectEnum.FULL, accessibleResources) + AND + AssetInstanceSQL.getTypeIdPredicate(typeId, true);
        return getAsset(tenantId, accessibleResources, sourceKey.toLowerCase(Locale.getDefault()), query, null, false);
    }

    @Override
    @CrossTenancyGet
    public List<Asset> getAssetsBySourceKeys(String tenantId, @Accessible Collection<String> accessibleResources,
        String typeName, List<String> sourceKeys) {
        if (StringUtils.isEmpty(typeName) || CollectionUtils.isEmpty(sourceKeys)) {
            return Collections.emptyList();
        }
        String typeId = OOTBCoreTypesIdLookup.valueOf(typeName).getId();
        String query = AssetInstanceSQL.getBySourceKeys(AttributeSelectEnum.FULL, accessibleResources, sourceKeys) + AND
            + AssetInstanceSQL.getTypeIdPredicate(typeId, true);
        List<AssetInstanceEntity> assets = jdbcTemplate.query(query, assetInstanceBeanPropertyRowMapper, tenantId);
        postLoadHandlers.forEach(loader -> loader.postLoad(tenantId, accessibleResources, assets,
            AttributeSelectEnum.FULL, EnumSet.of(AssetComponent.TEMPLATE_INFO)));
        return Collections.unmodifiableList(assets);
    }

    @Override
    @CrossTenancyGet(tenantified = false)
    public List<Asset> getAssets(String tenantId, @Accessible Collection<String> accessibleResources,
        AssetPredicate queryPredicate) {
        return findAssets(tenantId, accessibleResources, queryPredicate, false);
    }

    @Override
    @CrossTenancyGet(tenantified = false)
    public List<Asset> getAccessibleResources(String tenantId, @Accessible Collection<String> accessibleResources,
        AssetPredicate assetPredicate) {
        if (CollectionUtils.isEmpty(accessibleResources)) {
            assetPredicate.setType(
                TypePredicate.builder().ids(Collections.singleton(ROOT_ENTERPRISE_TYPE_ID)).deepSearch(true).build());
            assetPredicate.setParent(ParentPredicate.builder().ids(Collections.singleton(
                AssetInstanceSQL.NULL_UUID.toString())).build());
        } else {
            assetPredicate.setIds(new HashSet<>(accessibleResources));
        }

        List<AssetInstanceEntity> assets = queryAssets(tenantId, accessibleResources, assetPredicate, false);
        postLoadHandlers.forEach(loader -> loader.postLoad(tenantId,
            QueryUtils.getComponentAccessibleResources(assetPredicate, accessibleResources), assets,
            AttributeSelectEnum.FULL_WITHOUT_ATTRIBUTES, assetPredicate.getComponents()));

        return Collections.unmodifiableList(assets);
    }

    @Override
    @CrossTenancyGet
    public List<Asset> getChildAssets(String tenantId, @Accessible Collection<String> accessibleResources, String
        parentId, AssetPredicate childPredicate) {
        return findChildAssets(tenantId, accessibleResources, parentId, childPredicate, false);
    }

    @Override
    @CrossTenancyGet
    public List<Asset> getAssetsByIds(String tenantId, @Accessible Collection<String> accessibleResources, Set<String>
        assetIds)
        throws ObjectNotFoundException {
        String query = AssetInstanceSQL.getSelectAssetsByIds(accessibleResources, assetIds, AttributeSelectEnum.BASIC);
        List<AssetInstanceEntity> assets = jdbcTemplate.query(query, assetInstanceBeanPropertyRowMapper, tenantId);
        if (assets.size() != assetIds.size()) {
            throw new ObjectNotFoundException("Some assets in the given identifier list are not found.");
        }
        postLoadHandlers.forEach(loader -> loader.postLoad(tenantId, accessibleResources, assets,
            AttributeSelectEnum.FULL, EnumSet.of(AssetComponent.TEMPLATE_INFO)));
        return Collections.unmodifiableList(assets);
    }

    private Asset findAssetById(String tenantId, Collection<String> accessibleResources, String id,
        Set<AssetComponent> components, boolean ignoreComponentAcl) {
        return findAssetById(tenantId, accessibleResources, id,
            components == null || components.contains(AssetComponent.ATTRIBUTES)
                ? AttributeSelectEnum.FULL : AttributeSelectEnum.FULL_WITHOUT_ATTRIBUTES,
            components, ignoreComponentAcl, false, false);
    }

    //Find single asset by ID
    private Asset findAssetById(String tenantId, Collection<String> accessibleResources, String id,
        AttributeSelectEnum attributeSelectEnum, Set<AssetComponent> components, boolean ignoreComponentAcl,
        boolean selectForUpdate, boolean isParentObject) {
        if (StringUtils.isEmpty(id)) {
            return null;
        }
        String query = AssetInstanceSQL.getSelectWithAccessControlSqlForSingleObjectById(attributeSelectEnum,
            accessibleResources, selectForUpdate, isParentObject);
        return getAsset(tenantId, accessibleResources, id, query, components, ignoreComponentAcl);
    }

    private Asset getAsset(String tenantId, Collection<String> accessibleResources,
        String idOrSrcKey, String query, Set<AssetComponent> components, boolean ignoreComponentAcl) {
        try {
            AssetInstanceEntity asset = jdbcTemplate.queryForObject(query, assetInstanceBeanPropertyRowMapper, tenantId,
                idOrSrcKey);
            Collection<String> componentAcl = QueryUtils.getComponentAccessibleResources(ignoreComponentAcl,
                accessibleResources);
            postLoadHandlers.forEach(loader -> loader.postLoad(tenantId, componentAcl, asset,
                AttributeSelectEnum.FULL, components));
            return asset;
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("Asset not found with identifier: {}", idOrSrcKey);
            return null;
        }
    }

    //Global Search
    private List<Asset> findAssets(String tenantId, Collection<String> accessibleResources,
        AssetPredicate assetPredicate, boolean selectForUpdate) {
        List<AssetInstanceEntity> assets = queryAssets(tenantId, accessibleResources, assetPredicate, selectForUpdate);
        if (!selectForUpdate) {
            postLoadHandlers.forEach(loader -> loader.postLoad(tenantId,
                QueryUtils.getComponentAccessibleResources(assetPredicate, accessibleResources), assets,
                AttributeSelectEnum.FULL, assetPredicate.getComponents()));
        }
        return Collections.unmodifiableList(assets);
    }

    private List<AssetInstanceEntity> queryAssets(String tenantId, Collection<String> accessibleResources,
        AssetPredicate assetPredicate, boolean selectForUpdate) {

        String filterPredicate = AssetInstanceSQL.getFilterPredicate(tenantId, assetPredicate, accessibleResources);
        String andFilterPredicate = StringUtils.isEmpty(filterPredicate) ? "" : AND + filterPredicate;

        // The current accessible resources modelling dictates that if user has access to the parent, he/she has
        // access to all children. So as an optimization, we can skip outer ACL control on child assets.
        //NOTE: can no longer optimize after introducing asset user policies
        /*Collection<String> optimizedAccessibleResources = hasParentACL(tenantId, assetPredicate) ? Collections
            .emptyList() : accessibleResources;*/
        StringBuilder query = new StringBuilder(AssetInstanceSQL
            .getSelectWithAccessControlSqlForCollection(assetPredicate.getAttributeSelectEnum(), andFilterPredicate,
                accessibleResources));
        if (selectForUpdate) {
            query.append(" for update");
        } else {
            String orderBy = assetPredicate.isSortByHierarchy() ? AssetInstanceSQL.getOrderByHierarchy() : "";
            boolean defaultSorting = StringUtils.isEmpty(orderBy);
            if (defaultSorting) {
                String greaterThan = QueryUtils.getNextPageSortKeyFilter(assetPredicate);
                if (!StringUtils.isEmpty(greaterThan)) {
                    query.append(AND).append(greaterThan);
                }
            }
            String pagination = QueryUtils.getPagination(assetPredicate, defaultSorting);
            query.append(orderBy).append(pagination);
        }

        return jdbcTemplate.query(query.toString(), assetInstanceBeanPropertyRowMapper, tenantId);
    }

    private boolean hasParentACL(String tenantId, AssetPredicate assetPredicate) {
        // TODO: this is getting hairy, revisit
        boolean hasParentACL = !CollectionUtils.isEmpty(
            AssetInstanceSQL.getParentContextFilters(tenantId, Collections.emptyList(), assetPredicate.getParent()));
        if (hasParentACL) {
            return true;
        }

        if (assetPredicate.getChildPredicates() != null) {
            for (AssetPredicate ap : assetPredicate.getChildPredicates()) {
                hasParentACL = !CollectionUtils.isEmpty(AssetInstanceSQL
                    .getParentContextFilters(tenantId, Collections.emptyList(), assetPredicate.getParent()))
                    || !CollectionUtils.isEmpty(AssetInstanceSQL
                    .getParentTypePredicateExpressions(tenantId, Collections.emptyList(), ap.getParent()));
                if (hasParentACL) {
                    return true;
                }
            }
        }

        return false;
    }

    //In Context of given Parent container
    private List<Asset> findChildAssets(String tenantId, Collection<String> accessibleResources, String parentId,
        AssetPredicate queryPredicate, boolean selectForUpdate) {
        if (queryPredicate.getParent() == null) {
            queryPredicate.setParent(ParentPredicate.builder().build());
        }
        queryPredicate.getParent().setIds(Sets.newHashSet(parentId));
        queryPredicate.setSortByHierarchy(true);
        return findAssets(tenantId, accessibleResources, queryPredicate, selectForUpdate);
    }

    private List<String> getMyAncestors(Asset parentAsset) {
        List<String> parentAncestors;
        if (parentAsset == null) {
            parentAncestors = new ArrayList<>();
        } else {
            parentAncestors = new ArrayList<>(parentAsset.getAncestorsArray());
            parentAncestors.add(parentAsset.getId());
        }
        return parentAncestors;
    }

    /**
     * @return a map of asset ID to its ancestors
     */
    private Map<String, List<String>> getAncestorsByParentIds(String tenantId, Collection<String> accessibleResources,
        List<Asset> assets) {
        Set<String> parentIds = assets.stream().filter(a -> a.getParentId() != null).map(Asset::getParentId).collect(
            Collectors.toSet());
        Map<String, List<String>> rslt;
        if (parentIds.isEmpty()) {
            rslt = new HashMap<>();
            rslt.put(null, new ArrayList<>());
        } else {
            String query = AssetInstanceSQL.getSelectAncestorsByIds(accessibleResources, parentIds);
            rslt = jdbcTemplate.query(query, assetInstanceBeanPropertyRowMapper, tenantId).stream().collect(
                Collectors.toMap(Asset::getId, Asset::getAncestorsArray));
        }

        return rslt;
    }
}
