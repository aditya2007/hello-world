/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;

import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.entity.TemplateEntity;

public class TemplateBatchCreatePreparedStatementSetter implements BatchPreparedStatementSetter {

    private final String tenantId;
    private final List<TemplateEntity> templateEntities;
    private final JsonbAttributeConverter jsonbAttributeConverter;

    TemplateBatchCreatePreparedStatementSetter(String tenantId,
        List<TemplateEntity> templateEntities, JsonbAttributeConverter jsonbAttributeConverter) {
        this.tenantId = tenantId;
        this.templateEntities = templateEntities;
        this.jsonbAttributeConverter = jsonbAttributeConverter;
    }

    @Override
    public void setValues(PreparedStatement ps, int i) throws SQLException {
        TemplateEntity templateEntity = templateEntities.get(i);
        ps.setString(1, templateEntity.getId());
        ps.setString(2, templateEntity.getSourceKey());
        ps.setString(3, templateEntity.getName());
        ps.setString(4, templateEntity.getDescription());
        ps.setString(5, tenantId);
        ps.setString(6, templateEntity.getState());
        ps.setString(7, templateEntity.getStatus());
        ps.setString(8, templateEntity.getRevision());
        ps.setObject(9,
            jsonbAttributeConverter.convertToDatabaseColumn(templateEntity.getDefaultValueExpressions()));
        ps.setObject(10, jsonbAttributeConverter.convertToDatabaseColumn(templateEntity.getAttributes()));
        ps.setString(11, templateEntity.getCreatedBy());
        ps.setString(12, templateEntity.getLastModifiedBy());
    }

    @Override
    public int getBatchSize() {
        return templateEntities.size();
    }
}

