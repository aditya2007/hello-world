/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ge.apm.alm.persistence.jpa.entity.TemplateNotesEntity;

public interface TemplateNotesRepository extends JpaRepository<TemplateNotesEntity, String> {

    List<TemplateNotesEntity> findByTenantId(String tenantId);

    TemplateNotesEntity findByTenantIdAndId(String tenantId, String id);

    List<TemplateNotesEntity> findByTenantIdAndTemplateId(String tenantId, String templateId);

    List<TemplateNotesEntity> findByTenantIdAndTemplateId(String tenantId, String templateId, Pageable pageable);

    List<TemplateNotesEntity> findByTenantIdAndNotesId(String tenantId, String notesId, Pageable pageable);

    List<TemplateNotesEntity> findByTenantIdAndTemplateIdAndNotesId(String tenantId, String templateId, String notesId,
        Pageable pageable);
}
