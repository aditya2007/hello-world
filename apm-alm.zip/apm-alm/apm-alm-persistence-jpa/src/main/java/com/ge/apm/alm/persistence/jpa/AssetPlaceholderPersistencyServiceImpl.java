/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AssetPlaceholder;
import com.ge.apm.alm.persistence.AssetPlaceholderPersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.AssetPlaceholderEntity;
import com.ge.apm.alm.persistence.jpa.repository.AssetPlaceholderRepository;
import com.ge.apm.alm.persistence.jpa.sql.AssetPlaceholderSQL;

import static com.ge.apm.alm.persistence.jpa.utils.Validator.assertMatchingTenantId;

@Service
@Slf4j
@Transactional
public class AssetPlaceholderPersistencyServiceImpl implements AssetPlaceholderPersistencyService {

    @Autowired
    private DataSource dataSource;

    @Autowired
    private AssetPlaceholderRepository assetPlaceholderRepository;

    @Autowired
    private ConversionService conversionService;

    private EntityBeanPropertyRowMapper<AssetPlaceholderEntity> assetPlaceholderBeanPropertyRowMapper;

    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initializeConvertionService() {
        assetPlaceholderBeanPropertyRowMapper =
            new EntityBeanPropertyRowMapper(AssetPlaceholderEntity.class, conversionService);
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public AssetPlaceholder createAssetPlaceholder(String tenantId, AssetPlaceholder assetPlaceholder) {
        assertMatchingTenantId(tenantId, assetPlaceholder.getTenantId());
        validateAssetPlaceholder(assetPlaceholder);

        AssetPlaceholderEntity entity = toAssetPlaceholderEntity(tenantId, assetPlaceholder, true);
        return assetPlaceholderRepository.saveAndFlush(entity);
    }

    @Override
    public int createAssetPlaceholders(String tenantId, List<AssetPlaceholder> assetPlaceholders) {
        if (CollectionUtils.isEmpty(assetPlaceholders)) {
            return 0;
        }

        List<AssetPlaceholderEntity> entities = new ArrayList<>();
        assetPlaceholders.stream().forEach(assetPlaceholder -> {
            assertMatchingTenantId(tenantId, assetPlaceholder.getTenantId());
            validateAssetPlaceholder(assetPlaceholder);
            entities.add(toAssetPlaceholderEntity(tenantId, assetPlaceholder, true));
        });

        int[] updateCounts = jdbcTemplate
            .batchUpdate(AssetPlaceholderSQL.getBatchCreateSQL(), new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int i) throws SQLException {
                    AssetPlaceholderEntity entity = entities.get(i);
                    ps.setString(1, entity.getId());
                    ps.setString(2, tenantId);
                    ps.setString(3, entity.getAssetId());
                    ps.setString(4, entity.getPlaceholderId());
                    ps.setBoolean(5, entity.getConformanceFlag());
                    ps.setString(6, entity.getCreatedBy());
                    ps.setString(7, entity.getLastModifiedBy());
                }

                @Override
                public int getBatchSize() {
                    return entities.size();
                }
            });

        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public AssetPlaceholder updateAssetPlaceholder(String tenantId, AssetPlaceholder assetPlaceholder)
        throws PersistencyServiceException {
        assertMatchingTenantId(tenantId, assetPlaceholder.getTenantId());
        validateAssetPlaceholder(assetPlaceholder);

        AssetPlaceholderEntity entity = toAssetPlaceholderEntity(tenantId, assetPlaceholder, false);
        return assetPlaceholderRepository.saveAndFlush(entity);
    }

    @Override
    public int updateAssetPlaceholders(String tenantId, List<AssetPlaceholder> assetPlaceholders)
        throws PersistencyServiceException {
        if (CollectionUtils.isEmpty(assetPlaceholders)) {
            return 0;
        }

        int updateCounts = 0;
        for (AssetPlaceholder assetPlaceholder : assetPlaceholders) {
            updateAssetPlaceholder(tenantId, assetPlaceholder);
            updateCounts++;
        }
        return updateCounts;
    }

    @Override
    public int deleteAssetPlaceholderById(String tenantId, String id) throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = AssetPlaceholderSQL.getDeleteAssetPlaceholderByIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, id);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                "AssetPlaceholder has references to it. Hence cannot be deleted", ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("id:" + id);
        }
        return rowsDeleted;
    }

    @Override
    public int deleteAssetPlaceholderByAssetId(String tenantId, String assetId) throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = AssetPlaceholderSQL.getDeleteAssetPlaceholderByAssetIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, assetId);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                "AssetPlaceholder has references to it. Hence cannot be deleted", ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("assetId:" + assetId);
        }
        return rowsDeleted;
    }

    @Override
    public AssetPlaceholder getAssetPlaceholderById(String tenantId, String id) {
        try {
            String query = AssetPlaceholderSQL.getSelectSingleObjectById();
            return jdbcTemplate.queryForObject(query, assetPlaceholderBeanPropertyRowMapper, tenantId, id);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("AssetPlaceholder not found with identifier: {}", id);
            return null;
        }
    }

    @Override
    public AssetPlaceholder getAssetPlaceholderByAssetId(String tenantId, String assetId) {
        try {
            String query = AssetPlaceholderSQL.getSelectSingleObjectByAssetId();
            return jdbcTemplate.queryForObject(query, assetPlaceholderBeanPropertyRowMapper, tenantId, assetId);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("AssetPlaceholder not found with assetId: {}", assetId);
            return null;
        }
    }

    @Override
    public AssetPlaceholder getAssetPlaceholderByTemplateAndPpn(String tenantId, String templateId, String ppn) {
        try {
            String query = AssetPlaceholderSQL.getSelectSingleObjectByTemplateIdAndPpn();
            return jdbcTemplate.queryForObject(query, assetPlaceholderBeanPropertyRowMapper, tenantId, templateId, ppn);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("AssetPlaceholder not found with templateId:" + templateId + ", ppn:" + ppn);
            return null;
        }
    }

    @Override
    public List<AssetPlaceholder> getAssetPlaceholderByAssetIds(String tenantId, List<String> assetIds) {
        String query = AssetPlaceholderSQL.getSelectCollectionObjectsByAssetIds(assetIds);
        List<AssetPlaceholderEntity> entities = jdbcTemplate.query(query, assetPlaceholderBeanPropertyRowMapper,
            tenantId);
        return Collections.unmodifiableList(entities);
    }

    @Override
    public List<AssetPlaceholder> getAssetPlaceholderByPlaceholderIds(String tenantId, List<String> placeholderIds) {
        String query = AssetPlaceholderSQL.getSelectCollectionObjectsByPlaceholderIds(placeholderIds);
        List<AssetPlaceholderEntity> entities = jdbcTemplate.query(query, assetPlaceholderBeanPropertyRowMapper,
            tenantId);
        return Collections.unmodifiableList(entities);
    }

    private void validateAssetPlaceholder(AssetPlaceholder assetPlaceholder) {
        StringBuilder builder = new StringBuilder();
        if (StringUtils.isEmpty(assetPlaceholder.getId())) {
            builder.append("AssetPlaceholder Id is empty. ");
        }
        if (StringUtils.isEmpty(assetPlaceholder.getAssetId())) {
            builder.append("AssetPlaceholder assetId is empty. ");
        }
        if (StringUtils.isEmpty(assetPlaceholder.getPlaceholderId())) {
            builder.append("AssetPlaceholder placeholderId is empty. ");
        }

        if (!builder.toString().isEmpty()) {
            throw new IllegalArgumentException(builder.toString());
        }
    }

    private AssetPlaceholderEntity toAssetPlaceholderEntity(String tenantId, AssetPlaceholder assetPlaceholder,
        boolean isAdd) {
        AssetPlaceholderEntity entity = new AssetPlaceholderEntity();
        entity.setTenantId(tenantId);
        entity.setId(assetPlaceholder.getId());
        entity.setAssetId(assetPlaceholder.getAssetId());
        entity.setPlaceholderId(assetPlaceholder.getPlaceholderId());
        entity.setConformanceFlag(assetPlaceholder.getConformanceFlag());
        if (isAdd) {
            entity.setCreatedBy(assetPlaceholder.getCreatedBy());
        }
        entity.setLastModifiedBy(assetPlaceholder.getLastModifiedBy());

        return entity;
    }
}
