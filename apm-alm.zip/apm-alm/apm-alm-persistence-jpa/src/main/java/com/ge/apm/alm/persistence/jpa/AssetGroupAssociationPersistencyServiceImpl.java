/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupAssociation;
import com.ge.apm.alm.persistence.AssetGroupAssociationPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.converter.TagCorrelationGroupRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.AssetGroupAssociationEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetGroupEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.repository.AssetGroupAssociationRepository;
import com.ge.apm.alm.persistence.jpa.sql.AssetGroupAssociationSQL;
import com.ge.apm.alm.persistence.jpa.sql.AssetInstanceSQL;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;

@Service
@Slf4j
@Transactional
public class AssetGroupAssociationPersistencyServiceImpl implements AssetGroupAssociationPersistencyService {

    @Autowired
    private DataSource dataSource;

    @Autowired
    private AssetGroupAssociationRepository assetGroupAssociationRepository;

    @Autowired
    private ConversionService conversionService;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    @Autowired
    private TagCorrelationGroupRowMapper tagCorrelationGroupRowMapper;

    private JdbcTemplate jdbcTemplate;

    private EntityBeanPropertyRowMapper<AssetGroupEntity> groupBeanPropertyRowMapper;

    private EntityBeanPropertyRowMapper<AssetInstanceEntity> assetInstanceBeanPropertyRowMapper;

    private EntityBeanPropertyRowMapper<AssetGroupAssociationEntity> assetGroupAssociationBeanPropertyRowMapper;

    @PostConstruct
    public void initializeConvertionService() {
        jdbcTemplate = new JdbcTemplate(dataSource);
        groupBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(AssetGroupEntity.class, conversionService);
        assetInstanceBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(AssetInstanceEntity.class,
            conversionService);
        assetGroupAssociationBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(
            AssetGroupAssociationEntity.class, conversionService);
    }

    @Override
    public int deleteAssetGroupAssociations(String tenantId, Collection<String> accessibleResources,
        AssetGroupAssociation assetGroupAssociation) throws PersistencyServiceException {
        if (StringUtils.isEmpty(assetGroupAssociation.getObjectId()) && StringUtils.isEmpty(
            assetGroupAssociation.getGroupId())) {
            throw new IllegalArgumentException("Either groupID or assetID should be non-empty.");
        }
        int rowsDeleted = deleteAssetGroupAssociationsInternal(tenantId, accessibleResources,
            assetGroupAssociation.getGroupId(), assetGroupAssociation.getObjectId());
        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("Asset group association does not exist.");
        }
        return rowsDeleted;
    }

    @Override
    public void createAssetGroupAssociations(String tenantId, List<AssetGroupAssociation> assetGroupAssociations)
        throws PersistencyServiceException {
        for (AssetGroupAssociation assetGroupAssociation : assetGroupAssociations) {
            AssetGroupAssociationEntity associationEntity = new AssetGroupAssociationEntity();
            BeanUtils.copyProperties(assetGroupAssociation, associationEntity);
            assetGroupAssociationRepository.saveAndFlush(associationEntity);
        }
    }

    @Override
    public List<AssetGroup> getAssociatedGroupsByAssetId(String tenantId, Collection<String> accessibleResources,
        String assetId, String category) throws PersistencyServiceException {
        List<String> queryParams = new ArrayList<>(Arrays.asList(tenantId, assetId));
        if (QueryUtils.isNotUber(accessibleResources)) {
            queryParams.add(tenantId);
        }
        //Category should always be the last query param
        if (!StringUtils.isEmpty(category)) {
            queryParams.add(category.toUpperCase(Locale.getDefault()));
        }
        String query = AssetGroupAssociationSQL.getGroupsByAssetId(accessibleResources, category);
        return Collections.unmodifiableList(
            jdbcTemplate.query(query, groupBeanPropertyRowMapper, queryParams.toArray()));
    }

    @Override
    public Map<String, List<AssetGroup>> getAssociatedGroupsByAssetIds(String tenantId,
        Collection<String> accessibleResources, Collection<String> assetIds, String category)
        throws PersistencyServiceException {
        List<String> queryParams = new ArrayList<>(Collections.singletonList(tenantId));
        if (QueryUtils.isNotUber(accessibleResources)) {
            queryParams.add(tenantId);
        }
        //Category should always be the last query param
        if (!StringUtils.isEmpty(category)) {
            queryParams.add(category.toUpperCase(Locale.getDefault()));
        }
        String query = AssetGroupAssociationSQL.getGroupsByAssetIds(accessibleResources, category, assetIds);
        List<Map.Entry<String, AssetGroupEntity>> result = jdbcTemplate.query(query, tagCorrelationGroupRowMapper,
            queryParams.toArray());
        Map<String, List<AssetGroup>> map = new HashMap<>();
        for (Map.Entry<String, AssetGroupEntity> entry : result) {
            AssetGroupEntity value = entry.getValue();
            String key = entry.getKey();
            if (!map.containsKey(key)) {
                map.put(key, new ArrayList<>());
            }
            map.get(key).add(value);
        }
        return Collections.unmodifiableMap(map);
    }

    @Override
    public List<Asset> getAssociatedAssetsByGroupId(String tenantId, Collection<String> accessibleResources,
        String groupId) throws PersistencyServiceException {
        List<String> queryParams = new ArrayList<>(Arrays.asList(tenantId, groupId));
        if (QueryUtils.isNotUber(accessibleResources) || AssetInstanceSQL.hasApplicablePolicies(accessibleResources)) {
            queryParams.add(tenantId);
        }
        String query = AssetGroupAssociationSQL.getAssetsByGroupId(accessibleResources);
        return Collections.unmodifiableList(
            jdbcTemplate.query(query, assetInstanceBeanPropertyRowMapper, queryParams.toArray()));
    }

    @Override
    public List<AssetGroupAssociation> getAssetGroupAssociationsByAssetAndGroupURI(String tenantId,
        Collection<String> accessibleResources, String groupId, String assetId) {
        String selectQuery;
        List<String> queryParams = new ArrayList<>(Arrays.asList(tenantId, groupId, assetId));
        if (!StringUtils.isEmpty(assetId) && !StringUtils.isEmpty(groupId)) {
            selectQuery = AssetGroupAssociationSQL.getSelectAssetGroupAssociationsByGroupIdAndObjectId(
                accessibleResources);
            return Collections.unmodifiableList(
                jdbcTemplate.query(selectQuery, assetGroupAssociationBeanPropertyRowMapper, queryParams.toArray()));
        } else if (!StringUtils.isEmpty(groupId)) {
            queryParams = new ArrayList<>(Arrays.asList(tenantId, groupId));
            selectQuery = AssetGroupAssociationSQL.getSelectAssetGroupAssociationsByGroupId(accessibleResources);
            return Collections.unmodifiableList(
                jdbcTemplate.query(selectQuery, assetGroupAssociationBeanPropertyRowMapper, queryParams.toArray()));
        } else {
            queryParams = new ArrayList<>(Arrays.asList(tenantId, assetId));
            selectQuery = AssetGroupAssociationSQL.getSelectAssetGroupAssociationsByObjectId(accessibleResources);
            return Collections.unmodifiableList(
                jdbcTemplate.query(selectQuery, assetGroupAssociationBeanPropertyRowMapper, queryParams.toArray()));
        }
    }

    private int deleteAssetGroupAssociationsInternal(String tenantId, Collection<String> accessibleResources,
        String groupId, String assetId) throws PersistencyServiceException {
        String deleteQuery;
        if (!StringUtils.isEmpty(assetId) && !StringUtils.isEmpty(groupId)) {
            deleteQuery = AssetGroupAssociationSQL.getDeleteAssetGroupAssociationsByGroupIdAndObjectId(
                accessibleResources);
            return executeUpdate(deleteQuery, tenantId, accessibleResources, tenantId, groupId, assetId);
        } else if (!StringUtils.isEmpty(groupId)) {
            deleteQuery = AssetGroupAssociationSQL.getDeleteAssetGroupAssociationsByGroupId(accessibleResources);
            return executeUpdate(deleteQuery, tenantId, accessibleResources, tenantId, groupId);
        } else {
            deleteQuery = AssetGroupAssociationSQL.getDeleteAssetGroupAssociationsByObjectId(accessibleResources);
            return executeUpdate(deleteQuery, tenantId, accessibleResources, tenantId, assetId);
        }
    }

    private int executeUpdate(String updateQuery, String tenantId, Collection<String> accessibleResources,
        String... arguments) {
        List<String> queryParams = new ArrayList<>(Arrays.asList(arguments));
        if (QueryUtils.isNotUber(accessibleResources)) {
            queryParams.add(tenantId);
        }
        return jdbcTemplate.update(updateQuery, queryParams.toArray());
    }
}
