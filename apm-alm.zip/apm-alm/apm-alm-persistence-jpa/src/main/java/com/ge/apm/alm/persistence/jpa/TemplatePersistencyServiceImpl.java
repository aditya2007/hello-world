/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.model.query.TemplatePredicate;
import com.ge.apm.alm.persistence.TemplatePersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.entity.TemplateEntity;
import com.ge.apm.alm.persistence.jpa.repository.TemplateRepository;
import com.ge.apm.alm.persistence.jpa.sql.NotesSQL;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.sql.TemplateSQL;

import static com.ge.apm.alm.persistence.jpa.utils.Validator.assertMatchingTenantId;

@Service
@Slf4j
@Transactional
public class TemplatePersistencyServiceImpl implements TemplatePersistencyService {

    @Autowired
    private DataSource dataSource;
    private static final String AND = " and ";

    @Autowired
    private TemplateRepository templateRepository;

    @Autowired
    private ConversionService conversionService;

    @Autowired
    private JsonbAttributeConverter jsonbAttributeConverter;

    private EntityBeanPropertyRowMapper<TemplateEntity> templateBeanPropertyRowMapper;

    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initializeConvertionService() {
        templateBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(TemplateEntity.class,
            conversionService);
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public Template createTemplate(String tenantId, Template template) {
        assertMatchingTenantId(tenantId, template.getTenantId());
        validateTemplate(template);

        TemplateEntity templateEntity = toTemplateEntity(tenantId, template, true);
        return templateRepository.saveAndFlush(templateEntity);
    }

    @Override
    public int createTemplates(String tenantId, List<Template> templates) {
        if (CollectionUtils.isEmpty(templates)) {
            return 0;
        }

        List<TemplateEntity> templateEntities = new ArrayList<>();
        templates.forEach(t -> {
            assertMatchingTenantId(tenantId, t.getTenantId());
            templateEntities.add(toTemplateEntity(tenantId, t, true));
        });

        int[] updateCounts = jdbcTemplate
            .batchUpdate(TemplateSQL.getBatchCreateSQL(),
                new TemplateBatchCreatePreparedStatementSetter(tenantId, templateEntities, jsonbAttributeConverter));

        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public Template updateTemplate(String tenantId, Template template) {
        assertMatchingTenantId(tenantId, template.getTenantId());

        TemplateEntity templateEntity = toTemplateEntity(tenantId, template, false);
        return templateRepository.saveAndFlush(templateEntity);
    }

    @Override
    public int updateTemplates(String tenantId, List<Template> templates) {
        if (CollectionUtils.isEmpty(templates)) {
            return 0;
        }

        int updateCounts = 0;
        for (Template template : templates) {
            updateTemplate(tenantId, template);
            updateCounts++;
        }
        return updateCounts;
    }

    @Override
    public int deleteTemplateById(String tenantId, String id) throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            // manually delete notes from "notes" table based on templateId
            jdbcTemplate.update(NotesSQL.getDeleteByTemplateIdSQL(), tenantId, id);

            String deleteQuery = TemplateSQL.getDeleteTemplateByIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, id);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                "Template has references to it. Hence cannot be deleted", ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException(id);
        }
        return rowsDeleted;
    }

    @Override
    public Template getTemplateById(String tenantId, String id) {
        String query = TemplateSQL.getSelectSingleObjectById(AttributeSelectEnum.FULL);
        return getTemplate(tenantId, id, query);
    }


    @Override
    public Template getTemplateBySourceKey(String tenantId, String sourceKey) {
        if (StringUtils.isEmpty(sourceKey)) {
            return null;
        }
        String query = TemplateSQL.getSelectSingleObjectBySourceKey(AttributeSelectEnum.FULL);
        return getTemplate(tenantId, sourceKey.toLowerCase(Locale.getDefault()), query);
    }

    @Override
    public List<Template> getTemplatesBySourceKeys(String tenantId, List<String> sourceKeys) {
        if (CollectionUtils.isEmpty(sourceKeys)) {
            return Collections.emptyList();
        }
        String query = TemplateSQL.getSelectBySourceKeys(AttributeSelectEnum.FULL, sourceKeys);
        return Collections.unmodifiableList(
            jdbcTemplate.query(query, templateBeanPropertyRowMapper, tenantId));
    }

    @Override
    @SuppressWarnings("squid:S2077")
    public List<Template> getTemplates(String tenantId, TemplatePredicate templatePredicate) {

        String filterPredicate = TemplateSQL.getFilterPredicate(templatePredicate);
        String andFilterPredicate = StringUtils.isEmpty(filterPredicate) ? "" : AND + filterPredicate;
        String query = TemplateSQL.getSelectCollectionObjects(
            templatePredicate.getAttributeSelectEnum()) + andFilterPredicate;
        String greaterThan = QueryUtils.getNextPageSortKeyFilter(templatePredicate);
        if (!StringUtils.isEmpty(greaterThan)) {
            query += AND + greaterThan;
        }
        query += QueryUtils.getPagination(templatePredicate);
        log.info("****" + templatePredicate.getAttributeSelectEnum() + ", query: " + query);
        return Collections.unmodifiableList(
            jdbcTemplate.query(query, templateBeanPropertyRowMapper, tenantId));
    }

    private void validateTemplate(Template template) {
        StringBuilder builder = new StringBuilder();
        if (StringUtils.isEmpty(template.getSourceKey())) {
            builder.append("Template SourceKey is empty. ");
        }
        if (StringUtils.isEmpty(template.getName())) {
            builder.append("Template Name is empty. ");
        }
        if (StringUtils.isEmpty(template.getState())) {
            builder.append("Template State is empty. ");
        }
        if (StringUtils.isEmpty(template.getStatus())) {
            builder.append("Template Status is empty. ");
        }

        if (!builder.toString().isEmpty()) {
            throw new IllegalArgumentException(builder.toString());
        }
    }

    private TemplateEntity toTemplateEntity(String tenantId, Template template, boolean isAdd) {
        TemplateEntity templateEntity = new TemplateEntity();
        templateEntity.setTenantId(tenantId);
        templateEntity.setId(template.getId());
        templateEntity.setSourceKey(template.getSourceKey());
        templateEntity.setName(template.getName());
        templateEntity.setDescription(template.getDescription());
        templateEntity.setState(template.getState());
        templateEntity.setStatus(template.getStatus());
        templateEntity.setRevision(template.getRevision());
        templateEntity.setAttributes(template.getAttributes());
        templateEntity.setDefaultValueExpressions(template.getDefaultValueExpressions());
        if (isAdd) {
            templateEntity.setCreatedBy(template.getCreatedBy());
        }
        templateEntity.setLastModifiedBy(template.getLastModifiedBy());

        return templateEntity;
    }

    private Template getTemplate(String tenantId, String idOrSrcKey, String query) {
        try {
            return jdbcTemplate.queryForObject(query, templateBeanPropertyRowMapper, tenantId,
                idOrSrcKey);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("Template not found with identifier: {}", idOrSrcKey);
            return null;
        }
    }
}
