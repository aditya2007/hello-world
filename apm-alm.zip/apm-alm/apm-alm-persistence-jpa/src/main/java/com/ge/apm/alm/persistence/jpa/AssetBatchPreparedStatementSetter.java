/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;

import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;

@Slf4j
abstract class AssetBatchPreparedStatementSetter<T> extends BaseBatchPreparedStatementSetter<T> {

    final Map<String, List<String>> superTypesByTypeId;

    private Method setSuperTypesArray;

    protected final ListToTextArrayAttributeConverter listToTextArrayAttributeConverter;

    AssetBatchPreparedStatementSetter(String tenantId, List<T> instances, Map<String, List<String>> superTypesByTypeId,
        JsonbAttributeConverter jsonbAttributeConverter,
        ListToTextArrayAttributeConverter listToTextArrayAttributeConverter,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter) {
        super(tenantId, instances, jsonbAttributeConverter, offsetDateTimeAttributeConverter);
        this.superTypesByTypeId = superTypesByTypeId;
        this.listToTextArrayAttributeConverter = listToTextArrayAttributeConverter;
        if (!CollectionUtils.isEmpty(this.instances)) {
            //expecting all instances to be of same subtype.
            try {
                setSuperTypesArray = ReflectionUtils.findMethod(instances.get(0).getClass(), "setSuperTypesArray",
                    List.class);
            } catch (Exception e) {
                log.warn("Error setting value to Bean. It is possible Bean is not settable", e);
            }
        }
    }

    void setSetSuperTypesArray(T instance) {
        if (setSuperTypesArray != null) {
            ReflectionUtils.invokeMethod(setSuperTypesArray, instance, superTypesByTypeId.get(getTypeId(instance)));
        }
    }

    protected abstract String getTypeId(T t);
}
