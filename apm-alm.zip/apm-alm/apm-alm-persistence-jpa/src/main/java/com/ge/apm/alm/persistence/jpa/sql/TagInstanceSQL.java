/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.sql;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.model.query.TypePredicate;

public final class TagInstanceSQL {

    private static final String AND = " and ";

    private static final String ID_IN_0 = " id in ({0}) ";

    private static final String ID_COLUMN = "select id from apm_alm.tag_instance ";

    private static final String ALL_COLUMNS = "select * from apm_alm.tag_instance ";

    private static final String BASIC_COLUMNS =
        "select id, tenant_id, source_key, name, description, asset_id, tag_type, super_types_array, created_by, "
            + "created_date, last_modified_by, last_modified_date from apm_alm.tag_instance ";

    private static final String BASIC_COLUMNS_WITH_ATTRIBUTES =
        "select id, tenant_id, source_key, name, description, asset_id, tag_type, super_types_array, attributes, "
            + "created_by, created_date, last_modified_by, last_modified_date from apm_alm.tag_instance ";

    private static final String WHERE_TENANT_ID = " where tenant_id = ? ";

    private static final String WHERE_TENANT_ID_AND_ID = WHERE_TENANT_ID + " and id = ? ";

    private static final String WHERE_TENANT_ID_AND_ID_IN = WHERE_TENANT_ID + " and id in ({0}) ";

    private static final String WHERE_TENANT_ID_AND_SOURCE_KEY = WHERE_TENANT_ID + " and lower(source_key) = ? ";

    private static final String WHERE_TENANT_ID_AND_SOURCE_KEY_IN = WHERE_TENANT_ID
        + " and lower(source_key) in ({0}) ";

    private static final String ALIASES = "lower(aliases::text)::jsonb ?? ''{0}''";

    private static final String ID_OR_ANCESTORS_IN_CLAUSE = "(id in ({0}) or ancestors_array && array[{0}])";

    private static final String AND_ACL_CLAUSE = AND + ID_OR_ANCESTORS_IN_CLAUSE;

    private static final String ASSET_IN_ACL_CLAUSE =
        "asset_id in (select id from apm_alm.asset_instance where tenant_id = ''{0}'' " + " {1} " + ")";

    private static final String AND_ASSET_IN_ACL_CLAUSE = AND + ASSET_IN_ACL_CLAUSE;

    private static final String AND_ASSET_IN_ACL_CLAUSE1 =
        " and asset_id in (select id from apm_alm.asset_instance where tenant_id = ''{0}'' " + " {1} " + ")";

    private static final String AND_ASSET_IN_ACL_CLAUSE2_BY_ASSET_ID =
        " and asset_id in (select id from apm_alm.asset_instance where tenant_id = ''{0}'' and id = ''{1}'' " + " {2} "
            + ")";

    private static final String MONITORED_ENTITY_TYPE =
        "asset_id in (select id from apm_alm.asset_instance where tenant_id= ''{0}'' and asset_type ="
            + "(select id from apm_alm.asset_type where tenant_id = "
            + " ''{0}'' and {1}))";

    private static final String BATCH_CREATE_SQL =
        "insert into apm_alm.tag_instance (id, source_key, name, description, tenant_id, asset_id, tag_type, "
            + "tag_category, aliases, attributes, super_types_array, created_by, "
            + "created_date, last_modified_by, last_modified_date) values"
            + " (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String BATCH_UPDATE_SQL =
        "update apm_alm.tag_instance set source_key = ?, name = ?, description = ?, asset_id = ?, tag_type"
            + " = ?, tag_category = ?, aliases = ?, attributes = ?, super_types_array = ?, "
            + "last_modified_by = ?, last_modified_date = ? where tenant_id = ? and id = ?";

    private static final String DELETE_TAG_SQL = "delete from apm_alm.tag_instance ";

    //The following SQL is for recursive delete of all tags in entire hierarchy, say in an enterprise.
    //In Q3, we will rely on Cascade delete of tags along with assets.
    static final String DELETE_TAGS_WITH_ASSET_ID_IN = DELETE_TAG_SQL + " where tenant_id = ? and asset_id in ";

    private static final String DELETE_TAGS_SQL = DELETE_TAG_SQL + "where tenant_id = ? and asset_id = ? and" + ID_IN_0;

    private static final String DELETE_ALL_TAGS_SQL = DELETE_TAG_SQL + "where tenant_id = ? and asset_id = ? ";

    private static final String SELECT_WHERE_CORRELATED_TAGS_BY_ID =
        "select t.* from apm_alm.tag_instance t join apm_alm.asset_group_tag_correlation c on t.tenant_id = c"
            + ".tenant_id and t.id = c.object_id where t.tenant_id = ? and t.id in "
            + "(select object_id from apm_alm.asset_group_tag_correlation where tenant_id = ? and group_id = "
            + "(select group_id from apm_alm.asset_group_tag_correlation where tenant_id = ? and object_id = ?))";

    private static final String TAG_TYPE_IN_0 = "tag_type in ({0})";

    private static final String TAG_SUPER_TYPES_IN = "super_types_array && array[{0}]";

    // {0} is tenantId
    // {1} is additional type filtering criteria without ACL
    private static final String TAG_TYPE_IN_CRITERIA_CLAUSE
        = "tag_type in (select id from apm_alm.asset_type where tenant_id = ''{0}'' and {1})";

    private static final String TAG_SUPER_TYPES_IN_CRITERIA_CLAUSE =
        "super_types_array && array(select cast(id as text) from apm_alm.asset_type where tenant_id = ''{0}'' and"
            + " {1})";

    private static final String TAG_ID_BY_ASSET_ID_IN_QUERY = ID_COLUMN + WHERE_TENANT_ID + " and asset_id in ";

    private TagInstanceSQL() {
    }

    private static String getAclClause(Collection<String> accessibleResources) {
        if (QueryUtils.isNotUber(accessibleResources)) {
            return MessageFormat.format(AND_ACL_CLAUSE, QueryUtils.getSqlListOfResources(accessibleResources))
                + AssetInstanceSQL.buildUserPolicyAccessControlSql(accessibleResources);
        } else {
            return AssetInstanceSQL.buildUserPolicyAccessControlSql(accessibleResources);
        }
    }

    public static String getBatchCreateSQL() {
        return BATCH_CREATE_SQL;
    }

    public static String getBatchUpdateSQL() {
        return BATCH_UPDATE_SQL;
    }

    public static String getSelectAttributes(AttributeSelectEnum attributeSelectEnum) {
        if (attributeSelectEnum == null) {
            return BASIC_COLUMNS;
        }
        switch (attributeSelectEnum) {
            case ID:
                return ID_COLUMN;
            case FULL:
                return ALL_COLUMNS;
            case ATTRIBUTES:
                return BASIC_COLUMNS_WITH_ATTRIBUTES;
            default:
                return BASIC_COLUMNS;
        }
    }

    public static String buildDeleteTagQuery(String tenantId, Collection<String> accessibleResources) {
        return DELETE_TAG_SQL + WHERE_TENANT_ID_AND_ID + applyACL(AND_ASSET_IN_ACL_CLAUSE, tenantId,
            accessibleResources);
    }

    public static String buildDeleteTagsQuery(String tenantId, String assetId, Collection<String> accessibleResources,
        Set<String> tagIds) {
        return MessageFormat.format(DELETE_TAGS_SQL, QueryUtils.getSqlListOfResources(tagIds)) + applyACL(
            AND_ASSET_IN_ACL_CLAUSE2_BY_ASSET_ID, tenantId, assetId, accessibleResources);
    }

    public static String buildDeleteAllTagsForAssetQuery(String tenantId, String assetId,
        Collection<String> accessibleResources) {
        return DELETE_ALL_TAGS_SQL + applyACL(AND_ASSET_IN_ACL_CLAUSE2_BY_ASSET_ID, tenantId, assetId,
            accessibleResources);
    }

    public static String getSelectById(AttributeSelectEnum attributeSelectEnum, String tenantId,
        Collection<String> accessibleResources) {
        return getSelectAttributes(attributeSelectEnum) + WHERE_TENANT_ID_AND_ID + applyACL(AND_ASSET_IN_ACL_CLAUSE,
            tenantId, accessibleResources);
    }

    public static String getSelectByIdsForUpdate(AttributeSelectEnum attributeSelectEnum, String tenantId,
        Collection<String> accessibleResources, List<String> ids) {
        String listOfIds = QueryUtils.getSqlListOfResources(ids);
        return getSelectAttributes(attributeSelectEnum) + MessageFormat.format(WHERE_TENANT_ID_AND_ID_IN, listOfIds)
            + applyACL(AND_ASSET_IN_ACL_CLAUSE, tenantId, accessibleResources) + " order by id asc FOR UPDATE";
    }

    public static String getSelectBySourceKey(AttributeSelectEnum attributeSelectEnum, String tenantId,
        Collection<String> accessibleResources) {
        return getSelectAttributes(attributeSelectEnum) + WHERE_TENANT_ID_AND_SOURCE_KEY + applyACL(
            AND_ASSET_IN_ACL_CLAUSE, tenantId, accessibleResources);
    }

    public static String getSelectBySourceKeys(AttributeSelectEnum attributeSelectEnum, String tenantId,
        Collection<String> accessibleResources, List<String> sourceKeys) {
        String listOfLowerCaseSrcKeys = QueryUtils.getSqlListOfResources(
            sourceKeys.stream().map(String::toLowerCase).collect(Collectors.toList()));
        return getSelectAttributes(attributeSelectEnum) + MessageFormat.format(WHERE_TENANT_ID_AND_SOURCE_KEY_IN,
            listOfLowerCaseSrcKeys) + applyACL(AND_ASSET_IN_ACL_CLAUSE, tenantId, accessibleResources);
    }

    public static String getSelectForCollection(AttributeSelectEnum attributeSelectEnum) {
        return getSelectAttributes(attributeSelectEnum) + WHERE_TENANT_ID;
    }

    public static String getFilterPredicate(String tenantId, Collection<String> accessibleResources,
        TagPredicate predicate) {
        if (predicate == null) {
            return "";
        }

        boolean missingChildPredicates = predicate.getChildOperand() == null || !CollectionUtils.isEmpty(
            predicate.getChildPredicates());
        assert missingChildPredicates : "Predicate with child operand must have non-empty list of child predicates.";

        List<String> expressions = QueryUtils.getEqualOrLikeFilterExpressions(predicate, predicate.getAttributes(),
            predicate.getReservedAttributes());
        if (!StringUtils.isEmpty(predicate.getAlias())) {
            expressions.add(MessageFormat.format(ALIASES, predicate.getAlias().toLowerCase(Locale.getDefault())));
        }

        expressions.addAll(getTypeContextFilters(tenantId, predicate.getType()));
        expressions.addAll(getParentContextFilters(tenantId, predicate.getParent(), accessibleResources));

        Set<String> ids = predicate.getIds();
        if (!CollectionUtils.isEmpty(ids)) {
            expressions.add(MessageFormat.format(ID_IN_0, QueryUtils.getSqlListOfResources(ids)));
        }
        expressions = expressions.stream().filter(e -> !StringUtils.isEmpty(e)).collect(Collectors.toList());

        StringBuilder rslt = new StringBuilder();
        if (!CollectionUtils.isEmpty(expressions)) {
            rslt.append(QueryUtils.flattenExpressions(expressions, Operand.AND));
            if (predicate.getChildOperand() != null) {
                rslt.append(" ").append(predicate.getChildOperand().name());
            }
        }
        rslt.append(processChildPredicates(tenantId, accessibleResources, predicate.getChildPredicates()));

        if (rslt.length() == 0) {
            return "";
        }
        return rslt.insert(0, "(").append(")").toString();
    }

    private static String processChildPredicates(String tenantId, Collection<String> accessibleResources,
        List<TagPredicate> childPredicates) {
        if (CollectionUtils.isEmpty(childPredicates)) {
            return "";
        }

        StringBuilder rslt = new StringBuilder(" (");
        int lastIndex = childPredicates.size() - 1;
        int i = 0;
        for (TagPredicate tp : childPredicates) {
            rslt.append(getFilterPredicate(tenantId, accessibleResources, tp));
            if (tp != null && tp.getPeerOperand() != null && i < lastIndex) {
                rslt.append(" ").append(tp.getPeerOperand().name()).append(" ");
            }
            i++;
        }
        rslt.append(")");
        return rslt.toString();
    }

    public static String getCorrelatedTagsById(String tenantId, Collection<String> accessibleResources) {
        return SELECT_WHERE_CORRELATED_TAGS_BY_ID + applyACL(AND_ASSET_IN_ACL_CLAUSE1, tenantId, accessibleResources)
            + " order by c.position asc";
    }

    public static String getTagIdsByAssetIdInQuery() {
        return TAG_ID_BY_ASSET_ID_IN_QUERY;
    }

    public static String getRecursiveDeleteTagsQuery(Collection<String> accessibleResources, String assetId) {
        String andAncestorsClause = SQLConstants.AND + MessageFormat.format(AssetInstanceSQL.ID_OR_ANCESTORS_CLAUSE,
            assetId);
        String assetsSql = AssetInstanceSQL.getSelectWithAccessControlSqlForCollection(AttributeSelectEnum.ID,
            andAncestorsClause, accessibleResources);
        return TagInstanceSQL.DELETE_TAGS_WITH_ASSET_ID_IN + "(" + assetsSql + ")" + SQLConstants.RETURNING_FULL;
    }

    private static List<String> getParentContextFilters(String tenantId, ParentPredicate parent,
        Collection<String> accessibleResources) {
        if (parent == null) {
            return Collections.singletonList(applyACL(ASSET_IN_ACL_CLAUSE, tenantId, accessibleResources));
        }
        List<String> expressions = new ArrayList<>();
        String filterExp = getAssetIdInParentCriteriaQuery(tenantId, parent, accessibleResources);
        expressions.add(filterExp);

        return expressions;
    }

    /**
     * Generate query with filters other than <code>assetId</code> in the parent predicate.
     */
    private static String getAssetIdInParentCriteriaQuery(String tenantId, ParentPredicate parent,
        Collection<String> accessibleResources) {
        String filterExp;
        List<String> parentExpressions = QueryUtils.getEqualOrLikeFilterExpressions(parent, parent.getAttributes(),
            parent.getReservedAttributes());
        if (CollectionUtils.isEmpty(parent.getIds())) {
            filterExp = processParentFilterWithoutIds(tenantId, parent, accessibleResources, parentExpressions);
        } else {
            filterExp = processParentFilterWithIds(tenantId, parent, accessibleResources, parentExpressions);
        }

        return filterExp;
    }

    private static String processParentFilterWithIds(String tenantId, ParentPredicate parent,
        Collection<String> accessibleResources, List<String> parentExpressions) {
        String filterExp;
        String assetIdFilter = "asset_id in ";
        if (parent.isDeepSearch()) {
            assetIdFilter += "(select id from apm_alm.asset_instance where tenant_id = '" + tenantId + "' and "
                + MessageFormat.format(ID_OR_ANCESTORS_IN_CLAUSE, QueryUtils.getSqlListOfResources(parent.getIds()));
            if (QueryUtils.isNotUber(accessibleResources) || AssetInstanceSQL.hasApplicablePolicies(
                accessibleResources)) {
                assetIdFilter += getAclClause(accessibleResources);
            }
            assetIdFilter += ")";
        } else {
            assetIdFilter += "(" + QueryUtils.getSqlListOfResources(parent.getIds()) + ")";
            if (QueryUtils.isNotUber(accessibleResources) || AssetInstanceSQL.hasApplicablePolicies(
                accessibleResources)) {
                assetIdFilter += " and asset_id in (select id from apm_alm.asset_instance where tenant_id = '"
                    + tenantId + "'" + getAclClause(accessibleResources) + ")";
            }
        }
        parentExpressions.add(assetIdFilter);
        filterExp = QueryUtils.flattenExpressions(parentExpressions, Operand.AND);
        return filterExp;
    }

    private static String processParentFilterWithoutIds(String tenantId, ParentPredicate parent,
        Collection<String> accessibleResources, List<String> parentExpressions) {
        String filterExp;
        if (CollectionUtils.isEmpty(parentExpressions)) {
            filterExp = applyACL(AND_ASSET_IN_ACL_CLAUSE1, tenantId, accessibleResources);
        } else {
            String assetIdFilter = "asset_id in ";
            String criteria = QueryUtils.flattenExpressions(parentExpressions, Operand.AND);
            if (parent.isDeepSearch()) {
                String filterExpCast = "select cast(id as text) from apm_alm.asset_instance where tenant_id = '"
                    + tenantId + "' and " + criteria;
                assetIdFilter += MessageFormat.format(
                    "(select id from apm_alm.asset_instance where tenant_id = ''{0}'' and ({1} or "
                        + "ancestors_array && array({2}))", tenantId, criteria, filterExpCast);
            } else {
                assetIdFilter += MessageFormat.format(
                    "(select id from apm_alm.asset_instance where tenant_id = ''{0}'' and {1}", tenantId, criteria);
            }

            filterExp = assetIdFilter + applyACL(accessibleResources) + ")";
        }
        return filterExp;
    }

    private static String applyACL(Collection<String> accessibleResources) {
        return (QueryUtils.isUber(accessibleResources) && !AssetInstanceSQL.hasApplicablePolicies(accessibleResources))
            ? "" : getAclClause(accessibleResources);
    }

    private static String applyACL(String aclClause, String tenantId, Collection<String> accessibleResources) {
        return (QueryUtils.isUber(accessibleResources) && !AssetInstanceSQL.hasApplicablePolicies(accessibleResources))
            ? "" : MessageFormat.format(aclClause, tenantId, getAclClause(accessibleResources));
    }

    private static String applyACL(String aclClause, String tenantId, String assetId,
        Collection<String> accessibleResources) {
        return (QueryUtils.isUber(accessibleResources) && !AssetInstanceSQL.hasApplicablePolicies(accessibleResources))
            ? "" : MessageFormat.format(aclClause, tenantId, assetId, getAclClause(accessibleResources));
    }

    private static List<String> getTypeContextFilters(String tenantId, TypePredicate typePredicate) {
        if (typePredicate == null) {
            return Collections.emptyList();
        }
        Set<String> typeParentIds = typePredicate.getParent() == null ? null : typePredicate.getParent().getIds();
        Set<String> typeIds = typePredicate.getIds();
        if (CollectionUtils.isEmpty(typeParentIds) && CollectionUtils.isEmpty(typeIds)) {
            return getExpressionsWithoutTypeParentIdAndIds(tenantId, typePredicate);
        } else {
            if (CollectionUtils.isEmpty(typeParentIds)) {
                String clause = typePredicate.isDeepSearch() ? TAG_SUPER_TYPES_IN : TAG_TYPE_IN_0;
                return Collections.singletonList(
                    MessageFormat.format(clause, QueryUtils.getSqlListOfResources(typeIds)));
            } else {
                return Collections.singletonList(
                    getTypeParentIdsPredicate(tenantId, typeParentIds, typePredicate.getParent().isDeepSearch()));
            }
        }
    }

    private static List<String> getExpressionsWithoutTypeParentIdAndIds(String tenantId, TypePredicate typePredicate) {
        List<String> typeExpressions = QueryUtils.getEqualOrLikeFilterExpressions(typePredicate,
            typePredicate.getAttributes(), typePredicate.getReservedAttributes());
        if (!CollectionUtils.isEmpty(typeExpressions)) {
            String clause;
            /* If monitored entity, look for type */
            if (typePredicate.isMonitoredEntity()) {
                clause = MONITORED_ENTITY_TYPE;
            } else {
                clause = typePredicate.isDeepSearch() ? TAG_SUPER_TYPES_IN_CRITERIA_CLAUSE
                    : TAG_TYPE_IN_CRITERIA_CLAUSE;
            }
            String criteria = QueryUtils.flattenExpressions(typeExpressions, Operand.AND);
            return Collections.singletonList(MessageFormat.format(clause, tenantId, criteria));
        }
        return Collections.emptyList();
    }

    private static String getTypeParentIdsPredicate(String tenantId, Set<String> typeParentIds,
        boolean includeSubTypeInstances) {
        String clause = includeSubTypeInstances ?
            "tag_type in (select id from apm_alm.asset_type where tenant_id = ''{0}'' and super_types_array && "
                + "array[{1}])"
            : "tag_type in (select id from apm_alm.asset_type where tenant_id = ''{0}'' and super_type_id in ({1}))";

        return MessageFormat.format(clause, tenantId, QueryUtils.getSqlListOfResources(typeParentIds));
    }
}
