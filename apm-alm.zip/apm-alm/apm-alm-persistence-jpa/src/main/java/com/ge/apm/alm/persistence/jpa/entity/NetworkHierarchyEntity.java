/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.NetworkHierarchy;

/**
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 July 15, 2017
 * @since 1.0
 */
@Entity
@Table(name = "network_hierarchy", schema = "apm_alm")
@Getter
@Setter
@NoArgsConstructor
@ToString(callSuper = true)
public class NetworkHierarchyEntity extends AuditableEntity implements NetworkHierarchy {

    @Column(name = "network_node_id")
    private String networkNodeId;

    @Column(name = "parent_network_id")
    private String parentNetworkId;

    @Builder
    private NetworkHierarchyEntity(String id, String tenantId, String createdBy, String lastModifiedBy,
        String networkNodeId,
        String parentNetworkId) {
        super(id, tenantId, createdBy, lastModifiedBy);
        this.networkNodeId = networkNodeId;
        this.parentNetworkId = parentNetworkId;
    }
}

