/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.AssetUserPolicy;

/**
 * Created by Yogananda Gowda - 212590467 on 9/29/17.
 */
@Entity
@Table(name = "asset_user_policy", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class AssetUserPolicyEntity extends AuditableEntity implements AssetUserPolicy {

    @Column(name = "subject_id")
    private String subjectId;

    @Column(name = "subject_type")
    private String subjectType;

    @Column(name = "feature_id")
    private String featureId;

    @Column(name = "feature_code")
    private String featureCode;

    @Column(name = "user_name")
    private String userName;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "super_type")
    private String superType;

    @Column(name = "filter_criteria")
    private String filterCriteria;
}
