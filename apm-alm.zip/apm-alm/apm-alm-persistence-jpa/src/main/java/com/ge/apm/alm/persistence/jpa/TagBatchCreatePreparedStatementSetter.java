/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;

class TagBatchCreatePreparedStatementSetter extends AssetBatchPreparedStatementSetter<Tag> {

    TagBatchCreatePreparedStatementSetter(String tenantId, List<Tag> tags, Map<String, List<String>> superTypesByTypeId,
        JsonbAttributeConverter jsonbAttributeConverter,
        ListToTextArrayAttributeConverter listToTextArrayAttributeConverter,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter) {
        super(tenantId, tags, superTypesByTypeId, jsonbAttributeConverter, listToTextArrayAttributeConverter,
            offsetDateTimeAttributeConverter);
    }

    @Override
    public void setValues(PreparedStatement ps, int i) throws SQLException {
        Tag tag = instances.get(i);
        ps.setString(1, tag.getId());
        ps.setString(2, tag.getSourceKey());
        ps.setString(3, tag.getName());
        ps.setString(4, tag.getDescription());
        ps.setString(5, tenantId);
        ps.setString(6, tag.getAssetId());
        ps.setString(7, tag.getTagType());
        ps.setString(8, tag.getTagCategory());
        ps.setObject(9, jsonbAttributeConverter.convertToDatabaseColumn(tag.getAliases()));
        ps.setObject(10, jsonbAttributeConverter.convertToDatabaseColumn(tag.getAttributes()));
        ps.setObject(11,
            listToTextArrayAttributeConverter.convertToDatabaseColumn(superTypesByTypeId.get(tag.getTagType())));
        ps.setString(12, tag.getCreatedBy());
        ps.setTimestamp(13, now);
        ps.setString(14, tag.getLastModifiedBy());
        ps.setTimestamp(15, now);
        //setting computed values back to bean for client's convenience
        setCreatedDate(tag);
        setLastModifiedDate(tag);
        setSetSuperTypesArray(tag);
    }

    @Override
    protected String getTypeId(Tag tag) {
        return tag.getTagType();
    }
}