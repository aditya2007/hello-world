/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.converter;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ConversionServiceFactoryBean;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * Created by 212564021 on 3/15/17.
 */
@Component
public class AppConfig {

    @Autowired
    JsonbConveter jsonbConveter;
    @Autowired
    ListToTextArrayConverter listToTextArrayConverter;
    @Autowired
    OffsetDateTimeConverter offsetDateTimeConverter;

    @SuppressWarnings("PMD")
    @Bean(name = "conversionService")
    private ConversionService getConversionService() {
        ConversionServiceFactoryBean bean = new ConversionServiceFactoryBean();
        bean.setConverters(getConverters());
        bean.afterPropertiesSet();
        return bean.getObject();
    }

    private Set<Converter> getConverters() {
        Set<Converter> converters = new HashSet<>();
        if (jsonbConveter == null) {
            jsonbConveter = new JsonbConveter();
        }
        if (listToTextArrayConverter == null) {
            listToTextArrayConverter = new ListToTextArrayConverter();
        }
        if (offsetDateTimeConverter == null) {
            offsetDateTimeConverter = new OffsetDateTimeConverter();
        }
        converters.add(jsonbConveter);
        converters.add(listToTextArrayConverter);
        converters.add(offsetDateTimeConverter);
        return converters;
    }
}
