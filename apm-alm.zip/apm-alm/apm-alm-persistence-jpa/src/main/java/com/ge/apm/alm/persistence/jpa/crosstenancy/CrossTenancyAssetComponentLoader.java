/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.crosstenancy;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import lombok.Getter;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entitylistener.PostLoadHandler;
import com.ge.apm.common.support.RequestContext;

/**
 * @author Shu W. Yu 212614203
 * @version 1.0 Mar 07, 2018
 * @since 1.0
 */
@Getter
class CrossTenancyAssetComponentLoader extends AbstractCrossTenancyCall implements Runnable {

    private final List<PostLoadHandler<AssetInstanceEntity, AssetComponent>> postLoadHandlers;

    private final List<AssetInstanceEntity> assets;

    private final AttributeSelectEnum attributeSelectEnum;

    private final Set<AssetComponent> components;

    private final Collection<String> componentAcls;

    private final TransactionalRunner transactionalRunner;

    CrossTenancyAssetComponentLoader(String tenantId, boolean contextTenant, Collection<String> componentAcls,
        List<PostLoadHandler<AssetInstanceEntity, AssetComponent>> postLoadHandlers,
        List<AssetInstanceEntity> assets, AttributeSelectEnum attributeSelectEnum,
        Set<AssetComponent> components, AbstractCrossTenancyCall prevCall, TransactionalRunner transactionalRunner) {
        super(tenantId, contextTenant, prevCall);
        this.componentAcls = componentAcls;
        this.postLoadHandlers = postLoadHandlers;
        this.assets = assets;
        this.attributeSelectEnum = attributeSelectEnum;
        this.components = components;
        this.transactionalRunner = transactionalRunner;
    }

    @Override
    public void run() {
        if (!hasOp()) {
            return;
        }

        Object allAcls = getRequestContextMap().get(ALL_ACCESSIBLE_RESOURCES);
        try {
            setupCallContext();
            transactionalRunner.invoke(this::doRun);
        } finally {
            getRequestContextMap().put(ALL_ACCESSIBLE_RESOURCES, allAcls);
            if (isContextTenant()) {
                RequestContext.put(ALL_ACCESSIBLE_RESOURCES, allAcls);
            }
        }
    }

    private void doRun() {
        try {
            String tenantId = formatTenantId(getTenantId());
            postLoadHandlers
                .forEach(loader -> loader.postLoad(tenantId, componentAcls, assets, attributeSelectEnum, components));
        } finally {
            clean();
        }
    }
}
