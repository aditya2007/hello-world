/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.converter;

import java.io.IOException;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import org.postgresql.util.PGobject;
import org.springframework.stereotype.Component;

@Component
public class JsonbConveter implements org.springframework.core.convert.converter.Converter<PGobject, JsonNode> {

    private final ObjectReader objectReader = new ObjectMapper().reader();

    //following method is to make BeanRowMappper Happy for PreparedStatements.
    @Override
    public JsonNode convert(PGobject source) {
        if (source == null) {
            return null;
        } else if ("jsonb".equals(source.getType())) {
            try {
                return objectReader.readTree(source.getValue());
            } catch (IOException e) {
                throw new IllegalStateException("Unable to read JSONB data from db ", e);
            }
        }

        throw new UnsupportedOperationException("Unsupported source column type: " + source.getType());
    }
}
