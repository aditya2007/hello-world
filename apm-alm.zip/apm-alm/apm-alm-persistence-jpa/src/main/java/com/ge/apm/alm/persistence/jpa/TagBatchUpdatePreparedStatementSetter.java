/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;

@Slf4j
class TagBatchUpdatePreparedStatementSetter extends AssetBatchPreparedStatementSetter<Tag> {

    TagBatchUpdatePreparedStatementSetter(String tenantId, List<Tag> tags, Map<String, List<String>> superTypesByTypeId,
        JsonbAttributeConverter jsonbAttributeConverter,
        ListToTextArrayAttributeConverter listToTextArrayAttributeConverter,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter) {
        super(tenantId, tags, superTypesByTypeId, jsonbAttributeConverter, listToTextArrayAttributeConverter,
            offsetDateTimeAttributeConverter);
    }

    @Override
    public void setValues(PreparedStatement ps, int i) throws SQLException {
        Tag tag = instances.get(i);
        ps.setString(1, tag.getSourceKey());
        ps.setString(2, tag.getName());
        ps.setString(3, tag.getDescription());
        ps.setString(4, tag.getAssetId());
        ps.setString(5, tag.getTagType());
        ps.setString(6, tag.getTagCategory());
        ps.setObject(7, jsonbAttributeConverter.convertToDatabaseColumn(tag.getAliases()));
        ps.setObject(8, jsonbAttributeConverter.convertToDatabaseColumn(tag.getAttributes()));
        ps.setObject(9,
            listToTextArrayAttributeConverter.convertToDatabaseColumn(superTypesByTypeId.get(tag.getTagType())));
        ps.setString(10, tag.getLastModifiedBy());
        ps.setTimestamp(11, now);
        ps.setString(12, tenantId);
        ps.setString(13, tag.getId());
        //for updates only last modified date and super types is computed
        setLastModifiedDate(tag);
        setSetSuperTypesArray(tag);
    }

    @Override
    protected String getTypeId(Tag tag) {
        return tag.getTagType();
    }
}
