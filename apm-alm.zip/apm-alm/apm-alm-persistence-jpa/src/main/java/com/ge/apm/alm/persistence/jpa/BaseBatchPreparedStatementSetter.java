/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.time.OffsetDateTime;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;

import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;

@Slf4j
abstract class BaseBatchPreparedStatementSetter<T> implements BatchPreparedStatementSetter {

    protected final String tenantId;
    protected final List<T> instances;
    protected final JsonbAttributeConverter jsonbAttributeConverter;
    protected final Timestamp now;
    private final OffsetDateTime offsetDateTime;
    private Method lastModifiedDateMethod;
    private Method createdDateMethod;

    BaseBatchPreparedStatementSetter(String tenantId, List<T> instances,
        JsonbAttributeConverter jsonbAttributeConverter,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter) {
        this.tenantId = tenantId;
        this.instances = instances;
        this.jsonbAttributeConverter = jsonbAttributeConverter;
        offsetDateTime = OffsetDateTime.now();
        this.now = offsetDateTimeAttributeConverter.convertToDatabaseColumn(offsetDateTime);
        if (!CollectionUtils.isEmpty(this.instances)) {
            //expecting all instances to be of same subtype.
            try {
                lastModifiedDateMethod = ReflectionUtils
                    .findMethod(instances.get(0).getClass(), "setLastModifiedDate", OffsetDateTime.class);
                createdDateMethod = ReflectionUtils
                    .findMethod(instances.get(0).getClass(), "setCreatedDate", OffsetDateTime.class);
            } catch (Exception e) {
                log.warn("Error setting value to Bean. It is possible Bean is not settable", e);
            }
        }
    }

    void setCreatedDate(T instance) {
        if (createdDateMethod != null) {
            ReflectionUtils.invokeMethod(createdDateMethod, instance, offsetDateTime);
        }
    }

    void setLastModifiedDate(T instance) {
        if (lastModifiedDateMethod != null) {
            ReflectionUtils.invokeMethod(lastModifiedDateMethod, instance, offsetDateTime);
        }
    }

    @Override
    public int getBatchSize() {
        return instances.size();
    }
}
