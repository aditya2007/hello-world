/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entity;

import java.util.Collections;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.model.TemplateNotes;
import com.ge.apm.alm.persistence.PlaceholderPersistencyService;
import com.ge.apm.alm.persistence.jpa.SpringApplicationContext;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.repository.TemplateNotesRepository;

@Entity
@Table(name = "template", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class TemplateEntity extends SourceableEntity implements Template {

    @Column(name = "state")
    private String state;

    @Column(name = "status")
    private String status;

    @Column(name = "default_value_expressions")
    @Convert(converter = JsonbAttributeConverter.class)
    private JsonNode defaultValueExpressions;

    @Column(name = "attributes")
    @Convert(converter = JsonbAttributeConverter.class)
    private JsonNode attributes;

    @Column(name = "revision")
    private String revision;

    @Transient
    private List<TemplateNotes> templateNotes;
    @Transient
    private List<Placeholder> placeholders;

    @Builder
    private TemplateEntity(String id, String name, String tenantId, String createdBy,
        String lastModifiedBy, String sourceKey,
        String description, String state, String status, JsonNode defaultValueExpressions,
        JsonNode attributes, String revision) {
        super(id, name, tenantId, createdBy, lastModifiedBy, sourceKey, description);
        this.state = state;
        this.status = status;
        this.defaultValueExpressions = defaultValueExpressions;
        this.attributes = attributes;
        this.revision = revision;
    }

    @Override
    public List<TemplateNotes> getTemplateNotes() {
        if (CollectionUtils.isEmpty(templateNotes)) {
            loadTemplateNotes();
        }
        return Collections.unmodifiableList(templateNotes);
    }

    @Override
    public List<Placeholder> getPlaceholders() {
        if (CollectionUtils.isEmpty(placeholders)) {
            loadPlaceholders();
        }
        return Collections.unmodifiableList(placeholders);
    }

    private void loadTemplateNotes() {
        TemplateNotesRepository repository = SpringApplicationContext.getBeanByClass(TemplateNotesRepository.class);
        templateNotes = Collections.unmodifiableList(repository.findByTenantIdAndTemplateId(getTenantId(), getId()));
    }

    private void loadPlaceholders() {
        PlaceholderPersistencyService placeholderPersistencyService = SpringApplicationContext
            .getBeanByClass(PlaceholderPersistencyService.class);
        placeholders = placeholderPersistencyService.getPlaceholdersByTemplateId(getTenantId(), getId());
    }
}

