/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.ge.apm.alm.model.BaseDataModel;

@Getter
@Setter
@NoArgsConstructor
@MappedSuperclass
public abstract class BaseEntity implements BaseDataModel {

    @Id
    @Column(name = "id")
    private String id;

    @Column(name = "tenant_id")
    private String tenantId;

    BaseEntity(String id, String tenantId) {
        this.id = id;
        this.tenantId = tenantId;
    }

    @PrePersist
    protected void onCreate() {
        if (getId() == null) {
            //FIXME: setId(UUID.randomUUID().toString()); This is to be switched back to randomUUID in June, 2017
            throw new IllegalArgumentException("Please set id in the service layer");
        }
    }
}
