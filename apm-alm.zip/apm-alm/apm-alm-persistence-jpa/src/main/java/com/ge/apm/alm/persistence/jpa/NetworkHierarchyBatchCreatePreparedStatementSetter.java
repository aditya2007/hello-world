/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.ge.apm.alm.model.NetworkHierarchy;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;

/**
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 July 15, 2017
 * @since 1.0
 */
class NetworkHierarchyBatchCreatePreparedStatementSetter extends BaseBatchPreparedStatementSetter<NetworkHierarchy> {

    NetworkHierarchyBatchCreatePreparedStatementSetter(String tenantId, List<NetworkHierarchy> assetNodes,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter) {
        super(tenantId, assetNodes, null, offsetDateTimeAttributeConverter);
    }

    @Override
    public void setValues(PreparedStatement ps, int i) throws SQLException {
        NetworkHierarchy instance = instances.get(i);
        ps.setString(1, instance.getId());
        ps.setString(2, instance.getNetworkNodeId());
        ps.setString(3, instance.getParentNetworkId());
        ps.setString(4, tenantId);
        ps.setString(5, instance.getCreatedBy());
        ps.setTimestamp(6, now);
        ps.setString(7, instance.getLastModifiedBy());
        ps.setTimestamp(8, now);
        //setting computed values back to bean for client's convenience
        setCreatedDate(instance);
        setLastModifiedDate(instance);
    }
}