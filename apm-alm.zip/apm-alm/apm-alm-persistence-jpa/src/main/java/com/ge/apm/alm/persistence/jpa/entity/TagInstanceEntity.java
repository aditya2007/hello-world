/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entity;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.ListToTextArrayAttributeConverter;

@Entity
@Table(name = "tag_instance", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class TagInstanceEntity extends SourceableEntity implements Tag {

    /**
     * Tag classification type.
     */
    @Column(name = "tag_type")
    private String tagType;

    @Column(name = "asset_id")
    private String assetId;

    /**
     * Tag category such as SENSOR or COMPUTED, etc.
     */
    @Column(name = "tag_category")
    private String tagCategory;

    @Column(name = "aliases")
    private JsonNode aliases;

    @Column(name = "attributes")
    @Convert(converter = JsonbAttributeConverter.class)
    private JsonNode attributes;

    @SuppressWarnings("JpaAttributeTypeInspection")
    @Column(name = "super_types_array")
    @Convert(converter = ListToTextArrayAttributeConverter.class)
    private List<String> superTypesArray;

    @Transient
    @JsonIgnore
    private AssetInstanceEntity asset;

    @Transient
    @JsonIgnore
    private List<AssetGroup> assetGroups;

    @Builder
    private TagInstanceEntity(String id, String sourceKey, String name, String description, String tenantId,
        String createdBy, String lastModifiedBy, String tagType, String assetId, String tagCategory, JsonNode aliases,
        JsonNode attributes, List<String> superTypesArray) {
        super(id, name, tenantId, createdBy, lastModifiedBy, sourceKey, description);
        this.tagType = tagType;
        this.assetId = assetId;
        this.tagCategory = tagCategory;
        this.aliases = aliases;
        this.attributes = attributes;
        this.superTypesArray = superTypesArray;
    }
}

