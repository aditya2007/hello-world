/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.entity;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.AlmContextConfig;

@javax.persistence.Entity
@Table(name = "alm_context_config", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
public class AlmContextConfigEntity extends IdEntity implements AlmContextConfig {

    @Column(name = "tenant_id")
    private String tenantId;

    @Column(name = "value")
    private String value;

    @Column(name = "description")
    private String description;

    @ManyToOne
    @JoinColumn(name = "context_id", referencedColumnName = "id", nullable = false, updatable = false,
        insertable = true)
    private ContextEntity context;
}
