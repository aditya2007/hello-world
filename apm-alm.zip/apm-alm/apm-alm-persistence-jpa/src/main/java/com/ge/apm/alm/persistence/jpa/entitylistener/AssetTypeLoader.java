/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.core.convert.ConversionService;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetTypeEntity;
import com.ge.apm.alm.persistence.jpa.utils.BaseDataModelUtil;
import com.ge.apm.alm.persistence.jpa.utils.DatabaseUtil;

@Component
@Order(10)
public class AssetTypeLoader
    implements PostLoadHandler<AssetInstanceEntity, AssetComponent> {

    private static final String TYPE_QUERY = "SELECT * FROM apm_alm.asset_type WHERE id = :id";

    private static final String TYPES_QUERY = "SELECT * FROM apm_alm.asset_type WHERE id IN (:ids)";

    private static final AtomicReference<String> TYPE_QUERY_EXPANDED = new AtomicReference<>();
    private static final AtomicReference<String> TYPES_QUERY_EXPANDED = new AtomicReference<>();
    private final EntityBeanPropertyRowMapper<AssetTypeEntity> assetTypeRowMapper;
    @Autowired
    private NamedParameterJdbcTemplate jdbcParameterTemplate;

    @Autowired
    protected AssetTypeLoader(ConversionService conversionService) {
        assetTypeRowMapper =
            new EntityBeanPropertyRowMapper<>(AssetTypeEntity.class, conversionService);
    }

    private static String getSqlForSingleId() {
        String sql = TYPE_QUERY_EXPANDED.get();
        if (sql == null) {
            sql = TYPE_QUERY.replace("*", DatabaseUtil.getAllQueryColumns("asset_type")
                .stream().collect(Collectors.joining(",")));
            TYPE_QUERY_EXPANDED.set(sql);
        }

        return sql;
    }

    private static String getSqlForIds() {
        String sql = TYPES_QUERY_EXPANDED.get();
        if (sql == null) {
            sql = TYPES_QUERY.replace("*", DatabaseUtil.getAllQueryColumns("asset_type")
                .stream().collect(Collectors.joining(",")));
            TYPES_QUERY_EXPANDED.set(sql);
        }

        return sql;
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources,
        AssetInstanceEntity entity,
        AttributeSelectEnum selectEnum, Set<AssetComponent> components) {
        if (entity == null || components == null || !components.contains(
            AssetComponent.TYPE)) {
            return;
        }

        List<AssetTypeEntity> types = jdbcParameterTemplate.query(getSqlForSingleId(),
            new MapSqlParameterSource("id", entity.getAssetType()), assetTypeRowMapper);
        if (types.size() != 1) {
            throw new IllegalStateException(
                "Unable to find expected asset type: " + entity.getAssetType());
        }
        entity.setType(types.get(0));
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources,
        List<AssetInstanceEntity> assets,
        AttributeSelectEnum selectEnum, Set<AssetComponent> components) {
        if (assets.isEmpty() || components == null || !components.contains(
            AssetComponent.TYPE)) {
            return;
        }

        Set<String> typeIds = new HashSet<>();
        assets.forEach(asset -> typeIds.add(asset.getAssetType()));

        List<AssetTypeEntity> types = jdbcParameterTemplate.query(getSqlForIds(),
            new MapSqlParameterSource("ids", typeIds), assetTypeRowMapper);
        setTypes(assets, types);
    }

    private void setTypes(List<AssetInstanceEntity> assets, List<AssetTypeEntity> types) {
        Map<String, AssetTypeEntity> idMap = BaseDataModelUtil.toIdMap(types, null);
        assets.forEach(asset -> {
            String typeId = asset.getAssetType();
            AssetTypeEntity type = idMap.get(typeId);
            if (type == null) {
                throw new IllegalStateException(
                    "Unable to find expected asset type: " + typeId);
            }
            asset.setType(type);
        });
    }
}
