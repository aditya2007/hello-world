/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import static com.ge.apm.alm.persistence.jpa.sql.SQLConstants.AND;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.GroupPredicate;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.crosstenancy.CrossTenancyGet;
import com.ge.apm.alm.persistence.exceptions.IncompatibleItemsException;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.converter.TagCorrelationGroupRowMapper;
import com.ge.apm.alm.persistence.jpa.converter.TagCorrelationItemRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.AssetGroupEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceGroupItemEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetTypeGroupItemEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagCorrelationItemEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceGroupItemEntity;
import com.ge.apm.alm.persistence.jpa.repository.AssetGroupRepository;
import com.ge.apm.alm.persistence.jpa.repository.AssetInstanceGroupItemRepository;
import com.ge.apm.alm.persistence.jpa.repository.AssetTypeGroupItemRepository;
import com.ge.apm.alm.persistence.jpa.repository.TagCorrelationItemRepository;
import com.ge.apm.alm.persistence.jpa.repository.TagInstanceGroupItemRepository;
import com.ge.apm.alm.persistence.jpa.sql.AssetInstanceSQL;
import com.ge.apm.alm.persistence.jpa.sql.GroupSQL;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.utils.Validator;
import com.ge.apm.alm.persistence.mirror.Accessible;

@Service
@Slf4j
public class GroupPersistencyServiceImpl implements GroupPersistencyService {

    public static final String ITEMS_ARE_NOT_COMPATIBLE_OR_DO_NOT_EXIST = "Items are not compatible or do not exist.";

    public static final String ALL_TAG_ID_S_MUST_BE_ASSOCIATED_WITH_THE_SAME_ASSET
        = "All tag ID's must be associated with the same asset.";

    private final Map<AssetGroupCategory, EntityBeanPropertyRowMapper> rowMapperMap = new EnumMap<>(
        AssetGroupCategory.class);

    @Autowired
    private AssetGroupRepository assetGroupRepository;

    @Autowired
    private AssetTypeGroupItemRepository assetTypeGroupItemRepository;

    @Autowired
    private AssetInstanceGroupItemRepository assetInstanceGroupItemRepository;

    @Autowired
    private TagInstanceGroupItemRepository tagInstanceGroupItemRepository;

    @Autowired
    private TagCorrelationItemRepository tagCorrelationItemRepository;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private TagPersistencyService tagPersistencyService;

    @Autowired
    private ConversionService conversionService;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    @Autowired
    private DataSource dataSource;

    private JdbcTemplate jdbcTemplate;

    private EntityBeanPropertyRowMapper<AssetGroupEntity> groupBeanPropertyRowMapper;

    @Autowired
    private TagCorrelationGroupRowMapper tagCorrelationGroupRowMapper;

    @Autowired
    private TagCorrelationItemRowMapper tagCorrelationItemRowMapper;

    @PostConstruct
    public void initializeConvertionService() {
        jdbcTemplate = new JdbcTemplate(dataSource);
        groupBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(AssetGroupEntity.class, conversionService);
        EntityBeanPropertyRowMapper<AssetInstanceGroupItemEntity> assetItemBeanPropertyRowMapper
            = new EntityBeanPropertyRowMapper<>(AssetInstanceGroupItemEntity.class, conversionService);
        EntityBeanPropertyRowMapper<AssetTypeGroupItemEntity> assetTypeItemBeanPropertyRowMapper
            = new EntityBeanPropertyRowMapper<>(AssetTypeGroupItemEntity.class, conversionService);
        EntityBeanPropertyRowMapper<TagInstanceGroupItemEntity> tagItemBeanPropertyRowMapper
            = new EntityBeanPropertyRowMapper<>(TagInstanceGroupItemEntity.class, conversionService);
        EntityBeanPropertyRowMapper<TagCorrelationItemEntity> tagCorrelationItemBeanPropertyRowMapper
            = new EntityBeanPropertyRowMapper<>(TagCorrelationItemEntity.class, conversionService);

        rowMapperMap.put(AssetGroupCategory.ENTERPRISE_TYPE, assetTypeItemBeanPropertyRowMapper);
        rowMapperMap.put(AssetGroupCategory.SITE_TYPE, assetTypeItemBeanPropertyRowMapper);
        rowMapperMap.put(AssetGroupCategory.SEGMENT_TYPE, assetTypeItemBeanPropertyRowMapper);
        rowMapperMap.put(AssetGroupCategory.ASSET_TYPE, assetTypeItemBeanPropertyRowMapper);
        rowMapperMap.put(AssetGroupCategory.TAG_TYPE, assetTypeItemBeanPropertyRowMapper);

        rowMapperMap.put(AssetGroupCategory.ENTERPRISE, assetItemBeanPropertyRowMapper);
        rowMapperMap.put(AssetGroupCategory.SITE, assetItemBeanPropertyRowMapper);
        rowMapperMap.put(AssetGroupCategory.SEGMENT, assetItemBeanPropertyRowMapper);
        rowMapperMap.put(AssetGroupCategory.ASSET, assetItemBeanPropertyRowMapper);

        rowMapperMap.put(AssetGroupCategory.TAG, tagItemBeanPropertyRowMapper);
        rowMapperMap.put(AssetGroupCategory.TAG_CORRELATION, tagCorrelationItemBeanPropertyRowMapper);
    }

    @Override
    @Transactional
    public AssetGroup createAssetGroup(String tenantId, AssetGroup assetGroup) throws PersistencyServiceException {
        Validator.assertMatchingTenantId(tenantId, assetGroup.getTenantId());
        AssetGroupEntity assetGroupEntity = new AssetGroupEntity();
        BeanUtils.copyProperties(assetGroup, assetGroupEntity);
        assetGroupEntity.setTenantId(tenantId);
        if (assetGroup.getCategory() == AssetGroupCategory.TAG_CORRELATION && assetGroup.getName() == null) {
            assetGroupEntity.setName("");
        }
        try {
            return assetGroupRepository.saveAndFlush(assetGroupEntity);
        } catch (JpaSystemException jpa) {
            throw new PersistencyServiceException("Fail to create group: " + jpa.getMessage(), jpa);
        }
    }

    @Override
    @Transactional
    public int createAssetGroups(String tenantId, List<AssetGroup> assetGroups) throws PersistencyServiceException {
        //TODO Use bulk inserts.
        for (AssetGroup assetGroup : assetGroups) {
            createAssetGroup(tenantId, assetGroup);
        }
        return assetGroups.size();
    }

    @Override
    @Transactional
    public AssetGroup updateAssetGroup(String tenantId, AssetGroup assetGroup) throws PersistencyServiceException {
        if (assetGroupRepository.findOne(assetGroup.getId()) == null) {
            throw new ObjectNotFoundException("Group with id " + assetGroup.getId() + " not found");
        }
        return createAssetGroup(tenantId, assetGroup);
    }

    @Override
    @Transactional
    public void deleteAssetGroup(String tenantId, String assetGroupId) throws PersistencyServiceException {
        deleteAssetGroup(tenantId, null, assetGroupId, false);
    }

    @Override
    @Transactional
    public void deleteAssetGroupRecursively(String tenantId, Collection<String> accessibleResources,
        String assetGroupId) throws PersistencyServiceException {
        deleteAssetGroup(tenantId, accessibleResources, assetGroupId, true);
    }

    private void deleteAssetGroup(String tenantId, Collection<String> accessibleResources, String assetGroupId,
        boolean recursive) throws PersistencyServiceException {
        if (StringUtils.isEmpty(assetGroupId)) {
            throw new IllegalArgumentException("Asset Group ID cannot be null");
        }

        AssetGroup assetGroup = getAssetGroupById(tenantId, assetGroupId);
        if (assetGroup == null) {
            throw new ObjectNotFoundException("Asset Group " + assetGroupId + " does not exist");
        }
        if (recursive) {
            int itemsDeleted = deleteAssetGroupItems(tenantId, accessibleResources, assetGroupId);
            if (log.isDebugEnabled()) {
                log.debug("Recursively deleted {} items from group {} in tenant {}", itemsDeleted, assetGroupId,
                    tenantId);
            }
        }

        String deleteQuery = GroupSQL.getDeleteAssetGroupSql();
        try {
            int rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, assetGroupId);
            if (rowsDeleted == 0) {
                throw new ObjectNotFoundException(assetGroupId);
            }
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                "Asset Group has children or references to it. Hence cannot be deleted", ex);
        }
    }

    @Override
    @Transactional
    public AssetGroup getAssetGroupById(String tenantId, String id) {
        return assetGroupRepository.findByTenantIdAndId(tenantId, id);
    }

    @Override
    @Transactional
    public AssetGroup getAssetGroupBySourceKey(String tenantId, String sourceKey) {
        if (StringUtils.isEmpty(sourceKey)) {
            return null;
        }
        String query = GroupSQL.getSelectBySourceKey();
        try {
            return jdbcTemplate.queryForObject(query, groupBeanPropertyRowMapper, tenantId,
                sourceKey.toLowerCase(Locale.getDefault()));
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("Group not found with source key: {}", sourceKey);
            return null;
        }
    }

    @Override
    @Transactional
    public List<AssetGroup> getAssetGroupsBySourceKeys(String tenantId, List<String> sourceKeys) {
        if (CollectionUtils.isEmpty(sourceKeys)) {
            return Collections.emptyList();
        }
        String query = GroupSQL.getSelectBySourceKeys(sourceKeys);
        return Collections.unmodifiableList(jdbcTemplate.query(query, groupBeanPropertyRowMapper, tenantId));
    }

    @Override
    @Transactional
    public List<AssetGroup> getAssetGroups(String tenantId, GroupPredicate queryPredicate) {
        String filterPredicate = GroupSQL.getFilterPredicate(tenantId, queryPredicate);
        String andFilterPredicate = StringUtils.isEmpty(filterPredicate) ? "" : "and " + filterPredicate;
        StringBuilder query = new StringBuilder(GroupSQL.getSelectGroups());
        query.append(andFilterPredicate);
        String greaterThan = QueryUtils.getNextPageSortKeyFilter(queryPredicate);
        if (!StringUtils.isEmpty(greaterThan)) {
            query.append(AND).append(greaterThan);
        }
        query.append(QueryUtils.getPagination(queryPredicate));
        return Collections.unmodifiableList(jdbcTemplate.query(query.toString(), groupBeanPropertyRowMapper, tenantId));
    }

    @Override
    @Transactional
    public List<AssetGroup> getAssetGroupsOfItem(String tenantId, AssetGroupCategory category, String objectId) {
        String query = GroupSQL.selectGroups(category);
        return Collections.unmodifiableList(jdbcTemplate.query(query, groupBeanPropertyRowMapper, tenantId, objectId));
    }

    @Override
    @Transactional
    public Map<String, List<AssetGroup>> getAssetGroupsOfItems(String tenantId, AssetGroupCategory category,
        Collection<String> objectIds, boolean forUpdate) {
        String query = GroupSQL.selectGroupsByObjectIds(category, objectIds, forUpdate);
        List<Map.Entry<String, AssetGroupEntity>> result = jdbcTemplate.query(query, tagCorrelationGroupRowMapper,
            tenantId);
        Map<String, List<AssetGroup>> map = new HashMap<>();
        for (Map.Entry<String, AssetGroupEntity> e : result) {
            String key = e.getKey();
            AssetGroupEntity value = e.getValue();
            if (!map.containsKey(key)) {
                map.put(key, new ArrayList<>());
            }
            map.get(key).add(value);
        }
        return Collections.unmodifiableMap(map);
    }

    @Override
    @CrossTenancyGet
    public Map<String, AssetGroup> getCorrelationsForTags(String tenantId, @Accessible Collection<String> accessibleResources,
        Set<String> tagIds) {
        String query = GroupSQL.selectCorrelations(accessibleResources, tagIds);
        List<Map.Entry<String, AssetGroupEntity>> rslt = QueryUtils.isUber(accessibleResources) ? jdbcTemplate.query(
            query, tagCorrelationGroupRowMapper, tenantId) : jdbcTemplate.query(query, tagCorrelationGroupRowMapper,
            tenantId, tenantId, tenantId);
        Map<String, AssetGroup> map = new HashMap<>();
        for (Map.Entry<String, AssetGroupEntity> e : rslt) {
            map.put(e.getKey(), e.getValue());
        }
        return Collections.unmodifiableMap(map);
    }

    @Override
    @CrossTenancyGet
    public Map<String, List<AssetGroupItem>> getCorrelatedTags(String tenantId, @Accessible Collection<String> accessibleResources,
        Set<String> tagIds) {
        String query = GroupSQL.selectCorrelatedTags(accessibleResources, tagIds);
        List<Map.Entry<String, TagCorrelationItemEntity>> rslt = QueryUtils.isUber(accessibleResources) ? jdbcTemplate
            .query(query, tagCorrelationItemRowMapper, tenantId) : jdbcTemplate.query(query,
            tagCorrelationItemRowMapper, tenantId, tenantId, tenantId);
        Map<String, List<AssetGroupItem>> map = new HashMap<>();
        for (Map.Entry<String, TagCorrelationItemEntity> e : rslt) {
            String key = e.getKey();
            AssetGroupItem value = e.getValue();
            if (map.get(key) == null) {
                map.put(key, new ArrayList<>());
            }
            map.get(key).add(value);
        }
        return Collections.unmodifiableMap(map);
    }

    @Override
    @Transactional
    public int createAssetGroupItems(String tenantId, Collection<String> accessibleResources, String groupId,
        List<AssetGroupItem> assetGroupItems) throws PersistencyServiceException {
        AssetGroup assetGroup = getAssetGroupById(tenantId, groupId);
        if (assetGroup == null) {
            throw new ObjectNotFoundException("Cannot add items to a non-existing group " + groupId);
        }
        return createAssetGroupItems(tenantId, accessibleResources, assetGroup, assetGroupItems).size();
    }

    private List<AssetGroupItem> createAssetGroupItems(String tenantId, Collection<String> accessibleResources,
        AssetGroup group, List<AssetGroupItem> assetGroupItems) throws PersistencyServiceException {
        String groupId = group.getId();
        Set<String> groupIds = assetGroupItems.stream().map(AssetGroupItem::getGroupId).collect(Collectors.toSet());
        Validator.validateAllIdsAreUniform("group", groupId, groupIds);
        Set<String> tenantIds = assetGroupItems.stream().map(AssetGroupItem::getTenantId).collect(Collectors.toSet());
        Validator.validateAllIdsAreUniform("tenant", tenantId, tenantIds);
        try {
            switch (group.getCategory()) {
                case ENTERPRISE:
                case SITE:
                case SEGMENT:
                case ASSET:
                    return createAssetInstanceGroupItems(tenantId, accessibleResources, group.getCategory(),
                        assetGroupItems);
                case ENTERPRISE_TYPE:
                case SITE_TYPE:
                case SEGMENT_TYPE:
                case ASSET_TYPE:
                case TAG_TYPE:
                    return createAssetTypeGroupItems(tenantId, group.getCategory(), assetGroupItems);
                case TAG:
                    return createTagInstanceGroupItems(tenantId, accessibleResources, assetGroupItems);
                case TAG_CORRELATION:
                    return createTagCorrelationGroupItems(tenantId, accessibleResources, assetGroupItems);
                default:
                    throw new IllegalArgumentException(
                        "Group Category is unknown or not expected in this context:" + group.getCategory());
            }
        } catch (JpaSystemException jse) {
            // e.g., this jse is thrown when unique key constraints are violated
            throw new PersistencyServiceException(jse.getMessage(), jse);
        }
    }

    private List<AssetGroupItem> createAssetTypeGroupItems(String tenantId, AssetGroupCategory category,
        List<AssetGroupItem> assetGroupItems) throws IncompatibleItemsException {
        OOTBCoreTypesIdLookup typeId = getOotbCoreTypesIdLookup(category);
        Set<String> assetTypeIds = assetGroupItems.stream().map(AssetGroupItem::getObjectId).collect(
            Collectors.toSet());
        Set<String> coretypeids = StringUtils.isEmpty(typeId.getId()) ? Collections.emptySet() : Sets.newHashSet(
            typeId.getId());
        TypePredicate typePredicate = TypePredicate.builder().ids(assetTypeIds).attributeSelectEnum(
            AttributeSelectEnum.ID).parent(ParentPredicate.builder().ids(coretypeids).deepSearch(true).build()).build();
        List<AssetType> assetTypes = assetTypePersistencyService.findAllAssetTypes(tenantId, typePredicate);
        Set<String> foundTypeIds = assetTypes.stream().map(AssetType::getId).collect(Collectors.toSet());
        if (assetTypes.size() != assetTypeIds.size() || !foundTypeIds.containsAll(assetTypeIds)) {
            throw new IncompatibleItemsException(ITEMS_ARE_NOT_COMPATIBLE_OR_DO_NOT_EXIST);
        }
        List<AssetGroupItem> rslt = new ArrayList<>();
        for (AssetGroupItem groupItem : assetGroupItems) {
            AssetTypeGroupItemEntity item = new AssetTypeGroupItemEntity();
            BeanUtils.copyProperties(groupItem, item);
            rslt.add(assetTypeGroupItemRepository.saveAndFlush(item));
        }
        return rslt;
    }

    private List<AssetGroupItem> createAssetInstanceGroupItems(String tenantId, Collection<String> accessibleResources,
        AssetGroupCategory category, List<AssetGroupItem> assetGroupItems) throws IncompatibleItemsException {
        Set<String> assetIds = assetGroupItems.stream().map(AssetGroupItem::getObjectId).collect(Collectors.toSet());
        List<Asset> accessibleAssets = getAccessibleAssets(tenantId, accessibleResources, category, assetIds);
        if (accessibleAssets.size() != assetIds.size()) {
            throw new IncompatibleItemsException(ITEMS_ARE_NOT_COMPATIBLE_OR_DO_NOT_EXIST);
        }
        List<AssetGroupItem> rslt = new ArrayList<>();
        for (AssetGroupItem groupItem : assetGroupItems) {
            AssetInstanceGroupItemEntity item = new AssetInstanceGroupItemEntity();
            BeanUtils.copyProperties(groupItem, item);
            rslt.add(assetInstanceGroupItemRepository.saveAndFlush(item));
        }
        return rslt;
    }

    private List<Asset> getAccessibleAssets(String tenantId, Collection<String> accessibleResources,
        AssetGroupCategory category, Set<String> assetIds) {
        OOTBCoreTypesIdLookup typeId = getOotbCoreTypesIdLookup(category);
        Set<String> coretypeIds = StringUtils.isEmpty(typeId) ? Collections.emptySet() : Sets.newHashSet(
            typeId.getId());
        TypePredicate typePredicate = TypePredicate.builder().parent(ParentPredicate.builder().ids(coretypeIds)
            .deepSearch(true).build()).build();
        AssetPredicate assetPredicate = AssetPredicate.builder().ids(assetIds).type(typePredicate).attributeSelectEnum(
            AttributeSelectEnum.ID).build();
        return assetPersistencyService.getAssets(tenantId, accessibleResources, assetPredicate);
    }

    private OOTBCoreTypesIdLookup getOotbCoreTypesIdLookup(AssetGroupCategory category) {
        OOTBCoreTypesIdLookup typeId;
        switch (category) {
            case ENTERPRISE_TYPE:
            case ENTERPRISE:
                typeId = OOTBCoreTypesIdLookup.EnterpriseType;
                break;
            case SITE_TYPE:
            case SITE:
                typeId = OOTBCoreTypesIdLookup.SiteType;
                break;
            case SEGMENT_TYPE:
            case SEGMENT:
                typeId = OOTBCoreTypesIdLookup.SegmentType;
                break;
            case ASSET_TYPE:
            case ASSET:
                typeId = OOTBCoreTypesIdLookup.AssetType;
                break;
            case TAG_TYPE:
            case TAG:
            case TAG_CORRELATION:
                typeId = OOTBCoreTypesIdLookup.TagType;
                break;
            default:
                throw new IllegalArgumentException("Unknown category or category not applicable " + category);
        }
        return typeId;
    }

    private List<AssetGroupItem> createTagInstanceGroupItems(String tenantId, Collection<String> accessibleResources,
        List<AssetGroupItem> assetGroupItems) throws IncompatibleItemsException {
        Set<String> tagIds = assetGroupItems.stream().map(AssetGroupItem::getObjectId).collect(Collectors.toSet());
        List<Tag> accessibleTags = getAccessibleTags(tenantId, accessibleResources, AssetGroupCategory.TAG, tagIds);
        if (accessibleTags.size() != tagIds.size()) {
            throw new IncompatibleItemsException(ITEMS_ARE_NOT_COMPATIBLE_OR_DO_NOT_EXIST);
        }
        List<AssetGroupItem> rslt = new ArrayList<>();
        for (AssetGroupItem groupItem : assetGroupItems) {
            TagInstanceGroupItemEntity item = new TagInstanceGroupItemEntity();
            BeanUtils.copyProperties(groupItem, item);
            rslt.add(tagInstanceGroupItemRepository.saveAndFlush(item));
        }
        return rslt;
    }

    private List<Tag> getAccessibleTags(String tenantId, Collection<String> accessibleResources,
        AssetGroupCategory category, Set<String> tagIds) {
        OOTBCoreTypesIdLookup typeId = getOotbCoreTypesIdLookup(category);
        Set<String> coretypeIds = StringUtils.isEmpty(typeId) ? Collections.emptySet() : Sets.newHashSet(
            typeId.getId());
        TypePredicate typePredicate = TypePredicate.builder().parent(ParentPredicate.builder().ids(coretypeIds)
            .deepSearch(true).build()).build();
        TagPredicate tagPredicate = TagPredicate.builder().ids(tagIds).type(typePredicate).attributeSelectEnum(
            AttributeSelectEnum.BASIC).build();
        return tagPersistencyService.getTags(tenantId, accessibleResources, tagPredicate);
    }

    private List<AssetGroupItem> createTagCorrelationGroupItems(String tenantId, Collection<String> accessibleResources,
        List<AssetGroupItem> assetGroupItems) throws IncompatibleItemsException {
        validatePositionsInCorrelatedTags(assetGroupItems);
        Set<String> tagIds = assetGroupItems.stream().map(AssetGroupItem::getObjectId).collect(Collectors.toSet());
        validateSimilarAndAccessibleTags(tenantId, accessibleResources, tagIds);

        //TODO: Do bulk inserts
        List<AssetGroupItem> rslt = new ArrayList<>();
        for (AssetGroupItem groupItem : assetGroupItems) {
            TagCorrelationItemEntity item = new TagCorrelationItemEntity();
            BeanUtils.copyProperties(groupItem, item);
            rslt.add(tagCorrelationItemRepository.saveAndFlush(item));
        }

        return rslt;
    }

    /**
     * Validate that the positions in the correlated instances satisfy <ul> <li>Positions have no overlap.</li>
     * <li>Positions are sequential starting from 1.</li> </ul>
     */
    private void validatePositionsInCorrelatedTags(List<AssetGroupItem> assetGroupItems) {
        // the position numbers should be sequential from 1 to size
        Set<Integer> positions = assetGroupItems.stream().map(AssetGroupItem::getPosition).collect(Collectors.toSet());
        if (assetGroupItems.size() != positions.size()) {
            throw new IllegalArgumentException("Position of correlated group items must not overlap.");
        }

        Optional<Integer> optSum = positions.stream().reduce(Integer::sum);
        int sum = optSum.orElse(0);
        if (sum != (positions.size() * (positions.size() + 1)) / 2) {
            throw new IllegalArgumentException("Position values must be sequential from 1 to " + positions.size());
        }
    }

    @Override
    @CrossTenancyGet
    public List<AssetGroupItem> getGroupItems(String tenantId, @Accessible Collection<String> accessibleResources, String groupId)
        throws PersistencyServiceException {
        AssetGroup assetGroup = getAssetGroupById(tenantId, groupId);
        if (assetGroup == null) {
            throw new ObjectNotFoundException("No asset group found for id " + groupId);
        }
        String query = GroupSQL.selectGroupItems(assetGroup.getCategory(), accessibleResources);
        if ((QueryUtils.isUber(accessibleResources) && !AssetInstanceSQL.hasApplicablePolicies(accessibleResources))
            || isTypeCategory(assetGroup.getCategory())) {
            return Collections.unmodifiableList(
                jdbcTemplate.query(query, getRowMapper(assetGroup.getCategory()), tenantId, groupId));
        } else if (isTagOrCorrelationCategory(assetGroup.getCategory())) {
            return Collections.unmodifiableList(jdbcTemplate
                .query(query, getRowMapper(assetGroup.getCategory()), tenantId, groupId, tenantId, tenantId));
        }

        return Collections.unmodifiableList(
            jdbcTemplate.query(query, getRowMapper(assetGroup.getCategory()), tenantId, groupId, tenantId));
    }

    private boolean isTypeCategory(AssetGroupCategory category) {
        switch (category) {
            case ENTERPRISE_TYPE:
            case SITE_TYPE:
            case SEGMENT_TYPE:
            case ASSET_TYPE:
            case TAG_TYPE:
                return true;
            default:
                return false;
        }
    }

    private boolean isTagOrCorrelationCategory(AssetGroupCategory category) {
        return category == AssetGroupCategory.TAG || category == AssetGroupCategory.TAG_CORRELATION;
    }

    @Override
    @Transactional
    public int deleteAssetGroupItems(String tenantId, Collection<String> accessibleResources, String groupId)
        throws PersistencyServiceException {
        if (StringUtils.isEmpty(groupId)) {
            throw new IllegalArgumentException("groupID should be non-empty");
        }
        AssetGroup assetGroup = getAssetGroupById(tenantId, groupId);
        if (assetGroup == null) {
            throw new ObjectNotFoundException("Asset Group " + groupId + " does not exist");
        }

        String deleteQuery = GroupSQL.getDeleteGroupItemsSqlByGroupId(accessibleResources, assetGroup.getCategory());
        if ((QueryUtils.isUber(accessibleResources) && !AssetInstanceSQL.hasApplicablePolicies(accessibleResources))
            || isTypeCategory(assetGroup.getCategory())) {
            return jdbcTemplate.update(deleteQuery, tenantId, groupId);
        } else if (isTagOrCorrelationCategory(assetGroup.getCategory())) {
            return jdbcTemplate.update(deleteQuery, tenantId, groupId, tenantId, tenantId);
        }

        return jdbcTemplate.update(deleteQuery, tenantId, groupId, tenantId);
    }

    @Override
    @Transactional
    public int deleteAssetGroupItems(String tenantId, Collection<String> accessibleResources, String groupId,
        List<String> assetGroupItemIds) throws PersistencyServiceException {
        if (CollectionUtils.isEmpty(assetGroupItemIds) || StringUtils.isEmpty(groupId)) {
            throw new IllegalArgumentException("Group items being deleted or Group id cannot be empty");
        }

        AssetGroup assetGroup = getAssetGroupById(tenantId, groupId);
        if (assetGroup.getCategory() == AssetGroupCategory.TAG_CORRELATION) {
            // arbitrarily deleting items from a tag correlation group is not supported
            // such items need to be deleted one at a time otherwise it is too complicated to readjust by
            // splitting into multiple correlations,
            // e.g., imagine deleting from A-B-C-D-E-F-G-H-I-J-K items B E H I should split it into only F-G and J-K
            throw new UnsupportedOperationException(
                "Deleting items from correlated group by item identifier is not supported.");
        }
        return deleteGroupItemsInternal(tenantId, accessibleResources, assetGroup.getCategory(), assetGroupItemIds);
    }

    private int deleteGroupItemsInternal(String tenantId, Collection<String> accessibleResources,
        AssetGroupCategory category, List<String> assetGroupItemIds) throws PersistencyServiceException {
        String deleteQuery = GroupSQL.getDeleteGroupItemsSqlByIds(accessibleResources, category, assetGroupItemIds);
        int rowsDeleted;
        if ((QueryUtils.isUber(accessibleResources) && !AssetInstanceSQL.hasApplicablePolicies(accessibleResources))
            || isTypeCategory(category)) {
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId);
        } else if (isTagOrCorrelationCategory(category)) {
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, tenantId, tenantId);
        } else {
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, tenantId);
        }

        if (rowsDeleted != assetGroupItemIds.size()) {
            throw new PersistencyServiceException("Unable to delete all the group items " + assetGroupItemIds.size());
        }
        return rowsDeleted;
    }

    @Override
    @Transactional
    public AssetGroupItem addGroupItem(String tenantId, Collection<String> accessibleResources, String groupId,
        AssetGroupItem newItem) throws PersistencyServiceException {
        AssetGroup group = getAssetGroupById(tenantId, groupId);
        if (group == null) {
            throw new ObjectNotFoundException("Cannot add new item to a non-existing group " + groupId);
        }

        if (group.getCategory() == AssetGroupCategory.TAG_CORRELATION) {
            validateCompatibleCorrelatedGroup(tenantId, accessibleResources, groupId, newItem);

            String query = GroupSQL.getMaxPositionInCorrelatedTags(accessibleResources);
            Integer max = QueryUtils.isUber(accessibleResources) ? jdbcTemplate.queryForObject(query, Integer.class,
                tenantId, groupId) : jdbcTemplate.queryForObject(query, Integer.class, tenantId, groupId, tenantId,
                tenantId);
            int count = max == null ? 0 : max;

            TagCorrelationItemEntity item = newAsserGroupItem(tenantId, groupId, newItem, count + 1);
            try {
                return tagCorrelationItemRepository.saveAndFlush(item);
            } catch (JpaSystemException jse) {
                throw new PersistencyServiceException(jse.getMessage(), jse);
            }
        }

        return createAssetGroupItems(tenantId, accessibleResources, group, Collections.singletonList(newItem)).get(0);
    }

    @Override
    @Transactional
    public AssetGroupItem insertHeadItemToCorrelatedGroup(String tenantId, Collection<String> accessibleResources,
        String groupId, AssetGroupItem headItem) throws PersistencyServiceException {
        verifyIsCorrelatedGroup(tenantId, groupId);
        validateCompatibleCorrelatedGroup(tenantId, accessibleResources, groupId, headItem);

        List<AssetGroupItem> items = getGroupItems(tenantId, accessibleResources, groupId);
        for (int i = items.size(); i > 0; i--) {
            TagCorrelationItemEntity e = (TagCorrelationItemEntity) items.get(i - 1);
            e.setPosition(i + 1);
            tagCorrelationItemRepository.saveAndFlush(e);
        }
        TagCorrelationItemEntity tciEntity = newAsserGroupItem(tenantId, groupId, headItem, 1);
        return tagCorrelationItemRepository.saveAndFlush(tciEntity);
    }

    private AssetGroup verifyIsCorrelatedGroup(String tenantId, String groupId) throws ObjectNotFoundException {
        AssetGroup group = getAssetGroupById(tenantId, groupId);
        if (group == null) {
            throw new ObjectNotFoundException("Cannot add new item to a non-existing group " + groupId);
        }

        if (group.getCategory() != AssetGroupCategory.TAG_CORRELATION) {
            throw new IllegalArgumentException("Insert item only supports tag correlation");
        }

        return group;
    }

    /**
     * Validate that the new tag correlation item is compatible with the given group. The compatibility is defined as
     * <ul> <li>The new item is not already in the group.</li> <li>The new item and all items in the group are
     * accesible.</li> <li>The new item and all items in the group are associated with the same asset.</li> </ul>
     *
     * @param groupId id of the given group
     * @param newItem new tag correlation item whose compatibility with the group is being validated
     */
    private void validateCompatibleCorrelatedGroup(String tenantId, Collection<String> accessibleResources,
        String groupId, AssetGroupItem newItem) throws PersistencyServiceException {
        List<AssetGroupItem> items = getGroupItems(tenantId, accessibleResources, groupId);
        Set<String> tagIds = items.stream().map(AssetGroupItem::getObjectId).collect(Collectors.toSet());
        if (tagIds.contains(newItem.getObjectId())) {
            throw new IllegalArgumentException("New tag " + newItem.getObjectId() + " is already in group " + groupId);
        }
        tagIds.add(newItem.getObjectId());
        validateSimilarAndAccessibleTags(tenantId, accessibleResources, tagIds);
    }

    private void validateSimilarAndAccessibleTags(String tenantId, Collection<String> accessibleResources,
        Set<String> tagIds) throws IncompatibleItemsException {
        List<Tag> accessibleTags = getAccessibleTags(tenantId, accessibleResources, AssetGroupCategory.TAG_CORRELATION,
            tagIds);
        if (accessibleTags.size() != tagIds.size()) {
            throw new IncompatibleItemsException(ITEMS_ARE_NOT_COMPATIBLE_OR_DO_NOT_EXIST);
        }
        Set<String> assetIds = accessibleTags.stream().map(Tag::getAssetId).collect(Collectors.toSet());
        if (assetIds.size() > 1) {
            throw new IncompatibleItemsException(ALL_TAG_ID_S_MUST_BE_ASSOCIATED_WITH_THE_SAME_ASSET);
        }
    }

    @Override
    @Transactional
    public List<AssetGroupItem> mergeCorrelatedGroups(String tenantId, Collection<String> accessibleResources,
        AssetGroup srcGroup, AssetGroup targetGroup) throws PersistencyServiceException {

        String srcGroupId = (srcGroup == null) ? null : srcGroup.getId();
        String targetGroupId = (targetGroup == null) ? null : targetGroup.getId();

        verifyIsCorrelatedGroup(tenantId, srcGroupId);
        verifyIsCorrelatedGroup(tenantId, targetGroupId);

        List<AssetGroupItem> srcGroupItems = getGroupItems(tenantId, accessibleResources, srcGroupId);
        List<AssetGroupItem> targetGroupItems = getGroupItems(tenantId, accessibleResources, targetGroupId);
        if (!srcGroupItems.isEmpty() && !targetGroupItems.isEmpty()) {
            validateItemCompatibilityForMerging(tenantId, accessibleResources, srcGroupItems, targetGroupItems);
        }

        List<TagCorrelationItemEntity> targets = new ArrayList<>();
        int offset = srcGroupItems.size() + 1;
        for (int i = 0, size = targetGroupItems.size(); i < size; i++) {
            TagCorrelationItemEntity item = (TagCorrelationItemEntity) targetGroupItems.get(i);
            item.setGroupId(srcGroupId);
            item.setPosition(offset + i);
            targets.add(item);
        }
        List<AssetGroupItem> rslt = new ArrayList<>(srcGroupItems);
        rslt.addAll(tagCorrelationItemRepository.save(targets));
        tagCorrelationItemRepository.flush();
        assetGroupRepository.deleteByTenantIdAndId(tenantId, targetGroupId);
        return Collections.unmodifiableList(rslt);
    }

    protected void validateItemCompatibilityForMerging(String tenantId, Collection<String> accessibleResources,
        List<AssetGroupItem> srcGroupItems, List<AssetGroupItem> targetGroupItems) throws IncompatibleItemsException {
        Set<String> tagIds = srcGroupItems.stream().map(AssetGroupItem::getObjectId).collect(Collectors.toSet());
        tagIds.addAll(targetGroupItems.stream().map(AssetGroupItem::getObjectId).collect(Collectors.toSet()));
        List<Tag> accessibleTags = getAccessibleTags(tenantId, accessibleResources, AssetGroupCategory.TAG_CORRELATION,
            tagIds);
        Set<String> assetIds = accessibleTags.stream().map(Tag::getAssetId).collect(Collectors.toSet());
        if (assetIds.size() > 1) {
            throw new IncompatibleItemsException(ALL_TAG_ID_S_MUST_BE_ASSOCIATED_WITH_THE_SAME_ASSET);
        }
    }

    @Override
    @Transactional
    public String disassociateCorrelatedGroup(String tenantId, Collection<String> accessibleResources, String groupId,
        String objectId) throws PersistencyServiceException {
        verifyIsCorrelatedGroup(tenantId, groupId);
        List<AssetGroupItem> items = getGroupItems(tenantId, accessibleResources, groupId);
        int size = items.size();
        if (size == 0) {
            throw new IllegalArgumentException("Cannot disassociate an empty correlated group.");
        }

        List<String> objectIds = items.stream().map(AssetGroupItem::getObjectId).collect(Collectors.toList());
        int indexOfObject = objectIds.indexOf(objectId);
        if (indexOfObject == -1) {
            throw new IllegalArgumentException(
                "Object " + objectId + " is not in the group " + groupId + " to be disassociated.");
        }

        if (indexOfObject == size - 1) {
            // disassociate at tail not supported
            throw new UnsupportedOperationException(
                "Disassociate tail from a correlated group is not supported; explicitly delete it instead.");
        } else if (indexOfObject == 0) {
            return dissociateAtHeadOnly(tenantId, accessibleResources, groupId, items, size);
        } else if (indexOfObject + 1 == size - 1) {
            //disassociate second to last element
            deleteGroupItemsInternal(tenantId, accessibleResources, AssetGroupCategory.TAG_CORRELATION,
                Collections.singletonList(items.get(indexOfObject + 1).getId()));
            return null;
        }

        // need to create a new group
        String newGroupId = UUID.randomUUID().toString();
        AssetGroup newGroup = AssetGroupEntity.builder().id(newGroupId).category(AssetGroupCategory.TAG_CORRELATION)
            .tenantId(tenantId).build();
        createAssetGroup(tenantId, newGroup);

        List<AssetGroupItem> newGroupItems = items.subList(indexOfObject + 1, size);
        for (int i = 0, newSize = newGroupItems.size(); i < newSize; i++) {
            TagCorrelationItemEntity tci = (TagCorrelationItemEntity) newGroupItems.get(i);
            tci.setGroupId(newGroupId);
            tci.setPosition(i + 1);
        }
        createAssetGroupItems(tenantId, accessibleResources, newGroupId, newGroupItems);
        return newGroupId;
    }

    private String dissociateAtHeadOnly(String tenantId, Collection<String> accessibleResources, String groupId,
        List<AssetGroupItem> items, int size) throws PersistencyServiceException {
        // disassociate at head
        if (size <= 2) {
            deleteAssetGroup(tenantId, accessibleResources, groupId, true);
        } else {
            deleteGroupItemsInternal(tenantId, accessibleResources, AssetGroupCategory.TAG_CORRELATION,
                Collections.singletonList(items.get(0).getId()));
            for (int i = 1; i < size; i++) {
                TagCorrelationItemEntity e = (TagCorrelationItemEntity) items.get(i);
                e.setPosition(i);
                tagCorrelationItemRepository.saveAndFlush(e);
            }
        }
        return null;
    }

    @Override
    @Transactional
    public String deleteCorrelatedItem(String tenantId, Collection<String> accessibleResources, String groupId,
        String objectId) throws PersistencyServiceException {
        verifyIsCorrelatedGroup(tenantId, groupId);
        List<AssetGroupItem> items = getGroupItems(tenantId, accessibleResources, groupId);
        int size = items.size();
        if (size == 0) {
            throw new IllegalArgumentException("Cannot disassociate an empty correlated group.");
        }

        List<String> objectIds = items.stream().map(AssetGroupItem::getObjectId).collect(Collectors.toList());
        int indexOfObject = objectIds.indexOf(objectId);
        if (indexOfObject == -1) {
            throw new IllegalArgumentException(
                "Object " + objectId + " is not in the group " + groupId + " to be disassociated.");
        }

        if (deleteWithoutCreatingGroup(tenantId, accessibleResources, groupId, objectId, items, objectIds)) {
            return null;
        }

        // create a new correlated group to hold the split-off's
        String newGroupId = UUID.randomUUID().toString();
        AssetGroup newGroup = AssetGroupEntity.builder().id(newGroupId).category(AssetGroupCategory.TAG_CORRELATION)
            .tenantId(tenantId).build();
        createAssetGroup(tenantId, newGroup);
        List<AssetGroupItem> newGroupItems = items.subList(indexOfObject + 1, size);
        for (int i = 0, newSize = newGroupItems.size(); i < newSize; i++) {
            TagCorrelationItemEntity tci = (TagCorrelationItemEntity) newGroupItems.get(i);
            tci.setGroupId(newGroupId);
            tci.setPosition(i + 1);
        }
        createAssetGroupItems(tenantId, accessibleResources, newGroupId, newGroupItems);

        deleteGroupItemsInternal(tenantId, accessibleResources, AssetGroupCategory.TAG_CORRELATION,
            Collections.singletonList(items.get(indexOfObject).getId()));
        return newGroupId;
    }

    /**
     * Checks to see if we can delete without creating a new group to hold the split-off's. If yes, perform the deletion
     * and return <code>true</code>, otherwise return <code>false</code>.
     */
    private boolean deleteWithoutCreatingGroup(String tenantId, Collection<String> accessibleResources, String groupId,
        String objectId, List<AssetGroupItem> items, List<String> objectIds) throws PersistencyServiceException {
        int size = items.size();
        int indexOfObject = objectIds.indexOf(objectId);
        switch (size) {
            case 1:
            case 2:
                deleteAssetGroup(tenantId, accessibleResources, groupId, true);
                return true;
            case 3:
                if (indexOfObject == 1) {
                    deleteAssetGroup(tenantId, accessibleResources, groupId, true);
                } else {
                    deleteGroupItemsInternal(tenantId, accessibleResources, AssetGroupCategory.TAG_CORRELATION,
                        Collections.singletonList(items.get(indexOfObject).getId()));
                }
                return true;
            case 4:
                if (indexOfObject == 0 || indexOfObject == 3) {
                    deleteGroupItemsInternal(tenantId, accessibleResources, AssetGroupCategory.TAG_CORRELATION,
                        Collections.singletonList(items.get(indexOfObject).getId()));
                } else {
                    String otherId = indexOfObject == 1 ? items.get(0).getId() : items.get(3).getId();
                    deleteGroupItemsInternal(tenantId, accessibleResources, AssetGroupCategory.TAG_CORRELATION,
                        Arrays.asList(items.get(indexOfObject).getId(), otherId));
                }
                return true;
            default:
                return false;
        }
    }

    private TagCorrelationItemEntity newAsserGroupItem(String tenantId, String groupId, AssetGroupItem newItem,
        int position) {
        TagCorrelationItemEntity item = new TagCorrelationItemEntity();
        BeanUtils.copyProperties(newItem, item);
        item.setGroupId(groupId);
        item.setTenantId(tenantId);
        item.setPosition(position);
        return item;
    }

    private EntityBeanPropertyRowMapper getRowMapper(AssetGroupCategory category) {
        EntityBeanPropertyRowMapper mapper = rowMapperMap.get(category);
        if (mapper == null) {
            throw new IllegalArgumentException("Asset group category " + category + " is not supported.");
        }

        return mapper;
    }
}
