/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.converter;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.stereotype.Component;

import com.ge.apm.alm.persistence.jpa.entity.AssetGroupEntity;

@Component
public class TagCorrelationGroupRowMapper implements RowMapper<Entry<String, AssetGroupEntity>> {

    @Autowired
    private ConversionService conversionService;

    private EntityBeanPropertyRowMapper<AssetGroupEntity> groupBeanPropertyRowMapper;

    @PostConstruct
    public void initialize() {
        groupBeanPropertyRowMapper = new EntityBeanPropertyRowMapper(AssetGroupEntity.class, conversionService);
    }

    @Override
    public Entry<String, AssetGroupEntity> mapRow(ResultSet rs, int i) throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnCount = rsmd.getColumnCount();
        String key = JdbcUtils.getResultSetValue(rs, columnCount).toString();
        AssetGroupEntity value = groupBeanPropertyRowMapper.mapRow(rs, i);
        return new MyEntry(key, value);
    }

    private static class MyEntry implements Map.Entry<String, AssetGroupEntity> {

        private final String key;
        private final AssetGroupEntity value;

        MyEntry(String key, AssetGroupEntity value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String getKey() {
            return this.key;
        }

        @Override
        public AssetGroupEntity getValue() {
            return this.value;
        }

        // value is immutable
        @Override
        public AssetGroupEntity setValue(AssetGroupEntity value) {
            return this.value;
        }
    }
}
