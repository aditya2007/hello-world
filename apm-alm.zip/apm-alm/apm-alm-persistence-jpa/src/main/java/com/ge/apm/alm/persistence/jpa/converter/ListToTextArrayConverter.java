/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.converter;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.postgresql.jdbc.PgArray;
import org.springframework.stereotype.Component;

/**
 * Created by 212578721 on 2/5/18.
 * A converter to convert PostgresSQL Text array to and from Java list of String.
 */
@Component
public class ListToTextArrayConverter
    implements org.springframework.core.convert.converter.Converter<PgArray, List<String>> {

    @Override
    public List<String> convert(PgArray source) {
        if (source == null) {
            return new ArrayList<>();
        }

        try {
            if ("text".equals(source.getBaseTypeName())) {
                String[] values = (String[]) source.getArray();
                return Arrays.stream(values).collect(Collectors.toList());
            }

            throw new UnsupportedOperationException("Unsupported source base type: " + source.getBaseTypeName());
        } catch (SQLException ex) {
            throw new IllegalStateException("Conversion failure: " + ex.getMessage(), ex);
        }
    }
}
