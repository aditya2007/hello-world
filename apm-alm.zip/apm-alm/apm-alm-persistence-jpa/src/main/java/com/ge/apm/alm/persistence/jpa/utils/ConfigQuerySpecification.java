/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.utils;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.ConfigContextQuery;
import com.ge.apm.alm.persistence.jpa.entity.AlmContextConfigEntity;
import com.ge.apm.alm.persistence.jpa.entity.ReservedAttributeContextConfigEntity;

public class ConfigQuerySpecification {

    public static Specification<ReservedAttributeContextConfigEntity> filterReservedAttributeConfigBy(String tenantId,
        ConfigContextQuery configContextQuery) {
        return (root, query, builder) -> {
            final List<javax.persistence.criteria.Predicate> predicates = new ArrayList<>();
            String[] contexts = configContextQuery.getContext();
            if (!StringUtils.isEmpty(contexts)) {
                predicates.add(builder.and(root.get("context").get("contextName").in((Object[]) contexts)));
            }
            String[] codes = configContextQuery.getCode();
            if (!StringUtils.isEmpty(codes)) {
                predicates.add(builder.and(root.get("code").in((Object[]) codes)));
            }
            String[] semanticNames = configContextQuery.getSemanticName();
            if (!StringUtils.isEmpty(semanticNames)) {
                predicates.add(builder.and(root.get("semanticName").in((Object[]) semanticNames)));
            }
            String[] displayNames = configContextQuery.getDisplayName();
            if (!StringUtils.isEmpty(displayNames)) {
                predicates.add(builder.and(root.get("displayName").in((Object[]) displayNames)));
            }
            Boolean activation = configContextQuery.getIsActive();
            if (activation != null) {
                predicates.add(builder.equal(root.get("isActive"), activation));
            }

            predicates.add(builder.or(builder.equal(root.get("tenantId"), SeedOOTBData.SYSTEM_TENANT_ID),
                builder.equal(root.get("tenantId"), tenantId)));
            return builder.and(predicates.toArray(new javax.persistence.criteria.Predicate[predicates.size()]));
        };
    }

    public static Specification<AlmContextConfigEntity> filterAlmConfigBy(String tenantId,
        ConfigContextQuery configContextQuery) {
        return (root, query, builder) -> {
            final List<javax.persistence.criteria.Predicate> predicates = new ArrayList<>();
            String[] contexts = configContextQuery.getContext();
            if (!StringUtils.isEmpty(contexts)) {
                predicates.add(builder.and(root.get("context").get("contextName").in((Object[]) contexts)));
            }
            Boolean activation = configContextQuery.getIsActive();
            if (activation != null) {
                predicates.add(builder.equal(root.get("value"), activation));  // key - value
            }

            predicates.add(builder.or(builder.equal(root.get("tenantId"), SeedOOTBData.SYSTEM_TENANT_ID),
                builder.equal(root.get("tenantId"), tenantId)));
            return builder.and(predicates.toArray(new javax.persistence.criteria.Predicate[predicates.size()]));
        };
    }
}
