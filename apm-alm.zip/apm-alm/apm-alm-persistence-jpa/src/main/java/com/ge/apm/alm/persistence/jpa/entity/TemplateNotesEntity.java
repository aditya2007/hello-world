/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.ge.apm.alm.model.TemplateNotes;

@Entity
@Table(name = "template_notes", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class TemplateNotesEntity extends BaseEntity implements TemplateNotes {

    @Column(name = "template_id")
    private String templateId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "notes_id", referencedColumnName = "id")
    private NotesEntity notes;

    @Builder
    private TemplateNotesEntity(String id, String tenantId, String templateId, NotesEntity notes) {
        super(id, tenantId);
        this.templateId = templateId;
        this.notes = notes;
    }
}

