/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.crosstenancy;

import java.util.concurrent.Callable;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implements over an interface to ensure being proxy-able.
 *
 * @author Shu W. Yu 212614203
 * @version 1.0 Mar 22, 2018
 * @since 1.0
 */
@Component
@Transactional
class TransactionalRunnerImpl implements TransactionalRunner {

    @Override
    public void invoke(Runnable runnable) {
        runnable.run();
    }

    @Override
    @SuppressWarnings("squid:S00112")
    public <V> V invoke(Callable<V> callable) throws Exception {
        return callable.call();
    }
}
