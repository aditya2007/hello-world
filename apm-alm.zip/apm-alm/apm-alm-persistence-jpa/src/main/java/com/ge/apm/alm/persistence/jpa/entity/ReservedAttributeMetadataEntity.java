/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.ReservedAttributeMetadata;
import com.ge.apm.alm.persistence.jpa.utils.JsonConverter;

/**
 * Created by 212402415 on 3/8/17.
 */
@Entity
@Table(name = "reserved_attribute_metadata", schema = "apm_alm")
@Getter
@Setter
@NoArgsConstructor
@ToString(callSuper = true)
public class ReservedAttributeMetadataEntity extends IdEntity implements
    ReservedAttributeMetadata {

    @Column(name = "type", nullable = false, updatable = false)
    private String type;

    @Column(name = "config_json", columnDefinition = "json")
    @Convert(converter = JsonConverter.class)
    private JsonNode configJson;
}
