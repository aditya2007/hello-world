/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.ge.apm.alm.model.Edge;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;

/**
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 July 15, 2017
 * @since 1.0
 */
class EdgeBatchCreatePreparedStatementSetter extends BaseBatchPreparedStatementSetter<Edge> {

    EdgeBatchCreatePreparedStatementSetter(String tenantId, List<Edge> networks,
        JsonbAttributeConverter jsonbAttributeConverter,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter) {
        super(tenantId, networks, jsonbAttributeConverter, offsetDateTimeAttributeConverter);
    }

    @Override
    public void setValues(PreparedStatement ps, int i) throws SQLException {
        Edge instance = instances.get(i);
        ps.setString(1, instance.getId());
        ps.setString(2, instance.getName());
        ps.setString(3, instance.getDescription());
        ps.setString(4, tenantId);
        ps.setString(5, instance.getSource());
        ps.setString(6, instance.getTarget());
        ps.setString(7, instance.getDirection().toString());
        ps.setString(8, instance.getAssetId());
        ps.setObject(9, jsonbAttributeConverter.convertToDatabaseColumn(instance.getAttributes()));
        ps.setString(10, instance.getCreatedBy());
        ps.setTimestamp(11, now);
        ps.setString(12, instance.getLastModifiedBy());
        ps.setTimestamp(13, now);
        //setting computed values back to bean for client's convenience
        setCreatedDate(instance);
        setLastModifiedDate(instance);
    }
}