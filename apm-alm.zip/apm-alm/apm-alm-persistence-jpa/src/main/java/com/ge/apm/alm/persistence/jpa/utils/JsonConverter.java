/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.utils;

import java.io.IOException;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import org.postgresql.util.PGobject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.apm.alm.persistence.jpa.entity.ReservedAttributeMetadataEntity;

@Converter
public class JsonConverter implements AttributeConverter<JsonNode, Object> {

    private final ObjectReader objectReader = new ObjectMapper().reader();

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public ReservedAttributeMetadataEntity convertToDatabaseColumn(JsonNode reservedAttributeConfig) {
        throw new UnsupportedOperationException("Convert to database column is not supported");
    }

    @Override
    public JsonNode convertToEntityAttribute(Object object) {
        try {
            return objectReader.readTree(((PGobject)object).getValue());
        } catch (IOException exp) {
            logger.warn("Exception while converting object to json", exp);
            return null;
        }
    }
}