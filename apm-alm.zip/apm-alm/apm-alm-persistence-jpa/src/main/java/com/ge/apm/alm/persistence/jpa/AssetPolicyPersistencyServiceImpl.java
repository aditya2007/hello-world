/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.AssetRestrictionFeature;
import com.ge.apm.alm.model.AssetUserPolicy;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectAlreadyExistsException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.entity.AssetRestrictionFeatureEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetUserPolicyEntity;
import com.ge.apm.alm.persistence.jpa.repository.AssetPolicyRepository;
import com.ge.apm.alm.persistence.jpa.repository.AssetRestrictionFeatureRepository;

/**
 * Created by Yogananda Gowda - 212590467 on 9/28/17.
 */
@Service
@Slf4j
@Transactional
public class AssetPolicyPersistencyServiceImpl implements AssetPolicyPersistencyService {

    @Autowired
    private AssetRestrictionFeatureRepository restrictionFeatureRepository;

    @Autowired
    private AssetPolicyRepository assetPolicyRepository;

    @Override
    public List<AssetRestrictionFeature> getAssetRestrictionFeaturesByStatus(boolean isActive) {
        List<? extends AssetRestrictionFeature> features = getAssetRestrictionFeatures();
        return features.stream().filter(f -> (f.isFeatureActive() == isActive)).collect(Collectors.toList());
    }

    @Override
    public List<AssetRestrictionFeature> getAssetRestrictionFeatures() {
        List<AssetRestrictionFeatureEntity> features = restrictionFeatureRepository.findAll();
        return Collections.unmodifiableList(features);
    }

    @Override
    public AssetRestrictionFeature getAssetRestrictionFeatureByCode(String featureCode) {
        return restrictionFeatureRepository.findByFeatureCode(featureCode);
    }

    @Override
    public AssetUserPolicy createUserPolicy(String tenantId, AssetUserPolicy assetUserPolicy)
        throws PersistencyServiceException {
        AssetUserPolicyEntity policyEntity = (AssetUserPolicyEntity) assetUserPolicy;
        policyEntity.setId(getRandomId());
        policyEntity.setTenantId(tenantId);
        try {
            return assetPolicyRepository.saveAndFlush(policyEntity);
        } catch (TransactionSystemException tse) {
            log.error("Unique Constraint Exception while creating User Policy {}, ", tse);
            throw new ObjectAlreadyExistsException(convertErrorMsg(tse.getMessage()), tse.getCause());
        } catch (JpaSystemException jse) {
            log.error("Unique Constraint Exception while creating User Policy {}, ", jse);
            throw new ObjectAlreadyExistsException(convertErrorMsg(jse.getMessage()), jse.getCause());
        }
    }

    @Override
    public int createUserPolicies(String tenantId, List<AssetUserPolicy> assetUserPolicies)
        throws PersistencyServiceException {
        List<AssetUserPolicyEntity> entities = assetUserPolicies.stream().map(policy -> {
            AssetUserPolicyEntity policyEntity = (AssetUserPolicyEntity) policy;
            policyEntity.setId(getRandomId());
            policyEntity.setTenantId(tenantId);
            return policyEntity;
        }).collect(Collectors.toList());
        try {
            List<AssetUserPolicyEntity> savedPolicies = assetPolicyRepository.save(entities);
            assetPolicyRepository.flush();
            return Objects.nonNull(savedPolicies) ? savedPolicies.size() : 0;
        } catch (TransactionSystemException tse) {
            log.error("Unique Constraint Exception while creating User Policies {}, ", tse);
            throw new ObjectAlreadyExistsException(convertErrorMsg(tse.getMessage()), tse.getCause());
        } catch (JpaSystemException jse) {
            log.error("Unique Constraint Exception while creating User Policies {}, ", jse);
            throw new ObjectAlreadyExistsException(convertErrorMsg(jse.getMessage()), jse.getCause());
        }
    }

    @Override
    public void deleteAssetUserPolicy(String tenantId, String assetPolicyId) throws PersistencyServiceException {
        assetPolicyRepository.deleteByTenantIdAndId(tenantId, assetPolicyId);
    }

    @Override
    @Transactional
    public void deleteAllAssetUserPolicy(String tenantId) throws PersistencyServiceException {
        assetPolicyRepository.deleteByTenantId(tenantId);
    }

    @Override
    public AssetUserPolicy getAssetUserPolicyById(String tenantId, String policyId) {
        return assetPolicyRepository.findByTenantIdAndId(tenantId, policyId);
    }

    @Override
    public List<AssetUserPolicy> getAssetUserPolicies(String tenantId, String assetFeatureId) {
        return assetPolicyRepository.findByTenantIdAndFeatureId(tenantId, assetFeatureId);
    }

    @Override
    public List<AssetUserPolicy> getAssetUserPoliciesBySubject(String tenantId, String subjectId, String subjectType) {
        return assetPolicyRepository.findByTenantIdAndSubjectIdAndSubjectType(tenantId, subjectId, subjectType);
    }

    @Override
    public List<AssetUserPolicy> getAssetUserPoliciesBySubjects(String tenantId, List<String> subjectIds) {
        return assetPolicyRepository.findByTenantIdAndSubjectIds(tenantId, subjectIds);
    }

    @Override
    public List<AssetUserPolicy> getAssetUserPoliciesByTenant(String tenantId) {
        return assetPolicyRepository.findByTenantId(tenantId);
    }

    private String getRandomId() {
        return UUID.randomUUID().toString();
    }

    private String convertErrorMsg(String errorMsg) {
        String parsedMsg = StringUtils.substringBetween(errorMsg, "Detail: Key ", ") already exists.");
        parsedMsg = StringUtils.isNotEmpty(parsedMsg) ? parsedMsg.replaceAll("\\)=\\(", "~").replaceAll("\\(", "")
            .replaceAll("\\)", "") : "";
        if (StringUtils.isEmpty(parsedMsg)) {
            return errorMsg;
        }
        String[] tokens = parsedMsg.split("~");
        String[] keys = tokens[0].split(",");
        String[] values = tokens[1].split(",");
        if (isTokensAreValid(keys) && isTokensAreValid(values) && isTwoTokensAreEqual(keys, values)) {
            StringBuilder convertedErrorMsg = new StringBuilder();
            IntStream.range(0, keys.length).forEach(idx -> convertedErrorMsg.append(keys[idx]).append("=")
                .append(values[idx].trim()).append(","));
            return StringUtils.chop(convertedErrorMsg.toString());
        } else {
            return errorMsg;
        }
    }

    private boolean isTokensAreValid(String[] tokens) {
        return tokens != null && tokens.length > 0;
    }

    private boolean isTwoTokensAreEqual(String[] keys, String[] values) {
        return keys.length == values.length;
    }
}
