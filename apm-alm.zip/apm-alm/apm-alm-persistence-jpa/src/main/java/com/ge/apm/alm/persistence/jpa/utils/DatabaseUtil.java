/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.sql.DataSource;

import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.jdbc.support.MetaDataAccessException;

import com.ge.apm.alm.persistence.jpa.SpringApplicationContext;

public final class DatabaseUtil {

    private static final Map<String, List<String>> ALL_COLUMNS_BY_TABLE = new ConcurrentHashMap<>();

    private static final Map<String, List<String>> ALL_QUERY_COLUMNS_BY_TABLE =
        new ConcurrentHashMap<>();

    private static final Map<String, Set<String>> EXCL_QUERY_COLUMNS = new HashMap<>();

    private DatabaseUtil() {
        // nothing.
    }

    public static List<String> getAllQueryColumns(String tableName) {
        String table = tableName.toLowerCase(Locale.getDefault());
        doGetAllColumns(table);
        List<String> columns = ALL_QUERY_COLUMNS_BY_TABLE.get(table);

        return columns == null ? null : Collections.unmodifiableList(columns);
    }

    @SuppressWarnings("squid:S00112")
    private static void doGetAllColumns(String table) {
        if (ALL_COLUMNS_BY_TABLE.get(table) != null) {
            return;
        }

        List<String> columnNames = new ArrayList<>();
        DataSource dataSource = SpringApplicationContext.getBeanByClass(DataSource.class);
        try {
            JdbcUtils.extractDatabaseMetaData(dataSource, dbmd -> {
                try (ResultSet rs = dbmd.getColumns(null, "apm_alm",
                    table.toLowerCase(Locale.getDefault()), null)) {
                    while (rs.next()) {
                        columnNames.add(rs.getString("COLUMN_NAME")
                            .toLowerCase(Locale.getDefault()));
                    }
                }
                return null;
            });
        } catch (MetaDataAccessException unlikelyException) {
            throw new RuntimeException("Unable to get table columns", unlikelyException);
        }

        List<String> queryColumnNames = new ArrayList<>(columnNames);
        Set<String> excluded = EXCL_QUERY_COLUMNS.get(table);
        if (excluded != null) {
            queryColumnNames.removeAll(excluded);
        }

        ALL_COLUMNS_BY_TABLE.put(table, columnNames);
        ALL_QUERY_COLUMNS_BY_TABLE.put(table, queryColumnNames);
    }
}
