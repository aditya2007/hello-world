/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.sql;

import java.text.MessageFormat;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.query.GroupPredicate;
import com.ge.apm.alm.model.query.Operand;

public final class GroupSQL {

    private static final String DELETE_FROM_GROUP_ITEM = "delete from {0} ";

    private static final String SELECT_FROM_GROUP_ITEM = "select * from {0} ";

    private static final String WHERE_TENANT_ID = " where tenant_id = ? ";

    private static final String SELECT_FROM_APM_ALM_ASSET_GROUP = "select * from apm_alm.asset_group "
        + WHERE_TENANT_ID;

    private static final String WHERE_TENAND_ID_AND_ID_CLAUSE = WHERE_TENANT_ID + " and id = ?";

    private static final String WHERE_TENAND_ID_AND_GROUP_ID_CLAUSE = WHERE_TENANT_ID + " and group_id = ?";

    private static final String WHERE_TENAND_ID_AND_IDS_CLAUSE = WHERE_TENANT_ID + " and id in ({1})";

    private static final String SELECT_BY_SOURCE_KEY = SELECT_FROM_APM_ALM_ASSET_GROUP + " and lower(source_key) = ?";

    private static final String SELECT_BY_SOURCE_KEYS = SELECT_FROM_APM_ALM_ASSET_GROUP
        + " and lower(source_key) in ({0})";

    private static final String SELECT_FROM_APM_ALM_ASSET_GROUP_WITH_ITEM_ID = SELECT_FROM_APM_ALM_ASSET_GROUP
        + " and id in (select group_id from {0} where {1} = ?)";

    private static final String SELECT_FROM_APM_ALM_ASSET_GROUP_WITH_ITEM_IDS = "select g.*, e.{0} from "
        + "apm_alm.asset_group g join {1} e on "
        + "g.tenant_id = e.tenant_id and g.id = e.group_id where g.tenant_id = ? and e.{0} in ({2})";

    private static final String SELECT_FROM_APM_ALM_ASSET_GROUP_WITH_ITEM_IDS_FOR_UPDATE = "select g.*, e.{0} from "
        + "apm_alm.asset_group g join {1} e on "
        + "g.tenant_id = e.tenant_id and g.id = e.group_id where g.tenant_id = ? and e.{0} in ({2}) order by g.id, e"
        + ".{0} asc FOR UPDATE";

    private static final String DELETE_GROUP_ITEMS_SQL = DELETE_FROM_GROUP_ITEM + WHERE_TENAND_ID_AND_IDS_CLAUSE;

    private static final String AND_OBJECT_ID_IN = " and object_id in ";

    private static final String SELECT_TAG_ID_ACL
        = "select id from apm_alm.tag_instance where tenant_id = ? and asset_id in ";

    private static final String DELETE_GROUP_ITEMS_BY_GROUPID_SQL = DELETE_FROM_GROUP_ITEM
        + WHERE_TENAND_ID_AND_GROUP_ID_CLAUSE;

    private static final String SELECT_GROUP_ITEMS_BY_GROUPID_SQL = SELECT_FROM_GROUP_ITEM
        + WHERE_TENAND_ID_AND_GROUP_ID_CLAUSE;

    private static final String DELETE_ASSET_GROUP_SQL = "delete from apm_alm.asset_group "
        + WHERE_TENAND_ID_AND_ID_CLAUSE;

    private static final String DELETE_GROUP_ITEMS_BY_OBJECT_ID_IN_SQL = DELETE_FROM_GROUP_ITEM + WHERE_TENANT_ID
        + AND_OBJECT_ID_IN;

    private static final String MAX_POSITION_TAG_CORRELATION_BY_GROUP_ID =
        "select max(position) from apm_alm.asset_group_tag_correlation " + WHERE_TENAND_ID_AND_GROUP_ID_CLAUSE;

    private static final String ORDER_BY_POSITION = " order by position asc";

    private static final String UPDATE_CORRELATION_ITEM_POSITIONS =
        "update apm_alm.asset_group_tag_correlation set position = position + ? where tenant_id ="
            + " ? and group_id = ? and position >= ?";

    private GroupSQL() {
    }

    public static String getSelectBySourceKey() {
        return SELECT_BY_SOURCE_KEY;
    }

    public static String getSelectBySourceKeys(List<String> sourceKeys) {
        String listOfLowerCaseSrcKeys = QueryUtils.getSqlListOfResources(
            sourceKeys.stream().map(String::toLowerCase).collect(Collectors.toList()));
        return MessageFormat.format(SELECT_BY_SOURCE_KEYS, listOfLowerCaseSrcKeys);
    }

    public static String getDeleteGroupItemsSqlByIds(Collection<String> accessibleResources,
        AssetGroupCategory category, List<String> assetGroupItemIds) {
        String deleteSQL = MessageFormat.format(DELETE_GROUP_ITEMS_SQL,
            getGroupItemTableColumn(category).getTableName(), QueryUtils.getSqlListOfResources(assetGroupItemIds));
        return getSecuredSQL(accessibleResources, category, deleteSQL);
    }

    public static String getDeleteGroupItemsSqlByGroupId(Collection<String> accessibleResources,
        AssetGroupCategory category) {
        String deleteSQL = MessageFormat.format(DELETE_GROUP_ITEMS_BY_GROUPID_SQL,
            getGroupItemTableColumn(category).getTableName());
        return getSecuredSQL(accessibleResources, category, deleteSQL);
    }

    public static String getDeleteAssetGroups(Set<String> ids) {
        return MessageFormat.format("delete from apm_alm.asset_group where tenant_id = ? and id in ({0}) returning *",
            QueryUtils.getSqlListOfResources(ids));
    }

    private static String getSecuredSQL(Collection<String> accessibleResources, AssetGroupCategory category,
        String sql) {
        if (CollectionUtils.isEmpty(accessibleResources) && !AssetInstanceSQL.hasApplicablePolicies(
            accessibleResources)) {
            return sql;
        }
        String aclClause = AssetInstanceSQL.getSelectWithAccessControlSqlForCollection(AttributeSelectEnum.ID,
            accessibleResources);
        switch (category) {
            case ENTERPRISE:
            case SITE:
            case SEGMENT:
            case ASSET:
                return sql + AND_OBJECT_ID_IN + " ( " + aclClause + " ) ";
            case TAG:
            case TAG_CORRELATION:
                return sql + AND_OBJECT_ID_IN + " ( " + SELECT_TAG_ID_ACL + " ( " + aclClause + " ))";
            case ENTERPRISE_TYPE:
            case SITE_TYPE:
            case SEGMENT_TYPE:
            case ASSET_TYPE:
            case TAG_TYPE:
                return sql;
            default:
                throw new IllegalArgumentException("Invalid category " + category);
        }
    }

    public static String getDeleteAssetGroupSql() {
        return DELETE_ASSET_GROUP_SQL;
    }

    public static String getSelectGroups() {
        return SELECT_FROM_APM_ALM_ASSET_GROUP;
    }

    public static String getFilterPredicate(String tenantId, GroupPredicate predicate) {
        if (predicate == null) {
            return "";
        }

        boolean missingChildPredicates = predicate.getChildOperand() == null || !CollectionUtils.isEmpty(
            predicate.getChildPredicates());
        assert missingChildPredicates : "Predicate with child operand must have non-empty list of child predicates.";

        List<String> expressions = QueryUtils.getEqualOrLikeFilterExpressions(predicate, predicate.getAttributes(),
            Collections.emptyMap());
        if (!CollectionUtils.isEmpty(predicate.getIds())) {
            expressions.add(MessageFormat.format("id in ({0})", QueryUtils.getSqlListOfResources(predicate.getIds())));
        }

        if (!CollectionUtils.isEmpty(predicate.getCategories())) {
            Collection<String> categories = predicate.getCategories().stream().map(AssetGroupCategory::name).collect(
                Collectors.toSet());
            expressions.add("category in (" + QueryUtils.getSqlListOfResources(categories) + ")");
        }

        StringBuilder rslt = new StringBuilder();
        if (!CollectionUtils.isEmpty(expressions)) {
            rslt.append(QueryUtils.flattenExpressions(expressions, Operand.AND));
            if (predicate.getChildOperand() != null) {
                rslt.append(" ").append(predicate.getChildOperand().name().toLowerCase(Locale.getDefault()));
            }
        }

        if (!CollectionUtils.isEmpty(predicate.getChildPredicates())) {
            rslt.append(" (");
            int lastIndex = predicate.getChildPredicates().size() - 1;
            int i = 0;
            for (GroupPredicate gp : predicate.getChildPredicates()) {
                rslt.append(getFilterPredicate(tenantId, gp));
                if (gp.getPeerOperand() != null && i < lastIndex) {
                    rslt.append(" ").append(gp.getPeerOperand().name().toLowerCase(Locale.getDefault())).append(" ");
                }
                i++;
            }
            rslt.append(")");
        }

        if (rslt.length() == 0) {
            return "";
        }
        return rslt.insert(0, "(").append(")").toString();
    }

    public static String selectGroups(AssetGroupCategory category) {
        return MessageFormat.format(SELECT_FROM_APM_ALM_ASSET_GROUP_WITH_ITEM_ID,
            getGroupItemTableColumn(category).getTableName(), getGroupItemTableColumn(category).getColumnName());
    }

    public static String selectGroupsByObjectIds(AssetGroupCategory category, Collection<String> objectIds,
        boolean forUpdate) {
        if (forUpdate) {
            return MessageFormat.format(SELECT_FROM_APM_ALM_ASSET_GROUP_WITH_ITEM_IDS_FOR_UPDATE,
                getGroupItemTableColumn(category).getColumnName(), getGroupItemTableColumn(category).getTableName(),
                QueryUtils.getSqlListOfResources(objectIds));
        } else {
            return MessageFormat.format(SELECT_FROM_APM_ALM_ASSET_GROUP_WITH_ITEM_IDS,
                getGroupItemTableColumn(category).getColumnName(), getGroupItemTableColumn(category).getTableName(),
                QueryUtils.getSqlListOfResources(objectIds));
        }
    }

    public static String selectCorrelations(Collection<String> accessibleResources, Set<String> tagIds) {
        String query = MessageFormat.format(
            "select g.*, t.object_id from apm_alm.asset_group g join apm_alm.asset_group_tag_correlation t on "
                + "g.tenant_id = t.tenant_id and g.id = t.group_id where g.tenant_id = ? and t.object_id in ({0})",
            QueryUtils.getSqlListOfResources(tagIds));
        if (QueryUtils.isNotUber(accessibleResources)) {
            String aclClause = AssetInstanceSQL.getSelectWithAccessControlSqlForCollection(AttributeSelectEnum.ID,
                accessibleResources);
            query += " and t.object_id in (" + SELECT_TAG_ID_ACL + "(" + aclClause + "))";
        }
        return query;
    }

    public static String selectCorrelatedTags(Collection<String> accessibleResources, Set<String> tagIds) {
        String query = MessageFormat.format(
            "select t1.*, t2.object_id as tag_id from apm_alm.asset_group_tag_correlation t1 join "
                + "apm_alm.asset_group_tag_correlation t2 on t1.tenant_id = t2.tenant_id and t1.group_id = t2.group_id "
                + "where t1.tenant_id = ? and t2.object_id in ({0})", QueryUtils.getSqlListOfResources(tagIds));
        if (QueryUtils.isNotUber(accessibleResources)) {
            String aclClause = AssetInstanceSQL.getSelectWithAccessControlSqlForCollection(AttributeSelectEnum.ID,
                accessibleResources);
            query += " and t2.object_id in (" + SELECT_TAG_ID_ACL + "(" + aclClause + "))";
        }
        return query + " order by t2.object_id, t1.position";
    }

    private static GroupItemTableColumn getGroupItemTableColumn(AssetGroupCategory category) {
        String tablename;
        String columnName = "object_id";
        switch (category) {
            case ENTERPRISE:
            case SITE:
            case SEGMENT:
            case ASSET:
                tablename = "apm_alm.asset_group_asset_instance";
                break;
            case ENTERPRISE_TYPE:
            case SITE_TYPE:
            case SEGMENT_TYPE:
            case ASSET_TYPE:
            case TAG_TYPE:
                tablename = "apm_alm.asset_group_asset_type";
                break;
            case TAG:
                tablename = "apm_alm.asset_group_tag_instance";
                break;
            case TAG_CORRELATION:
                tablename = "apm_alm.asset_group_tag_correlation";
                break;
            default:
                throw new IllegalArgumentException("Invalid Category");
        }
        return GroupItemTableColumn.builder().tableName(tablename).columnName(columnName).build();
    }

    public static String getMaxPositionInCorrelatedTags(Collection<String> accessibleResources) {
        return getSecuredSQL(accessibleResources, AssetGroupCategory.TAG_CORRELATION,
            MAX_POSITION_TAG_CORRELATION_BY_GROUP_ID);
    }

    public static String getUpdateCorrelationItemPositions() {
        return UPDATE_CORRELATION_ITEM_POSITIONS;
    }

    public static String selectGroupItems(AssetGroupCategory category, Collection<String> accessibleResources) {
        String selectSQL = MessageFormat.format(SELECT_GROUP_ITEMS_BY_GROUPID_SQL,
            getGroupItemTableColumn(category).getTableName());
        return getSecuredSQL(accessibleResources, category, selectSQL) + (category == AssetGroupCategory.TAG_CORRELATION
            ? ORDER_BY_POSITION : "");
    }

    public static String getDeleteGroupItemByObjectIds(AssetGroupCategory category) {
        return MessageFormat.format(DELETE_GROUP_ITEMS_BY_OBJECT_ID_IN_SQL,
            getGroupItemTableColumn(category).getTableName());
    }

    public static String getRecursiveDeleteGroupAssetInstancesQuery(Collection<String> accessibleResources,
        String assetId) {
        String andAncestorsClause = SQLConstants.AND + MessageFormat.format(AssetInstanceSQL.ID_OR_ANCESTORS_CLAUSE,
            assetId);
        String assetsSql = AssetInstanceSQL.getSelectWithAccessControlSqlForCollection(AttributeSelectEnum.ID,
            andAncestorsClause, accessibleResources);
        return GroupSQL.getDeleteGroupItemByObjectIds(AssetGroupCategory.ASSET) + "(" + assetsSql + ")"
            + SQLConstants.RETURNING_FULL;
    }

    public static String getRecursiveDeleteGroupTagInstancesQuery(Collection<String> accessibleResources,
        AssetGroupCategory category, String assetId) {
        if (!(category == AssetGroupCategory.TAG || category == AssetGroupCategory.TAG_CORRELATION)) {
            throw new IllegalArgumentException("Category " + category + " must be either tag or tag correlation.");
        }
        String andAncestorsClause = SQLConstants.AND + MessageFormat.format(AssetInstanceSQL.ID_OR_ANCESTORS_CLAUSE,
            assetId);
        String assetsSql = AssetInstanceSQL.getSelectWithAccessControlSqlForCollection(AttributeSelectEnum.ID,
            andAncestorsClause, accessibleResources);
        return GroupSQL.getDeleteGroupItemByObjectIds(category) + "(" + TagInstanceSQL.getTagIdsByAssetIdInQuery() + "("
            + assetsSql + "))" + SQLConstants.RETURNING_FULL;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    private static class GroupItemTableColumn {

        private String tableName;

        private String columnName;
    }
}
