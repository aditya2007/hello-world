/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.ge.apm.alm.model.PlaceholderTagType;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;

@Entity
@Table(name = "placeholder_tag_type", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class PlaceholderTagTypeEntity extends AuditableEntity implements PlaceholderTagType {

    @Column(name = "tag_type_id")
    private String tagTypeId;

    @Column(name = "placeholder_id")
    private String placeholderId;

    @Column(name = "category")
    private String category;

    @Column(name = "expressions")
    @Convert(converter = JsonbAttributeConverter.class)
    private JsonNode expressions;

    @Builder
    private PlaceholderTagTypeEntity(String id, String placeholderId, String tagTypeId, String category, JsonNode
        expressions, String tenantId, String createdBy, String lastModifiedBy) {
        super(id, tenantId, createdBy, lastModifiedBy);
        this.tagTypeId = tagTypeId;
        this.placeholderId = placeholderId;
        this.category = category;
        this.expressions = expressions;
    }
}

