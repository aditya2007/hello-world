/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entity;

import java.util.Collections;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.PlaceholderGroupTagType;
import com.ge.apm.alm.model.PlaceholderTagType;
import com.ge.apm.alm.model.PlaceholderTemplate;
import com.ge.apm.alm.model.PlaceholderType;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;

@Entity
@Table(name = "placeholder", schema = "apm_alm")
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class PlaceholderEntity extends SourceableEntity implements Placeholder {

    @Column(name = "template_id")
    private String templateId;

    @Column(name = "parent_id")
    private String parentId;

    // this is a slot ID that is unique within a template
    @Column(name = "part_position_number")
    private String partPositionNumber;

    @Column(name = "attributes")
    @Convert(converter = JsonbAttributeConverter.class)
    private JsonNode attributes;

    @Transient
    private List<PlaceholderTypeEntity> placeholderTypes;
    @Transient
    private PlaceholderTemplateEntity placeholderTemplates;

    @Transient
    private List<PlaceholderTagTypeEntity> placeholderTagTypes;
    @Transient
    private List<PlaceholderGroupTagTypeEntity> placeholderGroupTagTypes;

    @Builder
    private PlaceholderEntity(String id, String name, String tenantId, String createdBy,
        String lastModifiedBy, String sourceKey, String description,
        String templateId, String parentId, String partPositionNumber, JsonNode attributes) {
        super(id, name, tenantId, createdBy, lastModifiedBy, sourceKey, description);
        this.templateId = templateId;
        this.parentId = parentId;
        this.partPositionNumber = partPositionNumber;
        this.attributes = attributes;
    }

    @Override
    public List<PlaceholderType> getPlaceholderTypes() {
        if (CollectionUtils.isEmpty(placeholderTypes)) {
            return Collections.emptyList();
        } else {
            return Collections.unmodifiableList(placeholderTypes);
        }
    }

    @Override
    public PlaceholderTemplate getPlaceholderTemplate() {
        return placeholderTemplates;
    }

    @Override
    public List<PlaceholderTagType> getPlaceholderTagTypes() {
        if (CollectionUtils.isEmpty(placeholderTagTypes)) {
            return Collections.emptyList();
        } else {
            return Collections.unmodifiableList(placeholderTagTypes);
        }
    }

    @Override
    public List<PlaceholderGroupTagType> getPlaceholderGroupTagTypes() {
        if (CollectionUtils.isEmpty(placeholderGroupTagTypes)) {
            return Collections.emptyList();
        } else {
            return Collections.unmodifiableList(placeholderGroupTagTypes);
        }
    }
}
