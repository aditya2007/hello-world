/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.mirror;

import java.time.OffsetDateTime;
import java.util.Collection;

import lombok.Getter;
import org.aspectj.lang.JoinPoint;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetGroupAssociation;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AssetUserPolicy;
import com.ge.apm.alm.model.Auditable;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.Edge;
import com.ge.apm.alm.model.Network;
import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;

import lombok.Getter;
import org.aspectj.lang.JoinPoint;

import java.time.OffsetDateTime;
import java.util.Collection;

/**
 * This class represents a single entity relating to a persistence event.
 * For example: saving a {@link java.util.Collection} of 9 entities to the
 * database would result in 9 {@link MirrorableParam} instances.
 */
@Getter
public class MirrorableParam {

    private final String tenantId;

    private final Collection<String> accessibleResources;
    private Type persistType;
    private String objectType;
    private String objectId;
    private OffsetDateTime lastModified;
    private Object arg;
    private Object result;
    private JoinPoint joinPoint;
    private String deletedReason;

    public MirrorableParam(String tenantId, String methodName, Mirror mirror, Object object, Object result,
        Collection<String> accessibleResources)
        throws PersistencyServiceException {
        this.tenantId = tenantId;
        this.accessibleResources = accessibleResources;
        this.arg = object;
        this.result = result;
        setObjectId(object);
        setPersistType(methodName, mirror);
        setObjectType(mirror, object, result);
        setObjectLastModified(object, result);
    }

    private void setObjectId(Object object) throws PersistencyServiceException {

        if (object == null) {
            throw new ObjectNotFoundException("Target object is null and cannot be located.");
        }

        if (object instanceof String) {
            objectId = (String) object;
        } else if (object instanceof BaseDataModel) {
            BaseDataModel model = (BaseDataModel) object;
            objectId = model.getId();
        } else {
            throw new PersistencyServiceException("Object does not support an id field");
        }
    }

    public void setDeletedReason() {
        Object[] args = joinPoint.getArgs();

        if (args[3] instanceof String) {
            deletedReason = (String) args[3];
        }
    }

    private void setPersistType(String method, Mirror mirror) throws PersistencyServiceException {

        if (mirror.type().length > 0) {
            persistType = mirror.type()[0];
        } else if (method.startsWith("create") || method.startsWith("add")) {
            persistType = Type.CREATE;
        } else if (method.startsWith("update")) {
            persistType = Type.UPDATE;
        } else if (method.startsWith("delete")) {
            persistType = Type.DELETE;
        } else {
            throw new PersistencyServiceException(
                "Could not determine persist type (by method name or by declaration)");
        }
    }

    private void setObjectType(Mirror mirror, Object object, Object result)
        throws PersistencyServiceException {

        Class clazz;

        if (mirror.clazz().length > 0) {
            clazz = mirror.clazz()[0];
        } else if (object instanceof BaseDataModel) {
            clazz = object.getClass();
        } else if (object instanceof String) {
            if (result instanceof BaseDataModel) {
                clazz = result.getClass();
                this.arg = result;
            } else {
                throw new PersistencyServiceException(
                    "You must specify the class type in the Mirror annotation");
            }
        } else {
            throw new PersistencyServiceException(
                "Unsupported class type to be mirrored");
        }

        setObjectType(clazz);
    }

    private void setObjectType(Class clazz) throws PersistencyServiceException {
        if (Tag.class.isAssignableFrom(clazz)) {
            objectType = "Tag";
        } else if (AssetGroup.class.isAssignableFrom(clazz)) {
            objectType = "AssetGroup";
        } else if (AssetType.class.isAssignableFrom(clazz)) {
            objectType = "AssetType";
        } else if (Asset.class.isAssignableFrom(clazz)) {
            objectType = "Asset";
        } else if (AssetGroupItem.class.isAssignableFrom(clazz)) {
            objectType = "AssetGroupItem";
        } else if (Template.class.isAssignableFrom(clazz)) {
            objectType = "Template";
        } else if (Placeholder.class.isAssignableFrom(clazz)) {
            objectType = "Placeholder";
        } else if (Network.class.isAssignableFrom(clazz)) {
            objectType = "Network";
        } else if (Edge.class.isAssignableFrom(clazz)) {
            objectType = "Edge";
        } else if (AssetGroupAssociation.class.isAssignableFrom(clazz)) {
            objectType = "AssetGroupAssociation";
        } else if (AssetUserPolicy.class.isAssignableFrom(clazz)) {
            objectType = "AssetUserPolicy";
        } else {
            throw new PersistencyServiceException("What kind of object are you mirroring??? " + clazz.getSimpleName());
        }
    }

    public void setRealObjectType(String objectType) {
        this.objectType = objectType;
    }

    private void setObjectLastModified(Object object, Object result) {

        if (result instanceof Auditable) {
            lastModified = ((Auditable) result).getLastModifiedDate();
        } else if (object instanceof Auditable) {
            lastModified = ((Auditable) object).getLastModifiedDate();
        }

        if (lastModified == null) {
            lastModified = OffsetDateTime.now();
        }
    }


    public boolean isCreateOrRecursiveDeleteType() {
        return getPersistType() == Type.CREATE || getPersistType() == Type.RECURSIVE_ASSET_DELETE
            || getPersistType() == Type.DELETE_NETWORK;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public void setJoinPoint(JoinPoint joinPoint) {
        this.joinPoint = joinPoint;
    }

}
