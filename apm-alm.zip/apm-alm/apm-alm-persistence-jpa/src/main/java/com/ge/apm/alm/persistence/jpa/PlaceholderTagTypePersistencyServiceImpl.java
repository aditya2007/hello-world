/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.PlaceholderTagType;
import com.ge.apm.alm.persistence.PlaceholderTagTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderTagTypeEntity;
import com.ge.apm.alm.persistence.jpa.repository.PlaceholderTagTypeRepository;
import com.ge.apm.alm.persistence.jpa.sql.PlaceholderTagTypeSQL;

import static com.ge.apm.alm.persistence.jpa.utils.Validator.assertMatchingTenantId;

@Service
@Slf4j
@Transactional
public class PlaceholderTagTypePersistencyServiceImpl implements PlaceholderTagTypePersistencyService {

    private static final int QUERY_BATCH_SIZE = 500;
    private static final String PLACEHOLDER_TAG_TYPE_HAS_REFERENCES_TO_IT_HENCE_CANNOT_BE_DELETED =
        "PlaceholderTagType has references to it. Hence cannot be deleted";

    @Autowired
    private JsonbAttributeConverter jsonbAttributeConverter;

    @Autowired
    private DataSource dataSource;
    @Autowired
    private PlaceholderTagTypeRepository placeholderTagTypeRepository;
    @Autowired
    private ConversionService conversionService;

    private EntityBeanPropertyRowMapper<PlaceholderTagTypeEntity> placeholderTagTypeBeanPropertyRowMapper;
    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initializeConvertionService() {
        placeholderTagTypeBeanPropertyRowMapper = new EntityBeanPropertyRowMapper<>(PlaceholderTagTypeEntity.class,
            conversionService);
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public PlaceholderTagType createPlaceholderTagType(String tenantId, PlaceholderTagType placeholderTagType) {
        assertMatchingTenantId(tenantId, placeholderTagType.getTenantId());
        validatePlaceholderTagType(placeholderTagType);

        PlaceholderTagTypeEntity entity = toPlaceholderTagTypeEntity(tenantId, placeholderTagType, true);
        return placeholderTagTypeRepository.saveAndFlush(entity);
    }

    @Override
    public int createPlaceholderTagTypes(String tenantId, List<PlaceholderTagType> placeholderTagTypes) {
        if (CollectionUtils.isEmpty(placeholderTagTypes)) {
            return 0;
        }

        List<PlaceholderTagTypeEntity> entities = new ArrayList<>();
        placeholderTagTypes.stream().forEach(placeholderTagType -> {
            assertMatchingTenantId(tenantId, placeholderTagType.getTenantId());
            entities.add(toPlaceholderTagTypeEntity(tenantId, placeholderTagType, true));
        });

        int[] updateCounts = jdbcTemplate
            .batchUpdate(PlaceholderTagTypeSQL.getBatchCreateSQL(), new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int index) throws SQLException {
                    PlaceholderTagTypeEntity entity = entities.get(index);
                    ps.setString(1, entity.getId());
                    ps.setString(2, tenantId);
                    ps.setString(3, entity.getPlaceholderId());
                    ps.setString(4, entity.getTagTypeId());
                    ps.setString(5, entity.getCategory());
                    ps.setString(6, entity.getCreatedBy());
                    ps.setString(7, entity.getLastModifiedBy());
                    ps.setObject(8, jsonbAttributeConverter.convertToDatabaseColumn(entity.getExpressions()));
                }

                @Override
                public int getBatchSize() {
                    return placeholderTagTypes.size();
                }
            });
        return Arrays.stream(updateCounts).sum();
    }

    @Override
    public PlaceholderTagType updatePlaceholderTagType(String tenantId, PlaceholderTagType placeholderTagType)
        throws PersistencyServiceException {
        assertMatchingTenantId(tenantId, placeholderTagType.getTenantId());
        validatePlaceholderTagType(placeholderTagType);

        PlaceholderTagTypeEntity entity = toPlaceholderTagTypeEntity(tenantId, placeholderTagType, true);
        return placeholderTagTypeRepository.saveAndFlush(entity);
    }

    @Override
    public int updatePlaceholderTagTypes(String tenantId, List<PlaceholderTagType> placeholderTagTypes)
        throws PersistencyServiceException {
        if (CollectionUtils.isEmpty(placeholderTagTypes)) {
            return 0;
        }

        int updateCounts = 0;
        for (PlaceholderTagType placeholderTagType : placeholderTagTypes) {
            updatePlaceholderTagType(tenantId, placeholderTagType);
            updateCounts++;
        }
        return updateCounts;
    }

    @Override
    public int deletePlaceholderTagTypeById(String tenantId, String id)
        throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderTagTypeSQL.getDeleteByIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, id);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                PLACEHOLDER_TAG_TYPE_HAS_REFERENCES_TO_IT_HENCE_CANNOT_BE_DELETED, ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException(id);
        }
        return rowsDeleted;
    }

    @Override
    public int deletePlaceholderTagTypeByPlaceholderIdAndTagTypeId(String tenantId, String placeholderId,
        String tagTypeId)
        throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderTagTypeSQL.getDeleteByPlaceholderIdAndTagTypeIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, placeholderId, tagTypeId);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                PLACEHOLDER_TAG_TYPE_HAS_REFERENCES_TO_IT_HENCE_CANNOT_BE_DELETED, ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException("placeholderId:" + placeholderId + ", tagTypeId:" + tagTypeId);
        }
        return rowsDeleted;
    }

    @Override
    public int deletePlaceholderTagTypeByPlaceholderId(String tenantId, String placeholderId)
        throws PersistencyServiceException {
        int rowsDeleted = 0;
        try {
            String deleteQuery = PlaceholderTagTypeSQL.getDeleteByPlaceholderIdSQL();
            rowsDeleted = jdbcTemplate.update(deleteQuery, tenantId, placeholderId);
        } catch (DataIntegrityViolationException ex) {
            throw new com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException(
                PLACEHOLDER_TAG_TYPE_HAS_REFERENCES_TO_IT_HENCE_CANNOT_BE_DELETED, ex);
        }

        if (rowsDeleted == 0) {
            throw new ObjectNotFoundException(placeholderId);
        }
        return rowsDeleted;
    }

    @Override
    public PlaceholderTagType getPlaceholderTagTypeById(String tenantId, String id) {
        try {
            String query = PlaceholderTagTypeSQL.getSelectSingleObjectById();
            return jdbcTemplate.queryForObject(query, placeholderTagTypeBeanPropertyRowMapper, tenantId, id);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("PlaceholderTagType not found with identifier: {}", id);
            return null;
        }
    }

    @Override
    public PlaceholderTagType getPlaceholderTagTypeByPlaceholderIdAndTagTypeId(String tenantId, String placeholderId,
        String tagTypeId) {
        try {
            String query = PlaceholderTagTypeSQL.getSelectSingleObjectByPlaceholderIdAndTagTypeId();
            return jdbcTemplate.queryForObject(query, placeholderTagTypeBeanPropertyRowMapper, tenantId,
                placeholderId, tagTypeId);
        } catch (EmptyResultDataAccessException emptyResultDataAccessException) { //NOSONAR
            log.debug("PlaceholderTagType not found with identifier: {}", placeholderId);
            return null;
        }
    }

    @Override
    public List<PlaceholderTagType> getPlaceholderTagTypeByPlaceholderId(String tenantId, String placeholderId) {
        String query = PlaceholderTagTypeSQL.getSelectCollectionObjectsByPlaceholderId();
        return Collections.unmodifiableList(
            jdbcTemplate.query(query, placeholderTagTypeBeanPropertyRowMapper, tenantId, placeholderId));
    }

    @Override
    public List<PlaceholderTagType> getPlaceholderTagTypeByTemplateId(String tenantId, String templateId) {
        String query = PlaceholderTagTypeSQL.getSelectCollectionObjectsByTemplateId();
        return Collections.unmodifiableList(jdbcTemplate.query(query, placeholderTagTypeBeanPropertyRowMapper,
            tenantId, templateId));
    }

    @Override
    public List<PlaceholderTagType> getPlaceholderTagTypeByPlaceholderIds(String tenantId,
        List<String> placeholderIds) {
        if (CollectionUtils.isEmpty(placeholderIds)) {
            return Collections.emptyList();
        }

        List<PlaceholderTagTypeEntity> placeholderTagTypeEntities = new ArrayList<>();
        int counter = 0;
        int size = placeholderIds.size();

        while (counter < size) {
            int endIndex = counter + QUERY_BATCH_SIZE < size ? counter + QUERY_BATCH_SIZE : size;
            List<String> batchPlaceholderIdList = placeholderIds.subList(counter, endIndex);
            String query = PlaceholderTagTypeSQL.getSelectCollectionObjectsByPlaceholderIs(batchPlaceholderIdList);

            List<PlaceholderTagTypeEntity> foundEnties = jdbcTemplate.query(query,
                placeholderTagTypeBeanPropertyRowMapper, tenantId);
            placeholderTagTypeEntities.addAll(foundEnties);

            counter = endIndex;
        }

        return Collections.unmodifiableList(placeholderTagTypeEntities);
    }

    private void validatePlaceholderTagType(PlaceholderTagType placeholderTagType) {
        StringBuilder builder = new StringBuilder();
        if (StringUtils.isEmpty(placeholderTagType.getId())) {
            builder.append("PlaceholderTagType Id is empty. ");
        }
        if (StringUtils.isEmpty(placeholderTagType.getPlaceholderId())) {
            builder.append("PlaceholderTagType placeholderId is empty. ");
        }
        if (StringUtils.isEmpty(placeholderTagType.getTagTypeId())) {
            builder.append("PlaceholderTagType typeId is empty. ");
        }

        if (!builder.toString().isEmpty()) {
            throw new IllegalArgumentException(builder.toString());
        }
    }

    private PlaceholderTagTypeEntity toPlaceholderTagTypeEntity(String tenantId, PlaceholderTagType placeholderTagType,
        boolean isAdd) {
        PlaceholderTagTypeEntity entity = new PlaceholderTagTypeEntity();
        entity.setId(placeholderTagType.getId());
        entity.setTenantId(tenantId);
        entity.setPlaceholderId(placeholderTagType.getPlaceholderId());
        entity.setTagTypeId(placeholderTagType.getTagTypeId());
        entity.setCategory(placeholderTagType.getCategory());
        if (isAdd) {
            entity.setCreatedBy(placeholderTagType.getCreatedBy());
        }
        entity.setLastModifiedBy(placeholderTagType.getLastModifiedBy());
        entity.setExpressions(placeholderTagType.getExpressions());
        return entity;
    }
}
