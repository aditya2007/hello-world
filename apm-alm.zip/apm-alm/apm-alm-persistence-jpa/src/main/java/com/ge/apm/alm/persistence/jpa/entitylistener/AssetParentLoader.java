/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.core.convert.ConversionService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.SpringApplicationContext;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetTypeEntity;
import com.ge.apm.alm.persistence.jpa.sql.AssetInstanceSQL;
import com.ge.apm.alm.persistence.jpa.utils.BaseDataModelUtil;

@Component
@Order(20) // order before AssetTypeParentLoader, AssetTagLoader and AssetTemplateInfoLoadHandler
public class AssetParentLoader
    implements PostLoadHandler<AssetInstanceEntity, AssetComponent> {

    private final EntityBeanPropertyRowMapper<AssetInstanceEntity> assetRowMapper;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private AssetTemplateInfoLoadHandler templateInfoLoadHandler;

    @Autowired
    protected AssetParentLoader(ConversionService conversionService) {
        assetRowMapper = new EntityBeanPropertyRowMapper<>(AssetInstanceEntity.class, conversionService);
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources, AssetInstanceEntity entity,
        AttributeSelectEnum selectEnum, Set<AssetComponent> components) {
        if (entity == null || components == null || ignoreParentComponent(components)) {
            return;
        }

        List<String> ancestorIds = entity.getAncestorsArray();
        if (ancestorIds == null || ancestorIds.isEmpty()) {
            return;
        }

        List<AssetInstanceEntity> assets = jdbcTemplate.query(getSql(accessibleResources, new HashSet<>(ancestorIds)),
            assetRowMapper, tenantId);
        templateInfoLoadHandler.postLoad(tenantId, accessibleResources, assets, AttributeSelectEnum.FULL, components);

        Map<String, AssetInstanceEntity> idMap = BaseDataModelUtil.toIdMap(assets, null);
        idMap = BaseDataModelUtil.toIdMap(entity, idMap);
        setParents(idMap);
        loadParentTypes(tenantId, idMap, components);
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources, List<AssetInstanceEntity> assets,
        AttributeSelectEnum selectEnum, Set<AssetComponent> components) {
        if (assets.isEmpty() || components == null || ignoreParentComponent(components)) {
            return;
        }

        Set<String> parentIds = new HashSet<>();
        assets.forEach(asset -> {
            if (asset.getAncestorsArray() != null) {
                parentIds.addAll(asset.getAncestorsArray());
            }
        });

        // excluding source assets for optimization might causing apm seeing too much on the parents.
        Map<String, AssetInstanceEntity> idMap = BaseDataModelUtil.toIdMap(assets, null);
        if (!parentIds.isEmpty()) {
            List<AssetInstanceEntity> parents = jdbcTemplate.query(getSql(accessibleResources, parentIds),
                assetRowMapper, tenantId);
            templateInfoLoadHandler.postLoad(tenantId, accessibleResources, parents, AttributeSelectEnum.FULL, components);
            BaseDataModelUtil.toIdMap(parents, idMap);
        }

        setParents(idMap);

        assets.forEach(asset -> {
            if (asset.getParentId() != null && asset.getParent() == null) {
                asset.setParent(idMap.get(asset.getParentId()));
            }
        });

        loadParentTypes(tenantId, idMap, components);
    }

    private void setParents(Map<String, AssetInstanceEntity> idMap) {
        idMap.forEach((key, asset) -> {
            String parentId = asset.getParentId();
            if (parentId != null) {
                asset.setParent(idMap.get(parentId));
            }
        });
    }

    private void loadParentTypes(String tenantId, Map<String, AssetInstanceEntity> parentMap,
        Set<AssetComponent> components) {
        if (parentMap.isEmpty() || !components.contains(AssetComponent.PARENT_TYPE_OBJECT)) {
            return;
        }

        Set<String> typeIds = new HashSet<>(parentMap.size());
        parentMap.values().forEach(asset -> typeIds.add(asset.getAssetType()));
        List<AssetType> types = SpringApplicationContext.getBeanByClass(
            AssetTypePersistencyService.class).findAllAssetTypes(tenantId, TypePredicate.builder()
            .ids(typeIds).attributeSelectEnum(AttributeSelectEnum.FULL).build());
        Map<String, AssetType> typeMap = BaseDataModelUtil.toIdMap(types, null);
        parentMap.values().forEach(asset -> asset.setType((AssetTypeEntity) typeMap.get(asset.getAssetType())));
    }

    private boolean ignoreParentComponent(Set<AssetComponent> components) {
        return !components.contains(AssetComponent.PARENT)
            && !components.contains(AssetComponent.PARENT_TAGS)
            && !components.contains(AssetComponent.PARENT_TYPE_OBJECT);
    }

    private String getSql(Collection<String> accessibleResources, Set<String> parentIds) {
        return AssetInstanceSQL.getSelectAssetsByIds(accessibleResources, parentIds, AttributeSelectEnum.FULL);
    }
}
