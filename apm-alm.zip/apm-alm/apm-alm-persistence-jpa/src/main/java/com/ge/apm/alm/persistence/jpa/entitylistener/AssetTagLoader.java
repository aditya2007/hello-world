/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.core.convert.ConversionService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.model.view.TagComponent;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceEntity;
import com.ge.apm.alm.persistence.jpa.sql.TagInstanceSQL;
import com.ge.apm.alm.persistence.jpa.utils.AssetJsonUtils;
import com.ge.apm.alm.persistence.jpa.utils.DatabaseUtil;

@Component
@Order(1000) // loading tags of transitive parents, after AssetParentLoader
@Slf4j
public class AssetTagLoader implements PostLoadHandler<AssetInstanceEntity, AssetComponent> {

    private final EntityBeanPropertyRowMapper<TagInstanceEntity> tagRowMapper;

    @Autowired
    private List<PostLoadHandler<TagInstanceEntity, TagComponent>> postLoadHandlers;

    @Autowired
    private TagPersistencyService tagPersistencyService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    protected AssetTagLoader(ConversionService conversionService) {
        tagRowMapper = new EntityBeanPropertyRowMapper<>(TagInstanceEntity.class, conversionService);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources, AssetInstanceEntity entity,
        AttributeSelectEnum selectEnum, Set<AssetComponent> components) {
        if (entity == null || components == null || !components.contains(AssetComponent.TAGS)
            || AssetJsonUtils.getCoreType(entity) == OOTBCoreTypesIdLookup.EnterpriseType) {
            return;
        }

        Map<String, AssetInstanceEntity> idMap = new LinkedHashMap<>();
        addAsset(entity, idMap, components.contains(AssetComponent.PARENT_TAGS));
        loadTags(tenantId, accessibleResources, selectEnum, idMap, Collections.singletonList(entity), components);
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources, List<AssetInstanceEntity> assets,
        AttributeSelectEnum selectEnum, Set<AssetComponent> components) {
        if (assets.isEmpty() || components == null || !components.contains(AssetComponent.TAGS)) {
            return;
        }

        Map<String, AssetInstanceEntity> idMap = new LinkedHashMap<>();
        assets.forEach(
            asset -> addAsset(asset, idMap, components.contains(AssetComponent.PARENT_TAGS)));

        loadTags(tenantId, accessibleResources, selectEnum, idMap, assets, components);
    }

    private void loadTags(String tenantId, Collection<String> accessibleResources, AttributeSelectEnum selectEnum,
        Map<String, AssetInstanceEntity> assetIdMap, List<AssetInstanceEntity> sourceAssets, Set<AssetComponent>
        components) {
        if (assetIdMap.isEmpty()) {
            return;
        }

        long startTime = System.currentTimeMillis();
        List<TagInstanceEntity> tags = assetIdMap.size() == 1
            ? queryForSingleAsset(tenantId, accessibleResources, assetIdMap.keySet().iterator().next())
            : queryForAssets(tenantId, accessibleResources, assetIdMap.keySet());
        log.info("Time {} ms to load {} tags for {} assets", System.currentTimeMillis() - startTime,
            tags.size(), assetIdMap.size());

        attachTags(tags, assetIdMap, sourceAssets, components);

        if (!tags.isEmpty()) {
            // fire to enable loading of asset groups.
            postLoadHandlers.forEach(handler -> handler.postLoad(tenantId, accessibleResources, tags, selectEnum,
                EnumSet.of(TagComponent.CORRELATED_ITEMS)));
        }
    }

    private List<TagInstanceEntity> queryForSingleAsset(String tenantId, Collection<String> accessibleResources, String assetId) {
        TagPredicate tagPredicate = TagPredicate.builder()
            .attributeSelectEnum(AttributeSelectEnum.FULL).pageSize(250).build();

        return toTagInstanceEntityList(tagPersistencyService.getTagsForAsset(tenantId, accessibleResources, assetId,
            false, tagPredicate));
    }

    private List<TagInstanceEntity> queryForAssets(String tenantId, Collection<String> accessibleResources, Set<String> assetIds) {
        TagPredicate tagPredicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.ID).build();
        tagPredicate.setParent(ParentPredicate.builder().ids(Sets.newHashSet(assetIds)).build());

        String sql = "SELECT * FROM( SELECT *, row_number() OVER (PARTITION BY asset_id) AS tags_per_asset FROM "
            + "apm_alm.tag_instance where tenant_id = ? and " + TagInstanceSQL.getFilterPredicate(tenantId,
            accessibleResources,
            tagPredicate) + ") AS dummy WHERE tags_per_asset <= 250";

        sql = sql.replace("*",
            DatabaseUtil.getAllQueryColumns("tag_instance").stream().collect(Collectors.joining(",")));

        return jdbcTemplate.query(sql, tagRowMapper, tenantId);
    }

    @SuppressWarnings("unchecked")
    private List<TagInstanceEntity> toTagInstanceEntityList(List<?> list) {
        return (List<TagInstanceEntity>) list;
    }

    private void attachTags(List<TagInstanceEntity> tags, Map<String, AssetInstanceEntity> assetIdMap,
        List<AssetInstanceEntity> sourceAssets, Set<AssetComponent> components) {

        // set null to indicate empty tags.
        Map<String, List<Tag>> assetIdToTags = new HashMap<>(assetIdMap.size());
        assetIdMap.values().forEach(asset -> {
            List<Tag> holders = new ArrayList<>();
            asset.setTags(holders);
            assetIdToTags.put(asset.getId(), holders);
        });

        tags.forEach(tag -> {
            AssetInstanceEntity asset = assetIdMap.get(tag.getAssetId());
            tag.setAsset(asset);
            List<Tag> assetTags = asset.getTags();
            if (assetTags == null) {
                assetTags = new ArrayList<>();
                asset.setTags(assetTags);
                assetIdToTags.put(asset.getId(), assetTags);
            }
            assetTags.add(tag);
        });

        // overlapping where a source asset can be a parent.
        sourceAssets.forEach(asset -> {
            if (asset.getTags() == null) {
                asset.setTags(assetIdToTags.get(asset.getId()));
            }
        });

        // attach assets to multiple references to the same asset.
        if (!components.contains(AssetComponent.PARENT_TAGS)) {
            return;
        }
        assetIdMap.values().forEach(asset -> {
            AssetInstanceEntity parent = asset.getParent();
            while (parent != null) {
                if (parent.getTags() == null) {
                    parent.setTags(assetIdToTags.get(parent.getId()));
                }
                parent = parent.getParent();
            }
        });
    }

    private void addAsset(AssetInstanceEntity asset, Map<String, AssetInstanceEntity> idMap,
        boolean includeParents) {
        if (asset != null && AssetJsonUtils.getCoreType(asset)
            != OOTBCoreTypesIdLookup.EnterpriseType && !idMap.containsKey(asset.getId())) {
            idMap.put(asset.getId(), asset);
            asset.setTags(new ArrayList<>());
            if (includeParents) {
                addAsset(asset.getParent(), idMap, includeParents);
            }
        }
    }

}
