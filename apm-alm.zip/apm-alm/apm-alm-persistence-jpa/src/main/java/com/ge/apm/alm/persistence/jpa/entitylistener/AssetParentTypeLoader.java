/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.core.convert.ConversionService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.jpa.converter.EntityBeanPropertyRowMapper;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.sql.AssetInstanceSQL;
import com.ge.apm.alm.persistence.jpa.utils.BaseDataModelUtil;

@Component
@Order(21) // order after AssetParentLoader
public class AssetParentTypeLoader
    implements PostLoadHandler<AssetInstanceEntity, AssetComponent> {

    private final EntityBeanPropertyRowMapper<AssetInstanceEntity> assetRowMapper;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    protected AssetParentTypeLoader(ConversionService conversionService) {
        assetRowMapper =
            new EntityBeanPropertyRowMapper<>(AssetInstanceEntity.class, conversionService);
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources, AssetInstanceEntity entity,
        AttributeSelectEnum selectEnum, Set<AssetComponent> components) {
        if (entity == null || entity.getParentId() == null || ignoreParentTypeComponent(
            components)) {
            return;
        }

        List<AssetInstanceEntity> parent = jdbcTemplate.query(AssetInstanceSQL.getSelectAssetsByIds(accessibleResources,
            Collections.singleton(entity.getParentId()), AttributeSelectEnum.BASIC), assetRowMapper, tenantId);
        if (!parent.isEmpty()) {
            entity.setParent(parent.get(0));
        }
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources, List<AssetInstanceEntity> assets,
        AttributeSelectEnum selectEnum, Set<AssetComponent> components) {
        if (assets.isEmpty() || ignoreParentTypeComponent(components)) {
            return;
        }

        Set<String> parentIds = new HashSet<>();
        assets.forEach(asset -> {
            if (asset.getParentId() != null) {
                parentIds.add(asset.getParentId());
            }
        });

        if (!parentIds.isEmpty()) {
            List<AssetInstanceEntity> parents = jdbcTemplate.query(AssetInstanceSQL.getSelectAssetsByIds(
                accessibleResources, parentIds, AttributeSelectEnum.BASIC), assetRowMapper, tenantId);
            setParents(assets, parents);
        }
    }

    private void setParents(List<AssetInstanceEntity> assets, List<AssetInstanceEntity> parents) {
        Map<String, AssetInstanceEntity> idMap = BaseDataModelUtil.toIdMap(parents, null);
        assets.forEach(asset -> {
            String parentId = asset.getParentId();
            if (parentId != null) {
                AssetInstanceEntity parent = idMap.get(parentId);
                if (parent != null) {
                    asset.setParent(parent);
                }
            }
        });
    }

    private boolean ignoreParentTypeComponent(Set<AssetComponent> components) {
        return components == null
            || components.contains(AssetComponent.PARENT) // this already gives parent type info.
            || components.contains(AssetComponent.PARENT_TYPE_OBJECT) // this already gives parent type info.

            || !components.contains(AssetComponent.PARENT_TYPE);
    }
}
