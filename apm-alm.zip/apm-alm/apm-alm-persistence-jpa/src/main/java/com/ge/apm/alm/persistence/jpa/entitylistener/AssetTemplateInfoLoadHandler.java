/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.TemplateInfoEntity;

@Component
@Order(1001) // loading template info of transitive parents, after AssetParentLoader
public class AssetTemplateInfoLoadHandler
    implements PostLoadHandler<AssetInstanceEntity, AssetComponent> {

    private static final String PARAM_TENANT_ID = "tenantId";

    private static final String PARAM_ASSET_ID = "assetId";

    private static final String PARAM_ASSET_IDS = "assetIds";

    private static final String QUERY =
        // asset with a sub-template
        "select asset_placeholder.asset_id as assetId"
            + ", asset_placeholder.conformance_flag as conformanceFlag"
            + ", placeholder2.template_id as templateId"
            + ", placeholder2.part_position_number as ppn"
            + ", placeholder1.template_id as embeddedTemplateId"
            + ", placeholder1.part_position_number as embeddedPpn"
            + " from apm_alm.asset_placeholder"
            + " join apm_alm.placeholder placeholder1"
            + " on (asset_placeholder.placeholder_id = placeholder1.id"
            + " and asset_placeholder.tenant_id = :" + PARAM_TENANT_ID
            + " and placeholder1.tenant_id = :" + PARAM_TENANT_ID

            + " and asset_placeholder.asset_id %s)"

            + " join apm_alm.placeholder_template"
            + " on placeholder1.id = placeholder_template.placeholder_id"
            + " and placeholder1.tenant_id = placeholder_template.tenant_id" // for use of index
            + " join apm_alm.placeholder placeholder2"
            + " on (placeholder_template.template_id = placeholder2.template_id and "
            + "placeholder2.parent_id is null)"

            // asset without a sub-template
            + " union all"
            + " select asset_placeholder.asset_id as assetId"
            + ", asset_placeholder.conformance_flag as conformanceFlag"
            + ", placeholder1.template_id as templateId"
            + ", placeholder1.part_position_number as ppn"
            + ", null as embeddedTemplateId"
            + ", null as embeddedPpn"
            + " from apm_alm.asset_placeholder"
            + " join apm_alm.placeholder placeholder1"
            + " on (asset_placeholder.placeholder_id = placeholder1.id"
            + " and asset_placeholder.tenant_id = :" + PARAM_TENANT_ID
            + " and placeholder1.tenant_id = :" + PARAM_TENANT_ID

            + " and asset_placeholder.asset_id %s)"

            + " and placeholder1.id not in (select placeholder_id from apm_alm"
            + ".placeholder_template)";

    private static final String QUERY_ID = String.format(QUERY,
        "= :" + PARAM_ASSET_ID, "= :" + PARAM_ASSET_ID);

    private static final String QUERY_IDS = String.format(QUERY,
        "in (:" + PARAM_ASSET_IDS + ")", "in (:" + PARAM_ASSET_IDS + ")");
    private final BeanPropertyRowMapper<TemplateInfoEntity> rowMapper =
        new BeanPropertyRowMapper<>(TemplateInfoEntity.class);
    @Autowired
    private NamedParameterJdbcTemplate jdbcTemplate;

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources,
        AssetInstanceEntity asset, AttributeSelectEnum selectEnum,
        Set<AssetComponent> components) {
        if (asset == null || ignoreTemplateInfo(selectEnum) || !isOfAssetType(asset)) {
            return; // otherwise load them anyway for backward compatibility
        }

        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue(PARAM_TENANT_ID, tenantId);
        parameters.addValue(PARAM_ASSET_ID, asset.getId());

        TemplateInfoEntity info = DataAccessUtils.singleResult(
            jdbcTemplate.query(QUERY_ID, parameters, rowMapper));
        asset.setTemplateInfo(info);
    }

    @Override
    public void postLoad(String tenantId, Collection<String> accessibleResources,
        List<AssetInstanceEntity> assets,
        AttributeSelectEnum selectEnum,
        Set<AssetComponent> components) {
        if (CollectionUtils.isEmpty(assets) || ignoreComponentForList(components) || ignoreTemplateInfo(selectEnum)) {
            return; // otherwise load them anyway for backward compatibility
        }

        Map<String, AssetInstanceEntity> idToAsset = new LinkedHashMap<>(assets.size());
        assets.forEach(asset -> {
            if (isOfAssetType(asset)) {
                idToAsset.put(asset.getId(), asset);
            }
        });

        if (!idToAsset.isEmpty()) {
            MapSqlParameterSource parameters = new MapSqlParameterSource();
            parameters.addValue(PARAM_TENANT_ID, tenantId);
            parameters.addValue(PARAM_ASSET_IDS, idToAsset.keySet());

            jdbcTemplate.query(QUERY_IDS, parameters, rowMapper)
                .forEach(info -> idToAsset.get(info.getAssetId()).setTemplateInfo(info));
        }
    }

    private boolean ignoreTemplateInfo(AttributeSelectEnum selectEnum) {
        return selectEnum != AttributeSelectEnum.FULL;
    }

    private boolean ignoreComponentForList(Set<AssetComponent> components) {
        return components == null || !components.contains(AssetComponent.TEMPLATE_INFO);
    }

    private boolean isOfAssetType(AssetInstanceEntity asset) {
        List<String> superTypes = asset.getSuperTypesArray();
        return !CollectionUtils.isEmpty(superTypes) && SeedOOTBData.ROOT_ASSET_TYPE_ID.equals(superTypes.get(0));
    }
}
