/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.ge.apm.alm.model.Network;
import com.ge.apm.alm.persistence.jpa.converter.JsonbAttributeConverter;
import com.ge.apm.alm.persistence.jpa.converter.OffsetDateTimeAttributeConverter;

/**
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 July 15, 2017
 * @since 1.0
 */
class NetworkBatchCreatePreparedStatementSetter extends BaseBatchPreparedStatementSetter<Network> {

    NetworkBatchCreatePreparedStatementSetter(String tenantId, List<Network> networks,
        JsonbAttributeConverter jsonbAttributeConverter,
        OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter) {
        super(tenantId, networks, jsonbAttributeConverter, offsetDateTimeAttributeConverter);
    }

    @Override
    public void setValues(PreparedStatement ps, int i) throws SQLException {
        Network instance = instances.get(i);
        ps.setString(1, instance.getId());
        ps.setString(2, tenantId);
        if (StringUtils.isEmpty(instance.getAssetId())) {
            ps.setString(3, null);
            ps.setString(4, instance.getSourceKey());
            ps.setString(5, instance.getName());
            ps.setString(6, instance.getDescription());
            ps.setObject(7, jsonbAttributeConverter.convertToDatabaseColumn(instance.getAttributes()));
        } else {
            ps.setString(3, instance.getAssetId());
            ps.setString(4, null);
            ps.setString(5, null);
            ps.setString(6, null);
            ps.setObject(7, null);
        }
        ps.setString(8, instance.getCreatedBy());
        ps.setTimestamp(9, now);
        ps.setString(10, instance.getLastModifiedBy());
        ps.setTimestamp(11, now);
        //setting computed values back to bean for client's convenience
        setCreatedDate(instance);
        setLastModifiedDate(instance);
    }
}