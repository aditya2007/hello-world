/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.apm.alm.model.Context;
import com.ge.apm.alm.model.ReservedAttributeContextConfig;
import com.ge.apm.alm.model.query.ConfigContextQuery;
import com.ge.apm.alm.persistence.ReservedAttributeContextConfigService;
import com.ge.apm.alm.persistence.jpa.entity.ContextEntity;
import com.ge.apm.alm.persistence.jpa.entity.ReservedAttributeContextConfigEntity;
import com.ge.apm.alm.persistence.jpa.repository.IReservedAttributeContextConfigRepository;

@Service
public class ReservedAttributeContextConfigServiceImpl implements ReservedAttributeContextConfigService {

    @Autowired
    IReservedAttributeContextConfigRepository configRepository;

    @Override
    public List<ReservedAttributeContextConfig> findAllByTenantId(String tenantId) {
        return Collections.unmodifiableList(configRepository.findAllByTenantId(tenantId));
    }

    @Override
    public List<ReservedAttributeContextConfig> findAllByContextAndTenantId(String contextName, String tenantId) {
        return Collections.unmodifiableList(
            configRepository.findAllByContextAndTenantId(contextName, tenantId));
    }

    @Override
    public ReservedAttributeContextConfig findByContextAndTenantIdAndCode(String contextName, String tenantId,
        String code) {
        return configRepository.findByContextAndTenantIdAndCode(contextName, tenantId, code);
    }

    @Override
    public ReservedAttributeContextConfig findByContextAndTenantIdAndIsDefaultTrue(String contextName,
        String tenantId) {
        return configRepository.findByContextAndTenantIdAndIsDefaultTrue(contextName, tenantId);
    }

    @Override
    public void delete(ReservedAttributeContextConfig contextConfig) {
        configRepository.delete((ReservedAttributeContextConfigEntity) contextConfig);
    }

    @Override
    public ReservedAttributeContextConfig save(ReservedAttributeContextConfig contextConfig) {
        return configRepository.saveAndFlush((ReservedAttributeContextConfigEntity) contextConfig);
    }

    @Override
    public List<ReservedAttributeContextConfig> findAllByContextAndCodeAndTenantId(String contextName,
        String tenantId, String code) {
        return Collections.unmodifiableList(
            configRepository.findAllByContextAndCodeAndTenantId(contextName, tenantId, code));
    }

    @Override
    public List<ReservedAttributeContextConfig> findAllByQuerySpecs(String tenantId,
        ConfigContextQuery configContextQuery) {
        return Collections.unmodifiableList(configRepository.findAllByQuerySpecs(tenantId, configContextQuery));
    }
}
