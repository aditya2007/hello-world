ALTER TABLE asset_type
  ADD COLUMN super_types_array TEXT[];
CREATE INDEX asset_type_super_types_array_idx ON apm_alm.asset_type
  USING gin (super_types_array);

ALTER TABLE asset_instance
  ADD COLUMN super_types_array TEXT[];
ALTER TABLE asset_instance
  ADD COLUMN ancestors_array TEXT[];
CREATE INDEX asset_instance_super_types_array_idx ON apm_alm.asset_instance
  USING gin (super_types_array);
CREATE INDEX asset_instance_ancestors_array_idx ON apm_alm.asset_instance
  USING gin (ancestors_array);

ALTER TABLE tag_instance
  ADD COLUMN super_types_array TEXT[];
CREATE INDEX tag_instance_super_types_array_idx ON apm_alm.tag_instance
  USING gin (super_types_array);