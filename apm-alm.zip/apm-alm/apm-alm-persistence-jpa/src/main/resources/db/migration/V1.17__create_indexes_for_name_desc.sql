DO $$
BEGIN
SET SEARCH_PATH = apm_alm, pg_catalog;
IF to_regclass('apm_alm.asset_type_lower_name_idx') IS NULL THEN
CREATE INDEX asset_type_lower_name_idx ON apm_alm.asset_type (lower(name));
END IF;
IF to_regclass('apm_alm.asset_type_lower_desc_idx') IS NULL THEN
CREATE INDEX asset_type_lower_desc_idx ON apm_alm.asset_type (lower(description));
END IF;
IF to_regclass('apm_alm.asset_instance_lower_name_idx') IS NULL THEN
CREATE INDEX asset_instance_lower_name_idx ON apm_alm.asset_instance (lower(name));
END IF;
IF to_regclass('apm_alm.asset_instance_lower_desc_idx') IS NULL THEN
CREATE INDEX asset_instance_lower_desc_idx ON apm_alm.asset_instance (lower(description));
END IF;
IF to_regclass('apm_alm.tag_instance_lower_name_idx') IS NULL THEN
CREATE INDEX tag_instance_lower_name_idx ON apm_alm.tag_instance (lower(name));
END IF;
IF to_regclass('apm_alm.tag_instance_lower_desc_idx') IS NULL THEN
CREATE INDEX tag_instance_lower_desc_idx ON apm_alm.tag_instance (lower(description));
END IF;
IF to_regclass('apm_alm.asset_group_lower_name_idx') IS NULL THEN
CREATE INDEX asset_group_lower_name_idx ON apm_alm.asset_group (lower(name));
END IF;
IF to_regclass('apm_alm.asset_group_lower_desc_idx') IS NULL THEN
CREATE INDEX asset_group_lower_desc_idx ON apm_alm.asset_group (lower(description));
END IF;
IF to_regclass('apm_alm.network_node_lower_name_idx') IS NULL THEN
CREATE INDEX network_node_lower_name_idx ON apm_alm.network_node (lower(name));
END IF;
IF to_regclass('apm_alm.network_node_lower_desc_idx') IS NULL THEN
CREATE INDEX network_node_lower_desc_idx ON apm_alm.network_node (lower(description));
END IF;
IF to_regclass('apm_alm.edge_lower_name_idx') IS NULL THEN
CREATE INDEX edge_lower_name_idx ON apm_alm.edge (lower(name));
END IF;
IF to_regclass('apm_alm.edge_lower_desc_idx') IS NULL THEN
CREATE INDEX edge_lower_desc_idx ON apm_alm.edge (lower(description));
END IF;
IF to_regclass('apm_alm.placeholder_lower_name_idx') IS NULL THEN
CREATE INDEX placeholder_lower_name_idx ON apm_alm.placeholder (lower(name));
END IF;
IF to_regclass('apm_alm.placeholder_lower_desc_idx') IS NULL THEN
CREATE INDEX placeholder_lower_desc_idx ON apm_alm.placeholder (lower(description));
END IF;
IF to_regclass('apm_alm.template_lower_name_idx') IS NULL THEN
CREATE INDEX template_lower_name_idx ON apm_alm.template (lower(name));
END IF;
IF to_regclass('apm_alm.template_lower_desc_idx') IS NULL THEN
CREATE INDEX template_lower_desc_idx ON apm_alm.template (lower(description));
END IF;
END $$;