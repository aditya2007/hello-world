CREATE INDEX asset_instance_tnnt_asset_type
  ON asset_instance (tenant_id, asset_type);
CREATE INDEX tag_instance_tnnt_tag_type
  ON tag_instance (tenant_id, tag_type);

