ALTER TABLE apm_alm.asset_instance
  ALTER COLUMN super_types DROP NOT NULL;
ALTER TABLE apm_alm.asset_instance
  ALTER COLUMN super_types_array SET NOT NULL;
ALTER TABLE apm_alm.tag_instance
  ALTER COLUMN super_types DROP NOT NULL;
ALTER TABLE apm_alm.tag_instance
  ALTER COLUMN super_types_array SET NOT NULL;
CREATE OR REPLACE FUNCTION apm_alm.map_asset_type(super_types_array TEXT [])
  RETURNS INT
AS $BODY$
DECLARE
  VALUE INT;
BEGIN
  VALUE := 999;
  IF super_types_array @> ARRAY ['4012dc78-2339-37f2-bbba-92a980b9ee65']
  THEN
    VALUE := 4;
  ELSEIF super_types_array @> ARRAY ['8c8b780b-14e0-382a-aeea-16b18c312dfa']
    THEN
      VALUE := 3;
  ELSEIF super_types_array @> ARRAY ['c9fb733c-4c2e-3b43-9e01-47c9256af586']
    THEN
      VALUE := 2;
  ELSEIF super_types_array @> ARRAY ['edf150de-d869-3741-8141-6f4c7f80254e']
    THEN
      VALUE := 1;
  END IF;
  RETURN VALUE;
END;
$BODY$ LANGUAGE PLPGSQL IMMUTABLE STRICT;