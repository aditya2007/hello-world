CREATE EXTENSION IF NOT EXISTS pg_trgm with schema pg_catalog;
CREATE TABLE asset_type (
  id                 UUID UNIQUE PRIMARY KEY,
  source_key         TEXT                                   NOT NULL,
  name               TEXT,
  label              TEXT,
  description        TEXT,
  tenant_id          UUID                                   NOT NULL,
  super_type_id      UUID                                   NULL REFERENCES asset_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  json_schema        JSONB,
  attribute_schema   JSONB,
  type_semantics     JSONB,
  super_types        JSONB,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT asset_type_tnnt_id UNIQUE (tenant_id, id)
);
CREATE INDEX asset_type_jsn_schema_idx
  ON asset_type USING GIN (json_schema jsonb_path_ops);
CREATE INDEX asset_type_lower_attr_schema_idx
  ON asset_type USING GIN ((lower(attribute_schema :: TEXT) :: JSONB) jsonb_path_ops);
CREATE INDEX asset_type_super_types_idx
  ON asset_type USING GIN ((super_types -> 'ids'));
CREATE INDEX asset_type_name_idx
  ON asset_type USING GIN (name gin_trgm_ops);
CREATE INDEX asset_type_sourcekey_idx
  ON asset_type USING GIN (source_key gin_trgm_ops);
CREATE INDEX asset_type_description_idx
  ON asset_type USING GIN (description gin_trgm_ops);
CREATE INDEX asset_type_lower_sourceKey_idx
  ON asset_type (lower(source_key));

CREATE TABLE template (
  id                        UUID UNIQUE PRIMARY KEY,
  source_key                TEXT                                   NOT NULL,
  name                      TEXT,
  label                     TEXT,
  description               TEXT,
  tenant_id                 UUID                                   NOT NULL,
  state                     TEXT,
  status                    TEXT,
  default_value_expressions JSONB,
  attributes                JSONB,
  revision                  TEXT,
  created_by                TEXT,
  created_date              TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by          TEXT,
  last_modified_date        TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT template_tnnt_sk UNIQUE (tenant_id, source_key)
);

CREATE INDEX template_name_idx
  ON template USING GIN (name gin_trgm_ops);
CREATE INDEX template_sourceKey_idx
  ON template USING GIN (source_key gin_trgm_ops);
CREATE INDEX template_description_idx
  ON template USING GIN (description gin_trgm_ops);
CREATE INDEX template_lower_sourceKey_idx
  ON template (lower(source_key));
CREATE INDEX template_lower_attr_idx
  ON template USING GIN ((lower(attributes :: TEXT) :: JSONB) jsonb_path_ops);

CREATE TABLE asset_instance (
  id                 UUID PRIMARY KEY,
  source_key         TEXT                                   NOT NULL,
  name               TEXT,
  label              TEXT,
  description        TEXT,
  tenant_id          UUID                                   NOT NULL,
  asset_type         UUID                                   NOT NULL REFERENCES asset_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  parent_id          UUID                                   NULL REFERENCES asset_instance (id) ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  attributes         JSONB,
  ancestors          JSONB,
  super_types        JSONB                                  NOT NULL,
  geolocation        JSONB,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  FOREIGN KEY (tenant_id, asset_type) REFERENCES asset_type (tenant_id, id) DEFERRABLE INITIALLY IMMEDIATE
);
CREATE INDEX asset_instance_lower_attr_idx
  ON asset_instance USING GIN ((lower(attributes :: TEXT) :: JSONB) jsonb_path_ops);
CREATE INDEX asset_instance_ance_idx
  ON asset_instance USING GIN ((ancestors -> 'ids'));
CREATE INDEX asset_instance_types_idx
  ON asset_instance USING GIN ((super_types -> 'ids'));
CREATE INDEX asset_instance_name_idx
  ON asset_instance USING GIN (name gin_trgm_ops);
CREATE INDEX asset_instance_sourceKey_idx
  ON asset_instance USING GIN (source_key gin_trgm_ops);
CREATE INDEX asset_instance_description_idx
  ON asset_instance USING GIN (description gin_trgm_ops);
CREATE INDEX asset_instance_lower_sourceKey_idx
  ON asset_instance (lower(source_key));
CREATE INDEX asset_instance_tnnt_parent_idx
  ON asset_instance (tenant_id, parent_id);

CREATE TABLE tag_instance (
  id                 UUID PRIMARY KEY,
  source_key         TEXT                                   NOT NULL,
  name               TEXT,
  label              TEXT,
  description        TEXT,
  tenant_id          UUID                                   NOT NULL,
  --In Q3 we are going to put CASCADE DELETE BACK
  asset_id           UUID                                   NOT NULL REFERENCES asset_instance (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  tag_type           UUID                                   NOT NULL REFERENCES asset_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  tag_category       TEXT,
  aliases            JSONB,
  unit               TEXT,
  unit_group         TEXT,
  attributes         JSONB,
  super_types        JSONB                                  NOT NULL,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT tag_instance_uk1 UNIQUE (tenant_id, source_key),
  FOREIGN KEY (tenant_id, tag_type) REFERENCES asset_type (tenant_id, id) DEFERRABLE INITIALLY IMMEDIATE
);
CREATE INDEX tag_instance_lower_attr_idx
  ON tag_instance USING GIN ((lower(attributes :: TEXT) :: JSONB) jsonb_path_ops);
CREATE INDEX tag_instance_types_idx
  ON tag_instance USING GIN ((super_types -> 'ids'));
CREATE INDEX tag_instance_name_idx
  ON tag_instance USING GIN (name gin_trgm_ops);
CREATE INDEX tag_instance_sourceKey_idx
  ON tag_instance USING GIN (source_key gin_trgm_ops);
CREATE INDEX tag_instance_description_idx
  ON tag_instance USING GIN (description gin_trgm_ops);
CREATE INDEX tag_instance_lower_sourceKey_idx
  ON tag_instance (lower(source_key));
CREATE INDEX tag_instance_tnnt_asset_idx
  ON tag_instance (tenant_id, asset_id);


CREATE TABLE asset_group (
  id                 UUID UNIQUE PRIMARY KEY,
  source_key         TEXT,
  name               TEXT                                   NOT NULL,
  label              TEXT,
  description        TEXT,
  category           TEXT                                   NOT NULL,
  attributes         JSONB,
  tenant_id          UUID                                   NOT NULL,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT asset_group_tnnt_sk UNIQUE (tenant_id, source_key)
);

CREATE INDEX asset_group_lower_attr_idx
  ON asset_group USING GIN ((lower(attributes :: TEXT) :: JSONB) jsonb_path_ops);
CREATE INDEX asset_group_name_idx
  ON asset_group USING GIN (name gin_trgm_ops);
CREATE INDEX asset_group_sourceKey_idx
  ON asset_group USING GIN (source_key gin_trgm_ops);
CREATE INDEX asset_group_lower_sourceKey_idx
  ON asset_group (lower(source_key));
CREATE INDEX asset_group_category_idx
  ON asset_group (category);
CREATE INDEX asset_group_description_idx
  ON asset_group USING GIN (description gin_trgm_ops);


CREATE TABLE asset_group_asset_instance (
  id        UUID UNIQUE PRIMARY KEY,
  group_id  UUID NOT NULL REFERENCES asset_group (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  object_id UUID NOT NULL REFERENCES asset_instance (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  tenant_id UUID NOT NULL,
  CONSTRAINT asset_group_asset_instance_uk UNIQUE (tenant_id, group_id, object_id)
);
CREATE INDEX asset_group_asset_instance_idx
  ON asset_group_asset_instance (tenant_id, group_id);

CREATE TABLE asset_group_tag_instance (
  id        UUID UNIQUE PRIMARY KEY,
  group_id  UUID     NOT NULL REFERENCES asset_group (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  object_id UUID     NOT NULL REFERENCES tag_instance (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  tenant_id UUID     NOT NULL,
  position  SMALLINT NOT NULL DEFAULT 0,
  CONSTRAINT asset_group_tag_instance_uk UNIQUE (tenant_id, group_id, object_id)
);
CREATE INDEX asset_group_tag_instance_idx
  ON asset_group_tag_instance (tenant_id, group_id);

CREATE TABLE asset_group_tag_correlation (
  id        UUID UNIQUE PRIMARY KEY,
  group_id  UUID     NOT NULL REFERENCES asset_group (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  object_id UUID     NOT NULL REFERENCES tag_instance (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  tenant_id UUID     NOT NULL,
  position  SMALLINT NOT NULL,
  CONSTRAINT asset_group_tag_correl_tnnt_obj_uk UNIQUE (tenant_id, object_id),
  CONSTRAINT asset_group_tag_correl_tnnt_grp_pos_uk UNIQUE (tenant_id, group_id, position)
);

CREATE INDEX asset_group_tag_correlation_idx
  ON asset_group_tag_correlation (tenant_id, group_id);

CREATE TABLE asset_group_asset_type (
  id        UUID UNIQUE PRIMARY KEY,
  group_id  UUID NOT NULL REFERENCES asset_group (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  object_id UUID NOT NULL REFERENCES asset_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  tenant_id UUID NOT NULL,
  CONSTRAINT asset_group_asset_type_uk UNIQUE (tenant_id, group_id, object_id)
);
CREATE INDEX asset_group_asset_type_idx
  ON asset_group_asset_type (tenant_id, group_id);

CREATE TABLE placeholder (
  id                   UUID UNIQUE PRIMARY KEY,
  source_key           TEXT                                   NOT NULL,
  name                 TEXT,
  label                TEXT,
  description          TEXT,
  tenant_id            UUID                                   NOT NULL,
  template_id          UUID                                   NOT NULL REFERENCES template (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  parent_id            UUID                                   NULL REFERENCES placeholder (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  part_position_number TEXT,
  attributes           JSONB,
  created_by           TEXT,
  created_date         TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by     TEXT,
  last_modified_date   TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT placehoder_tnnt_sk UNIQUE (tenant_id, source_key),
  CONSTRAINT placeholder_tnnt_ppn_templateid UNIQUE (tenant_id, part_position_number,
                                                     template_id)
);

CREATE INDEX placeholder_lower_attr_idx
  ON placeholder USING GIN ((lower(attributes :: TEXT) :: JSONB) jsonb_path_ops);
CREATE INDEX placeholder_tnnt_templateid_idx
  ON placeholder (tenant_id, template_id);


CREATE TABLE placeholder_type (
  id                 UUID UNIQUE PRIMARY KEY,
  placeholder_id     UUID                                   NOT NULL REFERENCES placeholder (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  type_id            UUID                                   NOT NULL REFERENCES asset_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  tenant_id          UUID                                   NOT NULL,
  primary_flag       BOOLEAN,
  status             TEXT                                   NOT NULL,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT placehoder_type UNIQUE (tenant_id, placeholder_id, type_id)
);

CREATE TABLE placeholder_template (
  id                 UUID UNIQUE PRIMARY KEY,
  placeholder_id     UUID                                   NOT NULL REFERENCES placeholder (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  template_id        UUID                                   NOT NULL REFERENCES template (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  tenant_id          UUID                                   NOT NULL,
  status             TEXT                                   NOT NULL,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT placehoder_template UNIQUE (tenant_id, placeholder_id, template_id)
);

CREATE TABLE placeholder_tag_type (
  id                 UUID UNIQUE PRIMARY KEY,
  placeholder_id     UUID                                   NOT NULL REFERENCES placeholder (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  tag_type_id        UUID                                   NOT NULL REFERENCES asset_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  tenant_id          UUID                                   NOT NULL,
  category           TEXT,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT placehoder_tag_type UNIQUE (tenant_id, placeholder_id, tag_type_id)
);

CREATE TABLE placeholder_group_tag_type (
  id                 UUID UNIQUE PRIMARY KEY,
  placeholder_id     UUID                                   NOT NULL REFERENCES placeholder (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  group_id           UUID                                   NOT NULL REFERENCES asset_group (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  tenant_id          UUID                                   NOT NULL,
  category           TEXT,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT placeholder_group_tag_type_tnnt_ph_group UNIQUE (tenant_id, placeholder_id, group_id)
);

CREATE TABLE asset_placeholder (
  id                 UUID UNIQUE PRIMARY KEY,
  tenant_id          UUID                                   NOT NULL,
  asset_id           UUID UNIQUE                            NOT NULL REFERENCES asset_instance (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  placeholder_id     UUID                                   NOT NULL REFERENCES placeholder (id) ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY IMMEDIATE,
  conformance_flag   BOOLEAN,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT asset_placehoder_tnnt_assetid UNIQUE (tenant_id, asset_id)
);

-- TOOD
--CREATE TABLE placeholder_tag_type_group (
--);

/*
   all notes for APM ALM could be saved at this table, then we could not set fk here
   if an entity is deleted from db, then application needs to delete all notes belong to entity_id
*/
CREATE TABLE notes (
  id                 UUID UNIQUE PRIMARY KEY,
  name               TEXT                                   NOT NULL,
  content            TEXT,
  tenant_id          UUID                                   NOT NULL,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);
CREATE INDEX notes_tnnt_name_idx
  ON notes (tenant_id, name);
CREATE INDEX notes_tnnt_content_idx
  ON notes (tenant_id, content);


CREATE TABLE template_notes (
  id          UUID UNIQUE PRIMARY KEY,
  template_id UUID NOT NULL REFERENCES template (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  notes_id    UUID NOT NULL REFERENCES notes (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  tenant_id   UUID NOT NULL
);
CREATE INDEX template_notes_idx
  ON template_notes (tenant_id, template_id, notes_id);

CREATE TABLE asset_event (
  id                        UUID UNIQUE PRIMARY KEY,
  tenant_id                 UUID                                   NOT NULL,
  created_by                TEXT,
  created_date              TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by          TEXT,
  last_modified_date        TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  tenant_object_id          TEXT,
  event_type                TEXT,
  object_id                 TEXT,
  object_type               TEXT,
  object_last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  job_start_date            TIMESTAMP WITH TIME ZONE
);

CREATE INDEX asset_event_tenant_object_id_idx
  ON asset_event (tenant_object_id);


/*
 * Create a trigger to disable tag update from one asset to another.
 */
CREATE OR REPLACE FUNCTION apm_alm.disable_tag_asset_update()
  RETURNS TRIGGER AS
$BODY$
BEGIN
  IF OLD.asset_id IS DISTINCT FROM NEW.asset_id
  THEN
    RAISE EXCEPTION 'Asset update on tag is not allowed';
  END IF;
  RETURN NEW;
END;
$BODY$
LANGUAGE plpgsql;

CREATE TRIGGER disable_tag_asset_update
BEFORE UPDATE ON apm_alm.tag_instance
FOR EACH ROW EXECUTE PROCEDURE disable_tag_asset_update();

/*
 * Create a trigger to enforce not-null source_key for non-correlated groups.
 */
CREATE OR REPLACE FUNCTION apm_alm.not_null_sourcekey_for_noncorrelated_groups()
  RETURNS TRIGGER AS
$BODY$
BEGIN
  IF NEW.category <> 'TAG_CORRELATION' AND NEW.source_key IS NULL
  THEN
    RAISE EXCEPTION 'Source key cannot be null for (%)', NEW.category;
  END IF;
  RETURN NEW;
END;
$BODY$
LANGUAGE plpgsql;

CREATE TRIGGER not_null_sourcekey_for_noncorrelated_groups
BEFORE INSERT OR UPDATE ON apm_alm.asset_group
FOR EACH ROW EXECUTE PROCEDURE not_null_sourcekey_for_noncorrelated_groups();


CREATE OR REPLACE FUNCTION apm_alm.map_asset_type(super_types JSONB)
  RETURNS INT
AS $BODY$
DECLARE
  VALUE INT;
BEGIN
  VALUE := 999;
  IF super_types -> 'ids' ? '4012dc78-2339-37f2-bbba-92a980b9ee65'
  THEN
    VALUE := 4;
  ELSEIF super_types -> 'ids' ? '8c8b780b-14e0-382a-aeea-16b18c312dfa'
    THEN
      VALUE := 3;
  ELSEIF super_types -> 'ids' ? 'c9fb733c-4c2e-3b43-9e01-47c9256af586'
    THEN
      VALUE := 2;
  ELSEIF super_types -> 'ids' ? 'edf150de-d869-3741-8141-6f4c7f80254e'
    THEN
      VALUE := 1;
  END IF;
  RETURN VALUE;
END;
$BODY$ LANGUAGE PLPGSQL IMMUTABLE STRICT;

/*
 ** populating OOTB types **
 */

INSERT INTO asset_type VALUES
  ('edf150de-d869-3741-8141-6f4c7f80254e', 'EnterpriseType', 'EnterpriseType', 'EnterpriseType', 'EnterpriseType',
                                           '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', NULL, '{}', '{}', '{}',
                                           cast('{"ids":[]}' AS JSONB),
   'system', now(), 'system', now());
INSERT INTO asset_type VALUES ('c9fb733c-4c2e-3b43-9e01-47c9256af586', 'SiteType', 'SiteType', 'SiteType', 'SiteType',
                                                                       '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', NULL,
                                                                       '{}', '{}', '{}', cast('{"ids":[]}' AS JSONB),
                               'system', now(),
                               'system', now());
INSERT INTO asset_type VALUES
  ('8c8b780b-14e0-382a-aeea-16b18c312dfa', 'SegmentType', 'SegmentType', 'SegmentType', 'SegmentType',
                                           '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', NULL, '{}', '{}', '{}',
                                           cast('{"ids":[]}' AS JSONB),
   'system', now(), 'system', now());
INSERT INTO asset_type VALUES
  ('4012dc78-2339-37f2-bbba-92a980b9ee65', 'AssetType', 'AssetType', 'AssetType', 'AssetType',
                                           '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', NULL, cast(
                                               '{"title": "reserved_attributes","type": "object","properties": {"model": {"type": "string"},"make": {"type": "string"},"status": {"description": "Make","type": "integer","minimum": 0}},"required": ["model"]}'
                                               AS JSONB),
                                           '{}', '{}', cast('{"ids":[]}' AS JSONB), 'system', now(), 'system', now());
INSERT INTO asset_type VALUES ('203d4660-702c-3cc9-8399-5663b9378408', 'TagType', 'TagType', 'TagType', 'TagType',
                                                                       '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', NULL,
                                                                       '{}', '{}', '{}', cast('{"ids":[]}' AS JSONB),
                               'system', now(),
                               'system', now());
