UPDATE asset_feature_metadata SET default_filter_criteria = 'reservedAttributes.state.key=''10'''
WHERE feature_code = 'RESTRICT_DECOMMISIONED_ASSETS';

UPDATE asset_feature_metadata SET default_filter_criteria = 'reservedAttributes.state.key=''03'''
WHERE feature_code = 'RESTRICT_INACTIVE_TAGS';

UPDATE asset_feature_metadata SET feature_code = 'RESTRICT_DECOMMISSIONED_ASSETS'
WHERE feature_code = 'RESTRICT_DECOMMISIONED_ASSETS';