CREATE TABLE asset_feature_metadata
(
  id                       UUID PRIMARY KEY,
  tenant_id                UUID,
  feature_code             TEXT NOT NULL,
  name                     TEXT NOT NULL,
  description              TEXT,
  category                 TEXT,
  filter_on                TEXT,
  applicable_super_types   TEXT[],
  action                   TEXT,
  filter_scope             TEXT,
  default_filter_criteria  TEXT,
  is_active                BOOLEAN,
  created_by               TEXT,
  created_date             TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by         TEXT,
  last_modified_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT asset_feature_code_id UNIQUE (feature_code)
);

CREATE TABLE asset_user_policy
(
   id                     UUID PRIMARY KEY,
   subject_id             UUID NOT NULL,
   subject_type           TEXT NOT NULL,
   tenant_id              UUID NOT NULL,
   feature_id             UUID NOT NULL REFERENCES asset_feature_metadata (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
   user_name              TEXT,
   display_name           TEXT,
   super_type             TEXT,
   filter_criteria        TEXT NOT NULL,
   created_by             TEXT,
   created_date           TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
   last_modified_by       TEXT,
   last_modified_date     TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    CONSTRAINT asset_policy_sub_id_type_feat UNIQUE (subject_id, subject_type,feature_id,filter_criteria,tenant_id),
   FOREIGN KEY (feature_id) REFERENCES asset_feature_metadata (id) DEFERRABLE INITIALLY IMMEDIATE
);
CREATE INDEX asset_user_policy_subject_idx
  ON asset_user_policy (subject_id);

/*
** Populate seed asset feature meta data
*/

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_DECOMMISIONED_ASSETS', 'Hide decommissioned assets', 'Prevents view/query of decommission assets', 'Hide Assets', 'ATTRIBUTES', '{4012dc78-2339-37f2-bbba-92a980b9ee65}', 'READ', 'OBJECTS', 'reservedAttribute.state.key="10"', true, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_ASSETS_BY_CLASS', 'Hide assets by classification', 'Prevents view/query of assets by classification', 'Hide Assets', 'CLASS', '{4012dc78-2339-37f2-bbba-92a980b9ee65}', 'READ', 'OBJECTS', '', false, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_ASSETS_BY_GROUP', 'Hide assets by group', 'Prevents view/query of assets by group', 'Hide Assets', 'GROUP', '{4012dc78-2339-37f2-bbba-92a980b9ee65}', 'READ', 'OBJECTS', '', false, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_ASSET_ATTRIBUTES', 'Hide asset attributes', 'Prevents view/query on asset attributes', 'Hide Assets', 'ATTRIBUTES', '{4012dc78-2339-37f2-bbba-92a980b9ee65}', 'READ', 'OBJECT_ELEMENTS', '', false, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_TAGS_BY_CLASS', 'Hide tags by classification', 'Prevents view/query of tags by classification', 'Hide Tags', 'CLASS', '{203d4660-702c-3cc9-8399-5663b9378408}', 'READ', 'OBJECTS', '', false, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_TAGS_BY_GROUP', 'Hide tags by group', 'Prevents view/query of tags by group', 'Hide Tags', 'GROUP', '{203d4660-702c-3cc9-8399-5663b9378408}', 'READ', 'OBJECTS', '', false, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_INACTIVE_TAGS', 'Hide inactive tags', 'Prevents view/query of inactive tags', 'Hide Tags', 'ATTRIBUTES', '{203d4660-702c-3cc9-8399-5663b9378408}', 'READ', 'OBJECTS', 'reservedAttribute.state.key="03"', false, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_TAG_ATTRIBUTES', 'Hide tag attributes', 'Prevents view/query on tag attribute', 'Hide Tags', 'ATTRIBUTES', '{203d4660-702c-3cc9-8399-5663b9378408}', 'READ', 'OBJECT_ELEMENTS', '', false, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_ENTERPRISE_BY_CLASS', 'Hide enterprise by classification', 'Prevents view/query on enterprise by classification', 'Hide Enterprises', 'CLASS', '{edf150de-d869-3741-8141-6f4c7f80254e}', 'READ', 'OBJECTS', '', false, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_ENTERPRISE_BY_GROUP', 'Hide enterprise by group', 'Prevents view/query on enterprise by group', 'Hide Enterprises', 'GROUP', '{edf150de-d869-3741-8141-6f4c7f80254e}', 'READ', 'OBJECTS', '', false, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_SITE_BY_CLASS', 'Hide site by classification', 'Prevents view/query on site by classification', 'Hide Sites', 'CLASS', '{c9fb733c-4c2e-3b43-9e01-47c9256af586}', 'READ', 'OBJECTS', '', false, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_SITE_BY_GROUP', 'Hide site by group', 'Prevents view/query on site by group', 'Hide Sites', 'GROUP', '{c9fb733c-4c2e-3b43-9e01-47c9256af586}', 'READ', 'OBJECTS', '', false, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_SEGMENT_BY_CLASS', 'Hide segment by classification', 'Prevents view/query on segment by classification', 'Hide Segments', 'CLASS', '{8c8b780b-14e0-382a-aeea-16b18c312dfa}', 'READ', 'OBJECTS', '', false, 'System', now(), 'System', now());

INSERT INTO asset_feature_metadata VALUES(
  (SELECT uuid_in(md5(random()::text || now()::text)::cstring)), null, 'RESTRICT_SEGMENT_BY_GROUP', 'Hide segment by group', 'Prevents view/query on segment by group', 'Hide Segments', 'GROUP', '{8c8b780b-14e0-382a-aeea-16b18c312dfa}', 'READ', 'OBJECTS', '', false, 'System', now(), 'System', now());
