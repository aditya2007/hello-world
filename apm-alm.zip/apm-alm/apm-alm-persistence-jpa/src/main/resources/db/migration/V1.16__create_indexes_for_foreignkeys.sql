DO $$
BEGIN
SET SEARCH_PATH = apm_alm, pg_catalog;
IF to_regclass('apm_alm.asset_instance_parentId_idx') IS NULL THEN
CREATE INDEX asset_instance_parentId_idx ON asset_instance (parent_id);
END IF;
IF to_regclass('apm_alm.tag_instance_assetId_idx') IS NULL THEN
CREATE INDEX tag_instance_assetId_idx ON tag_instance (asset_id);
END IF;
IF to_regclass('apm_alm.asset_group_asset_instance_objectId_idx') IS NULL THEN
CREATE INDEX asset_group_asset_instance_objectId_idx ON asset_group_asset_instance (object_id);
END IF;
IF to_regclass('apm_alm.asset_placeholder_assetId_idx') IS NULL THEN
CREATE INDEX asset_placeholder_assetId_idx ON asset_placeholder (asset_id);
END IF;
IF to_regclass('apm_alm.asset_group_association_objectId_idx') IS NULL THEN
CREATE INDEX asset_group_association_objectId_idx ON asset_group_association (object_id);
END IF;
IF to_regclass('apm_alm.network_node_asset_id_idx') IS NULL THEN
CREATE INDEX network_node_asset_id_idx ON network_node (asset_id);
END IF;
IF to_regclass('apm_alm.edge_assetId_idx') IS NULL THEN
CREATE INDEX edge_assetId_idx ON edge (asset_id);
END IF;
END $$;