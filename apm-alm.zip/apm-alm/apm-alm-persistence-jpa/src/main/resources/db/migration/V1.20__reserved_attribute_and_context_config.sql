CREATE SEQUENCE alm_context_config_id_seq start with 13;
CREATE SEQUENCE context_config_id_seq start with 24;
CREATE SEQUENCE reserved_attribute_context_config_id_seq start with 77;

--
-- Name: alm_context_config; Type: TABLE;
--

CREATE TABLE alm_context_config (
    id bigint DEFAULT nextval('alm_context_config_id_seq'::regclass) NOT NULL,
    tenant_id UUID NOT NULL,
    context_id bigint NOT NULL,
    value text NOT NULL,
    description text,
    created_on timestamp without time zone DEFAULT now() NOT NULL,
    updated_on timestamp without time zone
);


--
-- Name: context_config; Type: TABLE;
--

CREATE TABLE context_config (
    id bigint DEFAULT nextval('context_config_id_seq'::regclass) NOT NULL,
    name text NOT NULL ,
    code_type text NOT NULL,
    reserved_code_validation_expression text,
    created_on timestamp without time zone DEFAULT now() NOT NULL,
    updated_on timestamp without time zone,
    is_reserved_attribute_config boolean DEFAULT true NOT NULL,
    context_type text
);


--
-- Name: reserved_attribute_context_config; Type: TABLE;
--

CREATE TABLE reserved_attribute_context_config (
    id bigint DEFAULT nextval('reserved_attribute_context_config_id_seq'::regclass) NOT NULL,
    tenant_id UUID NOT NULL,
    context_id bigint NOT NULL,
    code text NOT NULL,
    semantic_name text NOT NULL,
    display_name text,
    description text,
    is_active boolean NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT now() NOT NULL,
    updated_on timestamp without time zone
);


--
-- Name: reserved_attribute_metadata; Type: TABLE;
--

CREATE TABLE reserved_attribute_metadata (
    id numeric NOT NULL,
    type text NOT NULL,
    config_json json,
    updated_on timestamp without time zone,
    created_on timestamp without time zone DEFAULT now() NOT NULL
);



--
-- Name: alm_context_config_pkey; Type: CONSTRAINT;
--

ALTER TABLE ONLY alm_context_config
    ADD CONSTRAINT alm_context_config_pkey PRIMARY KEY (id);


--
-- Name: alm_context_config_uk1; Type: CONSTRAINT;
--

ALTER TABLE ONLY alm_context_config
    ADD CONSTRAINT alm_context_config_uk1 UNIQUE (tenant_id, context_id);


--
-- Name: context_config_pkey; Type: CONSTRAINT;
--

ALTER TABLE ONLY context_config
    ADD CONSTRAINT context_config_pkey PRIMARY KEY (id);


--
-- Name: context_config_uk1; Type: CONSTRAINT;
--

ALTER TABLE ONLY context_config
    ADD CONSTRAINT context_config_uk1 UNIQUE (name);


--
-- Name: ra_metadata_pkey; Type: CONSTRAINT;
--

ALTER TABLE ONLY reserved_attribute_metadata
    ADD CONSTRAINT ra_metadata_pkey PRIMARY KEY (id);


--
-- Name: reserved_attribute_context_config_pkey; Type: CONSTRAINT;
--

ALTER TABLE ONLY reserved_attribute_context_config
    ADD CONSTRAINT reserved_attribute_context_config_pkey PRIMARY KEY (id);


--
-- Name: reserved_attribute_context_config_uk1; Type: CONSTRAINT;
--

ALTER TABLE ONLY reserved_attribute_context_config
    ADD CONSTRAINT reserved_attribute_context_config_uk1 UNIQUE (tenant_id, context_id, code, is_active);


--
-- Name: type_ukey; Type: CONSTRAINT;
--

ALTER TABLE ONLY reserved_attribute_metadata
    ADD CONSTRAINT type_ukey UNIQUE (type);


--
-- Name: alm_context_config_fk1; Type: FK CONSTRAINT;
--

ALTER TABLE ONLY alm_context_config
    ADD CONSTRAINT alm_context_config_fk1 FOREIGN KEY (context_id) REFERENCES context_config(id);


--
-- Name: reserved_attribute_context_config_fk1; Type: FK CONSTRAINT;
--

ALTER TABLE ONLY reserved_attribute_context_config
    ADD CONSTRAINT reserved_attribute_context_config_fk1 FOREIGN KEY (context_id) REFERENCES context_config(id);


--
-- Data for Name: context_config; Type: TABLE DATA;
--

INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (6, 'bulk_ingestion_audit', 'boolean', NULL, '2018-04-03 16:13:19.808459', NULL, false, NULL);
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (7, 'api_audit', 'boolean', NULL, '2018-04-03 16:13:19.808459', NULL, false, NULL);
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (8, 'cascade_delete_audit', 'boolean', NULL, '2018-04-03 16:13:19.808459', NULL, false, NULL);
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (1, 'asset-state', 'integer', 'code > 0 && code <= 100', '2018-04-03 16:13:19.737337', NULL, true, 'assets');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (2, 'asset-status', 'integer', 'code > 0 && code <= 100', '2018-04-03 16:13:19.737337', NULL, true, 'assets');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (5, 'tag-status', 'integer', 'code > 0 && code <= 100', '2018-04-03 16:13:19.737337', NULL, true, 'tags');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (9, 'asset_status_ui_edit', 'boolean', NULL, '2018-04-03 16:13:19.87382', NULL, false, 'assets');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (10, 'asset_state_ui_edit', 'boolean', NULL, '2018-04-03 16:13:19.87382', NULL, false, 'assets');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (11, 'tag_status_ui_edit', 'boolean', NULL, '2018-04-03 16:13:19.87382', NULL, false, 'tags');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (12, 'enterprise-state', 'integer', 'code > 0 && code <= 100', '2018-04-03 16:13:19.941748', NULL, true, 'enterprises');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (13, 'enterprise-status', 'integer', 'code > 0 && code <= 100', '2018-04-03 16:13:19.941748', NULL, true, 'enterprises');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (14, 'site-state', 'integer', 'code > 0 && code <= 100', '2018-04-03 16:13:19.941748', NULL, true, 'sites');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (15, 'site-status', 'integer', 'code > 0 && code <= 100', '2018-04-03 16:13:19.941748', NULL, true, 'sites');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (16, 'segment-state', 'integer', 'code > 0 && code <= 100', '2018-04-03 16:13:19.941748', NULL, true, 'segments');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (17, 'segment-status', 'integer', 'code > 0 && code <= 100', '2018-04-03 16:13:19.941748', NULL, true, 'segments');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (18, 'enterprise_state_ui_edit', 'boolean', NULL, '2018-04-03 16:13:19.941748', NULL, false, 'enterprises');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (19, 'enterprise_status_ui_edit', 'boolean', NULL, '2018-04-03 16:13:19.941748', NULL, false, 'enterprises');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (20, 'site_state_ui_edit', 'boolean', NULL, '2018-04-03 16:13:19.941748', NULL, false, 'sites');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (21, 'site_status_ui_edit', 'boolean', NULL, '2018-04-03 16:13:19.941748', NULL, false, 'sites');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (22, 'segment_state_ui_edit', 'boolean', NULL, '2018-04-03 16:13:19.941748', NULL, false, 'segments');
INSERT INTO context_config (id, name, code_type, reserved_code_validation_expression, created_on, updated_on, is_reserved_attribute_config, context_type) VALUES (23, 'segment_status_ui_edit', 'boolean', NULL, '2018-04-03 16:13:19.941748', NULL, false, 'segments');


--
-- Data for Name: alm_context_config; Type: TABLE DATA;
--

INSERT INTO alm_context_config (id, tenant_id, context_id, value, description, created_on, updated_on) VALUES (1, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 6, 'true', 'This is a flag to turn “on or off” auditing of ALM asset ingestion. “On” will audit all activities for ingestion. This includes Create, Update and Delete. “Off” will not audit any activity.', '2018-04-03 16:13:19.808459', NULL);
INSERT INTO alm_context_config (id, tenant_id, context_id, value, description, created_on, updated_on) VALUES (2, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 7, 'true', 'This is a flag to turn “on or off” auditing of the APM ALM API. “On” will audit all Create, Update and Delete operations performed by users or external processes. “Off” will not audit an operation.', '2018-04-03 16:13:19.808459', NULL);
INSERT INTO alm_context_config (id, tenant_id, context_id, value, description, created_on, updated_on) VALUES (3, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 8, 'true', 'This is a flag to turn “on or off” auditing of cascade delete activity. “On” will audit all activities for “ALM asset” ingestion. “Off” will not audit any activity', '2018-04-03 16:13:19.808459', NULL);
INSERT INTO alm_context_config (id, tenant_id, context_id, value, description, created_on, updated_on) VALUES (4, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 9, 'true', 'This is a flag to “enable or disable” the ability to edit the asset status via user interface. The default value is “True”, i.e. through user interface asset status is enabled for editing. The value “False” will make the user interface for asset status as read only.', '2018-04-03 16:13:19.87382', NULL);
INSERT INTO alm_context_config (id, tenant_id, context_id, value, description, created_on, updated_on) VALUES (5, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 10, 'true', 'This is a flag to “enable or disable” the ability to edit the asset state via user interface. The default value is “True”, i.e. through user interface asset state is enabled for editing. The value “False” will make the user interface for asset state as read only.', '2018-04-03 16:13:19.87382', NULL);
INSERT INTO alm_context_config (id, tenant_id, context_id, value, description, created_on, updated_on) VALUES (6, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 11, 'true', 'This is a flag to “enable or disable” the ability to edit the tag status via user interface. The default value is “True”, i.e. through user interface tag status is enabled for editing. The value “False” will make the user interface for tag status as read only.', '2018-04-03 16:13:19.87382', NULL);
INSERT INTO alm_context_config (id, tenant_id, context_id, value, description, created_on, updated_on) VALUES (7, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 18, 'true', 'This is a flag to “enable or disable” the ability to edit the enterprise state via user interface. The default value is “True”, i.e. through user interface asset status is enabled for editing. The value “False” will make the user interface for asset status as read only.', '2018-04-03 16:13:19.941748', NULL);
INSERT INTO alm_context_config (id, tenant_id, context_id, value, description, created_on, updated_on) VALUES (8, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 19, 'true', 'This is a flag to “enable or disable” the ability to edit the enterprise status via user interface. The default value is “True”, i.e. through user interface asset status is enabled for editing. The value “False” will make the user interface for asset status as read only.', '2018-04-03 16:13:19.941748', NULL);
INSERT INTO alm_context_config (id, tenant_id, context_id, value, description, created_on, updated_on) VALUES (9, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 20, 'true', 'This is a flag to “enable or disable” the ability to edit the site state via user interface. The default value is “True”, i.e. through user interface asset status is enabled forediting. The value “False” will make the user interface for asset status as read only.', '2018-04-03 16:13:19.941748', NULL);
INSERT INTO alm_context_config (id, tenant_id, context_id, value, description, created_on, updated_on) VALUES (10, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 21, 'true', 'This is a flag to “enable or disable” the ability to edit the site status via user interface. The default value is “True”, i.e. through user interface asset status is enabled for editing. The value “False” will make the user interface for asset status as read only.', '2018-04-03 16:13:19.941748', NULL);
INSERT INTO alm_context_config (id, tenant_id, context_id, value, description, created_on, updated_on) VALUES (11, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 22, 'true', 'This is a flag to “enable or disable” the ability to edit the segment state via user interface. The default value is “True”, i.e. through user interface asset status is enabled for editing. The value “False” will make the user interface for asset status as read only.', '2018-04-03 16:13:19.941748', NULL);
INSERT INTO alm_context_config (id, tenant_id, context_id, value, description, created_on, updated_on) VALUES (12, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 23, 'true', 'This is a flag to “enable or disable” the ability to edit the segment status via user interface. The default value is “True”, i.e. through user interface asset status is enabledfor editing. The value “False” will make the user interface for asset status as read only.', '2018-04-03 16:13:19.941748', NULL);

--
-- Data for Name: reserved_attribute_context_config; Type: TABLE DATA;
--

INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (13, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 2, '01', 'Failure', NULL, 'RED: Signal of stop of the operating machine in front of a major failure and which need operator intervention. Failure conditions such as an emergency stop or machine fault.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (14, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 2, '02', 'Warning', NULL, 'YELLOW: Report an anomaly and requires intervention by the operator for verification of the cause manifested. Warnings such as over-temperature or over-pressure conditions', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (15, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 2, '03', 'Normal', NULL, 'GREEN: Correct operation signaling or drive alert ready to be actuated. Normal machine or process operation', true, true, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (16, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 2, '04', 'External Help Request', NULL, 'BLUE: Report a request of intervention by the operator for the reset. External help request, where an operator might be requesting raw materials, scheduling or maintenance personnel assistance', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (17, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 2, '05', 'User-Defined Condition', NULL, 'WHITE: To be used to communicate a message different to that foreseen by the standard status required monitoring. User-defined conditions specific to a machine, often related to productivity monitoring.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (1, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 1, '01', 'Plan', NULL, 'The most effective way to reduce the overall risk exposure for an asset is to eliminate factors that could result in risks during the planning/conceptual and actual design phases. This approach can be referred to as “Front-end elimination” of risk, or at least, front-end minimization of risk. Eliminating or minimizing risk during these phases of a project will limit the overall risk exposure that an asset will carry for the remainder of its operating life. This can obviously be much more effective than attempting to manage in-built risks later during a asset’s operating phase. Risk reduction during the operating phase may be restricted to implementing procedures and training, which have limited effectiveness, or retro-fitting of engineering solutions, which can be expensive', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (2, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 1, '02', 'Design', NULL, 'The most effective way to reduce the overall risk exposure for an asset is to eliminate factors that could result in risks during the planning/conceptual and actual design phases. This approach can be referred to as “Front-end elimination” of risk, or at least, front-end minimization of risk. Eliminating or minimizing risk during these phases of a project will limit the overall risk exposure that an asset will carry for the remainder of its operating life. This can obviously be much more effective than attempting to manage in-built risks later during a asset’s operating phase. Risk reduction during the operating phase may be restricted to implementing procedures and training, which have limited effectiveness, or retro-fitting of engineering solutions, which can be expensive', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (3, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 1, '03', 'Procure', NULL, 'Procurement is the act of finding, acquiring, buying parts, services or works from an external source, often via a tendering or competitive bidding process. The process is used to ensure the manufacturer receives parts, services or works at the best possible price, when aspects such as quality, quantity, time, and location are compared. Corporations and public bodies often define processes intended to promote fair and open competition for their business while minimizing risk, such as exposure to fraud and collusion.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (4, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 1, '04', 'Build', NULL, 'A variety of risks present themselves during the build phase of a project. These range from occupational health and safety risks associated with injuries, to major financial risks that may have the potential to derail the project. In addition to managing the lower level risks, it is essential to identify and address risks that have the potential to seriously impact the viability of the project. Industrial relations is an example of potential risks facing a project during construction.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (5, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 1, '05', 'Commission', NULL, 'During the commissioning phase, reviews are essential to ensure that the capital equipment and systems have been manufactured, installed and connected in a safe and reliable fashion. There is a need to conduct validation reviews to ensure that the installed design of the asset meets the specified performance parameters. This process is an extension of the “Owner’s Representative” approach discussed earlier, and is most effective when implemented as a continuation of the same process.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (6, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 1, '06', 'Operate', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, true, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (7, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 1, '07', 'Maintain', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (8, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 1, '08', 'Monitor', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (9, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 1, '09', 'Upgrade', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (23, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 5, '01', 'Unknown', NULL, 'The tag status is “Unknown”. It means not configured correctly or not configured at all.', true, true, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (24, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 5, '02', 'Active', NULL, 'The tag status is “Active”. The tag is actively used for multiple applications like Visualization and Analytic.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (25, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 5, '03', 'Inactive', NULL, 'The tag status is “Inactive”. The tag is not used by any application.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (33, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 12, '08', 'Monitor', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (34, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 12, '09', 'Upgrade', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (35, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 12, '10', 'Decommission', NULL, 'Selection of appropriate asset design can eliminate or reduce the issues associated with the decommissioning and disposal of facilities at the end of their useful life. Without such consideration, headaches easily present themselves for those left with the responsibility of decommissioning and disposing of the asset. Risk management can be put to good effect during the concept and design phases of a project to anticipate potential problems and take them into consideration in the initial design of the asset. This would enable potential clean-up issues to be avoided altogether, or at least appropriate risk reduction controls to be put into place in the initial design to minimize the impacts. Asset remediation is an issue that often raises itself during the final phases of the life of an asset. It is during this phase that major costs that have remained hidden for years will become evident. An example of this is major contamination of the asset, caused by chemicals leaking. The extent of the contamination is commonly not known until the clean-up begins and many companies have faced potential financial ruin from the clean-up obligations that have been imposed on them following cessation of operations. To avoid this situation, it is important to identify potential risks early on and act accordingly, such as by providing appropriate leak prevention and spill containment systems.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (10, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 1, '10', 'Decommission', NULL, 'Selection of appropriate asset design can eliminate or reduce the issues associated with the decommissioning and disposal of facilities at the end of their useful life. Without such consideration, headaches easily present themselves for those left with the responsibility of decommissioning and disposing of the asset. Risk management can be put to good effect during the concept and design phases of a project to anticipate potential problems and take them into consideration in the initial design of the asset. This would enable potential clean-up issues to be avoided altogether, or at least appropriate risk reduction controls to be put into place in the initial design to minimize the impacts. Asset remediation is an issue that often raises itself during the final phases of the life of an asset. It is during this phase that major costs that have remained hidden for years will become evident. An example of this is major contamination of the asset, caused by chemicals leaking. The extent of the contamination is commonly not known until the clean-up begins and many companies have faced potential financial ruin from the clean-up obligations that have been imposed on them following cessation of operations. To avoid this situation, it is important to identify potential risks early on and act accordingly, such as by providing appropriate leak prevention and spill containment systems.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (11, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 1, '11', 'Replace', NULL, 'Selection of appropriate asset design can eliminate or reduce the issues associated with the decommissioning and disposal of facilities at the end of their useful life. Without such consideration, headaches easily present themselves for those left with the responsibility of decommissioning and disposing of the asset. Risk management can be put to good effect during the concept and design phases of a project to anticipate potential problems and take them into consideration in the initial design of the asset. This would enable potential clean-up issues to be avoided altogether, or at least appropriate risk reduction controls to be put into place in the initial design to minimize the impacts. Asset remediation is an issue that often raises itself during the final phases of the life of an asset. It is during this phase that major costs that have remained hidden for years will become evident. An example of this is major contamination of the asset, caused by chemicals leaking. The extent of the contamination is commonly not known until the clean-up begins and many companies have faced potential financial ruin from the clean-up obligations that have been imposed on them following cessation of operations. To avoid this situation, it is important to identify potential risks early on and act accordingly, such as by providing appropriate leak prevention and spill containment systems.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (12, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 1, '12', 'Dispose', NULL, 'Selection of appropriate asset design can eliminate or reduce the issues associated with the decommissioning and disposal of facilities at the end of their useful life. Without such consideration, headaches easily present themselves for those left with the responsibility of decommissioning and disposing of the asset. Risk management can be put to good effect during the concept and design phases of a project to anticipate potential problems and take them into consideration in the initial design of the asset. This would enable potential clean-up issues to be avoided altogether, or at least appropriate risk reduction controls to be put into place in the initial design to minimize the impacts. Asset remediation is an issue that often raises itself during the final phases of the life of an asset. It is during this phase that major costs that have remained hidden for years will become evident. An example of this is major contamination of the asset, caused by chemicals leaking. The extent of the contamination is commonly not known until the clean-up begins and many companies have faced potential financial ruin from the clean-up obligations that have been imposed on them following cessation of operations. To avoid this situation, it is important to identify potential risks early on and act accordingly, such as by providing appropriate leak prevention and spill containment systems.', true, false, '2018-04-03 16:13:19.737337', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (26, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 12, '01', 'Plan', NULL, 'The most effective way to reduce the overall risk exposure for an asset is to eliminate factors that could result in risks during the planning/conceptual and actual design phases. This approach can be referred to as “Front-end elimination” of risk, or at least, front-end minimization of risk. Eliminating or minimizing risk during these phases of a project will limit the overall risk exposure that an asset will carry for the remainder of its operating life. This can obviously be much more effective than attempting to manage in-built risks later during a asset’s operating phase. Risk reduction during the operating phase may be restricted to implementing procedures and training, which have limited effectiveness, or retro-fitting of engineering solutions, which can be expensive', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (27, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 12, '02', 'Design', NULL, 'The most effective way to reduce the overall risk exposure for an asset is to eliminate factors that could result in risks during the planning/conceptual and actual design phases. This approach can be referred to as “Front-end elimination” of risk, or at least, front-end minimization of risk. Eliminating or minimizing risk during these phases of a project will limit the overall risk exposure that an asset will carry for the remainder of its operating life. This can obviously be much more effective than attempting to manage in-built risks later during a asset’s operating phase. Risk reduction during the operating phase may be restricted to implementing procedures and training, which have limited effectiveness, or retro-fitting of engineering solutions, which can be expensive', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (28, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 12, '03', 'Procure', NULL, 'Procurement is the act of finding, acquiring, buying parts, services or works from an external source, often via a tendering or competitive bidding process. The process is used to ensure the manufacturer receives parts, services or works at the best possible price, when aspects such as quality, quantity, time, and location are compared. Corporations and public bodies often define processes intended to promote fair and open competition for their business while minimizing risk, such as exposure to fraud and collusion.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (29, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 12, '04', 'Build', NULL, 'A variety of risks present themselves during the build phase of a project. These range from occupational health and safety risks associated with injuries, to major financial risks that may have the potential to derail the project. In addition to managing the lower level risks, it is essential to identify and address risks that have the potential to seriously impact the viability of the project. Industrial relations is an example of potential risks facing a project during construction.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (30, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 12, '05', 'Commission', NULL, 'During the commissioning phase, reviews are essential to ensure that the capital equipment and systems have been manufactured, installed and connected in a safe and reliable fashion. There is a need to conduct validation reviews to ensure that the installed design of the asset meets the specified performance parameters. This process is an extension of the “Owner’s Representative” approach discussed earlier, and is most effective when implemented as a continuation of the same process.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (31, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 12, '06', 'Operate', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, true, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (32, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 12, '07', 'Maintain', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (36, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 12, '11', 'Replace', NULL, 'Selection of appropriate asset design can eliminate or reduce the issues associated with the decommissioning and disposal of facilities at the end of their useful life. Without such consideration, headaches easily present themselves for those left with the responsibility of decommissioning and disposing of the asset. Risk management can be put to good effect during the concept and design phases of a project to anticipate potential problems and take them into consideration in the initial design of the asset. This would enable potential clean-up issues to be avoided altogether, or at least appropriate risk reduction controls to be put into place in the initial design to minimize the impacts. Asset remediation is an issue that often raises itself during the final phases of the life of an asset. It is during this phase that major costs that have remained hidden for years will become evident. An example of this is major contamination of the asset, caused by chemicals leaking. The extent of the contamination is commonly not known until the clean-up begins and many companies have faced potential financial ruin from the clean-up obligations that have been imposed on them following cessation of operations. To avoid this situation, it is important to identify potential risks early on and act accordingly, such as by providing appropriate leak prevention and spill containment systems.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (37, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 12, '12', 'Dispose', NULL, 'Selection of appropriate asset design can eliminate or reduce the issues associated with the decommissioning and disposal of facilities at the end of their useful life. Without such consideration, headaches easily present themselves for those left with the responsibility of decommissioning and disposing of the asset. Risk management can be put to good effect during the concept and design phases of a project to anticipate potential problems and take them into consideration in the initial design of the asset. This would enable potential clean-up issues to be avoided altogether, or at least appropriate risk reduction controls to be put into place in the initial design to minimize the impacts. Asset remediation is an issue that often raises itself during the final phases of the life of an asset. It is during this phase that major costs that have remained hidden for years will become evident. An example of this is major contamination of the asset, caused by chemicals leaking. The extent of the contamination is commonly not known until the clean-up begins and many companies have faced potential financial ruin from the clean-up obligations that have been imposed on them following cessation of operations. To avoid this situation, it is important to identify potential risks early on and act accordingly, such as by providing appropriate leak prevention and spill containment systems.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (38, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 13, '01', 'Failure', NULL, 'RED: Signal of stop of the operating machine in front of a major failure and which need operator intervention. Failure conditions such as an emergency stop or machine fault.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (39, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 13, '02', 'Warning', NULL, 'YELLOW: Report an anomaly and requires intervention by the operator for verification of the cause manifested. Warnings such as over-temperature or over-pressure conditions', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (40, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 13, '03', 'Normal', NULL, 'GREEN: Correct operation signaling or drive alert ready to be actuated. Normal machine or process operation', true, true, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (41, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 13, '04', 'External Help Request', NULL, 'BLUE: Report a request of intervention by the operator for the reset. External help request, where an operator might be requesting raw materials, scheduling or maintenance personnel assistance', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (42, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 13, '05', 'User-Defined Condition', NULL, 'WHITE: To be used to communicate a message different to that foreseen by the standard status required monitoring. User-defined conditions specific to a machine, often related to productivity monitoring.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (43, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 14, '01', 'Plan', NULL, 'The most effective way to reduce the overall risk exposure for an asset is to eliminate factors that could result in risks during the planning/conceptual and actual design phases. This approach can be referred to as “Front-end elimination” of risk, or at least, front-end minimization of risk. Eliminating or minimizing risk during these phases of a project will limit the overall risk exposure that an asset will carry for the remainder of its operating life. This can obviously be much more effective than attempting to manage in-built risks later during a asset’s operating phase. Risk reduction during the operating phase may be restricted to implementing procedures and training, which have limited effectiveness, or retro-fitting of engineering solutions, which can be expensive', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (44, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 14, '02', 'Design', NULL, 'The most effective way to reduce the overall risk exposure for an asset is to eliminate factors that could result in risks during the planning/conceptual and actual design phases. This approach can be referred to as “Front-end elimination” of risk, or at least, front-end minimization of risk. Eliminating or minimizing risk during these phases of a project will limit the overall risk exposure that an asset will carry for the remainder of its operating life. This can obviously be much more effective than attempting to manage in-built risks later during a asset’s operating phase. Risk reduction during the operating phase may be restricted to implementing procedures and training, which have limited effectiveness, or retro-fitting of engineering solutions, which can be expensive', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (45, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 14, '03', 'Procure', NULL, 'Procurement is the act of finding, acquiring, buying parts, services or works from an external source, often via a tendering or competitive bidding process. The process is used to ensure the manufacturer receives parts, services or works at the best possible price, when aspects such as quality, quantity, time, and location are compared. Corporations and public bodies often define processes intended to promote fair and open competition for their business while minimizing risk, such as exposure to fraud and collusion.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (46, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 14, '04', 'Build', NULL, 'A variety of risks present themselves during the build phase of a project. These range from occupational health and safety risks associated with injuries, to major financial risks that may have the potential to derail the project. In addition to managing the lower level risks, it is essential to identify and address risks that have the potential to seriously impact the viability of the project. Industrial relations is an example of potential risks facing a project during construction.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (47, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 14, '05', 'Commission', NULL, 'During the commissioning phase, reviews are essential to ensure that the capital equipment and systems have been manufactured, installed and connected in a safe and reliable fashion. There is a need to conduct validation reviews to ensure that the installed design of the asset meets the specified performance parameters. This process is an extension of the “Owner’s Representative” approach discussed earlier, and is most effective when implemented as a continuation of the same process.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (48, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 14, '06', 'Operate', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, true, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (49, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 14, '07', 'Maintain', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (50, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 14, '08', 'Monitor', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (51, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 14, '09', 'Upgrade', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (52, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 14, '10', 'Decommission', NULL, 'Selection of appropriate asset design can eliminate or reduce the issues associated with the decommissioning and disposal of facilities at the end of their useful life. Without such consideration, headaches easily present themselves for those left with the responsibility of decommissioning and disposing of the asset. Risk management can be put to good effect during the concept and design phases of a project to anticipate potential problems and take them into consideration in the initial design of the asset. This would enable potential clean-up issues to be avoided altogether, or at least appropriate risk reduction controls to be put into place in the initial design to minimize the impacts. Asset remediation is an issue that often raises itself during the final phases of the life of an asset. It is during this phase that major costs that have remained hidden for years will become evident. An example of this is major contamination of the asset, caused by chemicals leaking. The extent of the contamination is commonly not known until the clean-up begins and many companies have faced potential financial ruin from the clean-up obligations that have been imposed on them following cessation of operations. To avoid this situation, it is important to identify potential risks early on and act accordingly, such as by providing appropriate leak prevention and spill containment systems.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (53, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 14, '11', 'Replace', NULL, 'Selection of appropriate asset design can eliminate or reduce the issues associated with the decommissioning and disposal of facilities at the end of their useful life. Without such consideration, headaches easily present themselves for those left with the responsibility of decommissioning and disposing of the asset. Risk management can be put to good effect during the concept and design phases of a project to anticipate potential problems and take them into consideration in the initial design of the asset. This would enable potential clean-up issues to be avoided altogether, or at least appropriate risk reduction controls to be put into place in the initial design to minimize the impacts. Asset remediation is an issue that often raises itself during the final phases of the life of an asset. It is during this phase that major costs that have remained hidden for years will become evident. An example of this is major contamination of the asset, caused by chemicals leaking. The extent of the contamination is commonly not known until the clean-up begins and many companies have faced potential financial ruin from the clean-up obligations that have been imposed on them following cessation of operations. To avoid this situation, it is important to identify potential risks early on and act accordingly, such as by providing appropriate leak prevention and spill containment systems.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (54, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 14, '12', 'Dispose', NULL, 'Selection of appropriate asset design can eliminate or reduce the issues associated with the decommissioning and disposal of facilities at the end of their useful life. Without such consideration, headaches easily present themselves for those left with the responsibility of decommissioning and disposing of the asset. Risk management can be put to good effect during the concept and design phases of a project to anticipate potential problems and take them into consideration in the initial design of the asset. This would enable potential clean-up issues to be avoided altogether, or at least appropriate risk reduction controls to be put into place in the initial design to minimize the impacts. Asset remediation is an issue that often raises itself during the final phases of the life of an asset. It is during this phase that major costs that have remained hidden for years will become evident. An example of this is major contamination of the asset, caused by chemicals leaking. The extent of the contamination is commonly not known until the clean-up begins and many companies have faced potential financial ruin from the clean-up obligations that have been imposed on them following cessation of operations. To avoid this situation, it is important to identify potential risks early on and act accordingly, such as by providing appropriate leak prevention and spill containment systems.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (55, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 15, '01', 'Failure', NULL, 'RED: Signal of stop of the operating machine in front of a major failure and which need operator intervention. Failure conditions such as an emergency stop or machine fault.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (56, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 15, '02', 'Warning', NULL, 'YELLOW: Report an anomaly and requires intervention by the operator for verification of the cause manifested. Warnings such as over-temperature or over-pressure conditions', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (57, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 15, '03', 'Normal', NULL, 'GREEN: Correct operation signaling or drive alert ready to be actuated. Normal machine or process operation', true, true, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (58, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 15, '04', 'External Help Request', NULL, 'BLUE: Report a request of intervention by the operator for the reset. External help request, where an operator might be requesting raw materials, scheduling or maintenance personnel assistance', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (59, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 15, '05', 'User-Defined Condition', NULL, 'WHITE: To be used to communicate a message different to that foreseen by the standard status required monitoring. User-defined conditions specific to a machine, often related to productivity monitoring.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (60, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 16, '01', 'Plan', NULL, 'The most effective way to reduce the overall risk exposure for an asset is to eliminate factors that could result in risks during the planning/conceptual and actual design phases. This approach can be referred to as “Front-end elimination” of risk, or at least, front-end minimization of risk. Eliminating or minimizing risk during these phases of a project will limit the overall risk exposure that an asset will carry for the remainder of its operating life. This can obviously be much more effective than attempting to manage in-built risks later during a asset’s operating phase. Risk reduction during the operating phase may be restricted to implementing procedures and training, which have limited effectiveness, or retro-fitting of engineering solutions, which can be expensive', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (61, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 16, '02', 'Design', NULL, 'The most effective way to reduce the overall risk exposure for an asset is to eliminate factors that could result in risks during the planning/conceptual and actual design phases. This approach can be referred to as “Front-end elimination” of risk, or at least, front-end minimization of risk. Eliminating or minimizing risk during these phases of a project will limit the overall risk exposure that an asset will carry for the remainder of its operating life. This can obviously be much more effective than attempting to manage in-built risks later during a asset’s operating phase. Risk reduction during the operating phase may be restricted to implementing procedures and training, which have limited effectiveness, or retro-fitting of engineering solutions, which can be expensive', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (62, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 16, '03', 'Procure', NULL, 'Procurement is the act of finding, acquiring, buying parts, services or works from an external source, often via a tendering or competitive bidding process. The process is used to ensure the manufacturer receives parts, services or works at the best possible price, when aspects such as quality, quantity, time, and location are compared. Corporations and public bodies often define processes intended to promote fair and open competition for their business while minimizing risk, such as exposure to fraud and collusion.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (63, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 16, '04', 'Build', NULL, 'A variety of risks present themselves during the build phase of a project. These range from occupational health and safety risks associated with injuries, to major financial risks that may have the potential to derail the project. In addition to managing the lower level risks, it is essential to identify and address risks that have the potential to seriously impact the viability of the project. Industrial relations is an example of potential risks facing a project during construction.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (64, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 16, '05', 'Commission', NULL, 'During the commissioning phase, reviews are essential to ensure that the capital equipment and systems have been manufactured, installed and connected in a safe and reliable fashion. There is a need to conduct validation reviews to ensure that the installed design of the asset meets the specified performance parameters. This process is an extension of the “Owner’s Representative” approach discussed earlier, and is most effective when implemented as a continuation of the same process.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (65, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 16, '06', 'Operate', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, true, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (66, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 16, '07', 'Maintain', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (67, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 16, '08', 'Monitor', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (68, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 16, '09', 'Upgrade', NULL, 'During the production phase of a asset, the scope for reducing risk is more limited. During the production or operational phase, implementation of additional risk control measures is restricted to procedures and the installation of improved control systems to manage safety-related hazards, or procedures and improved maintenance practices to manage operational risks. Unfortunately for the operators of many assets, the first time that risk approaches are implemented is often during the operational phase. Risk assessment can typically be triggered by regulatory requirements (e.g. statutory approvals) or unsatisfactory performance (e.g. in either safety or operational performance). These assessments may identify areas where the risk exposure can be reduced; however risk reduction measures that achieve a step-change in the risk exposure for a facility commonly require significant expenditure. Experience has indicated that when considering operational risk exposures, the major risks are commonly associated with relatively frequent events that have a moderate consequence. The cumulative impact of these events on the overall operation is commonly underestimated, resulting in them being neglected, with the status quo of poor operation continuing. A thorough risk assessment targeting events of this nature can identify the high-risk events and then also identify suitable controls for prevention and mitigation of the incident. Although it is preferable that risk exposures be minimized in the front-end design of an asset, significant risk reduction can often be achieved once the asset is operational. As with the initial design of the asset, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. In many situations where upgrades and modifications are designed for an asset, they fail to take advantage of the opportunity to optimize the overall outcome. This can occur when external contractors are used, but can also easily occur when in-house project engineering groups are used. These groups often operate virtually independently of the operational arms of the organization, having their own goals and performance measures in place. Similar to the situation that can be encountered during the design phase, this situation can result in the installed asset having a greater risk exposure than is necessary. In order to minimize this potential, it is good practice to have representatives from the operational plant involved intimately with the design team, effectively fulfilling the role of an “owner’s representative”. This will ensure that the new items do not add unnecessary risk exposures to the original asset and will decrease risk where possible. An example of a significant risk improvement achieved during the life of an asset was the replacement of particular asset in a chlorine production plant. When the need arose to replace the refrigeration unit for the refrigerated liquid chlorine storage facility, the design choice was made to install the refrigeration unit within the secondary containment building housing the refrigerated storage vessels. As with the initial design of the facility, it is important to ensure that the risk exposures and operational requirements are taken into account during the design of upgrades, enhancements and modifications. This option was selected to minimize the potential consequences of a release, by locating all pipelines that held liquid chlorine within the secondary containment building. A cheaper option of replacing the refrigeration system “like for like” would have missed this opportunity to increase the overall safety of the facility.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (69, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 16, '10', 'Decommission', NULL, 'Selection of appropriate asset design can eliminate or reduce the issues associated with the decommissioning and disposal of facilities at the end of their useful life. Without such consideration, headaches easily present themselves for those left with the responsibility of decommissioning and disposing of the asset. Risk management can be put to good effect during the concept and design phases of a project to anticipate potential problems and take them into consideration in the initial design of the asset. This would enable potential clean-up issues to be avoided altogether, or at least appropriate risk reduction controls to be put into place in the initial design to minimize the impacts. Asset remediation is an issue that often raises itself during the final phases of the life of an asset. It is during this phase that major costs that have remained hidden for years will become evident. An example of this is major contamination of the asset, caused by chemicals leaking. The extent of the contamination is commonly not known until the clean-up begins and many companies have faced potential financial ruin from the clean-up obligations that have been imposed on them following cessation of operations. To avoid this situation, it is important to identify potential risks early on and act accordingly, such as by providing appropriate leak prevention and spill containment systems.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (70, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 16, '11', 'Replace', NULL, 'Selection of appropriate asset design can eliminate or reduce the issues associated with the decommissioning and disposal of facilities at the end of their useful life. Without such consideration, headaches easily present themselves for those left with the responsibility of decommissioning and disposing of the asset. Risk management can be put to good effect during the concept and design phases of a project to anticipate potential problems and take them into consideration in the initial design of the asset. This would enable potential clean-up issues to be avoided altogether, or at least appropriate risk reduction controls to be put into place in the initial design to minimize the impacts. Asset remediation is an issue that often raises itself during the final phases of the life of an asset. It is during this phase that major costs that have remained hidden for years will become evident. An example of this is major contamination of the asset, caused by chemicals leaking. The extent of the contamination is commonly not known until the clean-up begins and many companies have faced potential financial ruin from the clean-up obligations that have been imposed on them following cessation of operations. To avoid this situation, it is important to identify potential risks early on and act accordingly, such as by providing appropriate leak prevention and spill containment systems.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (71, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 16, '12', 'Dispose', NULL, 'Selection of appropriate asset design can eliminate or reduce the issues associated with the decommissioning and disposal of facilities at the end of their useful life. Without such consideration, headaches easily present themselves for those left with the responsibility of decommissioning and disposing of the asset. Risk management can be put to good effect during the concept and design phases of a project to anticipate potential problems and take them into consideration in the initial design of the asset. This would enable potential clean-up issues to be avoided altogether, or at least appropriate risk reduction controls to be put into place in the initial design to minimize the impacts. Asset remediation is an issue that often raises itself during the final phases of the life of an asset. It is during this phase that major costs that have remained hidden for years will become evident. An example of this is major contamination of the asset, caused by chemicals leaking. The extent of the contamination is commonly not known until the clean-up begins and many companies have faced potential financial ruin from the clean-up obligations that have been imposed on them following cessation of operations. To avoid this situation, it is important to identify potential risks early on and act accordingly, such as by providing appropriate leak prevention and spill containment systems.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (72, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 17, '01', 'Failure', NULL, 'RED: Signal of stop of the operating machine in front of a major failure and which need operator intervention. Failure conditions such as an emergency stop or machine fault.', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (73, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 17, '02', 'Warning', NULL, 'YELLOW: Report an anomaly and requires intervention by the operator for verification of the cause manifested. Warnings such as over-temperature or over-pressure conditions', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (74, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 17, '03', 'Normal', NULL, 'GREEN: Correct operation signaling or drive alert ready to be actuated. Normal machine or process operation', true, true, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (75, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 17, '04', 'External Help Request', NULL, 'BLUE: Report a request of intervention by the operator for the reset. External help request, where an operator might be requesting raw materials, scheduling or maintenance personnel assistance', true, false, '2018-04-03 16:13:19.941748', NULL);
INSERT INTO reserved_attribute_context_config (id, tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on) VALUES (76, '259dd121-fd2c-43e0-aa5c-c9ebf0cb724c', 17, '05', 'User-Defined Condition', NULL, 'WHITE: To be used to communicate a message different to that foreseen by the standard status required monitoring. User-defined conditions specific to a machine, often related to productivity monitoring.', true, false, '2018-04-03 16:13:19.941748', NULL);


--
-- Data for Name: reserved_attribute_metadata; Type: TABLE DATA;
--

INSERT INTO reserved_attribute_metadata (id, type, config_json, updated_on, created_on) VALUES (5, 'assetTemplates', '[
  {
    "name": "state",
    "displayName": "Template state",
    "type": "KeyValue",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [
      {
        "key": "01",
        "value": "Draft"
      },
      {
        "key": "02",
        "value": "Review"
      },
      {
        "key": "03",
        "value": "Published"
      }
    ],
    "defaultValue": {
      "key": "01",
      "value": "Draft"
    },
    "tenant": null,
    "overwrite": false,
    "instanceApplicability" : null
  },
  {
    "name": "status",
    "displayName": "Template Status",
    "type": "KeyValue",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [
      {
        "key": "01",
        "value": "Active"
      },
      {
        "key": "02",
        "value": "Inactive"
      }
    ],
    "defaultValue":  {
      "key": "01",
      "value": "Active"
    },
    "tenant": null,
    "overwrite": false,
    "instanceApplicability" :null
  }
]', NULL, '2018-04-03 16:13:19.78741');
INSERT INTO reserved_attribute_metadata (id, type, config_json, updated_on, created_on) VALUES (6, 'assetTemplatePlaceholders', '[{
  "name": "systemEffectiveTimestamp",
  "displayName": "Placeholder System Effective Timestamp",
  "type": "Timestamp",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValues": [],
  "defaultValue": null,
  "overwrite": true,
  "tenant": null,
  "instanceApplicability" : null
}]', NULL, '2018-04-03 16:13:19.78741');
INSERT INTO reserved_attribute_metadata (id, type, config_json, updated_on, created_on) VALUES (2, 'assetTypes', '[
{
  "name": "familyType",
  "displayName": "Family Type",
  "type": "String",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValues": [],
  "defaultValue": null,
  "overwrite": true,
  "tenant": null,
  "instanceApplicability" : {
    "arrayType": "NA",
    "overwrite": true
  }
}, {
  "name": "equipmentType",
  "displayName": "Equipment Type",
  "type": "String",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null,
  "overwrite": true,
  "instanceApplicability" : {
    "arrayType": "NA",
    "overwrite": true
  }
}, {
  "name": "make",
  "displayName": "Make",
  "type": "String",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null,
  "overwrite": true,
  "instanceApplicability" : {
    "arrayType": "NA",
    "overwrite": true
  }
}, {
  "name": "model",
  "displayName": "Model",
  "type": "String",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null,
  "overwrite": true,
  "instanceApplicability" : {
    "arrayType": "NA",
    "overwrite": true
  }
}, {
  "name": "series",
  "displayName": "Series",
  "type": "String",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null,
  "overwrite": true,
  "instanceApplicability" : {
    "arrayType": "NA",
    "overwrite": true
  }
}, {
  "name": "serialNumber",
  "displayName": "Serial Number",
  "type": "String",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null,
  "overwrite": true,
  "instanceApplicability" : {
    "arrayType": "NA",
    "overwrite": true
  }
}, {
  "name": "maintenanceCriticalityRiskScore",
  "displayName": "Maintenance Criticality Risk Score",
  "type": "Integer",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null,
  "overwrite": true,
  "instanceApplicability" : {
    "arrayType": "NA",
    "overwrite": true
  }
}, {
  "name": "faultMode",
  "displayName": "Fault Mode",
  "type": "String",
  "valueRegex": "NA",
  "arrayType" : "ONE_DIMENSIONAL",
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null,
  "overwrite": true,
  "instanceApplicability" : {
    "arrayType": "ONE_DIMENSIONAL",
    "overwrite": true
  }
}]', NULL, '2018-04-03 16:13:19.78741');
INSERT INTO reserved_attribute_metadata (id, type, config_json, updated_on, created_on) VALUES (1, 'assets', '[{
  "name": "state",
  "displayName": "State",
  "type": "KeyValue",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValuesContext" : "asset-state",
  "permissionsContext": "asset_state_ui_edit",
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null,
  "overwrite": false
}, {
  "name": "status",
  "displayName": "Status",
  "type": "KeyValue",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValuesContext" : "asset-status",
  "permissionsContext": "asset_status_ui_edit",
  "overwrite": false,
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null
}]', NULL, '2018-04-03 16:13:19.78741');
INSERT INTO reserved_attribute_metadata (id, type, config_json, updated_on, created_on) VALUES (3, 'tags', '[{ "name": "status",
    "displayName": "Status",
    "type": "KeyValue",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValuesContext": "tag-status",
    "permissionsContext": "tag_status_ui_edit",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": false,
    "instanceApplicability" : null },
  {
    "name": "timeseriesLink",
    "displayName": "Timeseries Link",
    "type": "String",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : null
  },
  {
    "name": "shiOutlierLimitsLow",
    "displayName": "Sensor Health Index Outlier Limits Low",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : null
  },
  {
    "name": "shiOutlierLimitsHigh",
    "displayName": "Sensor Health Index Outlier Limits High",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : null
  },
  {
    "name": "sensorHealthIndex",
    "displayName": "Sensor Health Index",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : null
  },
  {
    "name": "sensorHealthStatus",
    "displayName": "Sensor Health Status",
    "type": "Boolean",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : null
  },
  {
    "name": "standardUom",
    "displayName": "Standard Unit Of Measure",
    "type": "UnitOfMeasure",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : null
  },
  {
    "name": "paintBrushingTestWeight",
    "displayName": "Paint Brushing Test Weight",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : null
  },
  {
    "name": "timeseriesDataSource",
    "displayName": "Timeseries Data Source Identifier",
    "type": "String",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : null
  }]', NULL, '2018-04-03 16:13:19.78741');
INSERT INTO reserved_attribute_metadata (id, type, config_json, updated_on, created_on) VALUES (7, 'enterprises', '[{
  "name": "state",
  "displayName": "State",
  "type": "KeyValue",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValuesContext" : "enterprise-state",
  "permissionsContext": "enterprise_state_ui_edit",
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null,
  "overwrite": false
}, {
  "name": "status",
  "displayName": "Status",
  "type": "KeyValue",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValuesContext" : "enterprise-status",
  "permissionsContext": "enterprise_status_ui_edit",
  "overwrite": false,
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null
}]', NULL, '2018-04-03 16:13:19.941748');
INSERT INTO reserved_attribute_metadata (id, type, config_json, updated_on, created_on) VALUES (8, 'sites', '[{
  "name": "state",
  "displayName": "State",
  "type": "KeyValue",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValuesContext" : "site-state",
  "permissionsContext": "site_state_ui_edit",
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null,
  "overwrite": false
}, {
  "name": "status",
  "displayName": "Status",
  "type": "KeyValue",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValuesContext" : "site-status",
  "permissionsContext": "site_status_ui_edit",
  "overwrite": false,
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null
}]', NULL, '2018-04-03 16:13:19.941748');
INSERT INTO reserved_attribute_metadata (id, type, config_json, updated_on, created_on) VALUES (9, 'segments', '[{
  "name": "state",
  "displayName": "State",
  "type": "KeyValue",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValuesContext" : "segment-state",
  "permissionsContext": "segment_state_ui_edit",
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null,
  "overwrite": false
}, {
  "name": "status",
  "displayName": "Status",
  "type": "KeyValue",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "possibleValuesContext" : "segment-status",
  "permissionsContext": "segment_status_ui_edit",
  "overwrite": false,
  "possibleValues": [],
  "defaultValue": null,
  "tenant": null
}]', NULL, '2018-04-03 16:13:19.941748');
INSERT INTO reserved_attribute_metadata (id, type, config_json, updated_on, created_on) VALUES (4, 'tagTypes', '[
  {
    "name": "uom",
    "displayName": "Source Unit Of Measure",
    "type": "UnitOfMeasure",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": false,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": false
    }
  },
  {
    "name": "dataType",
    "displayName": "Data Type",
    "type": "String",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": ["Double", "Float", "Long", "String"],
    "defaultValue": "String",
    "tenant": null,
    "overwrite": false,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": false
    }
  },
  {
    "name": "resolution",
    "displayName": "Resolution",
    "type": "String",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "shiLowThreshold",
    "displayName": "Sensor Health Index Low Threshold",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 0.0,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "shiHighThreshold",
    "displayName": "Sensor Health Index High Threshold",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 1.00,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "shiFlatLineNumber",
    "displayName": "Sensor Health Index Flat Line Number",
    "type": "Integer",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 720,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "shiFlatLineEpsilon",
    "displayName": "Sensor Health Index Flat Line Epsilon",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 0.00000001,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "badObservationPersistent",
    "displayName": "Bad Observation Persistent / Penalty Window",
    "type": "Integer",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 2880,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "falseAlarmProbability",
    "displayName": "False Alarm Probability",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 0.001,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "missedAlarmProbability",
    "displayName": "Missed Alarm Probability",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 0.001,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "sampleFailureMagnitudesMean",
    "displayName": "Sample Failure Magnitudes Mean",
    "type": "Integer",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 10,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "sampleFailureMagnitudesVariance",
    "displayName": "Sample Failure Magnitudes Variance",
    "type": "Integer",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 40,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "nullHypothesisVariance",
    "displayName": "Null Hypothesis Variance",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 0.0025,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "nanTestWeight",
    "displayName": "NaN Test Weight",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 1,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "outlierTestWeight",
    "displayName": "Outlier Test Weight",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 1,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "flatTestWeight",
    "displayName": "Flat Test Weight",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": 1,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "category",
    "displayName": "Category",
    "type": "String",
    "valueRegex": "NA",
    "arrayType": "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "maxOperatingValue",
    "displayName": "Maximum Operating Value",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "minOperatingValue",
    "displayName": "Minimum Operating Value",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "highestThresholdValue",
    "displayName": "Highest Threshold Value",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
  },
  {
    "name": "lowestThresholdValue",
    "displayName": "Lowest Threshold Value",
    "type": "Double",
    "valueRegex": "NA",
    "arrayType" : "NA",
    "possibleValues": [],
    "defaultValue": null,
    "tenant": null,
    "overwrite": true,
    "instanceApplicability" : {
      "arrayType": "NA",
      "overwrite": true
    }
}]', NULL, '2018-04-03 16:13:19.78741');
INSERT INTO reserved_attribute_metadata (id, type, config_json, updated_on, created_on) VALUES (10, 'networks', '[{
  "name": "status",
  "displayName": "Status",
  "type": "KeyValue",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "overwrite": true,
  "possibleValues": [
    {
      "key": "01",
      "value": "Active"
    },
    {
      "key": "02",
      "value": "Inactive"
    }
  ],
  "defaultValue":  {
    "key": "01",
    "value": "Active"
  },
  "tenant": null
}]', NULL, '2018-04-03 16:13:19.979017');
INSERT INTO reserved_attribute_metadata (id, type, config_json, updated_on, created_on) VALUES (11, 'edges', '[{
  "name": "status",
  "displayName": "Status",
  "type": "KeyValue",
  "valueRegex": "NA",
  "arrayType" : "NA",
  "overwrite": true,
  "possibleValues": [
    {
      "key": "01",
      "value": "Active"
    },
    {
      "key": "02",
      "value": "Inactive"
    }
  ],
  "defaultValue":  {
    "key": "01",
    "value": "Active"
  },
  "tenant": null
}]', NULL, '2018-04-03 16:13:19.979017');

DO $$
BEGIN
  IF EXISTS(
    SELECT schema_name from information_schema.schemata WHERE schema_name = 'apm_asset'
   )
  THEN
    INSERT INTO apm_alm.alm_context_config (tenant_id, context_id, value, description, created_on, updated_on)
    SELECT uuid(tenant_id), context_id, value, description, created_on, updated_on FROM apm_asset.alm_context_config
    WHERE tenant_id IS NOT NULL;

    INSERT INTO apm_alm.reserved_attribute_context_config (tenant_id, context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on)
    SELECT uuid(tenant_id), context_id, code, semantic_name, display_name, description, is_active, is_default, created_on, updated_on FROM apm_asset.reserved_attribute_context_config
    WHERE tenant_id IS NOT NULL;
  END IF;
END $$;