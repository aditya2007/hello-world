CREATE OR REPLACE FUNCTION apm_alm.disable_multiple_assets_in_same_parent()
  RETURNS TRIGGER AS
$BODY$
DECLARE
  assetId UUID;
BEGIN
  SELECT asset_id
  INTO assetId
  FROM apm_alm.network_node
  WHERE tenant_id = NEW.tenant_id AND id = NEW.network_node_id;
  IF EXISTS(SELECT 1
            FROM apm_alm.network_node nn
              JOIN apm_alm.network_hierarchy nh
                ON nn.tenant_id = nh.tenant_id AND nn.id = nh.network_node_id
            WHERE nh.parent_network_id = NEW.parent_network_id
                  AND nn.asset_id IN (assetId))
  THEN
    RAISE EXCEPTION 'Asset [%] is already added to this network', assetId;
  END IF;
  RETURN NEW;
END;
$BODY$
LANGUAGE plpgsql;

CREATE TRIGGER disable_multiple_assets_in_same_parent
BEFORE INSERT ON apm_alm.network_hierarchy
FOR EACH ROW EXECUTE PROCEDURE disable_multiple_assets_in_same_parent();