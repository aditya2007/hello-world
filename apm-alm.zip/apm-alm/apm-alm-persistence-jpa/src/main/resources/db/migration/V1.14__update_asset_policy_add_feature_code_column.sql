ALTER TABLE asset_user_policy
  ADD COLUMN feature_code TEXT REFERENCES asset_feature_metadata (feature_code) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE;

UPDATE asset_user_policy
SET feature_code = (SELECT feature_code
                    FROM asset_feature_metadata
                    WHERE id = feature_id);

ALTER TABLE asset_user_policy
  ALTER COLUMN feature_code SET NOT NULL,
  DROP CONSTRAINT IF EXISTS asset_policy_sub_id_type_feat,
  ADD CONSTRAINT asset_policy_sub_id_type_feat UNIQUE (subject_id, subject_type, feature_id, filter_criteria, tenant_id, feature_code);

UPDATE asset_feature_metadata
SET feature_code = 'VIEW_DECOMMISSIONED_ASSETS', name = 'View decommissioned assets',
  description    = 'Allows view/query of decommissioned assets', category = 'View Decommissioned Assets'
WHERE feature_code = 'RESTRICT_DECOMMISSIONED_ASSETS';


