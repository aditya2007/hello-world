ALTER TABLE placeholder_tag_type
   ADD COLUMN expressions jsonb;