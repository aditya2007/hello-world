CREATE OR REPLACE FUNCTION apm_alm.jsonb_merge(JSONB, JSONB)
RETURNS JSONB AS $$
WITH json_union AS (
    SELECT * FROM JSONB_EACH($1)
    UNION ALL
    SELECT * FROM JSONB_EACH($2)
) SELECT JSON_OBJECT_AGG(key, value)::JSONB
     FROM json_union
     WHERE key NOT IN (SELECT key FROM json_union WHERE value ='null');
$$ LANGUAGE SQL;

update apm_alm.asset_instance
set attributes = apm_alm.jsonb_merge(attributes,'{"reservedAttributes":
                             {"status":{"key":"03"},"state":{"key":"01"}}}')
where super_types->'ids' ?| array['edf150de-d869-3741-8141-6f4c7f80254e',  -- EnterpriseType
'c9fb733c-4c2e-3b43-9e01-47c9256af586',  -- SiteType
'8c8b780b-14e0-382a-aeea-16b18c312dfa']  -- SegmentType