CREATE INDEX asset_event_audit_status_idx
        ON apm_alm.asset_event(audit_pub_status);
CREATE INDEX asset_event_eventhub_status_idx
        ON apm_alm.asset_event(eventhub_pub_status);
CREATE INDEX asset_event_eventhub_job_start_idx
        ON apm_alm.asset_event(eventhub_job_start_date);
CREATE INDEX asset_event_audit_job_start_idx
        ON apm_alm.asset_event(audit_job_start_date);

ALTER TABLE apm_alm.asset_event
        SET (autovacuum_vacuum_scale_factor = 0.0);
ALTER TABLE apm_alm.asset_event
        SET (autovacuum_vacuum_threshold = 5000);
ALTER TABLE apm_alm.asset_event
        SET (autovacuum_analyze_scale_factor = 0.0);
ALTER TABLE apm_alm.asset_event
        SET (autovacuum_analyze_threshold = 5000);