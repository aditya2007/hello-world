CREATE INDEX placeholder_sourceKey_idx
  ON placeholder USING GIN (source_key gin_trgm_ops);
CREATE INDEX placeholder_lower_sourceKey_idx
  ON placeholder (lower(source_key));
CREATE INDEX placeholder_tnnt_templateid_ppn_idx
  ON placeholder (tenant_id, template_id, part_position_number);

ALTER TABLE asset_placeholder
  DROP CONSTRAINT asset_placeholder_asset_id_key;
