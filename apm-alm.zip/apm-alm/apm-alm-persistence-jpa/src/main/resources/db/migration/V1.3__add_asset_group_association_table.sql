CREATE TABLE asset_group_association (
  id        UUID UNIQUE PRIMARY KEY,
  group_id  UUID NOT NULL REFERENCES asset_group (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  object_id UUID NOT NULL REFERENCES asset_instance (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  tenant_id UUID NOT NULL,
  CONSTRAINT asset_group_association_uk UNIQUE (tenant_id, group_id, object_id)
);
CREATE INDEX asset_group_association_idx
  ON asset_group_association (tenant_id, group_id);
CREATE INDEX asset_group_association_idx1
  ON asset_group_association (tenant_id, object_id);