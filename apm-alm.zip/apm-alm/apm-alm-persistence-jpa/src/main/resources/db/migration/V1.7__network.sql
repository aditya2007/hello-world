ALTER TABLE asset_type
  DROP COLUMN label;
ALTER TABLE template
  DROP COLUMN label;
ALTER TABLE asset_instance
  DROP COLUMN label;
ALTER TABLE tag_instance
  DROP COLUMN label;
ALTER TABLE asset_group
  DROP COLUMN label;
ALTER TABLE placeholder
  DROP COLUMN label;
ALTER TABLE asset_instance
  ADD CONSTRAINT asset_instance_tnnt_id UNIQUE (tenant_id, id);

-- encodes either a network(contains node or network) or a node(contains only asset)
CREATE TABLE network_node (
  id                 UUID PRIMARY KEY,
  source_key         TEXT,
  name               TEXT,
  description        TEXT,
  tenant_id          UUID                                   NOT NULL,
  attributes         JSONB,
  asset_id           UUID REFERENCES asset_instance (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT network_node_tnnt_id UNIQUE (tenant_id, id),
  CONSTRAINT network_node_tnnt_sk UNIQUE (tenant_id, source_key),
  CONSTRAINT network_node_chk CHECK ((asset_id IS NULL AND source_key IS NOT NULL AND name IS NOT NULL) OR
                                     (asset_id IS NOT NULL AND source_key IS NULL AND name IS NULL AND
                                      description IS NULL AND attributes IS NULL))
);
CREATE INDEX network_node_lower_attr_idx
  ON network_node USING GIN ((lower(attributes :: TEXT) :: JSONB) jsonb_path_ops);
CREATE INDEX network_node_name_idx
  ON network_node USING GIN (name gin_trgm_ops);
CREATE INDEX network_node_sourcekey_idx
  ON network_node USING GIN (source_key gin_trgm_ops);
CREATE INDEX network_node_description_idx
  ON network_node USING GIN (description gin_trgm_ops);
CREATE INDEX network_node_lower_sourceKey_idx
  ON network_node (lower(source_key));


CREATE TABLE network_hierarchy (
  id                 UUID PRIMARY KEY,
  network_node_id         UUID                              NOT NULL REFERENCES network_node (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  parent_network_id          UUID                           NOT NULL REFERENCES network_node (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  tenant_id          UUID                                   NOT NULL,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT network_hierarchy_tnnt_id UNIQUE (tenant_id, id),
  CONSTRAINT network_hierarchy_ntwk_parent_chk CHECK (network_node_id <> parent_network_id),
  CONSTRAINT network_hierarchy_tnnt_ntwk_parent UNIQUE (tenant_id, network_node_id, parent_network_id),
  FOREIGN KEY (tenant_id, network_node_id) REFERENCES network_node (tenant_id, id) DEFERRABLE INITIALLY IMMEDIATE,
  FOREIGN KEY (tenant_id, parent_network_id) REFERENCES network_node (tenant_id, id) DEFERRABLE INITIALLY IMMEDIATE
);
CREATE INDEX network_hierarchy_tnnt_parent_idx
  ON network_hierarchy (tenant_id, parent_network_id);


CREATE TABLE edge (
  id                 UUID PRIMARY KEY,
  name               TEXT                                   NOT NULL,
  description        TEXT,
  tenant_id          UUID                                   NOT NULL,
  source             UUID                                   NOT NULL REFERENCES network_node (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  target             UUID                                   NOT NULL REFERENCES network_node (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  direction          TEXT                                   NOT NULL,
  attributes         JSONB,
  asset_id           UUID REFERENCES asset_instance (id) ON UPDATE NO ACTION ON DELETE CASCADE DEFERRABLE INITIALLY IMMEDIATE,
  created_by         TEXT,
  created_date       TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  last_modified_by   TEXT,
  last_modified_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  CONSTRAINT edge_tnnt_id UNIQUE (tenant_id, id),
  CONSTRAINT edge_tnnt_name_source_target UNIQUE (tenant_id, name, source, target),
  CONSTRAINT edge_source_target_chk CHECK (source <> target),
  FOREIGN KEY (tenant_id, source) REFERENCES network_node (tenant_id, id) DEFERRABLE INITIALLY IMMEDIATE,
  FOREIGN KEY (tenant_id, target) REFERENCES network_node (tenant_id, id) DEFERRABLE INITIALLY IMMEDIATE,
  FOREIGN KEY (tenant_id, asset_id) REFERENCES asset_instance (tenant_id, id) DEFERRABLE INITIALLY IMMEDIATE
);
CREATE INDEX edge_lower_attr_idx
  ON edge USING GIN ((lower(attributes :: TEXT) :: JSONB) jsonb_path_ops);
CREATE INDEX edge_name_idx
  ON edge USING GIN (name gin_trgm_ops);
CREATE INDEX edge_description_idx
  ON edge USING GIN (description gin_trgm_ops);
CREATE INDEX edge_tnnt_source_idx
  ON edge (tenant_id, source, direction);
CREATE INDEX edge_tnnt_target_idx
  ON edge (tenant_id, target, direction);
CREATE INDEX edge_tnnt_asset_idx
  ON edge (tenant_id, asset_id);
