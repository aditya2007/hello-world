ALTER TABLE asset_event
  add column pre_modified_object JSONB,
  add column modified_object JSONB,
  add column predix_pub_status TEXT,
  add column eventhub_pub_status TEXT,
  add column audit_pub_status TEXT,
  add column eventhub_job_start_date TIMESTAMP WITH TIME ZONE,
  add column audit_job_start_date TIMESTAMP WITH TIME ZONE;

  UPDATE asset_event set predix_pub_status = 'QUEUED',
                         audit_pub_status = 'COMPLETED',
                         eventhub_pub_status = 'COMPLETED';