ALTER TABLE asset_type
  DROP COLUMN IF EXISTS super_types;
ALTER TABLE asset_instance
  DROP COLUMN IF EXISTS super_types;
ALTER TABLE asset_instance
  DROP COLUMN IF EXISTS ancestors;
ALTER TABLE tag_instance
  DROP COLUMN IF EXISTS super_types;