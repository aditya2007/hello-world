update apm_alm.asset_instance
set attributes = apm_alm.jsonb_merge(attributes,'{"reservedAttributes":
                             {"status":{"key":"03"},"state":{"key":"06"}}}')
where super_types->'ids' ?| array['edf150de-d869-3741-8141-6f4c7f80254e',  -- EnterpriseType
'c9fb733c-4c2e-3b43-9e01-47c9256af586',  -- SiteType
'8c8b780b-14e0-382a-aeea-16b18c312dfa']  -- SegmentType