/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.io.IOException;
import java.util.Map;

import org.assertj.core.util.Maps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.TEST_TENANT;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUber;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUnPrivileged;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests asset searches using {@link com.ge.apm.alm.model.query.AssetPredicate}, with emphasis
 * on query by attributes.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetSearchByReservedAttributesTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;
    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Test
    @Transactional
    public void reservedAttributeExists() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test boolean", null)).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void reservedArrayAttributeExists() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test boolean array", null)).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void reservedBooleanAttributeEquals() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test boolean", "true")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test boolean", "false"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void reservedBooleanArrayAttributeEquals() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        for (String value : new String[]{"true", "false"}) {
            AssetPredicate predicate =
                AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test boolean array", value)).build();
            assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
            assertThat(assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
                .extracting(Asset::getName)
                .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
            assertThat(assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        }
    }

    @Test
    @Transactional
    public void reservedNumberAttributeEquals() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder()
            .reservedAttributes(Maps.newHashMap("test number", String.valueOf(Integer.MIN_VALUE))).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test number", "123"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void reservedNumberArrayAttributeEquals() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder()
            .reservedAttributes(Maps.newHashMap("test number array", String.valueOf(Integer.MIN_VALUE))).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test number", "123"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void reservedNumberAttributeLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test number", "922*")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void reservedNumberArrayAttributeLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test number array", "922*")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void reservedStringAttributeEquals() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test string", "abc")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test string", "@@@@@"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void reservedStringMultiLevelAttributeEquals() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test multi,key", "06")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test multi,key", "@@@@@"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void reservedStringMultiLevel2AttributeEquals() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test multi2,key", "-12.345")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test multi,key", "@@@@@"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void reservedStringArrayAttributeEquals() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test string array", "abc")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test string", "@@@@@"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void reservedStringAttributeLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test string", "*bc*")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test string", "*xyz*"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void reservedStringAttributeLeftLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test string", "*bc")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test string", "*yz"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void reservedStringAttributeRightLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test string", "ab*")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test string", "xy*"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void reservedStringArrayAttributeLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test string array", "*bc*")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test string", "*xyz*"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void reservedStringArrayAttributeLeftLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test string array", "*bc")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test string", "*yz"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void reservedStringArrayAttributeRightLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test string array", "ab*")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test string", "xy*"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void reservedStringArrayAttributeLike2() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().reservedAttributes(Maps.newHashMap("test string array", "*bc\", \"jk*")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName)
            .containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate)).hasSize(0);
        predicate.setReservedAttributes(Maps.newHashMap("test string array", "*abcjkl*"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(
            assetPersistencyService
                .getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    Map<String, BaseDataModel> setupData() throws IOException {
        return PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService, assetPersistencyService);
    }
}
