/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.config;

import java.util.Iterator;

import com.fasterxml.jackson.databind.JsonNode;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.ReservedAttributeMetadata;
import com.ge.apm.alm.persistence.ReservedAttributeService;
import com.ge.apm.alm.persistence.jpa.TestApp;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class ReservedAttributePersistSvcTests {

    @Autowired
    private ReservedAttributeService reservedAttributeService;

    @Test
    @Transactional
    public void testFindByType_ExistingType() {
        ReservedAttributeMetadata metadata = reservedAttributeService.findByType("sites");
        Assert.assertNotNull(metadata);
        Assert.assertEquals("sites", metadata.getType());
        String[] attributeNames = new String[]{"state", "status"};
        int index = 0;
        Iterator<JsonNode> it = metadata.getConfigJson().iterator();
        while(it.hasNext()) {
            JsonNode node = it.next();
            Assert.assertNotNull(node);
            Assert.assertEquals(attributeNames[index], node.get("name").asText());
            index++;
        }
        Assert.assertEquals(2, index);
    }

    @Test
    @Transactional
    public void testFindByType_NonExistingType() {
        ReservedAttributeMetadata metadata = reservedAttributeService.findByType("stessa");
        Assert.assertNull(metadata);
    }
}
