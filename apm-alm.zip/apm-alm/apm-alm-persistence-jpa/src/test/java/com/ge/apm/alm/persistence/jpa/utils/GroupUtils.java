/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroupItem;
import com.ge.apm.alm.persistence.jpa.model.TestTag;

import static org.assertj.core.api.Assertions.assertThat;

public final class GroupUtils {

    private GroupUtils() {
    }

    public static AssetGroup createAssetGroup(String name, AssetGroupCategory category) {
        return TestAssetGroup.builder().id(UUID.randomUUID().toString()).sourceKey(name).name(name).description(name)
            .createdBy("Test").lastModifiedBy("test").category(category).tenantId(TenantTestUtils.getTenantId()).build();
    }

    public static TestAssetGroupItem createAssetGroupItem(String groupId, String assetInstanceId) {
        return TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).groupId(groupId).objectId(assetInstanceId)
            .tenantId(TenantTestUtils.getTenantId()).build();
    }

    /**
     * Creating the following type and instance hierarchy
     * ROOT_ENTERPRISE_TYPE <- MyEnterpriseType (*)
     *                         MyEnterpriseType2 <- MyEnterpriseType2SubType
     *                         MyEnterpriseType3
     *
     * ROOT_SITE_TYPE       <- MySiteType (@)
     * ROOT_SEGEMENT_TYPE   <- MySegmentType (%)
     * ROOT_ASSET_TYPE      <- MyAssetType (#)
     * ROOT_TAG_TYPE        <- MyTagType
     *
     * E2 (*) <- E2_Asset1 (#) <- E2_Asset1_Tag1
     * E1 (*) <- E1_S1 (@) <- E1_S1_Seg1 (%) <- E1_S1_Seg1_Asset1 (#) <- E1_S1_Seg1_Asset1_Tag1
     *                                          E1_S1_Seg1_Asset2 (#) <- E1_S1_Seg1_Asset2_Tag1
     */
    public static Map<String, BaseDataModel> setupData(AssetTypePersistencyService assetTypePersistencyService,
        AssetPersistencyService assetPersistencyService, TagPersistencyService tagPersistencyService)
        throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> assetData =
            AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);

        BaseDataModel tagType = assetData.get("MyTagType");

        String name = "E1_S1_Seg1_Asset1_Tag1";
        Tag tag1 = TestTag.builder().
            id(UUID.randomUUID().toString()).tenantId(TenantTestUtils.getTenantId())
            .assetId(assetData.get("E1_S1_Seg1_Asset1").getId())
            .name(name).sourceKey(name).description(name)
            .tagType(tagType.getId()).tagCategory("SENSOR")
            .build();
        name = "E1_S1_Seg1_Asset2_Tag1";
        Tag tag2 = TestTag.builder().
            id(UUID.randomUUID().toString()).tenantId(TenantTestUtils.getTenantId())
            .assetId(assetData.get("E1_S1_Seg1_Asset2").getId())
            .name(name).sourceKey(name).description(name)
            .tagType(tagType.getId()).tagCategory("SENSOR")
            .build();

        name = "E2_Asset1_Tag1";
        Tag tag3 = TestTag.builder().
            id(UUID.randomUUID().toString()).tenantId(TenantTestUtils.getTenantId()).assetId(assetData.get("E2_Asset1").getId())
            .name(name).sourceKey(name)
            .description(name).tagType(tagType.getId()).tagCategory("SENSOR")
            .build();

        assetData.put("E1_S1_Seg1_Asset1_Tag1", tag1);
        assetData.put("E1_S1_Seg1_Asset2_Tag1", tag2);
        assetData.put("E2_Asset1_Tag1", tag3);

        List<Tag> tags = new ArrayList<>();
        tags.add(tag1);
        tags.add(tag2);
        tags.add(tag3);
        assertThat(tagPersistencyService.createTags(TenantTestUtils.getTenantId(), TestUtils.getUber(), tags)).isEqualTo(3);
        return assetData;
    }
}
