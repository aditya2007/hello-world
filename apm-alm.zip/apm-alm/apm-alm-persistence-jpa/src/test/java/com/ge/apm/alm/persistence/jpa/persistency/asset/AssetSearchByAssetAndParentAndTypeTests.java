/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.Sets;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_ASSET_TYPE_ID;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUnPrivileged;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests asset searches using {@link com.ge.apm.alm.model.query.AssetPredicate}, with {@link
 * com.ge.apm.alm.model.query.TypePredicate} and {@link com.ge.apm.alm.model.query.ParentPredicate} either separately or
 * in combination.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetSearchByAssetAndParentAndTypeTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    ////////////////////////////////////////////////////////////////////////////////////////////
    // AssetPredicate tests with AND/OR combinations of name, sourceKey, description
    ////////////////////////////////////////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////////////////////////////////////////
    // tests with AND/OR combinations of name, sourceKey, description, with parent and type criteria
    /////////////////////////////////////////////////////////////////////////////////////////////////

    @After
    public void tearDown() {
        TestUtils.destroyAssetUserPolicies();
    }

    /**
     * (name like "*_A*" or name like "*_B*") and (parent name = "E1_S1_Seg1 or parent name like "E1_S2_Seg4") and (type
     * name = "AssetAType")
     */
    @Test
    @Transactional
    public void nameOrName_and_parentOrParent_and_typeA() throws IOException {
        Map<String, BaseDataModel> data = setupData();

        AssetPredicate nameLikeA_or_nameLikeB = AssetPredicate.builder().childPredicates(
            Arrays.asList(AssetPredicate.builder().name("*_A*").peerOperand(Operand.OR).build(),
                AssetPredicate.builder().name("*_B*").build())).peerOperand(Operand.AND).build();
        AssetPredicate parentSeg1_or_Seg4 = AssetPredicate.builder().childPredicates(
            Arrays.asList(AssetPredicate.builder().parent(ParentPredicate.builder().name("E1_S1_Seg1").build())
                    .peerOperand(Operand.OR).build(),
                AssetPredicate.builder().parent(ParentPredicate.builder().name("E1_S2_Seg4").build()).build()))
            .peerOperand(Operand.AND).build();
        AssetPredicate typeA = AssetPredicate.builder().childPredicates(Collections
            .singletonList(AssetPredicate.builder().type(TypePredicate.builder().name("AssetAType").build()).build()))
            .build();

        AssetPredicate predicate = AssetPredicate.builder().childPredicates(
            Arrays.asList(nameLikeA_or_nameLikeB, parentSeg1_or_Seg4, typeA)).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(2).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S2_Seg4_A4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1"), data.get("E1_S2")),
                predicate)).hasSize(2).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S2_Seg4_A4");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);

        typeA.getChildPredicates().get(0).setName("NonExistingAssetType");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1"), data.get("E1_S2")),
                predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Just a second way of construction the predicates for
     * <p>
     * (name like '%_A%' or description like '%_B%') and (parent name = 'E1_S1_Seg1' or parent name = 'E1_S2_Seg4') and
     * (type name = 'AssetAType')
     */
    @Test
    @Transactional
    public void nameOrDescription_and_parentName_and_typeA() throws IOException {
        Map<String, BaseDataModel> data = setupData();

        AssetPredicate nameLikeA_or_descriptionLikeB = AssetPredicate.builder().childPredicates(
            Arrays.asList(AssetPredicate.builder().name("*_A*").peerOperand(Operand.OR).build(),
                AssetPredicate.builder().description("*_B*").build())).peerOperand(Operand.AND).build();
        AssetPredicate parentSeg1_or_Seg4 = AssetPredicate.builder().childPredicates(
            Arrays.asList(AssetPredicate.builder().parent(ParentPredicate.builder().name("E1_S1_Seg1").build())
                    .peerOperand(Operand.OR).build(),
                AssetPredicate.builder().parent(ParentPredicate.builder().name("E1_S2_Seg4").build()).build()))
            .peerOperand(Operand.AND).build();
        AssetPredicate typeA = AssetPredicate.builder().childPredicates(Collections
            .singletonList(AssetPredicate.builder().type(TypePredicate.builder().name("AssetAType").build()).build()))
            .build();

        AssetPredicate predicate = AssetPredicate.builder().childPredicates(
            Arrays.asList(nameLikeA_or_descriptionLikeB, parentSeg1_or_Seg4, typeA)).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(2).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S2_Seg4_A4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1"), data.get("E1_S2")),
                predicate)).hasSize(2).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S2_Seg4_A4");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);

        typeA.getChildPredicates().get(0).setName("NonExistingAssetType");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1"), data.get("E1_S2")),
                predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Just a third way of construction the predicates for
     * <p>
     * (name like '%_A%' or description like '%_B%') and (parent name = 'E1_S1_Seg1' or parent name = 'E1_S2_Seg4') and
     * (type name = 'AssetAType')
     */
    @Test
    @Transactional
    public void nameOrDescription_and_parentName_and_typeA_2() throws IOException {
        Map<String, BaseDataModel> data = setupData();

        AssetPredicate predicate = AssetPredicate.builder().parent(ParentPredicate.builder().name("*_S1_Seg1").build())
            .type(TypePredicate.builder().name("AssetAType").build()).childOperand(Operand.AND).childPredicates(
                Arrays.asList(AssetPredicate.builder().name("*_A*").peerOperand(Operand.OR).build(),
                    AssetPredicate.builder().description("*_A4").build())).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(1).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1"), data.get("E1_S2")),
                predicate)).hasSize(1).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Just a fourth way of construction the predicates for
     * <p>
     * (name like '%_A%' or description like '%_B%') and (parent name = 'E1_S1_Seg1' or parent name = 'E1_S2_Seg4') and
     * (type name = 'AssetAType')
     */
    @Test
    @Transactional
    public void nameOrDescription_and_parentName_and_typeA_3() throws IOException {
        Map<String, BaseDataModel> data = setupData();

        AssetPredicate predicate = AssetPredicate.builder().parent(ParentPredicate.builder().name("*_S1_Seg1").build())
            .type(TypePredicate.builder().parent(ParentPredicate.builder().ids(Sets.newHashSet(ROOT_ASSET_TYPE_ID))
                .deepSearch(true).build()).build()).childOperand(Operand.AND).childPredicates(Arrays.asList(
                // the childOperand here will be ignored since the asset predicate does not itself generate
                // any boolean expressions to be joined with the children
                AssetPredicate.builder().childOperand(Operand.AND).childPredicates(
                    Arrays.asList(AssetPredicate.builder().name("*_A*").peerOperand(Operand.OR).build(),
                        AssetPredicate.builder().description("*_A4").build())).peerOperand(Operand.AND).build(),
                // the childOperand here will be ignored since the asset predicate does not itself generate
                // any boolean expressions to be joined with the children
                AssetPredicate.builder().childOperand(Operand.AND)
                    .childPredicates(Arrays.asList(AssetPredicate.builder().parent(
                        ParentPredicate.builder().name("*_S1_Seg1").build()).peerOperand(Operand.AND).build(),
                        AssetPredicate.builder().type(TypePredicate.builder().name("AssetAType").build()).build()))
                    .build())).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(1).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1"), data.get("E1_S2")),
                predicate)).hasSize(1).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void nameOrDescription_and_parentName_and_typeA_Decommissioned()
        throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = setupData();

        Asset e1S1Seg1A1 = (Asset) data.get("E1_S1_Seg1_A1");
        ((ObjectNode) ((Asset) data.get("E1_S1_Seg2_A2")).getAttributes().path("reservedAttributes").path("state")).put(
            "key", "1010");
        ((ObjectNode) ((Asset) data.get("E1_S1_Seg3_A3")).getAttributes().path("reservedAttributes").path("state")).put(
            "key", "1010");
        ((ObjectNode) ((Asset) data.get("E1_S2_Seg4_A4")).getAttributes().path("reservedAttributes").path("state")).put(
            "key", "1010");
        ((ObjectNode) e1S1Seg1A1.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(),
            ((Asset) data.get("E1_S1_Seg2_A2")));
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(),
            ((Asset) data.get("E1_S1_Seg3_A3")));
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(),
            ((Asset) data.get("E1_S2_Seg4_A4")));
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), e1S1Seg1A1);

        AssetPredicate predicate = AssetPredicate.builder().parent(ParentPredicate.builder().name("*_S*_Seg*").build())
            .type(TypePredicate.builder().parent(ParentPredicate.builder().ids(Sets.newHashSet(ROOT_ASSET_TYPE_ID))
                .deepSearch(true).build()).build()).childOperand(Operand.AND).childPredicates(Arrays.asList(
                // the childOperand here will be ignored since the asset predicate does not itself generate
                // any boolean expressions to be joined with the children
                AssetPredicate.builder().childOperand(Operand.AND).childPredicates(
                    Arrays.asList(AssetPredicate.builder().name("*_A*").peerOperand(Operand.OR).build(),
                        AssetPredicate.builder().description("*_A4").build())).peerOperand(Operand.AND).build(),
                // the childOperand here will be ignored since the asset predicate does not itself generate
                // any boolean expressions to be joined with the children
                AssetPredicate.builder().childOperand(Operand.AND)
                    .childPredicates(Arrays.asList(AssetPredicate.builder().parent(
                        ParentPredicate.builder().name("*_S*_Seg*").build()).peerOperand(Operand.AND).build(),
                        AssetPredicate.builder().type(TypePredicate.builder().name("AssetAType").build()).build()))
                    .build())).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg2_A2", "E1_S1_Seg3_A3", "E1_S2_Seg4_A4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1_S1").getId(), data.get("E1_S2").getId()),
                predicate)).hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg2_A2", "E1_S1_Seg3_A3",
            "E1_S2_Seg4_A4");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    Map<String, BaseDataModel> setupData() throws IOException {
        return PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService, assetPersistencyService);
    }
}
