/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.alm.persistence.jpa.SpringApplicationContext;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.repository.TemplateNotesRepository;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class SpringApplicationContextTests {

    @Test
    public void testGetBeanByClass() {
        TemplateNotesRepository repository = SpringApplicationContext.getBeanByClass(TemplateNotesRepository.class);
        assertThat(repository).isNotNull();
    }

    @Test
    public void testGetBeanByName() {
        TemplateNotesRepository repository = SpringApplicationContext.getBeanByName("templateNotesRepository");
        assertThat(repository).isNotNull();
    }
}
