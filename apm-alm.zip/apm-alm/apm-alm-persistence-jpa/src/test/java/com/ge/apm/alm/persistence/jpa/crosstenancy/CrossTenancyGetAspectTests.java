/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.crosstenancy;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_ASSET_TYPE_ID;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.assertj.core.util.Maps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.Sort;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TenantTestUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;
import com.ge.apm.alm.persistence.mirror.MirrorTestUtils;
import com.ge.apm.common.support.RequestContext;

/**
 * @author Shu W. Yu 212614203
 * @version 1.0 Apr 06, 2018
 * @since 1.0
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class CrossTenancyGetAspectTests {

    private final String[] tenantIds = new String[]{
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
    };

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;
    @Autowired
    private AssetPersistencyService assetPersistencyService;
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Test
    public void listAssetTest() throws IOException {
        try {
            MirrorTestUtils.setEventCreationEnabled(false);
            Map<String, BaseDataModel> tenantData = setupData(tenantIds[0]);
            Map<String, BaseDataModel> tenant1Data = setupData(tenantIds[1]);
            List<Asset> assetsOrderedById = mergeAssetsOrderById(tenantData.values(), tenant1Data.values());

            verifyListAssetAndPaging(assetsOrderedById);

            verifyPagingNextWithSortKey(assetsOrderedById);
            verifyPagingNextWithTwoSortKeys(assetsOrderedById);

            verifyComponentLoadingHappened(assetsOrderedById);

            verifyAccessibleResources(tenant1Data);
        } finally {
            clearData();
            MirrorTestUtils.setEventCreationEnabled(true);
        }
    }

    private void verifyAccessibleResources(Map<String, BaseDataModel> tenant1Data) {
        AssetPredicate predicate = AssetPredicate.builder()
            .attributeSelectEnum(AttributeSelectEnum.FULL_WITHOUT_ATTRIBUTES)
            .pageSize(251)
            .build();
        predicate.setComponents(EnumSet.of(AssetComponent.PARENT));
        predicate.setIgnoreComponentAcl(true);

        String[] star = new String[]{"*"};
        RequestContext.put(CrossTenancyCall.ALL_ACCESSIBLE_RESOURCES, Maps.newHashMap(
            tenantIds[1].replace("-", ""),
            new String[] {"/assets/" + tenant1Data.get("E1_S1_Seg1").getId()}));
        RequestContext.put(CrossTenancyCall.ACCESSIBLE_RESOURCES, star);
        RequestContext.put(RequestContext.TENANT_UUID, tenantIds[0].replace("-", ""));

        List<Asset> assetsFound = assetPersistencyService.getAccessibleResources(tenantIds[0], null, predicate);
        assertThat(assetsFound).hasSize(2);
        Asset homeAsset = assetsFound.get(0).getTenantId().equals(tenantIds[0]) ? assetsFound.get(0) : assetsFound
            .get(1);
        assertThat(homeAsset.getName()).isEqualTo("E1");
        assertThat(homeAsset.getParentId()).isNull();
        assertThat(homeAsset.getParent()).isNull();

        Asset foreignAsset = assetsFound.get(0).getTenantId().equals(tenantIds[0]) ? assetsFound.get(1) : assetsFound
            .get(0);
        assertThat(foreignAsset.getName()).isEqualTo("E1_S1_Seg1");
        assertThat(foreignAsset.getParentId()).isNotNull();
        assertThat(foreignAsset.getParent()).isNotNull();
        assertThat(foreignAsset.getParent().getParentId()).isNotNull();
        assertThat(foreignAsset.getParent().getParent()).isNotNull();
    }

    private void verifyListAssetAndPaging(List<Asset> assetsOrderedById) {
        List<String> orderedIds = assetsOrderedById.stream().map(Asset::getId).collect(Collectors.toList());

        AssetPredicate predicate = AssetPredicate.builder().type(
            TypePredicate.builder().ids(Collections.singleton(ROOT_ASSET_TYPE_ID)).deepSearch(true).build())
            .attributeSelectEnum(AttributeSelectEnum.FULL).build();
        RequestContext.put(RequestContext.TENANT_UUID, tenantIds[0]);
        List<Asset> assetsFound = assetPersistencyService.getAssets(tenantIds[0], TestUtils.getUber(), predicate);
        assertThat(assetsFound.size()).isEqualTo(orderedIds.size() / 2);

        setupCrossTenants();
        assetsFound = assetPersistencyService.getAssets(tenantIds[0], TestUtils.getUber(), predicate);
        assertThat(orderedIds)
            .containsExactlyElementsOf(assetsFound.stream().map(Asset::getId).collect(Collectors.toList()));

        int pageSize = 2;
        int offset = 0;
        predicate.setPageSize(pageSize);
        predicate.setAttributeSelectEnum(AttributeSelectEnum.FULL_WITHOUT_ATTRIBUTES);
        while (offset < orderedIds.size()) {
            predicate.setOffset(offset);
            assetsFound = assetPersistencyService.getAssets(tenantIds[0], TestUtils.getUber(), predicate);
            assertThat(assetsFound).hasSize(pageSize);
            assertThat(orderedIds.subList(offset, offset + pageSize)).containsExactlyElementsOf(assetsFound.stream()
                .map(Asset::getId).collect(Collectors.toList()));

            offset += pageSize;
        }
        predicate.setOffset(offset);
        assetsFound = assetPersistencyService.getAssets(tenantIds[0], TestUtils.getUber(), predicate);
        assertThat(assetsFound).isEmpty();

        String tenant2RandomAcl = "/assets/" + UUID.randomUUID().toString();
        RequestContext.put(CrossTenancyCall.ALL_ACCESSIBLE_RESOURCES, Maps.newHashMap(
            tenantIds[1], new String[]{tenant2RandomAcl}));
        predicate.setPageSize(orderedIds.size());
        predicate.setOffset(0);
        assetsFound = assetPersistencyService.getAssets(tenantIds[0], TestUtils.getUber(), predicate);
        assertThat(assetsFound).hasSize(orderedIds.size() / 2);

        clearCrossTenants();
    }

    private void verifyPagingNextWithSortKey(List<Asset> assetsOrderedById) {
        AssetPredicate predicate = AssetPredicate.builder().type(
            TypePredicate.builder().ids(Collections.singleton(ROOT_ASSET_TYPE_ID)).deepSearch(true).build())
            .attributeSelectEnum(AttributeSelectEnum.FULL).build();

        verifyPagingNextWithSortKeys(assetsOrderedById, 1, predicate);
    }

    private void verifyPagingNextWithTwoSortKeys(List<Asset> assetsOrderedById) {
        List<Asset> byNameAndId = assetsOrderedById.stream()
            .sorted(Comparator.comparing(Asset::getName).thenComparing(Comparator.comparing(Asset::getId)))
            .collect(Collectors.toList());

        AssetPredicate predicate = AssetPredicate.builder().type(
            TypePredicate.builder().ids(Collections.singleton(ROOT_ASSET_TYPE_ID)).deepSearch(true).build())
            .attributeSelectEnum(AttributeSelectEnum.FULL).build();
        predicate.setSorts(Arrays.asList(new Sort("name", true), new Sort("id", true)));

        verifyPagingNextWithSortKeys(byNameAndId, 2, predicate);
    }

    private void verifyPagingNextWithSortKeys(List<Asset> orderedAssets, int numSorts, AssetPredicate predicate) {
        List<String> orderedIds = orderedAssets.stream().map(Asset::getId).collect(Collectors.toList());

        List<Asset> assetsFound = assetPersistencyService.getAssets(tenantIds[0], null, predicate);
        assertThat(assetsFound.size()).isEqualTo(orderedIds.size() / 2);

        setupCrossTenants();
        predicate.setPagingInfo(0, orderedIds.size(), null, true);
        assetsFound = assetPersistencyService.getAssets(tenantIds[0], null, predicate);
        assertThat(orderedIds)
            .containsExactlyElementsOf(assetsFound.stream().map(Asset::getId).collect(Collectors.toList()));

        int pageSize = 2;
        predicate.setPagingInfo(0, pageSize, null, true);
        assetsFound = assetPersistencyService.getAssets(tenantIds[0], null, predicate);
        assertThat(assetsFound).hasSize(pageSize);
        assertThat(orderedIds.subList(0, pageSize)).containsExactlyElementsOf(assetsFound.stream()
            .map(Asset::getId).collect(Collectors.toList()));
        String sortKey = QueryUtils.getNextPageSortKey(predicate, orderedAssets.get(pageSize - 1));

        predicate.setPageSize(pageSize);
        predicate.setAttributeSelectEnum(AttributeSelectEnum.FULL_WITHOUT_ATTRIBUTES);
        int offset = pageSize;
        while (offset < orderedIds.size()) {
            predicate.setPagingInfo(0, pageSize, sortKey, true);
            assertThat(predicate.getNextPageSortValues()).hasSize(numSorts);
            assetsFound = assetPersistencyService.getAssets(tenantIds[0], null, predicate);
            assertThat(assetsFound).hasSize(pageSize);
            assertThat(orderedIds.subList(offset, offset + pageSize)).containsExactlyElementsOf(assetsFound.stream()
                .map(Asset::getId).collect(Collectors.toList()));

            offset += pageSize;
            sortKey = QueryUtils.getNextPageSortKey(predicate, orderedAssets.get(offset - 1));
        }
        predicate.setPagingInfo(0, pageSize, sortKey, true);
        assetsFound = assetPersistencyService.getAssets(tenantIds[0], null, predicate);
        assertThat(assetsFound).isEmpty();

        predicate.setPagingInfo(0, pageSize, null, true);
        assetsFound = assetPersistencyService.getAssets(tenantIds[0], null, predicate);
        assertThat(orderedIds.subList(0, pageSize)).containsExactlyElementsOf(assetsFound.stream()
            .map(Asset::getId).collect(Collectors.toList()));
        clearCrossTenants();
    }

    private void verifyComponentLoadingHappened(List<Asset> assetsOrderedById) {
        setupCrossTenants();

        int pageSize = assetsOrderedById.size() - 1;
        AssetPredicate predicate = AssetPredicate.builder().type(
            TypePredicate.builder().ids(Collections.singleton(ROOT_ASSET_TYPE_ID)).deepSearch(true).build())
            .pageSize(pageSize).attributeSelectEnum(AttributeSelectEnum.FULL).build();
        predicate.setComponents(EnumSet.of(AssetComponent.PARENT));

        List<Asset> assetsFound = assetPersistencyService.getAssets(tenantIds[0], null, predicate);
        List<String> orderedIds = assetsOrderedById.stream().map(Asset::getId).collect(Collectors.toList());
        assertThat(orderedIds.subList(0, pageSize)).containsExactlyElementsOf(assetsFound.stream()
            .map(Asset::getId).collect(Collectors.toList()));

        for (int i = 0; i < pageSize; i++) {
            Asset expected = assetsOrderedById.get(i);
            Asset found = assetsFound.get(i);
            if (expected.getParentId() == null) {
                assertThat(found.getParent()).isNull();
            } else {
                Asset parent = found.getParent();
                assertThat(parent).isNotNull();
                assertThat(parent.getId()).isEqualTo(expected.getParentId());
            }
        }

        clearCrossTenants();
    }

    private void setupCrossTenants() {
        String[] star = new String[]{"*"};
        RequestContext.put(CrossTenancyCall.ALL_ACCESSIBLE_RESOURCES, Maps.newHashMap(
            tenantIds[1].replace("-", ""), star));
        RequestContext.put(CrossTenancyCall.ACCESSIBLE_RESOURCES, star);
        RequestContext.put(RequestContext.TENANT_UUID, tenantIds[0].replace("-", ""));
    }

    private void clearCrossTenants() {
        RequestContext.remove(CrossTenancyCall.ALL_ACCESSIBLE_RESOURCES);
        RequestContext.remove(CrossTenancyCall.ACCESSIBLE_RESOURCES);
        RequestContext.remove(RequestContext.TENANT_UUID);
    }

    private Map<String, BaseDataModel> setupData(String tenantId) throws IOException {
        String oldTenantId = TenantTestUtils.setTenantId(tenantId);
        try {
            return PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService, assetPersistencyService);
        } finally {
            TenantTestUtils.setTenantId(oldTenantId);
        }
    }

    @SafeVarargs
    private final List<Asset> mergeAssetsOrderById(Collection<BaseDataModel>... tenantData) {

        List<Asset> assets = new ArrayList<>();
        for (Collection<BaseDataModel> aTenantData : tenantData) {
            aTenantData.forEach(model -> addAsset(model, assets));
        }

        return assets.stream().sorted(Comparator.comparing(BaseDataModel::getId)).collect(Collectors.toList());
    }

    private void addAsset(BaseDataModel model, List<Asset> targets) {
        if (model instanceof Asset) {
            Asset asset = (Asset) model;
            if (asset.getCoreAssetTypeName().equals(OOTBCoreTypesIdLookup.AssetType.name())) {
                targets.add(asset);
            }
        }
    }

    private void clearData() {
        clearCrossTenants();
        for (String tenantId : tenantIds) {
            jdbcTemplate.update("DELETE FROM apm_alm.asset_instance WHERE tenant_id=?", tenantId);
            jdbcTemplate.update("DELETE FROM apm_alm.asset_type WHERE tenant_id=?", tenantId);
        }
    }
}
