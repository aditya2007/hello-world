/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.sql;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.persistence.jpa.TestApp;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests {@link com.ge.apm.alm.persistence.jpa.sql.QueryUtils}
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class QueryUtilsTests {

    @Test
    public void flattenExpressions() {
        assertThat(QueryUtils.flattenExpressions(Arrays.asList("A", "B", "C"), Operand.AND))
            .isEqualTo("(A and B and C)");
        assertThat(QueryUtils.flattenExpressions(Arrays.asList("A", "B", "C"), Operand.OR))
            .isEqualTo("(A or B or C)");
    }
}
