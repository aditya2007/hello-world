/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.groupassociation;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupAssociation;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.persistence.AssetGroupAssociationPersistencyService;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroupItem;
import com.ge.apm.alm.persistence.jpa.utils.AssetGroupAssociationUtils;
import com.ge.apm.alm.persistence.jpa.utils.GroupUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

/**
 * Created by 212576241 on 7/9/17.
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetGroupAssociationSvcTests {

    @Autowired
    private AssetGroupAssociationPersistencyService assetGroupAssociationPersistencyService;

    @Autowired
    private GroupPersistencyService groupPersistencyService;

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    @After
    public void tearDown() {
        TestUtils.destroyAssetUserPolicies();
    }

    @Test
    @Transactional
    public void negativeTestCasesDelete() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");

        TestAssetGroupItem a1_item1 = GroupUtils.createAssetGroupItem(assetGroupCr.getId(), assetInstance.getId());
        groupPersistencyService.createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupCr.getId(),
            Arrays.asList(a1_item1));

        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        try {
            AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(null,
                null);
            assetGroupAssociationPersistencyService.deleteAssetGroupAssociations(TestUtils.TEST_TENANT,
                TestUtils.getUber(), assetGroupAssociation2);
        } catch (IllegalArgumentException ex) {
            //expected
        } catch (PersistencyServiceException ex) {
            fail("Exception is not expected here ", ex);
        }
        try {
            AssetGroupAssociation assetGroupAssociation3 = AssetGroupAssociationUtils.createAssetGroupAssociation(null,
                null);
            assetGroupAssociationPersistencyService.deleteAssetGroupAssociations(TestUtils.TEST_TENANT,
                TestUtils.getUber(), assetGroupAssociation3);
        } catch (IllegalArgumentException ex) {
            //expected
        } catch (PersistencyServiceException ex) {
            fail("Exception is not expected here ", ex);
        }
    }

    @Test
    @Transactional
    public void deleteAssetGroupAssociation_NotFound() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");

        TestAssetGroupItem a1_item1 = GroupUtils.createAssetGroupItem(assetGroupCr.getId(), assetInstance.getId());
        groupPersistencyService.createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupCr.getId(),
            Arrays.asList(a1_item1));

        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        try {
            AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(
                assetGroupCr.getId(), UUID.randomUUID().toString());
            assetGroupAssociationPersistencyService.deleteAssetGroupAssociations(TestUtils.TEST_TENANT,
                TestUtils.getUber(), assetGroupAssociation2);
        } catch (ObjectNotFoundException ex) {
            //expected
        }
        try {
            AssetGroupAssociation assetGroupAssociation3 = AssetGroupAssociationUtils.createAssetGroupAssociation(
                UUID.randomUUID().toString(), assetInstance2.getId());
            assetGroupAssociationPersistencyService.deleteAssetGroupAssociations(TestUtils.TEST_TENANT,
                TestUtils.getUber(), assetGroupAssociation3);
        } catch (ObjectNotFoundException ex) {
            //expected
        }
        try {
            AssetGroupAssociation assetGroupAssociation4 = AssetGroupAssociationUtils.createAssetGroupAssociation(
                assetGroupCr.getId(), assetInstance2.getId());
            assetGroupAssociationPersistencyService.deleteAssetGroupAssociations(TestUtils.TEST_TENANT,
                TestUtils.getUnPrivileged(), assetGroupAssociation4);
        } catch (ObjectNotFoundException ex) {
            //expected
        }
    }

    @Test
    @Transactional
    public void deleteAssetGroupAssociation_UberUser() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");

        TestAssetGroupItem a1_item1 = GroupUtils.createAssetGroupItem(assetGroupCr.getId(), assetInstance.getId());
        groupPersistencyService.createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupCr.getId(),
            Arrays.asList(a1_item1));

        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        try {
            assetGroupAssociationPersistencyService.deleteAssetGroupAssociations(TestUtils.TEST_TENANT,
                TestUtils.getUnPrivileged(), assetGroupAssociation1);
        } catch (ObjectNotFoundException ex) {
            //expected
        }

        AssetGroupAssociation assetGroupAssociation4 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), "");

        assertThat(assetGroupAssociationPersistencyService
            .deleteAssetGroupAssociations(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupAssociation4))
            .isEqualTo(1);
    }

    @Test
    @Transactional
    public void deleteAssetGroupAssociation_nonUberUser() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");

        TestAssetGroupItem a1_item1 = GroupUtils.createAssetGroupItem(assetGroupCr.getId(), assetInstance.getId());
        groupPersistencyService.createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupCr.getId(),
            Arrays.asList(a1_item1));

        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        try {
            assetGroupAssociationPersistencyService.deleteAssetGroupAssociations(TestUtils.TEST_TENANT,
                TestUtils.getUber(), assetGroupAssociation1);
        } catch (ObjectNotFoundException ex) {
            //expected
        } catch (PersistencyServiceException ex) {
            fail("Exception is not expected here ", ex);
        }
    }

    @Test
    @Transactional
    public void deleteAssetGroupAssociation_byGroupId() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");

        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        //user only has access to one of the two assets that are connected to the group

        AssetGroupAssociation assetGroupAssociation3 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assertThat(assetGroupAssociationPersistencyService
            .deleteAssetGroupAssociations(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupAssociation3)).isOne();

        assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(assetGroupCr.getId(),
            assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        //user has resource level permission on both assets, should remove both assetGroupAssociations
        assertThat(assetGroupAssociationPersistencyService
            .deleteAssetGroupAssociations(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupAssociation2)).isOne();
    }

    @Test
    @Transactional
    public void deleteAssetGroupAssociation_byObjectId() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");
        AssetGroup assetGroupCr2 = (AssetGroup) data.get("Group2");

        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        assertThat(assetGroupAssociationPersistencyService
            .deleteAssetGroupAssociations(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupAssociation1)).isOne();

        assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(assetGroupCr.getId(),
            assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(assetGroupCr2.getId(),
            assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        assertThat(assetGroupAssociationPersistencyService
            .deleteAssetGroupAssociations(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupAssociation2))
            .isEqualTo(1);
    }

    @Test
    @Transactional
    public void deleteAssetGroupAssociation_byGroupIdAndObjectId() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");
        AssetGroup assetGroupCr2 = (AssetGroup) data.get("Group2");

        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        AssetGroupAssociation assetGroupAssociation3 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr2.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation3));

        assertThat(assetGroupAssociationPersistencyService
            .deleteAssetGroupAssociations(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupAssociation1)).isOne();

        assertThat(assetGroupAssociationPersistencyService
            .deleteAssetGroupAssociations(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupAssociation2)).isOne();

        assertThat(assetGroupAssociationPersistencyService
            .deleteAssetGroupAssociations(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupAssociation3)).isOne();
    }

    @Test
    @Transactional
    public void deleteAssetGroupAssociation_byCascadeDelete() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");
        AssetGroup assetGroupCr2 = (AssetGroup) data.get("Group2");

        AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        AssetGroupAssociation assetGroupAssociation3 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr2.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation3));

        assetPersistencyService.deleteAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), assetInstance2.getId());

        try {
            AssetGroupAssociation assetGroupAssociation4 = AssetGroupAssociationUtils.createAssetGroupAssociation(
                assetGroupCr.getId(), assetInstance2.getId());
            assetGroupAssociationPersistencyService.deleteAssetGroupAssociations(TestUtils.TEST_TENANT,
                TestUtils.getUber(), assetGroupAssociation4);
        } catch (ObjectNotFoundException ex) {
            //expected
        }
        try {

            AssetGroupAssociation assetGroupAssociation5 = AssetGroupAssociationUtils.createAssetGroupAssociation(
                assetGroupCr2.getId(), assetInstance2.getId());
            assetGroupAssociationPersistencyService.deleteAssetGroupAssociations(TestUtils.TEST_TENANT,
                TestUtils.getUber(), assetGroupAssociation5);
        } catch (ObjectNotFoundException ex) {
            //expected
        }

        assetGroupAssociation3 = AssetGroupAssociationUtils.createAssetGroupAssociation(assetGroupCr2.getId(),
            assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation3));
        groupPersistencyService.deleteAssetGroup(TestUtils.TEST_TENANT, assetGroupCr2.getId());

        try {

            AssetGroupAssociation assetGroupAssociation6 = AssetGroupAssociationUtils.createAssetGroupAssociation(
                assetGroupCr2.getId(), assetInstance.getId());
            assetGroupAssociationPersistencyService.deleteAssetGroupAssociations(TestUtils.TEST_TENANT,
                TestUtils.getUber(), assetGroupAssociation6);
        } catch (ObjectNotFoundException ex) {
            //expected
        }
    }

    @Test
    @Transactional
    public void getAssetGroupAssociation_byObjectId_UberUser() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");
        AssetGroup assetGroupCr2 = (AssetGroup) data.get("Group2");

        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        AssetGroupAssociation assetGroupAssociation3 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr2.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation3));

        assertThat(assetGroupAssociationPersistencyService
            .getAssociatedGroupsByAssetId(TestUtils.TEST_TENANT, TestUtils.getUber(), assetInstance.getId(), null))
            .hasSize(1).extracting(AssetGroup::getName).containsOnly("Group1");

        assertThat(assetGroupAssociationPersistencyService
            .getAssociatedGroupsByAssetId(TestUtils.TEST_TENANT, TestUtils.getUber(), assetInstance2.getId(), "asset"))
            .hasSize(2).extracting(AssetGroup::getName).contains("Group1", "Group2");

        assertThat(assetGroupAssociationPersistencyService
            .getAssociatedGroupsByAssetId(TestUtils.TEST_TENANT, TestUtils.getUber(), assetInstance2.getId(), "asset"))
            .hasSize(2).extracting(AssetGroup::getName).contains("Group1", "Group2");

        assertThat(assetGroupAssociationPersistencyService.getAssociatedGroupsByAssetIds(
            TestUtils.TEST_TENANT, TestUtils.getUber(), Arrays.asList(assetInstance2.getId()), "tag")).hasSize(0);

        Map<String, List<AssetGroup>> result = assetGroupAssociationPersistencyService.getAssociatedGroupsByAssetIds(
            TestUtils.TEST_TENANT, TestUtils.getUber(), Arrays.asList(assetInstance2.getId()), "asset");
        assertThat(result).hasSize(1).containsOnlyKeys(assetInstance2.getId());
        assertThat(result.get(assetInstance2.getId())).extracting(AssetGroup::getName).containsOnly("Group1", "Group2");

        result = assetGroupAssociationPersistencyService.getAssociatedGroupsByAssetIds(TestUtils.TEST_TENANT,
            TestUtils.getUber(), Arrays.asList(assetInstance.getId()), null);
        assertThat(result).hasSize(1).containsOnlyKeys(assetInstance.getId());
        assertThat(result.get(assetInstance.getId())).extracting(AssetGroup::getName).containsOnly("Group1");

        result = assetGroupAssociationPersistencyService.getAssociatedGroupsByAssetIds(TestUtils.TEST_TENANT,
            TestUtils.getUber(), Arrays.asList(assetInstance.getId(), assetInstance2.getId()), "asset");
        assertThat(result).hasSize(2).containsOnlyKeys(assetInstance.getId(), assetInstance2.getId());
        assertThat(result.get(assetInstance.getId())).extracting(AssetGroup::getName).containsOnly("Group1");
        assertThat(result.get(assetInstance2.getId())).extracting(AssetGroup::getName).containsOnly("Group1", "Group2");
    }

    @Test
    @Transactional
    public void getAssetGroupAssociation_byGroupId_andObjectId_UberUser()
        throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");
        AssetGroup assetGroupCr2 = (AssetGroup) data.get("Group2");

        // Create 3 associations
        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        AssetGroupAssociation assetGroupAssociation3 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr2.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation3));

        // Verify that A1 -> Group1 exists
        assertThat(assetGroupAssociationPersistencyService
            .getAssetGroupAssociationsByAssetAndGroupURI(TestUtils.TEST_TENANT, TestUtils.getUber(),
                assetGroupCr.getId(), assetInstance.getId())).hasSize(1);

        // Verify that A2 -> Group1 exists
        assertThat(assetGroupAssociationPersistencyService
            .getAssetGroupAssociationsByAssetAndGroupURI(TestUtils.TEST_TENANT, TestUtils.getUber(),
                assetGroupCr.getId(), null)).hasSize(2);

        // Verify that A2 -> Group2 exists
        assertThat(assetGroupAssociationPersistencyService
            .getAssetGroupAssociationsByAssetAndGroupURI(TestUtils.TEST_TENANT, TestUtils.getUber(), null,
                assetInstance2.getId())).hasSize(2);
    }

    @Test
    @Transactional
    public void getAssetGroupAssociation_byGroupId_UberUser() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");
        AssetGroup assetGroupCr2 = (AssetGroup) data.get("Group2");

        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        AssetGroupAssociation assetGroupAssociation3 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr2.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation3));

        assertThat(assetGroupAssociationPersistencyService
            .getAssociatedAssetsByGroupId(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupCr.getId())).hasSize(2)
            .extracting(Asset::getName).containsOnly("A1", "A2");
    }

    @Test
    @Transactional
    public void getAssetGroupAssociation_byObjectId_nonUberUser() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");
        AssetGroup assetGroupCr2 = (AssetGroup) data.get("Group2");

        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        AssetGroupAssociation assetGroupAssociation3 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr2.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation3));

        assertThat(assetGroupAssociationPersistencyService
            .getAssociatedGroupsByAssetId(TestUtils.TEST_TENANT, Arrays.asList(assetInstance2.getId()),
                assetInstance.getId(), null)).isEmpty();

        assertThat(assetGroupAssociationPersistencyService
            .getAssociatedGroupsByAssetIds(TestUtils.TEST_TENANT, Arrays.asList(assetInstance2.getId()),
                Arrays.asList(assetInstance.getId()), null)).isEmpty();

        Map<String, List<AssetGroup>> result = assetGroupAssociationPersistencyService.getAssociatedGroupsByAssetIds(
            TestUtils.TEST_TENANT, Arrays.asList(assetInstance2.getId()),
            Arrays.asList(assetInstance.getId(), assetInstance2.getId()), null);

        assertThat(result).hasSize(1).containsOnlyKeys(assetInstance2.getId());
        assertThat(result.get(assetInstance2.getId())).extracting(AssetGroup::getId).containsOnly(assetGroupCr.getId(),
            assetGroupCr2.getId());
    }

    @Test
    @Transactional
    public void getAssetGroupAssociation_byGroupId_nonUberUser() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");
        AssetGroup assetGroupCr2 = (AssetGroup) data.get("Group2");

        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        AssetGroupAssociation assetGroupAssociation3 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr2.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation3));

        assertThat(assetGroupAssociationPersistencyService
            .getAssociatedAssetsByGroupId(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), assetGroupCr.getId()))
            .isEmpty();
    }

    @Test
    @Transactional
    public void getAssetGroupAssociation_byGroupId_nonUberUser_decommissioned()
        throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetGroupAssociationUtils.setupData(assetTypePersistencyService,
            assetPersistencyService, groupPersistencyService);
        Collection<String> accessibleResources = Arrays.asList(data.get("A1").getId(), data.get("A2").getId());

        Asset assetInstance = (Asset) data.get("A1");
        Asset assetInstance2 = (Asset) data.get("A2");
        AssetGroup assetGroupCr = (AssetGroup) data.get("Group1");
        AssetGroup assetGroupCr2 = (AssetGroup) data.get("Group2");

        ((ObjectNode) assetInstance.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        ((ObjectNode) assetInstance2.getAttributes().path("reservedAttributes").path("state")).put("key", "45");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), assetInstance);
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), assetInstance2);

        AssetGroupAssociation assetGroupAssociation1 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation1));

        AssetGroupAssociation assetGroupAssociation2 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation2));

        AssetGroupAssociation assetGroupAssociation3 = AssetGroupAssociationUtils.createAssetGroupAssociation(
            assetGroupCr2.getId(), assetInstance2.getId());
        assetGroupAssociationPersistencyService.createAssetGroupAssociations(TestUtils.TEST_TENANT,
            Arrays.asList(assetGroupAssociation3));

        assertThat(assetGroupAssociationPersistencyService
            .getAssociatedAssetsByGroupId(TestUtils.TEST_TENANT, accessibleResources, assetGroupCr.getId())).hasSize(1)
            .extracting(Asset::getName).containsOnly("A2");
    }
}
