/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.EventsJobType;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetEventEntity;
import com.ge.apm.alm.persistence.jpa.model.TestAssetInstance;
import com.ge.apm.alm.persistence.jpa.repository.AssetEventRepository;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
@Slf4j
@Transactional
public class AssetEventPersistTests {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private static final String TEST_USER = "test-admin";
    private static final String TEST_OBJ_NAME = "test-event";
    private static final String TEST_SRC_KEY = "test-event-src-key";
    private static final String TEST_TENANT = "f743b7ef-42df-4d7e-89dd-90dc3b53b0ac";
    private static final String ASSET_TYPE = "963068c7-1181-451a-9750-e61f6dacb339";
    private static final String OBJECT_TYPE_ASSET = "Asset";
    private static final String MODIFIED = "-Modified";


    @Autowired
    private AssetEventPersistencyService eventService;


    @Autowired
    private AssetEventRepository eventRepo;

    @Test
    public void testGetPendingEventsForPredix() throws PersistencyServiceException {
        List<AssetEvent> events = createEvents(AssetEvent.EventStatus.QUEUED);
        eventService.createEvents(events);
        eventRepo.flush();
        List<AssetEvent> entities = eventService.getPendingEventBatch(EventsJobType.PREDIX, 5, 60000L, 864000000l);

        assertEquals(events.size(), entities.size());

        eventService.deleteEvents(events);
    }

    @Test
    public void testGetPendingEventsForEventhub() throws PersistencyServiceException {
        List<AssetEvent> events = createEvents(AssetEvent.EventStatus.QUEUED);
        eventService.createEvents(events);
        eventRepo.flush();
        List<AssetEvent> entities = eventService.getPendingEventBatch(EventsJobType.EVENTHUB, 3, 60000L, 864000000l);

        assertEquals(events.size(), entities.size());

        eventService.deleteEvents(events);
    }

    @Test
    public void testGetPendingEventsForAuditlog() throws PersistencyServiceException {
        List<AssetEvent> events = createEvents(AssetEvent.EventStatus.QUEUED);
        eventService.createEvents(events);
        eventRepo.flush();
        List<AssetEvent> entities = eventService.getPendingEventBatch(EventsJobType.AUDIT, 5, 60000L, 864000000l);

        assertEquals(events.size(), entities.size());

        eventService.deleteEvents(events);
    }

    @Test
    public void testCleanupEventsForStatus() throws PersistencyServiceException {
        List<AssetEvent> events = createEvents(AssetEvent.EventStatus.COMPLETED);
        eventService.createEvents(events);
        eventRepo.flush();
        long jobTimeoutMillis = 5000L;
        int count = eventService.cleanupEvents(AssetEvent.EventStatus.COMPLETED.name(), jobTimeoutMillis + "");
        assertEquals(events.size(), count);

        eventService.deleteEvents(events);
    }

   /* @Test
    public void testCleanupEventsForTimeout() throws PersistencyServiceException, InterruptedException {
        clearEvents();
        List<AssetEvent> events = createEvents(AssetEvent.EventStatus.PROCESSING);
        eventService.createEvents(events);
        long jobTimeoutMillis = 100L;
        Thread.currentThread().sleep(110L);
        int count = eventService.cleanupEvents(AssetEvent.EventStatus.COMPLETED.name(),jobTimeoutMillis + "");
        assertEquals(events.size(), count);

        eventService.deleteEvents(events);
    }*/

    @Test
    public void testCleanupEventsForInValidState() throws PersistencyServiceException {
        List<AssetEvent> events = createEvents(AssetEvent.EventStatus.QUEUED);
        eventService.createEvents(events);
        eventRepo.flush();
        long jobTimeoutMillis = 5000L;
        int count = eventService.cleanupEvents(AssetEvent.EventStatus.COMPLETED.name(), jobTimeoutMillis + "");
        assertEquals(0, count);

        eventService.deleteEvents(events);
    }

    @Test
    public void testUpdateEvent() throws PersistencyServiceException {
        List<AssetEvent> events = createEvents(AssetEvent.EventStatus.QUEUED);
        eventService.createEvents(events);
        eventRepo.flush();
        int count = eventService.updateEvent(events.get(0).getId(),
                AssetEvent.EventsJobType.EVENTHUB,
                AssetEvent.EventStatus.COMPLETED.name());
        assertEquals(1, count);

        count = eventService.updateEvent(events.get(1).getId(),
                AssetEvent.EventsJobType.AUDIT,
                AssetEvent.EventStatus.COMPLETED.name());
        assertEquals(1, count);

        count = eventService.updateEvent(events.get(2).getId(),
                AssetEvent.EventsJobType.PREDIX,
                AssetEvent.EventStatus.COMPLETED.name());
        assertEquals(1, count);

        eventService.deleteEvents(events);
    }

    @Test
    public void testUpdateEventsForPredixJob() throws PersistencyServiceException {
        List<AssetEvent> events = createEvents(AssetEvent.EventStatus.QUEUED);
        eventService.createEvents(events);
        eventRepo.flush();
        int count = eventService.updateEvents(events,
                AssetEvent.EventsJobType.PREDIX,
                AssetEvent.EventStatus.COMPLETED.name());
        assertEquals(3, count);

        eventService.deleteEvents(events);
    }

    @Test
    public void testUpdateEventsForAuditJob() throws PersistencyServiceException {
        List<AssetEvent> events = createEvents(AssetEvent.EventStatus.QUEUED);
        eventService.createEvents(events);
        eventRepo.flush();
        int count = eventService.updateEvents(events,
                AssetEvent.EventsJobType.AUDIT,
                AssetEvent.EventStatus.COMPLETED.name());
        assertEquals(3, count);

        eventService.deleteEvents(events);
    }

    @Test
    public void testUpdateEventsInClauseLimit() throws PersistencyServiceException {
        int limit = 350;
        List<AssetEvent> events = createEventsInClauseLimit(AssetEvent.EventStatus.QUEUED, limit);
        eventService.createEvents(events);
        eventRepo.flush();
        int count = eventService.updateEventsStatus(events.stream().map(AssetEvent::getId).collect(Collectors.toList()),
                AssetEvent.EventsJobType.AUDIT,
                AssetEvent.EventStatus.COMPLETED.name());
        assertEquals(limit*3, count);

        eventService.deleteEvents(events);
    }

    @Test
    public void testUpdateEventsForEventhubJob() throws PersistencyServiceException {
        List<AssetEvent> events = createEvents(AssetEvent.EventStatus.QUEUED);
        eventService.createEvents(events);
        eventRepo.flush();
        int count = eventService.updateEvents(events,
                AssetEvent.EventsJobType.EVENTHUB,
                AssetEvent.EventStatus.COMPLETED.name());
        assertEquals(3, count);

        eventService.deleteEvents(events);
    }

    @Test
    public void deleteEvents() throws PersistencyServiceException {
        AssetEventEntity event = createEvent(TestUtils.TEST_TENANT, null, null, null);
        assertThat(eventService.deleteEvents(Collections.singletonList(event))).isEqualTo(0);
    }

    @Test
    public void getEvents() throws PersistencyServiceException {
        assertThat(eventService.getEvents(TestUtils.TEST_TENANT, Type.CREATE, Collections.singleton(TestUtils.NULL_UUID)))
                .hasSize(0);
    }

    private List<AssetEvent> createEventsInClauseLimit(AssetEvent.EventStatus eventStatus, int limit) {
        List<AssetEvent> events = new ArrayList<>();
        IntStream.range(0, limit).forEach(idx -> {
            String objectId = newUuid();
            JsonNode preModifiedObject = convertBizObjToJsonNode(
                    createAssetInstance(ASSET_TYPE, TEST_OBJ_NAME, TEST_SRC_KEY));
            JsonNode modifiedObject = convertBizObjToJsonNode(
                    updateAssetInstance(ASSET_TYPE, TEST_OBJ_NAME + MODIFIED, TEST_SRC_KEY));
            AssetEvent createEvent = createEvent(TEST_TENANT, objectId, OBJECT_TYPE_ASSET, AssetEvent.Type.CREATE,
                    null, preModifiedObject, eventStatus);
            AssetEvent updateEvent = createEvent(TEST_TENANT, objectId, OBJECT_TYPE_ASSET, AssetEvent.Type.UPDATE,
                    preModifiedObject, modifiedObject, eventStatus);
            AssetEvent deleteEvent = createEvent(TEST_TENANT, objectId, OBJECT_TYPE_ASSET, AssetEvent.Type.DELETE,
                    preModifiedObject, null, eventStatus);
            events.add(createEvent);
            events.add(updateEvent);
            events.add(deleteEvent);
        });
        return events;
    }

    private List<AssetEvent> createEvents(AssetEvent.EventStatus eventStatus) {
        List<AssetEvent> events = new ArrayList<>();
        String objectId = newUuid();
        JsonNode preModifiedObject = convertBizObjToJsonNode(
                createAssetInstance(ASSET_TYPE, TEST_OBJ_NAME, TEST_SRC_KEY));
        JsonNode modifiedObject = convertBizObjToJsonNode(
                updateAssetInstance(ASSET_TYPE, TEST_OBJ_NAME + MODIFIED, TEST_SRC_KEY));
        AssetEvent createEvent = createEvent(TEST_TENANT, objectId, OBJECT_TYPE_ASSET, AssetEvent.Type.CREATE,
                null, preModifiedObject, eventStatus);
        AssetEvent updateEvent = createEvent(TEST_TENANT, objectId, OBJECT_TYPE_ASSET, AssetEvent.Type.UPDATE,
                preModifiedObject, modifiedObject, eventStatus);
        AssetEvent deleteEvent = createEvent(TEST_TENANT, objectId, OBJECT_TYPE_ASSET, AssetEvent.Type.DELETE,
                preModifiedObject, null, eventStatus);
        events.add(createEvent);
        events.add(updateEvent);
        events.add(deleteEvent);
        return events;
    }

    private AssetEvent createEvent(String tenantId, String objectId, String objectType,
                                   AssetEvent.Type eventType, JsonNode preModifiedObject,
                                   JsonNode modifiedBizObject, AssetEvent.EventStatus eventStatus) {
        return AssetEventEntity.builder()
                .id(newUuid())
                .tenantId(tenantId)
                .objectId(objectId)
                .objectType(objectType)
                .eventType(eventType)
                .preModifiedObject(preModifiedObject)
                .modifiedBizObject(modifiedBizObject)
                .objectLastModifiedDate(OffsetDateTime.now())
                .createdBy(TEST_USER)
                .lastModifiedBy(TEST_USER)
                .predixPubStatus(eventStatus)
                .auditPubStatus(eventStatus)
                .eventhubPubStatus(eventStatus)
                .build();
    }

    private Asset createAssetInstance(String assetType, String name, String srcKey) {
        return TestAssetInstance.builder().
                id(newUuid()).tenantId(TEST_TENANT).sourceKey(srcKey).
                name(name).description(name).
                assetType(ASSET_TYPE).build();
    }

    private Asset updateAssetInstance(String assetType, String name, String srcKey) {
        return TestAssetInstance.builder().
                id(newUuid()).tenantId(TEST_TENANT).sourceKey(srcKey).
                name(name).description(name).
                assetType(ASSET_TYPE).build();
    }

    private String newUuid() {
        return UUID.randomUUID().toString();
    }

    private JsonNode convertBizObjToJsonNode(Asset asset) {
        return OBJECT_MAPPER.convertValue(asset, JsonNode.class);
    }

    private JsonNode createJsonNode(String objectId) {
        try {
            return OBJECT_MAPPER.reader().readTree("{objectId}");
        } catch (IOException ex) {
            log.error("Exception while creating JsonNode {}, ", ex);
        }
        return null;
    }


    //@Test
    //@Transactional
    public void testGettingNumbersOfJobs() throws PersistencyServiceException {

        String tenant1 = UUID.randomUUID().toString();
        String object1_1 = UUID.randomUUID().toString();
        String object1_2 = UUID.randomUUID().toString();

        String tenant2 = UUID.randomUUID().toString();
        String object2_1 = UUID.randomUUID().toString();

        String tenant3 = UUID.randomUUID().toString();
        String object3_1 = UUID.randomUUID().toString();

        String tenant4 = UUID.randomUUID().toString();
        String object4_1 = UUID.randomUUID().toString();

        List<AssetEvent> events = new ArrayList<>();
        events.add(createEvent(tenant1, object1_1, "Segment", AssetEvent.Type.CREATE));
        events.add(createEvent(tenant1, object1_2, "AssetType", Type.CREATE));
        events.add(createEvent(tenant1, object1_2, "AssetType", Type.UPDATE));
        events.add(createEvent(tenant2, object2_1, "Segment", Type.CREATE));
        events.add(createEvent(tenant3, object3_1, "Segment", Type.CREATE));
        events.add(createEvent(tenant3, object3_1, "Segment", Type.UPDATE));
        events.add(createEvent(tenant3, object3_1, "Segment", Type.UPDATE));
        events.add(createEvent(tenant3, object3_1, "Segment", Type.UPDATE));
        events.add(createEvent(tenant3, object3_1, "Segment", Type.UPDATE));
        events.add(createEvent(tenant3, object3_1, "Segment", Type.UPDATE));
        events.add(createEvent(tenant3, object3_1, "Segment", Type.UPDATE));
        events.add(createEvent(tenant3, object3_1, "Segment", Type.UPDATE));
        events.add(createEvent(tenant3, object3_1, "Segment", Type.DELETE));

        events.add(createEvent(tenant4, object4_1, "Template", Type.CREATE));
        events.add(createEvent(tenant4, object4_1, "Template", Type.UPDATE));
        events.add(createEvent(tenant4, object4_1, "Template", Type.DELETE));

        eventService.createEvents(events);
        List<AssetEvent> entities = eventService.getPendingEventBatch(EventsJobType.PREDIX, 5, 5000l, 864000000l);

        assertEquals(events.size(), entities.size());
    }

    private AssetEventEntity createEvent(String tenantId, String objectId, String objectType, AssetEvent.Type type) {
        return AssetEventEntity.builder()
                .id(UUID.randomUUID().toString())
                .tenantId(tenantId)
                .objectId(objectId)
                .objectType(objectType)
                .eventType(type)
                .lastModifiedBy("wush")
                .objectLastModifiedDate(OffsetDateTime.now())
                .build();
    }

}
