/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.network;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.Sets;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.Direction;
import com.ge.apm.alm.model.Edge;
import com.ge.apm.alm.model.Network;
import com.ge.apm.alm.model.query.NetworkPredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.NetworkPersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectAlreadyExistsException;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.EdgeEntity;
import com.ge.apm.alm.persistence.jpa.entity.NetworkEntity;
import com.ge.apm.alm.persistence.jpa.entity.NetworkHierarchyEntity;
import com.ge.apm.alm.persistence.jpa.model.TestEdge;
import com.ge.apm.alm.persistence.jpa.model.TestNetwork;
import com.ge.apm.alm.persistence.jpa.utils.AssetUtils;
import com.ge.apm.alm.persistence.jpa.utils.NetworkUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.failBecauseExceptionWasNotThrown;

/**
 * @author Albert H. Yu 212365823
 * @version 1.0 July 15, 2017
 * @since 1.0
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class NetworkPersistSvcTests {

    @Autowired
    private NetworkPersistencyService networkPersistencyService;

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    @After
    public void tearDown() {
        TestUtils.destroyAssetUserPolicies();
    }

    @Test
    public void networkEntityBuilder() throws IOException {
        NetworkEntity expected = new NetworkEntity();
        BeanUtils.copyProperties(NetworkUtils.createNetwork(), expected);
        NetworkEntity built = NetworkEntity.builder().id(expected.getId()).sourceKey(expected.getSourceKey()).name(
            expected.getName()).description(expected.getDescription()).tenantId(expected.getTenantId()).attributes(
            expected.getAttributes()).createdBy(expected.getCreatedBy()).lastModifiedBy(expected.getLastModifiedBy())
            .build();
        assertThat(built).isEqualToComparingFieldByField(expected);
    }

    @Test
    public void networkHierarchyEntityBuilder() {
        NetworkHierarchyEntity expected = new NetworkHierarchyEntity();
        BeanUtils.copyProperties(
            NetworkUtils.createNetworkHierarchy(UUID.randomUUID().toString(), UUID.randomUUID().toString()), expected);
        NetworkHierarchyEntity built = NetworkHierarchyEntity.builder().id(expected.getId()).networkNodeId(
            expected.getNetworkNodeId()).parentNetworkId(expected.getParentNetworkId()).tenantId(expected.getTenantId())
            .createdBy(expected.getCreatedBy()).lastModifiedBy(expected.getLastModifiedBy()).build();
        assertThat(built).isEqualToComparingFieldByField(expected);
    }

    @Test
    public void edgeEntityBuilder() throws IOException {
        EdgeEntity expected = new EdgeEntity();
        BeanUtils.copyProperties(NetworkUtils
            .createEdge(UUID.randomUUID().toString(), UUID.randomUUID().toString(), Direction.BIDIRECTIONAL,
                UUID.randomUUID().toString()), expected);
        EdgeEntity built = EdgeEntity.builder().id(expected.getId()).name(expected.getName()).description(
            expected.getDescription()).source(expected.getSource()).target(expected.getTarget()).direction(
            expected.getDirection()).assetId(expected.getAssetId()).tenantId(expected.getTenantId()).attributes(
            expected.getAttributes()).createdBy(expected.getCreatedBy()).lastModifiedBy(expected.getLastModifiedBy())
            .build();
        assertThat(built).isEqualToComparingFieldByField(expected);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void createNetwork_tenantIdMismatch() throws PersistencyServiceException {
        networkPersistencyService.createNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            TestNetwork.builder().tenantId(TestUtils.NULL_UUID).build());
    }

    @Test
    @Transactional
    public void createNetwork() throws IOException, PersistencyServiceException {
        Network network = NetworkUtils.createNetwork();
        assertThat(network.getCreatedDate()).isNull();
        assertThat(network.getLastModifiedDate()).isNull();
        Network created = networkPersistencyService.createNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(), network);
        assertThat(created.getCreatedDate()).isNotNull();
        assertThat(created.getLastModifiedDate()).isNotNull();
        Network selectedById = networkPersistencyService.getNetworkById(network.getTenantId(), TestUtils.getUber(),
            network.getId());
        assertThat(selectedById).isEqualToComparingFieldByField(created);
        Network selectedBySourceKey = networkPersistencyService.getNetworkBySourceKey(network.getTenantId(),
            network.getSourceKey());
        assertThat(selectedBySourceKey).isEqualToComparingFieldByField(created);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void getNetworksByIds_fullNotSupported() throws PersistencyServiceException {
        networkPersistencyService.getNetworksByIds(TestUtils.TEST_TENANT, TestUtils.getUber(), Collections.emptySet(),
            AttributeSelectEnum.FULL);
    }

    @Test
    @Transactional
    public void getNetworkBySourceKey() throws PersistencyServiceException {
        assertThat(networkPersistencyService.getNetworkBySourceKey(TestUtils.TEST_TENANT, TestUtils.NULL_UUID))
            .isNull();
    }

    @Test
    @Transactional
    public void createNetwork_asAssetNode() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Asset asset = (Asset) data.get("E1_S1_Seg1_Asset1");
        Network assetNode = NetworkUtils.createNetwork(asset.getId());
        Network created = networkPersistencyService.createNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            assetNode);
        assertThat(created.getSourceKey()).isNull();
        assertThat(created.getName()).isNull();
        assertThat(created.getDescription()).isNull();
        assertThat(created.getAttributes()).isNull();
        Network selectedById = networkPersistencyService.getNetworkById(assetNode.getTenantId(), TestUtils.getUber(),
            assetNode.getId());
        assertThat(selectedById.getAssetId()).isEqualTo(created.getAssetId());
        assertThat(selectedById.getAsset().getName()).isEqualTo(asset.getName());
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void createNetwork_asAssetNode_unpriviledged() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Asset asset = (Asset) data.get("E1_S1_Seg1_Asset1");
        Network assetNode = NetworkUtils.createNetwork(asset.getId());
        networkPersistencyService.createNetwork(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), assetNode);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void createNetworks_tenantIdMismatch() throws PersistencyServiceException {
        networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(),
            Collections.singletonList(TestNetwork.builder().tenantId(TestUtils.NULL_UUID).build()));
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void createNetworks_withAssetNodes_insufficientAccess() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork(data.get("E1_S1_Seg1_Asset1").getId()),
            NetworkUtils.createNetwork());

        networkPersistencyService.createNetworks(TestUtils.TEST_TENANT,
            TestUtils.getUnPrivileged(data.get("E1_S1_Seg1_Asset2")), networks);
    }

    @Test
    @Transactional
    public void createNetworks() throws IOException, PersistencyServiceException {
        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork(), NetworkUtils.createNetwork());

        assertThat(networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(), networks))
            .isEqualTo(2);
        Set<String> sourceKeys = networks.stream().map(Network::getSourceKey).collect(Collectors.toSet());
        assertThat(networkPersistencyService
            .getNetworksBySourceKeys(TestUtils.TEST_TENANT, sourceKeys, AttributeSelectEnum.ATTRIBUTES)).hasSize(2);
        assertThat(networkPersistencyService.getNetworksBySourceKeys(TestUtils.TEST_TENANT,
            Sets.newHashSet(UUID.randomUUID() + "-sourceKey", UUID.randomUUID() + "-sourceKey"),
            AttributeSelectEnum.BASIC)).isEmpty();
        try {
            networkPersistencyService.getNetworksBySourceKeys(TestUtils.TEST_TENANT, sourceKeys,
                AttributeSelectEnum.FULL);
            failBecauseExceptionWasNotThrown(IllegalArgumentException.class);
        } catch (IllegalArgumentException ex) {
            // ignore expected exception
        }
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void updateNetwork_tenantIdMismatch() throws PersistencyServiceException {
        networkPersistencyService.updateNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            TestNetwork.builder().tenantId(TestUtils.NULL_UUID).build());
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void updateNetwork_asAssetNode_unpriviledged() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Asset asset = (Asset) data.get("E1_S1_Seg1_Asset1");
        Network assetNode = NetworkUtils.createNetwork(asset.getId());
        networkPersistencyService.updateNetwork(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), assetNode);
    }

    @Test
    @Transactional
    public void updateNetwork_asAssetNode() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Asset asset = (Asset) data.get("E1_S1_Seg1_Asset1");
        Network assetNode = NetworkUtils.createNetwork(asset.getId());
        Network created = networkPersistencyService.createNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            assetNode);
        assertThat(created.getSourceKey()).isNull();
        assertThat(created.getName()).isNull();
        assertThat(created.getDescription()).isNull();
        assertThat(created.getAttributes()).isNull();

        NetworkEntity tobeUpdated = new NetworkEntity();
        BeanUtils.copyProperties(created, tobeUpdated);
        tobeUpdated.setAssetId(data.get("E1_S1_Seg1_Asset2").getId());
        tobeUpdated.setSourceKey("updated-sourceKey-" + tobeUpdated.getId());
        tobeUpdated.setName("updated-name-" + tobeUpdated.getId());
        tobeUpdated.setDescription("updated-description-" + tobeUpdated.getId());
        tobeUpdated.setAttributes(TestUtils.emptyJsonNode());
        Network updated = networkPersistencyService.updateNetwork(TestUtils.TEST_TENANT,
            Collections.singletonList(tobeUpdated.getAssetId()), tobeUpdated);
        assertThat(updated.getSourceKey()).isNull();
        assertThat(updated.getName()).isNull();
        assertThat(updated.getDescription()).isNull();
        assertThat(updated.getAttributes()).isNull();
        assertThat(updated.getAssetId()).isEqualTo(tobeUpdated.getAssetId());

        // update to a regular network
        tobeUpdated.setAssetId(null);
        Network updatedWithoutAsset = networkPersistencyService.updateNetwork(TestUtils.TEST_TENANT,
            Collections.singletonList(asset.getId()), tobeUpdated);
        assertThat(updatedWithoutAsset.getSourceKey()).isEqualTo(tobeUpdated.getSourceKey());
        assertThat(updatedWithoutAsset.getName()).isEqualTo(tobeUpdated.getName());
        assertThat(updatedWithoutAsset.getDescription()).isEqualTo(tobeUpdated.getDescription());
        assertThat(updatedWithoutAsset.getAttributes()).isEqualTo(tobeUpdated.getAttributes());
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void updateNetworks_tenantIdMismatch() throws PersistencyServiceException {
        networkPersistencyService.updateNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(),
            Collections.singletonList(TestNetwork.builder().tenantId(TestUtils.NULL_UUID).build()));
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void updateNetworks_withAssetNodes_insufficientAccess() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork(data.get("E1_S1_Seg1_Asset1").getId()),
            NetworkUtils.createNetwork());

        networkPersistencyService.updateNetworks(TestUtils.TEST_TENANT,
            TestUtils.getUnPrivileged(data.get("E1_S1_Seg1_Asset2")), networks);
    }

    @Test
    @Transactional
    public void updteNetworks() throws IOException, PersistencyServiceException {
        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork(), NetworkUtils.createNetwork());

        assertThat(networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(), networks))
            .isEqualTo(2);
        Set<String> sourceKeys = networks.stream().map(Network::getSourceKey).collect(Collectors.toSet());
        List<Network> createdNetworks = networkPersistencyService.getNetworksBySourceKeys(TestUtils.TEST_TENANT,
            sourceKeys, AttributeSelectEnum.ATTRIBUTES);
        createdNetworks.forEach(ntw -> {
            NetworkEntity ntwe = (NetworkEntity) ntw;
            ntwe.setSourceKey("updated-" + ntw.getSourceKey());
            ntwe.setName("updated-" + ntw.getName());
            ntwe.setDescription("updated-" + ntw.getDescription());
        });
        assertThat(
            networkPersistencyService.updateNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(), createdNetworks))
            .isEqualTo(2);
        List<Network> updatedNetworks = networkPersistencyService.getNetworksByIds(TestUtils.TEST_TENANT,
            TestUtils.getUber(), networks.stream().map(Network::getId).collect(Collectors.toSet()),
            AttributeSelectEnum.BASIC);
        updatedNetworks.forEach(ntw -> {
            assertThat(ntw.getSourceKey()).startsWith("updated-");
            assertThat(ntw.getName()).startsWith("updated-");
            assertThat(ntw.getDescription()).startsWith("updated-");
        });
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void addAssetsToNetwork_tenantIdMismatch() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        List<Asset> assets = Arrays.asList((Asset) data.get("E1_S1_Seg1_Asset1"),
            (Asset) data.get("E1_S1_Seg1_Asset2"));
        networkPersistencyService.addAssetsToNetwork(UUID.randomUUID().toString(), TestUtils.getUber(),
            UUID.randomUUID().toString(), assets);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void addAssetsToNetwork_parentNetworkMissing() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        List<Asset> assets = Arrays.asList((Asset) data.get("E1_S1_Seg1_Asset1"),
            (Asset) data.get("E1_S1_Seg1_Asset2"));
        networkPersistencyService.addAssetsToNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            UUID.randomUUID().toString(), assets);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void addAssetsToNetwork_insufficientAccess() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Network network = NetworkUtils.createNetwork();
        Network parentNetwork = networkPersistencyService.createNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            network);

        List<Asset> assets = Arrays.asList((Asset) data.get("E1_S1_Seg1_Asset1"),
            (Asset) data.get("E1_S1_Seg1_Asset2"));
        networkPersistencyService.addAssetsToNetwork(TestUtils.TEST_TENANT,
            TestUtils.getUnPrivileged(data.get("E1_S1_Seg1_Asset1")), parentNetwork.getId(), assets);
    }

    @Test
    @Transactional
    public void addAssetsToNetwork() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Network network = NetworkUtils.createNetwork();
        Network parentNetwork = networkPersistencyService.createNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            network);

        List<Asset> assets = Arrays.asList((Asset) data.get("E1_S1_Seg1_Asset1"),
            (Asset) data.get("E1_S1_Seg1_Asset2"));
        assertThat(networkPersistencyService
            .addAssetsToNetwork(TestUtils.TEST_TENANT, Arrays.asList(assets.get(0).getId(), assets.get(1).getId()),
                parentNetwork.getId(), assets)).isEqualTo(2);
    }

    @Test(expected = ObjectAlreadyExistsException.class)
    @Transactional
    public void addDuplicateAssetsToNetwork() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Network network = NetworkUtils.createNetwork();
        Network parentNetwork = networkPersistencyService.createNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            network);

        List<Asset> assets = Arrays.asList((Asset) data.get("E1_S1_Seg1_Asset1"),
            (Asset) data.get("E1_S1_Seg1_Asset2"));
        assertThat(networkPersistencyService
            .addAssetsToNetwork(TestUtils.TEST_TENANT, Arrays.asList(assets.get(0).getId(), assets.get(1).getId()),
                parentNetwork.getId(), assets)).isEqualTo(2);
        assertThat(networkPersistencyService
            .addAssetsToNetwork(TestUtils.TEST_TENANT, Arrays.asList(assets.get(0).getId(), assets.get(1).getId()),
                parentNetwork.getId(), assets)).isEqualTo(2);
    }

    @Test
    @Transactional
    public void addChidrenToNetwork() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Network network = NetworkUtils.createNetwork();
        Network parentNetwork = networkPersistencyService.createNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            network);
        List<Network> subnetworks = Arrays.asList(NetworkUtils.createNetwork(), NetworkUtils.createNetwork(),
            NetworkUtils.createNetwork(data.get("E1_S1_Seg1_Asset1").getId()));
        Collection<String> accessibleToAsset = Collections.singletonList(data.get("E1_S1_Seg1_Asset1").getId());
        assertThat(networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, accessibleToAsset, subnetworks))
            .isEqualTo(subnetworks.size());

        assertThat(networkPersistencyService
            .addChildrenToNetwork(TestUtils.TEST_TENANT, accessibleToAsset, parentNetwork.getId(), subnetworks))
            .isEqualTo(subnetworks.size());

        try {
            networkPersistencyService.addChildrenToNetwork(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(),
                parentNetwork.getId(), subnetworks);
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (ObjectNotFoundException ex) {
            // ignore expected exception
        }
    }

    @Test
    @Transactional
    public void getNodesByAssetIds() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Set<String> assetIds = new HashSet<>();
        int totalAssets = 5;
        for (int i = 1; i <= totalAssets; i++) {
            assetIds.add(data.get("A" + i).getId());
        }
        assertThat(networkPersistencyService.getNodesByAssetIds(TestUtils.TEST_TENANT, TestUtils.getUber(), assetIds))
            .hasSize(totalAssets);
        Collection<String> accessibleToOneTwo = Arrays.asList(data.get("A1").getId(), data.get("A2").getId());
        Map<String, List<Network>> oneTwo = networkPersistencyService.getNodesByAssetIds(TestUtils.TEST_TENANT,
            accessibleToOneTwo, assetIds);
        assertThat(
            networkPersistencyService.getNodesByAssetIds(TestUtils.TEST_TENANT, accessibleToOneTwo, assetIds).keySet())
            .hasSize(accessibleToOneTwo.size()).containsOnly(data.get("A1").getId(), data.get("A2").getId());
    }

    @Test
    @Transactional
    public void getNodesByAssetIdsForNetwork() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Set<String> assetIds = new HashSet<>();
        int totalAssets = 3;
        for (int i = 1; i <= totalAssets; i++) {
            assetIds.add(data.get("A" + i).getId());
        }

        assertThat(networkPersistencyService.getNodesByAssetIdsForNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-A-A1,A2,A3").getId(), assetIds)).hasSize(totalAssets);

        Collection<String> accessibleToOneTwo = Arrays.asList(data.get("A1").getId(), data.get("A2").getId());
        assertThat(networkPersistencyService.getNodesByAssetIdsForNetwork(TestUtils.TEST_TENANT, accessibleToOneTwo,
            data.get("network-A-A1,A2,A3").getId(), assetIds).keySet()).hasSize(accessibleToOneTwo.size()).containsOnly(
            data.get("A1").getId(), data.get("A2").getId());

        assetIds.clear();
        assetIds.add(data.get("A1").getId());
        assetIds.add(data.get("A4").getId());
        assetIds.add(data.get("A5").getId());

        assertThat(networkPersistencyService.getNodesByAssetIdsForNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-B-A1,A4,A5-D").getId(), assetIds)).hasSize(assetIds.size());
    }

    @Test
    @Transactional
    public void getNodesByAssetIdsForNetwork_decommissioned() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Collection<String> accessibleResources = Collections.singletonList(data.get("E1").getId());
        Set<String> assetIds = new HashSet<>();
        int totalAssets = 3;
        for (int i = 1; i <= totalAssets; i++) {
            assetIds.add(data.get("A" + i).getId());
            ((ObjectNode) ((Asset) data.get("A" + i)).getAttributes().path("reservedAttributes").path("state")).put(
                "key", "03");
            assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), (Asset) data.get("A" + i));
        }

        assertThat(networkPersistencyService.getNodesByAssetIdsForNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-A-A1,A2,A3").getId(), assetIds)).hasSize(totalAssets);

        Asset asset1 = (Asset) data.get("A1");
        ((ObjectNode) asset1.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), asset1);

        assertThat(networkPersistencyService.getNodesByAssetIdsForNetwork(TestUtils.TEST_TENANT, accessibleResources,
            data.get("network-A-A1,A2,A3").getId(), assetIds)).hasSize(totalAssets - 1).containsOnlyKeys(
            data.get("A2").getId(), data.get("A3").getId());

        Collection<String> accessibleToOneTwo = Arrays.asList(data.get("A1").getId(), data.get("A2").getId());
        assertThat(networkPersistencyService.getNodesByAssetIdsForNetwork(TestUtils.TEST_TENANT, accessibleToOneTwo,
            data.get("network-A-A1,A2,A3").getId(), assetIds).keySet()).hasSize(accessibleToOneTwo.size() - 1)
            .containsOnly(data.get("A2").getId());

        assetIds.clear();
        assetIds.add(data.get("A1").getId());
        for (int i = 4; i <= 5; i++) {
            assetIds.add(data.get("A" + i).getId());
            ((ObjectNode) ((Asset) data.get("A" + i)).getAttributes().path("reservedAttributes").path("state")).put(
                "key", "03");
            assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), (Asset) data.get("A" + i));
        }
        assetIds.add(data.get("A4").getId());
        assetIds.add(data.get("A5").getId());

        assertThat(networkPersistencyService.getNodesByAssetIdsForNetwork(TestUtils.TEST_TENANT, accessibleResources,
            data.get("network-B-A1,A4,A5-D").getId(), assetIds)).hasSize(assetIds.size() - 1).containsOnlyKeys(
            data.get("A4").getId(), data.get("A5").getId());
    }

    @Test
    @Transactional
    public void getNodesByNetworkId() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);

        assertThat(networkPersistencyService.getNodesByNetworkId(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-E-parent-of-A,B,C").getId(), null)).hasSize(3);

        assertThat(networkPersistencyService
            .getNodesByNetworkId(TestUtils.TEST_TENANT, TestUtils.getUber(), data.get("network-A-A1,A2,A3").getId(),
                null)).hasSize(3);

        assertThat(networkPersistencyService
            .getNodesByNetworkId(TestUtils.TEST_TENANT, TestUtils.getUber(), data.get("network-B-A1,A4,A5-D").getId(),
                null)).hasSize(4);

        Collection<String> accessibleToOneTwo = Arrays.asList(data.get("A1").getId(), data.get("A2").getId());

        List<String> accessibleNodes = networkPersistencyService.getNodesByNetworkId(TestUtils.TEST_TENANT,
            accessibleToOneTwo, data.get("network-A-A1,A2,A3").getId(), null).stream().map(a -> a.getAssetId()).collect(
            Collectors.toList());

        assertThat(accessibleNodes).hasSize(accessibleToOneTwo.size()).containsOnly(data.get("A1").getId(),
            data.get("A2").getId());

        //paginated
        NetworkPredicate networkPredicate = new NetworkPredicate();
        networkPredicate.setPageSize(2);
        networkPredicate.setOffset(1);
        assertThat(networkPersistencyService
            .getNodesByNetworkId(TestUtils.TEST_TENANT, TestUtils.getUber(), data.get("network-A-A1,A2,A3").getId(),
                networkPredicate)).hasSize(2);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void getRootNetworks_fullDetailsNotSupported() {
        networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT,
            NetworkPredicate.builder().attributeSelectEnum(AttributeSelectEnum.FULL).build());
    }

    @Test
    @Transactional
    public void getRootNetworks() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        List<Network> rootNetworks = networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT,
            NetworkPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).offset(0).pageSize(1).build());
        assertThat(rootNetworks).hasSize(1);
        assertThat(Arrays.asList("network-E-parent-of-A,B,C", "network-F-empty")).contains(
            rootNetworks.get(0).getName());
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void createEdges_tenantIdMismatch() throws PersistencyServiceException {
        networkPersistencyService.createEdges(UUID.randomUUID().toString(), TestUtils.getUber(),
            Collections.singletonList(TestEdge.builder().tenantId(TestUtils.TEST_TENANT).build()));
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void createEdges_associatedAssetNotAccessible() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Network network = NetworkUtils.createNetwork();
        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork(), NetworkUtils.createNetwork());
        assertThat(networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(), networks))
            .isEqualTo(networks.size());

        List<Edge> edges = Collections.singletonList(NetworkUtils
            .createEdge(networks.get(0).getId(), networks.get(1).getId(), Direction.UNDIRECTED,
                data.get("E1_S1_Seg1_Asset1").getId()));

        networkPersistencyService.createEdges(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), edges);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void createEdges_networkAssetNotAccessible() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Network network = NetworkUtils.createNetwork();
        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork(),
            NetworkUtils.createNetwork(data.get("E1_S1_Seg1_Asset1").getId()));
        assertThat(networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(), networks))
            .isEqualTo(networks.size());

        List<Edge> edges = Collections.singletonList(
            NetworkUtils.createEdge(networks.get(0).getId(), networks.get(1).getId(), Direction.UNDIRECTED, null));

        networkPersistencyService.createEdges(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), edges);
    }

    @Test
    @Transactional
    public void createEdges_asUber() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Network network = NetworkUtils.createNetwork();
        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork(), NetworkUtils.createNetwork(),
            NetworkUtils.createNetwork(), NetworkUtils.createNetwork(data.get("E1_S1_Seg1_Asset1").getId()));
        assertThat(networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(), networks))
            .isEqualTo(networks.size());

        List<Edge> edges = Arrays.asList(
            NetworkUtils.createEdge(networks.get(0).getId(), networks.get(1).getId(), Direction.UNDIRECTED, null),
            NetworkUtils.createEdge(networks.get(1).getId(), networks.get(2).getId(), Direction.BIDIRECTIONAL,
                data.get("E1_S1_Seg1_Asset2").getId()),
            NetworkUtils.createEdge(networks.get(2).getId(), networks.get(3).getId(), Direction.UNIDIRECTIONAL, null));

        assertThat(networkPersistencyService.createEdges(TestUtils.TEST_TENANT, TestUtils.getUber(), edges)).isEqualTo(
            edges.size());
    }

    @Test
    @Transactional
    public void createEdges_asPriviledged() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Network network = NetworkUtils.createNetwork();
        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork(), NetworkUtils.createNetwork(),
            NetworkUtils.createNetwork(), NetworkUtils.createNetwork(data.get("E1_S1_Seg1_Asset1").getId()));
        assertThat(networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(), networks))
            .isEqualTo(networks.size());

        List<Edge> edges = Arrays.asList(
            NetworkUtils.createEdge(networks.get(0).getId(), networks.get(1).getId(), Direction.UNDIRECTED, null),
            NetworkUtils.createEdge(networks.get(1).getId(), networks.get(2).getId(), Direction.BIDIRECTIONAL,
                data.get("E1_S1_Seg1_Asset2").getId()),
            NetworkUtils.createEdge(networks.get(2).getId(), networks.get(3).getId(), Direction.UNIDIRECTIONAL, null));

        assertThat(networkPersistencyService.createEdges(TestUtils.TEST_TENANT,
            Arrays.asList(data.get("E1_S1_Seg1_Asset1").getId(), data.get("E1_S1_Seg1_Asset2").getId()), edges))
            .isEqualTo(edges.size());
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void createEdges_asUnpriviledged() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Network network = NetworkUtils.createNetwork();
        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork(), NetworkUtils.createNetwork(),
            NetworkUtils.createNetwork(), NetworkUtils.createNetwork(data.get("E1_S1_Seg1_Asset1").getId()));
        assertThat(networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(), networks))
            .isEqualTo(networks.size());

        List<Edge> edges = Arrays.asList(
            NetworkUtils.createEdge(networks.get(0).getId(), networks.get(1).getId(), Direction.UNDIRECTED, null),
            NetworkUtils.createEdge(networks.get(1).getId(), networks.get(2).getId(), Direction.BIDIRECTIONAL,
                data.get("E1_S1_Seg1_Asset2").getId()),
            NetworkUtils.createEdge(networks.get(2).getId(), networks.get(3).getId(), Direction.UNIDIRECTIONAL, null));

        networkPersistencyService.createEdges(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), edges);
    }

    @Test(expected = PersistencyServiceException.class)
    @Transactional
    public void createEdges_EdgeAlreadyExists() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        Network network = NetworkUtils.createNetwork();
        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork(), NetworkUtils.createNetwork(),
            NetworkUtils.createNetwork(), NetworkUtils.createNetwork(data.get("E1_S1_Seg1_Asset1").getId()));
        assertThat(networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(), networks))
            .isEqualTo(networks.size());

        List<Edge> edges = Collections.singletonList(
            NetworkUtils.createEdge(networks.get(0).getId(), networks.get(1).getId(), Direction.UNDIRECTED, null));

        networkPersistencyService.createEdges(TestUtils.TEST_TENANT,
            Arrays.asList(data.get("E1_S1_Seg1_Asset1").getId(), data.get("E1_S1_Seg1_Asset2").getId()), edges);
        networkPersistencyService.createEdges(TestUtils.TEST_TENANT,
            Arrays.asList(data.get("E1_S1_Seg1_Asset1").getId(), data.get("E1_S1_Seg1_Asset2").getId()), edges);
    }

    @Test
    @Transactional
    public void deleteEdgeById_asUber() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        assertThat(networkPersistencyService
            .deleteEdgeById(TestUtils.TEST_TENANT, TestUtils.getUber(), data.get("edge-A2-->A3").getId())).isEqualTo(1);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void deleteEdgeById_nullEdgeId() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        networkPersistencyService.deleteEdgeById(TestUtils.TEST_TENANT, TestUtils.getUber(), "");
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void deleteEdgeById_nonExistingEdgeId() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        networkPersistencyService.deleteEdgeById(TestUtils.TEST_TENANT, TestUtils.getUber(),
            UUID.randomUUID().toString());
    }

    @Test
    @Transactional
    public void getEdgeById() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Edge edge = networkPersistencyService.getNetworkEdgeById(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("edge-A2-->A3").getId());
        assertThat(edge.getName()).isEqualTo("edge-A2-->A3");
        assertThat(edge.getDescription()).isEqualTo("description-edge-A2-->A3");
    }

    @Test
    @Transactional
    public void getEdgeById_invalidId() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Edge edge = networkPersistencyService.getNetworkEdgeById(TestUtils.TEST_TENANT, TestUtils.getUber(),
            UUID.randomUUID().toString());
        Assert.assertNull(edge);
    }

    @Test
    @Transactional
    public void getEdgeById_invalidEdgeId() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Edge edge = networkPersistencyService.getNetworkEdgeById(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-A-A1,A2,A3").getId(), UUID.randomUUID().toString());
        assertThat(edge).isNull();
    }

    @Test
    @Transactional
    public void getEdgeById_asUber() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Edge edge = networkPersistencyService.getNetworkEdgeById(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-A-A1,A2,A3").getId(), data.get("edge-A2-->A3").getId());

        assertThat(edge.getName()).isEqualTo("edge-A2-->A3");
        assertThat(edge.getDescription()).isEqualTo("description-edge-A2-->A3");
        assertThat(edge.getSourceNetwork().getAsset()).isNotNull();
        assertThat(edge.getSourceNetwork().getName()).isNull();
        assertThat(edge.getTargetNetwork().getAsset()).isNotNull();
        assertThat(edge.getTargetNetwork().getName()).isNull();
    }

    @Test
    @Transactional
    public void getNetworkEdges() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        List<Edge> rslt = networkPersistencyService.getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-E-parent-of-A,B,C").getId(), null);
        assertThat(rslt).hasSize(1);
        assertThat(rslt.get(0).getSourceNetwork().getName()).isEqualTo("network-A-A1,A2,A3");
        assertThat(rslt.get(0).getTargetNetwork().getName()).isEqualTo("network-B-A1,A4,A5-D");
        rslt = networkPersistencyService.getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-A-A1,A2,A3").getId(), null);
        rslt.forEach(x -> {
            if ("edge-A1<-->A2".equals(x.getName())) {
                assertThat(x.getAssetId()).isNotNull();
                assertThat(x.getAsset()).isNotNull();
            }
            assertThat(x.getSourceNetwork().getAsset()).isNotNull();
            assertThat(x.getSourceNetwork().getName()).isNull();
            assertThat(x.getTargetNetwork().getAsset()).isNotNull();
            assertThat(x.getTargetNetwork().getName()).isNull();
        });
        assertThat(networkPersistencyService
            .getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(), data.get("network-B-A1,A4,A5-D").getId(),
                null)).hasSize(3);
    }

    @Test
    @Transactional
    public void getNetworkEdgesPaginated() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        //paginated
        NetworkPredicate networkPredicate = new NetworkPredicate();
        networkPredicate.setPageSize(2);
        networkPredicate.setOffset(1);

        assertThat(networkPersistencyService
            .getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(), data.get("network-B-A1,A4,A5-D").getId(),
                networkPredicate)).hasSize(2);
    }

    //updateEdge calls updateEdges. No need to repeat tests for updateEdges.
    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void updateEdge_tenantIdMismatch() throws PersistencyServiceException {
        networkPersistencyService.updateEdge(TestUtils.TEST_TENANT, TestUtils.getUber(),
            TestEdge.builder().tenantId(TestUtils.NULL_UUID).build());
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void updateEdge_associatedAssetNotAccessible() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork(), NetworkUtils.createNetwork());
        assertThat(networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(), networks))
            .isEqualTo(networks.size());

        Edge edge = NetworkUtils.createEdge(networks.get(0).getId(), networks.get(1).getId(), Direction.UNDIRECTED,
            data.get("E1_S1_Seg1_Asset1").getId());

        networkPersistencyService.updateEdge(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), edge);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void updateEdge_sourceNotAccessible() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork(data.get("E1_S1_Seg1_Asset2").getId()),
            NetworkUtils.createNetwork());
        assertThat(networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(), networks))
            .isEqualTo(networks.size());

        Edge edge = NetworkUtils.createEdge(networks.get(0).getId(), networks.get(1).getId(), Direction.UNDIRECTED,
            data.get("E1_S1_Seg1_Asset1").getId());

        //Required Permissions: E1_S1_Seg1_Asset1 + E1_S1_Seg1_Asset2
        //Given Permissions: E1_S1_Seg1_Asset1

        networkPersistencyService.updateEdge(TestUtils.TEST_TENANT,
            Arrays.asList(data.get("E1_S1_Seg1_Asset1").getId()), edge);
    }

    @Test
    @Transactional
    public void updateEdge_asAssetNode_noUpdatesOnReferences() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> assetData = AssetUtils.setupData(assetTypePersistencyService,
            assetPersistencyService);
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);

        List<Edge> edges = networkPersistencyService.getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-E-parent-of-A,B,C").getId(), null);
        assertThat(edges).hasSize(1);
        Edge oldEdge = edges.get(0);
        EdgeEntity tobeUpdated = new EdgeEntity();
        BeanUtils.copyProperties(oldEdge, tobeUpdated);

        tobeUpdated.setName("updatedName");
        tobeUpdated.setDescription("updated Description");
        tobeUpdated.setAssetId(null);
        tobeUpdated.setSource(null);
        tobeUpdated.setTarget(null);
        // tobeUpdated.setAssetId(assetData.get("E1_S1_Seg1_Asset1").getId());
        tobeUpdated.setDirection(Direction.BIDIRECTIONAL);

        assertThat(networkPersistencyService.updateEdge(TestUtils.TEST_TENANT, TestUtils.getUber(), tobeUpdated))
            .isEqualTo(1);

        Edge updatedEdge = networkPersistencyService.getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-E-parent-of-A,B,C").getId(), null).get(0);

        assertThat(updatedEdge.getName()).isEqualTo(tobeUpdated.getName());
        assertThat(updatedEdge.getDescription()).isEqualTo(tobeUpdated.getDescription());
        assertThat(updatedEdge.getDirection()).isEqualTo(tobeUpdated.getDirection());
        // assert that these haven't changed
        assertThat(updatedEdge.getAssetId()).isEqualTo(oldEdge.getAssetId());
        assertThat(updatedEdge.getTarget()).isEqualTo(oldEdge.getTarget());
        assertThat(updatedEdge.getSource()).isEqualTo(oldEdge.getSource());
    }

    @Test
    @Transactional
    public void updateEdge_asAssetNode_updateSourceAndTargetOnly() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> assetData = AssetUtils.setupData(assetTypePersistencyService,
            assetPersistencyService);
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);

        List<Edge> edges = networkPersistencyService.getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-E-parent-of-A,B,C").getId(), null);
        assertThat(edges).hasSize(1);
        Edge oldEdge = edges.get(0);
        EdgeEntity tobeUpdated = new EdgeEntity();
        BeanUtils.copyProperties(oldEdge, tobeUpdated);

        tobeUpdated.setName("updatedName");
        tobeUpdated.setDescription("updated Description");
        tobeUpdated.setAssetId(null);
        tobeUpdated.setSource(oldEdge.getTarget());
        tobeUpdated.setTarget(oldEdge.getSource());
        // tobeUpdated.setAssetId(assetData.get("E1_S1_Seg1_Asset1").getId());
        tobeUpdated.setDirection(Direction.BIDIRECTIONAL);

        assertThat(networkPersistencyService.updateEdge(TestUtils.TEST_TENANT, TestUtils.getUber(), tobeUpdated))
            .isEqualTo(1);

        Edge updatedEdge = networkPersistencyService.getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-E-parent-of-A,B,C").getId(), null).get(0);

        assertThat(updatedEdge.getName()).isEqualTo(tobeUpdated.getName());
        assertThat(updatedEdge.getDescription()).isEqualTo(tobeUpdated.getDescription());
        assertThat(updatedEdge.getDirection()).isEqualTo(tobeUpdated.getDirection());
        assertThat(updatedEdge.getSource()).isEqualTo(tobeUpdated.getSource());
        assertThat(updatedEdge.getTarget()).isEqualTo(tobeUpdated.getTarget());
        // assert that these haven't changed
        assertThat(updatedEdge.getAssetId()).isEqualTo(oldEdge.getAssetId());
    }

    @Test
    @Transactional
    public void updateEdge_asAssetNode_BusinessObjOnly() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> assetData = AssetUtils.setupData(assetTypePersistencyService,
            assetPersistencyService);
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);

        List<Edge> edges = networkPersistencyService.getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-E-parent-of-A,B,C").getId(), null);
        assertThat(edges).hasSize(1);
        Edge oldEdge = edges.get(0);
        EdgeEntity tobeUpdated = new EdgeEntity();
        BeanUtils.copyProperties(oldEdge, tobeUpdated);

        tobeUpdated.setName("updatedName");
        tobeUpdated.setDescription("updated Description");
        tobeUpdated.setAssetId(assetData.get("E1_S1_Seg1_Asset1").getId());
        tobeUpdated.setSource(null);
        tobeUpdated.setTarget(null);
        tobeUpdated.setDirection(Direction.BIDIRECTIONAL);

        assertThat(networkPersistencyService.updateEdge(TestUtils.TEST_TENANT, TestUtils.getUber(), tobeUpdated))
            .isEqualTo(1);

        Edge updatedEdge = networkPersistencyService.getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-E-parent-of-A,B,C").getId(), null).get(0);

        assertThat(updatedEdge.getName()).isEqualTo(tobeUpdated.getName());
        assertThat(updatedEdge.getDescription()).isEqualTo(tobeUpdated.getDescription());
        assertThat(updatedEdge.getDirection()).isEqualTo(tobeUpdated.getDirection());
        assertThat(updatedEdge.getAssetId()).isEqualTo(tobeUpdated.getAssetId());
        // assert that these haven't changed
        assertThat(updatedEdge.getSource()).isEqualTo(oldEdge.getSource());
        assertThat(updatedEdge.getTarget()).isEqualTo(oldEdge.getTarget());
    }

    @Test
    @Transactional
    public void updateEdge_asAssetNode_updateAllRefs() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> assetData = AssetUtils.setupData(assetTypePersistencyService,
            assetPersistencyService);
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);

        List<Edge> edges = networkPersistencyService.getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-E-parent-of-A,B,C").getId(), null);
        assertThat(edges).hasSize(1);
        Edge oldEdge = edges.get(0);
        EdgeEntity tobeUpdated = new EdgeEntity();
        BeanUtils.copyProperties(oldEdge, tobeUpdated);

        tobeUpdated.setName("updatedName");
        tobeUpdated.setDescription("updated Description");
        tobeUpdated.setAssetId(assetData.get("E1_S1_Seg1_Asset1").getId());
        tobeUpdated.setSource(oldEdge.getTarget());
        tobeUpdated.setTarget(oldEdge.getSource());
        tobeUpdated.setDirection(Direction.BIDIRECTIONAL);

        assertThat(networkPersistencyService.updateEdge(TestUtils.TEST_TENANT, TestUtils.getUber(), tobeUpdated))
            .isEqualTo(1);

        Edge updatedEdge = networkPersistencyService.getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-E-parent-of-A,B,C").getId(), null).get(0);

        assertThat(updatedEdge.getName()).isEqualTo(tobeUpdated.getName());
        assertThat(updatedEdge.getDescription()).isEqualTo(tobeUpdated.getDescription());
        assertThat(updatedEdge.getDirection()).isEqualTo(tobeUpdated.getDirection());
        assertThat(updatedEdge.getSource()).isEqualTo(tobeUpdated.getSource());
        assertThat(updatedEdge.getTarget()).isEqualTo(tobeUpdated.getTarget());
        assertThat(updatedEdge.getAssetId()).isEqualTo(tobeUpdated.getAssetId());
        assertThat(updatedEdge.getSource()).isEqualTo(tobeUpdated.getSource());
    }

    @Test
    @Transactional
    public void deleteNetworkById() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        List<Network> networkHierarchy = networkPersistencyService.deleteNetworkById(TestUtils.TEST_TENANT,
            TestUtils.getUber(), data.get("network-E-parent-of-A,B,C").getId());

        Network network = networkPersistencyService.getNetworkById(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-B-A1,A4,A5-D").getId());
        assertThat(networkHierarchy.size()).isEqualTo(5);
        assertThat(network).isNull();
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void deleteNetworkById_NonExisting() throws PersistencyServiceException {
        networkPersistencyService.deleteNetworkById(TestUtils.TEST_TENANT, TestUtils.getUber(),
            UUID.randomUUID().toString());
    }

    @Test
    @Transactional
    public void removeAssetsFromNetwork() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Set<String> assetIds = new HashSet<>();
        assetIds.add(data.get("A1").getId());
        assertThat(networkPersistencyService.getNodesByAssetIdsForNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-A-A1,A2,A3").getId(), assetIds)).hasSize(1);
        networkPersistencyService.removeAssetsFromNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-A-A1,A2,A3").getId(), assetIds);
        assertThat(networkPersistencyService.getNodesByAssetIdsForNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-A-A1,A2,A3").getId(), assetIds)).hasSize(0);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void removeAssetsFromNetwork_emptyAssetIds() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Set<String> assetIds = new HashSet<>();
        networkPersistencyService.removeAssetsFromNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-A-A1,A2,A3").getId(), assetIds);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void removeAssetsFromNetwork_invalidIDs() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Set<String> assetIds = new HashSet<>();
        assetIds.add(data.get("A1").getId());
        assetIds.add(UUID.randomUUID().toString());
        networkPersistencyService.removeAssetsFromNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-A-A1,A2,A3").getId(), assetIds);
    }

    @Test
    @Transactional
    public void removeSubNetworksFromNetwork() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Set<String> networkIds = new HashSet<>();
        networkIds.add(data.get("network-D-empty-child-of-B").getId());
        assertThat(networkPersistencyService
            .getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(), data.get("network-B-A1,A4,A5-D").getId(),
                null)).hasSize(3);
        networkPersistencyService.removeChildrenFromNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-B-A1,A4,A5-D").getId(), networkIds);
        assertThat(networkPersistencyService
            .getNetworkEdges(TestUtils.TEST_TENANT, TestUtils.getUber(), data.get("network-B-A1,A4,A5-D").getId(),
                null)).hasSize(2);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void removeSubNetworksFromNetwork_emptyNetworKIds() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Set<String> networkIds = new HashSet<>();
        networkPersistencyService.removeChildrenFromNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-B-A1,A4,A5-D").getId(), networkIds);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void removeSubNetworksFromNetwork_invalidIDs() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);
        Set<String> networkIds = new HashSet<>();
        networkIds.add(data.get("network-D-empty-child-of-B").getId());  // valid
        networkIds.add(UUID.randomUUID().toString());                    // invalid
        networkPersistencyService.removeChildrenFromNetwork(TestUtils.TEST_TENANT, TestUtils.getUber(),
            data.get("network-B-A1,A4,A5-D").getId(), networkIds);
    }
}

