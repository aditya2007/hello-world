/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.Sets;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetHierarchy;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.config.EntityTestAuditor;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.model.TestAssetInstance;
import com.ge.apm.alm.persistence.jpa.model.TestTag;
import com.ge.apm.alm.persistence.jpa.utils.GroupUtils;
import com.ge.apm.alm.persistence.jpa.utils.TagPredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUnPrivileged;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.assertj.core.api.Fail.failBecauseExceptionWasNotThrown;

/**
 * Tests the JPA Persistency Layer
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetPersistSvcTests {

    private static final String MY_ENTERPRISE_TYPE = "MyEnterpriseType";

    private static final String MY_SITE_TYPE = "MySiteType";

    private static final String MY_SEGMENT_TYPE = "MySegmentType";

    private static final String MY_ASSET_TYPE = "MyAssetType";

    private static final String MY_ASSET_SUB_TYPE = "MyAssetSubType";

    private static final String MY_TAG_TYPE = "MyTagType";

    private static final String E1 = "E1";

    private static final String E1_S1 = "E1_S1";

    private static final String E1_S1_SEG1 = "E1_S1_Seg1";

    private static final String E1_S1_SEG1_ASSET1 = "E1_S1_Seg1_Asset1";

    private static final String E1_S1_SEG1_ASSET2 = "E1_S1_Seg1_Asset2";

    private static final String E2 = "E2";

    private static final String E2_S1 = "E2_S1";

    private static final String E2_S1_SEG1 = "E2_S1_Seg1";

    private static final String E3 = "E3";

    private static final String E3_S1 = "E3_S1";

    private static final String ENTERPRISE_TYPE = OOTBCoreTypesIdLookup.EnterpriseType.name();

    private static final String TURBINE_TYPE = "TurbineType";

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private TagPersistencyService tagPersistencyService;

    @Autowired
    private GroupPersistencyService groupPersistencyService;

    @Autowired
    private AssetEventPersistencyService assetEventPersistencyService;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    @After
    public void tearDown() {
        TestUtils.destroyAssetUserPolicies();
    }

    @Test(expected = IllegalArgumentException.class)
    public void createAsset_tenantIdMismatch() throws PersistencyServiceException {
        assetPersistencyService.createAsset(TestUtils.TEST_TENANT, TestUtils.getUber(),
            AssetInstanceEntity.builder().tenantId(TestUtils.NULL_UUID).build());
    }

    @Test
    @Transactional
    public void getChildAssets_createAssetGroupTest() throws IOException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);
        String enterpriseTypeId = data.get(MY_ENTERPRISE_TYPE).getId();
        String siteTypeId = data.get(MY_SITE_TYPE).getId();
        String segmentTypeId = data.get(MY_SEGMENT_TYPE).getId();
        String assetTypeId = data.get(MY_ASSET_TYPE).getId();
        Asset e1 = (Asset) data.get(E1);
        String e1Id = data.get(E1).getId();
        String e1S1Seg1Id = data.get(E1_S1_SEG1).getId();

        Asset e2 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            enterpriseTypeId, null, E2);
         Asset e2S1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, getUnPrivileged(e2), siteTypeId,
            e2.getId(), E2_S1);
        Asset e2S1Seg1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, getUnPrivileged(e2),
            segmentTypeId, e2S1.getId(), E2_S1_SEG1);
        TestUtils.createAssetInstanceAndAssert(assetPersistencyService, getUnPrivileged(e2), assetTypeId,
            e2S1Seg1.getId(), "E2_S1_Seg1_Asset1");

        Asset e3 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            enterpriseTypeId, null, E3);
        Asset e3S1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, getUnPrivileged(e3), siteTypeId,
            e3.getId(), E3_S1);
        Asset e3S1Seg1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, getUnPrivileged(e3),
            segmentTypeId, e3S1.getId(), "E3_S1_Seg1");
        Asset e3S1Seg1Asset1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, getUnPrivileged(e3),
            assetTypeId, e3S1Seg1.getId(), "E3_S1_Seg1_Asset1");

        assertThat(e3S1Seg1Asset1.getSuperTypesArray()).hasSize(2).containsOnly(assetTypeId,
            OOTBCoreTypesIdLookup.AssetType.getId());
        assertThat(e3S1Seg1Asset1.getLastModifiedDate()).isBefore(OffsetDateTime.now());

        AssetPredicate predicate = AssetPredicate.builder().type(TypePredicate.builder().build()).build();

        //Getting Child Assets of a given Enterprise
        predicate.getType().setIds(Collections.singleton(assetTypeId));
        assertThat(assetPersistencyService
            .getChildAssets(TestUtils.TEST_TENANT, getUnPrivileged(e1, e2S1), e3S1.getId(), predicate)).hasSize(
            0); //Nothing should be returned since user does not have permissions on e3

        //Nothing should be returned since user does not have permissions on e2 either
        assertThat(
            assetPersistencyService.getChildAssets(TestUtils.TEST_TENANT, getUnPrivileged(e1, e2S1), e2.getId(), predicate))
            .hasSize(0);

        predicate = AssetPredicate.builder().parent(ParentPredicate.builder().ids(Sets.newHashSet(e1Id))
            .deepSearch(true).build()).build();
        assertThat(assetPersistencyService.getChildAssets(TestUtils.TEST_TENANT, getUnPrivileged(e1, e2S1), e1Id, predicate))
            .hasSize(4).extracting(Asset::getName).containsOnly(E1_S1, E1_S1_SEG1, E1_S1_SEG1_ASSET1, E1_S1_SEG1_ASSET2)
            .doesNotContain(E3_S1);

        //Get all children of MyAssetType (of direct type)
        predicate = AssetPredicate.builder().type(
            TypePredicate.builder().ids(Collections.singleton(assetTypeId)).build()).build();
        assertThat(
            assetPersistencyService.getChildAssets(TestUtils.TEST_TENANT, getUnPrivileged(e1, e2S1), e1S1Seg1Id, predicate))
            .hasSize(1).extracting(Asset::getName).containsOnly(E1_S1_SEG1_ASSET1);

        // Get all children of MyAssetType (of direct type and as well as subtypes of MyAssetType, in this case
        // MyAssetSubType
        predicate.getType().setDeepSearch(true);
        assertThat(
            assetPersistencyService.getChildAssets(TestUtils.TEST_TENANT, getUnPrivileged(e1, e2S1), e1S1Seg1Id, predicate))
            .hasSize(2).extracting(Asset::getName).containsOnly(E1_S1_SEG1_ASSET1, E1_S1_SEG1_ASSET2);

        // Give permissions to only E3->S1->Seg1, expect results e3_s1_seg1 and e3_s1_seg1_asset1 without any type spec
        predicate = AssetPredicate.builder().build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(e3S1Seg1), predicate)).hasSize(
            2).extracting(Asset::getName).containsOnly(e3S1Seg1.getName(), e3S1Seg1Asset1.getName());

        //NO ACLS Permissions -> Scope is every asset within a Tenant
        predicate = AssetPredicate.builder().type(
            TypePredicate.builder().parent(ParentPredicate.builder().ids(Sets.newHashSet(assetTypeId)).build()).build())
            .build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1).
            extracting(Asset::getName).containsOnly(E1_S1_SEG1_ASSET2);
        predicate.getType().getParent().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1).
            extracting(Asset::getName).containsOnly(E1_S1_SEG1_ASSET2);

        //Delete Enterprise E1 should fail due to authorization
        try {
            assetPersistencyService.deleteAsset(TestUtils.TEST_TENANT, getUnPrivileged(e3S1Seg1), e1.getId());
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (ObjectNotFoundException onfe) {
            assertThat(onfe).isInstanceOf(ObjectNotFoundException.class).hasMessageContaining(e1Id);
        } catch (DataIntegrityViolationException exp) {
            fail("Not expecting to fail with Data Integrity voilation");
        } catch (PersistencyServiceException pse) {
            fail("Not expecting to fail with PersistencyServiceException");
        }

        //Delete Enterprise E1 should fail due to E1 has children..
        try {
            assetPersistencyService.deleteAsset(TestUtils.TEST_TENANT, getUnPrivileged(e1), e1.getId());
            failBecauseExceptionWasNotThrown(DataIntegrityViolationException.class);
        } catch (DataIntegrityViolationException exp) {
            assertThat(exp).isInstanceOf(DataIntegrityViolationException.class).hasMessageContaining(
                "Asset has children or references to it. Hence cannot be deleted");
        } catch (PersistencyServiceException pse) {
            fail("Not expecting to fail with PersistencyServiceException", pse);
        }

        //NOTE: Transaction has already rolled back due to DataIntegrityViolationException. No more tests can be
        // added after this.
    }

    @Test
    @Transactional
    public void createAndUpdateAsset_verifyDenormalizations() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);
        Asset e1S1Seg1Asset1 = (Asset) data.get(E1_S1_SEG1_ASSET1);
        Asset e1S1Seg1Asset2 = (Asset) data.get(E1_S1_SEG1_ASSET2);
        String e1Id = data.get(E1).getId();
        String e1S1Id = data.get(E1_S1).getId();

        //Asserting that the Super Types are properly Denormalized
        assertThat(e1S1Seg1Asset2.getSuperTypesArray()).hasSize(3).containsOnly(data.get(MY_ASSET_SUB_TYPE).getId(),
            data.get(MY_ASSET_TYPE).getId(), SeedOOTBData.ROOT_ASSET_TYPE_ID);
        assertThat(e1S1Seg1Asset1.getAncestorsArray()).hasSize(3).containsOnly(data.get(E1_S1_SEG1).getId(), e1S1Id,
            e1Id);
        //Creating instances based on above types.. E2 Hierarchy -- Check denormalization after move
        //--------------------------------------------------------------------------
        Asset e2 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            data.get(MY_ENTERPRISE_TYPE).getId(), null, E2);
        Asset e2S1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, getUnPrivileged(e1Id, e2.getId()),
            data.get(MY_SITE_TYPE).getId(), e2.getId(), E2_S1);

        // Update e2S1 without changing parent, but narrow down the permission to e2S1 itself
        TestAssetInstance updateE2S1 = new TestAssetInstance();
        BeanUtils.copyProperties(e2S1, updateE2S1);
        updateE2S1.setDescription("updated " + updateE2S1.getDescription());
        assertThat(assetPersistencyService
            .updateAsset(TestUtils.TEST_TENANT, Collections.singletonList(e2S1.getId()), updateE2S1)).isNotNull();
        assertThat(assetPersistencyService
            .getAssetById(TestUtils.TEST_TENANT, Collections.singletonList(e2S1.getId()), updateE2S1.getId())
            .getDescription()).isEqualTo(updateE2S1.getDescription());

        //Moving Segment e1_s1_seg1 from E1 hierarchy to E2 hierarchy
        TestAssetInstance testAssetInstance = new TestAssetInstance();
        BeanUtils.copyProperties(data.get(E1_S1_SEG1), testAssetInstance);
        testAssetInstance.setParentId(e2S1.getId());
        Asset segUpdated = assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, getUnPrivileged(e1Id, e2.getId()),
            testAssetInstance);
        assertThat(segUpdated.getAncestorsArray()).hasSize(2).containsExactly(e2.getId(), e2S1.getId());
        assertThat(segUpdated.getLastModifiedBy()).isEqualTo(EntityTestAuditor.TEST_USER);

        Asset movedAsset = assetPersistencyService.getAssetById(TestUtils.TEST_TENANT, getUnPrivileged(e1Id, e2.getId()),
            e1S1Seg1Asset1.getId());
        assertThat(movedAsset.getAncestorsArray()).hasSize(3).containsExactly(e2.getId(), e2S1.getId(),
            segUpdated.getId());
        assertThat(movedAsset.getLastModifiedBy()).isEqualTo(EntityTestAuditor.TEST_USER);

        //Move back again and test
        testAssetInstance.setParentId(e1S1Id);
        segUpdated = assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, getUnPrivileged(e1Id, e2.getId()),
            testAssetInstance);
        assertThat(segUpdated.getAncestorsArray()).hasSize(2).containsExactly(e1Id, e1S1Id);

        movedAsset = assetPersistencyService.getAssetById(TestUtils.TEST_TENANT, getUnPrivileged(e1Id, e2.getId()),
            e1S1Seg1Asset2.getId());
        assertThat(movedAsset.getAncestorsArray()).hasSize(3).containsExactly(e1Id, e1S1Id, segUpdated.getId());
    }

    @Test
    @Transactional
    public void getChildAssets_verifyCoreTypeName() throws IOException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);

        //Asserting the Assets returned from Query has Core Type Name
        AssetPredicate predicate = AssetPredicate.builder().type(
            TypePredicate.builder().ids(Collections.singleton(data.get(MY_ASSET_TYPE).getId())).build()).build();
        List<Asset> assets = assetPersistencyService.getChildAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get(E1)),
            data.get(E1_S1_SEG1).getId(), predicate);
        assertThat(assets).hasSize(1).
            extracting(Asset::getName).containsOnly(E1_S1_SEG1_ASSET1);
        Asset asset = assets.get(0); //first asset
        assertThat(asset.getCoreAssetTypeName()).isEqualTo("AssetType");

        // verify case-insensitive search
        assertThat(
            assetPersistencyService.getAssetBySourceKey(TestUtils.TEST_TENANT, TestUtils.getUber(), ENTERPRISE_TYPE, E1)
                .getSourceKey()).isEqualTo(E1);
        assertThat(assetPersistencyService
            .getAssetBySourceKey(TestUtils.TEST_TENANT, TestUtils.getUber(), ENTERPRISE_TYPE,
                E1.toLowerCase(Locale.getDefault())).getSourceKey()).isEqualTo(E1);
        assertThat(assetPersistencyService
            .getAssetBySourceKey(TestUtils.TEST_TENANT, Collections.singletonList(data.get(E1).getId()),
                ENTERPRISE_TYPE, E1.toLowerCase(Locale.getDefault())).getSourceKey()).isEqualTo(E1);
        assertThat(assetPersistencyService
            .getAssetBySourceKey(TestUtils.TEST_TENANT, getUnPrivileged(), ENTERPRISE_TYPE,
                E1.toLowerCase(Locale.getDefault()))).isNull();
        assertThat(assetPersistencyService
            .getAssetBySourceKey(TestUtils.TEST_TENANT, TestUtils.getUber(), null, E1.toLowerCase(Locale.getDefault())))
            .isNull();
        assertThat(assetPersistencyService
            .getAssetBySourceKey(TestUtils.TEST_TENANT, TestUtils.getUber(), ENTERPRISE_TYPE, null)).isNull();
    }

    @Test
    @Transactional
    public void getAssetsBySourceKeys() throws IOException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);

        assertThat(assetPersistencyService.getAssetsBySourceKeys(TestUtils.TEST_TENANT, TestUtils.getUber(), null,
            Arrays.asList(E1_S1_SEG1_ASSET1, E1_S1_SEG1_ASSET2))).hasSize(0);
        assertThat(assetPersistencyService
            .getAssetsBySourceKeys(TestUtils.TEST_TENANT, TestUtils.getUber(), OOTBCoreTypesIdLookup.AssetType.name(),
                Collections.emptyList())).hasSize(0);
        assertThat(assetPersistencyService.getAssetsBySourceKeys(TestUtils.TEST_TENANT, TestUtils.getUber(), "", null))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssetsBySourceKeys(TestUtils.TEST_TENANT, TestUtils.getUber(), OOTBCoreTypesIdLookup.AssetType.name(),
                Arrays.asList(E1_S1_SEG1_ASSET1, E1_S1_SEG1_ASSET2))).hasSize(2).extracting(Asset::getSourceKey)
            .containsOnly(E1_S1_SEG1_ASSET1, E1_S1_SEG1_ASSET2);
        assertThat(assetPersistencyService.getAssetsBySourceKeys(TestUtils.TEST_TENANT,
            Arrays.asList(data.get(E1_S1).getId(), data.get(E1_S1_SEG1).getId()),
            OOTBCoreTypesIdLookup.AssetType.name(), Arrays.asList(E1_S1_SEG1_ASSET1, E1_S1_SEG1_ASSET2))).hasSize(2)
            .extracting(Asset::getSourceKey).containsOnly(E1_S1_SEG1_ASSET1, E1_S1_SEG1_ASSET2);
        assertThat(assetPersistencyService.getAssetsBySourceKeys(TestUtils.TEST_TENANT, getUnPrivileged(),
            OOTBCoreTypesIdLookup.AssetType.name(), Arrays.asList(E1_S1_SEG1_ASSET1, E1_S1_SEG1_ASSET2))).hasSize(0);

        assertThat(assetPersistencyService
            .getAssetsBySourceKeys(TestUtils.TEST_TENANT, TestUtils.getUber(), OOTBCoreTypesIdLookup.SegmentType.name(),
                Arrays.asList(E1_S1_SEG1_ASSET1, E1_S1_SEG1_ASSET2))).hasSize(0);
        assertThat(assetPersistencyService.getAssetsBySourceKeys(TestUtils.TEST_TENANT,
            Arrays.asList(data.get(E1_S1).getId(), data.get(E1_S1_SEG1).getId()),
            OOTBCoreTypesIdLookup.SegmentType.name(), Arrays.asList(E1_S1_SEG1_ASSET1, E1_S1_SEG1_ASSET2))).hasSize(0);
    }

    @Test
    @Transactional
    public void getAssetsBySourceKeysSqlInjection() throws IOException {
        setupAssetData(assetTypePersistencyService, assetPersistencyService);
        List<String> sourcekeys = new ArrayList<>();
        sourcekeys.add("junk') OR 'x'='x' --");
        assertThat(assetPersistencyService
            .getAssetsBySourceKeys(TestUtils.TEST_TENANT, TestUtils.getUber(), OOTBCoreTypesIdLookup.AssetType.name(),
                sourcekeys)).hasSize(0);
    }

    @Test
    @Transactional
    public void getCoreAssetTypeName() throws IOException {
        AssetType enterpriseType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID, MY_ENTERPRISE_TYPE);
        assertThat(TestUtils
            .createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), enterpriseType.getId(), null,
                E1).getCoreAssetTypeName()).isEqualTo(ENTERPRISE_TYPE);
        assertThat(
            assetPersistencyService.getAssetBySourceKey(TestUtils.TEST_TENANT, TestUtils.getUber(), ENTERPRISE_TYPE, E1)
                .getSourceKey()).isEqualTo(E1);
    }

    @Test(expected = UnsupportedOperationException.class)
    @Transactional
    public void getAssets_byParent() throws IOException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);

        AssetPredicate predicate = AssetPredicate.builder().name(E1_S1_SEG1_ASSET1).parent(
            ParentPredicate.builder().name(E1).deepSearch(true).build()).build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get(E1)), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly(E1_S1_SEG1_ASSET1);

        predicate.getParent().setName(E2);
        List<Asset> assets = assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get(E1)), predicate);
        assertThat(assets).hasSize(0);

        //We cannot make changes to the list from outside the persistency layer. The list of assets is unmodifiable.
        assets.add((Asset) data.get(E1_S1_SEG1));
    }

    //update tests

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void updateAssets_nullOrEmptyIdTest() throws PersistencyServiceException {
        // the asset does not exist at all
        TestAssetInstance testAssetInstance = TestAssetInstance.builder().name("E1_S1_Seg1_Asset1_Modified").build();
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), testAssetInstance);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void updateAsset_assetNotAccessible() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);
        Asset e2 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            data.get(MY_ENTERPRISE_TYPE).getId(), null, E2);

        //Test1 - user does not have permission on e1_asset1 (since it is under E1, whereas accessile resources is E2)
        TestAssetInstance testAssetInstance = new TestAssetInstance();
        BeanUtils.copyProperties(data.get(E1_S1_SEG1_ASSET1), testAssetInstance);
        testAssetInstance.setName("E1_S1_Seg1_Asset1_Modified");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, getUnPrivileged(e2), testAssetInstance);
        //NOTE: Transaction has already rolled back due to DataIntegrityViolationException. No more tests can be
        // added after this.
    }

    @Test
    @Transactional
    public void geolocationTest() throws IOException {
        AssetType enterpriseType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID, MY_ENTERPRISE_TYPE);
        Asset e1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            enterpriseType.getId(), null, E1);
        JsonNode expectedGeolocation = TestUtils.createGeolocation();
        assertThat(e1.getGeolocation()).isEqualTo(expectedGeolocation);
    }

    @Test
    @Transactional
    public void updateAssets_moveParentTest() throws IOException {

        //Creating Custom Enterprise Type
        AssetType enterpriseType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID, MY_ENTERPRISE_TYPE);
        //Creating Custom Asset Type
        AssetType assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, MY_ASSET_TYPE);

        //Creating instances based on above types..
        Asset e1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            enterpriseType.getId(), null, E1);
        Asset e2 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            enterpriseType.getId(), null, E2);

        //creating an assets under E1
        Asset e1Asset1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, getUnPrivileged(e1),
            assetType.getId(), e1.getId(), E1_S1_SEG1_ASSET1);
        assertThat(e1Asset1.getAncestorsArray()).hasSize(1).containsOnly(e1.getId());
        Asset e2Asset2 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, getUnPrivileged(e2),
            assetType.getId(), e2.getId(), "E2_Asset2");
        assertThat(e2Asset2.getAncestorsArray()).hasSize(1).containsOnly(e2.getId());

        //Test1 - Update e1_asset1 and assert name changed
        TestAssetInstance testAssetInstance = new TestAssetInstance();
        BeanUtils.copyProperties(e1Asset1, testAssetInstance);
        testAssetInstance.setName("E1_S1_Seg1_Asset1_Modified");
        try {
            assertThat(
                assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), testAssetInstance)
                    .getName()).isEqualTo("E1_S1_Seg1_Asset1_Modified");
            Asset found = assetPersistencyService.getAssetById(TestUtils.TEST_TENANT, TestUtils.getUber(),
                testAssetInstance.getId());
            assertThat(found.getAncestorsArray()).hasSize(1).containsOnly(testAssetInstance.getParentId());
        } catch (PersistencyServiceException pse) {
            fail("Not expecting to fail with PersistencyServiceException");
        }

        //moving to null parent.
        testAssetInstance = new TestAssetInstance();
        BeanUtils.copyProperties(e2Asset2, testAssetInstance);
        testAssetInstance.setName("Null_Asset2_Modified");
        testAssetInstance.setParentId(null);
        try {
            assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), testAssetInstance);
            Asset found = assetPersistencyService.getAssetById(TestUtils.TEST_TENANT, TestUtils.getUber(),
                testAssetInstance.getId());
            assertThat(found.getAncestorsArray()).hasSize(0);
        } catch (PersistencyServiceException pse) {
            fail("Not expecting to fail with PersistencyServiceException");
        }

        //moving orphan back under e1Asset1
        testAssetInstance = new TestAssetInstance();
        BeanUtils.copyProperties(e2Asset2, testAssetInstance);
        testAssetInstance.setName("E2_Asset2_Modified");
        testAssetInstance.setParentId(e1Asset1.getId());
        try {
            assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), testAssetInstance);
            Asset found = assetPersistencyService.getAssetById(TestUtils.TEST_TENANT, TestUtils.getUber(),
                testAssetInstance.getId());
            assertThat(found.getAncestorsArray()).hasSize(2).containsOnly(e1Asset1.getParentId(),
                testAssetInstance.getParentId());
        } catch (PersistencyServiceException ex) {
            fail("Not expecting to fail with PersistencyServiceException", ex);
        }

        //moving to non-accessible parent. Should fail with Authorization
        testAssetInstance = new TestAssetInstance();
        BeanUtils.copyProperties(e1Asset1, testAssetInstance);
        testAssetInstance.setName("E1_S1_Seg1_Asset1_Modified");
        testAssetInstance.setParentId(e2.getId());
        try {
            assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, getUnPrivileged(e1), testAssetInstance);
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (ObjectNotFoundException exp) {
            assertThat(exp).isInstanceOf(ObjectNotFoundException.class);
        } catch (PersistencyServiceException pse) {
            fail("Not expecting to fail with PersistencyServiceException");
        }
        //NOTE: Transaction has already rolled back due to DataIntegrityViolationException. No more tests can be
        // added after this.
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void updateAsset_changeParent() throws IOException, PersistencyServiceException {
        AssetType enterpriseType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID, MY_ENTERPRISE_TYPE);
        TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_ASSET_TYPE_ID, MY_ASSET_TYPE);

        Asset e1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            enterpriseType.getId(), null, E1);

        // as Uber, create e2 without parent, update it to have e1 as parent
        Asset e2 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            enterpriseType.getId(), null, E2);
        assertThat(e2.getAncestorsArray().size()).isEqualTo(0);
        ((AssetInstanceEntity) e2).setParentId(e1.getId());
        assertThat(assetPersistencyService.updateAsset(e2.getTenantId(), TestUtils.getUber(), e2).getParentId())
            .isEqualTo(e2.getParentId());
        e2 = assetPersistencyService.getAssetById(TestUtils.TEST_TENANT, TestUtils.getUber(), e2.getId());
        assertThat(e2.getAncestorsArray()).hasSize(1).containsOnly(e1.getId());
        // as privileged user, create e3 without parent, update it to have e1 as parent
        Asset e3 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            enterpriseType.getId(), null, E3);
        ((AssetInstanceEntity) e3).setParentId(e2.getId());
        assertThat(assetPersistencyService.updateAsset(e3.getTenantId(), getUnPrivileged(e1, e3), e3))
            .isNotNull().extracting(Asset::getParentId).containsOnly(e3.getParentId());

        // create e4 as User without parent, update its parent to e1 as an unprivileged user, expect exception
        Asset e4 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            enterpriseType.getId(), null, "E4");
        ((AssetInstanceEntity) e4).setParentId(e1.getId());
        assetPersistencyService.updateAsset(e4.getTenantId(), getUnPrivileged(), e4);
    }

    //Delete Tests..
    @Test
    @Transactional
    public void deleteAssetInstancesRecursive() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);
        Asset e1 = (Asset) data.get(E1);
        Asset seg1 = (Asset) data.get(E1_S1_SEG1);

        // create a group of asset instances
        AssetGroup assetGroup = GroupUtils.createAssetGroup("AssetGroup", AssetGroupCategory.ASSET);
        AssetGroup createdAssetGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1), createdAssetGroup.getId(), Arrays
                .asList(GroupUtils.createAssetGroupItem(assetGroup.getId(), data.get("E1_S1_Seg1_Asset1").getId()),
                    GroupUtils.createAssetGroupItem(assetGroup.getId(), data.get("E1_S1_Seg1_Asset2").getId()))))
            .isEqualTo(2);
        assertThat(groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1), createdAssetGroup.getId())).hasSize(2);

        // create a group of tag instances
        AssetGroup tagGroup = GroupUtils.createAssetGroup("TagGroup", AssetGroupCategory.TAG);
        AssetGroup createdTagGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, tagGroup);
        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1), createdTagGroup.getId(), Arrays
                .asList(GroupUtils.createAssetGroupItem(tagGroup.getId(), data.get("e1_tag").getId()),
                    GroupUtils.createAssetGroupItem(tagGroup.getId(), data.get("seg1_tag").getId()),
                    GroupUtils.createAssetGroupItem(tagGroup.getId(), data.get("asset1_tag").getId())))).isEqualTo(3);
        assertThat(
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1), createdTagGroup.getId()))
            .hasSize(3);

        // create a correlation of asset tags
        AssetGroup tagCorrelationGroup = GroupUtils.createAssetGroup("TagCorrelation",
            AssetGroupCategory.TAG_CORRELATION);
        AssetGroup createdTagCorrelationGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT,
            tagCorrelationGroup);
        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1), createdTagCorrelationGroup.getId(),
                Arrays.asList(TagPredicateUtils
                        .newTagCorrelationItem((Tag) data.get("asset1_tag"), tagCorrelationGroup.getId(), 1),
                    TagPredicateUtils
                        .newTagCorrelationItem((Tag) data.get("asset1_tag2"), tagCorrelationGroup.getId(), 2))))
            .isEqualTo(2);
        assertThat(groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1), createdTagCorrelationGroup.getId())).hasSize(2);

        TagPredicate tagPredicate = TagPredicate.builder().parent(ParentPredicate.builder().ids(
            Sets.newHashSet(data.get("E1").getId())).deepSearch(true).build()).build();
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, getUnPrivileged(e1), tagPredicate)).hasSize(6);

        //E1, E1_S1, E1_S1_Seg1, E1_S1_Seg1_Asset1 and E1_S1_Seg1_Asset2
        //Each of the object above has a corresponding tag
        AssetHierarchy seg1Hierarchy = assetPersistencyService.deleteAssetRecursively(TestUtils.TEST_TENANT,
            getUnPrivileged(e1), seg1.getId(), "Test");
        assertThat(seg1Hierarchy.getCoreType()).isEqualTo(OOTBCoreTypesIdLookup.SegmentType);
        assertThat(seg1Hierarchy.getAssetCount()).isEqualTo(3);
        assertThat(seg1Hierarchy.getAsset().getId()).isEqualTo(data.get("E1_S1_Seg1").getId());
        assertThat(seg1Hierarchy.getChildren()).extracting(ah -> ah.getAsset().getName()).containsOnly(
            "E1_S1_Seg1_Asset1", "E1_S1_Seg1_Asset2");
        assertThat(seg1Hierarchy.getAssetGroups()).hasSize(0);
        assertThat(seg1Hierarchy.getTagGroups().keySet().iterator().next()).extracting(AssetGroup::getId).containsOnly(
            createdTagGroup.getId());
        assertThat(seg1Hierarchy.getTagGroups().values().iterator().next()).hasSize(1).extracting(
            AssetGroupItem::getObjectId).containsOnly(data.get("seg1_tag").getId());
        assertThat(seg1Hierarchy.getTagCorrelations()).hasSize(0);
        assertThat(seg1Hierarchy.getTags()).hasSize(1).extracting(Tag::getName).containsOnly("seg1_tag");

        Set<String> eventObjectIds = new HashSet<>();
        eventObjectIds.add(seg1Hierarchy.getAsset().getId());
        eventObjectIds.addAll(
            seg1Hierarchy.getAssetGroups().values().stream().map(AssetGroupItem::getId).collect(Collectors.toSet()));
        eventObjectIds.addAll(seg1Hierarchy.getTagGroups().values().stream().flatMap(List::stream)
            .map(AssetGroupItem::getId).collect(Collectors.toSet()));
        eventObjectIds.addAll(seg1Hierarchy.getTagCorrelations().values().stream().flatMap(List::stream)
            .map(AssetGroupItem::getId).collect(Collectors.toSet()));
        eventObjectIds.addAll(
            seg1Hierarchy.getTagCorrelations().keySet().stream().map(AssetGroup::getId).collect(Collectors.toSet()));
        eventObjectIds.addAll(seg1Hierarchy.getTags().stream().map(Tag::getId).collect(Collectors.toSet()));

        for (AssetHierarchy ah : seg1Hierarchy.getChildren()) {
            assertThat(ah.getCoreType()).isEqualTo(OOTBCoreTypesIdLookup.AssetType);
            assertThat(ah.getAssetCount()).isEqualTo(1);
            if (ah.getAsset().getName().equals("E1_S1_Seg1_Asset1")) {
                assertThat(ah.getTags()).hasSize(2).extracting(Tag::getId).containsOnly(data.get("asset1_tag").getId(),
                    data.get("asset1_tag2").getId());
                assertThat(ah.getTagCorrelations().keySet().iterator().next().getName()).isEqualTo(
                    createdTagCorrelationGroup.getName());
                assertThat(ah.getTagCorrelations().values().iterator().next()).hasSize(2).extracting(
                    AssetGroupItem::getObjectId).containsOnly(data.get("asset1_tag").getId(),
                    data.get("asset1_tag2").getId());
                assertThat(ah.getTagGroups().keySet().iterator().next()).extracting(AssetGroup::getId).containsOnly(
                    createdTagGroup.getId());
                assertThat(ah.getTagGroups().values().iterator().next()).hasSize(1).extracting(
                    AssetGroupItem::getObjectId).containsOnly(data.get("asset1_tag").getId());
            } else {
                assertThat(ah.getTags()).hasSize(1).extracting(Tag::getId).containsOnly(data.get("asset2_tag").getId());
                assertThat(ah.getTagCorrelations().values()).hasSize(0);
            }
            assertThat(ah.getAssetGroups().keySet().iterator().next()).extracting(AssetGroup::getId).containsOnly(
                createdAssetGroup.getId());
            assertThat(ah.getAssetGroups().values().iterator().next()).extracting(AssetGroupItem::getGroupId)
                .containsOnly(createdAssetGroup.getId());

            eventObjectIds.add(ah.getAsset().getId());
            eventObjectIds.addAll(
                ah.getAssetGroups().values().stream().map(AssetGroupItem::getId).collect(Collectors.toSet()));
            eventObjectIds.addAll(ah.getTagGroups().values().stream().flatMap(List::stream).map(AssetGroupItem::getId)
                .collect(Collectors.toSet()));
            eventObjectIds.addAll(ah.getTagCorrelations().values().stream().flatMap(List::stream)
                .map(AssetGroupItem::getId).collect(Collectors.toSet()));
            eventObjectIds.addAll(
                ah.getTagCorrelations().keySet().stream().map(AssetGroup::getId).collect(Collectors.toSet()));
            eventObjectIds.addAll(ah.getTags().stream().map(Tag::getId).collect(Collectors.toSet()));
        }

        // TODO: the following assertion only works when @Transactional is commented out
        // assertThat(
        //     assetEventPersistencyService.getEvents(TestUtils.TEST_TENANT, AssetEvent.Type.DELETE, eventObjectIds))
        //     .hasSize(eventObjectIds.size());

        assertThat(groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1), createdAssetGroup.getId())).hasSize(0);
        assertThat(
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1), createdTagGroup.getId()))
            .hasSize(1);
        try {
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1),
                createdTagCorrelationGroup.getId());
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (ObjectNotFoundException onfe) {
            // expeted, ignore
        }
        tagPredicate.getParent().setIds(Sets.newHashSet(data.get("E1_S1_Seg1").getId()));
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, getUnPrivileged(e1), tagPredicate)).hasSize(0);
        tagPredicate.getParent().setIds(Sets.newHashSet(data.get("E1").getId()));
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, getUnPrivileged(e1), tagPredicate)).hasSize(2);
        AssetHierarchy remainingE1Hierarchy = assetPersistencyService.deleteAssetRecursively(TestUtils.TEST_TENANT,
            getUnPrivileged(e1), e1.getId(), "Test");
        assertThat(remainingE1Hierarchy.getCoreType()).isEqualTo(OOTBCoreTypesIdLookup.EnterpriseType);
        assertThat(remainingE1Hierarchy.getAssetCount()).isEqualTo(2);
        assertThat(remainingE1Hierarchy.getAsset().getId()).isEqualTo(data.get("E1").getId());
        assertThat(remainingE1Hierarchy.getAssetGroups()).hasSize(0);
        assertThat(remainingE1Hierarchy.getTagGroups().keySet().iterator().next()).extracting(AssetGroup::getId)
            .containsOnly(createdTagGroup.getId());
        assertThat(remainingE1Hierarchy.getTagGroups().values().iterator().next()).hasSize(1).extracting(
            AssetGroupItem::getGroupId).containsOnly(createdTagGroup.getId());
        assertThat(remainingE1Hierarchy.getTagCorrelations()).hasSize(0);
        assertThat(remainingE1Hierarchy.getTags()).hasSize(1).extracting(Tag::getAssetId).containsOnly(
            data.get("E1").getId());
        assertThat(remainingE1Hierarchy.getChildren()).hasSize(1);
        for (AssetHierarchy ah : remainingE1Hierarchy.getChildren()) {
            assertThat(ah.getCoreType()).isEqualTo(OOTBCoreTypesIdLookup.SiteType);
            assertThat(ah.getAssetCount()).isEqualTo(1);
            assertThat(ah.getAsset().getId()).isEqualTo(data.get("E1_S1").getId());
            assertThat(ah.getAssetGroups()).hasSize(0);
            assertThat(ah.getTagGroups()).hasSize(0);
            assertThat(ah.getTagCorrelations()).hasSize(0);
            assertThat(ah.getTags()).hasSize(1).extracting(Tag::getId).containsOnly(data.get("s1_tag").getId());
        }

        assertThat(
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1), createdTagGroup.getId()))
            .hasSize(0);
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, getUnPrivileged(e1), tagPredicate)).hasSize(0);
    }

    //Delete Asset with Tags..
    @Test
    @Transactional
    public void deleteAssetWithTags() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);
        String e1Id = data.get(E1).getId();
        //E1, E1_S1, E1_S1_Seg1, E1_S1_Seg1_Asset1 and E1_S1_Seg1_Asset2
        Asset asset = (Asset) data.get("E1_S1_Seg1_Asset1");
        String name = "MyTag";

        Tag tag1 = TestTag.builder().
            id(UUID.randomUUID().toString()).tenantId(TestUtils.TEST_TENANT).assetId(asset.getId()).name(name)
            .sourceKey(name).tagType(data.get(MY_TAG_TYPE).getId()).tagCategory("SENSOR").build();
        tagPersistencyService.createTag(TestUtils.TEST_TENANT, getUnPrivileged(e1Id), tag1);
        try {
            assetPersistencyService.deleteAsset(TestUtils.TEST_TENANT, getUnPrivileged(e1Id), asset.getId());
            failBecauseExceptionWasNotThrown(DataIntegrityViolationException.class);
        } catch (DataIntegrityViolationException exp) {
            assertThat(exp).isInstanceOf(DataIntegrityViolationException.class);
        } catch (PersistencyServiceException pse) {
            fail("Not expecting to fail with PersistencyServiceException");
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void createAssets_tenantIdMismatch() throws PersistencyServiceException {
        assetPersistencyService.createAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), Arrays
            .asList(AssetInstanceEntity.builder().tenantId(TestUtils.TEST_TENANT).build(),
                AssetInstanceEntity.builder().tenantId(TestUtils.NULL_UUID).build()));
    }

    @Test
    @Transactional
    public void createAssets_withoutHierarchy() throws IOException, PersistencyServiceException {
        //Creating Custom Turbine Type
        AssetType turbineType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, TURBINE_TYPE);
        Asset assetInstance1 = TestUtils.createAssetInstance(turbineType.getId(), null, "SteamTurbineType_instance1");
        Asset assetInstance2 = TestUtils.createAssetInstance(turbineType.getId(), null, "SteamTurbineType_instance2");
        List<Asset> assets = Arrays.asList(assetInstance1, assetInstance2);

        try {
            //user with no privileges is attempting to create assets at root level..
            assertThat(assetPersistencyService.createAssets(TestUtils.TEST_TENANT, getUnPrivileged(), assets))
                .isEqualTo(assets.size());
            failBecauseExceptionWasNotThrown(PersistencyServiceException.class);
        } catch (PersistencyServiceException exp) {
            assertThat(exp).hasMessage("Assets without parent cannot be added with constrained hierarchies");
        }

        assertThat(assetPersistencyService.createAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), assets)).isEqualTo(
            assets.size());

        AssetPredicate qp = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.FULL).type(
            TypePredicate.builder().ids(Collections.singleton(turbineType.getId())).build()).build();
        List<Asset> found = assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), qp);
        for (Asset a : found) {
            assertThat(a.getAncestorsArray()).hasSize(0);
            assertThat(a.getSuperTypesArray()).hasSize(2).containsOnly(turbineType.getId(),
                turbineType.getSuperTypeId());
        }
    }

    @Test
    @Transactional
    public void createAssets_withHierarchy() throws IOException, PersistencyServiceException {
        //Creating Custom Turbine Type
        AssetType model = TestUtils.createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, TURBINE_TYPE);
        AssetType turbineType = assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT, model);

        Asset existingParent = assetPersistencyService.createAsset(TestUtils.TEST_TENANT, TestUtils.getUber(),
            TestUtils.createAssetInstance(turbineType.getId(), null, "ExistingParent"));
        assertThat(existingParent.getAncestorsArray()).hasSize(0);

        List<Asset> assets = new ArrayList<>();

        // create assets without parent and children
        int noParentNoChildrenCount = 3;
        for (int i = 0; i < noParentNoChildrenCount; i++) {
            assets.add(TestUtils.createAssetInstance(turbineType.getId(), null, "NoParentNoChildren_" + i));
        }

        // // create assets with existing parent, with or without children
        int hasExistingParentCount = 4;
        for (int i = 0; i < hasExistingParentCount; i++) {
            if (i % 2 == 0) {
                Asset a = TestUtils.createAssetInstance(turbineType.getId(), existingParent.getId(),
                    "HasExistingParentNoChildren_" + i);
                assets.add(a);
            } else {
                Asset a = TestUtils.createAssetInstance(turbineType.getId(), existingParent.getId(),
                    "HasExistingParentWithChildren_" + i);
                assets.add(a);
                Asset c = TestUtils.createAssetInstance(turbineType.getId(), a.getId(),
                    "ChildOfHasExistingParent_" + i);
                assets.add(c);
            }
        }

        // create assets without existing parent and have a hierarchy of children
        int hasHierarchyOfChildrenCount = 5;
        for (int i = 0; i < hasHierarchyOfChildrenCount; i++) {
            Asset parent = TestUtils.createAssetInstance(turbineType.getId(), null,
                "ParentOfHasHierarchyOfChildren_" + i);
            assets.add(parent);
            Asset child = TestUtils.createAssetInstance(turbineType.getId(), parent.getId(),
                "ChildHasHierarchyOfChildren_" + i);
            assets.add(child);
            Asset grandchild = TestUtils.createAssetInstance(turbineType.getId(), child.getId(),
                "GrandchildHasHierarchyOfChildren_" + i);
            assets.add(grandchild);
            Asset greatGrandchild = TestUtils.createAssetInstance(turbineType.getId(), grandchild.getId(),
                "GreatGrandchildHasHierarchyOfChildren_" + i);
            assets.add(greatGrandchild);
        }

        Collections.reverse(assets);

        try {
            assertThat(assetPersistencyService.createAssets(TestUtils.TEST_TENANT, getUnPrivileged(), assets))
                .isEqualTo(assets.size());
            failBecauseExceptionWasNotThrown(PersistencyServiceException.class);
        } catch (ObjectNotFoundException onf) {
            //ignore, expected for unprivileged user
        } catch (PersistencyServiceException pe) {
            assertThat(pe).hasMessage("Assets without parent cannot be added with constrained hierarchies");
        }

        assertThat(assetPersistencyService.createAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), assets)).isEqualTo(
            assets.size());
        assertThat(assets.get(0).getSuperTypesArray()).hasSize(2).containsOnly(turbineType.getId(),
            turbineType.getSuperTypeId());
        assertThat(assets.get(0).getLastModifiedDate()).isBefore(OffsetDateTime.now());
        //TODO: Check the order of ids

        Map<String, String> nameToIdMap = assets.stream().collect(Collectors.toMap(Asset::getName, Asset::getId));
        nameToIdMap.put(existingParent.getName(), existingParent.getId());

        // verify ancestors for children with existing parent
        Asset childOfHasExistingParent1 = assetPersistencyService.getAssetById(TestUtils.TEST_TENANT,
            TestUtils.getUber(), nameToIdMap.get("ChildOfHasExistingParent_1"));
        assertThat(childOfHasExistingParent1.getAncestorsArray()).hasSize(2).containsOnly(
            nameToIdMap.get("HasExistingParentWithChildren_1"), nameToIdMap.get("ExistingParent"));

        Asset greatGrandchildHasHierarchyOfChildren4 = assetPersistencyService.getAssetById(TestUtils.TEST_TENANT,
            TestUtils.getUber(), nameToIdMap.get("GreatGrandchildHasHierarchyOfChildren_4"));
        assertThat(greatGrandchildHasHierarchyOfChildren4.getAncestorsArray()).hasSize(3).containsOnly(
            nameToIdMap.get("ParentOfHasHierarchyOfChildren_4"), nameToIdMap.get("ChildHasHierarchyOfChildren_4"),
            nameToIdMap.get("GrandchildHasHierarchyOfChildren_4"));
    }

    @Test
    @Transactional
    public void createAssets_withDifferentParents() throws IOException, PersistencyServiceException {
        //Creating Custom Turbine Type
        AssetType turbineType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, TURBINE_TYPE);

        Asset[] parents = new Asset[] { assetPersistencyService.createAsset(TestUtils.TEST_TENANT, TestUtils.getUber(),
            TestUtils.createAssetInstance(turbineType.getId(), null, "ExistingParent1")),
            assetPersistencyService.createAsset(TestUtils.TEST_TENANT, TestUtils.getUber(),
                TestUtils.createAssetInstance(turbineType.getId(), null, "ExistingParent2")) };

        List<Asset> assets = new ArrayList<>();
        int hasExistingParentCount = 4;
        for (int i = 0; i < hasExistingParentCount; i++) {
            assets.add(TestUtils
                .createAssetInstance(turbineType.getId(), parents[i % 2].getId(), "HasExistingParentNoChildren_" + i));
        }

        try {
            assertThat(assetPersistencyService.createAssets(TestUtils.TEST_TENANT, getUnPrivileged(), assets))
                .isEqualTo(assets.size());
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (ObjectNotFoundException onf) {
            //ignore, expected for unprivileged user
        } catch (PersistencyServiceException ex) {
            fail("Not expecting to fail with " + ex.getMessage(), ex);
        }

        assertThat(assetPersistencyService
            .createAssets(TestUtils.TEST_TENANT, Arrays.asList(parents[0].getId(), parents[1].getId()), assets))
            .isEqualTo(assets.size());
    }

    Map<String, BaseDataModel> setupAssetData(AssetTypePersistencyService assetTypePersistencyService,
        AssetPersistencyService assetPersistencyService) throws IOException {
        Map<String, BaseDataModel> data = new HashMap<>();
        AssetType enterpriseType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID, MY_ENTERPRISE_TYPE);
        data.put(enterpriseType.getName(), enterpriseType);
        AssetType siteType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_SITE_TYPE_ID, MY_SITE_TYPE);
        data.put(siteType.getName(), siteType);
        AssetType segmentType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_SEGMENT_TYPE_ID, MY_SEGMENT_TYPE);
        data.put(segmentType.getName(), segmentType);
        AssetType assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, MY_ASSET_TYPE);
        data.put(assetType.getName(), assetType);
        AssetType assetSubType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, assetType.getId(),
            MY_ASSET_SUB_TYPE);
        data.put(assetSubType.getName(), assetSubType);

        AssetType myTagType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_TAG_TYPE_ID, MY_TAG_TYPE);
        data.put(myTagType.getName(), myTagType);

        Asset e1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            enterpriseType.getId(), null, E1);
        data.put(e1.getName(), e1);

        Collection<String> accessibleResources1 = Collections.singletonList(e1.getId());

        Asset e1S1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1,
            siteType.getId(), e1.getId(), E1_S1);
        data.put(e1S1.getName(), e1S1);

        Asset e1S1Seg1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1,
            segmentType.getId(), e1S1.getId(), E1_S1_SEG1);
        data.put(e1S1Seg1.getName(), e1S1Seg1);
        Asset e1S1Seg1Asset1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1,
            assetType.getId(), e1S1Seg1.getId(), E1_S1_SEG1_ASSET1);
        data.put(e1S1Seg1Asset1.getName(), e1S1Seg1Asset1);
        Asset e1S1Seg1Asset2 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1,
            assetSubType.getId(), e1S1Seg1.getId(), E1_S1_SEG1_ASSET2);
        data.put(e1S1Seg1Asset2.getName(), e1S1Seg1Asset2);

        //Creating tags for Enterprise and Site
        Tag e_tag = TagPredicateUtils.newTag(myTagType.getId(), e1.getId(), "e1_tag");
        Tag s_tag = TagPredicateUtils.newTag(myTagType.getId(), e1S1.getId(), "s1_tag");
        Tag seg_tag = TagPredicateUtils.newTag(myTagType.getId(), e1S1Seg1.getId(), "seg1_tag");
        Tag a1_tag = TagPredicateUtils.newTag(myTagType.getId(), e1S1Seg1Asset1.getId(), "asset1_tag");
        Tag a1_tag2 = TagPredicateUtils.newTag(myTagType.getId(), e1S1Seg1Asset1.getId(), "asset1_tag2");
        Tag a2_tag = TagPredicateUtils.newTag(myTagType.getId(), e1S1Seg1Asset2.getId(), "asset2_tag");

        try {
            data.put(e_tag.getName(),
                tagPersistencyService.createTag(TestUtils.TEST_TENANT, TestUtils.getUber(), e_tag));
            data.put(s_tag.getName(),
                tagPersistencyService.createTag(TestUtils.TEST_TENANT, accessibleResources1, s_tag));
            data.put(seg_tag.getName(),
                tagPersistencyService.createTag(TestUtils.TEST_TENANT, accessibleResources1, seg_tag));
            data.put(a1_tag.getName(),
                tagPersistencyService.createTag(TestUtils.TEST_TENANT, accessibleResources1, a1_tag));
            data.put(a1_tag2.getName(),
                tagPersistencyService.createTag(TestUtils.TEST_TENANT, accessibleResources1, a1_tag2));
            data.put(a2_tag.getName(),
                tagPersistencyService.createTag(TestUtils.TEST_TENANT, accessibleResources1, a2_tag));
        } catch (PersistencyServiceException ex) {
            fail("tag creation failed", ex);
        }

        return data;
    }

    @Test
    @Transactional
    public void getAssets_Decommissioned() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);

        Asset a1 = (Asset) data.get(E1_S1_SEG1_ASSET1);
        Asset a2 = (Asset) data.get(E1_S1_SEG1_ASSET2);
        Asset e1S1Seg1 = (Asset) data.get(E1_S1_SEG1);
        ((ObjectNode) a1.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        ((ObjectNode) e1S1Seg1.getAttributes().path("reservedAttributes").path("state")).put("key", "10");

        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), a1);
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), e1S1Seg1);

        assertThat(assetPersistencyService.getAssetById(TestUtils.TEST_TENANT, getUnPrivileged(data.get(E1)),
            a1.getId()))
            .isNull();
        assertThat(
            assetPersistencyService.getAssetById(TestUtils.TEST_TENANT, getUnPrivileged(data.get(E1)), a2.getId())
                .getSourceKey())
            .isEqualTo(a2.getSourceKey());
    }

    @Test
    @Transactional
    public void getChildAssets_Decommissioned() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);

        String assetTypeId = data.get(MY_ASSET_TYPE).getId();
        Asset e1 = (Asset) data.get(E1);
        Asset a1 = (Asset) data.get(E1_S1_SEG1_ASSET1);
        Asset a2 = (Asset) data.get(E1_S1_SEG1_ASSET2);
        Asset e1S1 = (Asset) data.get(E1_S1);
        Asset e1S1Seg1 = (Asset) data.get(E1_S1_SEG1);
        ((ObjectNode) a1.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        ((ObjectNode) e1S1Seg1.getAttributes().path("reservedAttributes").path("state")).put("key", "10");

        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), a1);
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), e1S1Seg1);

        AssetPredicate predicate = AssetPredicate.builder().build();
        assertThat(assetPersistencyService.getChildAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get(E1)), e1S1Seg1.getId(),
            predicate).get(0).getSourceKey()).isEqualTo(a2.getSourceKey());

        assertThat(assetPersistencyService
            .getChildAssets(TestUtils.TEST_TENANT, getUnPrivileged(a1), e1S1Seg1.getId(), predicate)
            .size()).isEqualTo(0);

        predicate.setParent(ParentPredicate.builder().deepSearch(true).build());
        /*assertThat(assetPersistencyService
            .getChildAssets(TestUtils.TEST_TENANT, Collections.singleton(e1.getId()), e1.getId(), predicate)).hasSize(2)
            .extracting(Asset::getSourceKey).containsOnly(e1S1.getSourceKey(), a2.getSourceKey());*/
        assertThat(assetPersistencyService
            .getChildAssets(TestUtils.TEST_TENANT, getUnPrivileged(e1), e1.getId(), predicate)).hasSize(3)
            .extracting(Asset::getSourceKey).containsOnly(e1S1.getSourceKey(), a2.getSourceKey(),
            e1S1Seg1.getSourceKey());

        predicate = AssetPredicate.builder().type(TypePredicate.builder().ids(Collections.singleton(assetTypeId))
            .deepSearch(true).build()).parent(ParentPredicate.builder().ids(Collections.singleton(e1.getId()))
            .deepSearch(true).build()).build();
        assertThat(assetPersistencyService
            .getChildAssets(TestUtils.TEST_TENANT, getUnPrivileged(e1), e1.getId(), predicate)).hasSize(1)
            .extracting(Asset::getSourceKey).containsOnly(a2.getSourceKey());
    }

    @Test
    @Transactional
    public void getAssets_byParent_Decommissioned() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);

        Asset e1 = (Asset) data.get(E1);
        Asset a1 = (Asset) data.get(E1_S1_SEG1_ASSET1);
        Asset a2 = (Asset) data.get(E1_S1_SEG1_ASSET2);
        Asset e1S1 = (Asset) data.get(E1_S1);
        ((ObjectNode) a2.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), a2);

        AssetPredicate predicate = AssetPredicate.builder().name(E1_S1_SEG1_ASSET1).parent(
            ParentPredicate.builder().name(E1).deepSearch(true).build()).build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get(E1)), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly(E1_S1_SEG1_ASSET1);
        predicate = AssetPredicate.builder().ids(Sets.newHashSet(a1.getId(), a2.getId(), e1.getId())).parent(
            ParentPredicate.builder().name(e1S1.getName()).deepSearch(true).build()).build();

        List<Asset> assets = assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get(E1)), predicate);
        assertThat(assets).hasSize(1).extracting(Asset::getSourceKey).containsOnly(a1.getSourceKey());
    }

    @Test
    @Transactional
    public void getAssets_bySourceKeys_Decommissioned() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);

        Asset a1 = (Asset) data.get(E1_S1_SEG1_ASSET1);
        Asset a2 = (Asset) data.get(E1_S1_SEG1_ASSET2);
        Asset e1S1 = (Asset) data.get(E1_S1);
        ((ObjectNode) a2.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), a2);
        ((ObjectNode) e1S1.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), e1S1);

        assertThat(assetPersistencyService
            .getAssetBySourceKey(TestUtils.TEST_TENANT, getUnPrivileged(data.get(E1)), OOTBCoreTypesIdLookup.AssetType.name(),
                a2.getSourceKey())).isNull();

        //although e1s1 is decommissioned, the user does not have the policy set to hide decommissioned sites
        assertThat(assetPersistencyService
            .getAssetBySourceKey(TestUtils.TEST_TENANT, getUnPrivileged(data.get(E1)), OOTBCoreTypesIdLookup.SiteType.name(),
                e1S1.getSourceKey())).extracting(Asset::getName).containsOnly(e1S1.getName());

        assertThat(assetPersistencyService
            .getAssetsBySourceKeys(TestUtils.TEST_TENANT, getUnPrivileged(data.get(E1)), OOTBCoreTypesIdLookup.AssetType.name(),
                Arrays.asList(a1.getSourceKey(), a2.getSourceKey(), e1S1.getSourceKey()))).extracting(Asset::getName)
            .hasSize(1).containsOnly(a1.getName());
    }

    @Test
    @Transactional
    public void getAssets_byIds_Decommissioned() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = setupAssetData(assetTypePersistencyService, assetPersistencyService);
        Collection<String> accessibleResources = getUnPrivileged(data.get(E1));

        Asset a1 = (Asset) data.get(E1_S1_SEG1_ASSET1);
        Asset a2 = (Asset) data.get(E1_S1_SEG1_ASSET2);
        Asset e1S1 = (Asset) data.get(E1_S1);
        Asset e1S1Seg1 = (Asset) data.get(E1_S1_SEG1);

        ((ObjectNode) a1.getAttributes().path("reservedAttributes").path("state")).put("key", "4");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, accessibleResources, a1);
        ((ObjectNode) a2.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, accessibleResources, a2);
        ((ObjectNode) e1S1.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, accessibleResources, e1S1);
        ((ObjectNode) e1S1Seg1.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, accessibleResources, e1S1Seg1);

        assertThat(assetPersistencyService.getAssetById(TestUtils.TEST_TENANT, accessibleResources, a2.getId()))
            .isNull();

        //although e1s1 is decommissioned, the user does not have the policy set to hide decommissioned sites
        assertThat(assetPersistencyService.getAssetById(TestUtils.TEST_TENANT, accessibleResources, e1S1.getId()))
            .extracting(Asset::getName).containsOnly(e1S1.getName());

        assertThat(assetPersistencyService
            .getAssetsByIds(TestUtils.TEST_TENANT, accessibleResources, Sets.newHashSet(a1.getId(), e1S1.getId())))
            .extracting(Asset::getName).hasSize(2).containsOnly(a1.getName(), e1S1.getName());

        assertThat(assetPersistencyService.getAssetsByIds(TestUtils.TEST_TENANT, Collections.singleton(e1S1.getId()),
            Sets.newHashSet(a1.getId(), e1S1.getId()))).extracting(Asset::getName).hasSize(2).containsOnly(a1.getName(),
            e1S1.getName());
    }
}
