/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.converter;

import java.sql.SQLException;

import org.junit.Test;
import org.postgresql.util.PGobject;

import static org.assertj.core.api.Assertions.assertThat;

public class JsonbAttributeConverterTest {
    @Test
    public void convertToEntityAttribute_nullValue() throws SQLException {
        JsonbAttributeConverter converter = new JsonbAttributeConverter();
        assertThat(converter.convertToEntityAttribute(null)).isNull();
    }

    @Test
    public void convertToEntityAttribute() throws SQLException {
        JsonbAttributeConverter converter = new JsonbAttributeConverter();
        PGobject value = new PGobject();
        value.setType("jsonb");
        value.setValue("{\"ids\":{}}");
        assertThat(converter.convertToEntityAttribute(value)).isNotNull();
    }

    @Test(expected = UnsupportedOperationException.class)
    public void convertToEntityAttribute_notPGobject() {
        JsonbAttributeConverter converter = new JsonbAttributeConverter();
        converter.convertToEntityAttribute(new Object());
    }

    @Test(expected = UnsupportedOperationException.class)
    public void convertToEntityAttribute_notJsonB() {
        JsonbAttributeConverter converter = new JsonbAttributeConverter();
        PGobject value = new PGobject();
        value.setType("unsupported");
        converter.convertToEntityAttribute(value);
    }

    @Test
    public void convertToEntityAttribute_invalidJsonb() throws SQLException {
        JsonbAttributeConverter converter = new JsonbAttributeConverter();
        PGobject value = new PGobject();
        value.setType("jsonb");
        value.setValue("");
        converter.convertToEntityAttribute(value);
    }
}