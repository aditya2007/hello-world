/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import com.ge.apm.common.support.RequestContext;

/**
 * @author Shu W. Yu 212614203
 * @version 1.0 Apr 06, 2018
 * @since 1.0
 */
public final class TenantTestUtils {

    private static final ThreadLocal<String> TENANT_ID = ThreadLocal.withInitial(() -> TestUtils.TEST_TENANT);

    private TenantTestUtils() {
        // nothing.
    }

    public static String getTenantId() {
        return TENANT_ID.get();
    }

    public static String setTenantId(String tenantId) {
        String oldId = getTenantId();
        TENANT_ID.set(tenantId);
        RequestContext.put(RequestContext.TENANT_UUID, tenantId);

        return oldId;
    }
}
