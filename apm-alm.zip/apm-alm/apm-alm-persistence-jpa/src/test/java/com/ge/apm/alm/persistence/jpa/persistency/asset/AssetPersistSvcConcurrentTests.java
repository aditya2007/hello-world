/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import javax.sql.DataSource;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import lombok.extern.slf4j.Slf4j;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Sourceable;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.utils.TagPredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TenantTestUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;
import com.ge.apm.alm.persistence.mirror.MirrorTestUtils;
import com.ge.apm.common.support.RequestContext;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_ASSET_TYPE_ID;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
@Slf4j
public class AssetPersistSvcConcurrentTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private DataSource dataSource;

    private static final String TEST_TENANT = UUID.randomUUID().toString();

    @Before
    public void beforeTest() {
        MirrorTestUtils.setEventCreationEnabled(false);
        initTenantThread();
    }

    @After
    public void afterTest() {
        TenantTestUtils.setTenantId(TestUtils.TEST_TENANT);
        MirrorTestUtils.setEventCreationEnabled(true);
    }

    private static void initTenantThread() {
        TenantTestUtils.setTenantId(TEST_TENANT);
    }

    @Test
    @Transactional
    public void updateAsset_updateConnections_singleThreaded_topDown() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = TagPredicateUtils.createTypes(assetTypePersistencyService);
        int numSites = 1;
        int numSegmentsPerSite = 1;
        int numAssetsPerSegment = 1;
        Map<String, Asset> assets = createMoreAssetsWithoutConnections(assetPersistencyService, types, numSites,
            numSegmentsPerSite, numAssetsPerSegment);

        // update connections
        Asset e1 = updateConnections(numSites, numSegmentsPerSite, numAssetsPerSegment, assets);

        Collection<String> accessibleResources = TestUtils.getUber();
        for (int i = 1; i <= numSites; i++) {
            Asset site = assets.get("E1_S" + i);
            Asset updatedSite = assetPersistencyService.updateAsset(TEST_TENANT, accessibleResources, site);

            assertThat(updatedSite.getAncestorsArray()).containsOnly(e1.getId());
            assertThat(updatedSite.getAncestorsArray()).hasSize(1).containsOnly(e1.getId());
            for (int j = 1; j <= numSegmentsPerSite; j++) {
                Asset segment = assets.get("E1_S" + i + "_Seg" + j);
                Asset updatedSegment = assetPersistencyService.updateAsset(TEST_TENANT, accessibleResources, segment);
                assertThat(updatedSegment.getAncestorsArray()).containsOnly(e1.getId(), site.getId());
                assertThat(updatedSegment.getAncestorsArray()).hasSize(2).containsOnly(e1.getId(), site.getId());
                for (int k = 1; k <= numAssetsPerSegment; k++) {
                    Asset asset = assets.get("E1_S" + i + "_Seg" + j + "_Asset" + k);
                    Asset updatedAsset = assetPersistencyService.updateAsset(TEST_TENANT, accessibleResources, asset);
                    assertThat(updatedAsset.getAncestorsArray()).containsOnly(e1.getId(), site.getId(),
                        segment.getId());
                    assertThat(updatedAsset.getAncestorsArray()).hasSize(3).containsOnly(e1.getId(), site.getId(),
                        segment.getId());

                    Asset subAsset = assets.get("E1_S" + i + "_Seg" + j + "_AssetSub" + k);
                    Asset updatedSubAsset = assetPersistencyService.updateAsset(TEST_TENANT, accessibleResources,
                        subAsset);
                    assertThat(updatedSubAsset.getAncestorsArray()).containsOnly(e1.getId(), site.getId(),
                        segment.getId(), asset.getId());
                    assertThat(updatedSubAsset.getAncestorsArray()).hasSize(4).containsOnly(e1.getId(), site.getId(),
                        segment.getId(), asset.getId());
                }
            }
        }
    }

    private Asset updateConnections(int numSites, int numSegmentsPerSite, int numAssetsPerSegment,
        Map<String, Asset> assets) {
        Asset e1 = assets.get("E1");
        for (int i = 1; i <= numSites; i++) {
            Asset site = assets.get("E1_S" + i);
            ((AssetInstanceEntity) site).setParentId(e1.getId());
            for (int j = 1; j <= numSegmentsPerSite; j++) {
                Asset segment = assets.get("E1_S" + i + "_Seg" + j);
                ((AssetInstanceEntity) segment).setParentId(site.getId());
                for (int k = 1; k <= numAssetsPerSegment; k++) {
                    Asset asset = assets.get("E1_S" + i + "_Seg" + j + "_Asset" + k);
                    ((AssetInstanceEntity) asset).setParentId(segment.getId());
                    Asset subAsset = assets.get("E1_S" + i + "_Seg" + j + "_AssetSub" + k);
                    ((AssetInstanceEntity) subAsset).setParentId(asset.getId());
                }
            }
        }
        return e1;
    }

    @Test
    @Transactional
    public void updateAsset_updateConnections_singleThreaded_bottomUp()
        throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = TagPredicateUtils.createTypes(assetTypePersistencyService);
        int numSites = 1;
        int numSegmentsPerSite = 1;
        int numAssetsPerSegment = 1;
        Map<String, Asset> assets = createMoreAssetsWithoutConnections(assetPersistencyService, types, numSites,
            numSegmentsPerSite, numAssetsPerSegment);
        Set<String> eventObjectIds = types.values().stream().map(AssetType::getId).collect(Collectors.toSet());
        eventObjectIds.addAll(assets.values().stream().map(Asset::getId).collect(Collectors.toSet()));
        for (Map.Entry<String, Asset> e : assets.entrySet()) {
            assertThat(
                assetPersistencyService.getAssetById(TEST_TENANT, TestUtils.getUber(), e.getValue().getId()))
                .isNotNull().extracting(Asset::getParentId).containsNull();
            // System.out
            //     .println(String.format("Found persistent asset %s: %s", e.getValue().getName(), e.getValue().getId
            // ()));
        }

        // update connections
        Asset e1 = updateConnections(numSites, numSegmentsPerSite, numAssetsPerSegment, assets);

        Collection<String> accessibleResources = TestUtils.getUber();
        for (int i = 1; i <= numSites; i++) {
            for (int j = 1; j <= numSegmentsPerSite; j++) {
                for (int k = 1; k <= numAssetsPerSegment; k++) {
                    Asset asset = assets.get("E1_S" + i + "_Seg" + j + "_Asset" + k);
                    Asset subAsset = assets.get("E1_S" + i + "_Seg" + j + "_AssetSub" + k);
                    assetPersistencyService.updateAsset(TEST_TENANT, accessibleResources, subAsset);
                    assetPersistencyService.updateAsset(TEST_TENANT, accessibleResources, asset);
                }
                Asset segment = assets.get("E1_S" + i + "_Seg" + j);
                assetPersistencyService.updateAsset(TEST_TENANT, accessibleResources, segment);
            }
            Asset site = assets.get("E1_S" + i);
            assetPersistencyService.updateAsset(TEST_TENANT, accessibleResources, site);
        }

        for (int i = 1; i <= numSites; i++) {
            Asset site = assetPersistencyService.getAssetById(TEST_TENANT, accessibleResources,
                assets.get("E1_S" + i).getId());
            assertThat(site.getAncestorsArray()).containsOnly(e1.getId());
            assertThat(site.getAncestorsArray()).hasSize(1).containsOnly(e1.getId());
            for (int j = 1; j <= numSegmentsPerSite; j++) {
                Asset segment = assetPersistencyService.getAssetById(TEST_TENANT, accessibleResources,
                    assets.get("E1_S" + i + "_Seg" + j).getId());
                assertThat(segment.getAncestorsArray()).containsOnly(e1.getId(), site.getId());
                assertThat(segment.getAncestorsArray()).hasSize(2).containsOnly(e1.getId(), site.getId());
                for (int k = 1; k <= numAssetsPerSegment; k++) {
                    Asset asset = assetPersistencyService.getAssetById(TEST_TENANT, accessibleResources,
                        assets.get("E1_S" + i + "_Seg" + j + "_Asset" + k).getId());
                    assertThat(asset.getAncestorsArray()).containsOnly(e1.getId(), site.getId(), segment.getId());
                    assertThat(asset.getAncestorsArray()).hasSize(3).containsOnly(e1.getId(), site.getId(),
                        segment.getId());

                    Asset subAsset = assetPersistencyService.getAssetById(TEST_TENANT, accessibleResources,
                        assets.get("E1_S" + i + "_Seg" + j + "_AssetSub" + k).getId());
                    assertThat(subAsset.getAncestorsArray()).containsOnly(e1.getId(), site.getId(), segment.getId(),
                        asset.getId());
                    assertThat(subAsset.getAncestorsArray()).hasSize(4).containsOnly(e1.getId(), site.getId(),
                        segment.getId(), asset.getId());
                }
            }
        }
    }

    private List<JsonNode> toList(ArrayNode arrayNode) {
        return StreamSupport.stream(Spliterators.spliteratorUnknownSize(arrayNode.elements(), Spliterator.ORDERED),
            false).collect(Collectors.toList());
    }

    @Test
    public void updateAsset_updateConnections_concurrent_singleHierarchy()
        throws IOException, PersistencyServiceException, InterruptedException, ExecutionException {
        Map<String, AssetType> types = TagPredicateUtils.createTypes(assetTypePersistencyService);

        int numSites = 1;
        int numSegmentsPerSite = 1;
        int numAssetsPerSegment = 1;
        Map<String, Asset> assets = createMoreAssetsWithoutConnections(assetPersistencyService, types, numSites,
            numSegmentsPerSite, numAssetsPerSegment);

        List<Task> tasks = createUpdateConnectionTasks(assets, numSites, numSegmentsPerSite, numAssetsPerSegment);
        executeAssetTasksWithRetry(tasks, tasks.size(), 5);
        Map<String, Asset> updatedAssets = assets.values().stream().collect(Collectors.toMap(Sourceable::getName,
            x -> assetPersistencyService.getAssetById(TEST_TENANT, TestUtils.getUber(), x.getId())));

        Asset e1 = assets.get("E1");
        for (int i = 1; i <= numSites; i++) {
            Asset site = updatedAssets.get("E1_S" + i);
            assertThat(site.getAncestorsArray()).containsOnly(e1.getId());
            assertThat(site.getAncestorsArray()).hasSize(1).containsOnly(e1.getId());
            for (int j = 1; j <= numSegmentsPerSite; j++) {
                Asset segment = updatedAssets.get("E1_S" + i + "_Seg" + j);
                assertThat(segment.getAncestorsArray()).containsOnly(e1.getId(), site.getId());
                assertThat(segment.getAncestorsArray()).hasSize(2).containsOnly(e1.getId(), site.getId());
                for (int k = 1; k <= numAssetsPerSegment; k++) {
                    Asset asset = updatedAssets.get("E1_S" + i + "_Seg" + j + "_Asset" + k);
                    assertThat(asset.getAncestorsArray()).containsOnly(e1.getId(), site.getId(), segment.getId());
                    assertThat(asset.getAncestorsArray()).hasSize(3).containsOnly(e1.getId(), site.getId(),
                        segment.getId());
                    Asset subAsset = updatedAssets.get("E1_S" + i + "_Seg" + j + "_AssetSub" + k);
                    assertThat(subAsset.getAncestorsArray()).containsOnly(e1.getId(), site.getId(), segment.getId(),
                        asset.getId());
                    assertThat(subAsset.getAncestorsArray()).hasSize(4).containsOnly(e1.getId(), site.getId(),
                        segment.getId(), asset.getId());
                }
            }

            deleteTestTypesAndAssets(types, tasks, e1);
        }
    }

    @Test
    public void runLargeDatasetWithSingleThread()
        throws IOException, PersistencyServiceException, InterruptedException, ExecutionException {
        int count = 1;
        for (int i = 0; i < count; i++) {
            updateAssetConnections_concurrentWithLargeDataset(10, 10, 10, 1);
        }
    }

    @Test
    public void runLargeDatasetWithMultipleThreads()
        throws IOException, PersistencyServiceException, InterruptedException, ExecutionException {
        int count = 1;
        for (int i = 0; i < count; i++) {
            updateAssetConnections_concurrentWithLargeDataset(10, 10, 10, 16);
        }
    }

    @Test
    public void updateAssetConnections_concurrentWithDeepHierarchy()
        throws IOException, InterruptedException, ExecutionException, PersistencyServiceException {
        AssetType assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, ROOT_ASSET_TYPE_ID,
            "MyAssetType");
        int numAssets = 200;

        List<Asset> assets = new ArrayList<>(numAssets);
        for (int i = 0; i < numAssets; i++) {
            assets.add(TestUtils
                .createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), assetType.getId(), null,
                    "A" + i));
        }

        // more contentions when the tasks are executed sequentially
        List<Task> tasks = new ArrayList<>();
        for (int i = 1; i < numAssets; i++) {
            ((AssetInstanceEntity) assets.get(i)).setParentId(assets.get(i - 1).getId());
            tasks.add(new Task(assetPersistencyService, assets.get(i)));
        }

        executeAssetTasksWithRetry(tasks, 32, 5);
        for (int i = 0; i < numAssets; i++) {
            assets.set(i, assetPersistencyService
                .getAssetById(TEST_TENANT, TestUtils.getUber(), assets.get(i).getId()));
        }

        int errorCount = 0;
        for (int i = 1; i < numAssets; i++) {
            String[] parentIds = new String[i];
            for (int j = 0; j < i; j++) {
                parentIds[j] = assets.get(j).getId();
            }
            try {
                assertThat(assets.get(i).getAncestorsArray()).containsOnly(parentIds);
                assertThat(assets.get(i).getAncestorsArray()).containsOnly(parentIds);
            } catch (AssertionError ae) {
                errorCount++;
            }
        }

        assertThat(assetPersistencyService
            .deleteAssetRecursively(TEST_TENANT, TestUtils.getUber(), assets.get(0).getId(), "Test")
            .getAssetCount()).isEqualTo(assets.size());
        assertThat(assetTypePersistencyService.deleteAssetType(TEST_TENANT, assetType.getId())).isEqualTo(1);

        if (errorCount > 0) {
            throw new AssertionError("failed count: " + errorCount);
        }
    }

    private static Map<String, Asset> createMoreAssetsWithoutConnections(
        AssetPersistencyService assetPersistencyService, Map<String, AssetType> types, int numSites,
        int segmentsPerSite, int assetsPerSegment) throws IOException {
        Map<String, Asset> assets = new HashMap<>();

        Asset e1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            types.get("MyEnterpriseType").getId(), null, "E1");
        assets.put(e1.getName(), e1);

        Collection<String> accessibleResources1 = Collections.singletonList(e1.getId());

        for (int i = 1; i <= numSites; i++) {
            Asset site = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1,
                types.get("MySiteType").getId(), null, "E1_S" + i);
            assets.put(site.getName(), site);
            for (int j = 1; j <= segmentsPerSite; j++) {
                Asset segment = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1,
                    types.get("MySegmentType").getId(), null, "E1_S" + i + "_Seg" + j);
                assets.put(segment.getName(), segment);
                for (int k = 1; k <= assetsPerSegment; k++) {
                    Asset asset = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1,
                        types.get("MyAssetType").getId(), null, "E1_S" + i + "_Seg" + j + "_Asset" + k);
                    assets.put(asset.getName(), asset);
                    Asset subAsset = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
                        accessibleResources1, types.get("MyAssetSubType").getId(), null,
                        "E1_S" + i + "_Seg" + j + "_AssetSub" + k);
                    assets.put(subAsset.getName(), subAsset);
                }
            }
        }

        return assets;
    }

    private void deleteTestTypesAndAssets(Map<String, AssetType> types, List<Task> tasks, Asset e1)
        throws PersistencyServiceException {
        assertThat(assetPersistencyService
            .deleteAssetRecursively(TEST_TENANT, TestUtils.getUber(), e1.getId(), "Test").getAssetCount())
            .isEqualTo(tasks.size() + 1);
        assertThat(
            assetTypePersistencyService.deleteAssetType(TEST_TENANT, types.get("MyEnterpriseType").getId()))
            .isEqualTo(1);
        assertThat(assetTypePersistencyService.deleteAssetType(TEST_TENANT, types.get("MySiteType").getId()))
            .isEqualTo(1);
        assertThat(
            assetTypePersistencyService.deleteAssetType(TEST_TENANT, types.get("MySegmentType").getId()))
            .isEqualTo(1);
        assertThat(assetTypePersistencyService
            .deleteAssetTypeRecursively(TEST_TENANT, types.get("MyAssetType").getId())).isEqualTo(2);
        assertThat(assetTypePersistencyService
            .deleteAssetTypeRecursively(TEST_TENANT, types.get("MyTagType").getId())).isEqualTo(1);
    }

    private void executeAssetTasksWithRetry(List<Task> tasks, int maxThreads, int maxRetry)
        throws InterruptedException, ExecutionException {
        ExecutorService executorService = Executors.newFixedThreadPool(
            tasks.size() > maxThreads ? maxThreads : tasks.size());
        List<Future<Asset>> futures = executorService.invokeAll(tasks);

        boolean retrySucceeded = false;
        List<Task> previousTasks = tasks;
        for (int i = 0; i < maxRetry; i++) {
            List<Task> retryTask = new ArrayList<>();
            for (int j = 0; j < futures.size(); j++) {
                try {
                    futures.get(j).get();
                } catch (ExecutionException ex) {
                    if (ex.getCause() instanceof JpaSystemException) {
                        retryTask.add(previousTasks.get(j));
                    } else {
                        throw ex;
                    }
                }
            }
            if (retryTask.isEmpty()) {
                retrySucceeded = true;
                break;
            }
            previousTasks = retryTask;
            futures = executorService.invokeAll(retryTask);
            System.out.println("attempting to retry executing " + retryTask.size() + " tasks");
        }
        if (!retrySucceeded) {
            System.out.println("maximum number of retrying task execution has reached.");
        }
    }

    private void updateAssetConnections_concurrentWithLargeDataset(int numSites, int numSegmentsPerSite,
        int numAssetsPerSegment, int maxThreads)
        throws IOException, PersistencyServiceException, InterruptedException, ExecutionException {
        Map<String, AssetType> types = TagPredicateUtils.createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createMoreAssetsWithoutConnections(assetPersistencyService, types, numSites,
            numSegmentsPerSite, numAssetsPerSegment);

        List<Task> tasks = createUpdateConnectionTasks(assets, numSites, numSegmentsPerSite, numAssetsPerSegment);
        tasks.sort(Comparator.comparing(t -> t.asset.getId()));

        int numThreads = tasks.size() > maxThreads ? maxThreads : tasks.size();
        long start = System.currentTimeMillis();
        executeAssetTasksWithRetry(tasks, numThreads, 5);
        System.out.println(
            "Total time to update object connections [" + maxThreads + " threads] = " + (System.currentTimeMillis()
                - start) + " msec");
        Map<String, Asset> updatedAssets = assets.values().stream().collect(Collectors.toMap(Sourceable::getName,
            x -> assetPersistencyService.getAssetById(TEST_TENANT, TestUtils.getUber(), x.getId())));

        Asset e1 = assets.get("E1");
        for (int i = 1; i <= numSites; i++) {
            Asset site = updatedAssets.get("E1_S" + i);
            assertThat(site.getAncestorsArray()).containsOnly(e1.getId());
            assertThat(site.getAncestorsArray()).hasSize(1).containsOnly(e1.getId());
            for (int j = 1; j <= numSegmentsPerSite; j++) {
                Asset segment = updatedAssets.get("E1_S" + i + "_Seg" + j);
                assertThat(segment.getAncestorsArray()).containsOnly(e1.getId(), site.getId());
                assertThat(segment.getAncestorsArray()).hasSize(2).containsOnly(e1.getId(), site.getId());
                for (int k = 1; k <= numAssetsPerSegment; k++) {
                    Asset asset = updatedAssets.get("E1_S" + i + "_Seg" + j + "_Asset" + k);
                    assertThat(asset.getAncestorsArray()).containsOnly(e1.getId(), site.getId(), segment.getId());
                    assertThat(asset.getAncestorsArray()).hasSize(3).containsOnly(e1.getId(), site.getId(),
                        segment.getId());
                    Asset subAsset = updatedAssets.get("E1_S" + i + "_Seg" + j + "_AssetSub" + k);
                    assertThat(subAsset.getAncestorsArray()).containsOnly(e1.getId(), site.getId(), segment.getId(),
                        asset.getId());
                    assertThat(subAsset.getAncestorsArray()).hasSize(4).containsOnly(e1.getId(), site.getId(),
                        segment.getId(), asset.getId());
                }
            }
        }

        deleteTestTypesAndAssets(types, tasks, e1);
    }

    private List<Task> createUpdateConnectionTasks(Map<String, Asset> assets, int numSites, int segmentsPerSite,
        int assetsPerSegment) {

        List<Task> tasks = new ArrayList<>();
        Asset e1 = assets.get("E1");
        //System.out.println(String.format("Asset: %s %s", e1.getName(), e1.getId()));
        for (int i = 1; i <= numSites; i++) {
            Asset site = assets.get("E1_S" + i);
            //System.out.println(String.format("Asset: %s %s", site.getName(), site.getId()));
            ((AssetInstanceEntity) site).setParentId(e1.getId());
            tasks.add(new Task(assetPersistencyService, site));
            for (int j = 1; j <= segmentsPerSite; j++) {
                Asset segment = assets.get("E1_S" + i + "_Seg" + j);
                //System.out.println(
                // String.format("Asset: %s %s", segment.getName(), segment.getId()));
                ((AssetInstanceEntity) segment).setParentId(site.getId());
                tasks.add(new Task(assetPersistencyService, segment));
                for (int k = 1; k <= assetsPerSegment; k++) {
                    Asset asset = assets.get("E1_S" + i + "_Seg" + j + "_Asset" + k);
                    //System.out.println(
                    // String.format("Asset: %s %s", asset.getName(), asset.getId()));
                    ((AssetInstanceEntity) asset).setParentId(segment.getId());
                    tasks.add(new Task(assetPersistencyService, asset));
                    Asset subAsset = assets.get("E1_S" + i + "_Seg" + j + "_AssetSub" + k);
                    //System.out.println(
                    // String.format("Asset: %s %s", subAsset.getName(), subAsset.getId()));
                    ((AssetInstanceEntity) subAsset).setParentId(asset.getId());
                    tasks.add(new Task(assetPersistencyService, subAsset));
                }
            }
        }

        return tasks;
    }

    static class Task implements Callable<Asset> {

        final AssetPersistencyService assetPersistencyService;

        final Asset asset;

        Task(AssetPersistencyService assetPersistencyService, Asset asset) {
            this.assetPersistencyService = assetPersistencyService;
            this.asset = asset;
        }

        @Override
        public Asset call() throws Exception { // NOPMD JDK API's fault in throwing Exception
            //System.out.println(String
            //     .format("Time %s => Thread %s => %s %s", OffsetDateTime.now(),
            //     Thread.currentThread().getId(),
            //     asset.getName(), asset.getId()));
            AssetPersistSvcConcurrentTests.initTenantThread();
            try {
                TestUtils.getUber();
                return assetPersistencyService.updateAsset(TEST_TENANT, TestUtils.getUber(), asset);
            } finally {
                RequestContext.destroy();
            }
        }
    }
}
