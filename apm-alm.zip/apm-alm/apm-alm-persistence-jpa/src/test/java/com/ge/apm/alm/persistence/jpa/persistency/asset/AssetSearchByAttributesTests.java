/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.io.IOException;
import java.util.Map;

import org.assertj.core.util.Maps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.TEST_TENANT;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUber;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUnPrivileged;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests asset searches using {@link com.ge.apm.alm.model.query.AssetPredicate}, with emphasis
 * on query by attributes.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetSearchByAttributesTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Test
    @Transactional
    public void customAttributeExists() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().attributes(Maps.newHashMap("Test Boolean", null)).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName).containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4",
            "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void customBooleanAttributeEquals() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().attributes(Maps.newHashMap("Test Boolean", "true")).offset(
            0).pageSize(100).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName).containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4",
            "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        predicate.setAttributes(Maps.newHashMap("Test Boolean", "false"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void customNumberAttributeEquals() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().attributes(
            Maps.newHashMap("Test Number", String.valueOf(Integer.MIN_VALUE))).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName).containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4",
            "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        predicate.setAttributes(Maps.newHashMap("Test Number", "123"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void customNumberAttributeLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().attributes(Maps.newHashMap("Test Number", "922*")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void customStringAttributeEquals() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType type = (AssetType) data.get("AssetCType");
        AssetPredicate predicate = AssetPredicate.builder().attributes(Maps.newHashMap("Test String", type.getId()))
            .build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(2).extracting(
            Asset::getName).containsOnly("E1_S1_Seg3_C3", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly("E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        predicate.setAttributes(Maps.newHashMap("Test String", "@@@@@"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test(expected = DataIntegrityViolationException.class)
    @Transactional
    public void customStringAttributeEquals_SqlInjection1() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType type = (AssetType) data.get("AssetCType");
        AssetPredicate predicate = AssetPredicate.builder().attributes(
            Maps.newHashMap("Test String", "junk\"]}}}') or 1=1)--")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void customStringAttributeFullLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType type = (AssetType) data.get("AssetCType");
        AssetPredicate predicate = AssetPredicate.builder().attributes(
            Maps.newHashMap("Test String", "*" + type.getId().replaceAll("-", "*") + "*")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(2).extracting(
            Asset::getName).containsOnly("E1_S1_Seg3_C3", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly("E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        predicate.setAttributes(Maps.newHashMap("Test String", "*@@@@@*"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void customStringAttributeLeftLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType type = (AssetType) data.get("AssetCType");
        AssetPredicate predicate = AssetPredicate.builder().attributes(
            Maps.newHashMap("Test String", "*" + type.getId().replaceAll("-", "*"))).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(2).extracting(
            Asset::getName).containsOnly("E1_S1_Seg3_C3", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly("E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        predicate.setAttributes(Maps.newHashMap("Test String", "*@@@@@*"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void customStringAttributeRightLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType type = (AssetType) data.get("AssetCType");
        AssetPredicate predicate = AssetPredicate.builder().attributes(
            Maps.newHashMap("Test String", type.getId().replaceAll("-", "*") + "*")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(2).extracting(
            Asset::getName).containsOnly("E1_S1_Seg3_C3", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly("E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        predicate.setAttributes(Maps.newHashMap("Test String", "*@@@@@*"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void customStringAttributeLeftLike2() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().attributes(Maps.newHashMap("Test String", "*bc")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName).containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4",
            "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        predicate.setAttributes(Maps.newHashMap("Test String", "*@@@@@*"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void customStringAttributeRightLike2() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().attributes(Maps.newHashMap("Test String", "ab*")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName).containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4",
            "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        predicate.setAttributes(Maps.newHashMap("Test String", "*@@@@@*"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void customStringAttributeLike2() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().attributes(Maps.newHashMap("Test String", "*bc*")).build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName).containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4",
            "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        predicate.setAttributes(Maps.newHashMap("Test String", "*xyz*"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void customStringAttributeLike3() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().attributes(Maps.newHashMap("Test String", "*bc\", \"de*"))
            .build();
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(17);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(5)
            .extracting(Asset::getName).containsOnly("E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4",
            "E1_S2_Seg4_C4");
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
        predicate.setAttributes(Maps.newHashMap("Test String", "*abcdef*"));
        assertThat(assetPersistencyService.getAssets(TEST_TENANT, getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    Map<String, BaseDataModel> setupData() throws IOException {
        return PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService, assetPersistencyService);
    }
}
