/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.Sourceable;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.createAssetInstanceAndAssert;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.createAssetTypeAndAssert;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUber;

public final class PredicateUtils {

    private PredicateUtils() {
    }

    /**
     * Creating the following type and instance hierarchy
     * E1Type <-- S1Type <-- Seg1Type <-- Asset1Type (*) <-- (Asset1TypeSubType1, 2, 3)
     *                                <-- Asset2Type (#)
     *
     * E1 <-- S1 <-- Seg1 <-- A1 (*) <-- A5 (*2) , A6 (*3)
     *           <-- Seg2 <-- A2 (*) <-- A7 (#), A8 (#)
     *    <-- S2 <-- Seg3 <-- A3 (*2), A4 (*3)
     */
    public static Map<String, Sourceable> setupDataForQuryByPredicates(
        AssetTypePersistencyService assetTypePersistencyService,
        AssetPersistencyService assetPersistencyService) throws IOException {

        Map<String, Sourceable> data = new HashMap<>();
        AssetType e1Type =
            createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID, "E1Type");
        data.put(e1Type.getName(), e1Type);
        AssetType s1Type = createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_SITE_TYPE_ID,
            "S1Type");
        data.put(s1Type.getName(), s1Type);
        AssetType seg1Type =
            createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_SEGMENT_TYPE_ID, "Seg1Type");
        data.put(seg1Type.getName(), seg1Type);
        AssetType asset1Type =
            createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_ASSET_TYPE_ID, "Asset1Type");
        data.put(asset1Type.getName(), asset1Type);
        AssetType asset2Type =
            createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_ASSET_TYPE_ID, "Asset2Type");
        data.put(asset2Type.getName(), asset2Type);
        AssetType asset1TypeSubType1 =
            createAssetTypeAndAssert(assetTypePersistencyService, asset1Type.getId(), "Asset1TypeSubType1");
        data.put(asset1TypeSubType1.getName(), asset1TypeSubType1);
        AssetType asset1TypeSubType2 =
            createAssetTypeAndAssert(assetTypePersistencyService, asset1Type.getId(), "Asset1TypeSubType2");
        data.put(asset1TypeSubType2.getName(), asset1TypeSubType2);
        AssetType asset1TypeSubType3 =
            createAssetTypeAndAssert(assetTypePersistencyService, asset1Type.getId(), "Asset1TypeSubType3");
        data.put(asset1TypeSubType3.getName(), asset1TypeSubType3);

        Asset e1 = createAssetInstanceAndAssert(assetPersistencyService, getUber(), e1Type.getId(), null, "E1");
        data.put(e1.getName(), e1);
        Asset s1 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), s1Type.getId(), e1.getId(), "E1_S1");
        data.put(s1.getName(), s1);
        Asset s2 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), s1Type.getId(), e1.getId(), "E1_S2");
        data.put(s2.getName(), s2);
        Asset seg1 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), seg1Type.getId(), s1.getId(),
                "E1_S1_Seg1");
        data.put(seg1.getName(), seg1);
        Asset seg2 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), seg1Type.getId(), s1.getId(),
                "E1_S1_Seg2");
        data.put(seg2.getName(), seg2);
        Asset seg3 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), seg1Type.getId(), s2.getId(),
                "E1_S2_Seg3");
        data.put(seg3.getName(), seg3);

        Asset asset1 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), asset1Type.getId(), seg1.getId(),
                "E1_S1_Seg1_Asset1_Asset1Type");
        data.put(asset1.getName(), asset1);
        Asset asset2 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), asset1Type.getId(), seg2.getId(),
                "E1_S1_Seg2_Asset2_Asset1Type");
        data.put(asset2.getName(), asset2);
        Asset asset3 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), asset1TypeSubType2.getId(), seg3.getId(),
                "E1_S2_Seg3_Asset3_Asset1TypeSubType2");
        data.put(asset3.getName(), asset3);
        Asset asset4 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), asset1TypeSubType3.getId(), seg3.getId(),
                "E1_S2_Seg3_Asset4_Asset1TypeSubType3");
        data.put(asset4.getName(), asset4);
        Asset asset5 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), asset1TypeSubType2.getId(), asset1.getId(),
                "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2");
        data.put(asset5.getName(), asset5);
        Asset asset6 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), asset1TypeSubType3.getId(), asset1.getId(),
                "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        data.put(asset6.getName(), asset6);
        Asset asset7 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), asset2Type.getId(), asset2.getId(),
                "E1_S1_Seg2_Asset2_Asset7_Asset2Type");
        data.put(asset7.getName(), asset7);
        Asset asset8 =
            createAssetInstanceAndAssert(assetPersistencyService, getUber(), asset2Type.getId(), asset2.getId(),
                "E1_S1_Seg2_Asset2_Asset8_Asset2Type");
        data.put(asset8.getName(), asset8);
        return data;
    }

    /**
     * creating the following type and instance hierarchy
     * ROOT_ENTERPRISE_TYPE <-- E1Type
     * ROOT_SITE_TYPE       <-- S1Type (^)
     *                      <-- S2Type (&)
     * ROOT_SEGMENT_TYPE    <-- Seg1Type (%)
     *                      <-- Seg2Type ($)
     * ROOT_ASSET_TYPE      <-- AssetAType (*)
     *                      <-- AssetBType (#)
     *                      <-- AssetCType (@)
     *                      <-- AssetDType  <-- AssetDSubType <-- AssetDSubSubType
     *
     * E1 <-- S1 (^) <-- Seg1 (%) <-- A1 (*)
     *                            <-- B1 (#)
     *               <-- Seg2 (%) <-- A2 (*)
     *                            <-- B2 (#)
     *               <-- Seg3 (%) <-- A3 (*)
     *                            <-- B3 (#)
     *                            <-- C3 (@)
     *    <-- S2 (&) <-- Seg4 ($) <-- A4 (*)
     *                            <-- B4 (#)
     *                            <-- C4 (@)
     */
    public static Map<String, BaseDataModel> setupDataForSearchByPredicates(
        AssetTypePersistencyService assetTypePersistencyService,
        AssetPersistencyService assetPersistencyService) throws IOException {

        Map<String, BaseDataModel> data = new HashMap<>();
        AssetTypePersistencyService typeSvc = assetTypePersistencyService;
        AssetType e1Type = createAssetTypeAndAssert(typeSvc, SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID, "E1Type");
        data.put(e1Type.getName(), e1Type);
        AssetType s1Type = createAssetTypeAndAssert(typeSvc, SeedOOTBData.ROOT_SITE_TYPE_ID, "S1Type");
        data.put(s1Type.getName(), s1Type);
        AssetType s2Type = createAssetTypeAndAssert(typeSvc, SeedOOTBData.ROOT_SITE_TYPE_ID, "S2Type");
        data.put(s2Type.getName(), s2Type);
        AssetType seg1Type = createAssetTypeAndAssert(typeSvc, SeedOOTBData.ROOT_SEGMENT_TYPE_ID, "Seg1Type");
        data.put(seg1Type.getName(), seg1Type);
        AssetType seg2Type = createAssetTypeAndAssert(typeSvc, SeedOOTBData.ROOT_SEGMENT_TYPE_ID, "Seg2Type");
        data.put(seg2Type.getName(), seg2Type);
        AssetType assetAType = createAssetTypeAndAssert(typeSvc, SeedOOTBData.ROOT_ASSET_TYPE_ID, "AssetAType");
        data.put(assetAType.getName(), assetAType);
        AssetType assetBType = createAssetTypeAndAssert(typeSvc, SeedOOTBData.ROOT_ASSET_TYPE_ID, "AssetBType");
        data.put(assetBType.getName(), assetBType);
        AssetType assetCType = createAssetTypeAndAssert(typeSvc, SeedOOTBData.ROOT_ASSET_TYPE_ID, "AssetCType");
        data.put(assetCType.getName(), assetCType);
        AssetType assetDType = createAssetTypeAndAssert(typeSvc, SeedOOTBData.ROOT_ASSET_TYPE_ID, "AssetDType");
        data.put(assetDType.getName(), assetDType);
        AssetType assetDSubType = createAssetTypeAndAssert(typeSvc, assetDType.getId(), "AssetDSubType");
        data.put(assetDSubType.getName(), assetDSubType);
        AssetType assetDSubSubType = createAssetTypeAndAssert(typeSvc, assetDSubType.getId(), "AssetDSubSubType");
        data.put(assetDSubSubType.getName(), assetDSubSubType);

        AssetPersistencyService instanceSvc = assetPersistencyService;
        Asset e1 = createAssetInstanceAndAssert(instanceSvc, getUber(), e1Type.getId(), null, "E1");
        data.put(e1.getName(), e1);
        Asset site1 = createAssetInstanceAndAssert(instanceSvc, getUber(), s1Type.getId(), e1.getId(), "E1_S1");
        data.put(site1.getName(), site1);
        Asset site2 = createAssetInstanceAndAssert(instanceSvc, getUber(), s2Type.getId(), e1.getId(), "E1_S2");
        data.put(site2.getName(), site2);
        for (int i = 1; i <= 3; i++) {
            Asset seg =
                createAssetInstanceAndAssert(instanceSvc, getUber(), seg1Type.getId(), site1.getId(), "E1_S1_Seg" + i);
            data.put(seg.getName(), seg);
        }
        Asset seg4 =
            createAssetInstanceAndAssert(instanceSvc, getUber(), seg2Type.getId(), site2.getId(), "E1_S2_Seg4");
        data.put(seg4.getName(), seg4);

        BaseDataModel seg1 = data.get("E1_S1_Seg1");
        Asset a1 =
            createAssetInstanceAndAssert(instanceSvc, getUber(), assetAType.getId(), seg1.getId(), "E1_S1_Seg1_A1");
        data.put(a1.getName(), a1);
        Asset b1 =
            createAssetInstanceAndAssert(instanceSvc, getUber(), assetBType.getId(), seg1.getId(), "E1_S1_Seg1_B1");
        data.put(b1.getName(), b1);

        BaseDataModel seg2 = data.get("E1_S1_Seg2");
        Asset a2 =
            createAssetInstanceAndAssert(instanceSvc, getUber(), assetAType.getId(), seg2.getId(), "E1_S1_Seg2_A2");
        data.put(a2.getName(), a2);
        Asset b2 =
            createAssetInstanceAndAssert(instanceSvc, getUber(), assetBType.getId(), seg2.getId(), "E1_S1_Seg2_B2");
        data.put(b2.getName(), b2);

        Asset a3 =
            createAssetInstanceAndAssert(instanceSvc, getUber(), assetAType.getId(), data.get("E1_S1_Seg3").getId(),
                "E1_S1_Seg3_A3");
        data.put(a3.getName(), a3);
        Asset b3 =
            createAssetInstanceAndAssert(instanceSvc, getUber(), assetBType.getId(), data.get("E1_S1_Seg3").getId(),
                "E1_S1_Seg3_B3");
        data.put(b3.getName(), b3);
        Asset c3 =
            createAssetInstanceAndAssert(instanceSvc, getUber(), assetCType.getId(), data.get("E1_S1_Seg3").getId(),
                "E1_S1_Seg3_C3");
        data.put(c3.getName(), c3);

        Asset a4 =
            createAssetInstanceAndAssert(instanceSvc, getUber(), assetAType.getId(), data.get("E1_S2_Seg4").getId(),
                "E1_S2_Seg4_A4");
        data.put(a4.getName(), a4);
        Asset b4 =
            createAssetInstanceAndAssert(instanceSvc, getUber(), assetBType.getId(), data.get("E1_S2_Seg4").getId(),
                "E1_S2_Seg4_B4");
        data.put(b4.getName(), b4);
        Asset c4 =
            createAssetInstanceAndAssert(instanceSvc, getUber(), assetCType.getId(), data.get("E1_S2_Seg4").getId(),
                "E1_S2_Seg4_C4");
        data.put(c4.getName(), c4);

        return data;
    }
}
