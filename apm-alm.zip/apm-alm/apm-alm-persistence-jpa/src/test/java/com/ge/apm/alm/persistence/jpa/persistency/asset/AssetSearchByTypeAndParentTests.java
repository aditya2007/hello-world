/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.io.IOException;
import java.util.Collections;
import java.util.Map;

import org.assertj.core.util.Sets;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_ASSET_TYPE_ID;
import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_SEGMENT_TYPE_ID;
import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_SITE_TYPE_ID;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUnPrivileged;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests asset searches using {@link com.ge.apm.alm.model.query.AssetPredicate}, with
 * {@link com.ge.apm.alm.model.query.TypePredicate} only.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetSearchByTypeAndParentTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;
    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Test
    @Transactional
    public void getAssets_byTypeIdAndParentSourceKey_equals() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType seg1Type = (AssetType) data.get("Seg1Type");
        AssetPredicate predicate =
            AssetPredicate.builder().offset(0).pageSize(251).type(
                TypePredicate.builder().ids(Sets.newLinkedHashSet(ROOT_ASSET_TYPE_ID)).deepSearch(true)
                    .build()
            ).childOperand(Operand.AND).childPredicates(
                Collections.singletonList(
                    AssetPredicate.builder().parent(
                        ParentPredicate.builder().deepSearch(true).type(
                            TypePredicate.builder().deepSearch(true).pageSize(250).sourceKey(seg1Type.getSourceKey())
                                .build()
                        ).build()
                    ).build()
                )
            ).build();

        String[] assetsUnderSeg1Type =
            { "E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3",
                "E1_S1_Seg3_C3" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg3")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg3_A3", "E1_S1_Seg3_B3", "E1_S1_Seg3_C3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_byTypeIdAndParentSourceKey_like() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType seg1Type = (AssetType) data.get("Seg1Type");
        AssetPredicate predicate =
            AssetPredicate.builder().offset(0).pageSize(251).attributeSelectEnum(AttributeSelectEnum.FULL)
                .parent(ParentPredicate.builder().attributeSelectEnum(
                    AttributeSelectEnum.BASIC).pageSize(250).build())
                .type(
                    TypePredicate.builder().ids(Sets.newLinkedHashSet(ROOT_ASSET_TYPE_ID)).deepSearch(true)
                        .attributeSelectEnum(AttributeSelectEnum.ATTRIBUTES).pageSize(250)
                        .build()
                ).childOperand(Operand.AND).childPredicates(
                Collections.singletonList(
                    AssetPredicate.builder().parent(
                        ParentPredicate.builder().deepSearch(true).attributeSelectEnum(AttributeSelectEnum.BASIC)
                            .type(TypePredicate.builder().deepSearch(true).pageSize(250)
                                .attributeSelectEnum(AttributeSelectEnum.BASIC)
                                .sourceKey("*" + seg1Type.getSourceKey() + "*")
                                .build()
                            ).build()
                    ).build()
                )
            ).build();

        String[] assetsUnderSeg1Type =
            { "E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3",
                "E1_S1_Seg3_C3" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg3")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg3_A3", "E1_S1_Seg3_B3", "E1_S1_Seg3_C3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);

        predicate.getChildPredicates().get(0).getParent().getType()
            .setSourceKey("*" + ((AssetType) data.get("Seg2Type")).getSourceKey() + "*");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
    }

    @Test
    @Transactional
    public void getAssets_byTypeIdAndParentSourceKey_rightLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType seg1Type = (AssetType) data.get("Seg1Type");
        AssetPredicate predicate =
            AssetPredicate.builder().offset(0).pageSize(251).type(
                TypePredicate.builder().ids(Sets.newLinkedHashSet(ROOT_ASSET_TYPE_ID)).deepSearch(true)
                    .build()
            ).childOperand(Operand.AND).childPredicates(
                Collections.singletonList(
                    AssetPredicate.builder().parent(
                        ParentPredicate.builder().deepSearch(true).type(
                            TypePredicate.builder().deepSearch(true).pageSize(250)
                                .sourceKey(seg1Type.getSourceKey() + "*")
                                .build()
                        ).build()
                    ).build()
                )
            ).build();

        String[] assetsUnderSeg1Type =
            { "E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3",
                "E1_S1_Seg3_C3" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg3")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg3_A3", "E1_S1_Seg3_B3", "E1_S1_Seg3_C3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_byTypeIdAndParentSourceKey_leftLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType seg1Type = (AssetType) data.get("Seg1Type");
        AssetPredicate predicate =
            AssetPredicate.builder().offset(0).pageSize(251).type(
                TypePredicate.builder().ids(Sets.newLinkedHashSet(ROOT_ASSET_TYPE_ID)).deepSearch(true)
                    .build()
            ).childOperand(Operand.AND).childPredicates(
                Collections.singletonList(
                    AssetPredicate.builder().parent(
                        ParentPredicate.builder().deepSearch(true).type(
                            TypePredicate.builder().deepSearch(true).pageSize(250)
                                .sourceKey("*" + seg1Type.getSourceKey())
                                .build()
                        ).build()
                    ).build()
                )
            ).build();

        String[] assetsUnderSeg1Type =
            { "E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3",
                "E1_S1_Seg3_C3" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg3")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg3_A3", "E1_S1_Seg3_B3", "E1_S1_Seg3_C3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_byTypeIdAndParentSourceKey_equals2() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType s1Type = (AssetType) data.get("S1Type");
        AssetPredicate predicate =
            AssetPredicate.builder().offset(0).pageSize(251).type(
                TypePredicate.builder().ids(Sets.newLinkedHashSet(ROOT_ASSET_TYPE_ID)).deepSearch(true)
                    .build()
            ).childOperand(Operand.AND).childPredicates(
                Collections.singletonList(
                    AssetPredicate.builder().parent(
                        ParentPredicate.builder().deepSearch(true).type(
                            TypePredicate.builder().deepSearch(true).pageSize(250).sourceKey(s1Type.getSourceKey())
                                .build()
                        ).build()
                    ).build()
                )
            ).build();

        String[] assetsUnderSeg1Type =
            { "E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3",
                "E1_S1_Seg3_C3" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_byTypeIdAndParentSourceKey_like2() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType s1Type = (AssetType) data.get("S1Type");
        AssetPredicate predicate =
            AssetPredicate.builder().offset(0).pageSize(251).type(
                TypePredicate.builder().ids(Sets.newLinkedHashSet(ROOT_ASSET_TYPE_ID)).deepSearch(true)
                    .build()
            ).childOperand(Operand.AND).childPredicates(
                Collections.singletonList(
                    AssetPredicate.builder().parent(
                        ParentPredicate.builder().deepSearch(true).type(
                            TypePredicate.builder().deepSearch(true).pageSize(250)
                                .sourceKey("*" + s1Type.getSourceKey() + "*")
                                .build()
                        ).build()
                    ).build()
                )
            ).build();

        String[] assetsUnderSeg1Type =
            { "E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3",
                "E1_S1_Seg3_C3" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_byTypeIdAndParentSourceKey_rightLike2() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType s1Type = (AssetType) data.get("S1Type");
        AssetPredicate predicate =
            AssetPredicate.builder().offset(0).pageSize(251).type(
                TypePredicate.builder().ids(Sets.newLinkedHashSet(ROOT_ASSET_TYPE_ID)).deepSearch(true)
                    .build()
            ).childOperand(Operand.AND).childPredicates(
                Collections.singletonList(
                    AssetPredicate.builder().parent(
                        ParentPredicate.builder().deepSearch(true).type(
                            TypePredicate.builder().deepSearch(true).pageSize(250)
                                .sourceKey(s1Type.getSourceKey() + "*")
                                .build()
                        ).build()
                    ).build()
                )
            ).build();

        String[] assetsUnderSeg1Type =
            { "E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3",
                "E1_S1_Seg3_C3" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_byTypeIdAndParentSourceKey_leftLike2() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType s1Type = (AssetType) data.get("S1Type");
        AssetPredicate predicate =
            AssetPredicate.builder().offset(0).pageSize(251).type(
                TypePredicate.builder().ids(Sets.newLinkedHashSet(ROOT_ASSET_TYPE_ID)).deepSearch(true)
                    .build()
            ).childOperand(Operand.AND).childPredicates(
                Collections.singletonList(
                    AssetPredicate.builder().parent(
                        ParentPredicate.builder().deepSearch(true).type(
                            TypePredicate.builder().deepSearch(true).pageSize(250)
                                .sourceKey("*" + s1Type.getSourceKey())
                                .build()
                        ).build()
                    ).build()
                )
            ).build();

        String[] assetsUnderSeg1Type =
            { "E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3",
                "E1_S1_Seg3_C3" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(assetsUnderSeg1Type.length).extracting(Asset::getName).containsOnly(assetsUnderSeg1Type);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_bySiteTypeIdAndParentSourceKey_rightLike() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType e1Type = (AssetType) data.get("E1Type");
        AssetPredicate predicate =
            AssetPredicate.builder().offset(0).pageSize(251).type(
                TypePredicate.builder().ids(Sets.newLinkedHashSet(ROOT_SITE_TYPE_ID)).deepSearch(true)
                    .build()
            ).childOperand(Operand.AND).childPredicates(
                Collections.singletonList(
                    AssetPredicate.builder().parent(
                        ParentPredicate.builder().deepSearch(true).type(
                            TypePredicate.builder().deepSearch(true).pageSize(250)
                                .sourceKey(e1Type.getSourceKey() + "*")
                                .build()
                        ).build()
                    ).build()
                )
            ).build();

        String[] sitesUnderE1 = { "E1_S1", "E1_S2" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(sitesUnderE1.length).extracting(Asset::getName).containsOnly(sitesUnderE1);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(sitesUnderE1.length).extracting(Asset::getName).containsOnly(sitesUnderE1);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_bySegmentTypeIdAndParentSourceKey_leftLike()
        throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType s1Type = (AssetType) data.get("S1Type");
        AssetPredicate predicate =
            AssetPredicate.builder().offset(0).pageSize(251).type(
                TypePredicate.builder().ids(Sets.newLinkedHashSet(ROOT_SEGMENT_TYPE_ID)).deepSearch(true)
                    .build()
            ).childOperand(Operand.AND).childPredicates(
                Collections.singletonList(
                    AssetPredicate.builder().parent(
                        ParentPredicate.builder().deepSearch(true).type(
                            TypePredicate.builder().deepSearch(true).pageSize(250)
                                .sourceKey("*" + s1Type.getSourceKey())
                                .build()
                        ).build()
                    ).build()
                )
            ).build();

        String[] segmentsUnderSite1 = { "E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(segmentsUnderSite1.length).extracting(Asset::getName).containsOnly(segmentsUnderSite1);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(segmentsUnderSite1.length).extracting(Asset::getName).containsOnly(segmentsUnderSite1);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(segmentsUnderSite1.length).extracting(Asset::getName).containsOnly(segmentsUnderSite1);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(TestUtils.NULL_UUID), predicate))
            .hasSize(0);
    }

    Map<String, BaseDataModel> setupData() throws IOException {
        return PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService, assetPersistencyService);
    }
}
