/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.assertj.core.util.Maps;
import org.assertj.core.util.Sets;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_ASSET_TYPE_ID;
import static com.ge.apm.alm.model.query.Operand.OR;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUnPrivileged;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests asset searches using {@link com.ge.apm.alm.model.query.AssetPredicate}, with
 * {@link com.ge.apm.alm.model.query.TypePredicate} only.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetSearchByTypeTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    /**
     * Search assets without criteria, only with different levels of permissions.
     */
    @Test
    @Transactional
    public void getAssets_noCriteria_variousPermissions() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(
            17);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate)).hasSize(
            17);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1"), data.get("E1_S2")),
                predicate)).hasSize(16);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate)).hasSize(
            11);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT,
            getUnPrivileged(data.get("E1_S1_Seg1"), data.get("E1_S1_Seg2")), predicate)).hasSize(6)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2",
            "E1_S1_Seg2_A2", "E1_S1_Seg2_B2");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Search assets where (type id = "AssetBType")
     */
    @Test
    @Transactional
    public void getAssets_byTypeId() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().type(
            TypePredicate.builder().ids(Collections.singleton(data.get("AssetBType").getId())).build()).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(4)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_B1", "E1_S1_Seg2_B2", "E1_S1_Seg3_B3",
            "E1_S2_Seg4_B4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1"), data.get("E1_S2")),
                predicate)).hasSize(4).extracting(Asset::getName).containsOnly("E1_S1_Seg1_B1", "E1_S1_Seg2_B2",
            "E1_S1_Seg3_B3", "E1_S2_Seg4_B4");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Search assets where (type id = "AssetBType")
     */
    @Test
    @Transactional
    public void getAssets_byType_Attribute() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().attributes(
            Maps.newHashMap("Test Number", String.valueOf(Integer.MIN_VALUE))).pageSize(251).type(
            TypePredicate.builder().ids(Collections.singleton(SeedOOTBData.ROOT_ASSET_TYPE_ID)).attributeSelectEnum(
                AttributeSelectEnum.ATTRIBUTES).deepSearch(true).build()).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize
            (10);
    }

    /**
     * Search assets where (type id = "ROOT_ASSET_TYPE_ID"), with or without deep search, and accessible from
     * different point in the asset hierarchy.
     */
    @Test
    @Transactional
    public void getAssets_byRootAssetTypeId_accessibleFromHierarchy() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().type(
            TypePredicate.builder().ids(Collections.singleton(ROOT_ASSET_TYPE_ID)).build()).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(0);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT,
            getUnPrivileged(data.get("E1"), data.get("E1_S1")), predicate)).hasSize(0);

        predicate.getType().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(10)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2",
            "E1_S1_Seg3_A3", "E1_S1_Seg3_B3", "E1_S1_Seg3_C3", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT,
            getUnPrivileged(data.get("E1"), data.get("E1_S1")), predicate)).hasSize(10)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2",
            "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3", "E1_S1_Seg3_C3", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4",
            "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate)).hasSize(
            7).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2",
            "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3", "E1_S1_Seg3_C3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg1")), predicate))
            .hasSize(2).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg1_B1");
    }

    /**
     * Search assets where (parent type id = "AssetBType")
     */
    @Test
    @Transactional
    public void getAssets_byParentTypeIds() throws IOException {
        Map<String, BaseDataModel> data = setupMoreData();

        AssetPredicate predicate = AssetPredicate.builder().type(TypePredicate.builder().parent(
            ParentPredicate.builder().ids(com.google.common.collect.Sets.newHashSet(data.get("AssetDType").getId()))
                .build()).build()).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly("E1_S2_Seg5_D1Sub");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly("E1_S2_Seg5_D1Sub");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);

        predicate.getType().getParent().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(2)
            .extracting(Asset::getName).containsOnly("E1_S2_Seg5_D1Sub", "E1_S2_Seg5_D1SubSub");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Collections.singletonList(data.get("E1").getId()), predicate)).hasSize(2)
            .extracting(Asset::getName).containsOnly("E1_S2_Seg5_D1Sub", "E1_S2_Seg5_D1SubSub");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Search assets where (parent type id = "AssetBType")
     */
    @Test
    @Transactional
    public void getAssets_byParentTypeIds_withRootAssetTypeId() throws IOException {
        Map<String, BaseDataModel> data = setupMoreData();
        AssetPredicate predicate = AssetPredicate.builder().type(TypePredicate.builder().parent(
            ParentPredicate.builder().ids(com.google.common.collect.Sets.newHashSet(ROOT_ASSET_TYPE_ID)).build())
            .build()).build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(11)
            .extracting(Asset::getName).contains("E1_S2_Seg5_D1");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate)).hasSize(11)
            .extracting(Asset::getName).contains("E1_S2_Seg5_D1");
        predicate.getType().getParent().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(13)
            .extracting(Asset::getName).contains("E1_S2_Seg5_D1", "E1_S2_Seg5_D1Sub", "E1_S2_Seg5_D1SubSub");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate)).hasSize(13)
            .extracting(Asset::getName).contains("E1_S2_Seg5_D1", "E1_S2_Seg5_D1Sub", "E1_S2_Seg5_D1SubSub");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg1")), predicate))
            .hasSize(2).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg1_B1");
    }

    /**
     * Search assets where (type name like "*BType" or type name like "AssetC*")
     */
    @Test
    @Transactional
    public void getAssets_byTypeName() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().type(TypePredicate.builder().name("*BType").build())
            .childOperand(OR).childPredicates(Collections
                .singletonList(AssetPredicate.builder().type(TypePredicate.builder().name("AssetC*").build()).build()))
            .build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(6)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_B1", "E1_S1_Seg2_B2", "E1_S1_Seg3_B3", "E1_S2_Seg4_B4",
            "E1_S1_Seg3_C3", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S2")), predicate)).hasSize(
            2).extracting(Asset::getName).containsOnly("E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
    }

    /**
     * Three levels of asset type hierarchies. Top level has no assets created based on it. Level two has 4 assets,
     * whereas level three has 5. Searching over them at each level of the type hierarchy, with or without deep search.
     */
    @Test
    @Transactional
    public void getAssets_bySourceKeyOnTypeHierarchy() throws IOException {
        // This is the user cases provided by TPM John Tease.

        Map<String, BaseDataModel> data = setupData();

        // create 4 assets based on AssetDSubType, parent is E1_S1_Seg2
        int dsubCount = 4;
        String seg2Id = data.get("E1_S1_Seg2").getId();
        String assetDSubType = data.get("AssetDSubType").getId();
        List<Asset> dsubAssets = new ArrayList<>();
        for (int i = 0; i < dsubCount; i++) {
            dsubAssets.add(TestUtils
                .createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), assetDSubType, seg2Id,
                    "AssetDSub" + (i + 1)));
        }

        // create 9 assets based on AssetDSubType, parent is E1_S1_Seg2
        int dsubSubCount = 5;
        String assetDSubSubType = data.get("AssetDSubSubType").getId();
        List<Asset> dsubSubAssets = new ArrayList<>();
        for (int i = 0; i < dsubSubCount; i++) {
            dsubSubAssets.add(TestUtils
                .createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), assetDSubSubType, seg2Id,
                    "AssetDSubSub" + (i + 1)));
        }

        // child, only 1 level type hierarchy, deep search or not makes no difference
        AssetPredicate findAllDSubSubAsset = AssetPredicate.builder().type(
            TypePredicate.builder().sourceKey("AssetDSubSubType").build()).build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), findAllDSubSubAsset))
            .hasSize(dsubSubCount).extracting(Asset::getName).containsOnly("AssetDSubSub1", "AssetDSubSub2",
            "AssetDSubSub3", "AssetDSubSub4", "AssetDSubSub5");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(seg2Id), findAllDSubSubAsset))
            .hasSize(dsubSubCount).extracting(Asset::getName).containsOnly("AssetDSubSub1", "AssetDSubSub2",
            "AssetDSubSub3", "AssetDSubSub4", "AssetDSubSub5");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), findAllDSubSubAsset))
            .hasSize(0);
        findAllDSubSubAsset.getType().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), findAllDSubSubAsset))
            .hasSize(dsubSubCount);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(seg2Id), findAllDSubSubAsset))
            .hasSize(dsubSubCount);

        // paren, 2 levels type hierarchies, deep search gets the leaf nodes
        AssetPredicate findAllAssetSubD = AssetPredicate.builder().type(
            TypePredicate.builder().sourceKey("AssetDSubType").build()).build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), findAllAssetSubD))
            .hasSize(dsubCount).extracting(Asset::getName).containsOnly("AssetDSub1", "AssetDSub2", "AssetDSub3",
            "AssetDSub4");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(seg2Id), findAllAssetSubD))
            .hasSize(dsubCount).extracting(Asset::getName).containsOnly("AssetDSub1", "AssetDSub2", "AssetDSub3",
            "AssetDSub4");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), findAllAssetSubD))
            .hasSize(0);
        findAllAssetSubD.getType().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), findAllAssetSubD))
            .hasSize(dsubCount + dsubSubCount);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(seg2Id), findAllAssetSubD))
            .hasSize(dsubCount + dsubSubCount);
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), findAllAssetSubD))
            .hasSize(0);

        // grand parent, has no immediate children assets, but deep search will fetch all
        AssetPredicate findAllAssetD = AssetPredicate.builder().type(
            TypePredicate.builder().sourceKey("AssetDType").build()).build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), findAllAssetD))
            .hasSize(0);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(seg2Id), findAllAssetD)).hasSize(
            0);
        findAllAssetD.getType().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), findAllAssetD))
            .hasSize(dsubCount + dsubSubCount);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(seg2Id), findAllAssetD)).hasSize(
            dsubCount + dsubSubCount);
    }

    @Test
    @Transactional
    public void getAssets_byRootAssetId_andAssetTypeId() throws IOException {
        Map<String, BaseDataModel> data = setupMoreData();
        AssetPredicate predicate = AssetPredicate.builder().type(TypePredicate.builder().ids(
            Sets.newLinkedHashSet(ROOT_ASSET_TYPE_ID)).deepSearch(true).build()).childOperand(Operand.AND)
            .childPredicates(Collections.singletonList(AssetPredicate.builder().type(TypePredicate.builder().ids(
                Sets.newLinkedHashSet(data.get("AssetDType").getId())).deepSearch(true).build()).build())).build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(3)
            .extracting(Asset::getName).containsOnly("E1_S2_Seg5_D1", "E1_S2_Seg5_D1Sub", "E1_S2_Seg5_D1SubSub");
    }

    @Test
    @Transactional
    public void getAssets_byRootAssetTypeId_andTypeNameLike_complicated()
        throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().type(TypePredicate.builder().ids(
            Sets.newLinkedHashSet(ROOT_ASSET_TYPE_ID)).deepSearch(true).build()).childOperand(Operand.AND)
            .childPredicates(Collections.singletonList(AssetPredicate.builder().type(TypePredicate.builder().name(
                "AssetB*").deepSearch(true).build()).build())).pageSize(101).build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(4)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_B1", "E1_S1_Seg2_B2", "E1_S1_Seg3_B3",
            "E1_S2_Seg4_B4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Collections.singletonList(data.get("E1").getId()), predicate)).hasSize(4)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_B1", "E1_S1_Seg2_B2", "E1_S1_Seg3_B3",
            "E1_S2_Seg4_B4");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_byRootAssetTypeId_andNameLike_simplified() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().type(TypePredicate.builder().name("AssetB*").ids(
            Sets.newLinkedHashSet(ROOT_ASSET_TYPE_ID)).deepSearch(true).build()).pageSize(101).build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(4)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_B1", "E1_S1_Seg2_B2", "E1_S1_Seg3_B3",
            "E1_S2_Seg4_B4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate)).hasSize(4)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_B1", "E1_S1_Seg2_B2", "E1_S1_Seg3_B3",
            "E1_S2_Seg4_B4");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    Map<String, BaseDataModel> setupData() throws IOException {
        return PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService, assetPersistencyService);
    }

    private Map<String, BaseDataModel> setupMoreData() throws IOException {
        Map<String, BaseDataModel> rslt = setupData();
        Asset e1S2Seg5 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            rslt.get("S1Type").getId(), rslt.get("E1_S2").getId(), "E1_S2_Seg5");
        TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            rslt.get("AssetDType").getId(), e1S2Seg5.getId(), "E1_S2_Seg5_D1");
        TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            rslt.get("AssetDSubType").getId(), e1S2Seg5.getId(), "E1_S2_Seg5_D1Sub");
        TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            rslt.get("AssetDSubSubType").getId(), e1S2Seg5.getId(), "E1_S2_Seg5_D1SubSub");
        return rslt;
    }
}
