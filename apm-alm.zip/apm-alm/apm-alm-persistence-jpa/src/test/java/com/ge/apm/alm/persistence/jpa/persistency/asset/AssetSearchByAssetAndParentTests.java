/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests asset searches using {@link com.ge.apm.alm.model.query.AssetPredicate}, with
 * {@link com.ge.apm.alm.model.query.ParentPredicate}.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetSearchByAssetAndParentTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;
    @Autowired
    private AssetPersistencyService assetPersistencyService;

    ////////////////////////////////////////////////////////////////////////////////////////////
    // tests with AND/OR combinations of name, sourceKey, description, with parent criteria
    ////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * (name like "*_A*" or name like "*_B*") and (parent name = "E1_S1_Seg1 or parent name like "E1_S2_Seg4")
     */
    @Test
    @Transactional
    public void nameOrName_and_parentOrParent() throws IOException {
        Map<String, BaseDataModel> data = setupData();

        AssetPredicate nameLikeA_or_nameLikeB = AssetPredicate.builder().childPredicates(Arrays.asList(
            AssetPredicate.builder().name("*_A*").peerOperand(Operand.OR).build(),
            AssetPredicate.builder().name("*_B*").build()
        )).peerOperand(Operand.AND).build();
        AssetPredicate parentSeg1_or_Seg4 =
            AssetPredicate.builder().childPredicates(Arrays.asList(
                AssetPredicate.builder().parent(ParentPredicate.builder().name("E1_S1_Seg1").build())
                    .peerOperand(Operand.OR)
                    .build(),
                AssetPredicate.builder().parent(ParentPredicate.builder().name("E1_S2_Seg4").build()).build())
            ).build();

        AssetPredicate predicate = AssetPredicate.builder().childPredicates(Arrays.asList(
            nameLikeA_or_nameLikeB, parentSeg1_or_Seg4
        )).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(4)
            .extracting(Asset::getName)
            .containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1_S1").getId(), data.get("E1_S2").getId()),
                predicate))
            .hasSize(4)
            .extracting(Asset::getName)
            .containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    Map<String, BaseDataModel> setupData() throws IOException {
        return PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService, assetPersistencyService);
    }
}
