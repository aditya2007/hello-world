/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.tag.correlation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.exceptions.IncompatibleItemsException;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.utils.TagPredicateUtils;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.TEST_TENANT;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUber;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TagMergeCorrelatedGroupsTests extends TagCorrelationBaseTest {

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void mergeCorrelatedGroups_sourceGroupNotFound_asUber() throws PersistencyServiceException {
        groupPersistencyService.mergeCorrelatedGroups(TEST_TENANT, getUber(), null, null);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void mergeCorrelatedGroups_sourceGroupNotFound_asPriviledged()
        throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        groupPersistencyService
            .mergeCorrelatedGroups(TEST_TENANT, Collections.singletonList(assets.get("E1_S1").getId()), null, null);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void mergeCorrelatedGroups_targetGroupNotFound_asUber() throws PersistencyServiceException, IOException {
        createTypes(assetTypePersistencyService);
        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        groupPersistencyService.mergeCorrelatedGroups(TEST_TENANT, getUber(), group, null);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void mergeCorrelatedGroups_targetGroupNotFound_asPriviledged()
        throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        groupPersistencyService
            .mergeCorrelatedGroups(TEST_TENANT, Collections.singletonList(assets.get("E1_S1").getId()), group, null);
    }

    @Test(expected = IncompatibleItemsException.class)
    @Transactional
    public void mergeCorrelatedGroups_differentAssetsNotAllowed() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 1;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);
        List<Tag> tags2 =
            createTagData(tagPersistencyService, types.get("MyTagType").getId(), assets.get("E1_S1_Seg1"),
                count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);
        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1").getId()),
                group.getId(), items)).isEqualTo(items.size());
        assertThat(groupPersistencyService
            .getGroupItems(TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1_Asset1").getId()),
                group.getId())).hasSize(items.size()).extracting(AssetGroupItem::getPosition).containsOnly(1);

        // create the 2nd group with 1 tag
        AssetGroup group2 = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group2))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);
        List<AssetGroupItem> items2 = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items2.add(TagPredicateUtils.newTagCorrelationItem(tags2.get(i), group2.getId(), i + 1));
        }
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1").getId()),
                group2.getId(),
                items2)).isEqualTo(items2.size());
        assertThat(groupPersistencyService
            .getGroupItems(TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1").getId()), group2.getId()))
            .hasSize(items2.size()).extracting(AssetGroupItem::getPosition).containsOnly(1);
        groupPersistencyService.mergeCorrelatedGroups(TEST_TENANT, getUber(), group, group2);
    }

    @Test
    @Transactional
    public void mergeCorrelatedGroups() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 6;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        // create the first group with 2 tags
        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1").getId()),
                group.getId(), items))
            .isEqualTo(items.size());
        assertThat(groupPersistencyService
            .getGroupItems(TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1_Asset1").getId()),
                group.getId()))
            .hasSize(items.size()).extracting(AssetGroupItem::getPosition).containsOnly(1, 2);

        // create the 2nd group with 4 tags
        AssetGroup group2 = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group2))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items2 = new ArrayList<>();
        for (int i = 2; i < count; i++) {
            items2.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group2.getId(), i - 1));
        }
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1").getId()),
                group2.getId(),
                items2)).isEqualTo(items2.size());
        assertThat(groupPersistencyService
            .getGroupItems(TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1_Asset1").getId()),
                group2.getId()))
            .hasSize(items2.size()).extracting(AssetGroupItem::getPosition).containsOnly(1, 2, 3, 4);

        // append group to group2
        List<AssetGroupItem> merged = groupPersistencyService
            .mergeCorrelatedGroups(TEST_TENANT, Arrays.asList(assets.get("E1").getId(), assets.get("E1_S1").getId()),
                group2, group);
        assertThat(merged.size()).isEqualTo(count);
        int[] index = new int[]{2, 3, 4, 5, 0, 1};
        for (int i = 0; i < count; i++) {
            assertThat(merged.get(i).getPosition()).isEqualTo(i + 1);
            assertThat(merged.get(i).getObjectId()).isEqualTo(tags.get(index[i]).getId());
        }
    }
}
