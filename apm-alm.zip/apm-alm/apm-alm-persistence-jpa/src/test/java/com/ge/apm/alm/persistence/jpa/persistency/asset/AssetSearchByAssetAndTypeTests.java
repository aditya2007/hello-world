/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests asset searches using {@link com.ge.apm.alm.model.query.AssetPredicate}, with
 * {@link com.ge.apm.alm.model.query.TypePredicate}.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetSearchByAssetAndTypeTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;
    @Autowired
    private AssetPersistencyService assetPersistencyService;

    ////////////////////////////////////////////////////////////////////////////////////////////
    // AssetPredicate tests with AND/OR combinations of name, sourceKey, description, with type criteria
    ////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * (name like "E1_S1_Seg1_*" and (type = "AssetAType")) or ((name like "E1_S2*" and (type = "AssetBType")))
     */
    @Test
    @Transactional
    public void nameType_or_nameType() throws IOException {
        Map<String, BaseDataModel> data = setupData();

        AssetPredicate nameLike_typeB = AssetPredicate.builder().sourceKey("E1_S2*")
            .type(TypePredicate.builder().name("AssetBType").build()).build();

        AssetPredicate nameLike_typeA =
            AssetPredicate.builder().name("E1_S1_Seg1_*").type(TypePredicate.builder().name("AssetAType").build())
                .build();

        nameLike_typeA.setChildOperand(Operand.OR);
        nameLike_typeA.setChildPredicates(Collections.singletonList(nameLike_typeB));

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), nameLike_typeA))
            .hasSize(2)
            .extracting(Asset::getName)
            .containsOnly("E1_S1_Seg1_A1", "E1_S2_Seg4_B4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Collections.singletonList(data.get("E1").getId()), nameLike_typeA))
            .hasSize(2)
            .extracting(Asset::getName)
            .containsOnly("E1_S1_Seg1_A1", "E1_S2_Seg4_B4");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), nameLike_typeA))
            .hasSize(0);
    }

    /**
     * (name like "E1_S1_Seg1_*" and (type = "AssetAType")) or
     * ((name like "E1_S2*" and (type = "AssetBType")) or (name like "E1_S2*" and (type = "AssetCType")))
     *
     * alternatively
     *
     * (name like "E1_S1_Seg1_*" and (type = "AssetAType")) or (name like "E1_S2*" and (type = "AssetBType" or type
     * = "AssetCType"))
     */
    @Test
    @Transactional
    public void nameType_or_nameType_or_nameType() throws IOException {
        Map<String, BaseDataModel> data = setupData();

        AssetPredicate name_typeA =
            AssetPredicate.builder().name("E1_S1_Seg1_*").type(TypePredicate.builder().name("AssetAType").build())
                .build();
        AssetPredicate name_typeB =
            AssetPredicate.builder().name("E1_S2*").type(TypePredicate.builder().name("AssetBType").build())
                .peerOperand(Operand.OR).build();
        AssetPredicate name_typeC =
            AssetPredicate.builder().name("E1_S2*").type(TypePredicate.builder().name("AssetCType").build())
                .build();
        name_typeA.setChildOperand(Operand.OR);
        name_typeA.setChildPredicates(Arrays.asList(name_typeB, name_typeC));
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), name_typeA)).hasSize(3)
            .extracting(Asset::getName)
            .containsOnly("E1_S1_Seg1_A1", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1_S1").getId(), data.get("E1_S2").getId()),
                name_typeA))
            .hasSize(3)
            .extracting(Asset::getName)
            .containsOnly("E1_S1_Seg1_A1", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), name_typeA))
            .hasSize(0);

        AssetPredicate name_typeB_or_typeC = AssetPredicate.builder().name("E1_S2*").build();
        AssetPredicate typeB =
            AssetPredicate.builder().type(TypePredicate.builder().name("AssetBType").build()).peerOperand(Operand.OR)
                .build();
        AssetPredicate typeC =
            AssetPredicate.builder().type(TypePredicate.builder().name("AssetCType").build()).peerOperand(Operand.OR)
                .build(); // the OR will be ignored
        name_typeB_or_typeC.setChildOperand(Operand.AND);
        name_typeB_or_typeC.setChildPredicates(Arrays.asList(typeB, typeC));
        name_typeA.setChildPredicates(Collections.singletonList(name_typeB_or_typeC));
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), name_typeA)).hasSize(3)
            .extracting(Asset::getName)
            .containsOnly("E1_S1_Seg1_A1", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1_S1").getId(), data.get("E1_S2").getId()),
                name_typeA))
            .hasSize(3)
            .extracting(Asset::getName)
            .containsOnly("E1_S1_Seg1_A1", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), name_typeA))
            .hasSize(0);
    }

    Map<String, BaseDataModel> setupData() throws IOException {
        return PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService, assetPersistencyService);
    }
}
