/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.config;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Context;
import com.ge.apm.alm.persistence.ContextPersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.ContextEntity;
import com.ge.apm.alm.persistence.jpa.model.TestContext;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class ContextPersistSvcTests {

    @Autowired
    private ContextPersistencyService contextPersistencyService;

    private static List<Context> seedContexts = new ArrayList<>();

    @BeforeClass
    public static void init() {
        seedContexts.add(TestContext.builder().codeType("integer").contextName("asset-state").contextType("assets")
            .isReservedAttributeConfig(true).reservedCodeValidationExpression("code > 0 && code <= 100").build());
        seedContexts.add(TestContext.builder().codeType("integer").contextName("site-status").contextType("assets")
            .isReservedAttributeConfig(true).reservedCodeValidationExpression("code > 0 && code <= 100").build());
        seedContexts.add(TestContext.builder().codeType("boolean").contextName("tag_status_ui_edit").contextType("tags")
            .isReservedAttributeConfig(false).build());
    }

    @Test
    @Transactional
    public void getContext_ExistingContextName() {
        for(Context c : seedContexts) {
            Context context = contextPersistencyService.findByContextName(c.getContextName());
            Assert.assertNotNull(context);
            Assert.assertEquals(c.getReservedCodeValidationExpression(), context.getReservedCodeValidationExpression());
            Assert.assertEquals(c.getCodeType(), context.getCodeType());
            Assert.assertEquals(c.getContextName(), context.getContextName());
            Assert.assertEquals(c.getIsReservedAttributeConfig(), context.getIsReservedAttributeConfig());
        }
    }

    @Test
    @Transactional
    public void getContext_NonExistingContextName() {
        Context context = contextPersistencyService.findByContextName("doesnotexist");
        Assert.assertNull(context);
    }
}
