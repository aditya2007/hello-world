/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetParentLoaderTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private AssetParentLoader assetParentLoader;

    @Test
    @Transactional
    public void testLoadAsset() throws IOException {
        AssetType assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, "T1");
        String assetTypeId = assetType.getId();
        Asset parent = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetTypeId, null, "A1");
        Asset child = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetTypeId, parent.getId(), "A2");
        Asset grandChild = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetTypeId, child.getId(), "A3");

        AssetInstanceEntity loadedGrandChild =
            (AssetInstanceEntity) assetPersistencyService.getAssetById(TestUtils.TEST_TENANT,
                TestUtils.getUber(), grandChild.getId());
        assertThat(loadedGrandChild.getParent()).isNull();

        assetParentLoader.postLoad(TestUtils.TEST_TENANT, null, loadedGrandChild,
            AttributeSelectEnum.FULL, EnumSet.noneOf(AssetComponent.class));
        assertThat(loadedGrandChild.getParent()).isNull();

        assetParentLoader.postLoad(TestUtils.TEST_TENANT, null, loadedGrandChild,
            AttributeSelectEnum.FULL, EnumSet.of(AssetComponent.PARENT));
        assertThat(loadedGrandChild.getParent()).isNotNull();
        assertThat(loadedGrandChild.getParent().getId()).isEqualTo(child.getId());
        assertThat(loadedGrandChild.getParent().getParent()).isNotNull();
        assertThat(loadedGrandChild.getParent().getParent().getId()).isEqualTo(parent.getId());

        loadedGrandChild.setParent(null);
        assetParentLoader.postLoad(TestUtils.TEST_TENANT, null, loadedGrandChild,
            AttributeSelectEnum.FULL, EnumSet.of(AssetComponent.PARENT, AssetComponent.PARENT_TYPE_OBJECT));
        assertThat(loadedGrandChild.getParent().getType()).isNotNull();
        assertThat(loadedGrandChild.getParent().getParent().getType()).isNotNull();
    }

    @Test
    @Transactional
    public void testLoadAssetList() throws IOException {
        AssetType assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, "T1");
        String assetTypeId = assetType.getId();
        Asset parent = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetTypeId, null, "A1");
        Asset child = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetTypeId, parent.getId(), "A2");
        Asset grandChild = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetTypeId, child.getId(), "A3");

        List<AssetInstanceEntity> assets = new ArrayList<>(2);
        assets.add((AssetInstanceEntity) assetPersistencyService
            .getAssetById(TestUtils.TEST_TENANT, TestUtils.getUber(), child.getId()));
        assets.add((AssetInstanceEntity) assetPersistencyService
            .getAssetById(TestUtils.TEST_TENANT, TestUtils.getUber(), grandChild.getId()));
        assertThat(assets.get(0).getParent()).isNull();
        assertThat(assets.get(1).getParent()).isNull();

        assetParentLoader.postLoad(TestUtils.TEST_TENANT, null, assets, AttributeSelectEnum.FULL,
            EnumSet.noneOf(AssetComponent.class));
        assertThat(assets.get(0).getParent()).isNull();
        assertThat(assets.get(1).getParent()).isNull();

        assetParentLoader.postLoad(TestUtils.TEST_TENANT, null, assets, AttributeSelectEnum.FULL,
            EnumSet.of(AssetComponent.PARENT));

        assertThat(assets.get(0).getParent()).isNotNull();
        assertThat(assets.get(0).getParent().getId()).isEqualTo(parent.getId());

        assertThat(assets.get(1).getParent()).isNotNull();
        assertThat(assets.get(1).getParent().getId()).isEqualTo(child.getId());
        assertThat(assets.get(1).getParent().getParent()).isNotNull();
        assertThat(assets.get(1).getParent().getParent().getId()).isEqualTo(parent.getId());
    }
}
