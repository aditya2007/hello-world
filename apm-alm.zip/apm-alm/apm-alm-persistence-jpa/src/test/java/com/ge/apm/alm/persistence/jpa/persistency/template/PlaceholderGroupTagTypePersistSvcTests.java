/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.template;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.PlaceholderGroupTagType;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholder;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderGroupTagType;
import com.ge.apm.alm.persistence.jpa.model.TestTemplate;
import com.ge.apm.alm.persistence.jpa.utils.TestTemplateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */
public class PlaceholderGroupTagTypePersistSvcTests extends TemplatePersistSvcBaseTests {

    @Test
    @Transactional
    public void testCreatePlaceholderGroupTagType() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestAssetGroup testAssetGroup = createAssetGroup("GE90_tagType_group");
        TestPlaceholderGroupTagType testPlaceholderGroupTagType = createTestPlaceholderGroupTagType(testPlaceholder,
            testAssetGroup);

        // make sure that retrieve Placeholder, PlaceholderType also returned.
        Placeholder dbPlaceholder = placeholderPersistencyService
            .getPlaceholderById(TestUtils.TEST_TENANT, testPlaceholder.getId());

        assertThat(dbPlaceholder).isNotNull();
        assertThat(dbPlaceholder.getId()).isEqualTo(testPlaceholder.getId());
        assertThat(dbPlaceholder.getPlaceholderGroupTagTypes().get(0).getId())
            .isEqualTo(testPlaceholderGroupTagType.getId());
        assertThat(dbPlaceholder.getPlaceholderGroupTagTypes().get(0).getGroupId())
            .isEqualTo(testPlaceholderGroupTagType.getGroupId());

        // delete template cascade
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes = new ArrayList<>();
        testPlaceholderGroupTagTypes.add(testPlaceholderGroupTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderType_missingId() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderGroupTagType groupTagType = TestTemplateUtils.buildPlaceholderGroupTagType(uuid, uuid);
        groupTagType.setId(null);
        placeholderGroupTagTypePersistencyService.createPlaceholderGroupTagType(TestUtils.TEST_TENANT, groupTagType);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderGroupTagType_missingPlaceholderId() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderGroupTagType groupTagType = TestTemplateUtils.buildPlaceholderGroupTagType(uuid, uuid);
        groupTagType.setPlaceholderId(null);
        placeholderGroupTagTypePersistencyService.createPlaceholderGroupTagType(TestUtils.TEST_TENANT, groupTagType);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderGroupTagType_missingGroupId() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderGroupTagType groupTagType = TestTemplateUtils.buildPlaceholderGroupTagType(uuid, uuid);
        groupTagType.setGroupId(null);
        placeholderGroupTagTypePersistencyService.createPlaceholderGroupTagType(TestUtils.TEST_TENANT, groupTagType);
    }

    @Test
    @Transactional
    public void testCreatePlaceholderGroupTagTypes() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestAssetGroup testAssetGroup1 = createAssetGroup("GE90_tagType_group_1");
        TestAssetGroup testAssetGroup2 = createAssetGroup("GE90_tagType_group_2");

        List<PlaceholderGroupTagType> groupTagTypes = new ArrayList<>();
        final String placeholderId = testPlaceholder.getId();
        groupTagTypes.add(TestTemplateUtils.buildPlaceholderGroupTagType(placeholderId, testAssetGroup1.getId()));
        groupTagTypes.add(TestTemplateUtils.buildPlaceholderGroupTagType(placeholderId, testAssetGroup2.getId()));

        int counter;
        final String tenantId = TestUtils.TEST_TENANT;
        counter = placeholderGroupTagTypePersistencyService.createPlaceholderGroupTagTypes(tenantId, new ArrayList<>());
        assertThat(counter).isEqualTo(0);

        counter = placeholderGroupTagTypePersistencyService.createPlaceholderGroupTagTypes(tenantId, groupTagTypes);
        assertThat(counter).isEqualTo(groupTagTypes.size());

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderGroupTagTypes(Collections.unmodifiableList(groupTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testUpdatePlaceholderGroupTagType() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestAssetGroup testAssetGroup = createAssetGroup("GE90_tagType_group");
        TestPlaceholderGroupTagType groupTagType = createTestPlaceholderGroupTagType(testPlaceholder, testAssetGroup);

        PlaceholderGroupTagType savedPlaceholderGroupTagType = placeholderGroupTagTypePersistencyService
            .updatePlaceholderGroupTagType(TestUtils.TEST_TENANT, groupTagType);
        assertThat(savedPlaceholderGroupTagType).isNotNull();
        assertThat(savedPlaceholderGroupTagType.getId()).isEqualTo(groupTagType.getId());

        // delete template cascade
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes = new ArrayList<>();
        testPlaceholderGroupTagTypes.add(groupTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testUpdatePlaceholderTypes() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestAssetGroup testAssetGroup1 = createAssetGroup("GE90_tagType_group_1");
        TestAssetGroup testAssetGroup2 = createAssetGroup("GE90_tagType_group_2");

        List<PlaceholderGroupTagType> groupTagTypes = new ArrayList<>();
        final String placeholderId = testPlaceholder.getId();
        groupTagTypes.add(TestTemplateUtils.buildPlaceholderGroupTagType(placeholderId, testAssetGroup1.getId()));
        groupTagTypes.add(TestTemplateUtils.buildPlaceholderGroupTagType(placeholderId, testAssetGroup2.getId()));

        int counter;
        final String tenantId = TestUtils.TEST_TENANT;
        counter = placeholderGroupTagTypePersistencyService.updatePlaceholderGroupTagTypes(tenantId, new ArrayList<>());
        assertThat(counter).isEqualTo(0);

        counter = placeholderGroupTagTypePersistencyService.createPlaceholderGroupTagTypes(tenantId, groupTagTypes);
        assertThat(counter).isEqualTo(2);

        TestAssetGroup testAssetGroup3 = createAssetGroup("GE90_tagType_group_3");
        groupTagTypes.add(TestTemplateUtils.buildPlaceholderGroupTagType(placeholderId, testAssetGroup3.getId()));
        counter = placeholderGroupTagTypePersistencyService.updatePlaceholderGroupTagTypes(tenantId, groupTagTypes);
        assertThat(counter).isEqualTo(3);

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderGroupTagTypes(Collections.unmodifiableList(groupTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testDeletePlaceholderGroupTagType_Id() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestAssetGroup testAssetGroup = createAssetGroup("GE90_tagType_group");
        TestPlaceholderGroupTagType groupTagType = createTestPlaceholderGroupTagType(testPlaceholder, testAssetGroup);

        int counter = placeholderGroupTagTypePersistencyService
            .deletePlaceholderGroupTagTypeById(TestUtils.TEST_TENANT, groupTagType.getId());
        assertThat(counter).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes = new ArrayList<>();
        testPlaceholderGroupTagTypes.add(groupTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeletePlaceholderGroupTagType_Id_NotFoundException() throws PersistencyServiceException {
        placeholderGroupTagTypePersistencyService.deletePlaceholderGroupTagTypeById(TestUtils.TEST_TENANT,
            TestTemplateUtils.getNewUuid());
    }

    @Test
    @Transactional
    public void testDeletePlaceholderGroupTagType_placeholderId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestAssetGroup testAssetGroup = createAssetGroup("GE90_tagType_group");
        TestPlaceholderGroupTagType groupTagType = createTestPlaceholderGroupTagType(testPlaceholder, testAssetGroup);

        int counter = placeholderGroupTagTypePersistencyService
            .deletePlaceholderGroupTagTypeByPlaceholderId(TestUtils.TEST_TENANT, groupTagType.getPlaceholderId());
        assertThat(counter).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes = new ArrayList<>();
        testPlaceholderGroupTagTypes.add(groupTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeletePlaceholderGroupTagType_placeholderId_NotFoundException() throws PersistencyServiceException {
        placeholderGroupTagTypePersistencyService.deletePlaceholderGroupTagTypeByPlaceholderId(TestUtils.TEST_TENANT,
            TestTemplateUtils.getNewUuid());
    }

    @Test
    @Transactional
    public void testDeletePlaceholderGroupTagTypeByPlaceholderIdAndGroupId()
        throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestAssetGroup testAssetGroup = createAssetGroup("GE90_tagType_group");
        TestPlaceholderGroupTagType testPlaceholderGroupTagType = createTestPlaceholderGroupTagType(testPlaceholder,
            testAssetGroup);

        int counter = placeholderGroupTagTypePersistencyService
            .deletePlaceholderGroupTagTypeByPlaceholderIdAndGroupId(TestUtils.TEST_TENANT,
                testPlaceholderGroupTagType.getPlaceholderId(),
                testPlaceholderGroupTagType.getGroupId());
        assertThat(counter).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes = new ArrayList<>();
        testPlaceholderGroupTagTypes.add(testPlaceholderGroupTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = ObjectNotFoundException.class)
    public void testDeletePlaceholderGroupTagTypeByPlaceholderIdAndGroupId_NotFoundException()
        throws PersistencyServiceException {
        String uuid = TestTemplateUtils.getNewUuid();
        placeholderGroupTagTypePersistencyService
            .deletePlaceholderGroupTagTypeByPlaceholderIdAndGroupId(TestUtils.TEST_TENANT,
                uuid, uuid);
    }

    @Test
    @Transactional
    public void testGetPlaceholderGroupTagTypeById() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestAssetGroup testAssetGroup = createAssetGroup("GE90_tagType_group");
        TestPlaceholderGroupTagType groupTagType = createTestPlaceholderGroupTagType(testPlaceholder, testAssetGroup);

        PlaceholderGroupTagType dbPlaceholderGroupTagType = placeholderGroupTagTypePersistencyService
            .getPlaceholderGroupTagTypeById(TestUtils.TEST_TENANT, groupTagType.getId());
        assertThat(dbPlaceholderGroupTagType).isNotNull();
        assertThat(dbPlaceholderGroupTagType.getId()).isEqualTo(groupTagType.getId());

        // delete template cascade
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes = new ArrayList<>();
        testPlaceholderGroupTagTypes.add(groupTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    public void testGetPlaceholderGroupTagTypeById_EmptyResultDataAccessException() {
        assertThat(placeholderGroupTagTypePersistencyService
            .getPlaceholderGroupTagTypeById(TestUtils.TEST_TENANT, TestTemplateUtils.getNewUuid())).isNull();
    }

    @Test
    @Transactional
    public void testGetPlaceholderGroupTagTypeByPlaceholderIdAndGroupId()
        throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestAssetGroup testAssetGroup = createAssetGroup("GE90_tagType_group");
        TestPlaceholderGroupTagType groupTagType = createTestPlaceholderGroupTagType(testPlaceholder, testAssetGroup);

        PlaceholderGroupTagType dbPlaceholderGroupTagType = placeholderGroupTagTypePersistencyService
            .getPlaceholderGroupTagTypeByPlaceholderIdAndGroupId(TestUtils.TEST_TENANT,
                groupTagType.getPlaceholderId(), groupTagType.getGroupId());
        assertThat(dbPlaceholderGroupTagType).isNotNull();
        assertThat(dbPlaceholderGroupTagType.getId()).isEqualTo(groupTagType.getId());

        // delete template cascade
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes = new ArrayList<>();
        testPlaceholderGroupTagTypes.add(groupTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    public void testGetPlaceholderGroupTagTypeByPlaceholderIdAndGroupId_EmptyResultDataAccessException() {
        String uuid = TestTemplateUtils.getNewUuid();
        assertThat(placeholderGroupTagTypePersistencyService
            .getPlaceholderGroupTagTypeByPlaceholderIdAndGroupId(TestUtils.TEST_TENANT, uuid, uuid)).isNull();
    }

    @Test
    @Transactional
    public void testGetPlaceholderGroupTagTypesByPlaceholderId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN01");
        TestAssetGroup testAssetGroup1 = createAssetGroup("GE90_tagType_group_1");
        TestPlaceholderGroupTagType groupTagType1 = createTestPlaceholderGroupTagType(testPlaceholder1,
            testAssetGroup1);

        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN02");
        TestAssetGroup testAssetGroup2 = createAssetGroup("GE90_tagType_group_2");
        TestPlaceholderGroupTagType groupTagType2 = createTestPlaceholderGroupTagType(testPlaceholder2,
            testAssetGroup2);

        final String tenantId = TestUtils.TEST_TENANT;
        assertThat(placeholderGroupTagTypePersistencyService.getPlaceholderGroupTagTypeByPlaceholderIds(tenantId,
            new ArrayList<>())).isEmpty();

        List<PlaceholderGroupTagType> foundPlaceholderGroupTagTypes = placeholderGroupTagTypePersistencyService
            .getPlaceholderGroupTagTypeByPlaceholderId(tenantId, testPlaceholder1.getId());
        assertThat(foundPlaceholderGroupTagTypes.size()).isEqualTo(1);
        assertThat(foundPlaceholderGroupTagTypes.get(0).getId()).isEqualTo(groupTagType1.getId());

        // delete template cascade
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes1 = new ArrayList<>();
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes2 = new ArrayList<>();
        testPlaceholderGroupTagTypes1.add(groupTagType1);
        testPlaceholderGroupTagTypes2.add(groupTagType2);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes1));
        testPlaceholder2.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes2));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);

        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testGetPlaceholderGroupTagTypes_placeholderIds() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN01");
        TestAssetGroup testAssetGroup1 = createAssetGroup("GE90_tagType_group_1");
        TestPlaceholderGroupTagType testPlaceholderGroupTagType1 = createTestPlaceholderGroupTagType(testPlaceholder1,
            testAssetGroup1);

        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN02");
        TestAssetGroup testAssetGroup2 = createAssetGroup("GE90_tagType_group_2");
        TestPlaceholderGroupTagType testPlaceholderGroupTagType2 = createTestPlaceholderGroupTagType(testPlaceholder2,
            testAssetGroup2);

        List<String> placeholderIds = new ArrayList<>();
        placeholderIds.add(testPlaceholder1.getId());
        placeholderIds.add(testPlaceholder2.getId());

        List<PlaceholderGroupTagType> foundPlaceholders = placeholderGroupTagTypePersistencyService
            .getPlaceholderGroupTagTypeByPlaceholderIds(TestUtils.TEST_TENANT, placeholderIds);
        assertThat(foundPlaceholders.size()).isEqualTo(2);
        assertThat(foundPlaceholders.get(0).getId()).isEqualTo(testPlaceholderGroupTagType1.getId());

        // make sure that retrieve Placeholder, PlaceholderGroupTagType also returned.
        Template dbTemplate = templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, testTemplate.getId());

        assertThat(dbTemplate).isNotNull();
        assertThat(dbTemplate.getPlaceholders().size()).isEqualTo(2);
        assertThat(dbTemplate.getPlaceholders().get(0).getPlaceholderGroupTagTypes().size()).isEqualTo(1);
        assertThat(dbTemplate.getPlaceholders().get(1).getPlaceholderGroupTagTypes().size()).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes1 = new ArrayList<>();
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes2 = new ArrayList<>();
        testPlaceholderGroupTagTypes1.add(testPlaceholderGroupTagType1);
        testPlaceholderGroupTagTypes2.add(testPlaceholderGroupTagType2);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes1));
        testPlaceholder2.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes2));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);

        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testGetPlaceholderGroupTagTypeByTemplateId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN10");
        TestAssetGroup testAssetGroup1 = createAssetGroup("GE90_tagType_group_1");
        TestPlaceholderGroupTagType testPlaceholderGroupTagType1 = createTestPlaceholderGroupTagType(testPlaceholder1,
            testAssetGroup1);

        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN11");
        TestAssetGroup testAssetGroup2 = createAssetGroup("GE90_tagType_group_2");
        TestPlaceholderGroupTagType testPlaceholderGroupTagType2 = createTestPlaceholderGroupTagType(testPlaceholder2,
            testAssetGroup2);

        List<PlaceholderGroupTagType> foundPlaceholders = placeholderGroupTagTypePersistencyService
            .getPlaceholderGroupTagTypeByTemplateId(TestUtils.TEST_TENANT, testTemplate.getId());
        assertThat(foundPlaceholders.size()).isEqualTo(2);
        assertThat(foundPlaceholders.get(0).getId()).isEqualTo(testPlaceholderGroupTagType1.getId());

        // delete template cascade
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes1 = new ArrayList<>();
        List<TestPlaceholderGroupTagType> testPlaceholderGroupTagTypes2 = new ArrayList<>();
        testPlaceholderGroupTagTypes1.add(testPlaceholderGroupTagType1);
        testPlaceholderGroupTagTypes2.add(testPlaceholderGroupTagType2);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes1));
        testPlaceholder2.setPlaceholderGroupTagTypes(Collections.unmodifiableList(testPlaceholderGroupTagTypes2));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);

        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    private void deleteTestTemplateCascade(TestTemplate testTemplate) throws PersistencyServiceException {
        String templateId = testTemplate.getId();
        final String tenantId = TestUtils.TEST_TENANT;
        templatePersistencyService.deleteTemplateById(tenantId, templateId);
        assertThat(templatePersistencyService.getTemplateById(tenantId, templateId)).isNull();

        List<Placeholder> placeholders = testTemplate.getPlaceholders();
        for (Placeholder placeholder : placeholders) {
            assertThat(placeholderPersistencyService.getPlaceholderById(tenantId, placeholder.getId()))
                .isNull();

            List<PlaceholderGroupTagType> placeholderGroupTagTypes = placeholder.getPlaceholderGroupTagTypes();
            if (!CollectionUtils.isEmpty(placeholderGroupTagTypes)) {
                placeholderGroupTagTypes.forEach(placeholderGroupTagType -> assertThat(placeholderGroupTagTypePersistencyService.getPlaceholderGroupTagTypeById(tenantId,
                    placeholderGroupTagType.getId())).isNull());
            }
        }
    }
}

