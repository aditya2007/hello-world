/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.fasterxml.jackson.databind.JsonNode;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.exceptions.SuperTypeDoesNotExistsException;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroupItem;
import com.ge.apm.alm.persistence.jpa.model.TestTag;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.objectReader;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */
public final class TagPredicateUtils {

    private TagPredicateUtils() {
    }

    public static AssetGroupItem newTagCorrelationItem(Tag tag, String groupId) {
        return newTagCorrelationItem(tag, groupId, 0);
    }

    public static AssetGroupItem newTagCorrelationItem(Tag tag, String groupId, int position) {
        return TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).tenantId(TenantTestUtils.getTenantId())
            .groupId(groupId).objectId(tag.getId()).position(position).build();
    }

    /**
     * SeedOOTBData.ROOT_ENTERPRISE_TYPE <-- MyEnterpriseType
     * SeedOOTBData.ROOT_SITE_TYPE       <-- MySiteType
     * SeedOOTBData.ROOT_SEGMENT_TYPE    <-- MySegmentType
     * SeedOOTBData.ROOT_ASSET_TYPE      <-- MyAssetType <-- MyAssetSubType
     * SeedOOTBData.ROOT_TAG_TYPE        <-- MyTagType
     */
    public static Map<String, AssetType> createTypes(AssetTypePersistencyService assetTypePersistencyService)
        throws IOException, SuperTypeDoesNotExistsException {
        Map<String, AssetType> types = new HashMap<>();

        AssetType enterpriseType =
            TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID,
                "MyEnterpriseType");
        types.put(enterpriseType.getName(), enterpriseType);
        AssetType siteType =
            TestUtils
                .createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_SITE_TYPE_ID, "MySiteType");
        types.put(siteType.getName(), siteType);
        AssetType segmentType =
            TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_SEGMENT_TYPE_ID,
                "MySegmentType");
        types.put(segmentType.getName(), segmentType);
        AssetType assetType =
            TestUtils
                .createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_ASSET_TYPE_ID, "MyAssetType");
        types.put(assetType.getName(), assetType);
        AssetType assetSubType =
            TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, assetType.getId(), "MyAssetSubType");
        types.put(assetSubType.getName(), assetSubType);
        AssetType tagType =
            TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_TAG_TYPE_ID, "MyTagType");
        types.put(tagType.getName(), tagType);

        return types;
    }

    /**
     * E1 <-- E1_S1 <-- E1_S1_Seg1 <-- E1_S1_Seg1 <-- E1_S1_Seg1_Asset1 <-- E1_S1_Seg1_Asset2
     */
    public static Map<String, Asset> createAssets(AssetPersistencyService assetPersistencyService,
        Map<String, AssetType> types)
        throws IOException, PersistencyServiceException {
        Map<String, Asset> assets = new HashMap<>();

        Asset e1 =
            TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
                types.get("MyEnterpriseType").getId(),
                null, "E1");
        assets.put(e1.getName(), e1);

        Collection<String> accessibleResources1 = Collections.singletonList(e1.getId());

        Asset e1S1 =
            TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1,
                types.get("MySiteType").getId(), e1.getId(), "E1_S1");
        assets.put(e1S1.getName(), e1S1);
        Asset e1S1Seg1 =
            TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1,
                types.get("MySegmentType").getId(), e1S1.getId(),
                "E1_S1_Seg1");
        assets.put(e1S1Seg1.getName(), e1S1Seg1);
        Asset e1S1Seg1Asset1 =
            TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1,
                types.get("MyAssetType").getId(), e1S1Seg1.getId(),
                "E1_S1_Seg1_Asset1");
        assets.put(e1S1Seg1Asset1.getName(), e1S1Seg1Asset1);
        Asset e1S1Seg1Asset2 =
            TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1,
                types.get("MyAssetSubType").getId(), e1S1Seg1.getId(),
                "E1_S1_Seg1_Asset2");
        assets.put(e1S1Seg1Asset2.getName(), e1S1Seg1Asset2);

        return assets;
    }

    /**
     * E1_S1_Seg1        <-- E1_S1_Seg1_Tag0, E1_S1_Seg1_Tag1
     * E1_S1_Seg1_Asset1 <-- E1_S1_Seg1_Asset1_Tag0, E1_S1_Seg1_Asset1_Tag1
     * E1_S1_Seg1_Asset2 <-- E1_S1_Seg1_Asset2_Tag3
     */
    public static List<Tag> createTagDataForDifferentAssets(TagPersistencyService tagPersistencyService,
        String tagTypeId, Map<String, Asset> assets) throws IOException, PersistencyServiceException {
        List<Tag> tags = new ArrayList<>();
        int count = 2; // total # of tags, 2 for the same segment E1_S1_Seg1
        for (int i = 0; i < count; i++) {
            String name = "E1_S1_Seg1_Tag" + i;
            Tag tag = newTag(tagTypeId, assets.get("E1_S1_Seg1").getId(), name);
            tags.add(tag);
            Tag persisted = tagPersistencyService.createTag(TenantTestUtils.getTenantId(), TestUtils.getUber(), tag);
            assertThat(persisted).isNotNull();
            assertThat(persisted.getCreatedDate()).isNotNull();
            assertThat(persisted.getLastModifiedDate()).isNotNull();
        }

        // Two tags on asset 1
        for (int i = 0; i < count; i++) {
            String name = "E1_S1_Seg1_Asset1_Tag" + i;
            Tag tag = newTag(tagTypeId, assets.get("E1_S1_Seg1_Asset1").getId(), name);
            tags.add(tag);
            Tag persisted = tagPersistencyService.createTag(TenantTestUtils.getTenantId(), TestUtils.getUber(), tag);
            assertThat(persisted).isNotNull();
            assertThat(persisted.getCreatedDate()).isNotNull();
            assertThat(persisted.getLastModifiedDate()).isNotNull();
        }

        // One tag for segment E1_S1_Seg1_Asset2
        String name = "E1_S1_Seg1_Asset2_Tag3";
        Tag tag = newTag(tagTypeId, assets.get("E1_S1_Seg1_Asset2").getId(), name);
        assertThat(tagPersistencyService.createTag(TenantTestUtils.getTenantId(), TestUtils.getUber(), tag)).isNotNull();
        tags.add(tag);
        return tags;
    }

    /**
     * Creates <code>numTags</code> with name prefixed with the name of the asset and suffixed with <code>_Tag_n</code>
     * where <code>n</code> goes from 0 to numTags-1.
     */
    public static List<Tag> createTagDataForAsset(TagPersistencyService tagPersistencyService,
        String tagTypeId, Asset asset, int numTags) throws IOException, PersistencyServiceException {

        List<Tag> tags = new ArrayList<>();
        for (int i = 0; i < numTags; i++) {
            String name = asset.getName() + "_Tag_" + i;
            Tag tag = newTag(tagTypeId, asset.getId(), name);
            tags.add(tagPersistencyService.createTag(TenantTestUtils.getTenantId(), TestUtils.getUber(), tag));
        }
        return tags;
    }

    public static TestTag newTag(String tagTypeId, String assetId, String name) throws IOException {
        return TestTag.builder().
            id(UUID.randomUUID().toString()).tenantId(TenantTestUtils.getTenantId()).assetId(assetId)
            .name(name).sourceKey(name).description(name)
            .tagType(tagTypeId).tagCategory("SENSOR")
            .aliases(getAliases(name)).attributes(TestUtils.getAttributes("myTagType"))
            .build();
    }

    private static JsonNode getAliases(String base) throws IOException {
        String str = MessageFormat.format("[\"{0}_alias1\", \"{0}_alias2\", \"{0}_alias3\"]", base);
        return objectReader.readTree(str);
    }
}
