/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetRestrictionFeature;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AssetUserPolicy;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.exceptions.SuperTypeDoesNotExistsException;
import com.ge.apm.alm.persistence.jpa.AccessibleResourceTestHandler;
import com.ge.apm.alm.persistence.jpa.entity.AssetUserPolicyEntity;
import com.ge.apm.alm.persistence.jpa.model.TestAssetInstance;
import com.ge.apm.alm.persistence.jpa.model.TestAssetType;
import com.ge.apm.alm.utils.AlmRequestContext;
import com.ge.apm.alm.utils.AlmRequestContext.AlmRequestContextEnum;
import com.ge.apm.common.support.RequestContext;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

public final class TestUtils {

    public static final String NULL_UUID = new UUID(0, 0).toString();

    public static final String TEST_TAG_TYPE_ID = "7c521edb-680a-49b2-bac2-acbc8039b34e";

    public static final String TEST_TENANT = "f743b7ef-42df-4d7e-89dd-90dc3b53b0ac";

    public static final String TEST_USER = "TestUser";

    public static final String TEST_TENANT1 = "fdd5e0ad-8ea3-4c9a-8381-9c98109ebd37";

    public static final String TEST_USER_ID = "09ce6664-b079-47f8-98ed-eb10f12c29fc";

    public static final ObjectMapper objectMapper = new ObjectMapper();

    public static final ObjectReader objectReader = objectMapper.reader();

    public static final JsonNode EMPTY_JSON_NODE;

    public static final String VIEW_DECOMM_FCODE = "VIEW_DECOMMISSIONED_ASSETS";

    static {
        try {
            EMPTY_JSON_NODE = objectReader.readTree("{}");
        } catch (IOException ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    private TestUtils() {
    }

    public static AssetType createAssetTypeAndAssert(AssetTypePersistencyService assetTypePersistencyService,
        String superTypeId, String name) throws IOException {
        AssetType assetType = createAssetType(superTypeId, name);
        AssetType assetCr = null;
        try {
            assetCr = assetTypePersistencyService.createAssetType(TenantTestUtils.getTenantId(), assetType);
            //Assertions..//TODO More to come
            assertThat(assetCr.getSuperTypeId()).isEqualTo(superTypeId);
        } catch (SuperTypeDoesNotExistsException e) {
            fail("should not have thrown error since root type should be a seed data", e);
        }
        return assetCr;
    }

    public static AssetType createAssetTypeAndAssertDiffTenant(AssetTypePersistencyService assetTypePersistencyService,
        String superTypeId, String name) throws IOException {
        AssetType assetType = createAssetType(superTypeId, name);
        AssetType assetCr = null;
        try {
            assetCr = assetTypePersistencyService.createAssetType(TEST_TENANT1, assetType);
            //Assertions..//TODO More to come
            assertThat(assetCr.getSuperTypeId()).isEqualTo(superTypeId);
        } catch (SuperTypeDoesNotExistsException e) {
            fail("should not have thrown error since root type should be a seed data", e);
        }
        return assetCr;
    }

    public static Asset createAssetInstanceAndAssert(AssetPersistencyService assetPersistencyService,
        Collection<String> accessibleResource, String assetType, String parentId, String name) throws IOException {
        Asset asset = createAssetInstance(assetType, parentId, name);
        Asset assetCr = null;
        try {
            assetCr = assetPersistencyService.createAsset(TenantTestUtils.getTenantId(), accessibleResource, asset);
            //Assertions..//TODO More to come
            assertThat(assetCr.getAssetType()).isEqualTo(assetType);
        } catch (ObjectNotFoundException e) {
            if (!accessibleResource.isEmpty()) {
                fail("should not have thrown error", e);
            }
        } catch (PersistencyServiceException e) {
            fail("Not expecting to fail with exception ", e);
        }
        return assetCr;
    }

    public static AssetType createAssetType(String superTypeId, String name) throws IOException {
        return TestAssetType.builder().
            id(newUuid()).sourceKey(name).
            name(name).description(name).
            superTypeId(superTypeId).attributeSchema(getAttributes(name)).typeSemantics(EMPTY_JSON_NODE).
            jsonSchema(EMPTY_JSON_NODE).build();
    }

    public static Asset createAssetInstance(String assetType, String parentId, String name) throws IOException {
        return TestAssetInstance.builder().
            id(newUuid()).sourceKey(name).
            name(name).description(name).
            assetType(assetType).parentId(parentId).
            geolocation(createGeolocation()).
            attributes(getAttributes(assetType)).build();
    }

    public static JsonNode createGeolocation() throws IOException {
        String geo = "{\n" + "  \"location\": {\n" + "    \"geoPoints\": [\n" + "      {\n"
            + "        \"altitude\": 112.356,\n" + "        \"latitude\": -21.290,\n"
            + "        \"longitude\": 13.112,\n" + "        \"name\": \"point1\",\n" + "        \"order\": 1\n"
            + "      }\n" + "    ]\n" + "  }\n" + "}";

        return objectReader.readTree(geo);
    }

    public static JsonNode emptyJsonNode() {
        return EMPTY_JSON_NODE;
    }

    public static String newUuid() {
        return UUID.randomUUID().toString();
    }

    public static Collection<String> getUber() {
        RequestContext.put(AccessibleResourceTestHandler.ACCESSIBLE_RESOURCES, AccessibleResourceTestHandler.ALL_RESOURCES);
        return Collections.emptyList();
    }

    public static Collection<String> getUnPrivileged(String ...ids) {
        if (ids == null || ids.length == 0) {
            RequestContext.put(AccessibleResourceTestHandler.ACCESSIBLE_RESOURCES, new String[] { "/assets/" + NULL_UUID});
            return Collections.singleton(NULL_UUID);
        }

        RequestContext.put(AccessibleResourceTestHandler.ACCESSIBLE_RESOURCES,
            Arrays.stream(ids).map(id -> "/prefix/" + id).collect(Collectors.toList()).toArray(new String[ids.length]));

        return Arrays.asList(ids);

    }

    public static Collection<String> getUnPrivileged(Collection<String> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            RequestContext.put(AccessibleResourceTestHandler.ACCESSIBLE_RESOURCES, new String[] { "/assets/" + NULL_UUID});
            return Collections.singleton(NULL_UUID);
        }

        RequestContext.put(AccessibleResourceTestHandler.ACCESSIBLE_RESOURCES,
            ids.stream().map(id -> "/prefix/" + id).collect(Collectors.toList()).toArray(new String[ids.size()]));

        return ids;
    }

    @SafeVarargs
    public static <T extends BaseDataModel> Collection<String> getUnPrivileged(T model, T ...models) {
        List<String> ids = new ArrayList<>();
        ids.add(model.getId());
        if (models != null) {
            Arrays.stream(models).forEach(m -> ids.add(m.getId()));
        }
        return getUnPrivileged(ids.toArray(new String[0]));
    }

    public static JsonNode getAssetTypeSchema() throws IOException {
        String str = "{\"title\": \"attributes\",\"type\": \"object\",\"properties\": {\"std_model_number\": {\"type\":"
            + " \"string\"},\"number_of_blades\": {\"type\": \"string\"},\"age\": {\"description\": \"Age in "
            + "years\",\"type\": \"integer\",\"minimum\": 0}},\"required\": [\"std_model_number\"]}";
        return objectReader.readTree(str);
    }

    public static JsonNode getAttributes(String type) throws IOException {
        Random random = new Random();
        long variable = random.nextInt(50) + 1;
        if (variable >= 10) {
            variable++;
        }
        StringBuilder attributes = new StringBuilder("{").append(getReservedAttributes(variable)).append(", ").append(
            getCustomAttributes(type, variable)).append("}");
        return objectReader.readTree(attributes.toString());
    }

    public static String createAssetUserPolicies(AssetPolicyPersistencyService assetPolicyPersistencyService,
        String featureCode, String assetType) {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(featureCode);
        assertThat(assetRestrictionFeature).isNotNull();

        AssetUserPolicyEntity assetUserPolicyEntity = createAssetUserPolicyEntity(assetRestrictionFeature.getId(),
            assetType, assetRestrictionFeature.getDefaultFilterCriteria(), featureCode);

        List<AssetUserPolicy> policies = AlmRequestContext.get(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_AS_LIST,
            List.class);
        if (CollectionUtils.isEmpty(policies)) {
            AlmRequestContext.put(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_AS_LIST,
                Arrays.asList(assetUserPolicyEntity));
        } else {
            policies.add(assetUserPolicyEntity);
        }
        /*AssetUserPolicy assetUserPolicy = assetPolicyPersistencyService.createUserPolicy(TEST_TENANT,
            assetUserPolicyEntity);
        assertThat(assetUserPolicy).isNotNull();*/

        return assetUserPolicyEntity.getId();
    }

    public static void destroyAssetUserPolicies() {
        AlmRequestContext.remove(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_AS_LIST);
    }

    private static AssetUserPolicyEntity createAssetUserPolicyEntity(String featureId, String superType,
        String filterCriteria, String featureCode) {
        AssetUserPolicyEntity assetUserPolicyEntity = new AssetUserPolicyEntity();

        assetUserPolicyEntity.setFeatureId(featureId);
        assetUserPolicyEntity.setFeatureCode(featureCode);
        assetUserPolicyEntity.setSubjectId(TEST_USER_ID);
        assetUserPolicyEntity.setSubjectType(AssetUserPolicy.SubjectType.USER.getType());
        assetUserPolicyEntity.setUserName("TestUserName");
        assetUserPolicyEntity.setDisplayName("TestDisplayName");
        assetUserPolicyEntity.setSuperType(superType);
        if (!StringUtils.isEmpty(filterCriteria)) {
            assetUserPolicyEntity.setFilterCriteria(filterCriteria);
        }
        return assetUserPolicyEntity;
    }

    private static String getCustomAttributes(String type, long variable) {
        StringBuilder custom = new StringBuilder("\"attributes\": ");
        custom.append("{\"std_model_number\": {\"type\": \"String\",\"value\": [\"PowerLogic ION8600 Form 9").append(
            variable).append("S STD\"]},").
            append("\"model_number\": {\"type\": \"String\",\"value\": [\"PowerLogic ION8600 Form 9").append(variable)
            .append("S STD\"]},\"serialNumber\":").
            append(
                "{\"type\": \"String\",\"value\": [\"GE12345\"]},\"Test String\": {\"type\": \"String\",\"value\": [\"")
            .append(type.toUpperCase(Locale.getDefault())).append(
            "\", \"AbC\", \"dEf\"]},\"Test Number\": {\"type\": \"Number\",\"value\": [").append(Long.MIN_VALUE).append(
            ",").append(Integer.MIN_VALUE).append(",").append(Integer.MAX_VALUE).append(
            "]}, \"Test Empty\": {\"type\": \"String\",\"value\":[]}, \"Test Boolean\": {\"type\": \"Boolean\","
                + "\"value\":[true]}}");

        return custom.toString();
    }

    private static String getReservedAttributes(long variable) {
        StringBuilder reserved = new StringBuilder("\"reservedAttributes\": ");
        reserved.append("{\"state\": {\"key\": \"").append(variable).append("\"},\"status\": {\"key\": \"").append(
            variable).append("\"},\"InstanceScenario-7\": \"").append(variable).append("\",\"InstanceScenario-8\": \"")
            .append(variable).append("\",\"familyType\": \"").append(variable).append("\",\"serialNumber\":").append(
            variable).append(",\"maintenanceCriticalityRiskScore\":").append(Math.floorMod(variable, 100)).append(
            ",\"faultMode\":").append(variable);
        reserved.append(",\"Test Boolean\": true, \"Test Boolean Array\": [true, false]").append(",\"Test Number\": ")
            .append(Integer.MIN_VALUE).append(", \"Test Number Array\": [").append(Integer.MAX_VALUE).append(", ")
            .append(Integer.MIN_VALUE).append(", ").append(Long.MAX_VALUE).append("]").append(
            ",\"Test String\": \"abc\", \"Test String Array\": [\"DeF\", \"aBc\", \"JkL\"]").append(
            ",\"Test Multi\": {\"key\": \"06\"}").append(",\"Test Multi2\": {\"key\": \"-12.345\"}").append("}");
        return reserved.toString();
    }
}
