/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.types;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import com.google.common.collect.Sets;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Sourceable;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.exceptions.SuperTypeDoesNotExistsException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetTypeEntity;
import com.ge.apm.alm.persistence.jpa.model.TestAssetType;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.assertj.core.api.Fail.failBecauseExceptionWasNotThrown;

/**
 * Tests the JPA Persistency Layer
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TypesPersistSvcTests {

    private static final String STEAM_TURBINE_TYPE = "SteamTurbineType";

    private static final String TURBINE_TYPE = "TurbineType";

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Test(expected = IllegalArgumentException.class)
    public void createAssetType_tenantIdMismatch() throws SuperTypeDoesNotExistsException {
        assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT, AssetTypeEntity.builder().id(
            TestUtils.NULL_UUID).tenantId(TestUtils.NULL_UUID).build());
    }

    @Test
    @Transactional
    public void createAssetTypes() throws IOException {
        //Creating Custom Enterprise Type
        TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID,
            "MyEnterpriseType");
        //Creating Custom Site Type
        TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_SITE_TYPE_ID, "MySiteType");
        //Creating Custom Site Type
        TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_SEGMENT_TYPE_ID,
            "MySegmentType");
        //Creating Custom Asset Type
        setupTurbineTypes();
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void createAssetTypes_tenantIdMismatch() throws SuperTypeDoesNotExistsException {
        assetTypePersistencyService.createAssetTypes(TestUtils.TEST_TENANT, Arrays.asList(AssetTypeEntity.builder().id(
            TestUtils.NULL_UUID).tenantId(TestUtils.TEST_TENANT).build(), AssetTypeEntity.builder().id(
            TestUtils.NULL_UUID).tenantId(TestUtils.NULL_UUID).build()));
    }

    @Test
    @Transactional
    public void getAssetTypesUsingDifferentTenantId() throws IOException, PersistencyServiceException {
        String testAssetType = "TestAssetType1";
        AssetType assetType = TestUtils.createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, testAssetType);
        assertThat(assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT, assetType)).isNotNull();
        AssetType retvdAssetType = assetTypePersistencyService.getAssetTypeById(TestUtils.TEST_TENANT,
            assetType.getId());
        assertThat(retvdAssetType.getSourceKey()).isEqualTo(testAssetType);
        retvdAssetType = assetTypePersistencyService.getAssetTypeById(TestUtils.TEST_TENANT1, assetType.getId());
        assertThat(retvdAssetType).isNull();
    }

    @Test
    @Transactional
    public void createAssetTypes_bulk() throws IOException, PersistencyServiceException {
        List<AssetType> types = new ArrayList<>();
        int stdCustomTypesNoChildrenCount = 3;
        for (int i = 0; i < stdCustomTypesNoChildrenCount; i++) {
            types.add(TestUtils.createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, "StandardCustomTypeNoChildren_" + i));
        }
        int stdCustomTypesWithChildrenCount = 4;
        for (int i = 0; i < stdCustomTypesWithChildrenCount; i++) {
            AssetType parent = TestUtils.createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID,
                "StandardCustomTypeWithChildren_" + i);
            types.add(parent);
            AssetType child = TestUtils.createAssetType(parent.getId(), "ChildOfStandardCustomTypeWithChildren_" + i);
            types.add(child);
            AssetType grandchild = TestUtils.createAssetType(child.getId(),
                "GrandchildOfStandardCustomTypeWithChildren_" + i);
            types.add(grandchild);
            AssetType greatGrandchild = TestUtils.createAssetType(grandchild.getId(),
                "GreatgrandchildOfStandardCustomTypeWithChildren_" + i);
            types.add(greatGrandchild);
        }

        AssetType existingCustomType = TestUtils.createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID,
            "ExistingTopLevelCustomType");
        assertThat(assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT, existingCustomType)).isNotNull();

        int existingCustomTypesWithChildrenCount = 4;
        for (int i = 0; i < existingCustomTypesWithChildrenCount; i++) {
            AssetType parent = TestUtils.createAssetType(existingCustomType.getId(),
                "ExistingCustomTypeWithChildren_" + i);
            types.add(parent);
            AssetType child = TestUtils.createAssetType(parent.getId(), "ChildOfExistingCustomTypeWithChildren_" + i);
            types.add(child);
            AssetType grandchild = TestUtils.createAssetType(child.getId(),
                "GrandchildOfExistingCustomTypeWithChildren_" + i);
            types.add(grandchild);
            AssetType greatGrandchild = TestUtils.createAssetType(grandchild.getId(),
                "GreatgrandchildOfExistingCustomTypeWithChildren_" + i);
            types.add(greatGrandchild);
        }

        Collections.reverse(types);

        assertThat(assetTypePersistencyService.createAssetTypes(TestUtils.TEST_TENANT, types)).isEqualTo(types.size());

        Map<String, String> nameToIdMap = types.stream().collect(
            Collectors.toMap(AssetType::getName, AssetType::getId));
        nameToIdMap.put(existingCustomType.getName(), existingCustomType.getId());

        // verify super types for children for the leaf node
        AssetType standardCustomTypeWithChildren0 = assetTypePersistencyService.getAssetTypeById(TestUtils.TEST_TENANT,
            nameToIdMap.get("StandardCustomTypeWithChildren_0"));
        assertThat(standardCustomTypeWithChildren0.getSuperTypesArray()).hasSize(1).containsOnly(
            SeedOOTBData.ROOT_ASSET_TYPE_ID);

        AssetType childOfExistingCustomTypeWithChildren2 = assetTypePersistencyService.getAssetTypeById(
            TestUtils.TEST_TENANT, nameToIdMap.get("ChildOfExistingCustomTypeWithChildren_2"));
        assertThat(childOfExistingCustomTypeWithChildren2.getSuperTypesArray()).hasSize(3).containsOnly(
            nameToIdMap.get("ExistingCustomTypeWithChildren_2"), nameToIdMap.get("ExistingTopLevelCustomType"),
            SeedOOTBData.ROOT_ASSET_TYPE_ID);

        // verify super types for children for the leaf node
        AssetType greatgrandchildOfStandardCustomTypeWithChildren4 = assetTypePersistencyService.getAssetTypeById(
            TestUtils.TEST_TENANT, nameToIdMap.get("GreatgrandchildOfStandardCustomTypeWithChildren_3"));
        assertThat(greatgrandchildOfStandardCustomTypeWithChildren4.getSuperTypesArray()).hasSize(4).containsOnly(
            nameToIdMap.get("GrandchildOfStandardCustomTypeWithChildren_3"),
            nameToIdMap.get("ChildOfStandardCustomTypeWithChildren_3"),
            nameToIdMap.get("StandardCustomTypeWithChildren_3"), SeedOOTBData.ROOT_ASSET_TYPE_ID);

        AssetType greatgrandchildOfExistingCustomTypeWithChildren4 = assetTypePersistencyService.getAssetTypeById(
            TestUtils.TEST_TENANT, nameToIdMap.get("GreatgrandchildOfExistingCustomTypeWithChildren_3"));
        assertThat(greatgrandchildOfExistingCustomTypeWithChildren4.getSuperTypesArray()).hasSize(5).containsOnly(
            nameToIdMap.get("GrandchildOfExistingCustomTypeWithChildren_3"),
            nameToIdMap.get("ChildOfExistingCustomTypeWithChildren_3"),
            nameToIdMap.get("ExistingCustomTypeWithChildren_3"), nameToIdMap.get("ExistingTopLevelCustomType"),
            SeedOOTBData.ROOT_ASSET_TYPE_ID);
    }

    @Test
    @Transactional
    public void updateAssetType() throws IOException {
        Map<String, AssetType> turbineTypes = setupTurbineTypes();
        AssetType turbineType = turbineTypes.get(TURBINE_TYPE);

        TestAssetType testAssetType = new TestAssetType();
        BeanUtils.copyProperties(turbineType, testAssetType);
        testAssetType.setName("TurbineType_Modified");
        try {
            AssetType updated = assetTypePersistencyService.updateAssetType(TestUtils.TEST_TENANT, testAssetType);
            assertThat(updated.getName()).isEqualTo("TurbineType_Modified");
        } catch (PersistencyServiceException pse) {
            fail("Not expecting to fail");
        }

        testAssetType = new TestAssetType();
        BeanUtils.copyProperties(turbineType, testAssetType);
        testAssetType.setId(UUID.randomUUID().toString());

        try {
            assetTypePersistencyService.updateAssetType(TestUtils.TEST_TENANT, testAssetType);
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (ObjectNotFoundException onfe) {
            assertThat(onfe).isInstanceOf(ObjectNotFoundException.class);
        } catch (PersistencyServiceException pse) {
            fail("Not expecting to fail");
        }

        testAssetType = new TestAssetType();
        BeanUtils.copyProperties(turbineType, testAssetType);
        testAssetType.setSuperTypeId(UUID.randomUUID().toString());

        try {
            assetTypePersistencyService.updateAssetType(TestUtils.TEST_TENANT, testAssetType);
            failBecauseExceptionWasNotThrown(SuperTypeDoesNotExistsException.class);
        } catch (SuperTypeDoesNotExistsException exp) {
            assertThat(exp).isInstanceOf(SuperTypeDoesNotExistsException.class);
        } catch (PersistencyServiceException pse) {
            fail("Not expecting to fail");
        }
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void deleteAssetType_nullId() throws PersistencyServiceException {
        assetTypePersistencyService.deleteAssetType(TestUtils.TEST_TENANT, null);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void deleteAssetType_emptyId() throws PersistencyServiceException {
        assetTypePersistencyService.deleteAssetType(TestUtils.TEST_TENANT, "");
    }

    @Test
    @Transactional
    public void deleteAssetType_deleteParentTypeWithSubTypesPresent() throws IOException {
        Map<String, AssetType> turbineTypes = setupTurbineTypes();

        //Delete Parent Type and expect to fail since it has children
        try {
            assetTypePersistencyService.deleteAssetType(TestUtils.TEST_TENANT, turbineTypes.get(TURBINE_TYPE).getId());
            failBecauseExceptionWasNotThrown(DataIntegrityViolationException.class);
        } catch (PersistencyServiceException exp) {
            assertThat(exp).isInstanceOf(DataIntegrityViolationException.class);
        }
    }

    @Test
    @Transactional
    public void deleteAssetType_deleteParentTypeWithSubTypesPresentRecursive()
        throws IOException, PersistencyServiceException {
        Map<String, AssetType> turbineTypes = setupTurbineTypes();

        //Delete Parent Type and expect to fail since it has children
        assertThat(assetTypePersistencyService
            .deleteAssetTypeRecursively(TestUtils.TEST_TENANT, turbineTypes.get(TURBINE_TYPE).getId())).isEqualTo(2);
    }

    @Test
    @Transactional
    public void deleteAssetType_deleteTypeWithInstancesRecursive() throws IOException {
        Map<String, AssetType> turbineTypes = setupTurbineTypes();

        AssetType steamTurbineType = turbineTypes.get(STEAM_TURBINE_TYPE);
        String steamTurbineTypeId = steamTurbineType.getId();

        ////Delete Asset Type and expect to fail since it has Asset Instances
        //create an orphan asset based on special turbine type - Even with Recursive = true
        TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), steamTurbineTypeId, null,
            "SteamTurbineType_instance1");

        //Delete Parent Type and expect to fail since it has children
        try {
            assetTypePersistencyService.deleteAssetTypeRecursively(TestUtils.TEST_TENANT, steamTurbineType.getId());
            failBecauseExceptionWasNotThrown(DataIntegrityViolationException.class);
        } catch (PersistencyServiceException exp) {
            //this failure is due to the instances being present
            assertThat(exp).isInstanceOf(DataIntegrityViolationException.class);
        }
    }

    @Test
    @Transactional
    public void deleteAssetType_deleteParentTypeWithSubTypeInstancesRecursive() throws IOException {
        Map<String, AssetType> turbineTypes = setupTurbineTypes();

        //create an orphan asset based on special turbine type - Even with Recursive = true
        TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            turbineTypes.get(STEAM_TURBINE_TYPE).getId(), null, "SteamTurbineType_instance1");

        //Delete Parent Type and expect to fail since it's children has instance
        try {
            assetTypePersistencyService.deleteAssetTypeRecursively(TestUtils.TEST_TENANT,
                turbineTypes.get(TURBINE_TYPE).getId());
            failBecauseExceptionWasNotThrown(DataIntegrityViolationException.class);
        } catch (PersistencyServiceException exp) {
            //this failure is due to the instances being present
            assertThat(exp).isInstanceOf(DataIntegrityViolationException.class);
        }
    }

    @Test
    @Transactional
    public void deleteAssetType_deleteTypeWithInstance() throws IOException {
        Map<String, AssetType> turbineTypes = setupTurbineTypes();

        AssetType steamTurbineType = turbineTypes.get(STEAM_TURBINE_TYPE);
        String steamTurbineTypeId = steamTurbineType.getId();

        //create an orphan asset based on the steam turbine type
        TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), steamTurbineTypeId, null,
            "SteamTurbineType_instance1");
        //Delete Asset Type and expect to fail since it has Asset Instances
        try {
            assetTypePersistencyService.deleteAssetType(TestUtils.TEST_TENANT, steamTurbineType.getId());
            failBecauseExceptionWasNotThrown(DataIntegrityViolationException.class);
        } catch (PersistencyServiceException exp) {
            //cannot delete since this has instance
            assertThat(exp).isInstanceOf(DataIntegrityViolationException.class);
        }
    }

    @Test
    @Transactional
    public void getAssetTypeBySuperTypeAndId() throws IOException {
        Map<String, AssetType> turbineTypes = setupTurbineTypes();
        AssetType turnbineType = turbineTypes.get(TURBINE_TYPE);
        assertThat(assetTypePersistencyService
            .getAssetTypeBySuperTypeAndId(TestUtils.TEST_TENANT, turnbineType.getCoreAssetTypeName(),
                turnbineType.getId()).getId()).isEqualTo(turnbineType.getId());
    }

    @Test
    @Transactional
    public void getAssetTypeBySuperTypeAndSourceKey_emptyCoreTypeName() {
        assertThat(assetTypePersistencyService.getAssetTypeBySuperTypeAndSourceKey(TestUtils.TEST_TENANT, "", ""))
            .isNull();
    }

    @Test
    @Transactional
    public void getAssetTypeBySuperTypeAndSourceKey_emptySourceKey() {
        assertThat(
            assetTypePersistencyService.getAssetTypeBySuperTypeAndSourceKey(TestUtils.TEST_TENANT, "coreTypeName", ""))
            .isNull();
    }

    @Test
    @Transactional
    public void getAssetTypesBySuperTypeAndSourceKeys_emptyCoreTypeName() {
        assertThat(assetTypePersistencyService
            .getAssetTypesBySuperTypeAndSourceKeys(TestUtils.TEST_TENANT, "", Collections.emptyList())).hasSize(0);
    }

    @Test
    @Transactional
    public void getAssetTypesBySuperTypeAndSourceKeys_emptySourceKeys() {
        assertThat(assetTypePersistencyService
            .getAssetTypesBySuperTypeAndSourceKeys(TestUtils.TEST_TENANT, "coreTypeName", Collections.emptyList()))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void deleteAssetType_deleteTypeWithNoInstances() throws IOException {
        Map<String, AssetType> turbineTypes = setupTurbineTypes();
        //Now try again to delete steam turbine type and it should pass
        try {
            assetTypePersistencyService.deleteAssetType(TestUtils.TEST_TENANT,
                turbineTypes.get(STEAM_TURBINE_TYPE).getId());
        } catch (PersistencyServiceException exp) {
            //can delete since this no longer has instance
            fail("Not expecting to fail with Data Integrity voilation");
        }
    }

    @Test
    @Transactional
    public void getAssetTypeBySuperTypeAndSourceKey() throws IOException {
        setupTurbineTypes();
        assertThat(assetTypePersistencyService
            .getAssetTypeBySuperTypeAndSourceKey(TestUtils.TEST_TENANT, OOTBCoreTypesIdLookup.AssetType.name(),
                STEAM_TURBINE_TYPE).getSourceKey()).isEqualTo(STEAM_TURBINE_TYPE);
    }

    @Test
    @Transactional
    public void getAssetTypeBySuperTypeAndSourceKeys() throws IOException {
        setupTurbineTypes();
        assertThat(assetTypePersistencyService
            .getAssetTypesBySuperTypeAndSourceKeys(TestUtils.TEST_TENANT, OOTBCoreTypesIdLookup.AssetType.name(),
                Arrays.asList(TURBINE_TYPE, STEAM_TURBINE_TYPE))).hasSize(2).extracting(AssetType::getSourceKey)
            .containsOnly(TURBINE_TYPE, STEAM_TURBINE_TYPE);
    }

    @Test
    @Transactional
    public void getAssetTypeBySuperTypeAndSourceKeysSqlInjection() throws IOException {
        setupTurbineTypes();
        List<String> sourcekeys = new ArrayList<>();
        sourcekeys.add("junk') OR 'x'='x' --");
        assertThat(assetTypePersistencyService
            .getAssetTypesBySuperTypeAndSourceKeys(TestUtils.TEST_TENANT, OOTBCoreTypesIdLookup.AssetType.name(),
                sourcekeys)).hasSize(0);
    }

    @Test
    @Transactional
    public void findChildAssetTypes_byName() throws IOException {
        setupTurbineTypes();
        TypePredicate childQueryPredicate = TypePredicate.builder().name(STEAM_TURBINE_TYPE).build();
        assertThat(assetTypePersistencyService
            .findChildAssetTypes(TestUtils.TEST_TENANT, SeedOOTBData.ROOT_ASSET_TYPE_ID, true, childQueryPredicate))
            .hasSize(1).extracting(Sourceable::getName).containsOnly(STEAM_TURBINE_TYPE);

        assertThat(assetTypePersistencyService
            .findChildAssetTypes(TestUtils.TEST_TENANT, SeedOOTBData.ROOT_ASSET_TYPE_ID, false, childQueryPredicate))
            .hasSize(0);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void isTypeASuperType_empty() {
        assetTypePersistencyService.isTypeASuperType(TestUtils.newUuid(), "", "");
    }

    @Test
    @Transactional
    public void isTypeASuperType() throws IOException {
        Map<String, AssetType> data = setupTurbineTypes();
        String turbineTypeId = data.get(TURBINE_TYPE).getId();
        assertThat(assetTypePersistencyService
            .isTypeASuperType(TestUtils.TEST_TENANT, SeedOOTBData.ROOT_SITE_TYPE_ID, turbineTypeId)).isFalse();
        assertThat(assetTypePersistencyService
            .isTypeASuperType(TestUtils.TEST_TENANT, SeedOOTBData.ROOT_ASSET_TYPE_ID, turbineTypeId)).isTrue();
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void allTypesAreCompatibleSuperType_empty() {
        assetTypePersistencyService.allTypesAreCompatibleSuperType(TestUtils.newUuid(), "", Collections.emptySet());
    }

    @Test
    @Transactional
    public void allTypesAreCompatibleSuperType() throws IOException, PersistencyServiceException {
        String tenantId = TestUtils.newUuid();
        List<AssetType> types = new ArrayList<>();
        int count = 2;
        for (int i = 0; i < count; i++) {
            types.add(TestUtils.createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, "MyTestAssetType_" + i));
        }
        for (int i = 0; i < count; i++) {
            types.add(TestUtils.createAssetType(types.get(i).getId(), "MyTestAssetSubType_" + i));
        }
        assertThat(assetTypePersistencyService.createAssetTypes(tenantId, types)).isEqualTo(types.size());
        Set<String> typeIds = types.stream().map(AssetType::getId).collect(Collectors.toSet());
        assertThat(assetTypePersistencyService
            .allTypesAreCompatibleSuperType(tenantId, SeedOOTBData.ROOT_ASSET_TYPE_ID, typeIds)).isTrue();
        AssetType spoiler = TestUtils.createAssetType(SeedOOTBData.ROOT_SITE_TYPE_ID, "MyTestSiteTypeSpoiler");
        assertThat(assetTypePersistencyService.createAssetType(tenantId, spoiler)).isNotNull();
        typeIds.add(spoiler.getId());
        assertThat(assetTypePersistencyService
            .allTypesAreCompatibleSuperType(tenantId, SeedOOTBData.ROOT_ASSET_TYPE_ID, typeIds)).isFalse();

        int rowsDeleted = 0;
        for (AssetType type : types) {
            rowsDeleted += assetTypePersistencyService.deleteAssetTypeRecursively(tenantId, type.getId());
        }
        assertThat(rowsDeleted).isEqualTo(types.size());
        String value = "MyTestAsset*Type*";
        TypePredicate predicate = TypePredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value)
            .description(value).sourceKey(value).build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void findAllTypes_pagination() throws IOException, PersistencyServiceException {
        String tenantId = TestUtils.newUuid();
        List<AssetType> types = new ArrayList<>();
        int count = 2;
        for (int i = 0; i < count; i++) {
            types.add(TestUtils.createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, "MyAssetType_" + i));
        }
        for (int i = 0; i < count; i++) {
            types.add(TestUtils.createAssetType(types.get(i).getId(), "MyAssetSubType_" + i));
        }
        assertThat(assetTypePersistencyService.createAssetTypes(tenantId, types)).isEqualTo(types.size());

        TypePredicate predicate = TypePredicate.builder().parent(ParentPredicate.builder().ids(
            Sets.newHashSet(SeedOOTBData.ROOT_ASSET_TYPE_ID)).deepSearch(true).build()).offset(0).pageSize(3).build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(3);

        int rowsDeleted = 0;
        for (AssetType type : types) {
            rowsDeleted += assetTypePersistencyService.deleteAssetTypeRecursively(tenantId, type.getId());
        }
        assertThat(rowsDeleted).isEqualTo(types.size());
        assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(0);
    }

    /**
     * SeedOOTBData.ROOT_ASSET_TYPE <-- TurbineType <-- SteamTurbineType
     */
    private Map<String, AssetType> setupTurbineTypes() throws IOException {
        Map<String, AssetType> turbines = new HashMap<>();
        //Creating Custom Turbine Type
        AssetType turbineType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, TURBINE_TYPE);
        turbines.put(turbineType.getName(), turbineType);
        //Creating Special Turbine Type
        AssetType steamTurbineType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            turbineType.getId(), STEAM_TURBINE_TYPE);
        assertThat(steamTurbineType.getSuperTypeId()).isEqualTo(turbineType.getId());
        turbines.put(steamTurbineType.getName(), steamTurbineType);
        return turbines;
    }
}
