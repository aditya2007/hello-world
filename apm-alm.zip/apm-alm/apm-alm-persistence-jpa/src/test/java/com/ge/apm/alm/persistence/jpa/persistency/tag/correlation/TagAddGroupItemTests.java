/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.tag.correlation;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.exceptions.IncompatibleItemsException;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroupItem;
import com.ge.apm.alm.persistence.jpa.utils.TagPredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.NULL_UUID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.failBecauseExceptionWasNotThrown;

/**
 * Tests the JPA Persistency Layer
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TagAddGroupItemTests extends TagCorrelationBaseTest {

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void addGroupItem_correlatedGroupNotFound_asUber() throws IOException, PersistencyServiceException {
        groupPersistencyService
            .addGroupItem(TestUtils.TEST_TENANT, TestUtils.getUber(), NULL_UUID, TestAssetGroupItem.builder().build());
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void addGroupItem__correlatedGroup_groupNotFound_asUnprivileged()
        throws IOException, PersistencyServiceException {
        groupPersistencyService
            .addGroupItem(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), NULL_UUID,
                TestAssetGroupItem.builder().build());
    }

    @Test(expected = IncompatibleItemsException.class)
    @Transactional
    public void addGroupItem_correlatedGroup_tagNotFound_asUber() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 1;
        assertThat(createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count)).hasSize(count);
        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        // the tag does not exist, so can't be found even by uber user
        AssetGroupItem item =
            TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).tenantId(TestUtils.TEST_TENANT)
                .groupId(group.getId()).objectId(NULL_UUID).build();
        groupPersistencyService.addGroupItem(TestUtils.TEST_TENANT, TestUtils.getUber(), group.getId(), item);
    }

    @Test(expected = IncompatibleItemsException.class)
    @Transactional
    public void addGroupItem_correlatedGroup_tagNotFound_asUnprivileged()
        throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 1;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);
        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        // tag exists, but cannot be access by the unprivileged user
        AssetGroupItem item = TagPredicateUtils.newTagCorrelationItem(tags.get(0), group.getId());
        groupPersistencyService.addGroupItem(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), group.getId(), item);
    }

    @Test(expected = IncompatibleItemsException.class)
    @Transactional
    public void addGroupItem_correlatedGroup_tagsForDifferentAssets() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 1;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);
        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);
        AssetGroupItem item = TagPredicateUtils.newTagCorrelationItem(tags.get(0), group.getId());
        groupPersistencyService
            .addGroupItem(TestUtils.TEST_TENANT, Collections.singletonList(assets.get("E1_S1").getId()), group.getId(),
                item);

        tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(), assets.get("E1_S1_Seg1"),
            count);
        item = TagPredicateUtils.newTagCorrelationItem(tags.get(0), group.getId());
        groupPersistencyService
            .addGroupItem(TestUtils.TEST_TENANT, Collections.singletonList(assets.get("E1_S1").getId()), group.getId(),
                item);
    }

    @Test
    @Transactional
    public void addGroupItem_correlatedGroup() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 3;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);
        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        // verify it is a group with no items
        assertThat(groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), group.getId()))
            .hasSize(0);
        assertThat(groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, Collections.singletonList(assets.get("E1").getId()), group.getId()))
            .hasSize(0);

        // add first item
        AssetGroupItem item = TagPredicateUtils.newTagCorrelationItem(tags.get(0), group.getId());
        AssetGroupItem addedItem =
            groupPersistencyService.addGroupItem(TestUtils.TEST_TENANT, TestUtils.getUber(), group.getId(), item);
        assertThat(addedItem.getObjectId()).isEqualTo(item.getObjectId());
        assertThat(addedItem.getPosition()).isEqualTo(1);
        assertThat(groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, Collections.singletonList(assets.get("E1").getId()), group.getId()))
            .hasSize(1);

        // add 2nd item
        item = TagPredicateUtils.newTagCorrelationItem(tags.get(1), group.getId());
        addedItem = groupPersistencyService
            .addGroupItem(TestUtils.TEST_TENANT,
                Arrays.asList(assets.get("E1_S1").getId(), assets.get("E1_S1_Seg1").getId()),
                group.getId(), item);
        assertThat(addedItem.getObjectId()).isEqualTo(item.getObjectId());
        assertThat(addedItem.getPosition()).isEqualTo(2);
        assertThat(groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1_Asset1").getId()),
                group.getId())).hasSize(2).extracting(AssetGroupItem::getPosition).containsOnly(1, 2);

        // add 3rd item
        item = TagPredicateUtils.newTagCorrelationItem(tags.get(2), group.getId());
        addedItem = groupPersistencyService
            .addGroupItem(TestUtils.TEST_TENANT,
                Arrays.asList(assets.get("E1_S1").getId(), assets.get("E1_S1_Seg1").getId()),
                group.getId(), item);
        assertThat(addedItem.getObjectId()).isEqualTo(item.getObjectId());
        assertThat(addedItem.getPosition()).isEqualTo(3);
        List<AssetGroupItem> items = groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1_Asset1").getId()),
                group.getId());
        assertThat(items.size()).isEqualTo(3);
        // verify order by is applied
        for (int i = 0, size = items.size(); i < size; i++) {
            assertThat(items.get(i).getPosition()).isEqualTo(i + 1);
        }

        // add 3rd item again, expected to fail
        assertThat(
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), group.getId()))
            .hasSize(0);
        item = TagPredicateUtils.newTagCorrelationItem(tags.get(2), group.getId());

        try {
            // adding a tag that is already in the correlation is a violation
            groupPersistencyService.addGroupItem(TestUtils.TEST_TENANT, TestUtils.getUber(), group.getId(), item);
            failBecauseExceptionWasNotThrown(IllegalArgumentException.class);
        } catch (IllegalArgumentException iae) {
            // expected, ignore
        }
    }
}
