/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.template;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.PlaceholderTemplate;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholder;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderTemplate;
import com.ge.apm.alm.persistence.jpa.model.TestTemplate;
import com.ge.apm.alm.persistence.jpa.utils.TestTemplateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */
public class PlaceholderTemplatePersistSvcTests extends TemplatePersistSvcBaseTests {

    @Test
    @Transactional
    public void testCreatePlaceholderTemplate() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestTemplate subTemplate = createTestTemplate("GE90_Fan_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestPlaceholderTemplate testPlaceholderTemplate = createTestPlaceholderTemplate(testPlaceholder, subTemplate);

        // make sure that retrieve Placeholder, PlaceholderTemplate also returned.
        Placeholder dbPlaceholder = placeholderPersistencyService
            .getPlaceholderById(TestUtils.TEST_TENANT, testPlaceholder.getId());
        assertThat(dbPlaceholder).isNotNull();
        assertThat(dbPlaceholder.getId()).isEqualTo(testPlaceholder.getId());
        assertThat(dbPlaceholder.getPlaceholderTemplate().getId()).isEqualTo(testPlaceholderTemplate.getId());
        assertThat(dbPlaceholder.getPlaceholderTemplate().getTemplateId())
            .isEqualTo(testPlaceholderTemplate.getTemplateId());

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTemplate(testPlaceholderTemplate);
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreatePlaceholderTemplate_missingId() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderTemplate testPlaceholderTemplate = TestTemplateUtils.buildPlaceholderTemplate(uuid, uuid);
        testPlaceholderTemplate.setId(null);
        placeholderTemplatePersistencyService.createPlaceholderTemplate(TestUtils.TEST_TENANT, testPlaceholderTemplate);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderTemplate_missingPlaceholderId() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderTemplate testPlaceholderTemplate = TestTemplateUtils.buildPlaceholderTemplate(uuid, uuid);
        testPlaceholderTemplate.setPlaceholderId(null);
        placeholderTemplatePersistencyService.createPlaceholderTemplate(TestUtils.TEST_TENANT, testPlaceholderTemplate);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderTemplate_missingTemplateId() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderTemplate testPlaceholderTemplate = TestTemplateUtils.buildPlaceholderTemplate(uuid, uuid);
        testPlaceholderTemplate.setTemplateId(null);
        placeholderTemplatePersistencyService.createPlaceholderTemplate(TestUtils.TEST_TENANT, testPlaceholderTemplate);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderTemplate_missingStatus() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderTemplate testPlaceholderTemplate = TestTemplateUtils.buildPlaceholderTemplate(uuid, uuid);
        testPlaceholderTemplate.setStatus(null);
        placeholderTemplatePersistencyService.createPlaceholderTemplate(TestUtils.TEST_TENANT, testPlaceholderTemplate);
    }


    @Test
    @Transactional
    public void testCreatePlaceholderTemplates() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestTemplate subTemplate1 = createTestTemplate("GE90_Fan_template1", null, null);
        TestTemplate subTemplate2 = createTestTemplate("GE90_Fan_template2", null, null);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN01");
        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN02");

        List<PlaceholderTemplate> placeholderTemplates = new ArrayList<>();
        final String placeholderId1 = testPlaceholder1.getId();
        final String placeholderId2 = testPlaceholder2.getId();
        placeholderTemplates.add(TestTemplateUtils.buildPlaceholderTemplate(placeholderId1, subTemplate1.getId()));
        placeholderTemplates.add(TestTemplateUtils.buildPlaceholderTemplate(placeholderId2, subTemplate2.getId()));

        final String tenantId = TestUtils.TEST_TENANT;
        int counter = placeholderTemplatePersistencyService.createPlaceholderTemplates(tenantId, new ArrayList<>());
        assertThat(counter).isEqualTo(0);

        counter = placeholderTemplatePersistencyService.createPlaceholderTemplates(tenantId, placeholderTemplates);
        assertThat(counter).isEqualTo(placeholderTemplates.size());

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTemplate(placeholderTemplates.get(0));
        testPlaceholder2.setPlaceholderTemplate(placeholderTemplates.get(1));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testUpdatePlaceholderTemplate() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestTemplate subTemplate = createTestTemplate("GE90_sub_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestPlaceholderTemplate testPlaceholderTemplate = createTestPlaceholderTemplate(testPlaceholder, subTemplate);

        testPlaceholderTemplate.setStatus("Inactive");
        PlaceholderTemplate savedPlaceholderTemplate = placeholderTemplatePersistencyService
            .updatePlaceholderTemplate(TestUtils.TEST_TENANT, testPlaceholderTemplate);
        assertThat(savedPlaceholderTemplate).isNotNull();
        assertThat(savedPlaceholderTemplate.getId()).isEqualTo(testPlaceholderTemplate.getId());
        assertThat(savedPlaceholderTemplate.getStatus()).isEqualTo(testPlaceholderTemplate.getStatus());

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTemplate(testPlaceholderTemplate);
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testUpdatePlaceholderTemplates() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestTemplate subTemplate1 = createTestTemplate("GE90_sub_template1", null, null);
        TestTemplate subTemplate2 = createTestTemplate("GE90_sub_template2", null, null);
        TestTemplate subTemplate3 = createTestTemplate("GE90_sub_template3", null, null);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN01");
        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN02");

        List<PlaceholderTemplate> placeholderTemplates = new ArrayList<>();
        final String placeholderId1 = testPlaceholder1.getId();
        final String placeholderId2 = testPlaceholder2.getId();
        placeholderTemplates.add(TestTemplateUtils.buildPlaceholderTemplate(placeholderId1, subTemplate1.getId()));
        placeholderTemplates.add(TestTemplateUtils.buildPlaceholderTemplate(placeholderId2, subTemplate2.getId()));

        final String tenantId = TestUtils.TEST_TENANT;
        int counter = placeholderTemplatePersistencyService.updatePlaceholderTemplates(tenantId, new ArrayList<>());
        assertThat(counter).isEqualTo(0);

        counter = placeholderTemplatePersistencyService.createPlaceholderTemplates(tenantId, placeholderTemplates);
        assertThat(counter).isEqualTo(2);

        placeholderTemplates.add(TestTemplateUtils.buildPlaceholderTemplate(placeholderId2, subTemplate3.getId()));
        counter = placeholderTemplatePersistencyService.updatePlaceholderTemplates(tenantId, placeholderTemplates);
        assertThat(counter).isEqualTo(3);

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTemplate(placeholderTemplates.get(0));
        testPlaceholder2.setPlaceholderTemplate(placeholderTemplates.get(1));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testDeletePlaceholderTemplateById() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestTemplate subTemplate = createTestTemplate("GE90_sub_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestPlaceholderTemplate testPlaceholderTemplate = createTestPlaceholderTemplate(testPlaceholder, subTemplate);

        int counter = placeholderTemplatePersistencyService
            .deletePlaceholderTemplateById(TestUtils.TEST_TENANT, testPlaceholderTemplate.getId());
        assertThat(counter).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTemplate(testPlaceholderTemplate);
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeletePlaceholderTemplateById_NotFoundException() throws PersistencyServiceException {
        placeholderTemplatePersistencyService.deletePlaceholderTemplateById(TestUtils.TEST_TENANT,
            TestTemplateUtils.getNewUuid());
    }

    @Test
    @Transactional
    public void testDeletePlaceholderTemplateByPlaceholderId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestTemplate subTemplate = createTestTemplate("GE90_sub_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestPlaceholderTemplate testPlaceholderTemplate = createTestPlaceholderTemplate(testPlaceholder, subTemplate);

        int counter = placeholderTemplatePersistencyService
            .deletePlaceholderTemplateByPlaceholderId(TestUtils.TEST_TENANT, testPlaceholder.getId());
        assertThat(counter).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTemplate(testPlaceholderTemplate);
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void deletePlaceholderTemplateByPlaceholderId_NotFoundException() throws PersistencyServiceException {
        placeholderTemplatePersistencyService.deletePlaceholderTemplateByPlaceholderId(TestUtils.TEST_TENANT,
            TestTemplateUtils.getNewUuid());
    }

    @Test
    @Transactional
    public void deletePlaceholderTemplateByPlaceholderIdAndTemplateId() throws IOException,
        PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestTemplate subTemplate = createTestTemplate("GE90_sub_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestPlaceholderTemplate testPlaceholderTemplate = createTestPlaceholderTemplate(testPlaceholder, subTemplate);

        int counter = placeholderTemplatePersistencyService
            .deletePlaceholderTemplateByPlaceholderIdAndTemplateId(TestUtils.TEST_TENANT,
                testPlaceholderTemplate.getPlaceholderId(), testPlaceholderTemplate.getTemplateId());
        assertThat(counter).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTemplate(testPlaceholderTemplate);
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = ObjectNotFoundException.class)
    public void deletePlaceholderTemplateByPlaceholderIdAndTemplateId_NotFoundException()
        throws PersistencyServiceException {
        String uuid = TestTemplateUtils.getNewUuid();
        placeholderTemplatePersistencyService
            .deletePlaceholderTemplateByPlaceholderIdAndTemplateId(TestUtils.TEST_TENANT,
                uuid, uuid);
    }

    @Test
    @Transactional
    public void testGetPlaceholderTemplateById() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestTemplate subTemplate = createTestTemplate("GE90_sub_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestPlaceholderTemplate testPlaceholderTemplate = createTestPlaceholderTemplate(testPlaceholder, subTemplate);

        PlaceholderTemplate dbPlaceholderTemplate = placeholderTemplatePersistencyService
            .getPlaceholderTemplateById(TestUtils.TEST_TENANT, testPlaceholderTemplate.getId());
        assertThat(dbPlaceholderTemplate).isNotNull();
        assertThat(dbPlaceholderTemplate.getId()).isEqualTo(testPlaceholderTemplate.getId());

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTemplate(testPlaceholderTemplate);
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    public void testGetPlaceholderTemplateById_EmptyResultDataAccessException() {
        assertThat(placeholderTemplatePersistencyService
            .getPlaceholderTemplateById(TestUtils.TEST_TENANT, TestTemplateUtils.getNewUuid())).isNull();
    }


    @Test
    @Transactional
    public void testGetPlaceholderTemplateByPlaceholderId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestTemplate subTemplate = createTestTemplate("GE90_sub_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        TestPlaceholderTemplate testPlaceholderTemplate = createTestPlaceholderTemplate(testPlaceholder, subTemplate);

        PlaceholderTemplate dbPlaceholderTemplate = placeholderTemplatePersistencyService
            .getPlaceholderTemplateByPlaceholderId(TestUtils.TEST_TENANT, testPlaceholderTemplate.getPlaceholderId());
        assertThat(dbPlaceholderTemplate).isNotNull();
        assertThat(dbPlaceholderTemplate.getId()).isEqualTo(testPlaceholderTemplate.getId());

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTemplate(testPlaceholderTemplate);
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    public void testGetPlaceholderTemplateByPlaceholderId_EmptyResultDataAccessException() {
        assertThat(placeholderTemplatePersistencyService
            .getPlaceholderTemplateByPlaceholderId(TestUtils.TEST_TENANT, TestTemplateUtils.getNewUuid())).isNull();
    }

    @Test
    @Transactional
    public void testGetPlaceholderTemplatesByTemplateId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestTemplate subTemplate1 = createTestTemplate("GE90_sub_template1", null, null);
        TestTemplate subTemplate2 = createTestTemplate("GE90_sub_template2", null, null);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN100");
        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN101");

        List<PlaceholderTemplate> placeholderTemplates = new ArrayList<>();
        final String placeholderId1 = testPlaceholder1.getId();
        final String placeholderId2 = testPlaceholder2.getId();
        placeholderTemplates.add(TestTemplateUtils.buildPlaceholderTemplate(placeholderId1, subTemplate1.getId()));
        placeholderTemplates.add(TestTemplateUtils.buildPlaceholderTemplate(placeholderId2, subTemplate2.getId()));

        final String tenantId = TestUtils.TEST_TENANT;
        int counter = placeholderTemplatePersistencyService.createPlaceholderTemplates(tenantId, placeholderTemplates);
        assertThat(counter).isEqualTo(placeholderTemplates.size());

        List<PlaceholderTemplate> foundPlaceholderTemplates = placeholderTemplatePersistencyService
            .getPlaceholderTemplateByTemplateId(TestUtils.TEST_TENANT, subTemplate2.getId());
        assertThat(foundPlaceholderTemplates.size()).isEqualTo(1);

        // make sure that retrieve Placeholder, PlaceholderTemplate also returned.
        Template dbTemplate = templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, testTemplate.getId());
        assertThat(dbTemplate).isNotNull();
        assertThat(dbTemplate.getPlaceholders().size()).isEqualTo(2);
        assertThat(dbTemplate.getPlaceholders().get(0).getPlaceholderTemplate()).isNotNull();
        assertThat(dbTemplate.getPlaceholders().get(1).getPlaceholderTemplate()).isNotNull();

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTemplate(placeholderTemplates.get(0));
        testPlaceholder2.setPlaceholderTemplate(placeholderTemplates.get(1));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }


    @Test
    @Transactional
    public void testGetPlaceholderTemplates_placeholderIds() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestTemplate subTemplate1 = createTestTemplate("GE90_sub_template1", null, null);
        TestTemplate subTemplate2 = createTestTemplate("GE90_sub_template2", null, null);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN100");
        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN101");

        List<PlaceholderTemplate> placeholderTemplates = new ArrayList<>();
        final String placeholderId1 = testPlaceholder1.getId();
        final String placeholderId2 = testPlaceholder2.getId();
        placeholderTemplates.add(TestTemplateUtils.buildPlaceholderTemplate(placeholderId1, subTemplate1.getId()));
        placeholderTemplates.add(TestTemplateUtils.buildPlaceholderTemplate(placeholderId2, subTemplate2.getId()));

        final String tenantId = TestUtils.TEST_TENANT;
        int counter = placeholderTemplatePersistencyService.createPlaceholderTemplates(tenantId, placeholderTemplates);
        assertThat(counter).isEqualTo(placeholderTemplates.size());

        List<String> placeholderIds = new ArrayList<>();
        placeholderIds.add(testPlaceholder1.getId());
        placeholderIds.add(testPlaceholder2.getId());

        assertThat(placeholderTemplatePersistencyService
            .getPlaceholderTemplates(TestUtils.TEST_TENANT, new ArrayList<>())).isEmpty();
        List<PlaceholderTemplate> foundPlaceholderTemplates = placeholderTemplatePersistencyService
            .getPlaceholderTemplates(TestUtils.TEST_TENANT, placeholderIds);
        assertThat(foundPlaceholderTemplates.size()).isEqualTo(2);

        // make sure that retrieve Placeholder, PlaceholderTemplate also returned.
        Template dbTemplate = templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, testTemplate.getId());
        assertThat(dbTemplate).isNotNull();
        assertThat(dbTemplate.getPlaceholders().size()).isEqualTo(2);
        assertThat(dbTemplate.getPlaceholders().get(0).getPlaceholderTemplate()).isNotNull();
        assertThat(dbTemplate.getPlaceholders().get(1).getPlaceholderTemplate()).isNotNull();

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTemplate(placeholderTemplates.get(0));
        testPlaceholder2.setPlaceholderTemplate(placeholderTemplates.get(1));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }


    @Test
    @Transactional
    public void testGetPlaceholderTypes_compositeTemplateId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestTemplate subTemplate1 = createTestTemplate("GE90_sub_template1", null, null);
        TestTemplate subTemplate2 = createTestTemplate("GE90_sub_template2", null, null);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN100");
        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN101");

        List<PlaceholderTemplate> placeholderTemplates = new ArrayList<>();
        final String placeholderId1 = testPlaceholder1.getId();
        final String placeholderId2 = testPlaceholder2.getId();
        placeholderTemplates.add(TestTemplateUtils.buildPlaceholderTemplate(placeholderId1, subTemplate1.getId()));
        placeholderTemplates.add(TestTemplateUtils.buildPlaceholderTemplate(placeholderId2, subTemplate2.getId()));

        final String tenantId = TestUtils.TEST_TENANT;
        int counter = placeholderTemplatePersistencyService.createPlaceholderTemplates(tenantId, placeholderTemplates);
        assertThat(counter).isEqualTo(placeholderTemplates.size());

        List<PlaceholderTemplate> foundPlaceholderTemplates = placeholderTemplatePersistencyService
            .getPlaceholderTemplates(TestUtils.TEST_TENANT, testTemplate.getId());
        assertThat(foundPlaceholderTemplates.size()).isEqualTo(2);

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTemplate(placeholderTemplates.get(0));
        testPlaceholder2.setPlaceholderTemplate(placeholderTemplates.get(1));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    private void deleteTestTemplateCascade(TestTemplate testTemplate) throws PersistencyServiceException {
        String templateId = testTemplate.getId();
        final String tenantId = TestUtils.TEST_TENANT;
        templatePersistencyService.deleteTemplateById(tenantId, templateId);
        assertThat(templatePersistencyService.getTemplateById(tenantId, templateId)).isNull();

        List<Placeholder> placeholders = testTemplate.getPlaceholders();
        for (Placeholder placeholder : placeholders) {
            assertThat(placeholderPersistencyService.getPlaceholderById(tenantId, placeholder.getId()))
                .isNull();

            PlaceholderTemplate placeholderTemplate = placeholder.getPlaceholderTemplate();
            if (placeholderTemplate != null) {
                assertThat(placeholderTemplatePersistencyService
                    .getPlaceholderTemplateById(tenantId, placeholderTemplate.getId())).isNull();
            }
        }
    }
}
