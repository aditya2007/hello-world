/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.tag.correlation;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.exceptions.SuperTypeDoesNotExistsException;
import com.ge.apm.alm.persistence.jpa.utils.TagPredicateUtils;

/**
 * Tests the JPA Persistency Layer
 */
public abstract class TagCorrelationBaseTest {

    @Autowired
    AssetTypePersistencyService assetTypePersistencyService;
    @Autowired
    AssetPersistencyService assetPersistencyService;
    @Autowired
    TagPersistencyService tagPersistencyService;
    @Autowired
    GroupPersistencyService groupPersistencyService;

    Map<String, AssetType> createTypes(AssetTypePersistencyService assetTypePersistencyService)
        throws IOException, SuperTypeDoesNotExistsException {
        return TagPredicateUtils.createTypes(assetTypePersistencyService);
    }

    Map<String, Asset> createAssets(AssetPersistencyService assetPersistencyService,
        Map<String, AssetType> types)

        throws IOException, PersistencyServiceException {
        return TagPredicateUtils.createAssets(assetPersistencyService, types);
    }

    List<Tag> createTagData(TagPersistencyService tagPersistencyService, String tagTypeId, Asset asset,
        int numTags) throws IOException, PersistencyServiceException {
        return TagPredicateUtils.createTagDataForAsset(tagPersistencyService, tagTypeId, asset, numTags);
    }
}
