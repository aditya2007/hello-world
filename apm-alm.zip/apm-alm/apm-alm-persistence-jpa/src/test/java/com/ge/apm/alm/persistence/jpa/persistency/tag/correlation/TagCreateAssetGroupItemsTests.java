/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.tag.correlation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.exceptions.IncompatibleItemsException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroupItem;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.NULL_UUID;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TagCreateAssetGroupItemsTests extends TagCorrelationBaseTest {

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void createAssetGroupItems_itemsFromMultipleGroups() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 5;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup assetGroup =
            TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
                .category(AssetGroupCategory.TAG_CORRELATION)
                .build();
        AssetGroup createdGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0, size = tags.size(); i < size; i++) {
            Tag tag = tags.get(i);
            items.add(TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).groupId(createdGroup.getId())
                .objectId(tag.getId()).tenantId(TestUtils.TEST_TENANT).position(i + 1).build());
        }
        ((TestAssetGroupItem) items.get(2)).setGroupId(NULL_UUID);
        groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), createdGroup.getId(), items);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void createAssetGroupItems_itemsFromMultipleTenants() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 5;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup assetGroup =
            TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
                .category(AssetGroupCategory.TAG_CORRELATION)
                .build();
        AssetGroup createdGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0, size = tags.size(); i < size; i++) {
            Tag tag = tags.get(i);
            items.add(TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).groupId(createdGroup.getId())
                .objectId(tag.getId()).tenantId(TestUtils.TEST_TENANT).position(i + 1).build());
        }
        ((TestAssetGroupItem) items.get(2)).setTenantId(NULL_UUID);
        groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), createdGroup.getId(), items);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void createAssetGroupItems_overlappedPositions() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 5;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup assetGroup =
            TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
                .category(AssetGroupCategory.TAG_CORRELATION)
                .build();
        AssetGroup createdGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0, size = tags.size(); i < size; i++) {
            Tag tag = tags.get(i);
            items.add(TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).groupId(createdGroup.getId())
                .objectId(tag.getId()).tenantId(TestUtils.TEST_TENANT).position(i + 1).build());
        }
        ((TestAssetGroupItem) items.get(2)).setPosition(1);
        groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), createdGroup.getId(), items);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void createAssetGroupItems_positionsNotSequential() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 5;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup assetGroup =
            TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
                .category(AssetGroupCategory.TAG_CORRELATION)
                .build();
        AssetGroup createdGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0, size = tags.size(); i < size; i++) {
            Tag tag = tags.get(i);
            items.add(TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).groupId(createdGroup.getId())
                .objectId(tag.getId()).tenantId(TestUtils.TEST_TENANT).position(i + 1).build());
        }
        ((TestAssetGroupItem) items.get(tags.size() - 1)).setPosition(tags.size() + 1);
        groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), createdGroup.getId(), items);
    }

    @Test(expected = IncompatibleItemsException.class)
    @Transactional
    public void createAssetGroupItems_tagCorrelationAllowedOnlyForSameAsset()
        throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), 2);
        tags.addAll(createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset2"), 3));

        AssetGroup assetGroup =
            TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
                .category(AssetGroupCategory.TAG_CORRELATION)
                .build();
        AssetGroup createdGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0, size = tags.size(); i < size; i++) {
            Tag tag = tags.get(i);
            items.add(TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).groupId(createdGroup.getId())
                .objectId(tag.getId()).tenantId(TestUtils.TEST_TENANT).position(i + 1).build());
        }
        groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), createdGroup.getId(), items);
    }

    @Test(expected = IncompatibleItemsException.class)
    @Transactional
    public void createAssetGroupItems_assetForTagsMustBeAccessible() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 5;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);
        AssetGroup assetGroup =
            TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
                .category(AssetGroupCategory.TAG_CORRELATION)
                .build();
        AssetGroup createdGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0, size = tags.size(); i < size; i++) {
            Tag tag = tags.get(i);
            items.add(TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).groupId(createdGroup.getId())
                .objectId(tag.getId()).tenantId(TestUtils.TEST_TENANT).position(i + 1).build());
        }
        groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), createdGroup.getId(), items);
    }

    @Test
    @Transactional
    public void createAssetGroupItems_correlatedGroup_asUber_queryWithOrWithoutACL()
        throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 3;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup assetGroup =
            TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
                .category(AssetGroupCategory.TAG_CORRELATION)
                .build();
        AssetGroup createdGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            Tag tag = tags.get(i);
            items.add(TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).groupId(createdGroup.getId())
                .objectId(tag.getId()).tenantId(TestUtils.TEST_TENANT).position(i + 1).build());
        }
        Collections.reverse(items);
        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), createdGroup.getId(), items))
            .isEqualTo(items.size());
        assertThat(
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroup.getId()))
            .hasSize(items.size());
        List<AssetGroupItem> responses = groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1").getId()),
                assetGroup.getId());
        assertThat(responses).hasSize(items.size()).extracting(AssetGroupItem::getObjectId).containsOnly(
            items.get(0).getObjectId(), items.get(1).getObjectId(), items.get(2).getObjectId());
        for (int i = 0, size = responses.size(); i < size; i++) {
            assertThat(responses.get(i).getPosition()).isEqualTo(i + 1);
        }
        assertThat(groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), assetGroup.getId()))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void createAssetGroupItems_CorrelatedGroup_withACL_queryWithOrWithoutACL()
        throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 5;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup assetGroup =
            TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
                .category(AssetGroupCategory.TAG_CORRELATION)
                .build();
        AssetGroup createdGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            Tag tag = tags.get(i);
            items.add(TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).groupId(createdGroup.getId())
                .objectId(tag.getId()).tenantId(TestUtils.TEST_TENANT).position(i + 1).build());
        }
        Collections.reverse(items);
        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT,
                Arrays.asList(assets.get("E1").getId(), assets.get("E1_S1").getId()),
                createdGroup.getId(), items)).isEqualTo(items.size());
        assertThat(groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, Arrays.asList(assets.get("E1").getId(), assets.get("E1_S1").getId()),
                assetGroup.getId())).hasSize(items.size());
        List<AssetGroupItem> responses = groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1_Asset1").getId()),
                assetGroup.getId());
        assertThat(responses).hasSize(items.size());
        for (int i = 0, size = responses.size(); i < size; i++) {
            assertThat(responses.get(i).getPosition()).isEqualTo(i + 1);
        }
        assertThat(groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), assetGroup.getId()))
            .hasSize(0);
    }
}
