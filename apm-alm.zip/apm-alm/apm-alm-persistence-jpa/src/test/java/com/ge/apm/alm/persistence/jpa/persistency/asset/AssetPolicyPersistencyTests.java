/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AssetRestrictionFeature;
import com.ge.apm.alm.model.AssetUserPolicy;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectAlreadyExistsException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.AssetPolicyPersistencyServiceImpl;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetUserPolicyEntity;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Yogananda Gowda - 212590467 on 9/29/17.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetPolicyPersistencyTests {

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    private String USER_ID = "35421a16-ff72-4758-9198-dde07a6d4836";

    private String USER_GROUP_ID = "65119077-b853-4a18-bc66-3aa9acb4e985";

    private String USER_GROUP_ID_1 = "75119077-b853-4a18-bc66-3aa9acb4e990";

    private String USER_NAME = "TestUser";

    private String DISPLAY_NAME = "Test User";

    private String UG_DISPLAY_NAME = "Test User";

    private String TENANT_ID = "ed7b023a-5ed2-4f15-8e28-4393e70a09e7";

    private static final String VIEW_DECOMM_FCODE = "VIEW_DECOMMISSIONED_ASSETS";

    private String RESTRICT_BY_CLASS_FCODE = "RESTRICT_ASSETS_BY_CLASS";

    private String ASSET_TYPE = "4012dc78-2339-37f2-bbba-92a980b9ee65";

    @Test
    public void testGetAllAssetRestrictionFeatures() {
        List<AssetRestrictionFeature> features = assetPolicyPersistencyService.getAssetRestrictionFeatures();
        assertThat(features).isNotNull();
        assertThat(features.size()).isGreaterThan(0);
    }

    @Test
    public void testGetActiveAssetRestrictionFeature() {
        List<AssetRestrictionFeature> features = assetPolicyPersistencyService.getAssetRestrictionFeaturesByStatus(
            true);
        assertThat(features).isNotNull();
        assertThat(features.size()).isGreaterThan(0);
    }

    @Test
    public void testGetInActiveAssetRestrictionFeature() {
        List<AssetRestrictionFeature> features = assetPolicyPersistencyService.getAssetRestrictionFeaturesByStatus(
            false);
        assertThat(features).isNotNull();
        assertThat(features.size()).isGreaterThan(0);
    }

    @Test
    public void testGetAssetFeatureByFeatureCode() {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();
        assertThat(assetRestrictionFeature.getName()).isEqualTo("Hide assets by classification");
    }

    @Test
    @Transactional
    public void testCreateAssetUserPolicy() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        String filterCriteria = "/assetTypes/" + getRandomId();
        assetPolicyPersistencyService.createUserPolicy(TestUtils.TEST_TENANT,
            createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));
    }

    @Test(expected = ObjectAlreadyExistsException.class)
    @Transactional
    public void testCreateAssetUserPolicyUqConst() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        String filterCriteria = "/assetTypes/" + getRandomId();
        assetPolicyPersistencyService.createUserPolicy(TestUtils.TEST_TENANT,
            createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));
        assetPolicyPersistencyService.createUserPolicy(TestUtils.TEST_TENANT,
            createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));
    }

    @Test
    @Transactional
    public void testCreateAssetUserPolicyUqConstErrMessage() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        String filterCriteria = "/assetTypes/" + getRandomId();

        try {
            assetPolicyPersistencyService.createUserPolicy(TestUtils.TEST_TENANT,
                createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));
            assetPolicyPersistencyService.createUserPolicy(TestUtils.TEST_TENANT,
                createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));
        } catch (ObjectAlreadyExistsException oae) {
            assertThat(oae.getMessage()).isNotNull();
            assertThat(oae.getMessage()).contains(filterCriteria);
        }
    }

    @Test
    @Transactional
    public void testCreateViewDecommissionedAssetUserPolicies() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(VIEW_DECOMM_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        List<AssetUserPolicyEntity> entities = new ArrayList<>();
        IntStream.range(1, 2).forEach(index -> {
            entities.add(createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE,
                assetRestrictionFeature.getDefaultFilterCriteria()));
        });

        int numOfRecCreated = assetPolicyPersistencyService.createUserPolicies(TestUtils.TEST_TENANT,
            Collections.unmodifiableList(entities));
        assertThat(numOfRecCreated).isEqualTo(1);
    }

    @Test
    @Transactional
    public void testCreateAssetUserPolicies() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        List<AssetUserPolicyEntity> entities = new ArrayList<>();
        IntStream.range(1, 6).forEach(index -> {
            String filterCriteria = "/assetTypes/" + getRandomId();
            entities.add(createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));
        });

        int numOfRecCreated = assetPolicyPersistencyService.createUserPolicies(TestUtils.TEST_TENANT,
            Collections.unmodifiableList(entities));
        assertThat(numOfRecCreated).isEqualTo(5);
    }

    @Test(expected = ObjectAlreadyExistsException.class)
    @Transactional
    public void testCreateAssetUserPoliciesUqConst() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        List<AssetUserPolicyEntity> entities = new ArrayList<>();
        IntStream.range(1, 6).forEach(index -> {
            String filterCriteria = "/assetTypes/" + getRandomId();
            entities.add(createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));
        });

        entities.add(
            createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, entities.get(0).getFilterCriteria()));
        int numOfRecCreated = assetPolicyPersistencyService.createUserPolicies(TestUtils.TEST_TENANT,
            Collections.unmodifiableList(entities));
        assertThat(numOfRecCreated).isEqualTo(6);
    }

    @Test
    @Transactional
    public void testCreateAssetUserPoliciesUqConstErrMessage() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        List<AssetUserPolicyEntity> entities = new ArrayList<>();
        IntStream.range(1, 6).forEach(index -> {
            String filterCriteria = "/assetTypes/" + getRandomId();
            entities.add(createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));
        });

        entities.add(
            createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, entities.get(0).getFilterCriteria()));
        try {
            assetPolicyPersistencyService.createUserPolicies(TestUtils.TEST_TENANT,
                Collections.unmodifiableList(entities));
        } catch (ObjectAlreadyExistsException oae) {
            assertThat(oae.getMessage()).isNotNull();
            assertThat(oae.getMessage()).contains(entities.get(0).getFilterCriteria());
        }
    }

    @Test
    @Transactional
    public void testDeleteAssetUserPolicyById() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        String filterCriteria = "/assetTypes/" + getRandomId();
        AssetUserPolicy userPolicy = assetPolicyPersistencyService.createUserPolicy(TestUtils.TEST_TENANT,
            createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));

        assertThat(userPolicy).isNotNull();

        assetPolicyPersistencyService.deleteAssetUserPolicy(TestUtils.TEST_TENANT, userPolicy.getId());

        userPolicy = assetPolicyPersistencyService.getAssetUserPolicyById(TestUtils.TEST_TENANT, userPolicy.getId());

        assertThat(userPolicy).isNull();
    }

    @Test
    @Transactional
    public void testDeleteDecommAssetUserPolicyById() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature =
                assetPolicyPersistencyService.getAssetRestrictionFeatureByCode(VIEW_DECOMM_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        AssetUserPolicy userPolicy = assetPolicyPersistencyService.createUserPolicy(TestUtils.TEST_TENANT,
                createAssetUserPolicyEntity(
                assetRestrictionFeature, ASSET_TYPE, assetRestrictionFeature.getDefaultFilterCriteria()));
        assertThat(userPolicy).isNotNull();

        assetPolicyPersistencyService.deleteAssetUserPolicy(TestUtils.TEST_TENANT, userPolicy.getId());

        userPolicy = assetPolicyPersistencyService.getAssetUserPolicyById(TestUtils.TEST_TENANT, userPolicy.getId());

        assertThat(userPolicy).isNull();
    }

    @Test
    @Transactional
    public void testDeleteAllAssetUserPolicyByTenant() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        String filterCriteria = "/assetTypes/" + getRandomId();
        AssetUserPolicy userPolicy = assetPolicyPersistencyService.createUserPolicy(TestUtils.TEST_TENANT,
            createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));

        assertThat(userPolicy).isNotNull();

        assetPolicyPersistencyService.deleteAllAssetUserPolicy(TestUtils.TEST_TENANT);

        userPolicy = assetPolicyPersistencyService.getAssetUserPolicyById(TestUtils.TEST_TENANT, userPolicy.getId());

        assertThat(userPolicy).isNull();
    }

    @Test
    @Transactional
    public void testGetUserPolicyById() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        String filterCriteria = "/assetTypes/" + getRandomId();
        AssetUserPolicy userPolicy = assetPolicyPersistencyService.createUserPolicy(TestUtils.TEST_TENANT,
            createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));
        assertThat(userPolicy).isNotNull();
        userPolicy = assetPolicyPersistencyService.getAssetUserPolicyById(TestUtils.TEST_TENANT, userPolicy.getId());
        assertThat(userPolicy).isNotNull();
        assertThat(userPolicy.getUserName()).isEqualTo(USER_NAME);
    }

    @Test
    @Transactional
    public void testGetAssetUserPolicies() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        List<AssetUserPolicyEntity> entities = new ArrayList<>();
        IntStream.range(1, 6).forEach(index -> {
            String filterCriteria = "/assetTypes/" + getRandomId();
            entities.add(createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));
        });

        int numOfRecCreated = assetPolicyPersistencyService.createUserPolicies(TestUtils.TEST_TENANT,
            Collections.unmodifiableList(entities));
        assertThat(numOfRecCreated).isEqualTo(5);

        List<AssetUserPolicy> policies = assetPolicyPersistencyService.getAssetUserPolicies(TestUtils.TEST_TENANT,
            assetRestrictionFeature.getId());

        assertThat(policies).isNotNull();
        assertThat(policies).size().isEqualTo(5);
    }

    @Test
    @Transactional
    public void testGetAssetUserPoliciesByTenant() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature =
            assetPolicyPersistencyService.getAssetRestrictionFeatureByCode(VIEW_DECOMM_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        AssetUserPolicy userPolicy = assetPolicyPersistencyService.createUserPolicy(TestUtils.TEST_TENANT,
            createAssetUserPolicyEntity(
                assetRestrictionFeature, ASSET_TYPE, assetRestrictionFeature.getDefaultFilterCriteria()));
        assertThat(userPolicy).isNotNull();

        AssetUserPolicy userGroupPolicy = assetPolicyPersistencyService.createUserPolicy(TestUtils.TEST_TENANT,
         createAssetUserGroupPolicyEntity(assetRestrictionFeature, ASSET_TYPE,
            assetRestrictionFeature.getDefaultFilterCriteria()));
        assertThat(userGroupPolicy).isNotNull();

        List<AssetUserPolicy> policies = assetPolicyPersistencyService.getAssetUserPoliciesByTenant(TestUtils
            .TEST_TENANT);
        assertThat(policies).isNotNull();
        assertThat(policies).size().isEqualTo(2);
    }

    @Test
    @Transactional
    public void testGetAssetUserPoliciesBySubjectId() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        List<AssetUserPolicyEntity> entities = new ArrayList<>();
        IntStream.range(1, 6).forEach(index -> {
            String filterCriteria = "/assetTypes/" + getRandomId();
            entities.add(createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));
        });

        int numOfRecCreated = assetPolicyPersistencyService.createUserPolicies(TestUtils.TEST_TENANT,
            Collections.unmodifiableList(entities));
        assertThat(numOfRecCreated).isEqualTo(5);

        List<AssetUserPolicy> policies = assetPolicyPersistencyService.getAssetUserPoliciesBySubject(
            TestUtils.TEST_TENANT, USER_ID, AssetUserPolicy.SubjectType.USER.getType());

        assertThat(policies).isNotNull();
        assertThat(policies).size().isEqualTo(5);

        assetPolicyPersistencyService.deleteAllAssetUserPolicy(TestUtils.TEST_TENANT);
    }

    @Test
    @Transactional
    public void testGetAssetUserGroupPoliciesBySubjectId() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        List<AssetUserPolicyEntity> entities = new ArrayList<>();
        IntStream.range(1, 6).forEach(index -> {
            String filterCriteria = "/assetTypes/" + getRandomId();
            entities.add(createAssetUserGroupPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));
        });

        int numOfRecCreated = assetPolicyPersistencyService.createUserPolicies(TestUtils.TEST_TENANT,
            Collections.unmodifiableList(entities));
        assertThat(numOfRecCreated).isEqualTo(5);

        List<AssetUserPolicy> policies = assetPolicyPersistencyService.getAssetUserPoliciesBySubject(
            TestUtils.TEST_TENANT, USER_GROUP_ID, AssetUserPolicy.SubjectType.USER_GROUP.getType());

        assertThat(policies).isNotNull();
        assertThat(policies).size().isEqualTo(5);

        assetPolicyPersistencyService.deleteAllAssetUserPolicy(TestUtils.TEST_TENANT);
    }

    @Test
    @Transactional
    public void testGetAssetUserAndUserGroupPoliciesBySubjectId() throws PersistencyServiceException {
        AssetRestrictionFeature assetRestrictionFeature = assetPolicyPersistencyService
            .getAssetRestrictionFeatureByCode(RESTRICT_BY_CLASS_FCODE);
        assertThat(assetRestrictionFeature).isNotNull();

        List<AssetUserPolicyEntity> entities = new ArrayList<>();
        String filterCriteria = "/assetTypes/" + getRandomId();
        entities.add(createAssetUserPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria));

        IntStream.range(1, 3).forEach(index -> {
            String filterCriteria1 = "/assetTypes/" + getRandomId();
            entities.add(
                createAssetUserGroupPolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria1));
        });

        IntStream.range(1, 3).forEach(index -> {
            String filterCriteria2 = "/assetTypes/" + getRandomId();
            entities.add(
                createAssetUserGroup1PolicyEntity(assetRestrictionFeature, ASSET_TYPE, filterCriteria2));
        });

        int numOfRecCreated = assetPolicyPersistencyService.createUserPolicies(TestUtils.TEST_TENANT,
            Collections.unmodifiableList(entities));
        assertThat(numOfRecCreated).isEqualTo(5);

        List<AssetUserPolicy> userPolicies = assetPolicyPersistencyService.getAssetUserPolicies(TestUtils.TEST_TENANT,
            assetRestrictionFeature.getId());

        assertThat(userPolicies.size()).isEqualTo(5);

        List<String> policyIds = userPolicies.stream().map(AssetUserPolicy::getSubjectId).collect(Collectors.toList());

        List<AssetUserPolicy> policies = assetPolicyPersistencyService.getAssetUserPoliciesBySubjects(
            TestUtils.TEST_TENANT, policyIds);

        assertThat(policies).isNotNull();
        assertThat(policies).size().isEqualTo(5);

        assetPolicyPersistencyService.deleteAllAssetUserPolicy(TestUtils.TEST_TENANT);
    }


    @Test
    public void testConvertErrorMessage() throws Exception {
        String errorMsg = "ERROR: duplicate key value violates unique constraint \"asset_policy_sub_id_type_feat\""
            + "Detail: Key (subject_id, subject_type, feature_id, filter_criteria, TestUtils.TEST_TENANT)"
            + "=(35421a16-ff72-4758-9198-dde07a6d4836, User, ab26d229-8281-7411-c2aa-5b4cf7e7dfa5,"
            + "/assetTypes/b230f7bb-e64e-4397-896a-2b7b90ccf812, ed7b023a-5ed2-4f15-8e28-4393e70a09e7) already exists.";

        AssetPolicyPersistencyServiceImpl assetUserPolicySvc = new AssetPolicyPersistencyServiceImpl();
        Method method = assetUserPolicySvc.getClass().getDeclaredMethod("convertErrorMsg", String.class);
        method.setAccessible(true);
        String convertedMsg = (String) method.invoke(assetUserPolicySvc, errorMsg);
        assertThat(convertedMsg).isNotNull();
        assertThat(convertedMsg).isEqualTo("subject_id=35421a16-ff72-4758-9198-dde07a6d4836, " + "subject_type=User, "
            + "feature_id=ab26d229-8281-7411-c2aa-5b4cf7e7dfa5, "
            + "filter_criteria=/assetTypes/b230f7bb-e64e-4397-896a-2b7b90ccf812, "
            + "TestUtils.TEST_TENANT=ed7b023a-5ed2-4f15-8e28-4393e70a09e7");
    }

    @Test
    public void testConvertReservedAttrErrorMessage() throws Exception {
        String errorMsg = "ERROR: duplicate key value violates unique constraint \"asset_policy_sub_id_type_feat\""
            + "Detail: Key (subject_id, subject_type, feature_id, filter_criteria, TestUtils.TEST_TENANT)"
            + "=(35421a16-ff72-4758-9198-dde07a6d4836, User, ab26d229-8281-7411-c2aa-5b4cf7e7dfa5,"
            + "\"reservedAttribute.state.key=10\", ed7b023a-5ed2-4f15-8e28-4393e70a09e7) already exists.";

        AssetPolicyPersistencyServiceImpl assetUserPolicySvc = new AssetPolicyPersistencyServiceImpl();
        Method method = assetUserPolicySvc.getClass().getDeclaredMethod("convertErrorMsg", String.class);
        method.setAccessible(true);
        String convertedMsg = (String) method.invoke(assetUserPolicySvc, errorMsg);
        assertThat(convertedMsg).isNotNull();
        assertThat(convertedMsg).isEqualTo("subject_id=35421a16-ff72-4758-9198-dde07a6d4836, " + "subject_type=User, "
            + "feature_id=ab26d229-8281-7411-c2aa-5b4cf7e7dfa5, "
            + "filter_criteria=\"reservedAttribute.state.key=10\", "
            + "TestUtils.TEST_TENANT=ed7b023a-5ed2-4f15-8e28-4393e70a09e7");
    }

    @Test
    public void testConvertInvalidErrorMessage() throws Exception {
        String errorMsg = "ERROR: null value in column \"filter_criteria\" violates not-null constraint"
            + "Detail: Failing row contains";
        AssetPolicyPersistencyServiceImpl assetUserPolicySvc = new AssetPolicyPersistencyServiceImpl();
        Method method = assetUserPolicySvc.getClass().getDeclaredMethod("convertErrorMsg", String.class);
        method.setAccessible(true);
        String convertedMsg = (String) method.invoke(assetUserPolicySvc, errorMsg);
        assertThat(convertedMsg).isNotNull();
        assertThat(convertedMsg).isEqualTo(errorMsg);
    }

    private AssetUserPolicyEntity createAssetUserPolicyEntity(AssetRestrictionFeature assetFeature, String superType,
        String filterCriteria) {
        AssetUserPolicyEntity assetUserPolicyEntity = new AssetUserPolicyEntity();

        assetUserPolicyEntity.setFeatureId(assetFeature.getId());
        assetUserPolicyEntity.setFeatureCode(assetFeature.getFeatureCode());
        assetUserPolicyEntity.setSubjectId(USER_ID);
        assetUserPolicyEntity.setSubjectType(AssetUserPolicy.SubjectType.USER.getType());
        assetUserPolicyEntity.setUserName(USER_NAME);
        assetUserPolicyEntity.setDisplayName(DISPLAY_NAME);
        assetUserPolicyEntity.setSuperType(superType);
        if (!StringUtils.isEmpty(filterCriteria)) {
            assetUserPolicyEntity.setFilterCriteria(filterCriteria);
        }
        return assetUserPolicyEntity;
    }

    private AssetUserPolicyEntity createAssetUserGroupPolicyEntity(AssetRestrictionFeature assetFeature,
        String superType, String filterCriteria) {
        AssetUserPolicyEntity assetUserPolicyEntity = new AssetUserPolicyEntity();

        assetUserPolicyEntity.setFeatureId(assetFeature.getId());
        assetUserPolicyEntity.setFeatureCode(assetFeature.getFeatureCode());
        assetUserPolicyEntity.setSubjectId(USER_GROUP_ID);
        assetUserPolicyEntity.setSubjectType(AssetUserPolicy.SubjectType.USER_GROUP.getType());
        assetUserPolicyEntity.setDisplayName(UG_DISPLAY_NAME);
        assetUserPolicyEntity.setSuperType(superType);
        if (!StringUtils.isEmpty(filterCriteria)) {
            assetUserPolicyEntity.setFilterCriteria(filterCriteria);
        }
        return assetUserPolicyEntity;
    }

    private AssetUserPolicyEntity createAssetUserGroup1PolicyEntity(AssetRestrictionFeature assetFeature,
        String superType, String filterCriteria) {
        AssetUserPolicyEntity assetUserPolicyEntity = new AssetUserPolicyEntity();

        assetUserPolicyEntity.setFeatureId(assetFeature.getId());
        assetUserPolicyEntity.setFeatureCode(assetFeature.getFeatureCode());
        assetUserPolicyEntity.setSubjectId(USER_GROUP_ID_1);
        assetUserPolicyEntity.setSubjectType(AssetUserPolicy.SubjectType.USER_GROUP.getType());
        assetUserPolicyEntity.setDisplayName(UG_DISPLAY_NAME + "_1");
        assetUserPolicyEntity.setSuperType(superType);
        if (!StringUtils.isEmpty(filterCriteria)) {
            assetUserPolicyEntity.setFilterCriteria(filterCriteria);
        }
        return assetUserPolicyEntity;
    }

    private String getRandomId() {
        return UUID.randomUUID().toString();
    }
}
