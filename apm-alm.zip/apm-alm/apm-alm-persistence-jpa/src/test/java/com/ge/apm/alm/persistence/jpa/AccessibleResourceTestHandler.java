/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import org.springframework.test.context.TestContext;
import org.springframework.test.context.support.AbstractTestExecutionListener;

import com.ge.apm.alm.persistence.jpa.utils.TestUtils;
import com.ge.apm.common.support.RequestContext;

/**
 *
 * @author Shu W. Yu 212614203
 * @version 1.0 Apr 25, 2018
 * @since 1.0
 */
public class AccessibleResourceTestHandler extends AbstractTestExecutionListener {

    public static final String ACCESSIBLE_RESOURCES = "AccessibleResources";
    public static final String[] ALL_RESOURCES = { "*" };

    /**
     * The default implementation is <em>empty</em>. Can be overridden by
     * subclasses as necessary.
     */
    @Override
    public void beforeTestMethod(TestContext testContext) {
        RequestContext.destroy();
        RequestContext.put(RequestContext.TENANT_UUID, TestUtils.TEST_TENANT);
        RequestContext.put(ACCESSIBLE_RESOURCES, ALL_RESOURCES);
    }

    /**
     * The default implementation is <em>empty</em>. Can be overridden by
     * subclasses as necessary.
     */
    @Override
    public void afterTestMethod(TestContext testContext) {
        RequestContext.destroy();
    }

}
