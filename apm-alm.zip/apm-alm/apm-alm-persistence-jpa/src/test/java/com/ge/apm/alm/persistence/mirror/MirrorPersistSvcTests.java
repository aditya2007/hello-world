/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.mirror;

import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetEventEntity;
import com.ge.apm.alm.persistence.jpa.repository.AssetEventRepository;

@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public abstract class MirrorPersistSvcTests {

    @Autowired
    protected AssetEventRepository eventRepo;

    void assertEventsContain(String... objectDetails) {

        if (objectDetails.length % 3 != 0) {
            Assert.fail("You must specify object details in pairs of object type and object ID.");
        }

        List<AssetEventEntity> events = eventRepo.findAll();
        HashSet<String> eventsTypeId = events.stream().map(e ->
            new String(e.getEventType().name() + "|" + e.getObjectType() + "|" + e.getObjectId()))
            .collect(Collectors.toCollection(HashSet::new));

        for (int i = 0; i < objectDetails.length; i += 3) {
            String eventType = objectDetails[i];
            String objectType = objectDetails[i + 1];
            String objectId = objectDetails[i + 2];

            Assert.assertTrue(eventsTypeId.contains(eventType + "|" + objectType + "|" + objectId));
        }
    }
}
