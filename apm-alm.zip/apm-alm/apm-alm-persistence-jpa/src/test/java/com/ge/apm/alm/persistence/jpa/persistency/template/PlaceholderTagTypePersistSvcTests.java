/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.template;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.PlaceholderTagType;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholder;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderTagType;
import com.ge.apm.alm.persistence.jpa.model.TestTemplate;
import com.ge.apm.alm.persistence.jpa.utils.TestTemplateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */
public class PlaceholderTagTypePersistSvcTests extends TemplatePersistSvcBaseTests {

    private static final String SUPPER_TYPE_ID = "203d4660-702c-3cc9-8399-5663b9378408";
    private static final String TAG_TYPE_NAME = "GE90";

    @Test
    @Transactional
    public void testCreatePlaceholderTagType() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType = createTestPlaceholderTagType(testPlaceholder, assetType);

        // make sure that retrieve Placeholder, PlaceholderType also returned.
        Placeholder dbPlaceholder = placeholderPersistencyService
            .getPlaceholderById(TestUtils.TEST_TENANT, testPlaceholder.getId());
        assertThat(dbPlaceholder).isNotNull();
        assertThat(dbPlaceholder.getId()).isEqualTo(testPlaceholder.getId());
        assertThat(dbPlaceholder.getPlaceholderTagTypes().get(0).getId()).isEqualTo(testPlaceholderTagType.getId());
        assertThat(dbPlaceholder.getPlaceholderTagTypes().get(0).getTagTypeId())
            .isEqualTo(testPlaceholderTagType.getTagTypeId());
        assertThat(dbPlaceholder.getPlaceholderTagTypes().get(0).getExpressions()).isNotNull();
        assertThat(dbPlaceholder.getPlaceholderTagTypes().get(0).getExpressions()).isEqualTo(testPlaceholderTagType
            .getExpressions());

        // delete template cascade
        List<TestPlaceholderTagType> testPlaceholderTagTypes = new ArrayList<>();
        testPlaceholderTagTypes.add(testPlaceholderTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderType_missingId() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderTagType testPlaceholderTagType = TestTemplateUtils.buildPlaceholderTagType(uuid, uuid);
        testPlaceholderTagType.setId(null);
        placeholderTagTypePersistencyService.createPlaceholderTagType(TestUtils.TEST_TENANT, testPlaceholderTagType);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderTagType_missingPlaceholderId() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderTagType testPlaceholderTagType = TestTemplateUtils.buildPlaceholderTagType(uuid, uuid);
        testPlaceholderTagType.setPlaceholderId(null);
        placeholderTagTypePersistencyService.createPlaceholderTagType(TestUtils.TEST_TENANT, testPlaceholderTagType);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderTagType_missingTagTypeId() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderTagType testPlaceholderTagType = TestTemplateUtils.buildPlaceholderTagType(uuid, uuid);
        testPlaceholderTagType.setTagTypeId(null);
        placeholderTagTypePersistencyService.createPlaceholderTagType(TestUtils.TEST_TENANT, testPlaceholderTagType);
    }


    @Test
    @Transactional
    public void testCreatePlaceholderTagTypes() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType1 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        AssetType assetType2 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);

        List<PlaceholderTagType> placeholderTagTypes = new ArrayList<>();
        final String placeholderId = testPlaceholder.getId();
        placeholderTagTypes.add(TestTemplateUtils.buildPlaceholderTagType(placeholderId, assetType1.getId()));
        placeholderTagTypes.add(TestTemplateUtils.buildPlaceholderTagType(placeholderId, assetType2.getId()));

        final String tenantId = TestUtils.TEST_TENANT;
        int counter = placeholderTagTypePersistencyService.createPlaceholderTagTypes(tenantId, new ArrayList<>());
        assertThat(counter).isEqualTo(0);

        counter = placeholderTagTypePersistencyService.createPlaceholderTagTypes(tenantId, placeholderTagTypes);
        assertThat(counter).isEqualTo(placeholderTagTypes.size());

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTagTypes(Collections.unmodifiableList(placeholderTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testUpdatePlaceholderTagType() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType = createTestPlaceholderTagType(testPlaceholder, assetType);

        PlaceholderTagType savedPlaceholderTagType = placeholderTagTypePersistencyService
            .updatePlaceholderTagType(TestUtils.TEST_TENANT, testPlaceholderTagType);
        assertThat(savedPlaceholderTagType).isNotNull();
        assertThat(savedPlaceholderTagType.getId()).isEqualTo(testPlaceholderTagType.getId());

        // delete template cascade
        List<TestPlaceholderTagType> testPlaceholderTagTypes = new ArrayList<>();
        testPlaceholderTagTypes.add(testPlaceholderTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testUpdatePlaceholderTypes() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType1 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        AssetType assetType2 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);

        List<PlaceholderTagType> placeholderTagTypes = new ArrayList<>();
        final String placeholderId = testPlaceholder.getId();
        placeholderTagTypes.add(TestTemplateUtils.buildPlaceholderTagType(placeholderId, assetType1.getId()));
        placeholderTagTypes.add(TestTemplateUtils.buildPlaceholderTagType(placeholderId, assetType2.getId()));

        final String tenantId = TestUtils.TEST_TENANT;
        int counter = placeholderTagTypePersistencyService.updatePlaceholderTagTypes(tenantId, new ArrayList<>());
        assertThat(counter).isEqualTo(0);

        counter = placeholderTagTypePersistencyService.createPlaceholderTagTypes(tenantId, placeholderTagTypes);
        assertThat(counter).isEqualTo(2);

        AssetType assetType3 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        placeholderTagTypes.add(TestTemplateUtils.buildPlaceholderTagType(placeholderId, assetType3.getId()));
        counter = placeholderTagTypePersistencyService.updatePlaceholderTagTypes(tenantId, placeholderTagTypes);
        assertThat(counter).isEqualTo(3);

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTagTypes(Collections.unmodifiableList(placeholderTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testDeletePlaceholderTagType_Id() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType = createTestPlaceholderTagType(testPlaceholder, assetType);

        int counter = placeholderTagTypePersistencyService
            .deletePlaceholderTagTypeById(TestUtils.TEST_TENANT, testPlaceholderTagType.getId());
        assertThat(counter).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholderTagType> testPlaceholderTagTypes = new ArrayList<>();
        testPlaceholderTagTypes.add(testPlaceholderTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeletePlaceholderTagType_Id_NotFoundException() throws PersistencyServiceException {
        placeholderTagTypePersistencyService.deletePlaceholderTagTypeById(TestUtils.TEST_TENANT,
            TestTemplateUtils.getNewUuid());
    }


    @Test
    @Transactional
    public void testDeletePlaceholderTagType_placeholderId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType = createTestPlaceholderTagType(testPlaceholder, assetType);

        int counter = placeholderTagTypePersistencyService
            .deletePlaceholderTagTypeByPlaceholderId(TestUtils.TEST_TENANT, testPlaceholderTagType.getPlaceholderId());
        assertThat(counter).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholderTagType> testPlaceholderTagTypes = new ArrayList<>();
        testPlaceholderTagTypes.add(testPlaceholderTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeletePlaceholderTagType_placeholderId_NotFoundException() throws PersistencyServiceException {
        placeholderTagTypePersistencyService.deletePlaceholderTagTypeByPlaceholderId(TestUtils.TEST_TENANT,
            TestTemplateUtils.getNewUuid());
    }

    @Test
    @Transactional
    public void testDeletePlaceholderTagTypeByPlaceholderIdAndTagTypeId()
        throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType = createTestPlaceholderTagType(testPlaceholder, assetType);

        int counter = placeholderTagTypePersistencyService
            .deletePlaceholderTagTypeByPlaceholderIdAndTagTypeId(TestUtils.TEST_TENANT,
                testPlaceholderTagType.getPlaceholderId(),
                testPlaceholderTagType.getTagTypeId());
        assertThat(counter).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholderTagType> testPlaceholderTagTypes = new ArrayList<>();
        testPlaceholderTagTypes.add(testPlaceholderTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = ObjectNotFoundException.class)
    public void testDeletePlaceholderTagTypeByPlaceholderIdAndTypeId_NotFoundException()
        throws PersistencyServiceException {
        String uuid = TestTemplateUtils.getNewUuid();
        placeholderTagTypePersistencyService.deletePlaceholderTagTypeByPlaceholderIdAndTagTypeId(TestUtils.TEST_TENANT,
            uuid, uuid);
    }

    @Test
    @Transactional
    public void testGetPlaceholderTagTypeById() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType = createTestPlaceholderTagType(testPlaceholder, assetType);

        PlaceholderTagType dbPlaceholderTagType = placeholderTagTypePersistencyService
            .getPlaceholderTagTypeById(TestUtils.TEST_TENANT, testPlaceholderTagType.getId());
        assertThat(dbPlaceholderTagType).isNotNull();
        assertThat(dbPlaceholderTagType.getId()).isEqualTo(testPlaceholderTagType.getId());

        // delete template cascade
        List<TestPlaceholderTagType> testPlaceholderTagTypes = new ArrayList<>();
        testPlaceholderTagTypes.add(testPlaceholderTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    public void testGetPlaceholderTagTypeById_EmptyResultDataAccessException() {
        assertThat(placeholderTagTypePersistencyService
            .getPlaceholderTagTypeById(TestUtils.TEST_TENANT, TestTemplateUtils.getNewUuid())).isNull();
    }

    @Test
    @Transactional
    public void testGetPlaceholderTagTypeByPlaceholderIdAndTypeId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType = createTestPlaceholderTagType(testPlaceholder, assetType);

        PlaceholderTagType dbPlaceholderTagType = placeholderTagTypePersistencyService
            .getPlaceholderTagTypeByPlaceholderIdAndTagTypeId(TestUtils.TEST_TENANT,
                testPlaceholderTagType.getPlaceholderId(),
                testPlaceholderTagType.getTagTypeId());
        assertThat(dbPlaceholderTagType).isNotNull();
        assertThat(dbPlaceholderTagType.getId()).isEqualTo(testPlaceholderTagType.getId());

        // delete template cascade
        List<TestPlaceholderTagType> testPlaceholderTagTypes = new ArrayList<>();
        testPlaceholderTagTypes.add(testPlaceholderTagType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    public void testGetPlaceholderTagTypeByPlaceholderIdAndTypeId_EmptyResultDataAccessException() {
        String uuid = TestTemplateUtils.getNewUuid();
        assertThat(placeholderTagTypePersistencyService
            .getPlaceholderTagTypeByPlaceholderIdAndTagTypeId(TestUtils.TEST_TENANT, uuid, uuid)).isNull();
    }

    @Test
    @Transactional
    public void testGetPlaceholderTagTypes_placeholderId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType1 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType1 = createTestPlaceholderTagType(testPlaceholder1, assetType1);

        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN02");
        AssetType assetType2 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType2 = createTestPlaceholderTagType(testPlaceholder2, assetType2);

        final String tenantId = TestUtils.TEST_TENANT;
        assertThat(placeholderTagTypePersistencyService.getPlaceholderTagTypeByPlaceholderIds(tenantId,
            new ArrayList<>())).isEmpty();

        List<PlaceholderTagType> foundPlaceholderTagTypes = placeholderTagTypePersistencyService
            .getPlaceholderTagTypeByPlaceholderId(tenantId, testPlaceholder1.getId());
        assertThat(foundPlaceholderTagTypes.size()).isEqualTo(1);
        assertThat(foundPlaceholderTagTypes.get(0).getId()).isEqualTo(testPlaceholderTagType1.getId());

        // delete template cascade
        List<TestPlaceholderTagType> testPlaceholderTagTypes1 = new ArrayList<>();
        List<TestPlaceholderTagType> testPlaceholderTagTypes2 = new ArrayList<>();
        testPlaceholderTagTypes1.add(testPlaceholderTagType1);
        testPlaceholderTagTypes2.add(testPlaceholderTagType2);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes1));
        testPlaceholder2.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes2));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);

        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testGetPlaceholderTypes_placeholderIdAndStatus() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType1 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType1 = createTestPlaceholderTagType(testPlaceholder1, assetType1);

        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN02");
        AssetType assetType2 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType2 = createTestPlaceholderTagType(testPlaceholder2, assetType2);

        List<PlaceholderTagType> foundPlaceholders = placeholderTagTypePersistencyService
            .getPlaceholderTagTypeByPlaceholderId(TestUtils.TEST_TENANT, testPlaceholderTagType1.getPlaceholderId());
        assertThat(foundPlaceholders.size()).isEqualTo(1);
        assertThat(foundPlaceholders.get(0).getId()).isEqualTo(testPlaceholderTagType1.getId());

        // delete template cascade
        List<TestPlaceholderTagType> testPlaceholderTagTypes1 = new ArrayList<>();
        List<TestPlaceholderTagType> testPlaceholderTagTypes2 = new ArrayList<>();
        testPlaceholderTagTypes1.add(testPlaceholderTagType1);
        testPlaceholderTagTypes2.add(testPlaceholderTagType2);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes1));
        testPlaceholder2.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes2));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);

        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testGetPlaceholderTagTypes_placeholderIds() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType1 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType1 = createTestPlaceholderTagType(testPlaceholder1, assetType1);

        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN02");
        AssetType assetType2 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType2 = createTestPlaceholderTagType(testPlaceholder2, assetType2);

        List<String> placeholderIds = new ArrayList<>();
        placeholderIds.add(testPlaceholder1.getId());
        placeholderIds.add(testPlaceholder2.getId());

        List<PlaceholderTagType> foundPlaceholders = placeholderTagTypePersistencyService
            .getPlaceholderTagTypeByPlaceholderIds(TestUtils.TEST_TENANT, placeholderIds);
        assertThat(foundPlaceholders.size()).isEqualTo(2);
        assertThat(foundPlaceholders.get(0).getId()).isEqualTo(testPlaceholderTagType1.getId());

        // make sure that retrieve Placeholder, PlaceholderTagType also returned.
        Template dbTemplate = templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, testTemplate.getId());
        assertThat(dbTemplate).isNotNull();
        assertThat(dbTemplate.getPlaceholders().size()).isEqualTo(2);
        assertThat(dbTemplate.getPlaceholders().get(0).getPlaceholderTagTypes().size()).isEqualTo(1);
        assertThat(dbTemplate.getPlaceholders().get(1).getPlaceholderTagTypes().size()).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholderTagType> testPlaceholderTagTypes1 = new ArrayList<>();
        List<TestPlaceholderTagType> testPlaceholderTagTypes2 = new ArrayList<>();
        testPlaceholderTagTypes1.add(testPlaceholderTagType1);
        testPlaceholderTagTypes2.add(testPlaceholderTagType2);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes1));
        testPlaceholder2.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes2));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);

        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);

    }

    @Test
    @Transactional
    public void testGetPlaceholderTagTypeByTemplateId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", "TYPE_XXX", 10L);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN10");
        AssetType assetType1 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType1 = createTestPlaceholderTagType(testPlaceholder1, assetType1);

        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN11");
        AssetType assetType2 = createAssetType(SUPPER_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType2 = createTestPlaceholderTagType(testPlaceholder2, assetType2);

        List<PlaceholderTagType> foundPlaceholders = placeholderTagTypePersistencyService
            .getPlaceholderTagTypeByTemplateId(TestUtils.TEST_TENANT, testTemplate.getId());
        assertThat(foundPlaceholders.size()).isEqualTo(2);
        assertThat(foundPlaceholders.get(0).getId()).isEqualTo(testPlaceholderTagType1.getId());

        // delete template cascade
        List<TestPlaceholderTagType> testPlaceholderTagTypes1 = new ArrayList<>();
        List<TestPlaceholderTagType> testPlaceholderTagTypes2 = new ArrayList<>();
        testPlaceholderTagTypes1.add(testPlaceholderTagType1);
        testPlaceholderTagTypes2.add(testPlaceholderTagType2);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes1));
        testPlaceholder2.setPlaceholderTagTypes(Collections.unmodifiableList(testPlaceholderTagTypes2));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);

        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);

    }

    private void deleteTestTemplateCascade(TestTemplate testTemplate) throws PersistencyServiceException {
        String templateId = testTemplate.getId();
        final String tenantId = TestUtils.TEST_TENANT;
        templatePersistencyService.deleteTemplateById(tenantId, templateId);
        assertThat(templatePersistencyService.getTemplateById(tenantId, templateId)).isNull();

        List<Placeholder> placeholders = testTemplate.getPlaceholders();
        for (Placeholder placeholder : placeholders) {
            assertThat(placeholderPersistencyService.getPlaceholderById(tenantId, placeholder.getId()))
                .isNull();

            List<PlaceholderTagType> placeholderTagTypes = placeholder.getPlaceholderTagTypes();
            if (!CollectionUtils.isEmpty(placeholderTagTypes)) {
                placeholderTagTypes.forEach(placeholderTagType -> assertThat(placeholderTagTypePersistencyService.getPlaceholderTagTypeById(tenantId,
                    placeholderTagType.getId())).isNull());

            }
        }
    }
}

