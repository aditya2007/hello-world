/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.tag;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_TAG_TYPE_ID;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUber;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUnPrivileged;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Fail.failBecauseExceptionWasNotThrown;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.Sets;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.IncompatibleItemsException;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceEntity;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroupItem;
import com.ge.apm.alm.persistence.jpa.model.TestTag;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.utils.TagPredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

/**
 * Tests the JPA Persistency Layer
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TagPersistSvcTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private TagPersistencyService tagPersistencyService;

    @Autowired
    private GroupPersistencyService groupPersistencyService;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    @After
    public void tearDown() {
        TestUtils.destroyAssetUserPolicies();
    }

    @Test
    @Transactional
    public void getTagById() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);

        // query for single tag, with 4 ACL use cases
        assertThat(tagPersistencyService.getTagById(tag.getTenantId(), getUber(), tag.getId())).extracting(
            Tag::getId).containsOnly(tag.getId());
        Tag retrieved = tagPersistencyService.getTagById(tag.getTenantId(), getUnPrivileged(tag.getAssetId()),
            tag.getId());
        assertThat(retrieved.getId()).isEqualTo(tag.getId());

        //Asserting that the Super Types are properly Denormalized
        assertThat(retrieved.getSuperTypesArray()).hasSize(2).containsOnly(ROOT_TAG_TYPE_ID,
            types.get("MyTagType").getId());

        assertThat(tagPersistencyService
            .getTagById(tag.getTenantId(), getUnPrivileged(assets.get("E1_S1")), tag.getId()))
            .extracting(Tag::getId).hasSize(1).containsOnly(tag.getId());
        assertThat(tagPersistencyService
            .getTagById(tag.getTenantId(), getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                tag.getId())).extracting(Tag::getId).hasSize(1).containsOnly(tag.getId());
        assertThat(tagPersistencyService.getTagById(tag.getTenantId(), getUnPrivileged(), tag.getId()))
            .isNull();
    }

    @Test
    @Transactional
    public void getTags_WithPageSize() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        TagPredicateUtils.createTagDataForAsset(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), 500);

        TagPredicateUtils.createTagDataForAsset(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset2"), 500);

        TagPredicate predicate = TagPredicate.builder().sourceKey("*Tag*").build();
        List<Tag> allTags = tagPersistencyService.getTags(TestUtils.TEST_TENANT, getUber(), predicate);
        assertThat(allTags).hasSize(1000);

        List<String> allTagIds = allTags.stream().map(Tag::getId).collect(Collectors.toList());

        IntStream.range(0, 500).forEach(i -> {
            predicate.setPageSize(2);
            predicate.setOffset(i * 2);
            List<Tag> tagsOfAsset = tagPersistencyService.getTags(TestUtils.TEST_TENANT, getUber(),
                predicate);
            List<String> tagIds = tagsOfAsset.stream().map(Tag::getId).collect(Collectors.toList());
            allTagIds.removeAll(tagIds);
        });

        assertThat(allTagIds).hasSize(0);
    }

    @Test
    @Transactional
    public void getTagsByIdForUpdate() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);
        Tag tag2 = tags.get(1);
        // query for single tag, with 4 ACL use cases
        assertThat(tagPersistencyService
            .getTagsByIdsForUpdate(tag.getTenantId(), getUber(), Arrays.asList(tag.getId()))).extracting(
            Tag::getId).containsOnly(tag.getId());
        List<Tag> retrieved = tagPersistencyService.getTagsByIdsForUpdate(tag.getTenantId(),
            Collections.singletonList(tag.getAssetId()), Arrays.asList(tag.getId()));

        assertThat(retrieved).extracting(Tag::getId).containsOnly(tag.getId());

        //Asserting that the Super Types are properly Denormalized
        for (Tag tagT : retrieved) {
            assertThat(tagT.getSuperTypesArray()).hasSize(2).containsOnly(ROOT_TAG_TYPE_ID,
                types.get("MyTagType").getId());
        }

        assertThat(tagPersistencyService
            .getTagsByIdsForUpdate(tag.getTenantId(), getUnPrivileged(assets.get("E1_S1")),
                Arrays.asList(tag.getId()))).extracting(Tag::getId).hasSize(1).containsOnly(tag.getId());
        assertThat(tagPersistencyService.getTagsByIdsForUpdate(tag.getTenantId(),
            getUnPrivileged(assets.get("E1"), assets.get("E1_S1")), Arrays.asList(tag.getId())))
            .extracting(Tag::getId).hasSize(1).containsOnly(tag.getId());
        assertThat(tagPersistencyService
            .getTagsByIdsForUpdate(tag.getTenantId(), getUnPrivileged(), Arrays.asList(tag.getId())))
            .isEmpty();

        assertThat(tagPersistencyService
            .getTagsByIdsForUpdate(tag.getTenantId(), getUnPrivileged(assets.get("E1_S1")),
                Arrays.asList(tag.getId(), tag2.getId()))).extracting(Tag::getId).hasSize(2).containsOnly(tag.getId(),
            tag2.getId());
        assertThat(tagPersistencyService.getTagsByIdsForUpdate(tag.getTenantId(),
            getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
            Arrays.asList(tag.getId(), tag2.getId()))).extracting(Tag::getId).hasSize(2).containsOnly(tag.getId(),
            tag2.getId());
        assertThat(tagPersistencyService.getTagsByIdsForUpdate(tag.getTenantId(), getUnPrivileged(),
            Arrays.asList(tag.getId(), tag2.getId()))).isEmpty();
    }

    @Test
    @Transactional
    public void getTagBySourceKey_emptyKey() {
        assertThat(tagPersistencyService.getTagBySourceKey(TestUtils.TEST_TENANT, getUber(), null)).isNull();
        assertThat(tagPersistencyService.getTagBySourceKey(TestUtils.TEST_TENANT, getUber(), "")).isNull();
    }

    @Test
    @Transactional
    public void getTagBySourceKey() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);

        // get by source key
        assertThat(tagPersistencyService.getTagBySourceKey(tag.getTenantId(), getUber(), tag.getSourceKey()))
            .extracting(Tag::getId).containsOnly(tag.getId());
        assertThat(tagPersistencyService
            .getTagBySourceKey(tag.getTenantId(), getUnPrivileged(tag.getAssetId()), tag.getSourceKey()))
            .extracting(Tag::getSourceKey).containsOnly(tag.getSourceKey());
        assertThat(tagPersistencyService
            .getTagBySourceKey(tag.getTenantId(), getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                tag.getSourceKey())).extracting(Tag::getSourceKey).containsOnly(tag.getSourceKey());
        assertThat(
            tagPersistencyService.getTagBySourceKey(tag.getTenantId(), getUnPrivileged(), tag.getSourceKey()))
            .isNull();
    }

    @Test
    @Transactional
    public void getTagBySourceKeys_emptyKeys() {
        assertThat(tagPersistencyService
            .getTagsBySourceKeys(TestUtils.TEST_TENANT, getUber(), Collections.emptyList())).hasSize(0);
    }

    @Test
    @Transactional
    public void getTagsBySourceKeys() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        String tenantId = tags.get(0).getTenantId();

        List<String> listOfSourceKeys = tags.stream().map(Tag::getSourceKey).collect(Collectors.toList());
        String[] sourceKeys = listOfSourceKeys.toArray(new String[listOfSourceKeys.size()]);
        // get by source keys
        assertThat(tagPersistencyService.getTagsBySourceKeys(tenantId, getUber(), listOfSourceKeys)).hasSize(
            tags.size()).extracting(Tag::getSourceKey).containsOnly(sourceKeys);
        assertThat(tagPersistencyService
            .getTagsBySourceKeys(tenantId, getUnPrivileged(tags.get(0).getAssetId()), listOfSourceKeys))
            .hasSize(tags.size()).extracting(Tag::getSourceKey).containsOnly(sourceKeys);
        assertThat(tagPersistencyService
            .getTagsBySourceKeys(tenantId, getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                listOfSourceKeys)).hasSize(tags.size()).extracting(Tag::getSourceKey).containsOnly(sourceKeys);
        assertThat(tagPersistencyService.getTagsBySourceKeys(tenantId, getUnPrivileged(), listOfSourceKeys))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getCorrelatedTagsById() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        int count = 5;
        List<Tag> tags = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String tagName1 = "E1_S1_Seg1_Asset2-" + i;
            tags.add(TagPredicateUtils.newTag(types.get("MyTagType").getId(), asset2.getId(), tagName1));
        }

        assertThat(tagPersistencyService.createTags(TestUtils.TEST_TENANT, getUber(), tags)).isEqualTo(count);
        AssetGroup assetGroup = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(
            UUID.randomUUID().toString()).category(AssetGroupCategory.TAG_CORRELATION).build();
        AssetGroup createdGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            Tag tag = tags.get(i);
            items.add(TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).groupId(createdGroup.getId())
                .objectId(tag.getId()).tenantId(TestUtils.TEST_TENANT).position(i + 1).build());
        }
        Collections.reverse(items);
        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUber(), createdGroup.getId(), items)).isEqualTo(
            items.size());

        List<Tag> retrieved = tagPersistencyService.getCorrelatedTagsById(TestUtils.TEST_TENANT, getUber(),
            tags.get(1).getId());
        assertThat(retrieved.size()).isEqualTo(count);
        for (int i = 0; i < count; i++) {
            assertThat(retrieved.get(i).getId()).isEqualTo(tags.get(i).getId());
        }
        retrieved = tagPersistencyService.getCorrelatedTagsById(TestUtils.TEST_TENANT,
            getUnPrivileged(assets.get("E1_S1_Seg1"), assets.get("E1_S1")), tags.get(1).getId());
        assertThat(retrieved.size()).isEqualTo(count);
        for (int i = 0; i < count; i++) {
            assertThat(retrieved.get(i).getId()).isEqualTo(tags.get(i).getId());
        }

        try {
            tagPersistencyService.createTags(TestUtils.TEST_TENANT, getUnPrivileged(), tags);
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (PersistencyServiceException e) {
            assertThat(e).isInstanceOf(ObjectNotFoundException.class);
        }
    }

    @Test
    @Transactional
    public void getTags_Decommissioned() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag1 = tags.get(2);
        Tag tag2 = tags.get(3);
        Tag tag3 = tags.get(4);
        Asset asset = assets.get("E1_S1_Seg1_Asset1");
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");
        ((ObjectNode) asset.getAttributes().path("reservedAttributes").path("state")).put("key", "03");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, getUber(), asset);
        ((ObjectNode) asset2.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, getUber(), asset2);

        TestUtils.createAssetUserPolicies(assetPolicyPersistencyService, TestUtils.VIEW_DECOMM_FCODE,
            SeedOOTBData.ROOT_ASSET_TYPE_ID);

        assertThat(tagPersistencyService
            .getTagById(tag1.getTenantId(), getUnPrivileged(assets.get("E1_S1")), tag1.getId()))
            .extracting(Tag::getId).hasSize(1).containsOnly(tag1.getId());
        assertThat(tagPersistencyService.getTagById(tag2.getTenantId(), getUnPrivileged(assets.get("E1")),
            tag2.getId())).extracting(Tag::getId).hasSize(1).containsOnly(tag2.getId());
        assertThat(tagPersistencyService
            .getTagById(tag3.getTenantId(), Collections.singletonList(assets.get("E1_S1").getId()), tag3.getId()))
            .extracting(Tag::getId).hasSize(1).containsOnly(tag3.getId());
        assertThat(
            tagPersistencyService.getTagBySourceKey(tag3.getTenantId(), getUnPrivileged(assets.get("E1")),
                tag3.getSourceKey())).extracting(Tag::getId).containsOnly(tag3.getId());
        assertThat(tagPersistencyService.getTagsBySourceKeys(TestUtils.TEST_TENANT, getUnPrivileged(assets.get("E1")),
            Arrays.asList(tag1.getSourceKey(), tag2.getSourceKey(), tag3.getSourceKey()))).hasSize(3).extracting(
            Tag::getSourceKey).containsOnly(tag1.getSourceKey(), tag2.getSourceKey(), tag3.getSourceKey());

        TestUtils.destroyAssetUserPolicies();

        assertThat(tagPersistencyService
            .getTagById(tag1.getTenantId(), Collections.singletonList(assets.get("E1_S1").getId()), tag1.getId()))
            .extracting(Tag::getId).hasSize(1).containsOnly(tag1.getId());
        assertThat(tagPersistencyService.getTagById(tag2.getTenantId(), getUnPrivileged(assets.get("E1")),
            tag2.getId())).extracting(Tag::getId).hasSize(1).containsOnly(tag2.getId());
        assertThat(tagPersistencyService
            .getTagById(tag3.getTenantId(), Collections.singletonList(assets.get("E1_S1").getId()), tag3.getId()))
            .isNull();
        assertThat(tagPersistencyService.getTagById(tag3.getTenantId(), getUnPrivileged(assets.get("E1")),
            tag3.getId())).isNull();
        assertThat(tagPersistencyService.getTagById(tag3.getTenantId(), getUnPrivileged(), tag3.getId()))
            .isNull();
        assertThat(
            tagPersistencyService.getTagBySourceKey(tag3.getTenantId(), getUnPrivileged(assets.get("E1")),
                tag3.getSourceKey())).isNull();
        assertThat(tagPersistencyService
            .getTagBySourceKey(tag3.getTenantId(), Collections.singletonList(assets.get("E1_S1").getId()),
                tag3.getSourceKey())).isNull();
        assertThat(tagPersistencyService.getTagsBySourceKeys(TestUtils.TEST_TENANT, getUnPrivileged(assets.get("E1")),
            Arrays.asList(tag1.getSourceKey(), tag2.getSourceKey(), tag3.getSourceKey()))).hasSize(2).extracting(
            Tag::getSourceKey).containsOnly(tag1.getSourceKey(), tag2.getSourceKey());
    }

    @Test(expected = IllegalArgumentException.class)
    public void createTag_tenantIdMismatch() throws PersistencyServiceException {
        tagPersistencyService.createTag(TestUtils.TEST_TENANT, getUber(),
            TagInstanceEntity.builder().tenantId(TestUtils.NULL_UUID).build());
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void createTag_missingTagId() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        String tagName1 = "E1_S1_Seg1_Asset2-0";
        Tag tag = TagPredicateUtils.newTag(types.get("MySegmentType").getId(), asset2.getId(), tagName1);
        ((TestTag) tag).setId(null);
        assertThat(tagPersistencyService.createTag(TestUtils.TEST_TENANT, getUber(), tag)).isNotNull();
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void createTag_invalidTagType() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        String tagName1 = "E1_S1_Seg1_Asset2-0";
        Tag tag = TagPredicateUtils.newTag(types.get("MySegmentType").getId(), asset2.getId(), tagName1);
        assertThat(tagPersistencyService.createTag(TestUtils.TEST_TENANT, getUber(), tag)).isNotNull();
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void createTag_assetNotAccessible() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        String tagName1 = "E1_S1_Seg1_Asset2-0";
        Tag tag = TagPredicateUtils.newTag(types.get("MySegmentType").getId(), asset2.getId(), tagName1);
        assertThat(tagPersistencyService
            .createTag(TestUtils.TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1_Asset1")), tag))
            .isNotNull();
    }

    @Test
    @Transactional
    public void createTag() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        String tagName1 = "E1_S1_Seg1_Asset2-0";
        Tag tag = TagPredicateUtils.newTag(types.get("MyTagType").getId(), asset2.getId(), tagName1);
        assertThat(tagPersistencyService.createTag(TestUtils.TEST_TENANT, getUber(), tag)).isNotNull();
    }

    @Test(expected = IllegalArgumentException.class)
    public void createTags_tenantIdMismatch() throws PersistencyServiceException {
        tagPersistencyService.createTags(TestUtils.TEST_TENANT, getUber(), Arrays
            .asList(TagInstanceEntity.builder().tenantId(TestUtils.TEST_TENANT).build(),
                TagInstanceEntity.builder().tenantId(TestUtils.NULL_UUID).build()));
    }

    @Test(expected = IncompatibleItemsException.class)
    @Transactional
    public void createTags_invalidTagType() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        int count = 3;
        List<Tag> tags = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String tagName1 = "E1_S1_Seg1_Asset2-" + i;
            String tagTypeId = i % 2 == 0 ? types.get("MyTagType").getId() : types.get("MySiteType").getId();
            tags.add(TagPredicateUtils.newTag(tagTypeId, asset2.getId(), tagName1));
        }

        tagPersistencyService.createTags(TestUtils.TEST_TENANT, getUber(), tags);
    }

    @Test
    @Transactional
    public void createTags_asUber() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        int count = 3;
        List<Tag> tags = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String tagName1 = "E1_S1_Seg1_Asset2-" + i;
            tags.add(TagPredicateUtils.newTag(types.get("MyTagType").getId(), asset2.getId(), tagName1));
        }

        assertThat(tagPersistencyService.createTags(TestUtils.TEST_TENANT, getUber(), tags)).isEqualTo(count);
        TagPredicate predicate = TagPredicate.builder().name(asset2.getName() + "-*").build();
        List<Tag> retrieved = tagPersistencyService.getTagsForAsset(TestUtils.TEST_TENANT, getUber(),
            asset2.getId(), true, predicate);
        for (Tag tag : retrieved) {
            assertThat(tag.getSuperTypesArray()).hasSize(2).containsOnly(ROOT_TAG_TYPE_ID,
                types.get("MyTagType").getId());
        }

        try {
            tagPersistencyService.createTags(TestUtils.TEST_TENANT, getUnPrivileged(), tags);
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (PersistencyServiceException e) {
            assertThat(e).isInstanceOf(ObjectNotFoundException.class);
        }
    }

    @Test
    @Transactional
    public void createTags_asPriviledged() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        int count = 10;
        List<Tag> tags = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String tagName1 = "E1_S1_Seg1_Asset2-" + i;
            tags.add(TagPredicateUtils.newTag(types.get("MyTagType").getId(), asset2.getId(), tagName1));
        }

        assertThat(tagPersistencyService.createTags(TestUtils.TEST_TENANT,
            getUnPrivileged(assets.get("E1"), assets.get("E1_S1_Seg1")), tags)).isEqualTo(count);

        try {
            tagPersistencyService.createTags(TestUtils.TEST_TENANT, getUnPrivileged(), tags);
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (PersistencyServiceException e) {
            assertThat(e).isInstanceOf(ObjectNotFoundException.class);
        }
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void updateTag_invalidTagType() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        String tagName1 = "E1_S1_Seg1_Asset2-tag";
        Tag tag = TagPredicateUtils.newTag(types.get("MyTagType").getId(), asset2.getId(), tagName1);

        assertThat(tagPersistencyService.createTag(TestUtils.TEST_TENANT, getUber(), tag)).isNotNull();
        TagInstanceEntity created = (TagInstanceEntity) tagPersistencyService.getTagById(TestUtils.TEST_TENANT,
            getUber(), tag.getId());
        assertThat(created.getCreatedDate()).isNotNull();
        assertThat(created.getLastModifiedDate()).isNotNull();
        created.setTagType(types.get("MyEnterpriseType").getId());
        created.setName(tag.getName() + " _updated");

        tagPersistencyService.updateTag(TestUtils.TEST_TENANT, getUber(), created);
    }

    @Test(expected = PersistencyServiceException.class)
    @Transactional
    public void updateTag_moveToAnotherAssetNotAllowed() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        String tagName1 = "E1_S1_Seg1_Asset2-tag";
        Tag tag = TagPredicateUtils.newTag(types.get("MyTagType").getId(), asset2.getId(), tagName1);

        assertThat(tagPersistencyService.createTag(TestUtils.TEST_TENANT, getUber(), tag)).isNotNull();
        Tag created = tagPersistencyService.getTagById(TestUtils.TEST_TENANT, getUber(), tag.getId());
        assertThat(created.getCreatedDate()).isNotNull();
        assertThat(created.getLastModifiedDate()).isNotNull();
        ((TagInstanceEntity) created).setName(tag.getName() + " _updated");
        ((TagInstanceEntity) created).setAssetId(assets.get("E1_S1_Seg1_Asset1").getId());

        // exception expected
        tagPersistencyService.updateTag(TestUtils.TEST_TENANT, getUber(), created);
    }

    @Test
    @Transactional
    public void updateTag() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        String tagName1 = "E1_S1_Seg1_Asset2-tag";
        Tag tag = TagPredicateUtils.newTag(types.get("MyTagType").getId(), asset2.getId(), tagName1);

        Tag created = tagPersistencyService.createTag(TestUtils.TEST_TENANT, getUber(), tag);
        assertThat(created).isNotNull();
        Tag found = tagPersistencyService.getTagById(TestUtils.TEST_TENANT, getUber(), tag.getId());

        assertThat(found.getCreatedDate().toInstant()).isEqualTo(created.getCreatedDate().toInstant());
        assertThat(found.getLastModifiedDate()).isAfterOrEqualTo(created.getCreatedDate());

        ((TagInstanceEntity) created).setName(tag.getName() + " _updated");
        Tag updated = tagPersistencyService.updateTag(TestUtils.TEST_TENANT, getUber(), created);

        assertThat(updated.getName()).isEqualTo(created.getName());
        System.out.println("Difference " + updated.getLastModifiedDate().compareTo(created.getLastModifiedDate()));
        assertThat(updated.getLastModifiedDate()).isAfterOrEqualTo(created.getLastModifiedDate());
    }

    @Test(expected = IncompatibleItemsException.class)
    @Transactional
    public void updateTags_invalidTagType() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        int count = 5;
        List<Tag> tags = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String tagName1 = "E1_S1_Seg1_Asset2-" + i;
            tags.add(TagPredicateUtils.newTag(types.get("MyTagType").getId(), asset2.getId(), tagName1));
        }

        assertThat(tagPersistencyService.createTags(TestUtils.TEST_TENANT, getUber(), tags)).isEqualTo(count);

        List<Tag> tobeUpdated = tags.stream().map(t -> {
            ((TestTag) t).setName("updated-" + t.getName());
            ((TestTag) t).setTagType(types.get("MySiteType").getId());
            return t;
        }).collect(Collectors.toList());
        tagPersistencyService.updateTags(TestUtils.TEST_TENANT, getUber(), tobeUpdated);
    }

    @Test
    @Transactional
    public void updateTags_moveToAnotherAssetNotAllowed() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        int count = 5;
        List<Tag> tags = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String tagName1 = "E1_S1_Seg1_Asset2-" + i;
            tags.add(TagPredicateUtils.newTag(types.get("MyTagType").getId(), asset2.getId(), tagName1));
        }

        assertThat(tagPersistencyService.createTags(TestUtils.TEST_TENANT, getUber(), tags)).isEqualTo(count);

        List<Tag> tobeUpdated = tags.stream().map(t -> {
            ((TestTag) t).setName("updated-" + t.getName());
            ((TestTag) t).setAssetId(assets.get("E1_S1").getId());
            return t;
        }).collect(Collectors.toList());
        try {
            tagPersistencyService.updateTags(TestUtils.TEST_TENANT, getUber(), tobeUpdated);
            failBecauseExceptionWasNotThrown(UncategorizedSQLException.class);
        } catch (PersistencyServiceException pse) {
            assertThat(pse.getCause()).isInstanceOf(UncategorizedSQLException.class);
        }
    }

    @Test
    @Transactional
    public void updateTags_bulkUpdate() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        int count = 5;
        List<Tag> tags = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String tagName1 = "E1_S1_Seg1_Asset2-" + i;
            tags.add(TagPredicateUtils.newTag(types.get("MyTagType").getId(), asset2.getId(), tagName1));
        }

        assertThat(tagPersistencyService.createTags(TestUtils.TEST_TENANT, getUber(), tags)).isEqualTo(count);
        OffsetDateTime now = OffsetDateTime.now();
        assertThat(tags.get(0).getLastModifiedDate()).isBeforeOrEqualTo(now);
        //during creation both should be same.
        assertThat(tags.get(0).getCreatedDate()).isEqualTo(tags.get(0).getLastModifiedDate());

        List<Tag> tobeUpdated = tags.stream().map(t -> {
            ((TestTag) t).setName("updated-" + t.getName());
            return t;
        }).collect(Collectors.toList());
        assertThat(tagPersistencyService.updateTags(TestUtils.TEST_TENANT, getUber(), tobeUpdated)).isEqualTo(
            tobeUpdated.size());
        List<Tag> updatedTags = tagPersistencyService.getTags(TestUtils.TEST_TENANT, getUber(),
            TagPredicate.builder().parent(ParentPredicate.builder().ids(Sets.newHashSet(asset2.getId())).build())
                .build());
        assertThat(updatedTags.size()).isEqualTo(tobeUpdated.size());
        assertThat(updatedTags).allMatch(
            t -> t.getName().startsWith("updated-") && !t.getLastModifiedDate().isBefore(now));

        assertThat(updatedTags.get(0).getLastModifiedDate()).isBeforeOrEqualTo(OffsetDateTime.now());
        assertThat(updatedTags.get(0).getSuperTypesArray()).hasSize(2).containsOnly(types.get("MyTagType").getId(),
            ROOT_TAG_TYPE_ID);

        assertThat(tobeUpdated.get(0).getLastModifiedDate()).isAfter(now);
        assertThat(tobeUpdated.get(0).getSuperTypesArray()).hasSize(2).containsOnly(types.get("MyTagType").getId(),
            ROOT_TAG_TYPE_ID);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void deleteTag_nullTagId() throws PersistencyServiceException {
        tagPersistencyService.deleteTag(TestUtils.TEST_TENANT, getUber(), null);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void deleteTag_emptyTagId() throws PersistencyServiceException {
        tagPersistencyService.deleteTag(TestUtils.TEST_TENANT, getUber(), "");
    }

    @Test
    @Transactional
    public void deleteTag_byId() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);

        // delete tag
        try {
            assertThat(tagPersistencyService
                .deleteTag(tags.get(0).getTenantId(), getUnPrivileged(), tags.get(0).getId())).isEqualTo(0);
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (PersistencyServiceException e) {
            assertThat(e).isInstanceOf(ObjectNotFoundException.class);
        }
        assertThat(tagPersistencyService.deleteTag(tags.get(0).getTenantId(), getUber(), tags.get(0).getId()))
            .isEqualTo(1);
        assertThat(
            tagPersistencyService.getTagById(tags.get(0).getTenantId(), getUber(), tags.get(0).getId()))
            .isNull();
        assertThat(tagPersistencyService
            .deleteTag(tags.get(1).getTenantId(), getUnPrivileged(tags.get(1).getAssetId()),
                tags.get(1).getId())).isEqualTo(1);
        try {
            assertThat(tagPersistencyService
                .deleteTag(tags.get(2).getTenantId(), getUnPrivileged(), tags.get(2).getId())).isEqualTo(0);
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (PersistencyServiceException e) {
            assertThat(e).isInstanceOf(ObjectNotFoundException.class);
        }
        assertThat(
            tagPersistencyService.getTagById(tags.get(2).getTenantId(), getUber(), tags.get(2).getId()))
            .isNotNull();

        assertThat(tagPersistencyService
            .deleteTag(tags.get(2).getTenantId(), getUnPrivileged(assets.get("E1")),
                tags.get(2).getId())).isEqualTo(1);
    }

    @Test
    @Transactional
    public void deleteTags_batchDelete() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        int count = 10;
        List<Tag> tags = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String tagName1 = "E1_S1_Seg1_Asset2-" + i;
            tags.add(TagPredicateUtils.newTag(types.get("MyTagType").getId(), asset2.getId(), tagName1));
        }

        assertThat(tagPersistencyService.createTags(TestUtils.TEST_TENANT, getUber(), tags)).isEqualTo(count);

        // delete first 3
        int three = 3;
        Set<String> tagIds = new HashSet<>();
        for (int i = 0; i < three; i++) {
            tagIds.add(tags.get(i).getId());
        }
        try {
            tagPersistencyService.deleteTags(TestUtils.TEST_TENANT, getUnPrivileged(), asset2.getId(),
                tagIds);
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (PersistencyServiceException e) {
            assertThat(e).isInstanceOf(ObjectNotFoundException.class);
        }

        assertThat(tagPersistencyService.deleteTags(TestUtils.TEST_TENANT, getUber(), asset2.getId(), tagIds))
            .isEqualTo(three);
        assertThat(tagPersistencyService.getTagById(TestUtils.TEST_TENANT, getUber(), tags.get(2).getId()))
            .isNull();

        // delete the rest
        try {
            tagPersistencyService.deleteTagsForAsset(TestUtils.TEST_TENANT, getUnPrivileged(), asset2.getId());
            failBecauseExceptionWasNotThrown(ObjectNotFoundException.class);
        } catch (PersistencyServiceException e) {
            assertThat(e).isInstanceOf(ObjectNotFoundException.class);
        }

        assertThat(tagPersistencyService.deleteTagsForAsset(TestUtils.TEST_TENANT, getUber(), asset2.getId()))
            .isEqualTo(count - three);
        assertThat(
            tagPersistencyService.getTagById(TestUtils.TEST_TENANT, getUber(), tags.get(count - 1).getId()))
            .isNull();
    }

    @Test
    @Transactional
    public void getTags_PagingWithSortKey() throws IOException, PersistencyServiceException {
        int pageSize = 5;
        int numPages = 4;
        int numTags = pageSize * numPages;
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        TagPredicateUtils.createTagDataForAsset(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), numTags);

        TagPredicate predicate = TagPredicate.builder().pageSize(numTags + 1).build();
        List<Tag> allTags = tagPersistencyService.getTags(TestUtils.TEST_TENANT, getUber(), predicate);
        assertThat(allTags).hasSize(numTags);

        predicate.setPagingInfo(0, pageSize, null, true);
        List<Tag> found = tagPersistencyService.getTags(TestUtils.TEST_TENANT, getUber(), predicate);
        assertThat(found).hasSize(pageSize);
        assertThat(found.stream().map(Tag::getId).collect(Collectors.toList()))
            .containsExactlyElementsOf(allTags.subList(0, pageSize).stream()
                .map(Tag::getId).collect(Collectors.toList()));

        String sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        assertThat(sortKey).isNotEmpty();

        predicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        int offset = pageSize;
        while (offset < pageSize * numPages) {
            predicate.setPagingInfo(1, pageSize, sortKey, true);
            found = tagPersistencyService.getTags(TestUtils.TEST_TENANT, getUber(), predicate);
            assertThat(found).hasSize(pageSize);
            assertThat(found.stream().map(Tag::getId).collect(Collectors.toList()))
                .containsExactlyElementsOf(allTags.subList(offset, offset + pageSize).stream()
                    .map(Tag::getId).collect(Collectors.toList()));
            offset += pageSize;
            sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        }

        predicate.setPagingInfo(1, pageSize, sortKey, true);
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, getUber(), predicate)).isEmpty();
    }

    /**
     * ROOT_ENTERPRISE_TYPE <-- MyEnterpriseType ROOT_SITE_TYPE       <-- MySiteType ROOT_SEGMENT_TYPE    <--
     * MySegmentType ROOT_ASSET_TYPE      <-- MyAssetType <-- MyAssetSubType ROOT_TAG_TYPE        <-- MyTagType
     */
    private Map<String, AssetType> createTypes() throws IOException, PersistencyServiceException {
        return TagPredicateUtils.createTypes(assetTypePersistencyService);
    }

    /**
     * E1 <-- E1_S1 <-- E1_S1_Seg1 <-- E1_S1_Seg1 <-- E1_S1_Seg1_Asset1 <-- E1_S1_Seg1_Asset2
     */
    private Map<String, Asset> createAssets(Map<String, AssetType> types)
        throws IOException, PersistencyServiceException {
        return TagPredicateUtils.createAssets(assetPersistencyService, types);
    }

    /**
     * E1_S1_Seg1        <-- E1_S1_Seg1_Tag0, E1_S1_Seg1_Tag1 E1_S1_Seg1_Asset1 <-- E1_S1_Seg1_Asset1_Tag0,
     * E1_S1_Seg1_Asset1_Tag1 E1_S1_Seg1_Asset2 <-- E1_S1_Seg1_Asset2_Tag3
     */
    private List<Tag> createTagData(Map<String, AssetType> types, Map<String, Asset> assets)
        throws IOException, PersistencyServiceException {
        return TagPredicateUtils.createTagDataForDifferentAssets(tagPersistencyService, types.get("MyTagType").getId(),
            assets);
    }
}