/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.view.TagComponent;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceEntity;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TagCorrelatedTagsLoaderTests extends TagCorrelatedItemsLoaderTests {

    @Autowired
    private TagCorrelatedTagsLoader tagCorrelatedTagsLoader;

    @Override
    protected Set<TagComponent> getComponentSet() {
        return EnumSet.of(TagComponent.CORRELATED_TAGS);
    }

    @Override
    protected void assertItemObject(AssetGroupItem item, List<AssetGroupItem> groupItems) {
        assertThat(item.getObject()).isNotNull();
        assertThat(item.getObject()).isInstanceOf(Tag.class);

        Set<String> expectedObjectIds = new HashSet<>(groupItems.size());
        groupItems.forEach(anyItem -> expectedObjectIds.add(anyItem.getObjectId()));

        Tag object = (Tag) item.getObject();
        assertThat(object.getId()).isIn(expectedObjectIds);
    }

    @Override
    protected PostLoadHandler<TagInstanceEntity, TagComponent> getPostLoader() {
        return this.tagCorrelatedTagsLoader;
    }
}
