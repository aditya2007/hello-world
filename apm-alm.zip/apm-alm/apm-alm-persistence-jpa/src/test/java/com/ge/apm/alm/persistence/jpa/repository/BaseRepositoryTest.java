/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.repository;

import java.io.IOException;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import org.junit.Assert;
import org.junit.Test;

import com.ge.apm.alm.persistence.jpa.entity.AuditableEntity;

/**
 * Created by hsiang-aiyu on 3/9/17.
 */
public class BaseRepositoryTest {

    protected static final ObjectReader objectReader = new ObjectMapper().reader();

    protected static JsonNode EMPTY_JSON_NODE;

    static {
        try {
            EMPTY_JSON_NODE = objectReader.readTree("{}");
        } catch (IOException ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    @Test
    public void stg0_flywayOnly() {
        // no-op, trigger flyway schema generation
    }

    protected void verifyPersistent(AuditableEntity auditable) {
        Assert.assertNotNull(auditable.getCreatedDate());
        Assert.assertNotNull(auditable.getLastModifiedDate());
    }
}
