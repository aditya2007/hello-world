/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.config;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.AlmContextConfig;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.ConfigContextQuery;
import com.ge.apm.alm.persistence.AlmContextConfigService;
import com.ge.apm.alm.persistence.ContextPersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AlmContextConfigEntity;
import com.ge.apm.alm.persistence.jpa.entity.ContextEntity;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AlmContextConfigPersistSvcTests {

    @Autowired
    private AlmContextConfigService configService;

    @Autowired
    private ContextPersistencyService contextService;

    @Test
    @Transactional
    public void test_findAll() {
        List<AlmContextConfig> contextConfigs = configService.findAll();
        Assert.assertEquals(12, contextConfigs.size());

        for (AlmContextConfig c : contextConfigs) {
            Assert.assertEquals(SeedOOTBData.SYSTEM_TENANT_ID, c.getTenantId());
        }
    }

    @Test
    @Transactional
    public void test_save() {
        AlmContextConfigEntity cc = new AlmContextConfigEntity();
        cc.setDescription("test");
        cc.setTenantId("459dd121-fd2c-43e0-aa5c-c9ebf0cb724c");
        cc.setValue("true");
        cc.setContext((ContextEntity) contextService.findByContextName("asset-state"));
        configService.save(cc);

       List<AlmContextConfig> contextList = configService.findAllByContextNameAndTenantId("asset-state",
            "459dd121-fd2c-43e0-aa5c-c9ebf0cb724c");

       Assert.assertEquals(1, contextList.size());
    }

    @Test(expected = JpaSystemException.class)
    @Transactional
    public void test_save_noContextProvided() {
        AlmContextConfigEntity cc = new AlmContextConfigEntity();
        cc.setDescription("test");
        cc.setTenantId(SeedOOTBData.SYSTEM_TENANT_ID);
        cc.setValue("true");
        configService.save(cc);
    }

    @Test
    @Transactional
    public void test_findAllByTenantId() {
        AlmContextConfigEntity cc = new AlmContextConfigEntity();
        cc.setDescription("test");
        cc.setTenantId("459dd121-fd2c-43e0-aa5c-c9ebf0cb724c");
        cc.setValue("true");
        cc.setContext((ContextEntity) contextService.findByContextName("asset-state"));
        configService.save(cc);

        List<AlmContextConfig> contextConfigs = configService.findAllByTenantId(SeedOOTBData.SYSTEM_TENANT_ID);
        Assert.assertEquals(12, contextConfigs.size());

        for (AlmContextConfig c : contextConfigs) {
            Assert.assertEquals(SeedOOTBData.SYSTEM_TENANT_ID, c.getTenantId());
        }
    }

    @Test
    @Transactional
    public void test_findAllByTenantId_NonExistent() {
        List<AlmContextConfig> contextConfigs = configService.findAllByTenantId("459dd121-fd2c-43e0-aa5c-c9ebf0cb724c");
        Assert.assertEquals(12, contextConfigs.size());
    }

    @Test
    @Transactional
    public void test_findAllByContextAndTenantId() {
        ContextEntity context = (ContextEntity) contextService.findByContextName("asset-state");
        List<AlmContextConfig> contextConfigs = configService.findAllByContextNameAndTenantId(context.getContextName(),
            "459dd121-fd2c-43e0-aa5c-c9ebf0cb724c");

        Assert.assertEquals(0, contextConfigs.size());

        context = (ContextEntity) contextService.findByContextName("bulk_ingestion_audit");
        contextConfigs = configService.findAllByContextNameAndTenantId(context.getContextName(), SeedOOTBData.SYSTEM_TENANT_ID);
        Assert.assertEquals(1, contextConfigs.size());
        for (AlmContextConfig c : contextConfigs) {
            Assert.assertEquals(SeedOOTBData.SYSTEM_TENANT_ID, c.getTenantId());
            Assert.assertEquals(context, c.getContext());
        }
    }

    @Test
    @Transactional
    public void test_findAllByQuerySpecs() {
        ContextEntity context = (ContextEntity) contextService.findByContextName("bulk_ingestion_audit");
        ConfigContextQuery ccq = new ConfigContextQuery();
        ccq.setContext(new String[] { context.getContextName() });

        ccq.setIsActive(true);
        List<AlmContextConfig> contextConfigs = configService.findAllByQuerySpecs(SeedOOTBData.SYSTEM_TENANT_ID, ccq);
        Assert.assertEquals(1, contextConfigs.size());

        ccq.setIsActive(false);
        contextConfigs = configService.findAllByQuerySpecs(SeedOOTBData.SYSTEM_TENANT_ID, ccq);
        Assert.assertEquals(0, contextConfigs.size());

        ccq.setContext(new String[] { "doesnotexist" });
        ccq.setIsActive(true);
        contextConfigs = configService.findAllByQuerySpecs(SeedOOTBData.SYSTEM_TENANT_ID, ccq);
        Assert.assertEquals(0, contextConfigs.size());

        ccq.setContext(
            new String[] { "bulk_ingestion_audit", "doesnotexist", "enterprise_state_ui_edit", "asset_state_ui_edit" });
        ccq.setIsActive(true);
        contextConfigs = configService.findAllByQuerySpecs(SeedOOTBData.SYSTEM_TENANT_ID, ccq);
        Assert.assertEquals(3, contextConfigs.size());
    }
}
