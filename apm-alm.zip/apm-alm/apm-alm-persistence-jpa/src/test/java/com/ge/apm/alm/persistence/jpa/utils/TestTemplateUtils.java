package com.ge.apm.alm.persistence.jpa.utils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.model.TestNotes;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholder;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderGroupTagType;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderTagType;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderTemplate;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderType;
import com.ge.apm.alm.persistence.jpa.model.TestTemplate;
import com.ge.apm.alm.persistence.jpa.model.TestTemplateNotes;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.objectReader;

public final class TestTemplateUtils {

    private static final String DATE_FORMAT = "MM/dd/yyyy hh:mm:ss";

    private TestTemplateUtils() {
    }

    public static String getNewUuid() {
        return UUID.randomUUID().toString();
    }

    public static TestTemplate buildTemplate(String sourceKey, String name) throws IOException {
        String mySourceKey = StringUtils.isEmpty(sourceKey) ? getNewUuid() : sourceKey;
        return TestTemplate.builder().id(getNewUuid()).sourceKey(mySourceKey).name(name).description(name).
            tenantId(TenantTestUtils.getTenantId()).state("01").status("01").createdBy("Test").lastModifiedBy("Test").build();
    }

    public static JsonNode buildTemplateAttributes(String type, long variable) throws IOException {
        StringBuilder custom = new StringBuilder("\"attributes\": ");
        custom.append("{\"std_model_number\": {\"type\": \"String\",\"value\": [\"PowerLogic ION8600 Form 9");
        custom.append(variable).append("S STD\"]},");
        custom.append("\"model_number\": {\"type\": \"String\",\"value\": [\"PowerLogic ION8600 Form 9");
        custom.append(variable).append("S STD\"]},");
        custom.append("\"test string\": {\"type\": \"String\",\"value\": [\"").append(type).append("\"]}}");
        String customAttributes = custom.toString();

        StringBuilder attributes = new StringBuilder("{").append(customAttributes).append("}");
        return TestUtils.objectReader.readTree(attributes.toString());
    }

    public static TestNotes buildNotes(String tenantId, String content) {
        return TestNotes.builder().id(getNewUuid()).tenantId(tenantId).name(getNewUuid()).content(content)
            .createdBy("Test").lastModifiedBy("Test").build();
    }

    public static TestTemplateNotes buildTestTemplateNotes(String templateId, TestNotes testNotes) {
        return TestTemplateNotes.builder().id(getNewUuid()).tenantId(TenantTestUtils.getTenantId())
            .templateId(templateId).notes(testNotes).build();
    }

    public static TestPlaceholder buildPlaceholder(String templateId, String ppn, String parentId) throws IOException {
        return TestPlaceholder.builder().id(getNewUuid()).sourceKey(getNewUuid()).name(getNewUuid())
            .description("placeholder with ppn:" + ppn)
            .tenantId(TenantTestUtils.getTenantId()).templateId(templateId).partPositionNumber(ppn)
            .parentId(parentId).attributes(buildPlaceholderAttributes(null))
            .createdBy("Test").lastModifiedBy("Test").build();
    }

    public static JsonNode buildPlaceholderAttributes(String effectivityDate) throws IOException {
        String myEffectivityDate = StringUtils.isEmpty(effectivityDate)
            ? new SimpleDateFormat(DATE_FORMAT, Locale.getDefault()).format(new Date()) : effectivityDate;
        StringBuilder custom = new StringBuilder("\"attributes\": ");
        custom.append("{\"effectivityDate\":{\"value\":[\"" + myEffectivityDate + "\"],\"type\":\"timestamp\"}}");
        StringBuilder attributes = new StringBuilder("{").append(custom.toString()).append("}");
        return TestUtils.objectReader.readTree(attributes.toString());
    }

    public static TestPlaceholderType buildPlaceholderType(String placeholderId, String typeId) {
        return TestPlaceholderType.builder().id(getNewUuid()).tenantId(TenantTestUtils.getTenantId())
            .placeholderId(placeholderId).typeId(typeId).status("Active").primary(Boolean.TRUE).build();
    }

    public static TestPlaceholderTemplate buildPlaceholderTemplate(String placeholderId, String templateId) {
        return TestPlaceholderTemplate.builder().id(getNewUuid()).tenantId(TenantTestUtils.getTenantId())
            .placeholderId(placeholderId).templateId(templateId).status("Active").build();
    }

    public static AssetType buildAssetTye(String supperTypeId, String name) throws IOException {
        return TestUtils.createAssetType(supperTypeId, name);
    }

    public static TestPlaceholderTagType buildPlaceholderTagType(String placeholderId, String tagTypeId) {
        return TestPlaceholderTagType.builder().id(getNewUuid()).tenantId(TenantTestUtils.getTenantId())
            .placeholderId(placeholderId).tagTypeId(tagTypeId).category("OUTPUT").expressions(getExpressions()).build();
    }

    public static TestPlaceholderGroupTagType buildPlaceholderGroupTagType(String placeholderId, String groupId) {
        return TestPlaceholderGroupTagType.builder().id(getNewUuid()).tenantId(TenantTestUtils.getTenantId())
            .placeholderId(placeholderId).groupId(groupId).category("TEMPORARY").build();
    }

    public static TestAssetGroup buildAssetGroup(String name, AssetGroupCategory category) {
        return TestAssetGroup.builder().id(UUID.randomUUID().toString()).sourceKey(name).name(name).description(name)
            .createdBy("Test").lastModifiedBy("test").category(category).tenantId(TenantTestUtils.getTenantId()).build();
    }

    private static JsonNode getExpressions() {
        String expressions = "{\"tagExpression\":[{\"tdExpr\":\"{$ID}{#ID}\",\"nameExpr\":\"{$name}.{#name}\","
            + "\"timeSeriesLinkExpr\":\"{$ID}.{#ID}\",\"range\":\"[a,b,c]\"}]}";
        try {
            return objectReader.readTree(expressions);
        } catch (IOException io) {
            return null;
        }
    }
}
