/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;

public final class AssetUtils {

    private AssetUtils() {
    }

    /**
     * Creating the following type and instance hierarchy
     * ROOT_ENTERPRISE_TYPE <- MyEnterpriseType (*)
     *                         MyEnterpriseType2 <- MyEnterpriseType2SubType
     *                         MyEnterpriseType3
     *
     * ROOT_SITE_TYPE       <- MySiteType (@)
     * ROOT_SEGEMENT_TYPE   <- MySegmentType (%)
     * ROOT_ASSET_TYPE      <- MyAssetType (#)
     * ROOT_TAG_TYPE        <- MyTagType
     *
     * E2 (*) <- E2_Asset1 (#) <- E2_Asset1_Tag1
     * E1 (*) <- E1_S1 (@) <- E1_S1_Seg1 (%) <- E1_S1_Seg1_Asset1 (#) <- E1_S1_Seg1_Asset1_Tag1
     *                                          E1_S1_Seg1_Asset2 (#) <- E1_S1_Seg1_Asset2_Tag1
     */
    public static Map<String, BaseDataModel> setupData(AssetTypePersistencyService assetTypePersistencyService,
        AssetPersistencyService assetPersistencyService)
        throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> assetData = new HashMap<>();
        AssetType enterpriseType =
            TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID,
                "MyEnterpriseType");
        AssetType enterpriseType2 = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID, "MyEnterpriseType2");
        AssetType enterpriseType2SubType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            enterpriseType2.getId(), "MyEnterpriseType2SubType");
        AssetType enterpriseType3 = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID, "MyEnterpriseType3");

        AssetType siteType =
            TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_SITE_TYPE_ID,
                "MySiteType");
        AssetType segmentType =
            TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_SEGMENT_TYPE_ID,
                "MySegmentType");
        AssetType assetType =
            TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_ASSET_TYPE_ID,
                "MyAssetType");
        AssetType tagType =
            TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_TAG_TYPE_ID, "MyTagType");

        assetData.put("MyEnterpriseType", enterpriseType);
        assetData.put("MyEnterpriseType2", enterpriseType2);
        assetData.put("MyEnterpriseType2SubType", enterpriseType2SubType);
        assetData.put("MyEnterpriseType3", enterpriseType3);
        assetData.put("MySiteType", siteType);
        assetData.put("MySegmentType", segmentType);
        assetData.put("MyAssetType", assetType);
        assetData.put("MyTagType", tagType);

        Asset e2 = TestUtils
            .createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), enterpriseType.getId(), null,
                "E2");
        assetData.put("E2", e2);

        Collection<String> accessibleFromE2 = Arrays.asList(e2.getId());
        Asset e2Asset1 =
            TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleFromE2, assetType.getId(),
                e2.getId(),
                "E2_Asset1");
        assetData.put("E2_Asset1", e2Asset1);

        Asset e1 = TestUtils
            .createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), enterpriseType.getId(), null,
                "E1");
        Collection<String> accessibleResources1 = Arrays.asList(e1.getId());
        Asset e1S1 =
            TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1, siteType.getId(),
                e1.getId(),
                "E1_S1");
        Asset e1S1Seg1 =
            TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1, segmentType.getId(),
                e1S1.getId(), "E1_S1_Seg1");
        Asset e1S1Seg1Asset1 =
            TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1, assetType.getId(),
                e1S1Seg1.getId(), "E1_S1_Seg1_Asset1");
        Asset e1S1Seg1Asset2 =
            TestUtils.createAssetInstanceAndAssert(assetPersistencyService, accessibleResources1, assetType.getId(),
                e1S1Seg1.getId(), "E1_S1_Seg1_Asset2");

        assetData.put("E1", e1);
        assetData.put("E1_S1", e1S1);
        assetData.put("E1_S1_Seg1", e1S1Seg1);
        assetData.put("E1_S1_Seg1_Asset1", e1S1Seg1Asset1);
        assetData.put("E1_S1_Seg1_Asset2", e1S1Seg1Asset2);

        return assetData;
    }
}
