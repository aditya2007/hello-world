package com.ge.apm.alm.persistence.mirror;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringRunner.class)
public class MirrorTagPersistSvcTests extends MirrorPersistSvcTests {

    @Test
    @Transactional
    public void test() {
        // doing nothing at the moment.
    }
}
