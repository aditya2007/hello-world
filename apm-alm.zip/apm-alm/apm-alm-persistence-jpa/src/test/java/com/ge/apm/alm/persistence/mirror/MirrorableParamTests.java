/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.mirror;

import java.time.OffsetDateTime;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(JUnit4.class)
public class MirrorableParamTests {

    @Test
    @Transactional
    public void testParamCreation() throws PersistencyServiceException {
        String tenantId = MirrorTestUtils.randomUUID();
        String methodName = "createAsset";
        String assetId = MirrorTestUtils.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        Object arg = MirrorTestUtils.createAsset(assetId, OOTBCoreTypesIdLookup.SegmentType, now);
        Object result = null;

        MirrorableParam p = new MirrorableParam(tenantId, methodName,
            MirrorTestUtils.createMirror(null, Asset.class), arg, result, null);
        p.setRealObjectType("Segment");

        verify(p, tenantId, Type.CREATE, "Segment", assetId);
    }

    @Test(expected = PersistencyServiceException.class)
    @Transactional
    public void testErrorOnStringButUnspecifiedClass() throws PersistencyServiceException {
        String tenantId = MirrorTestUtils.randomUUID();
        String methodName = "createAsset";
        String assetId = MirrorTestUtils.randomUUID();

        new MirrorableParam(tenantId, methodName, MirrorTestUtils.createMirror(null, null), assetId, null, null);
    }

    private void verify(MirrorableParam param, String tenantId, Type persistType, String objectType, String objectId) {
        assertEquals(tenantId, param.getTenantId());
        assertTrue(persistType.equals(param.getPersistType()));
        assertEquals(objectType, param.getObjectType());
        assertEquals(objectId, param.getObjectId());
    }

    private void verify(MirrorableParam param, String tenantId, Type persistType, String objectType, String objectId,
        OffsetDateTime dateTime) {
        verify(param, tenantId, persistType, objectType, objectId);
        assertEquals(dateTime, param.getLastModified());
    }

}
