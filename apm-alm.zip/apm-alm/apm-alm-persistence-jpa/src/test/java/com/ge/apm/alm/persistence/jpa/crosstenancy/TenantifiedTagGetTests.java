/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.crosstenancy;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUber;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.assertj.core.util.Maps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.utils.TagPredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TenantTestUtils;
import com.ge.apm.alm.persistence.mirror.MirrorTestUtils;
import com.ge.apm.common.support.RequestContext;

/**
 * @author Shu W. Yu 212614203
 * @version 1.0 Apr 30, 2018
 * @since 1.0
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TenantifiedTagGetTests {

    private final String[] tenantIds = new String[]{
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
    };

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private TagPersistencyService tagPersistencyService;

    @Autowired
    GroupPersistencyService groupPersistencyService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private List<Tag> tagsCreated;

    @Test
    public void testNonContextTenant() throws IOException, PersistencyServiceException {
        try {
            MirrorTestUtils.setEventCreationEnabled(false);
            createData();
            setupCrossTenants();

            doTests();

        } finally {
            clearCrossTenants();
            clearData();
            MirrorTestUtils.setEventCreationEnabled(true);
        }
    }

    private void doTests() throws PersistencyServiceException {
        getTagByIdTest();
        getTagsTest();
        getCorrelatedTagsByIdTest();
    }

    private void getTagByIdTest() {
        Tag tag = tagPersistencyService.getTagById(tenantIds[0], null, tagsCreated.get(0).getId());
        assertThat(tag.getTenantId()).isEqualTo(tenantIds[1]);

        RequestContext.put(CrossTenancyCall.ALL_ACCESSIBLE_RESOURCES, Maps.newHashMap(
            tenantIds[1], new String[]{"/tags/" + UUID.randomUUID().toString()}));
        assertThat(tagPersistencyService.getTagById(tenantIds[0], null, tagsCreated.get(0).getId()))
            .isNull();
        setupCrossTenants();
    }

    private void getTagsTest() {
        TagPredicate predicate = TagPredicate.builder().sourceKey("*Tag*").build();
        List<Tag> allTags = tagPersistencyService.getTags(tenantIds[0], null, predicate);
        assertThat(allTags).hasSize(tagsCreated.size());
        allTags.forEach(tag -> assertThat(tag.getTenantId()).isEqualTo(tenantIds[1]));

        List<String> allTagIds = allTags.stream().map(Tag::getId).collect(Collectors.toList());

        IntStream.range(0, 500).forEach(i -> {
            predicate.setPageSize(2);
            predicate.setOffset(i * 2);
            List<Tag> tagsOfAsset = tagPersistencyService.getTags(tenantIds[0], null, predicate);
            tagsOfAsset.forEach(tag -> assertThat(tag.getTenantId()).isEqualTo(tenantIds[1]));
            List<String> tagIds = tagsOfAsset.stream().map(Tag::getId).collect(Collectors.toList());
            allTagIds.removeAll(tagIds);
        });

        assertThat(allTagIds).hasSize(0);

        RequestContext.put(CrossTenancyCall.ALL_ACCESSIBLE_RESOURCES, Maps.newHashMap(
            tenantIds[1], new String[]{"/tags/" + UUID.randomUUID().toString()}));
        allTags = tagPersistencyService.getTags(tenantIds[0], null, predicate);
        assertThat(allTags).isEmpty();
        setupCrossTenants();
    }

    private void getCorrelatedTagsByIdTest() throws PersistencyServiceException {
        List<Tag> tags = tagPersistencyService.getCorrelatedTagsById(tenantIds[0], null,
            tagsCreated.get(0).getId());
        assertThat(tags).hasSize(tagsCreated.size());
        assertThat(tags.stream().map(Tag::getId).collect(Collectors.toList())).containsSequence(
            tagsCreated.stream().map(Tag::getId).collect(Collectors.toList()));
    }

    private void createData() throws IOException, PersistencyServiceException {
        String oldTenantId = TenantTestUtils.setTenantId(tenantIds[1]);
        try {
            Map<String, AssetType> typesCreated = TagPredicateUtils.createTypes(assetTypePersistencyService);
            Map<String, Asset> assetsCreated = TagPredicateUtils.createAssets(assetPersistencyService,
                typesCreated);
            tagsCreated = TagPredicateUtils
                .createTagDataForAsset(tagPersistencyService, typesCreated.get("MyTagType").getId(),
                    assetsCreated.get("E1_S1_Seg1_Asset1"), 500);

            List<AssetGroupItem> items = new ArrayList<>();
            AssetGroup group = TestAssetGroup.builder().id(UUID.randomUUID().toString()).category(
                AssetGroupCategory.TAG_CORRELATION).build();
            AssetGroup groupCreated = groupPersistencyService.createAssetGroup(tenantIds[1], group);
            for (int i = 0; i < tagsCreated.size(); i++) {
                items.add(TagPredicateUtils.newTagCorrelationItem(tagsCreated.get(i), groupCreated.getId(), i + 1));
            }
            groupPersistencyService.createAssetGroupItems(tenantIds[1], getUber(), groupCreated.getId(), items);
        } finally {
            TenantTestUtils.setTenantId(oldTenantId);
        }
    }

    private void setupCrossTenants() {
        RequestContext.destroy();
        RequestContext.put(RequestContext.TENANT_UUID, tenantIds[0]);
        RequestContext.put(CrossTenancyCall.ALL_ACCESSIBLE_RESOURCES, Maps.newHashMap(tenantIds[1], new String[]{"*"}));
    }

    private void clearCrossTenants() {
        RequestContext.destroy();
    }

    private void clearData() {
        jdbcTemplate.update("DELETE FROM apm_alm.asset_group_tag_correlation WHERE tenant_id=?", tenantIds[1]);
        jdbcTemplate.update("DELETE FROM apm_alm.asset_group WHERE tenant_id=?", tenantIds[1]);
        jdbcTemplate.update("DELETE FROM apm_alm.tag_instance WHERE tenant_id=?", tenantIds[1]);
        jdbcTemplate.update("DELETE FROM apm_alm.asset_instance WHERE tenant_id=?", tenantIds[1]);
        jdbcTemplate.update("DELETE FROM apm_alm.asset_type WHERE tenant_id=?", tenantIds[1]);
    }
}
