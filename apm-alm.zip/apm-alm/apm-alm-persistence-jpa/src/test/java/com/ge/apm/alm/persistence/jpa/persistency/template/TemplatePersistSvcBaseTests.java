/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.template;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Notes;
import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.PlaceholderGroupTagType;
import com.ge.apm.alm.model.PlaceholderTagType;
import com.ge.apm.alm.model.PlaceholderTemplate;
import com.ge.apm.alm.model.PlaceholderType;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.NotesPersistencyService;
import com.ge.apm.alm.persistence.PlaceholderGroupTagTypePersistencyService;
import com.ge.apm.alm.persistence.PlaceholderPersistencyService;
import com.ge.apm.alm.persistence.PlaceholderTagTypePersistencyService;
import com.ge.apm.alm.persistence.PlaceholderTemplatePersistencyService;
import com.ge.apm.alm.persistence.PlaceholderTypePersistencyService;
import com.ge.apm.alm.persistence.TemplateNotePersistencyService;
import com.ge.apm.alm.persistence.TemplatePersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.NotesEntity;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderEntity;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderGroupTagTypeEntity;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderTagTypeEntity;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderTemplateEntity;
import com.ge.apm.alm.persistence.jpa.entity.PlaceholderTypeEntity;
import com.ge.apm.alm.persistence.jpa.entity.TemplateEntity;
import com.ge.apm.alm.persistence.jpa.entity.TemplateNotesEntity;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.model.TestNotes;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholder;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderGroupTagType;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderTagType;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderTemplate;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderType;
import com.ge.apm.alm.persistence.jpa.model.TestTemplate;
import com.ge.apm.alm.persistence.jpa.model.TestTemplateNotes;
import com.ge.apm.alm.persistence.jpa.utils.TestTemplateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TemplatePersistSvcBaseTests {

    @Autowired
    TemplatePersistencyService templatePersistencyService;
    @Autowired
    PlaceholderPersistencyService placeholderPersistencyService;
    @Autowired
    PlaceholderTypePersistencyService placeholderTypePersistencyService;
    @Autowired
    PlaceholderTemplatePersistencyService placeholderTemplatePersistencyService;
    @Autowired
    PlaceholderTagTypePersistencyService placeholderTagTypePersistencyService;
    @Autowired
    PlaceholderGroupTagTypePersistencyService placeholderGroupTagTypePersistencyService;
    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;
    @Autowired
    private GroupPersistencyService groupPersistencyService;
    @Autowired
    NotesPersistencyService notesPersistencyService;
    @Autowired
    TemplateNotePersistencyService templateNotePersistencyService;

    @Test
    public void testTemplateEntities() throws IOException {
        TemplateEntity templateEntity = new TemplateEntity();
        templateEntity.setTenantId(TestUtils.TEST_TENANT);
        templateEntity.setId(TestTemplateUtils.getNewUuid());
        templateEntity.setName("Engine Template");
        templateEntity.setDescription("desc");
        templateEntity.setRevision("1.0");
        templateEntity.setState("01");
        templateEntity.setStatus("01");
        templateEntity.setAttributes(TestTemplateUtils.buildTemplateAttributes("test", 20L));
        templateEntity.setCreatedBy("testUser");
        templateEntity.setLastModifiedBy("testUser");
        templateEntity.setCreatedDate(OffsetDateTime.now());
        templateEntity.setLastModifiedDate(OffsetDateTime.now());
        log.info(templateEntity.toString());
        TemplateEntity.builder().id(TestTemplateUtils.getNewUuid()).tenantId(TestUtils.TEST_TENANT)
            .name("engine Template").createdBy("testUser").lastModifiedBy("testUser").description("desc").state("01")
            .status("01").revision("1.0").sourceKey(TestTemplateUtils.getNewUuid())
            .attributes(TestTemplateUtils.buildTemplateAttributes("test", 20L))
            .build();

        NotesEntity notesEntity = new NotesEntity();
        notesEntity.setTenantId(TestUtils.TEST_TENANT);
        notesEntity.setId(TestTemplateUtils.getNewUuid());
        notesEntity.setContent("This is test note");
        notesEntity.setName("testNote");
        notesEntity.setCreatedBy("testUser");
        notesEntity.setLastModifiedBy("testUser");
        notesEntity.setCreatedDate(OffsetDateTime.now());
        notesEntity.setLastModifiedDate(OffsetDateTime.now());
        log.info(notesEntity.toString());
        NotesEntity.builder().tenantId(TestUtils.TEST_TENANT).id(TestTemplateUtils.getNewUuid()).name("testNote")
            .content("first note").createdBy("testUser").lastModifiedBy("testUser").build();

        TemplateNotesEntity templateNotesEntity = new TemplateNotesEntity();
        templateNotesEntity.setTenantId(TestUtils.TEST_TENANT);
        templateNotesEntity.setTemplateId(templateEntity.getId());
        templateNotesEntity.setId(TestTemplateUtils.getNewUuid());
        templateNotesEntity.setNotes(notesEntity);
        log.info(templateNotesEntity.toString());
        TemplateNotesEntity.builder().tenantId(TestUtils.TEST_TENANT).id(TestTemplateUtils.getNewUuid())
            .templateId(templateEntity.getId()).notes(notesEntity).build();

        PlaceholderEntity placeholderEntity = new PlaceholderEntity();
        placeholderEntity.setTenantId(TestUtils.TEST_TENANT);
        placeholderEntity.setTemplateId(templateEntity.getId());
        placeholderEntity.setPartPositionNumber("PPN1");
        placeholderEntity.setId(TestTemplateUtils.getNewUuid());
        placeholderEntity.setSourceKey(TestTemplateUtils.getNewUuid());
        placeholderEntity.setName("Engine Template");
        placeholderEntity.setDescription("desc");
        placeholderEntity.setParentId(TestTemplateUtils.getNewUuid());
        placeholderEntity.setAttributes(TestTemplateUtils.buildPlaceholderAttributes(null));
        placeholderEntity.setCreatedBy("testUser");
        placeholderEntity.setLastModifiedBy("testUser");
        placeholderEntity.setCreatedDate(OffsetDateTime.now());
        placeholderEntity.setLastModifiedDate(OffsetDateTime.now());
        log.info(placeholderEntity.toString());
        PlaceholderEntity.builder().tenantId(TestUtils.TEST_TENANT).id(TestTemplateUtils.getNewUuid()).name("name")
            .templateId(templateEntity.getId()).sourceKey(TestTemplateUtils.getNewUuid()).description("desc")
            .attributes(TestTemplateUtils.buildPlaceholderAttributes(null))
            .parentId(TestTemplateUtils.getNewUuid()).partPositionNumber("PPN1").createdBy("testUser")
            .lastModifiedBy("testUser").build();

        PlaceholderTypeEntity placeholderTypeEntity = new PlaceholderTypeEntity();
        placeholderTypeEntity.setTenantId(TestUtils.TEST_TENANT);
        placeholderTypeEntity.setId(TestTemplateUtils.getNewUuid());
        placeholderTypeEntity.setPlaceholderId(placeholderEntity.getId());
        placeholderTypeEntity.setTypeId(TestTemplateUtils.getNewUuid());
        placeholderTypeEntity.setCreatedBy("testUser");
        placeholderTypeEntity.setLastModifiedBy("testUser");
        placeholderTypeEntity.setCreatedDate(OffsetDateTime.now());
        placeholderTypeEntity.setLastModifiedDate(OffsetDateTime.now());
        log.info(placeholderTypeEntity.toString());
        PlaceholderTypeEntity.builder().tenantId(TestUtils.TEST_TENANT).id(TestTemplateUtils.getNewUuid())
            .placeholderId(templateEntity.getId()).typeId(TestTemplateUtils.getNewUuid()).createdBy("testUser")
            .lastModifiedBy("testUser").build();

        PlaceholderTemplateEntity placeholderTemplateEntity = new PlaceholderTemplateEntity();
        placeholderTemplateEntity.setTenantId(TestUtils.TEST_TENANT);
        placeholderTemplateEntity.setId(TestTemplateUtils.getNewUuid());
        placeholderTemplateEntity.setPlaceholderId(placeholderEntity.getId());
        placeholderTemplateEntity.setTemplateId(TestTemplateUtils.getNewUuid());
        placeholderTemplateEntity.setCreatedBy("testUser");
        placeholderTemplateEntity.setLastModifiedBy("testUser");
        placeholderTemplateEntity.setCreatedDate(OffsetDateTime.now());
        placeholderTemplateEntity.setLastModifiedDate(OffsetDateTime.now());
        log.info(placeholderTemplateEntity.toString());
        PlaceholderTemplateEntity.builder().tenantId(TestUtils.TEST_TENANT).id(TestTemplateUtils.getNewUuid())
            .placeholderId(templateEntity.getId()).templateId(TestTemplateUtils.getNewUuid()).createdBy("testUser")
            .lastModifiedBy("testUser").build();

        PlaceholderTagTypeEntity placeholderTagTypeEntity = new PlaceholderTagTypeEntity();
        placeholderTagTypeEntity.setTenantId(TestUtils.TEST_TENANT);
        placeholderTagTypeEntity.setId(TestTemplateUtils.getNewUuid());
        placeholderTagTypeEntity.setPlaceholderId(placeholderEntity.getId());
        placeholderTagTypeEntity.setTagTypeId(TestTemplateUtils.getNewUuid());
        placeholderTagTypeEntity.setCategory("CONTRIBUTING");
        placeholderTagTypeEntity.setCreatedBy("testUser");
        placeholderTagTypeEntity.setLastModifiedBy("testUser");
        placeholderTagTypeEntity.setCreatedDate(OffsetDateTime.now());
        placeholderTagTypeEntity.setLastModifiedDate(OffsetDateTime.now());
        log.info(placeholderTagTypeEntity.toString());
        PlaceholderTagTypeEntity.builder().tenantId(TestUtils.TEST_TENANT).id(TestTemplateUtils.getNewUuid())
            .placeholderId(templateEntity.getId()).tagTypeId(TestTemplateUtils.getNewUuid()).category("CONTRIBUTING")
            .createdBy("testUser").lastModifiedBy("testUser").build();

        PlaceholderGroupTagTypeEntity placeholderGroupTagTypeEntity = new PlaceholderGroupTagTypeEntity();
        placeholderGroupTagTypeEntity.setTenantId(TestUtils.TEST_TENANT);
        placeholderGroupTagTypeEntity.setId(TestTemplateUtils.getNewUuid());
        placeholderGroupTagTypeEntity.setPlaceholderId(placeholderEntity.getId());
        placeholderGroupTagTypeEntity.setGroupId(TestTemplateUtils.getNewUuid());
        placeholderGroupTagTypeEntity.setCategory("CONTRIBUTING");
        placeholderGroupTagTypeEntity.setCreatedBy("testUser");
        placeholderGroupTagTypeEntity.setLastModifiedBy("testUser");
        placeholderGroupTagTypeEntity.setCreatedDate(OffsetDateTime.now());
        placeholderGroupTagTypeEntity.setLastModifiedDate(OffsetDateTime.now());
        log.info(placeholderGroupTagTypeEntity.toString());
        PlaceholderGroupTagTypeEntity.builder().tenantId(TestUtils.TEST_TENANT).id(TestTemplateUtils.getNewUuid())
            .placeholderId(templateEntity.getId()).groupId(TestTemplateUtils.getNewUuid()).category("CONTRIBUTING")
            .createdBy("testUser").lastModifiedBy("testUser").build();

        List<PlaceholderTypeEntity> typeEntities = new ArrayList<>();
        List<PlaceholderTagTypeEntity> tagTypeEntities = new ArrayList<>();
        List<PlaceholderGroupTagTypeEntity> groupTagTypeEntities = new ArrayList<>();
        typeEntities.add(placeholderTypeEntity);
        tagTypeEntities.add(placeholderTagTypeEntity);
        groupTagTypeEntities.add(placeholderGroupTagTypeEntity);

        placeholderEntity.setPlaceholderTypes(typeEntities);
        placeholderEntity.setPlaceholderTemplates(placeholderTemplateEntity);
        placeholderEntity.setPlaceholderTagTypes(tagTypeEntities);
        placeholderEntity.setPlaceholderGroupTagTypes(groupTagTypeEntities);
        log.info(placeholderEntity.toString());
        log.info(placeholderEntity.getPlaceholderTemplate().toString());
    }

    TestTemplate createTestTemplate(String name, String attributeName, Long attributeValue)
        throws IOException {
        TestTemplate testTemplate = TestTemplateUtils.buildTemplate(null, name);
        if (!StringUtils.isEmpty(attributeName)) {
            testTemplate.setAttributes(TestTemplateUtils.buildTemplateAttributes(attributeName, attributeValue));
        }
        Template savedTestTemplate = templatePersistencyService.createTemplate(TestUtils.TEST_TENANT, testTemplate);
        assertThat(savedTestTemplate.getId()).isEqualTo(testTemplate.getId());
        return testTemplate;
    }

    TestTemplate createTestTemplate(String name, Map<String, String> reservedAttributes)
        throws IOException {
        TestTemplate testTemplate = TestTemplateUtils.buildTemplate(null, name);
        if (reservedAttributes != null && reservedAttributes.size() > 0) {
            if (reservedAttributes.get("state") != null) {
                testTemplate.setState(reservedAttributes.get("state"));
            } else if (reservedAttributes.get("status") != null) {
                testTemplate.setStatus(reservedAttributes.get("status"));
            }
        }
        Template savedTestTemplate = templatePersistencyService.createTemplate(TestUtils.TEST_TENANT, testTemplate);
        assertThat(savedTestTemplate.getId()).isEqualTo(testTemplate.getId());
        return testTemplate;
    }

    TestPlaceholder createTestPlaceholder(TestTemplate testTemplate, String ppn) throws IOException {
        TestPlaceholder testPlaceholder = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), ppn, null);
        Placeholder savedPlaceholder = placeholderPersistencyService
            .createPlaceholder(TestUtils.TEST_TENANT, testTemplate.getId(), testPlaceholder);
        assertThat(savedPlaceholder.getId()).isEqualTo(testPlaceholder.getId());
        return testPlaceholder;
    }

    TestPlaceholderType createTestPlaceholderType(TestPlaceholder testPlaceholder, AssetType assetType) {
        TestPlaceholderType testPlaceholderType = TestTemplateUtils
            .buildPlaceholderType(testPlaceholder.getId(), assetType.getId());
        PlaceholderType savedTestPlaceholderType =
            placeholderTypePersistencyService.createPlaceholderType(TestUtils.TEST_TENANT, testPlaceholderType);
        assertThat(savedTestPlaceholderType.getId()).isEqualTo(testPlaceholderType.getId());
        return testPlaceholderType;
    }

    AssetType createAssetType(String supperTypeId, String name)
        throws IOException, PersistencyServiceException {
        AssetType assetType = TestTemplateUtils.buildAssetTye(supperTypeId, name);
        AssetType savedAssetType = assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT, assetType);
        assertThat(assetType.getId()).isEqualTo(savedAssetType.getId());
        return assetType;
    }

    TestPlaceholderTemplate createTestPlaceholderTemplate(TestPlaceholder testPlaceholder,
        TestTemplate subTemplate) {
        TestPlaceholderTemplate testPlaceholderTemplate = TestTemplateUtils
            .buildPlaceholderTemplate(testPlaceholder.getId(), subTemplate.getId());
        PlaceholderTemplate savedTestPlaceholderTemplate =
            placeholderTemplatePersistencyService
                .createPlaceholderTemplate(TestUtils.TEST_TENANT, testPlaceholderTemplate);
        assertThat(savedTestPlaceholderTemplate.getId()).isEqualTo(testPlaceholderTemplate.getId());
        return testPlaceholderTemplate;
    }

    TestPlaceholderTagType createTestPlaceholderTagType(TestPlaceholder testPlaceholder,
        AssetType assetType) {
        TestPlaceholderTagType testPlaceholderTagType = TestTemplateUtils
            .buildPlaceholderTagType(testPlaceholder.getId(), assetType.getId());
        PlaceholderTagType savedTestPlaceholderTagType =
            placeholderTagTypePersistencyService
                .createPlaceholderTagType(TestUtils.TEST_TENANT, testPlaceholderTagType);
        assertThat(savedTestPlaceholderTagType.getId()).isEqualTo(testPlaceholderTagType.getId());
        return testPlaceholderTagType;
    }

    TestPlaceholderGroupTagType createTestPlaceholderGroupTagType(TestPlaceholder testPlaceholder,
        AssetGroup assetGroup) {
        TestPlaceholderGroupTagType testPlaceholderGroupTagType = TestTemplateUtils
            .buildPlaceholderGroupTagType(testPlaceholder.getId(), assetGroup.getId());
        PlaceholderGroupTagType savedTestPlaceholderGroupTagType =
            placeholderGroupTagTypePersistencyService
                .createPlaceholderGroupTagType(TestUtils.TEST_TENANT, testPlaceholderGroupTagType);
        assertThat(savedTestPlaceholderGroupTagType.getId()).isEqualTo(testPlaceholderGroupTagType.getId());
        return testPlaceholderGroupTagType;
    }

    TestAssetGroup createAssetGroup(String groupName) throws PersistencyServiceException {
        TestAssetGroup assetGroup = TestTemplateUtils
            .buildAssetGroup(groupName, AssetGroupCategory.TAG_TYPE);
        AssetGroup savedAssetGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        assertThat(assetGroup.getId()).isEqualTo(savedAssetGroup.getId());
        return assetGroup;
    }

    TestNotes createNotes(String content) throws IOException {
        TestNotes notes = TestTemplateUtils.buildNotes(TestUtils.TEST_TENANT, content);
        Notes savedNotes = notesPersistencyService.createNote(TestUtils.TEST_TENANT, notes);
        assertThat(savedNotes.getId()).isEqualTo(notes.getId());
        assertThat(savedNotes.getContent()).isEqualTo(notes.getContent());
        return notes;
    }

    TestTemplateNotes createTemplateNotes(String templateId, TestNotes testNotes) {
        TestTemplateNotes templateNotes = TestTemplateUtils.buildTestTemplateNotes(templateId, testNotes);
        templateNotePersistencyService.createTemplateNote(TestUtils.TEST_TENANT, templateNotes);
        return templateNotes;
    }
}
