/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.UUID;

import com.google.common.collect.Sets;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_SEGMENT_TYPE_ID;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUnPrivileged;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests asset searches using {@link com.ge.apm.alm.model.query.AssetPredicate}, with
 * {@link com.ge.apm.alm.model.query.TypePredicate} only.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetSearchByParentTests {

    private static final UUID NULL_UUID = new UUID(0L, 0L);
    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;
    @Autowired
    private AssetPersistencyService assetPersistencyService;

    /**
     * Search assets where (parent id = "E1_S1"), without deep search, accessible from parent
     */
    @Test
    @Transactional
    public void getAssets_byParentId() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder()
                .parent(ParentPredicate.builder().ids(Sets.newHashSet(data.get("E1_S1").getId())).build()).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg1"), data.get("E1_S2")),
                predicate)).hasSize(0);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);

        AssetPredicate nullParentPredicate =
            AssetPredicate.builder()
                .parent(ParentPredicate.builder().ids(Sets.newHashSet(NULL_UUID.toString())).build()).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), nullParentPredicate))
            .hasSize(1).extracting(Asset::getName).containsOnly("E1");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), nullParentPredicate))
            .hasSize(1).extracting(Asset::getName).containsOnly("E1");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")),
                nullParentPredicate)).hasSize(0);
    }

    /**
     * Search assets where (parent id = "E1_S1"), without deep search, accessible from parent
     */
    @Test
    @Transactional
    public void getAssets_byParentId_deepSearch() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder()
            .parent(ParentPredicate.builder().ids(Sets.newHashSet(data.get("E1_S1").getId())).deepSearch(true).build())
            .build();

        String[] expectedNames =
            { "E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3", "E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2",
                "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3", "E1_S1_Seg3_C3" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(10).extracting(Asset::getName).containsOnly(expectedNames);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(10).extracting(Asset::getName).containsOnly(expectedNames);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(10).extracting(Asset::getName).containsOnly(expectedNames);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(
                data.get("E1_S1_Seg1"), data.get("E1_S1_Seg2"), data.get("E1_S1_Seg3")),
                predicate)).hasSize(0);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Search assets where (name = ? and parent id = ?), without deep search
     */
    @Test
    @Transactional
    public void getAssets_byNameWithParentId() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().name("*1")
                .parent(ParentPredicate.builder().ids(Sets.newHashSet(data.get("E1_S1").getId())).build())
                .build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(1).extracting(Asset::getName).containsOnly("E1_S1_Seg1");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(1).extracting(Asset::getName).containsOnly("E1_S1_Seg1");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(1).extracting(Asset::getName).containsOnly("E1_S1_Seg1");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg1")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Search assets where (name = ? and parent id = ?), without deep search
     */
    @Test
    @Transactional
    public void getAssets_byNameWithParentId_deepSearch() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().name("*1")
            .parent(ParentPredicate.builder().ids(Sets.newHashSet(data.get("E1_S1").getId())).deepSearch(true).build())
            .build();

        String[] expectedNames = { "E1_S1_Seg1", "E1_S1_Seg1_A1", "E1_S1_Seg1_B1" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly(expectedNames);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly(expectedNames);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly(expectedNames);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg1")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Search assets where (parent name = "E1_S1"), without deep search, accessible from parent
     */
    @Test
    @Transactional
    public void getAssets_byParentName() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().parent(ParentPredicate.builder().name("E1_S1").build()).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg1"), data.get("E1_S2")),
                predicate)).hasSize(0);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Search assets where (parent id = "E1_S1"), without deep search, accessible from parent
     */
    @Test
    @Transactional
    public void getAssets_byParentName_deepSearch() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder()
            .parent(ParentPredicate.builder().name("E1_S1").deepSearch(true).build()).build();

        String[] expectedNames =
            { "E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3", "E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2",
                "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3", "E1_S1_Seg3_C3" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(10).extracting(Asset::getName).containsOnly(expectedNames);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(10).extracting(Asset::getName).containsOnly(expectedNames);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(10).extracting(Asset::getName).containsOnly(expectedNames);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT,
                    getUnPrivileged(data.get("E1_S1_Seg1"), data.get("E1_S1_Seg2"), data.get("E1_S1_Seg3")),
                predicate)).hasSize(0);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Search assets where (parent name = "E1_S1"), without deep search, accessible from parent
     */
    @Test
    @Transactional
    public void getAssets_byParentNameOrSourceKey() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().parent(ParentPredicate.builder().name("E1_S1").build()).build();
        predicate.getParent().setChildOperand(Operand.OR);
        predicate.getParent()
            .setChildPredicates(Collections.singletonList(ParentPredicate.builder().sourceKey("E1_S1").build()));

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg1"), data.get("E1_S2")),
                predicate)).hasSize(0);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Search assets where (name = ? and parent name = ?), without deep search
     */
    @Test
    @Transactional
    public void getAssets_byNameWithParentName() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate =
            AssetPredicate.builder().name("*1").parent(ParentPredicate.builder().name("E1_S1").build())
                .build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(1).extracting(Asset::getName).containsOnly("E1_S1_Seg1");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(1).extracting(Asset::getName).containsOnly("E1_S1_Seg1");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(1).extracting(Asset::getName).containsOnly("E1_S1_Seg1");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg1")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Search assets where (name = ? and parent id = ?), without deep search
     */
    @Test
    @Transactional
    public void getAssets_byNameWithParentName_deepSearch() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder().name("*1")
            .parent(ParentPredicate.builder().name("E1_S1").deepSearch(true).build()).build();

        String[] expectedNames = { "E1_S1_Seg1", "E1_S1_Seg1_A1", "E1_S1_Seg1_B1" };
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly(expectedNames);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly(expectedNames);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly(expectedNames);
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg1")), predicate))
            .hasSize(0);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Search assets where (parent name = "E1_S1"), without deep search, accessible from parent
     */
    @Test
    @Transactional
    public void getAssets_byParentTypeName_deepSearch() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetPredicate predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().ids(Sets.newHashSet(ROOT_SEGMENT_TYPE_ID)).deepSearch(true).build())
            .parent(
                ParentPredicate.builder().type(TypePredicate.builder().name("S1Type*").deepSearch(true).build())
                    .deepSearch(true).build())
            .build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1")), predicate))
            .hasSize(3).extracting(Asset::getName).containsOnly("E1_S1_Seg1", "E1_S1_Seg2", "E1_S1_Seg3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, getUnPrivileged(data.get("E1_S1_Seg1"), data.get("E1_S2")),
                predicate)).hasSize(0);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, getUnPrivileged(), predicate))
            .hasSize(0);
    }

    Map<String, BaseDataModel> setupData() throws IOException {
        return PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService, assetPersistencyService);
    }
}
