/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.template;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.NotesPredicate;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.TemplateNotesPredicate;
import com.ge.apm.alm.model.query.TemplatePredicate;
import com.ge.apm.alm.persistence.TemplatePersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.model.TestNotes;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholder;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderTagType;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderTemplate;
import com.ge.apm.alm.persistence.jpa.model.TestTemplate;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestTemplateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

/**
 * Tests the JPA Persistency Layer
 */
public class TemplatePersistSvcTests extends TemplatePersistSvcBaseTests {

    private static final String TEST_TEMPLATE_NAME = "GE90_Engine_Template";

    @Autowired
    private TemplatePersistencyService templatePersistencyService;

    @Test
    @Transactional
    public void testCreateTemplateWithAllData() throws IOException, PersistencyServiceException {
        TestTemplate template = createTestTemplate("GE90_template", "TYPE_XXX", 200L);
        TestTemplate subTemplate = createTestTemplate("GE90_sub_template", "TYPE_XXX", 20L);

        TestNotes testNotes = createNotes("this is Junit test for " + TestUtils.TEST_TENANT);
        createTemplateNotes(template.getId(), testNotes);

        TestPlaceholder placeholder1 = createTestPlaceholder(template, "PPN01");
        TestPlaceholder placeholder2 = createTestPlaceholder(template, "PPN02");

        TestPlaceholderTemplate testPlaceholderTemplate = createTestPlaceholderTemplate(placeholder1, subTemplate);

        AssetType assetType1 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, "GE90");
        AssetType assetType2 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, "GE90_115B");
        createTestPlaceholderType(placeholder1, assetType1);
        createTestPlaceholderType(placeholder2, assetType2);

        AssetType tagType = createAssetType("203d4660-702c-3cc9-8399-5663b9378408", "GE90 TAG CS");
        TestPlaceholderTagType placeholderTagType = createTestPlaceholderTagType(placeholder2, tagType);

        TestAssetGroup testAssetGroup1 = createAssetGroup("GE90_tagType_group_1");
        TestAssetGroup testAssetGroup2 = createAssetGroup("GE90_tagType_group_2");
        createTestPlaceholderGroupTagType(placeholder2, testAssetGroup1);
        createTestPlaceholderGroupTagType(placeholder2, testAssetGroup2);

        //retrieve template from database based on Id
        Template dbTemplate = templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, template.getId());
        assertThat(dbTemplate.getId()).isEqualTo(template.getId());
        assertThat(dbTemplate.getTemplateNotes().size()).isEqualTo(1);
        assertThat(dbTemplate.getTemplateNotes().get(0).getNotes().getContent()).isEqualTo(testNotes.getContent());

        final List<Placeholder> dbPlaceholders = dbTemplate.getPlaceholders();
        assertThat(dbPlaceholders.size()).isEqualTo(2);

        for (Placeholder placeholder : dbPlaceholders) {
            if (placeholder.getId().equals(placeholder1.getId())) {
                assertThat(placeholder.getPlaceholderTemplate().getId()).isEqualTo(testPlaceholderTemplate.getId());
            } else if (placeholder.getId().equals(placeholder2.getId())) {
                assertThat(placeholder.getPlaceholderTypes().size()).isEqualTo(1);
                assertThat(placeholder.getPlaceholderTypes().get(0).getPrimary()).isEqualTo(Boolean.TRUE);
                assertThat(placeholder.getPlaceholderTagTypes().size()).isEqualTo(1);
                assertThat(placeholder.getPlaceholderTagTypes().get(0).getId()).isEqualTo(placeholderTagType.getId());
                assertThat(placeholder.getPlaceholderGroupTagTypes().size()).isEqualTo(2);
            } else {
                throw new IllegalArgumentException("unknown placeholder Id:" + placeholder.getId());
            }
        }

        deleteTestTemplateCascade(dbTemplate);
    }

    @Test
    @Transactional
    public void testCreateTemplate() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = TestTemplateUtils.buildTemplate(null, TEST_TEMPLATE_NAME);
        testTemplate.setAttributes(TestTemplateUtils.buildTemplateAttributes("TYPE_XXX", 20));

        final String tenantId = TestUtils.TEST_TENANT;
        final String testTemplateSourceKey = testTemplate.getSourceKey();
        Template savedTestTemplate = templatePersistencyService.createTemplate(tenantId, testTemplate);
        Template dbTemplate = templatePersistencyService.getTemplateBySourceKey(tenantId, testTemplateSourceKey);
        assertThat(dbTemplate).isNotNull();
        assertThat(savedTestTemplate.getId()).isEqualTo(testTemplate.getId());
        assertThat(savedTestTemplate.getSourceKey()).isEqualTo(testTemplateSourceKey);
        assertThat(dbTemplate.getId()).isEqualTo(testTemplate.getId());
        assertThat(dbTemplate.getSourceKey()).isEqualTo(testTemplateSourceKey);
        assertThat(dbTemplate.getAttributes()).isEqualTo(TestTemplateUtils.buildTemplateAttributes("TYPE_XXX", 20));

        deleteTestTemplateById(testTemplate.getId());
    }

    @Transactional
    @Test(expected = IllegalArgumentException.class)
    public void testCreateTemplate_TenantIdMissMatch() throws IOException {
        TestTemplate testTemplate = TestTemplateUtils.buildTemplate(null, TEST_TEMPLATE_NAME);
        testTemplate.setTenantId("UNKNOWN_TENANT_ID");
        templatePersistencyService.createTemplate(TestUtils.TEST_TENANT, testTemplate);
    }

    @Transactional
    @Test(expected = IllegalArgumentException.class)
    public void testCreateTemplate_MissingSourceKey() throws IOException {
        TestTemplate testTemplate = TestTemplateUtils.buildTemplate(null, TEST_TEMPLATE_NAME);
        testTemplate.setSourceKey(null);
        templatePersistencyService.createTemplate(TestUtils.TEST_TENANT, testTemplate);
    }

    @Transactional
    @Test(expected = IllegalArgumentException.class)
    public void testCreateTemplate_MissingName() throws IOException {
        TestTemplate testTemplate = TestTemplateUtils.buildTemplate(null, TEST_TEMPLATE_NAME);
        testTemplate.setName(null);
        templatePersistencyService.createTemplate(TestUtils.TEST_TENANT, testTemplate);
    }

    @Transactional
    @Test(expected = IllegalArgumentException.class)
    public void testCreateTemplate_MissingState() throws IOException {
        TestTemplate testTemplate = TestTemplateUtils.buildTemplate(null, TEST_TEMPLATE_NAME);
        testTemplate.setState(null);
        templatePersistencyService.createTemplate(TestUtils.TEST_TENANT, testTemplate);
    }

    @Transactional
    @Test(expected = IllegalArgumentException.class)
    public void testCreateTemplate_MissingStatus() throws IOException {
        TestTemplate testTemplate = TestTemplateUtils.buildTemplate(null, TEST_TEMPLATE_NAME);
        testTemplate.setStatus(null);
        templatePersistencyService.createTemplate(TestUtils.TEST_TENANT, testTemplate);
    }

    @Test
    @Transactional
    public void testCreateTemplates() throws IOException, PersistencyServiceException {
        List<Template> testTemplates = new ArrayList<>();
        int counter = templatePersistencyService.createTemplates(TestUtils.TEST_TENANT, testTemplates);
        assertThat(0).isEqualTo(counter);

        TestTemplate testTemplate1 = TestTemplateUtils.buildTemplate(null, TEST_TEMPLATE_NAME + "10");
        TestTemplate testTemplate2 = TestTemplateUtils.buildTemplate(null, TEST_TEMPLATE_NAME + "11");
        testTemplates.add(testTemplate1);
        testTemplates.add(testTemplate2);
        counter = templatePersistencyService.createTemplates(TestUtils.TEST_TENANT, testTemplates);
        assertThat(2).isEqualTo(counter);

        deleteTestTemplateById(testTemplate1.getId());
        deleteTestTemplateById(testTemplate2.getId());
    }

    @Test
    @Transactional
    public void testUpdateTemplate() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate(TEST_TEMPLATE_NAME, null, null);
        testTemplate.setDescription(null);
        templatePersistencyService.updateTemplate(TestUtils.TEST_TENANT, testTemplate);

        deleteTestTemplateById(testTemplate.getId());
    }

    @Test
    @Transactional
    public void testUpdateTemplates() throws IOException, PersistencyServiceException {
        int counter = templatePersistencyService.createTemplates(TestUtils.TEST_TENANT, new ArrayList<>());
        assertThat(0).isEqualTo(counter);

        TestTemplate testTemplate1 = TestTemplateUtils.buildTemplate(null, TEST_TEMPLATE_NAME + "20");
        TestTemplate testTemplate2 = TestTemplateUtils.buildTemplate(null, TEST_TEMPLATE_NAME + "21");
        templatePersistencyService.createTemplate(TestUtils.TEST_TENANT, testTemplate1);
        templatePersistencyService.createTemplate(TestUtils.TEST_TENANT, testTemplate2);

        List<Template> updatedTemplates = new ArrayList<>();
        testTemplate1.setDescription("Updated desc1");
        testTemplate2.setDescription("Updated desc2");
        updatedTemplates.add(testTemplate1);
        updatedTemplates.add(testTemplate2);
        counter = templatePersistencyService.updateTemplates(TestUtils.TEST_TENANT, updatedTemplates);
        assertThat(2).isEqualTo(counter);

        deleteTestTemplateById(testTemplate1.getId());
        deleteTestTemplateById(testTemplate2.getId());
    }

    @Test
    @Transactional
    public void testDeleteTemplateById() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate(TEST_TEMPLATE_NAME, null, null);

        Template dbTemplate = templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, testTemplate.getId());
        assertThat(dbTemplate.getId()).isEqualTo(testTemplate.getId());
        assertThat(dbTemplate.getSourceKey()).isEqualTo(testTemplate.getSourceKey());

        templatePersistencyService.deleteTemplateById(TestUtils.TEST_TENANT, dbTemplate.getId());
        assertThat(templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, testTemplate.getId())).isNull();
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeleteTemplateById_NotFoundExcetion() throws PersistencyServiceException {
        templatePersistencyService.deleteTemplateById(TestUtils.TEST_TENANT, TestTemplateUtils.getNewUuid());
    }

    @Test
    @Transactional
    public void testGetTemplateById() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate(TEST_TEMPLATE_NAME, null, null);

        Template dbTemplate = templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, testTemplate.getId());
        assertThat(dbTemplate).isNotNull();
        assertThat(dbTemplate.getId()).isEqualTo(testTemplate.getId());
        assertThat(dbTemplate.getSourceKey()).isEqualTo(testTemplate.getSourceKey());

        deleteTestTemplateById(testTemplate.getId());
    }

    @Test
    @Transactional
    public void testGetTemplateById_EmptyResultDataAccessException() {
        Template dbTemplate = templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT,
            TestTemplateUtils.getNewUuid());
        assertThat(dbTemplate).isNull();
    }

    @Test
    @Transactional
    public void testGetTemplateBySourceKey() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate(TEST_TEMPLATE_NAME, null, null);

        Template dbTemplate = templatePersistencyService.getTemplateBySourceKey(TestUtils.TEST_TENANT,
            testTemplate.getSourceKey());
        assertThat(dbTemplate).isNotNull();
        assertThat(dbTemplate.getId()).isEqualTo(testTemplate.getId());
        assertThat(dbTemplate.getSourceKey()).isEqualTo(testTemplate.getSourceKey());

        // verify case-insensitive search
        dbTemplate = templatePersistencyService.getTemplateBySourceKey(TestUtils.TEST_TENANT,
            testTemplate.getSourceKey().toUpperCase(Locale.getDefault()));
        assertThat(dbTemplate).isNotNull();
        assertThat(dbTemplate.getId()).isEqualTo(testTemplate.getId());
        assertThat(dbTemplate.getSourceKey()).isEqualTo(testTemplate.getSourceKey());

        deleteTestTemplateById(testTemplate.getId());
    }

    @Test
    @Transactional
    public void getTemplatesBySourceKeys() throws IOException {
        String[] sourceKeys = {"TemplateA", "TemplateB", "TemplateC"};
        for (String srcKey : sourceKeys) {
            TestTemplate testTemplate = TestTemplateUtils.buildTemplate(srcKey, srcKey);
            assertThat(templatePersistencyService.createTemplate(TestUtils.TEST_TENANT, testTemplate)).isNotNull();
        }

        assertThat(
            templatePersistencyService.getTemplatesBySourceKeys(TestUtils.TEST_TENANT, Arrays.asList(sourceKeys)))
            .hasSize(sourceKeys.length).extracting(Template::getSourceKey).containsOnly(sourceKeys);
    }

    @Test
    @Transactional
    public void testGetTemplateBySourceKey_EmptyResultDataAccessException() {
        Template dbTemplate = templatePersistencyService
            .getTemplateBySourceKey(TestUtils.TEST_TENANT, TestTemplateUtils.getNewUuid());
        assertThat(dbTemplate).isNull();
    }

    @Test
    @Transactional
    public void testGetTemplateWithReservedAttributes()throws IOException, PersistencyServiceException {
        Map<String, String> reservedAttributes = new HashMap<>();
        reservedAttributes.put("state", "03");
        reservedAttributes.put("status", "02");
        TestTemplate testTemplate3 = createTestTemplate(TEST_TEMPLATE_NAME + "32", reservedAttributes);
        assertThat(templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, testTemplate3.getId()))
            .isNotNull();

        TemplatePredicate parentTemplatePredicate = new TemplatePredicate();
        parentTemplatePredicate.setChildOperand(Operand.AND);

        TemplatePredicate childSourceKeyPredicate = new TemplatePredicate();
        childSourceKeyPredicate.setSourceKey(testTemplate3.getSourceKey());
        childSourceKeyPredicate.setPeerOperand(Operand.OR);

        TemplatePredicate childStateAttributePredicate = new TemplatePredicate();
        Map<String, String> stateReservedAttribute = new HashMap<>();
        stateReservedAttribute.put("state,key", "01~,02~,03");
        childStateAttributePredicate.setReservedAttributes(stateReservedAttribute);
        childStateAttributePredicate.setPeerOperand(Operand.OR);

        TemplatePredicate childStatusAttributePredicate = new TemplatePredicate();
        Map<String, String> statusReservedAttribute = new HashMap<>();
        statusReservedAttribute.put("status,key", "01~,02~,03");
        childStatusAttributePredicate.setReservedAttributes(statusReservedAttribute);

        List<TemplatePredicate> childPredicates = new ArrayList<>();
        childPredicates.add(childSourceKeyPredicate);
        childPredicates.add(childStateAttributePredicate);
        childPredicates.add(childStatusAttributePredicate);
        parentTemplatePredicate.setChildPredicates(childPredicates);

        List<Template> foundTemplate =
            templatePersistencyService.getTemplates(TestUtils.TEST_TENANT, parentTemplatePredicate);

        assertThat(foundTemplate).isNotNull();
        assertThat(foundTemplate.size()).isEqualTo(1);
        assertThat(foundTemplate.get(0).getId()).isEqualTo(testTemplate3.getId());
        assertThat(foundTemplate.get(0).getAttributes()).isEqualTo(testTemplate3.getAttributes());
        assertThat(foundTemplate.get(0).getState()).isEqualTo(testTemplate3.getState());
        assertThat(foundTemplate.get(0).getStatus()).isEqualTo(testTemplate3.getStatus());

        deleteTestTemplateById(testTemplate3.getId());
    }

    @Test
    @Transactional
    public void testGetTemplates() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate1 = createTestTemplate(TEST_TEMPLATE_NAME + "30", "TYPE_XXX", 20L);
        TestTemplate testTemplate2 = createTestTemplate(TEST_TEMPLATE_NAME + "31", "TYPE_XXX", 50L);

        assertThat(templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, testTemplate1.getId()))
            .isNotNull();
        assertThat(templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, testTemplate2.getId()))
            .isNotNull();

        Arrays.stream(AttributeSelectEnum.values()).forEach(attributeSelectEnum -> {
            TemplatePredicate templatePredicate = new TemplatePredicate();
            templatePredicate.setAttributeSelectEnum(attributeSelectEnum);

            final String tenantId = TestUtils.TEST_TENANT;
            templatePredicate.setChildPredicates(constructReservedAttributes(true, true, testTemplate1, null));
            List<Template> foundTemplate = templatePersistencyService.getTemplates(tenantId, templatePredicate);
            assertThat(foundTemplate).isNotNull();
            assertThat(foundTemplate.size()).isEqualTo(1);
            assertThat(foundTemplate.get(0).getId()).isEqualTo(testTemplate1.getId());

            templatePredicate.setChildPredicates(constructReservedAttributes(true, false, testTemplate1, null));
            foundTemplate = templatePersistencyService.getTemplates(tenantId, templatePredicate);
            assertThat(foundTemplate).isNotNull();
            assertThat(foundTemplate.size()).isEqualTo(1);
            assertThat(foundTemplate.get(0).getId()).isEqualTo(testTemplate1.getId());

            templatePredicate.setChildPredicates(constructReservedAttributes(false, true, testTemplate1, null));
            foundTemplate = templatePersistencyService.getTemplates(tenantId, templatePredicate);
            assertThat(foundTemplate).isNotNull();
            assertThat(foundTemplate.size()).isEqualTo(1);
            assertThat(foundTemplate.get(0).getId()).isEqualTo(testTemplate1.getId());

            templatePredicate.setChildPredicates(constructReservedAttributes(false, false, testTemplate1, null));
            foundTemplate = templatePersistencyService.getTemplates(tenantId, templatePredicate);
            assertThat(foundTemplate).isNotNull();
            assertThat(foundTemplate.size()).isEqualTo(1);
            assertThat(foundTemplate.get(0).getId()).isEqualTo(testTemplate1.getId());

            templatePredicate.setChildPredicates(constructReservedAttributes(false, false, testTemplate1, "*"));
            foundTemplate = templatePersistencyService.getTemplates(tenantId, templatePredicate);
            assertThat(foundTemplate).isNotNull();
            assertThat(foundTemplate.size()).isEqualTo(1);
            assertThat(foundTemplate.get(0).getId()).isEqualTo(testTemplate1.getId());
        });

        deleteTestTemplateById(testTemplate1.getId());
        deleteTestTemplateById(testTemplate2.getId());
    }

    @Test
    @Transactional
    public void testGetTemplates_PagingWithSortKey() throws IOException {
        int pageSize = 5;
        int numPages = 4;
        int numTemplates = pageSize * numPages;
        for (int i = 0; i < numTemplates; i++) {
            createTestTemplate(TEST_TEMPLATE_NAME + i, "TYPE_" + i, 20L);
        }

        TemplatePredicate predicate = new TemplatePredicate();
        predicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        List<Template> all = templatePersistencyService.getTemplates(TestUtils.TEST_TENANT, predicate);
        assertThat(all).hasSize(numTemplates);

        predicate.setPagingInfo(0, pageSize, null, true);
        List<Template> found = templatePersistencyService.getTemplates(TestUtils.TEST_TENANT, predicate);
        assertThat(found).hasSize(pageSize);
        assertThat(found.stream().map(Template::getId).collect(Collectors.toList()))
            .containsExactlyElementsOf(all.subList(0, pageSize).stream()
                .map(Template::getId).collect(Collectors.toList()));

        String sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        assertThat(sortKey).isNotEmpty();

        int offset = pageSize;
        while (offset < pageSize * numPages) {
            predicate.setPagingInfo(1, pageSize, sortKey, true);
            found = templatePersistencyService.getTemplates(TestUtils.TEST_TENANT, predicate);
            assertThat(found).hasSize(pageSize);
            assertThat(found.stream().map(Template::getId).collect(Collectors.toList()))
                .containsExactlyElementsOf(all.subList(offset, offset + pageSize).stream()
                    .map(Template::getId).collect(Collectors.toList()));
            offset += pageSize;
            sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        }

        predicate.setPagingInfo(1, pageSize, sortKey, true);
        assertThat(templatePersistencyService.getTemplates(TestUtils.TEST_TENANT, predicate)).isEmpty();
    }

    private void deleteTestTemplateById(String id) throws PersistencyServiceException {
        templatePersistencyService.deleteTemplateById(TestUtils.TEST_TENANT, id);
        assertThat(templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, id)).isNull();
    }

    private void deleteTestTemplateCascade(Template template) throws PersistencyServiceException {
        String templateId = template.getId();
        final String tenantId = TestUtils.TEST_TENANT;
        templatePersistencyService.deleteTemplateById(tenantId, templateId);

        assertThat(templatePersistencyService.getTemplateById(tenantId, templateId)).isNull();

        TemplateNotesPredicate templateNotesPredicate = new TemplateNotesPredicate();
        templateNotesPredicate.setTemplateId(templateId);
        assertThat(templateNotePersistencyService.getTemplateNotes(tenantId, templateNotesPredicate)).isEmpty();

        final NotesPredicate notesPredicate = new NotesPredicate();
        notesPredicate.setContent("this is Junit test for " + TestUtils.TEST_TENANT);
        assertThat(notesPersistencyService.getNotes(tenantId, notesPredicate)).isEmpty();

        assertThat(placeholderPersistencyService.getPlaceholdersByTemplateId(tenantId, templateId)).isEmpty();
        assertThat(placeholderTypePersistencyService.getPlaceholderTypeByTemplateId(tenantId, templateId)).isEmpty();
        assertThat(placeholderTemplatePersistencyService.getPlaceholderTemplates(tenantId, templateId)).isEmpty();
        assertThat(placeholderTagTypePersistencyService.getPlaceholderTagTypeByTemplateId(tenantId, templateId))
            .isEmpty();
        assertThat(
            placeholderGroupTagTypePersistencyService.getPlaceholderGroupTagTypeByTemplateId(tenantId, templateId))
            .isEmpty();
    }

    private List<TemplatePredicate> constructReservedAttributes(boolean isStateRequired, boolean isStatusRequired,
        TestTemplate testTemplate1, String name) {

        List<TemplatePredicate> childPredicates = new ArrayList<>();
        TemplatePredicate childStateAttributePredicate = new TemplatePredicate();
        TemplatePredicate childStatusAttributePredicate = new TemplatePredicate();
        TemplatePredicate attributePredicate = new TemplatePredicate();

        if (isStateRequired) {
            Map<String, String> stateReservedAttribute = new HashMap<>();
            stateReservedAttribute.put("state,key", testTemplate1.getState());
            childStateAttributePredicate.setReservedAttributes(stateReservedAttribute);
            childStateAttributePredicate.setPeerOperand(Operand.AND);
        }
        if (isStatusRequired) {
            Map<String, String> statusReservedAttribute = new HashMap<>();
            statusReservedAttribute.put("status,key", testTemplate1.getStatus());
            childStatusAttributePredicate.setReservedAttributes(statusReservedAttribute);
        }

        Map<String, String> attributes = new HashMap<>();
        attributes.put("test string", "TYPE_XXX");
        attributePredicate.setAttributes(attributes);
        attributePredicate.setPeerOperand(Operand.AND);

        TemplatePredicate sourceKeyPredicate = new TemplatePredicate();
        sourceKeyPredicate.setSourceKey(testTemplate1.getSourceKey());
        sourceKeyPredicate.setPeerOperand(Operand.AND);

        TemplatePredicate namePredicate = new TemplatePredicate();
        namePredicate.setName(name != null ? name : testTemplate1.getName());
        namePredicate.setPeerOperand(Operand.AND);

        TemplatePredicate descPredicate = new TemplatePredicate();
        descPredicate.setDescription(testTemplate1.getDescription());
        descPredicate.setPeerOperand(Operand.AND);
        descPredicate.setChildOperand(Operand.AND);

        childPredicates.add(attributePredicate);
        childPredicates.add(sourceKeyPredicate);
        childPredicates.add(namePredicate);
        childPredicates.add(descPredicate);
        if (childStateAttributePredicate.getReservedAttributes() != null) {
            childPredicates.add(childStateAttributePredicate);
        }
        if (childStatusAttributePredicate.getReservedAttributes() != null) {
            childPredicates.add(childStatusAttributePredicate);
        }
        return childPredicates;
    }
}
