/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.group;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.GroupPredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.DataIntegrityViolationException;
import com.ge.apm.alm.persistence.exceptions.IncompatibleItemsException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetGroupEntity;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroupItem;
import com.ge.apm.alm.persistence.jpa.utils.GroupUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUnPrivileged;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.assertj.core.api.Assertions.failBecauseExceptionWasNotThrown;

/**
 * Tests the JPA Persistency Layer
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class GroupPersistSvcTests {

    @Autowired
    private GroupPersistencyService groupPersistencyService;

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private TagPersistencyService tagPersistencyService;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    @After
    public void tearDown() {
        TestUtils.destroyAssetUserPolicies();
    }

    @Test
    @Transactional
    public void basicGroupTests() {
        try {
            AssetGroup assetGroup = GroupUtils.createAssetGroup("Group1", AssetGroupCategory.ASSET);
            groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
            AssetGroup assetGroupCr = groupPersistencyService.getAssetGroupById(TestUtils.TEST_TENANT,
                assetGroup.getId());
            assertThat(assetGroupCr).isNotNull();
            assertThat(assetGroupCr.getName()).isEqualTo("Group1");
            assetGroupCr = groupPersistencyService.getAssetGroupBySourceKey(TestUtils.TEST_TENANT, "Group1");
            assertThat(assetGroupCr.getName()).isEqualTo("Group1");

            GroupPredicate queryPredicate = GroupPredicate.builder().name("Group1").build();
            assertThat(groupPersistencyService.getAssetGroups(TestUtils.TEST_TENANT, queryPredicate)).hasSize(1).
                extracting(AssetGroup::getName).containsOnly(assetGroup.getName());

            AssetGroup dupGroup = GroupUtils.createAssetGroup("DupGroup", AssetGroupCategory.ASSET);
            groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, dupGroup);
            AssetGroup dupGroup2 = GroupUtils.createAssetGroup("DupGroup", AssetGroupCategory.ASSET);
            groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, dupGroup2);
            failBecauseExceptionWasNotThrown(PersistencyServiceException.class);
        } catch (PersistencyServiceException pse) {
            assertThat(pse.getCause()).isInstanceOf(JpaSystemException.class);
        }
    }

    @Test
    @Transactional
    public void createAssetGroups() throws PersistencyServiceException {
        List<AssetGroup> groups = Arrays.asList(GroupUtils.createAssetGroup("Group1", AssetGroupCategory.ASSET),
            GroupUtils.createAssetGroup("Group2", AssetGroupCategory.TAG));
        assertThat(groupPersistencyService.createAssetGroups(TestUtils.TEST_TENANT, groups)).isEqualTo(groups.size());
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void createGroup_tenantIdMismatch() throws PersistencyServiceException {
        AssetGroup group = GroupUtils.createAssetGroup("group", AssetGroupCategory.TAG);
        groupPersistencyService.createAssetGroup(UUID.randomUUID().toString(), group);
    }

    @Test
    @Transactional
    public void getAssetGroupsBySourceKeys() throws PersistencyServiceException {
        String[] sourceKeys = { "GroupA", "GroupB", "GroupC" };
        for (String srcKey : sourceKeys) {
            AssetGroup assetGroup = GroupUtils.createAssetGroup(srcKey, AssetGroupCategory.ASSET);
            groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        }

        assertThat(groupPersistencyService.getAssetGroupsBySourceKeys(TestUtils.TEST_TENANT, Arrays.asList(sourceKeys)))
            .hasSize(sourceKeys.length).extracting(AssetGroup::getSourceKey).containsOnly(sourceKeys);
    }

    @Test
    @Transactional
    public void getAssetGroups_byNameDescriptionSourceKey() throws PersistencyServiceException {
        String name = "Group1";
        AssetGroup assetGroup = GroupUtils.createAssetGroup(name, AssetGroupCategory.ASSET);
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup)).isNotNull();
        assertThat(groupPersistencyService.getAssetGroupById(TestUtils.TEST_TENANT, assetGroup.getId()).getName())
            .isEqualTo(name);
        assertThat(groupPersistencyService
            .getAssetGroupBySourceKey(TestUtils.TEST_TENANT, name.toUpperCase(Locale.getDefault())).getName())
            .isEqualTo(name);
        assertThat(groupPersistencyService
            .getAssetGroupBySourceKey(TestUtils.TEST_TENANT, name.toLowerCase(Locale.getDefault())).getName())
            .isEqualTo(name);

        GroupPredicate queryPredicate = GroupPredicate.builder().name(name).sourceKey(name).description(name)
            .categories(Collections.singletonList(AssetGroupCategory.ASSET)).build();
        assertThat(groupPersistencyService.getAssetGroups(TestUtils.TEST_TENANT, queryPredicate)).hasSize(1).extracting(
            AssetGroup::getName).containsOnly(assetGroup.getName());
        queryPredicate.setName(name.toUpperCase(Locale.getDefault()));
        queryPredicate.setDescription(name.toLowerCase(Locale.getDefault()));
        queryPredicate.setSourceKey(name.toUpperCase(Locale.getDefault()));
        assertThat(groupPersistencyService.getAssetGroups(TestUtils.TEST_TENANT, queryPredicate)).hasSize(1).extracting(
            AssetGroup::getName).containsOnly(assetGroup.getName());
    }

    @Test
    @Transactional
    public void getAssetGroupBySourceKey_nullOrEmptySourceKey() throws PersistencyServiceException {
        assertThat(groupPersistencyService.getAssetGroupBySourceKey(TestUtils.TEST_TENANT, null)).isNull();
        assertThat(groupPersistencyService.getAssetGroupBySourceKey(TestUtils.TEST_TENANT, "")).isNull();
        assertThat(groupPersistencyService.getAssetGroupBySourceKey(TestUtils.TEST_TENANT, TestUtils.NULL_UUID))
            .isNull();
    }

    @Test
    @Transactional
    public void getAssetGroupsBySourceKeys_emptySourceKeys() throws PersistencyServiceException {
        assertThat(groupPersistencyService.getAssetGroupsBySourceKeys(TestUtils.TEST_TENANT, Collections.emptyList()))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void createGroupsAndGroupItemsAndQueryTest() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = GroupUtils.setupData(assetTypePersistencyService, assetPersistencyService,
            tagPersistencyService);

        AssetGroup assetGroup = GroupUtils.createAssetGroup("Group1", AssetGroupCategory.ASSET);
        AssetGroup assetGroupCr = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);

        Asset e2 = (Asset) data.get("E2");
        Asset e2_asset1 = (Asset) data.get("E2_Asset1");
        Asset e1 = (Asset) data.get("E1");
        Asset e1_s1_seg1_asset1 = (Asset) data.get("E1_S1_Seg1_Asset1");
        Asset e1_s1_seg1_asset2 = (Asset) data.get("E1_S1_Seg1_Asset2");

        TestAssetGroupItem e1_item1 = GroupUtils.createAssetGroupItem(assetGroup.getId(), e1_s1_seg1_asset1.getId());
        TestAssetGroupItem e1_item2 = GroupUtils.createAssetGroupItem(assetGroup.getId(), e1_s1_seg1_asset2.getId());

        int createdItemCount = groupPersistencyService.createAssetGroupItems(TestUtils.TEST_TENANT,
            getUnPrivileged(e1), assetGroupCr.getId(), Arrays.asList(e1_item1, e1_item2));
        assertThat(createdItemCount).isEqualTo(2);

        AssetGroup assetGroup2 = GroupUtils.createAssetGroup("Group2", AssetGroupCategory.ASSET);
        AssetGroup assetGroup2Cr = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup2);
        TestAssetGroupItem asset1_item1 = GroupUtils.createAssetGroupItem(assetGroup2.getId(),
            e1_s1_seg1_asset1.getId());
        groupPersistencyService.createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1),
            assetGroup2Cr.getId(), Arrays.asList(asset1_item1));

        //Item1 belongs to 2 groups.
        List<AssetGroup> assetGroups2 = groupPersistencyService.getAssetGroupsOfItem(TestUtils.TEST_TENANT,
            AssetGroupCategory.ASSET, e1_s1_seg1_asset1.getId());
        assertThat(assetGroups2).hasSize(2).
            extracting(asset -> asset.getName()).containsOnly(assetGroup.getName(), assetGroup2.getName());

        Map<String, List<AssetGroup>> objectToGroup = groupPersistencyService.getAssetGroupsOfItems(
            TestUtils.TEST_TENANT, AssetGroupCategory.ASSET, Arrays.asList(e1_s1_seg1_asset1.getId()), false);
        assertThat(objectToGroup.entrySet()).hasSize(1).flatExtracting(Map.Entry::getValue).extracting(
            AssetGroup::getName).containsOnly(assetGroup.getName(), assetGroup2.getName());

        objectToGroup = groupPersistencyService.getAssetGroupsOfItems(TestUtils.TEST_TENANT, AssetGroupCategory.ASSET,
            Arrays.asList(e1_s1_seg1_asset1.getId(), e1_s1_seg1_asset2.getId()), true);
        assertThat(objectToGroup).hasSize(2).containsOnlyKeys(e1_s1_seg1_asset1.getId(), e1_s1_seg1_asset2.getId());
        assertThat(objectToGroup.get(e1_s1_seg1_asset1.getId())).extracting(AssetGroup::getName).containsOnly(
            assetGroup.getName(), assetGroup2.getName());
        assertThat(objectToGroup.get(e1_s1_seg1_asset2.getId())).extracting(AssetGroup::getName).containsOnly(
            assetGroup.getName());

        objectToGroup = groupPersistencyService.getAssetGroupsOfItems(TestUtils.TEST_TENANT, AssetGroupCategory.ASSET,
            Arrays.asList(e1_s1_seg1_asset2.getId()), true);
        assertThat(objectToGroup).containsOnlyKeys(e1_s1_seg1_asset2.getId());
        assertThat(objectToGroup.entrySet()).hasSize(1).flatExtracting(Map.Entry::getValue).extracting(
            AssetGroup::getName).containsOnly(assetGroup.getName());

        List<AssetGroupItem> items = groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1),
            assetGroupCr.getId());
        assertThat(items).hasSize(2).
            extracting(asset -> asset.getId()).containsOnly(e1_item1.getId(), e1_item2.getId());

        items = groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e2),
            assetGroupCr.getId());
        assertThat(items).hasSize(0);

        //more access control constraints
        items = groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1_s1_seg1_asset1),
            assetGroupCr.getId());
        assertThat(items).hasSize(1).extracting(asset -> asset.getId()).containsExactly(e1_item1.getId());

        try {
            int deletedCount = groupPersistencyService.deleteAssetGroupItems(TestUtils.TEST_TENANT,
                getUnPrivileged(e1), assetGroup.getId());
            assertThat(deletedCount).isEqualTo(2);
            groupPersistencyService.deleteAssetGroup(TestUtils.TEST_TENANT, assetGroup.getId());
        } catch (PersistencyServiceException e) {
            fail("Not expecting to fail with PersistencyServiceException Integrity voilation", e);
        }

        AssetGroup assetGroup22 = GroupUtils.createAssetGroup("Group22", AssetGroupCategory.ASSET);
        AssetGroup assetGroupCr22 = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup22);

        TestAssetGroupItem e1_item10 = GroupUtils.createAssetGroupItem(assetGroupCr22.getId(),
            e1_s1_seg1_asset1.getId());
        TestAssetGroupItem e1_item20 = GroupUtils.createAssetGroupItem(assetGroupCr22.getId(),
            e1_s1_seg1_asset2.getId());

        createdItemCount = groupPersistencyService.createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1),
            assetGroupCr22.getId(), Arrays.asList(e1_item10, e1_item20));
        assertThat(createdItemCount).isEqualTo(2);

        try {
            groupPersistencyService.deleteAssetGroupRecursively(TestUtils.TEST_TENANT, getUnPrivileged(e1),
                assetGroupCr22.getId());
        } catch (PersistencyServiceException e) {
            fail("Not expecting to fail with exception", e);
        }

        //Creating again to test data integrity voilation exception,
        AssetGroup assetGroup3 = GroupUtils.createAssetGroup("Group3", AssetGroupCategory.ASSET);
        AssetGroup assetGroupCr3 = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup3);

        TestAssetGroupItem e1_item11 = GroupUtils.createAssetGroupItem(assetGroupCr3.getId(),
            e1_s1_seg1_asset1.getId());
        TestAssetGroupItem e1_item22 = GroupUtils.createAssetGroupItem(assetGroupCr3.getId(),
            e1_s1_seg1_asset2.getId());
        TestAssetGroupItem e2_item11 = GroupUtils.createAssetGroupItem(assetGroupCr3.getId(), e2_asset1.getId());

         createdItemCount = groupPersistencyService.createAssetGroupItems(TestUtils.TEST_TENANT,
            getUnPrivileged(e1, e2), assetGroupCr3.getId(), Arrays.asList(e1_item11, e1_item22, e2_item11));
        assertThat(createdItemCount).isEqualTo(3);

        //Because of accessibleResources_e2 only e2_item11 will be deleted as part of below call,
        //leading to DataIntegrityViolationException
        try {
            groupPersistencyService.deleteAssetGroupRecursively(TestUtils.TEST_TENANT, getUnPrivileged(e2),
                assetGroupCr3.getId());
            failBecauseExceptionWasNotThrown(DataIntegrityViolationException.class);
        } catch (PersistencyServiceException e) {
            assertThat(e).isInstanceOf(DataIntegrityViolationException.class);
        }

        //Transaction rolled back..
    }

    @Test
    @Transactional
    public void negativeTestCases() {
        AssetType enterpriseType, enterpriseType2, enterpriseType2SubType;
        Asset e1, e2, e1_s1;
        AssetGroup assetGroup, assetGroupCr;
        TestAssetGroupItem groupItem_1, groupItem_2, groupItem_3;
        Map<String, BaseDataModel> data;
        try {
            data = GroupUtils.setupData(assetTypePersistencyService, assetPersistencyService, tagPersistencyService);
            enterpriseType = (AssetType) data.get("MyEnterpriseType");
            enterpriseType2 = (AssetType) data.get("MyEnterpriseType2");
            enterpriseType2SubType = (AssetType) data.get("MyEnterpriseType2SubType");
            e1 = (Asset) data.get("E1");
            e2 = (Asset) data.get("E2");
            e1_s1 = (Asset) data.get("E1_S1");
        } catch (Exception e) {
            fail("Not expected to fail", e);
            return;
        }
        try {
            assetGroup = GroupUtils.createAssetGroup("Group1", AssetGroupCategory.ASSET);
            assetGroupCr = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
            groupItem_1 = GroupUtils.createAssetGroupItem(assetGroup.getId(), e1.getId());
            groupItem_2 = GroupUtils.createAssetGroupItem(assetGroup.getId(), e1_s1.getId());
            groupPersistencyService.createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1),
                assetGroupCr.getId(), Arrays.asList(groupItem_1, groupItem_2));
            failBecauseExceptionWasNotThrown(IncompatibleItemsException.class);
        } catch (IncompatibleItemsException pse) {
            //expected
        } catch (PersistencyServiceException e) {
            fail("Not expected to fail", e);
        }

        try {
            assetGroup = GroupUtils.createAssetGroup("Group3", AssetGroupCategory.ENTERPRISE_TYPE);
            assetGroupCr = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
            groupItem_1 = GroupUtils.createAssetGroupItem(assetGroup.getId(), enterpriseType.getId());
            groupItem_2 = GroupUtils.createAssetGroupItem(assetGroup.getId(), enterpriseType2.getId());
            groupItem_3 = GroupUtils.createAssetGroupItem(assetGroup.getId(), enterpriseType2SubType.getId());
            int items = groupPersistencyService.createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1),
                assetGroupCr.getId(), Arrays.asList(groupItem_1, groupItem_2, groupItem_3));
            assertThat(items).isEqualTo(3);
            assertThat(groupPersistencyService
                .getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(enterpriseType),
                    assetGroupCr.getId())).hasSize(3);
        } catch (Exception pse) {
            fail("Exception is not expected here ", pse);
        }

        GroupPredicate queryPredicate = GroupPredicate.builder().categories(
            Collections.singletonList(AssetGroupCategory.ASSET)).build();
        assertThat(groupPersistencyService.getAssetGroups(TestUtils.TEST_TENANT, queryPredicate)).hasSize(1).extracting(
            AssetGroup::getName).containsOnly("Group1");

        queryPredicate = GroupPredicate.builder().categories(
            Collections.singletonList(AssetGroupCategory.ENTERPRISE_TYPE)).build();
        assertThat(groupPersistencyService.getAssetGroups(TestUtils.TEST_TENANT, queryPredicate)).hasSize(1).extracting(
            AssetGroup::getName).containsOnly("Group3");

        queryPredicate = GroupPredicate.builder().categories(
            Arrays.asList(AssetGroupCategory.ASSET, AssetGroupCategory.ENTERPRISE_TYPE)).build();
        assertThat(groupPersistencyService.getAssetGroups(TestUtils.TEST_TENANT, queryPredicate)).hasSize(2).extracting(
            AssetGroup::getName).containsOnly("Group3", "Group1");

        //adding tag instances and asset instances in one group should fail with exception
        try {
            assetGroup = GroupUtils.createAssetGroup("Group4", AssetGroupCategory.TAG);
            assetGroupCr = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
            Tag tag = (Tag) data.get("E1_S1_Seg1_Asset1_Tag1");
            groupItem_1 = GroupUtils.createAssetGroupItem(assetGroup.getId(), e1.getId());
            groupItem_2 = GroupUtils.createAssetGroupItem(assetGroup.getId(), tag.getId());
            groupPersistencyService.createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1),
                assetGroupCr.getId(), Arrays.asList(groupItem_1, groupItem_2));
            failBecauseExceptionWasNotThrown(IncompatibleItemsException.class);
        } catch (IncompatibleItemsException pse) {
            //expected
        } catch (PersistencyServiceException e) {
            fail("Exception is not expected here ", e);
        }

        //adding tag instances and asset instances in one group should fail with exception
        try {
            assetGroup = GroupUtils.createAssetGroup("Group5", AssetGroupCategory.TAG);
            assetGroupCr = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
            Tag e1_tag1 = (Tag) data.get("E1_S1_Seg1_Asset1_Tag1");
            Tag e2_tag2 = (Tag) data.get("E2_Asset1_Tag1");
            groupItem_1 = GroupUtils.createAssetGroupItem(assetGroup.getId(), e1_tag1.getId());
            groupItem_2 = GroupUtils.createAssetGroupItem(assetGroup.getId(), e2_tag2.getId());
            groupPersistencyService.createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e2),
                assetGroupCr.getId(), Arrays.asList(groupItem_1, groupItem_2));
            failBecauseExceptionWasNotThrown(IncompatibleItemsException.class);
        } catch (IncompatibleItemsException pse) {
            //expected
        } catch (PersistencyServiceException e) {
            fail("Exception is not expected here ", e);
        }
    }

    @Test(expected = UnsupportedOperationException.class)
    @Transactional
    public void deleteAssetGroupItems_tagCorrelationCategoryNotSupported() throws PersistencyServiceException {
        AssetGroup group = GroupUtils.createAssetGroup("Group1", AssetGroupCategory.TAG_CORRELATION);
        groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group);
        groupPersistencyService.deleteAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), group.getId(),
            Collections.singletonList(TestUtils.NULL_UUID));
    }

    @Test
    @Transactional
    public void deleteAssetGroupItems_byItemIds_asPriviledged() throws IOException, PersistencyServiceException {
        AssetType enterpriseType, siteType;
        AssetGroup assetGroup, assetGroupCr;
        enterpriseType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID, "MyEnterpriseType");

        siteType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_SITE_TYPE_ID,
            "MySiteType");

        Asset e1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            enterpriseType.getId(), null, "E1");
        List<Asset> sites = new ArrayList<>();
        int count = 2;
        for (int i = 0; i < count; i++) {
            sites.add(TestUtils
                .createAssetInstanceAndAssert(assetPersistencyService, getUnPrivileged(e1), siteType.getId(),
                    e1.getId(), "E1_S" + i));
        }
        assetGroup = GroupUtils.createAssetGroup("Group1", AssetGroupCategory.SITE);
        assetGroupCr = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        List<AssetGroupItem> grpItems = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            grpItems.add(GroupUtils.createAssetGroupItem(assetGroup.getId(), sites.get(i).getId()));
        }
        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1), assetGroupCr.getId(), grpItems))
            .isEqualTo(count);
        List<String> grpItemIds = grpItems.stream().map(AssetGroupItem::getId).collect(Collectors.toList());

        assertThat(groupPersistencyService
            .deleteAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1), assetGroup.getId(), grpItemIds))
            .isEqualTo(count);
        assertThat(
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(e1), assetGroup.getId()))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void deleteAssetGroupItems_byItemIds_asUber() throws IOException, PersistencyServiceException {
        AssetType enterpriseType, siteType;
        AssetGroup assetGroup, assetGroupCr;
        enterpriseType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID, "MyEnterpriseType");

        siteType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_SITE_TYPE_ID,
            "MySiteType");

        Asset e1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            enterpriseType.getId(), null, "E1");
        List<Asset> sites = new ArrayList<>();
        int count = 2;
        for (int i = 0; i < count; i++) {
            sites.add(TestUtils
                .createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), siteType.getId(),
                    e1.getId(), "E1_S" + i));
        }
        assetGroup = GroupUtils.createAssetGroup("Group1", AssetGroupCategory.SITE);
        assetGroupCr = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        List<AssetGroupItem> grpItems = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            grpItems.add(GroupUtils.createAssetGroupItem(assetGroup.getId(), sites.get(i).getId()));
        }
        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupCr.getId(), grpItems))
            .isEqualTo(count);
        List<String> grpItemIds = grpItems.stream().map(AssetGroupItem::getId).collect(Collectors.toList());

        assertThat(groupPersistencyService
            .deleteAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroup.getId(), grpItemIds))
            .isEqualTo(count);
        assertThat(
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroup.getId()))
            .hasSize(0);

        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroupCr.getId(), grpItems))
            .isEqualTo(count);
        try {
            groupPersistencyService.deleteAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(),
                assetGroup.getId(), grpItemIds);
            fail("Unprividged user cannot delete group items.");
        } catch (PersistencyServiceException pse) {
            // ignore, it's expected
        }
    }

    @Test
    @Transactional
    public void getAndDeleteAssetGroupItems_byItemIds_decommissioned() throws IOException, PersistencyServiceException {
        AssetType siteType, assetType;
        AssetGroup assetGroup, assetGroupCr;

        siteType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_SITE_TYPE_ID,
            "MySiteType");
        assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_ASSET_TYPE_ID,
            "MyAssetType");

        Asset s1 = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(),
            siteType.getId(), null, "S1");

        TestUtils.createAssetUserPolicies(assetPolicyPersistencyService, TestUtils.VIEW_DECOMM_FCODE,
            SeedOOTBData.ROOT_ASSET_TYPE_ID);

        List<Asset> assets = new ArrayList<>();
        int count = 4;
        for (int i = 0; i < count; i++) {
            Asset asset = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, getUnPrivileged(s1),
                assetType.getId(), s1.getId(), "S1_A" + i);
            String state = (i % 2 == 0) ? "10" : "310";
            ((ObjectNode) asset.getAttributes().path("reservedAttributes").path("state")).put("key", state);
            assets.add(assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), asset));
        }
        assetGroup = GroupUtils.createAssetGroup("Group1", AssetGroupCategory.ASSET);
        assetGroupCr = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        List<AssetGroupItem> grpItems = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            grpItems.add(GroupUtils.createAssetGroupItem(assetGroup.getId(), assets.get(i).getId()));
        }
        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(s1), assetGroupCr.getId(), grpItems))
            .isEqualTo(count);
        List<String> grpItemIds = grpItems.stream().map(AssetGroupItem::getId).collect(Collectors.toList());

        assertThat(
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(s1), assetGroup.getId()))
            .hasSize(4);

        TestUtils.destroyAssetUserPolicies();

        assertThat(
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(s1), assetGroup.getId()))
            .hasSize(2);

        try {
            groupPersistencyService.deleteAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(s1),
                assetGroup.getId(), grpItemIds);
        } catch (PersistencyServiceException pse) {
            assertThat(pse.getMessage()).isEqualTo("Unable to delete all the group items 4");
        }

        assertThat(
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(s1), assetGroup.getId()))
            .hasSize(0);

        TestUtils.createAssetUserPolicies(assetPolicyPersistencyService, TestUtils.VIEW_DECOMM_FCODE,
            SeedOOTBData.ROOT_ASSET_TYPE_ID);

        assertThat(
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(s1), assetGroup.getId()))
            .hasSize(2);

        assertThat(
            groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroup.getId()))
            .hasSize(2);

        assertThat(groupPersistencyService
            .deleteAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroup.getId(),
                Arrays.asList(grpItemIds.get(0)))).isEqualTo(1);

        assertThat(groupPersistencyService
            .deleteAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroup.getId(),
                Arrays.asList(grpItemIds.get(2)))).isEqualTo(1);
    }

    @Test
    @Transactional
    public void createNonCorrelatedGroup_sourceKeyNotNull() {
        AssetGroup assetGroup = GroupUtils.createAssetGroup("Group1", AssetGroupCategory.SITE);
        ((TestAssetGroup) assetGroup).setSourceKey(null);
        try {
            groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
            fail("Null source key is not allowed for " + assetGroup.getCategory() + " group");
        } catch (PersistencyServiceException pse) {
            assertThat(pse.getCause()).isInstanceOf(JpaSystemException.class);
        }
    }

    @Test
    @Transactional
    public void updateNonCorrelatedGroup_sourceKeyNotNull() throws PersistencyServiceException {
        AssetGroup assetGroup = GroupUtils.createAssetGroup("Group1", AssetGroupCategory.TAG_TYPE);
        AssetGroup created = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);
        ((AssetGroupEntity) created).setSourceKey(null);
        try {
            groupPersistencyService.updateAssetGroup(TestUtils.TEST_TENANT, created);
            fail("Null source key is not allowed for " + assetGroup.getCategory() + " group");
        } catch (PersistencyServiceException pse) {
            assertThat(pse.getCause()).isInstanceOf(JpaSystemException.class);
        } catch (JpaSystemException jse) {
            // success
        } catch (Exception e) {
            fail("Expected " + JpaSystemException.class.getSimpleName());
        }
    }
}
