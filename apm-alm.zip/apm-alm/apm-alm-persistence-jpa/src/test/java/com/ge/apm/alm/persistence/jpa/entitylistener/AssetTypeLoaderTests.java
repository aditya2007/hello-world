/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetTypeLoaderTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private AssetTypeLoader assetTypeLoader;

    @Test
    @Transactional
    public void testLoadAsset() throws IOException {
        AssetType assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, "T1");
        Asset asset = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetType.getId(), null, "A1");

        AssetInstanceEntity loadedAsset =
            (AssetInstanceEntity) assetPersistencyService.getAssetById(TestUtils.TEST_TENANT,
                TestUtils.getUber(), asset.getId());
        assertThat(loadedAsset.getType()).isNull();

        assetTypeLoader.postLoad(TestUtils.TEST_TENANT, null, loadedAsset,
            AttributeSelectEnum.FULL, EnumSet.noneOf(AssetComponent.class));
        assertThat(loadedAsset.getType()).isNull();

        assetTypeLoader.postLoad(TestUtils.TEST_TENANT, null, loadedAsset,
            AttributeSelectEnum.FULL, EnumSet.of(AssetComponent.TYPE));
        assertAssetTypeAttached(loadedAsset, assetType.getId());
    }

    @Test
    @Transactional
    public void testLoadAssetList() throws IOException {
        AssetType assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, "T1");
        Asset asset = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetType.getId(), null, "A1");

        AssetType siteType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_SITE_TYPE_ID, "T1");
        Asset site = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), siteType.getId(), null, "S1");

        List<AssetInstanceEntity> loadedList = new ArrayList<>(2);
        loadedList.add((AssetInstanceEntity) assetPersistencyService
            .getAssetById(TestUtils.TEST_TENANT, TestUtils.getUber(), asset.getId()));
        loadedList.add((AssetInstanceEntity) assetPersistencyService
            .getAssetById(TestUtils.TEST_TENANT, TestUtils.getUber(), site.getId()));

        assetTypeLoader.postLoad(TestUtils.TEST_TENANT, null, loadedList,
            AttributeSelectEnum.FULL, EnumSet.noneOf(AssetComponent.class));
        assertThat(loadedList.get(0).getType()).isNull();
        assertThat(loadedList.get(1).getType()).isNull();

        assetTypeLoader.postLoad(TestUtils.TEST_TENANT, null, loadedList,
            AttributeSelectEnum.FULL, EnumSet.of(AssetComponent.TYPE));
        assertAssetTypeAttached(loadedList.get(0), assetType.getId());
        assertAssetTypeAttached(loadedList.get(1), siteType.getId());
    }

    private void assertAssetTypeAttached(AssetInstanceEntity loadedAsset, String expectedTypeId) {
        AssetType loadedType = loadedAsset.getType();
        assertThat(loadedType).isNotNull();
        assertThat(loadedType.getId()).isEqualTo(loadedAsset.getAssetType());
        assertThat(loadedType.getId()).isEqualTo(expectedTypeId);
    }

}
