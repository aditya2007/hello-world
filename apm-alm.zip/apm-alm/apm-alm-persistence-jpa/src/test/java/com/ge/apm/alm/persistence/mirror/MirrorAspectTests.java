/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.mirror;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyCollection;
import static org.mockito.Matchers.anyString;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class MirrorAspectTests {

    @Mock
    AssetEventPersistencyService eventService;

    @Mock
    TagPersistencyService tagService;

    @Mock
    GroupPersistencyService groupService;

    @Mock
    AssetPersistencyService assetService;

    @Mock
    AssetTypePersistencyService assetTypeService;

    @InjectMocks
    MirrorAspect mirrorAspect;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Ignore
    @Test
    @Transactional
    public void testAccessibleResourcesIsUsed() throws PersistencyServiceException {
        String methodName = "createTags";
        Object[] args = new Object[] {
            MirrorTestUtils.randomUUID(), // tenantID
            Arrays.asList(
                MirrorTestUtils.createTag(MirrorTestUtils.randomUUID(), MirrorTestUtils.randomUUID()),
                MirrorTestUtils.createTag(MirrorTestUtils.randomUUID(), MirrorTestUtils.randomUUID()),
                MirrorTestUtils.createTag(MirrorTestUtils.randomUUID(), MirrorTestUtils.randomUUID())
            ),
            Arrays.asList(
                "resourceBART",
                "resourceHOMER"
            )
        };
        Annotation[] annotations = new Annotation[] {
            null, // tenantId
            MirrorTestUtils.createMirror(null, null),
            MirrorTestUtils.createAccessible()
        };

        JoinPoint joinPoint = mockJoinPoint(methodName, args, annotations, null);
        Collection<MirrorableParam> params = mirrorAspect.collectMirrorableParams(joinPoint, null);

        Assert.assertEquals(3, params.size());

        for (MirrorableParam p : params) {
            Assert.assertEquals(2, p.getAccessibleResources().size());
            Assert.assertTrue(p.getAccessibleResources().contains("resourceBART"));
            Assert.assertTrue(p.getAccessibleResources().contains("resourceHOMER"));
        }
    }

    @Ignore
    @Test
    @Transactional
    public void testMakingDeleteTagEventsForGivenAsset() throws PersistencyServiceException {
        String tenantId = MirrorTestUtils.randomUUID();
        String assetId = MirrorTestUtils.randomUUID();
        Asset asset = MirrorTestUtils.createAsset(assetId, OOTBCoreTypesIdLookup.SegmentType, OffsetDateTime.now());
        MirrorableParam param = new MirrorableParam(tenantId, "doIt",
            MirrorTestUtils.createMirror(Type.DELETE_TAGS, null), asset, null, new ArrayList<>());

        List<Tag> tags = new ArrayList<>();
        tags.add(MirrorTestUtils.createTag(MirrorTestUtils.randomUUID(), assetId));
        tags.add(MirrorTestUtils.createTag(MirrorTestUtils.randomUUID(), assetId));
        tags.add(MirrorTestUtils.createTag(MirrorTestUtils.randomUUID(), assetId));
        Mockito.when(tagService.getTagsForAsset(anyString(), anyCollection(), anyString(), anyBoolean(), any()))
            .thenReturn(tags);

        Collection<AssetEvent> events = mirrorAspect.resolveToEvents(param);
        Assert.assertEquals(3, events.size());
        Assert.assertEquals("Tag", events.iterator().next().getObjectType());
    }

    private JoinPoint mockJoinPoint(String methodName, Object[] args, Annotation[] annotations,
        Mirror methodAnnotation) {

        assert args.length == annotations.length;

        Annotation[][] annotationsMatrix = new Annotation[args.length][1];
        for (int i = 0; i < args.length; i++) {
            if (annotations[i] != null) {
                annotationsMatrix[i] = new Annotation[] { annotations[i] };
            }
        }

        Method method = Mockito.mock(Method.class);
        Mockito.when(method.getParameterAnnotations()).thenReturn(annotationsMatrix);
        if (methodAnnotation != null) {
            Mockito.when(method.getAnnotation(Mirror.class)).thenReturn(methodAnnotation);
        }

        MethodSignature methodSignature = Mockito.mock(MethodSignature.class);
        Mockito.when(methodSignature.getMethod()).thenReturn(method);
        Mockito.when(methodSignature.getName()).thenReturn(methodName);

        JoinPoint joinPoint = Mockito.mock(JoinPoint.class);
        Mockito.when(joinPoint.getSignature()).thenReturn(methodSignature);
        Mockito.when(joinPoint.getArgs()).thenReturn(args);

        return joinPoint;
    }
}

