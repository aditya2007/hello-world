/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupAssociation;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroupAssociation;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.createAssetInstanceAndAssert;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.createAssetTypeAndAssert;

public final class AssetGroupAssociationUtils {

    private AssetGroupAssociationUtils() {
    }

    public static AssetGroupAssociation createAssetGroupAssociation(String groupId, String objectId) {
        return TestAssetGroupAssociation.builder().id(UUID.randomUUID().toString()).tenantId(TenantTestUtils.getTenantId())
            .groupId(groupId).objectId(objectId).build();
    }

    public static Map<String, BaseDataModel> setupData(AssetTypePersistencyService assetTypePersistencyService,
        AssetPersistencyService assetPersistencyService,
        GroupPersistencyService groupPersistencyService)
        throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> assetData = new HashMap<>();
        AssetType assetType = createAssetTypeAndAssert(assetTypePersistencyService, SeedOOTBData.ROOT_ASSET_TYPE_ID,
            "MyAssetType");
        Asset assetInstance =
            createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), assetType.getId(),
                null, "A1");
        Asset assetInstance2 =
            createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), assetType.getId(),
                null, "A2");
        AssetGroup assetGroup = GroupUtils.createAssetGroup("Group1", AssetGroupCategory.ASSET);
        AssetGroup assetGroupCr = groupPersistencyService.createAssetGroup(TenantTestUtils.getTenantId(), assetGroup);
        AssetGroup assetGroup2 = GroupUtils.createAssetGroup("Group2", AssetGroupCategory.ASSET);
        AssetGroup assetGroupCr2 = groupPersistencyService.createAssetGroup(TenantTestUtils.getTenantId(), assetGroup2);
        assetData.put("MyAssetType", assetType);
        assetData.put("A1", assetInstance);
        assetData.put("A2", assetInstance2);
        assetData.put("Group1", assetGroupCr);
        assetData.put("Group2", assetGroupCr2);
        return assetData;
    }
}
