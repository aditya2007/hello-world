/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.network;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.assertj.core.util.Maps;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.Network;
import com.ge.apm.alm.model.query.NetworkElementEnum;
import com.ge.apm.alm.model.query.NetworkPredicate;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.NetworkPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.utils.NetworkUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * @author Venkata Bhaverisetti 212432041
 * @version 1.0 July 15, 2017
 * @since 1.0
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class NetworkSearchTests {

    @Autowired
    private NetworkPersistencyService networkPersistencyService;

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Test
    @Transactional
    public void testQueryByName_childPredicatesOnly() {
        try {
            //Given: Setup test networks
            List<Network> networks = Arrays.asList(
                    NetworkUtils.createNetwork("network-A1", null),
                    NetworkUtils.createNetwork("network-A12", null),
                    NetworkUtils.createNetwork("network-A121", null),
                    NetworkUtils.createNetwork("network-B1", null));
            networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(),
                    networks);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                    .childOperand(Operand.AND)
                    .childPredicates(
                            Arrays.asList(NetworkPredicate
                                    .builder().name("network-A1*").build())).build();

            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(3);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNameOrDescription() {
        try {
            //Given: Setup test networks
            List<Network> networks = Arrays.asList(
                    NetworkUtils.createNetwork("network-A1", null),
                    NetworkUtils.createNetwork("network-A12", null),
                    NetworkUtils.createNetwork("network-A121", null),
                    NetworkUtils.createNetwork("network-B1", null));
            networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(),
                    networks);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                    .childOperand(Operand.AND)
                    .childPredicates(Arrays.asList(
                            NetworkPredicate.builder().name("network-A1*").peerOperand(Operand.OR).build(),
                            NetworkPredicate.builder().description("description-*").build()))
                    .build();
            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(4)
                    .extracting(Network::getDescription)
                    .containsOnly("description-network-A1", "description-network-A12",
                            "description-network-A121", "description-network-B1");
        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByStringReservedAttributeEquals() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().reservedAttributes(
                            Maps.newHashMap("Test String", "abc"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-E-parent-of-A,B,C", "network-F-empty");

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByStringReservedAttributeFullLike() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().reservedAttributes(
                            Maps.newHashMap("Test String", "*b*"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-E-parent-of-A,B,C", "network-F-empty");

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByStringReservedAttributeLeftLike() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().reservedAttributes(
                            Maps.newHashMap("Test String", "*bc"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-E-parent-of-A,B,C", "network-F-empty");

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByStringReservedAttributeRightLike() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().reservedAttributes(
                            Maps.newHashMap("Test String", "ab*"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-E-parent-of-A,B,C", "network-F-empty");

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNumberAttributeEquals() {

        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().attributes(
                            Maps.newHashMap("Test Number", String.valueOf(Integer.MIN_VALUE)))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-E-parent-of-A,B,C", "network-F-empty");

            networkPredicate.setAttributes(Maps.newHashMap("Test Number", "123"));
            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(0);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }


    @Test
    @Transactional
    public void testQueryByStringAttributeEquals() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().attributes(
                            Maps.newHashMap("serialNumber", "GE12345"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-E-parent-of-A,B,C", "network-F-empty");

            networkPredicate.setAttributes(Maps.newHashMap("Test String", "*@@@@@*"));
            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(0);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByStringAttributeFullLike() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().attributes( //GE12345
                            Maps.newHashMap("serialNumber", "*E123*"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-E-parent-of-A,B,C", "network-F-empty");

            networkPredicate.setAttributes(Maps.newHashMap("Test String", "*@@@@@*"));
            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(0);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByStringAttributeRightLike() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().attributes(
                            Maps.newHashMap("serialNumber", "GE12*"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-E-parent-of-A,B,C", "network-F-empty");

            networkPredicate.setAttributes(Maps.newHashMap("Test String", "@@@@@*"));
            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(0);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByStringAttributeLeftLike() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().attributes(
                            Maps.newHashMap("serialNumber", "*12345")) //GE12345
                        .build()))
                .build();

            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-E-parent-of-A,B,C", "network-F-empty");

            networkPredicate.setAttributes(Maps.newHashMap("Test String", "*@@@@@"));
            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(0);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNameAndDescription_Paginated() {
        try {
            //Given: Setup test networks
            List<Network> networks = Arrays.asList(
                    NetworkUtils.createNetwork("network-A1", null),
                    NetworkUtils.createNetwork("network-A12", null),
                    NetworkUtils.createNetwork("network-A121", null),
                    NetworkUtils.createNetwork("network-B1", null));
            networkPersistencyService.createNetworks(TestUtils.TEST_TENANT, TestUtils.getUber(),
                    networks);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                    .childOperand(Operand.AND)
                    .childPredicates(Arrays.asList(
                            NetworkPredicate.builder().name("network-A1*").peerOperand(Operand.AND).build(),
                            NetworkPredicate.builder().description("description-*").build()))
                    .pageSize(2).offset(1)
                    .build();
            assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2);
        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeName_childPredicatesOnly() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().networkElementEnum(NetworkElementEnum.NODE).name("A1").build())).build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeNameAndDescription() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(Arrays.asList(
                    NetworkPredicate.builder().networkElementEnum(NetworkElementEnum.NODE).name("A1*").peerOperand(Operand.AND).build(),
                    NetworkPredicate.builder().networkElementEnum(NetworkElementEnum.NODE).description("A1*").build()
                )).build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeNameOrDescription() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(Arrays.asList(
                    NetworkPredicate.builder().networkElementEnum(NetworkElementEnum.NODE).name("A1*").peerOperand(Operand.OR).build(),
                    NetworkPredicate.builder().networkElementEnum(NetworkElementEnum.NODE).description("A2*").build()
                )).build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeStringReservedAttributeEquals() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().networkElementEnum(NetworkElementEnum.NODE).reservedAttributes(
                            Maps.newHashMap("Test String", "abc"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-B-A1,A4,A5-D", "network-A-A1,A2,A3");

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeStringReservedAttributeFullLike() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().networkElementEnum(NetworkElementEnum.NODE).reservedAttributes(
                            Maps.newHashMap("Test String", "*b*"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-B-A1,A4,A5-D", "network-A-A1,A2,A3");

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeStringReservedAttributeLeftLike() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().networkElementEnum(NetworkElementEnum.NODE).reservedAttributes(
                            Maps.newHashMap("Test String", "*bc"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-B-A1,A4,A5-D", "network-A-A1,A2,A3");

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeStringReservedAttributeRightLike() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().networkElementEnum(NetworkElementEnum.NODE).reservedAttributes(
                            Maps.newHashMap("Test String", "ab*"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-B-A1,A4,A5-D", "network-A-A1,A2,A3");

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeNumberAttributeEquals() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().networkElementEnum(NetworkElementEnum.NODE).attributes(
                            Maps.newHashMap("Test Number", String.valueOf(Integer.MIN_VALUE)))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-B-A1,A4,A5-D", "network-A-A1,A2,A3");

            networkPredicate.setAttributes(Maps.newHashMap("Test Number", "123"));
            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(0);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeStringAttributeEquals() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().networkElementEnum(NetworkElementEnum.NODE).attributes(
                            Maps.newHashMap("serialNumber", "GE12345"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-B-A1,A4,A5-D", "network-A-A1,A2,A3");

            networkPredicate.setAttributes(Maps.newHashMap("Test String", "*@@@@@*"));
            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(0);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeStringAttributeFullLike() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().networkElementEnum(NetworkElementEnum.NODE).attributes( //GE12345
                            Maps.newHashMap("serialNumber", "*E123*"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-B-A1,A4,A5-D", "network-A-A1,A2,A3");

            networkPredicate.setAttributes(Maps.newHashMap("Test String", "*@@@@@*"));
            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(0);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryNodeByStringAttributeRightLike() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().networkElementEnum(NetworkElementEnum.NODE).attributes(
                            Maps.newHashMap("serialNumber", "GE12*"))
                        .build()))
                .build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-B-A1,A4,A5-D", "network-A-A1,A2,A3");

            networkPredicate.setAttributes(Maps.newHashMap("Test String", "@@@@@*"));
            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(0);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeStringAttributeLeftLike() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().networkElementEnum(NetworkElementEnum.NODE).attributes(
                            Maps.newHashMap("serialNumber", "*12345")) //GE12345
                        .build()))
                .build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-B-A1,A4,A5-D", "network-A-A1,A2,A3");

            networkPredicate.setAttributes(Maps.newHashMap("Test String", "*@@@@@"));
            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(0);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeStringAttributesLikeAnd() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            Map<String, String> attributes = Maps.newHashMap("serialNumber", "*12345");  //GE12345
            attributes.put("Test String", "ab*");

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().networkElementEnum(NetworkElementEnum.NODE).attributes(attributes)
                        .build()))
                .build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-B-A1,A4,A5-D", "network-A-A1,A2,A3");

            networkPredicate.setAttributes(Maps.newHashMap("Test String", "*@@@@@"));
            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(0);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeStringAttributesLikeAndNegative() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            Map<String, String> attributes = Maps.newHashMap("serialNumber", "*12345"); //GE12345
            attributes.put("Test String", "I am not existing");

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(NetworkPredicate
                        .builder().networkElementEnum(NetworkElementEnum.NODE).attributes(attributes)
                        .build()))
                .build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(0);

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void testQueryByNodeStringAttributesLikeOr() {
        try {
            //Given: Setup test networks
            Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
                assetPersistencyService, networkPersistencyService);

            Map<String, String> attributes1 = Maps.newHashMap("serialNumber", "*12345");  //GE12345
            Map<String, String> attributes2 = Maps.newHashMap("Test String", "I am not existing");

            NetworkPredicate networkPredicate = NetworkPredicate.builder()
                .childOperand(Operand.AND)
                .childPredicates(
                    Arrays.asList(
                        NetworkPredicate.builder().networkElementEnum(NetworkElementEnum.NODE).attributes(attributes1).peerOperand(Operand.OR).build(),
                        NetworkPredicate.builder().networkElementEnum(NetworkElementEnum.NODE).attributes(attributes2).build()))
                .build();

            assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, networkPredicate)).hasSize(2)
                .extracting(Network::getName).containsOnly("network-B-A1,A4,A5-D", "network-A-A1,A2,A3");

        } catch (Exception e) {
            Assert.fail("Exception in unit test");
            e.printStackTrace();
        }
    }

    @Test
    @Transactional
    public void getNodesByNetworkId_PagingWithSortKey() throws IOException, PersistencyServiceException {
        Map<String, BaseDataModel> data = NetworkUtils.setupNetworks(assetTypePersistencyService,
            assetPersistencyService, networkPersistencyService);

        NetworkPredicate predicate = NetworkPredicate.builder().pageSize(1000).build();
        String netId = data.get("network-B-A1,A4,A5-D").getId();
        List<Network> all = networkPersistencyService.getNodesByNetworkId(TestUtils.TEST_TENANT, TestUtils.getUber(),
            netId, predicate);

        int pageSize = 1;
        int numPages = all.size();
        predicate.setPagingInfo(0, pageSize, null, true);
        List<Network> found = networkPersistencyService.getNodesByNetworkId(TestUtils.TEST_TENANT, TestUtils.getUber(),
            netId, predicate);
        assertThat(found).hasSize(pageSize);
        assertThat(found.stream().map(Network::getId).collect(Collectors.toList()))
            .containsExactlyElementsOf(all.subList(0, pageSize).stream()
                .map(Network::getId).collect(Collectors.toList()));

        String sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        assertThat(sortKey).isNotEmpty();

        int offset = pageSize;
        while (offset < pageSize * numPages) {
            predicate.setPagingInfo(0, pageSize, sortKey, true);
            found = networkPersistencyService.getNodesByNetworkId(TestUtils.TEST_TENANT, TestUtils.getUber(),
                netId, predicate);
            assertThat(found).hasSize(pageSize);
            assertThat(found.stream().map(Network::getId).collect(Collectors.toList()))
                .containsExactlyElementsOf(all.subList(offset, offset + pageSize).stream()
                    .map(Network::getId).collect(Collectors.toList()));
            offset += pageSize;
            sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        }

        predicate.setPagingInfo(0, pageSize, sortKey, true);
        assertThat(networkPersistencyService.getNodesByNetworkId(TestUtils.TEST_TENANT, TestUtils.getUber(),
            netId, predicate)).isEmpty();
    }

    @Test
    @Transactional
    public void getRootNetworks_PagingWithSortKey() throws IOException, PersistencyServiceException {
        NetworkUtils.setupNetworks(assetTypePersistencyService, assetPersistencyService, networkPersistencyService);

        NetworkPredicate predicate = NetworkPredicate.builder().pageSize(1000).build();
        List<Network> all = networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, predicate);

        int pageSize = 1;
        int numPages = all.size();
        predicate.setPagingInfo(0, pageSize, null, true);
        List<Network> found = networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, predicate);
        assertThat(found).hasSize(pageSize);
        assertThat(found.stream().map(Network::getId).collect(Collectors.toList()))
            .containsExactlyElementsOf(all.subList(0, pageSize).stream()
                .map(Network::getId).collect(Collectors.toList()));

        String sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        assertThat(sortKey).isNotEmpty();

        int offset = pageSize;
        while (offset < pageSize * numPages) {
            predicate.setPagingInfo(0, pageSize, sortKey, true);
            found = networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, predicate);
            assertThat(found).hasSize(pageSize);
            assertThat(found.stream().map(Network::getId).collect(Collectors.toList()))
                .containsExactlyElementsOf(all.subList(offset, offset + pageSize).stream()
                    .map(Network::getId).collect(Collectors.toList()));
            offset += pageSize;
            sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        }

        predicate.setPagingInfo(0, pageSize, sortKey, true);
        assertThat(networkPersistencyService.getRootNetworks(TestUtils.TEST_TENANT, predicate)).isEmpty();
    }

    @Test
    @Transactional
    public void getNetworksByNode_PagingWithSortKey() throws IOException, PersistencyServiceException {
        NetworkUtils.setupNetworks(assetTypePersistencyService, assetPersistencyService, networkPersistencyService);

        NetworkPredicate predicate = NetworkPredicate.builder()
            .childOperand(Operand.AND)
            .childPredicates(
                Arrays.asList(NetworkPredicate
                    .builder().networkElementEnum(NetworkElementEnum.NODE).name("*").build())).pageSize(100).build();
        List<Network> all = networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, predicate);

        int pageSize = 1;
        int numPages = all.size();
        predicate.setPagingInfo(0, pageSize, null, true);
        List<Network> found = networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, predicate);
        assertThat(found).hasSize(pageSize);
        assertThat(found.stream().map(Network::getId).collect(Collectors.toList()))
            .containsExactlyElementsOf(all.subList(0, pageSize).stream()
                .map(Network::getId).collect(Collectors.toList()));

        String sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        assertThat(sortKey).isNotEmpty();

        int offset = pageSize;
        while (offset < pageSize * numPages) {
            predicate.setPagingInfo(0, pageSize, sortKey, true);
            found = networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, predicate);
            assertThat(found).hasSize(pageSize);
            assertThat(found.stream().map(Network::getId).collect(Collectors.toList()))
                .containsExactlyElementsOf(all.subList(offset, offset + pageSize).stream()
                    .map(Network::getId).collect(Collectors.toList()));
            offset += pageSize;
            sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        }

        predicate.setPagingInfo(0, pageSize, sortKey, true);
        assertThat(networkPersistencyService.getNetworksByNode(TestUtils.TEST_TENANT, predicate)).isEmpty();
    }
}
