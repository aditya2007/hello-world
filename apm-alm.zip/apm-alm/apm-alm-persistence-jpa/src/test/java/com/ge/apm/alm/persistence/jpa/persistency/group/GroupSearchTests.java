/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.group;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.assertj.core.util.Sets;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.query.GroupPredicate;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.utils.GroupUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

/**
 * Tests the JPA Persistency Layer
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class GroupSearchTests {

    @Autowired
    private GroupPersistencyService groupPersistencyService;

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private TagPersistencyService tagPersistencyService;

    @Test
    @Transactional
    public void searchByNameAndCategory() throws IOException, PersistencyServiceException {
        GroupUtils.setupData(assetTypePersistencyService, assetPersistencyService, tagPersistencyService);
        AssetGroup group = GroupUtils.createAssetGroup("MyAssetGroup", AssetGroupCategory.ASSET);
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).isNotNull();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT,
            GroupUtils.createAssetGroup("MyAssetGroup-2", AssetGroupCategory.ASSET))).isNotNull();

        GroupPredicate predicate = GroupPredicate.builder().name(group.getName()).categories(
            Collections.singletonList(group.getCategory())).build();
        assertThat(groupPersistencyService.getAssetGroups(group.getTenantId(), predicate)).hasSize(1).extracting(
            AssetGroup::getName).containsOnly(group.getName());
    }

    @Test
    @Transactional
    public void searchByNameAndCategorySqlInjection() throws IOException, PersistencyServiceException {
        GroupUtils.setupData(assetTypePersistencyService, assetPersistencyService, tagPersistencyService);
        AssetGroup group = GroupUtils.createAssetGroup("MyAssetGroup", AssetGroupCategory.ASSET);
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).isNotNull();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT,
            GroupUtils.createAssetGroup("MyAssetGroup-2", AssetGroupCategory.ASSET))).isNotNull();

        GroupPredicate predicate = GroupPredicate.builder().name("junk' or 'x'='x").categories(
            Collections.singletonList(group.getCategory())).build();
        assertThat(groupPersistencyService.getAssetGroups(group.getTenantId(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void searchBySourceKeyAndCategorySqlInjection() throws IOException, PersistencyServiceException {
        GroupUtils.setupData(assetTypePersistencyService, assetPersistencyService, tagPersistencyService);
        AssetGroup group = GroupUtils.createAssetGroup("MyAssetGroup1", AssetGroupCategory.ASSET);
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).isNotNull();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT,
            GroupUtils.createAssetGroup("MyAssetGroup2", AssetGroupCategory.ASSET))).isNotNull();

        GroupPredicate predicate = GroupPredicate.builder().sourceKey("junk' or 'x'='x").categories(
            Collections.singletonList(group.getCategory())).build();
        assertThat(groupPersistencyService.getAssetGroups(group.getTenantId(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void searchByDescriptionAndCategorySqlInjection() throws IOException, PersistencyServiceException {
        GroupUtils.setupData(assetTypePersistencyService, assetPersistencyService, tagPersistencyService);
        AssetGroup group = GroupUtils.createAssetGroup("MyAssetGroup11", AssetGroupCategory.ASSET);
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).isNotNull();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT,
            GroupUtils.createAssetGroup("MyAssetGroup22", AssetGroupCategory.ASSET))).isNotNull();

        GroupPredicate predicate = GroupPredicate.builder().description("junk' or 'x'='x").categories(
            Collections.singletonList(group.getCategory())).build();
        assertThat(groupPersistencyService.getAssetGroups(group.getTenantId(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void searchByNameAndCategory_usingChildPredicatesOnly() throws IOException, PersistencyServiceException {
        GroupUtils.setupData(assetTypePersistencyService, assetPersistencyService, tagPersistencyService);
        AssetGroup group = GroupUtils.createAssetGroup("MyAssetGroup", AssetGroupCategory.ASSET);
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).isNotNull();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT,
            GroupUtils.createAssetGroup("MyAssetGroup-2", AssetGroupCategory.ASSET))).isNotNull();

        GroupPredicate predicate = GroupPredicate.builder().childOperand(Operand.AND).childPredicates(
            Arrays.asList(GroupPredicate.builder().categories(Collections.singletonList(group.getCategory()))
                .peerOperand(Operand.AND).build(), GroupPredicate.builder().name(group.getName()).build())).build();
        assertThat(groupPersistencyService.getAssetGroups(group.getTenantId(), predicate)).hasSize(1).extracting(
            AssetGroup::getName).containsOnly(group.getName());
    }

    @Test
    @Transactional
    public void searchByNameAndCategoryOrIds_usingChildPredicatesOnly()
        throws IOException, PersistencyServiceException {
        GroupUtils.setupData(assetTypePersistencyService, assetPersistencyService, tagPersistencyService);
        AssetGroup group = GroupUtils.createAssetGroup("MyAssetGroup", AssetGroupCategory.ASSET);
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).isNotNull();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT,
            GroupUtils.createAssetGroup("MyAssetGroup-2", AssetGroupCategory.ASSET))).isNotNull();
        AssetGroup typeGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT,
            GroupUtils.createAssetGroup("MyAssetTypeGroup", AssetGroupCategory.ASSET_TYPE));

        GroupPredicate predicate = GroupPredicate.builder().childOperand(Operand.AND).childPredicates(
            Arrays.asList(GroupPredicate.builder().categories(
                Arrays.asList(group.getCategory(), typeGroup.getCategory())).peerOperand(Operand.AND).build(),
                GroupPredicate.builder().name(group.getName()).childOperand(Operand.OR).childPredicates(Collections
                    .singletonList(GroupPredicate.builder().ids(Sets.newLinkedHashSet(typeGroup.getId())).build()))
                    .build())).build();
        assertThat(groupPersistencyService.getAssetGroups(group.getTenantId(), predicate)).hasSize(2).extracting(
            AssetGroup::getName).containsOnly(group.getName(), typeGroup.getName());
    }

    @Test
    @Transactional
    public void getAssetGroups_PagingWithSortKey()
        throws IOException, PersistencyServiceException {

        GroupUtils.setupData(assetTypePersistencyService, assetPersistencyService, tagPersistencyService);

        int pageSize = 3;
        int pages = 3;
        for (int i = 0; i < pageSize * pages; i++) {
            groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, GroupUtils.createAssetGroup
                ("MyAssetGroup-" + i, AssetGroupCategory.ASSET));
        }

        GroupPredicate predicate = GroupPredicate.builder()
            .categories(Collections.singletonList(AssetGroupCategory.ASSET)).pageSize(100).build();
        List<AssetGroup> groups = groupPersistencyService.getAssetGroups(TestUtils.TEST_TENANT, predicate);
        assertThat(groups).hasSize(pageSize * pages);

        predicate.setPagingInfo(0, pageSize, null, true);
        List<AssetGroup> found = groupPersistencyService.getAssetGroups(TestUtils.TEST_TENANT, predicate);
        assertThat(found).hasSize(pageSize);
        assertThat(found.stream().map(AssetGroup::getId).collect(Collectors.toList()))
            .containsExactlyElementsOf(groups.subList(0, pageSize).stream()
                .map(AssetGroup::getId).collect(Collectors.toList()));

        String sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        assertThat(sortKey).isNotEmpty();

        predicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        int offset = pageSize;
        while (offset < pageSize * pages) {
            predicate.setPagingInfo(1, pageSize, sortKey, true);
            found = groupPersistencyService.getAssetGroups(TestUtils.TEST_TENANT, predicate);
            assertThat(found).hasSize(pageSize);
            assertThat(found.stream().map(AssetGroup::getId).collect(Collectors.toList()))
                .containsExactlyElementsOf(groups.subList(offset, offset + pageSize).stream()
                    .map(AssetGroup::getId).collect(Collectors.toList()));
            offset += pageSize;
            sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        }

        predicate.setPagingInfo(1, pageSize, sortKey, true);
        assertThat(groupPersistencyService.getAssetGroups(TestUtils.TEST_TENANT, predicate)).isEmpty();
    }
}
