/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.repository;

import java.util.UUID;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetEventEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetGroupAssociationEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceGroupItemEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetTypeEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetTypeGroupItemEntity;
import com.ge.apm.alm.persistence.jpa.entity.NotesEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagCorrelationItemEntity;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceGroupItemEntity;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.NULL_UUID;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests to perform sanity checks on all JPA entity mappings.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class JpaRepositorySanityTests extends BaseRepositoryTest {

    private static final String VIOLATES_FOREIGN_KEY_CONSTRAINT = "violates foreign key constraint";
    private static final String VIOLATES_NOT_NULL_CONSTRAINT = "violates not-null constraint";
    @Autowired
    private AssetTypeRepository assetTypeRepository;
    @Autowired
    private AssetInstanceRepository assetInstanceRepository;
    @Autowired
    private TagInstanceRepository tagInstanceRepository;
    @Autowired
    private AssetGroupRepository assetGroupRepository;
    @Autowired
    private AssetInstanceGroupItemRepository assetInstanceGroupItemRepository;
    @Autowired
    private AssetTypeGroupItemRepository assetTypeGroupItemRepository;
    @Autowired
    private TagCorrelationItemRepository tagCorrelationItemRepository;
    @Autowired
    private TagInstanceGroupItemRepository tagInstanceGroupItemRepository;
    @Autowired
    private TemplateRepository templateRepository;
    @Autowired
    private PlaceholderRepository placeholderRepository;
    @Autowired
    private PlaceholderTemplateRepository placeholderTemplateRepository;
    @Autowired
    private PlaceholderTypeRepository placeholderTypeRepository;
    @Autowired
    private PlaceholderTagTypeRepository placeholderTagTypeRepository;
    @Autowired
    private NotesRepository notesRepository;
    @Autowired
    private TemplateNotesRepository templateNotesRepository;
    @Autowired
    private AssetEventRepository assetEventRepository;
    @Autowired
    private AssetGroupAssociationRepository assetGroupAssociationRepository;

    @Test(expected = JpaSystemException.class)
    @Transactional
    public void stg1_assetTypeSanityCheck() {
        assertThat(assetTypeRepository.findOne(NULL_UUID)).isNull();
        try {
            AssetTypeEntity item =
                AssetTypeEntity.builder().id(UUID.randomUUID().toString()).tenantId(TestUtils.TEST_TENANT).build();
            assertThat(assetTypeRepository.saveAndFlush(item)).isNotNull();
        } catch (JpaSystemException ex) {
            assertThat(ex.getMessage()).contains(VIOLATES_NOT_NULL_CONSTRAINT);
            throw ex;
        }
    }

    @Test(expected = JpaSystemException.class)
    @Transactional
    public void stg1_assetInstanceSanityCheck() {
        assertThat(assetInstanceRepository.findOne(NULL_UUID)).isNull();
        try {
            AssetInstanceEntity item =
                AssetInstanceEntity.builder().id(UUID.randomUUID().toString()).tenantId(TestUtils.TEST_TENANT).build();
            assertThat(assetInstanceRepository.saveAndFlush(item)).isNotNull();
        } catch (JpaSystemException ex) {
            assertThat(ex.getMessage()).contains(VIOLATES_NOT_NULL_CONSTRAINT);
            throw ex;
        }
    }

    @Test
    @Transactional
    public void stg1_tagInstanceSanityCheck() {
        assertThat(tagInstanceRepository.findOne(NULL_UUID)).isNull();
    }

    @Test
    @Transactional
    public void stg1_assetGroupSanityCheck() {
        assertThat(assetGroupRepository.findOne(NULL_UUID)).isNull();
    }

    @Test(expected = JpaSystemException.class)
    @Transactional
    public void stg1_assetInstanceGroupItemSanityCheck() {
        assertThat(assetInstanceGroupItemRepository.findOne(NULL_UUID)).isNull();
        try {
            AssetInstanceGroupItemEntity item =
                AssetInstanceGroupItemEntity.builder().id(UUID.randomUUID().toString()).tenantId(
                    TestUtils.TEST_TENANT).groupId(UUID.randomUUID().toString()).objectId(UUID.randomUUID().toString())
                    .build();
            assertThat(item.getPosition()).isEqualTo(0);
            assertThat(assetInstanceGroupItemRepository.saveAndFlush(item)).isNotNull();
        } catch (JpaSystemException ex) {
            assertThat(ex.getMessage()).contains(VIOLATES_FOREIGN_KEY_CONSTRAINT);
            throw ex;
        }
    }

    @Test(expected = JpaSystemException.class)
    @Transactional
    public void stg1_tagInstanceGroupItemSanityCheck() {
        assertThat(tagInstanceGroupItemRepository.findOne(NULL_UUID)).isNull();
        try {
            TagInstanceGroupItemEntity item =
                TagInstanceGroupItemEntity.builder().id(UUID.randomUUID().toString()).tenantId(
                    TestUtils.TEST_TENANT).groupId(UUID.randomUUID().toString()).objectId(UUID.randomUUID().toString())
                    .build();
            assertThat(item.getPosition()).isEqualTo(0);
            assertThat(tagInstanceGroupItemRepository.saveAndFlush(item)).isNotNull();
        } catch (JpaSystemException ex) {
            assertThat(ex.getMessage()).contains(VIOLATES_FOREIGN_KEY_CONSTRAINT);
            throw ex;
        }
    }

    @Test(expected = JpaSystemException.class)
    @Transactional
    public void stg1_tagCorrelationItemSanityCheck() {
        assertThat(tagCorrelationItemRepository.findOne(NULL_UUID)).isNull();
        try {
            TagCorrelationItemEntity item =
                TagCorrelationItemEntity.builder().id(UUID.randomUUID().toString()).tenantId(
                    TestUtils.TEST_TENANT).groupId(UUID.randomUUID().toString()).objectId(UUID.randomUUID().toString())
                    .build();
            assertThat(tagCorrelationItemRepository.saveAndFlush(item)).isNotNull();
        } catch (JpaSystemException ex) {
            assertThat(ex.getMessage()).contains(VIOLATES_FOREIGN_KEY_CONSTRAINT);
            throw ex;
        }
    }

    @Test(expected = JpaSystemException.class)
    @Transactional
    public void stg1_assetTypeGroupItemSanityCheck() {
        assertThat(assetTypeGroupItemRepository.findOne(NULL_UUID)).isNull();
        try {
            AssetTypeGroupItemEntity item =
                AssetTypeGroupItemEntity.builder().id(UUID.randomUUID().toString()).tenantId(
                    TestUtils.TEST_TENANT).groupId(UUID.randomUUID().toString()).objectId(UUID.randomUUID().toString())
                    .build();
            assertThat(item.getPosition()).isEqualTo(0);
            assertThat(assetTypeGroupItemRepository.saveAndFlush(item)).isNotNull();
        } catch (JpaSystemException ex) {
            assertThat(ex.getMessage()).contains(VIOLATES_FOREIGN_KEY_CONSTRAINT);
            throw ex;
        }
    }

    @Test
    @Transactional
    public void stg1_templateSanityCheck() {
        assertThat(templateRepository.findOne(NULL_UUID)).isNull();
    }

    @Test
    @Transactional
    public void stg1_placeholderSanityCheck() {
        assertThat(placeholderRepository.findOne(NULL_UUID)).isNull();
    }

    @Test
    @Transactional
    public void stg1_placeholderTypeSanityCheck() {
        assertThat(placeholderTypeRepository.findOne(NULL_UUID)).isNull();
    }

    @Test
    @Transactional
    public void stg1_placeholderTagTypeSanityCheck() {
        assertThat(placeholderTagTypeRepository.findOne(NULL_UUID)).isNull();
    }

    @Test
    @Transactional
    public void stg1_placeholderTemplateSanityCheck() {
        assertThat(placeholderTemplateRepository.findOne(NULL_UUID)).isNull();
    }

    @Test(expected = JpaSystemException.class)
    @Transactional
    public void stg1_notesSanityCheck() {
        assertThat(notesRepository.findOne(NULL_UUID)).isNull();
        try {
            NotesEntity item =
                NotesEntity.builder().id(UUID.randomUUID().toString()).tenantId(TestUtils.TEST_TENANT).build();
            assertThat(notesRepository.saveAndFlush(item)).isNotNull();
        } catch (JpaSystemException ex) {
            assertThat(ex.getMessage()).contains(VIOLATES_NOT_NULL_CONSTRAINT);
            throw ex;
        }
    }

    @Test
    @Transactional
    public void stg1_templateNotesSanithCheck() {
        assertThat(templateNotesRepository.findOne(NULL_UUID)).isNull();
    }

    @Test(expected = JpaSystemException.class)
    @Transactional
    public void stg1_assetEventSanityCheck() {
        assertThat(assetEventRepository.findOne(NULL_UUID)).isNull();
        try {
            AssetEventEntity item =
                AssetEventEntity.builder().id(UUID.randomUUID().toString()).tenantId(TestUtils.TEST_TENANT).build();
            assertThat(assetEventRepository.saveAndFlush(item)).isNotNull();
        } catch (JpaSystemException ex) {
            assertThat(ex.getMessage()).contains(VIOLATES_NOT_NULL_CONSTRAINT);
            throw ex;
        }
    }

    @Test(expected = JpaSystemException.class)
    @Transactional
    public void stg1_assetGroupAssociationItemSanityCheck() {
        assertThat(assetGroupAssociationRepository.findOne(NULL_UUID)).isNull();
        try {
            AssetGroupAssociationEntity item =
                AssetGroupAssociationEntity.builder().id(UUID.randomUUID().toString()).tenantId(
                    TestUtils.TEST_TENANT).groupId(UUID.randomUUID().toString()).objectId(UUID.randomUUID().toString())
                    .build();
            assertThat(assetGroupAssociationRepository.saveAndFlush(item)).isNotNull();
        } catch (JpaSystemException ex) {
            assertThat(ex.getMessage()).contains(VIOLATES_FOREIGN_KEY_CONSTRAINT);
            throw ex;
        }
    }
}
