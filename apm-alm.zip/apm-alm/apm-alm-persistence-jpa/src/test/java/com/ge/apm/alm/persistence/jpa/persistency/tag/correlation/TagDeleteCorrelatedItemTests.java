/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.tag.correlation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.utils.TagPredicateUtils;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.TEST_TENANT;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUber;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TagDeleteCorrelatedItemTests extends TagCorrelationBaseTest {

    @Test
    @Transactional
    public void deleteCorrelatedItem_onlyOneItem() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 1;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1").getId()),
                group.getId(), items))
            .isEqualTo(items.size());

        // break the correlation at 0
        assertThat(groupPersistencyService
            .deleteCorrelatedItem(TEST_TENANT, getUber(), group.getId(), tags.get(0).getId()))
            .isNull();
        assertThat(groupPersistencyService.getAssetGroupById(TEST_TENANT, group.getId())).isNull();
    }

    @Test
    @Transactional
    public void deleteCorrelatedItem_2Items_deleteAtHead()
        throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 2;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1").getId()),
                group.getId(), items)).isEqualTo(items.size());

        assertThat(groupPersistencyService
            .deleteCorrelatedItem(TEST_TENANT, getUber(), group.getId(), tags.get(0).getId()))
            .isNull();
        assertThat(groupPersistencyService.getAssetGroupById(TEST_TENANT, group.getId())).isNull();
    }

    @Test
    @Transactional
    public void deleteCorrelatedItem_2Items_deleteAtTail()
        throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 2;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        Collection<String> accessibleResources = getUber();
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, accessibleResources, group.getId(), items)).isEqualTo(items.size());

        assertThat(groupPersistencyService
            .deleteCorrelatedItem(TEST_TENANT, accessibleResources, group.getId(),
                tags.get(1).getId())).isNull();
        assertThat(groupPersistencyService.getAssetGroupById(TEST_TENANT, group.getId())).isNull();
    }

    @Test
    @Transactional
    public void deleteCorrelatedItem_3Items_deleteAtMiddle()
        throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 3;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        Collection<String> accessibleResources = Collections.singletonList(assets.get("E1_S1_Seg1").getId());
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, accessibleResources, group.getId(), items)).isEqualTo(items.size());
        assertThat(groupPersistencyService
            .deleteCorrelatedItem(TEST_TENANT, accessibleResources, group.getId(),
                tags.get(1).getId())).isNull();
        assertThat(groupPersistencyService.getAssetGroupById(TEST_TENANT, group.getId())).isNull();
    }

    @Test
    @Transactional
    public void deleteCorrelatedItem_3Items_deleteAtHead()
        throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 3;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        Collection<String> accessibleResources = getUber();
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, accessibleResources, group.getId(), items)).isEqualTo(items.size());

        assertThat(groupPersistencyService
            .deleteCorrelatedItem(TEST_TENANT, accessibleResources, group.getId(),
                tags.get(0).getId())).isNull();
        assertThat(groupPersistencyService.getGroupItems(TEST_TENANT, accessibleResources, group.getId()))
            .hasSize(2).extracting(AssetGroupItem::getObjectId).containsOnly(tags.get(1).getId(), tags.get(2).getId());
    }

    @Test
    @Transactional
    public void deleteCorrelatedItem_3Items_deleteAtTail()
        throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 3;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        Collection<String> accessibleResources = Collections.singletonList(assets.get("E1_S1_Seg1").getId());
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, accessibleResources, group.getId(), items)).isEqualTo(items.size());

        assertThat(groupPersistencyService
            .deleteCorrelatedItem(TEST_TENANT, accessibleResources, group.getId(),
                tags.get(2).getId())).isNull();
        assertThat(groupPersistencyService.getGroupItems(TEST_TENANT, accessibleResources, group.getId()))
            .hasSize(2).extracting(AssetGroupItem::getObjectId).containsOnly(tags.get(0).getId(), tags.get(1).getId());
    }

    @Test
    @Transactional
    public void deleteCorrelatedItem_4Items_deleteAt2ndHead()
        throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 4;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        Collection<String> accessibleResources = Collections.singletonList(assets.get("E1_S1_Seg1").getId());
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, accessibleResources, group.getId(), items)).isEqualTo(items.size());

        assertThat(groupPersistencyService
            .deleteCorrelatedItem(TEST_TENANT, accessibleResources, group.getId(),
                tags.get(1).getId())).isNull();
        assertThat(groupPersistencyService.getGroupItems(TEST_TENANT, accessibleResources, group.getId()))
            .hasSize(2).extracting(AssetGroupItem::getObjectId).containsOnly(tags.get(2).getId(), tags.get(3).getId());
    }

    @Test
    @Transactional
    public void deleteCorrelatedItem_4Items_deleteAt2ndTail()
        throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 4;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        Collection<String> accessibleResources = getUber();
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, accessibleResources, group.getId(), items)).isEqualTo(items.size());

        assertThat(groupPersistencyService
            .deleteCorrelatedItem(TEST_TENANT, accessibleResources, group.getId(),
                tags.get(2).getId())).isNull();
        assertThat(groupPersistencyService.getGroupItems(TEST_TENANT, accessibleResources, group.getId()))
            .hasSize(2).extracting(AssetGroupItem::getObjectId).containsOnly(tags.get(0).getId(), tags.get(1).getId());
    }

    @Test
    @Transactional
    public void deleteCorrelatedItem_4OrMoreItems_deleteAtHead()
        throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 4;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);
        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        Collection<String> accessibleResources = getUber();
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, accessibleResources, group.getId(), items)).isEqualTo(items.size());

        assertThat(groupPersistencyService
            .deleteCorrelatedItem(TEST_TENANT, accessibleResources, group.getId(),
                tags.get(0).getId())).isNull();
        assertThat(groupPersistencyService.getGroupItems(TEST_TENANT, accessibleResources, group.getId()))
            .hasSize(3).extracting(AssetGroupItem::getObjectId)
            .containsOnly(tags.get(1).getId(), tags.get(2).getId(), tags.get(3).getId());
    }

    @Test
    @Transactional
    public void deleteCorrelatedItem_4OrMoreItems_deleteAtTail()
        throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 4;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        Collection<String> accessibleResources = Collections.singletonList(assets.get("E1_S1_Seg1").getId());
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, accessibleResources, group.getId(), items)).isEqualTo(items.size());

        assertThat(groupPersistencyService
            .deleteCorrelatedItem(TEST_TENANT, accessibleResources, group.getId(),
                tags.get(3).getId())).isNull();
        assertThat(groupPersistencyService.getGroupItems(TEST_TENANT, accessibleResources, group.getId()))
            .hasSize(3).extracting(AssetGroupItem::getObjectId)
            .containsOnly(tags.get(0).getId(), tags.get(1).getId(), tags.get(2).getId());
    }

    @Test
    @Transactional
    public void deleteCorrelatedItem_createNewGroup() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 6;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        Collection<String> accessibleResources = Collections.singletonList(assets.get("E1_S1_Seg1").getId());
        assertThat(groupPersistencyService
            .createAssetGroupItems(TEST_TENANT, accessibleResources, group.getId(), items)).isEqualTo(items.size());

        String newGrpId = groupPersistencyService
            .deleteCorrelatedItem(TEST_TENANT, getUber(), group.getId(), tags.get(2).getId());
        assertThat(newGrpId).isNotNull();
        assertThat(groupPersistencyService.getGroupItems(TEST_TENANT, getUber(), group.getId())).hasSize(2)
            .extracting(AssetGroupItem::getObjectId).containsOnly(tags.get(0).getId(), tags.get(1).getId());
        assertThat(groupPersistencyService.getGroupItems(TEST_TENANT, accessibleResources, newGrpId)).hasSize(3)
            .extracting(AssetGroupItem::getObjectId)
            .containsOnly(tags.get(5).getId(), tags.get(4).getId(), tags.get(3).getId());
    }
}
