/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.config;

import javax.persistence.PostPersist;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.ge.apm.alm.model.Auditable;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;
import com.ge.stuf.security.context.SecurityPrincipal;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Support for @EnableJpaAuditing
 */
@Component
@Primary
public class EntityTestAuditor extends EntityAuditor {

    public static final String TEST_USER = "TEST_USER";

    private static final SecurityPrincipal principal = new SecurityPrincipal() {

        @Override
        public String getName() {
            return TEST_USER;
        }

        @Override
        public String getTenantUuid() {
            return TestUtils.TEST_TENANT;
        }
    };

    protected SecurityPrincipal getPrincipal() {
        return principal;
    }

    public static class EntityTestAuditorVerifier {

        @PostPersist
        public void verify(Object object) {
            if (!(object instanceof Auditable)) {
                return;
            }

            Auditable entity = (Auditable) object;
            String autoSetForEntity = " is auto-set for " + entity.getClass().getSimpleName();
            assertThat(entity.getCreatedBy()).as("createdBy " + autoSetForEntity).isEqualTo(TEST_USER);
            assertThat(entity.getCreatedDate()).as("createdDate" + autoSetForEntity).isNotNull();
            assertThat(entity.getLastModifiedBy()).as("lastModifiedBy" + autoSetForEntity).isEqualTo(TEST_USER);
            assertThat(entity.getLastModifiedDate()).as("lastModifiedDate" + autoSetForEntity).isNotNull();
        }

    }
}
