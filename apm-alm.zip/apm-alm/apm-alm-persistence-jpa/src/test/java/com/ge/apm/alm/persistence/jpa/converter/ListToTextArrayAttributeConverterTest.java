/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.converter;

import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.postgresql.util.PGobject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.alm.persistence.jpa.TestApp;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class ListToTextArrayAttributeConverterTest {

    @Value("${spring.datasource.url}")
    String url;

    @Value("${spring.datasource.username}")
    String user;

    @Value("${spring.datasource.password}")
    String password;

    @Test
    public void convertToEntityAttribute_nullValue() throws SQLException {
        ListToTextArrayAttributeConverter converter = new ListToTextArrayAttributeConverter();
        assertThat(converter.convertToEntityAttribute(null)).isEmpty();
    }

    @Test
    public void convertToEntityAttribute_PgArray_StringArray() throws SQLException {
        StringBuilder connUrl = new StringBuilder(1000);
        connUrl.append(url).append("?currentSchema=apm_alm&").append("user=").append(user).append("&password=")
            .append(password);
        Connection connection = DriverManager.getConnection(connUrl.toString());
        String[] values = { "aa", "bb", "cc" };
        Array array = connection.createArrayOf("text", values);
        ListToTextArrayAttributeConverter listToTextArrayAttributeConverter = new ListToTextArrayAttributeConverter();
        assertThat(listToTextArrayAttributeConverter.convertToEntityAttribute(array)).containsOnly("aa", "bb", "cc");
    }

    @Test(expected = UnsupportedOperationException.class)
    public void convertToEntityAttribute_PgArray_IntegerArray() throws SQLException {
        StringBuilder connUrl = new StringBuilder(1000);
        connUrl.append(url).append("?currentSchema=apm_alm&").append("user=").append(user).append("&password=")
            .append(password);
        Connection connection = DriverManager.getConnection(connUrl.toString());
        Integer[] values = { 1, 2, 3 };
        Array array = connection.createArrayOf("integer", values);
        ListToTextArrayAttributeConverter listToTextArrayAttributeConverter = new ListToTextArrayAttributeConverter();
        listToTextArrayAttributeConverter.convertToEntityAttribute(array);
    }

    @Test
    public void convertToEntityAttribute_StringArray() throws SQLException {
        ListToTextArrayAttributeConverter listToTextArrayAttributeConverter = new ListToTextArrayAttributeConverter();
        assertThat(listToTextArrayAttributeConverter.convertToEntityAttribute(new String[] { "x", "y" })).containsOnly(
            "x", "y");
    }

    @Test(expected = UnsupportedOperationException.class)
    public void convertToEntityAttribute() throws SQLException {
        ListToTextArrayAttributeConverter converter = new ListToTextArrayAttributeConverter();
        PGobject value = new PGobject();
        value.setType("text");
        value.setValue("{}");
        assertThat(converter.convertToEntityAttribute(value)).isNotNull();
    }
}