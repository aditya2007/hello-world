/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.template;

import java.io.IOException;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetPlaceholder;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.PlaceholderTemplate;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPlaceholderPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.PlaceholderPersistencyService;
import com.ge.apm.alm.persistence.PlaceholderTemplatePersistencyService;
import com.ge.apm.alm.persistence.TemplatePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.model.TestAssetPlaceholder;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholder;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestTemplateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.TEST_TENANT;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * placeholder for tests on template info
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TemplateInfoTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private TemplatePersistencyService templatePersistencyService;

    @Autowired
    private PlaceholderPersistencyService placeholderPersistencyService;

    @Autowired
    private PlaceholderTemplatePersistencyService placeholderTemplatePersistencyService;

    @Autowired
    private AssetPlaceholderPersistencyService assetPlaceholderPersistencyService;

    // see https://devcloud.swcoe.ge.com/devspace/display/LJSWI/Equipment+Instances, option 7
    // an aircraft (AC)  has a left (LE) and right (RE) engine.
    private Template t1;

    // an engine has P1 and p2
    private Template t2;

    @Test
    @Transactional
    public void searchTests() throws IOException {
        setupData();
        String tenant = t1.getTenantId();

        List<Asset> en1 = assetPersistencyService.getAssets(tenant, TestUtils.getUber(),
            AssetPredicate.builder()
                .embeddedTemplateId(t1.getId())
                .embeddedPpn("LE")
                .attributeSelectEnum(AttributeSelectEnum.FULL)
                .components(EnumSet.of(AssetComponent.TEMPLATE_INFO))
                 .build());

        assertThat(en1).as("left engine by id and ppn").hasSize(1);
        assertThat(en1.get(0).getName()).as("left engine's name ").isEqualTo("EN_1");
        assertThat(en1.get(0).getTemplateInfo()).isNotNull();

        List<Asset> t1Engines = assetPersistencyService.getAssets(tenant, TestUtils.getUber(),
            AssetPredicate.builder()
                .embeddedTemplateId(t1.getId())
                .attributeSelectEnum(AttributeSelectEnum.FULL)
                .build());
        assertThat(t1Engines).as("T1 engines").hasSize(2)
            .extracting(Asset::getName).containsOnly("EN_1", "EN_2");

        List<Asset> leftEngines = assetPersistencyService.getAssets(tenant, TestUtils.getUber(),
            AssetPredicate.builder()
                .embeddedPpn("LE")
                .attributeSelectEnum(AttributeSelectEnum.FULL)
                .build());
        assertThat(leftEngines).as("left engine by ppn").hasSize(1);
        assertThat(leftEngines.get(0).getName()).as("left engine's name ").isEqualTo("EN_1");

        List<Asset> exactMatch = assetPersistencyService.getAssets(tenant, TestUtils.getUber(),
            AssetPredicate.builder()
                .templateId(t2.getId())
                .ppn("EN")
                .embeddedTemplateId(t1.getId())
                .embeddedPpn("LE")
                .attributeSelectEnum(AttributeSelectEnum.FULL)
                .build());
        assertThat(exactMatch).as("LE exact match").hasSize(1);
        assertThat(exactMatch.get(0).getName()).isEqualTo("EN_1");

        List<Asset> acEngines = assetPersistencyService.getAssets(t1.getTenantId(), TestUtils.getUber(),
            AssetPredicate.builder()
                .templateId(t2.getId())
                .ppn("EN")
                .childPredicates(Collections.singletonList(
                    AssetPredicate.builder()
                        .embeddedTemplateId(t2.getId())
                        .embeddedPpn("EN")
                        .build()))
                .childOperand(Operand.OR)
                .peerOperand(Operand.AND)
                .attributeSelectEnum(AttributeSelectEnum.FULL)
                .build());
        assertThat(acEngines).as("ac engines").hasSize(3)
            .extracting(Asset::getName).containsOnly("EN_1", "EN_2", "EN_3");
    }

    private void setupTemplateData() throws IOException {
        AssetType type = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, getClass().getName() + "_type");

        t1 = createTemplate("T1");
        Placeholder ac = createPlaceholder(t1, "AC", null);
        Placeholder le = createPlaceholder(t1, "LE", ac);
        Placeholder re = createPlaceholder(t1, "RE", ac);

        t2 = createTemplate("T2");
        Placeholder en = createPlaceholder(t2, "EN", null);
        Placeholder p1 = createPlaceholder(t2, "P1", en);
        Placeholder p2 = createPlaceholder(t2, "P2", en);

        createPlaceholderTemplate(le, t2);
        createPlaceholderTemplate(re, t2);

        Asset ac1 = createAssetWithPlaceholder(null, "AC_1", type, ac);
        assertTemplateInfo(ac1, ac);

        Asset en1 = createAssetWithPlaceholder(ac1, "EN_1", type, le);
        assertTemplateInfo(en1, en);
        assertSubTemplateInfo(en1, le);

        Asset p11 = createAssetWithPlaceholder(en1, "P1_1", type, p1);
        assertTemplateInfo(p11, p1);

        Asset p21 = createAssetWithPlaceholder(en1, "P2_1", type, p2);
        assertTemplateInfo(p21, p2);

        Asset en2 = createAssetWithPlaceholder(ac1, "EN_2", type, re);
        assertTemplateInfo(en2, en);
        assertSubTemplateInfo(en2, re);

        Asset p12 = createAssetWithPlaceholder(en2, "P1_2", type, p1);
        assertTemplateInfo(p12, p1);

        Asset p22 = createAssetWithPlaceholder(en2, "P2_2", type, p2);
        assertTemplateInfo(p22, p2);

        // engine 3 is not in an aircraft
        Asset en3 = createAssetWithPlaceholder(null, "EN_3", type, en);
        assertTemplateInfo(en3, en);
        assertSubTemplateInfo(en3, null);

        Asset p13 = createAssetWithPlaceholder(en3, "P1_3", type, p1);
        assertTemplateInfo(p13, p1);

        Asset p23 = createAssetWithPlaceholder(en3, "P2_3", type, p2);
        assertTemplateInfo(p23, p2);
    }


    private void assertTemplateInfo(Asset asset, Placeholder placeholder) {
        assertThat(asset.getTemplateInfo().getTemplateId())
            .as(asset.getName() + "'s template")
            .isEqualTo(placeholder.getTemplateId());

        assertThat(asset.getTemplateInfo().getPpn())
            .as(asset.getName() + "'s ppn")
            .isEqualTo(placeholder.getPartPositionNumber());
    }

    private void assertSubTemplateInfo(Asset asset, Placeholder placeholder) {
        assertThat(asset.getTemplateInfo().getEmbeddedTemplateId())
            .as(asset.getName() + "'s embedded template")
            .isEqualTo(placeholder == null ? null : placeholder.getTemplateId());

        assertThat(asset.getTemplateInfo().getEmbeddedPpn())
            .as(asset.getName() + "'s embedded ppn")
            .isEqualTo(placeholder == null ? null : placeholder.getPartPositionNumber());
    }

    private void setupData() throws IOException {
        setupBackgroundData();
        setupTemplateData();
    }

    private void setupBackgroundData() throws IOException {
        PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService,
            assetPersistencyService);
    }

    private Template createTemplate(String name)
        throws IOException {
        return templatePersistencyService.createTemplate(TEST_TENANT,
            TestTemplateUtils.buildTemplate(null, name));
    }

    private Placeholder createPlaceholder(Template template, String ppn, Placeholder parent) {

        return placeholderPersistencyService
            .createPlaceholder(TEST_TENANT, template.getId(),
                TestPlaceholder.builder().id(UUID.randomUUID().toString())
                    .sourceKey(UUID.randomUUID().toString())
                    .name(template.getName() + "-" + ppn)
                    .tenantId(TEST_TENANT)
                    .templateId(template.getId())
                    .partPositionNumber(ppn)
                    .parentId(parent == null ? null : parent.getId())
                    .build());
    }

    private PlaceholderTemplate createPlaceholderTemplate(Placeholder placeholder, Template subTemplate) {
        return placeholderTemplatePersistencyService
            .createPlaceholderTemplate(TEST_TENANT,
                TestTemplateUtils
                    .buildPlaceholderTemplate(placeholder.getId(), subTemplate.getId()));
    }

    public AssetPlaceholder createAssetPlaceholder(Asset asset, Placeholder placeholder) {
        return assetPlaceholderPersistencyService.createAssetPlaceholder(TEST_TENANT,
            TestAssetPlaceholder
                .builder()
                .id(UUID.randomUUID().toString())
                .tenantId(TEST_TENANT)
                .assetId(asset.getId())
                .placeholderId(placeholder.getId())
                .build());
    }

    public Asset createAssetWithPlaceholder(Asset parent, String name, AssetType type,
        Placeholder placeholder) throws IOException {
        Asset asset = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), type.getId(), parent == null ? null : parent.getId(), name);

        createAssetPlaceholder(asset, placeholder);

        return assetPersistencyService.getAssetById(asset.getTenantId(), TestUtils.getUber(), asset.getId());
    }
}
