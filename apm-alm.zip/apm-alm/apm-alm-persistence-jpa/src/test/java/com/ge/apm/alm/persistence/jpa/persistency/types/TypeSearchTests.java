/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.types;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_ASSET_TYPE_ID;
import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_SITE_TYPE_ID;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import com.google.common.collect.Sets;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.query.Operand;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetTypeEntity;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

/**
 * Tests asset type searche via the {@link com.ge.apm.alm
 * .persistence.AssetTypePersistencyService#findAllAssetTypes(String, com.ge.apm.alm.model.query.TypePredicate)} API
 * using {@link com.ge.apm.alm.model.query.TypePredicate}.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TypeSearchTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Test
    @Transactional
    public void findAllAssetTypes_withWildcards() throws IOException, PersistencyServiceException {
        String tenantId = TestUtils.newUuid();
        List<AssetType> types = new ArrayList<>();
        int count = 3;
        for (int i = 0; i < count; i++) {
            types.add(TestUtils.createAssetType(ROOT_ASSET_TYPE_ID, i + "_WildcardSearchTest_" + i));
        }
        assertThat(assetTypePersistencyService.createAssetTypes(tenantId, types)).isEqualTo(types.size());
        OffsetDateTime lastModifiedDateFromBean = types.get(0).getLastModifiedDate();
        assertThat(types.get(0).getSuperTypesArray()).hasSize(1);
        assertThat(lastModifiedDateFromBean).isBefore(OffsetDateTime.now());
        AssetType found = assetTypePersistencyService.getAssetTypeById(tenantId, types.get(0).getId());
        assertThat(found.getLastModifiedDate()).isEqualTo(lastModifiedDateFromBean);
        //created and modified dates are same on creation
        assertThat(found.getCreatedDate()).isEqualTo(lastModifiedDateFromBean);
        assertThat(found.getSuperTypesArray()).isNotEqualTo(Collections.EMPTY_LIST);

        // "AND" all 3 LIKE name, description, source key: match middle or chunked matches
        TypePredicate predicate;
        for (String value : Arrays.asList("*SearchTest*", "*Wildcard*Test*")) {
            predicate = TypePredicate.builder().name(value).description(value).sourceKey(value).build();
            assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(count).extracting(
                AssetType::getDescription).containsOnly(types.get(0).getDescription(), types.get(1).getDescription(),
                types.get(2).getDescription());

            predicate = TypePredicate.builder().name(value).build();
            assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(count).extracting(
                AssetType::getName).containsOnly(types.get(0).getName(), types.get(1).getName(),
                types.get(2).getName());

            predicate = TypePredicate.builder().description(value).build();
            assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(count).extracting(
                AssetType::getDescription).containsOnly(types.get(0).getDescription(), types.get(1).getDescription(),
                types.get(2).getDescription());

            predicate = TypePredicate.builder().sourceKey(value).build();
            assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(count).extracting(
                AssetType::getSourceKey).containsOnly(types.get(0).getSourceKey(), types.get(1).getSourceKey(),
                types.get(2).getSourceKey());
        }

        // "AND" all 3 LIKE name, description, source key: matching suffix and prefix
        for (int i = 0; i < count; i++) {
            String value = "*_" + i;
            predicate = TypePredicate.builder().name(value).description(value).sourceKey(value).build();
            assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(1).extracting(
                AssetType::getDescription).containsOnly(types.get(i).getDescription());

            predicate = TypePredicate.builder().name(value).build();
            assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(1).extracting(
                AssetType::getName).containsOnly(types.get(i).getName());

            predicate = TypePredicate.builder().description(value).build();
            assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(1).extracting(
                AssetType::getDescription).containsOnly(types.get(i).getDescription());

            predicate = TypePredicate.builder().sourceKey(value).build();
            assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(1).extracting(
                AssetType::getSourceKey).containsOnly(types.get(i).getSourceKey());

            value = i + "_*";
            predicate = TypePredicate.builder().name(value).description(value).sourceKey(value).build();
            assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(1).extracting(
                AssetType::getDescription).containsOnly(types.get(i).getDescription());

            predicate = TypePredicate.builder().name(value).build();
            assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(1).extracting(
                AssetType::getName).containsOnly(types.get(i).getName());

            predicate = TypePredicate.builder().description(value).build();
            assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(1).extracting(
                AssetType::getDescription).containsOnly(types.get(i).getDescription());

            predicate = TypePredicate.builder().sourceKey(value).build();
            assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(1).extracting(
                AssetType::getSourceKey).containsOnly(types.get(i).getSourceKey());
        }

        // TODO: figure out why only this test is leaving its data behind and need to be explicitly deleted
        String value = "*WildcardSearchTest*";
        predicate = TypePredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).description(
            value).sourceKey(value).build();
        List<AssetType> retrieved = assetTypePersistencyService.findAllAssetTypes(tenantId, predicate);
        for (AssetType assetType : retrieved) {
            assetTypePersistencyService.deleteAssetTypeRecursively(tenantId, assetType.getId());
        }
        assertThat(assetTypePersistencyService.findAllAssetTypes(tenantId, predicate)).hasSize(0);
    }

    /**
     * id = "AssetDSubType's ID", with or without deep search
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byTypeId_inIds_deepSearch() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        TypePredicate byTypeId = TypePredicate.builder().ids(Collections.singleton(data.get("AssetDType").getId()))
            .build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byTypeId)).hasSize(1)
            .extracting(AssetType::getName).containsOnly("AssetDType");
        byTypeId.setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byTypeId)).hasSize(3)
            .extracting(AssetType::getName).containsOnly("AssetDType", "AssetDSubType", "AssetDSubSubType");
    }

    /**
     * id = ROOT_ASSET_TYPE_ID with deep search
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byRootTypeId_inIds_deepSearch() throws IOException {
        setupData();
        TypePredicate byTypeId = TypePredicate.builder().ids(Collections.singleton(ROOT_ASSET_TYPE_ID)).deepSearch(true)
            .build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byTypeId)).hasSize(6);
    }

    /**
     * parent id = "AssetDType's ID", with or without deep search
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byParentId_deepSearch() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        TypePredicate byParentId = TypePredicate.builder().parent(
            ParentPredicate.builder().ids(Sets.newHashSet(data.get("AssetDType").getId())).build()).build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byParentId)).hasSize(1)
            .extracting(AssetType::getName).containsOnly("AssetDSubType");
        byParentId.getParent().setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byParentId)).hasSize(2)
            .extracting(AssetType::getName).containsOnly("AssetDSubType", "AssetDSubSubType");
    }

    /**
     * id = ROOT_ASSET_TYPE_ID, with or without deep search
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byRootParentId_deepSearch() throws IOException {
        setupData();
        TypePredicate byParentId = TypePredicate.builder().parent(
            ParentPredicate.builder().ids(Sets.newHashSet(ROOT_ASSET_TYPE_ID)).build()).build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byParentId)).hasSize(4)
            .extracting(AssetType::getName).containsOnly("AssetAType", "AssetBType", "AssetCType", "AssetDType");
        byParentId.getParent().setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byParentId)).hasSize(6)
            .extracting(AssetType::getName).containsOnly("AssetAType", "AssetBType", "AssetCType", "AssetDType",
            "AssetDSubType", "AssetDSubSubType");
    }

    /**
     * name like "*D*", with or without deep search
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byNameLikeD_deepSearch() throws IOException {
        setupData();
        TypePredicate byNameLike = TypePredicate.builder().name("*DType").build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byNameLike)).hasSize(1)
            .extracting(AssetType::getName).containsOnly("AssetDType");
        byNameLike.setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byNameLike)).hasSize(3)
            .extracting(AssetType::getName).containsOnly("AssetDType", "AssetDSubType", "AssetDSubSubType");
    }

    @Test
    @Transactional
    public void findAllAssetTypes_byNameLikeD_deepSearch_SqlInjection1() throws IOException {
        setupData();
        TypePredicate byNameLike = TypePredicate.builder().name("*DType' OR name iLike 'AssetDSubType").build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byNameLike)).hasSize(0);
    }

    @Test
    @Transactional
    public void findAllAssetTypes_byNameLikeD_deepSearch_SqlInjection2() throws IOException {
        setupData();
        TypePredicate byNameLike = TypePredicate.builder().name("*DType' OR cast(tenant_id as text) like '%").build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byNameLike)).hasSize(0);
    }

    @Test
    @Transactional
    public void findAllAssetTypes_byNameLikeD_deepSearch_SqlInjection3() throws IOException {
        setupData();
        TypePredicate byNameLike = TypePredicate.builder().name("Generator' or 'x'='x").build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byNameLike)).hasSize(0);
    }

    @Test
    @Transactional
    public void findAllAssetTypes_byDescriptionLikeD_deepSearch_SqlInjection1() throws IOException {
        setupData();
        TypePredicate byNameLike = TypePredicate.builder().description("Generator' or 'x'='x").build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byNameLike)).hasSize(0);
    }

    @Test
    @Transactional
    public void findAllAssetTypes_bySourcekeyLikeD_deepSearch_SqlInjection1() throws IOException {
        setupData();
        TypePredicate byNameLike = TypePredicate.builder().sourceKey("Generator' or 'x'='x").build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byNameLike)).hasSize(0);
    }

    @Test
    @Transactional
    public void findAllAssetTypes_bySourcekeyLikeD_deepSearch_SqlInjection2() throws IOException {
        setupData();
        TypePredicate byNameLike = TypePredicate.builder().sourceKey(
            "Generator' or 'x'='x')); drop table apm_alm" + ".schema_version --").build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byNameLike)).hasSize(0);
    }

    /**
     * (name = "AssetBType" or description = AssetDType or sourceKey like "S1*")
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byNameOrDescriptionOrSourceKey_deepSearch() throws IOException {
        setupData();
        TypePredicate nameOrDescriptionOrSourceKey = TypePredicate.builder().name("AssetBType").childOperand(Operand.OR)
            .childPredicates(Arrays.asList(TypePredicate.builder().name("AssetDType").peerOperand(Operand.OR).build(),
                TypePredicate.builder().sourceKey("S1*").build())).build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, nameOrDescriptionOrSourceKey))
            .hasSize(3).extracting(AssetType::getName).containsOnly("AssetBType", "AssetDType", "S1Type");
        // AssetBType has no children, deep search has no effect
        nameOrDescriptionOrSourceKey.setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, nameOrDescriptionOrSourceKey))
            .hasSize(3).extracting(AssetType::getName).containsOnly("AssetBType", "AssetDType", "S1Type");
        nameOrDescriptionOrSourceKey.setDeepSearch(false);
        nameOrDescriptionOrSourceKey.getChildPredicates().get(0).setDeepSearch(true); // expect 2 more
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, nameOrDescriptionOrSourceKey))
            .hasSize(5).extracting(AssetType::getName).containsOnly("AssetBType", "AssetDType", "AssetDSubType",
            "AssetDSubSubType", "S1Type");
    }

    /**
     * (name = "AssetDType" or sourceKey = "AssetAType"), with deep search
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byNameOrSourceKey_deepSearch() throws IOException {
        setupData();
        TypePredicate nameOrSourceKey = TypePredicate.builder().name("AssetDType").childOperand(Operand.OR)
            .childPredicates(Collections.singletonList(TypePredicate.builder().sourceKey("AssetAType").build()))
            .build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, nameOrSourceKey)).hasSize(2)
            .extracting(AssetType::getName).containsOnly("AssetAType", "AssetDType");
        nameOrSourceKey.setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, nameOrSourceKey)).hasSize(4)
            .extracting(AssetType::getName).containsOnly("AssetAType", "AssetDType", "AssetDSubType",
            "AssetDSubSubType");
    }

    /**
     * (parent sourceKey = "AssetDType") with or without deep search
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byParentSourceKeyLike_deepSearch() throws IOException {
        setupData();
        TypePredicate parentSourceKeyLike = TypePredicate.builder().parent(
            ParentPredicate.builder().sourceKey("A*DType").build()).build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, parentSourceKeyLike)).hasSize(1)
            .extracting(AssetType::getName).containsOnly("AssetDSubType");
        parentSourceKeyLike.setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, parentSourceKeyLike)).hasSize(2)
            .extracting(AssetType::getName).containsOnly("AssetDSubType", "AssetDSubSubType");
        parentSourceKeyLike.setDeepSearch(false);
        parentSourceKeyLike.getParent().setDeepSearch(true); // this one makes more sense
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, parentSourceKeyLike)).hasSize(2)
            .extracting(AssetType::getName).containsOnly("AssetDSubType", "AssetDSubSubType");
    }

    /**
     * id = ROOT_ASSET_TYPE_ID with deep search
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byRootTypeId_inIds_andParentNameEquals_deepSearch() throws IOException {
        setupData();
        TypePredicate byTypeId = TypePredicate.builder().ids(Collections.singleton(ROOT_ASSET_TYPE_ID)).deepSearch(true)
            .parent(ParentPredicate.builder().name("AssetDType").deepSearch(true).build()).build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, byTypeId)).hasSize(2)
            .extracting(AssetType::getName).containsOnly("AssetDSubType", "AssetDSubSubType");
    }

    /**
     * id = ROOT_SITE_TYPE_ID with deep search
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byRootTypeId_andSourceKey() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        AssetType s1Type = (AssetType) data.get("S1Type");
        TypePredicate predicate = TypePredicate.builder().ids(Collections.singleton(ROOT_SITE_TYPE_ID)).deepSearch(true)
            .sourceKey(s1Type.getSourceKey()).build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, predicate)).hasSize(1)
            .extracting(AssetType::getName).containsOnly("S1Type");
    }

    /**
     * (parent name = "AssetDType") with or without deep search
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byParentNameEquals_deepSearch() throws IOException {
        setupData();
        TypePredicate parentName = TypePredicate.builder().parent(ParentPredicate.builder().name("AssetDType").build())
            .build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, parentName)).hasSize(1)
            .extracting(AssetType::getName).containsOnly("AssetDSubType");
        parentName.setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, parentName)).hasSize(2)
            .extracting(AssetType::getName).containsOnly("AssetDSubType", "AssetDSubSubType");
        parentName.setDeepSearch(false);
        parentName.getParent().setDeepSearch(true); // this one makes more sense
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, parentName)).hasSize(2)
            .extracting(AssetType::getName).containsOnly("AssetDSubType", "AssetDSubSubType");
    }

    /**
     * (parent name = "AssetDType") with or without deep search
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byParentDescrptionEquals_deepSearch() throws IOException {
        setupData();
        TypePredicate parentDescription = TypePredicate.builder().parent(
            ParentPredicate.builder().description("AssetDType").build()).build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, parentDescription)).hasSize(1)
            .extracting(AssetType::getName).containsOnly("AssetDSubType");
        parentDescription.setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, parentDescription)).hasSize(2)
            .extracting(AssetType::getName).containsOnly("AssetDSubType", "AssetDSubSubType");
        parentDescription.setDeepSearch(false);
        parentDescription.getParent().setDeepSearch(true); // this one makes more sense
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, parentDescription)).hasSize(2)
            .extracting(AssetType::getName).containsOnly("AssetDSubType", "AssetDSubSubType");
    }

    /**
     * (name like "*B*" or sourceKey = "AssetAType") with or without deep search
     */
    @Test
    @Transactional
    public void findAllAssetTypes_byNameOrParentSourceKeyLike_deepSearch() throws IOException {
        setupData();
        TypePredicate nameOrParentSourceKeyLike = TypePredicate.builder().name("*B*").childOperand(Operand.OR)
            .childPredicates(Collections.singletonList(
                TypePredicate.builder().parent(ParentPredicate.builder().sourceKey("A*DType").build()).build()))
            .build();
        // lower case "*b*" in name also matched "AssetDSubSubType"
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, nameOrParentSourceKeyLike))
            .hasSize(3).extracting(AssetType::getName).containsOnly("AssetBType", "AssetDSubType", "AssetDSubSubType");
        nameOrParentSourceKeyLike.getChildPredicates().get(0).setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, nameOrParentSourceKeyLike))
            .hasSize(3).extracting(AssetType::getName).containsOnly("AssetBType", "AssetDSubType", "AssetDSubSubType");
        nameOrParentSourceKeyLike.getChildPredicates().get(0).setDeepSearch(false);
        nameOrParentSourceKeyLike.getChildPredicates().get(0).getParent().setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, nameOrParentSourceKeyLike))
            .hasSize(3).extracting(AssetType::getName).containsOnly("AssetBType", "AssetDSubType", "AssetDSubSubType");

        // verify search is case-insensitive
        nameOrParentSourceKeyLike = TypePredicate.builder().name("*B*").childOperand(Operand.OR).childPredicates(
            Collections.singletonList(TypePredicate.builder()
                .parent(ParentPredicate.builder().sourceKey("A*DType".toUpperCase(Locale.getDefault())).build())
                .build())).build();
        // lower case "*b*" in name also matched "AssetDSubSubType"
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, nameOrParentSourceKeyLike))
            .hasSize(3).extracting(AssetType::getName).containsOnly("AssetBType", "AssetDSubType", "AssetDSubSubType");
        nameOrParentSourceKeyLike.getChildPredicates().get(0).setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, nameOrParentSourceKeyLike))
            .hasSize(3).extracting(AssetType::getName).containsOnly("AssetBType", "AssetDSubType", "AssetDSubSubType");
        nameOrParentSourceKeyLike.getChildPredicates().get(0).setDeepSearch(false);
        nameOrParentSourceKeyLike.getChildPredicates().get(0).getParent().setDeepSearch(true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, nameOrParentSourceKeyLike))
            .hasSize(3).extracting(AssetType::getName).containsOnly("AssetBType", "AssetDSubType", "AssetDSubSubType");
    }

    @Test
    @Transactional
    public void findAllAssetTypes_withNoPrefix() throws IOException {

        setupData();
        String tenantId = TestUtils.TEST_TENANT;

        TypePredicate predicate1 = TypePredicate.builder().orderBy("created_date").order("ASC").offset(0).pageSize(2)
            .build();
        TypePredicate predicate2 = TypePredicate.builder().orderBy("created_date").order("ASC").offset(2).pageSize(2)
            .build();

        List<AssetType> found = Stream.concat(
            assetTypePersistencyService.findAllAssetTypesWithNoPrefix(tenantId, predicate1).stream(),
            assetTypePersistencyService.findAllAssetTypesWithNoPrefix(tenantId, predicate2).stream()).collect(
            Collectors.toList());
        assertThat(IntStream.range(0, found.size() - 1).filter(i -> found.get(i).getCreatedDate()
            .compareTo(found.get(i + 1).getCreatedDate()) > 0).count()).isEqualTo(0);

        assertThat(IntStream.range(0, found.size()).mapToObj(i -> found.get(i).getId()).collect(Collectors.toSet()))
            .hasSize(4);
    }

    @Test
    @Transactional
    public void findAllAssetTypes_withNoPrefix_AttributesWithSuperTypes()
        throws IOException {

        Map<String, BaseDataModel> data = setupData();
        String tenantId = TestUtils.TEST_TENANT;

        TypePredicate predicate1 = TypePredicate.builder().attributeSelectEnum(
            AttributeSelectEnum.ATTRIBUTES_WITH_SUPERTYPES).orderBy("created_date").order("ASC").offset(0).pageSize(2)
            .build();

        List<AssetType> assetTypes = assetTypePersistencyService.findAllAssetTypesWithNoPrefix(tenantId, predicate1);
        assertThat(assetTypes).hasSize(2);

        AssetType e1Type = (AssetTypeEntity)data.get("E1Type");
        assertThat(assetTypes.get(0)).extracting(AssetType::getSuperTypesArray).containsOnly(e1Type.getSuperTypesArray());

        AssetType s1Type = (AssetTypeEntity)data.get("S1Type");
        assertThat(assetTypes.get(1)).extracting(AssetType::getSuperTypesArray).containsOnly(s1Type
            .getSuperTypesArray());

    }


    @Test
    @Transactional
    public void findAllAssetTypes_PagingWithSortKey() throws IOException {
        setupData();
        TypePredicate predicate = TypePredicate.builder().parent(
            ParentPredicate.builder().ids(Sets.newHashSet(ROOT_ASSET_TYPE_ID)).deepSearch(true).build())
            .pageSize(100).build();
        List<AssetType> all = assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, predicate);

        int pageSize = 1;
        int numPages = all.size();
        predicate.setPagingInfo(0, pageSize, null, true);
        List<AssetType> found = assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, predicate);
        assertThat(found).hasSize(pageSize);
        assertThat(found.stream().map(AssetType::getId).collect(Collectors.toList()))
            .containsExactlyElementsOf(all.subList(0, pageSize).stream()
                .map(AssetType::getId).collect(Collectors.toList()));

        String sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        assertThat(sortKey).isNotEmpty();

        int offset = pageSize;
        while (offset < pageSize * numPages) {
            predicate.setPagingInfo(0, pageSize, sortKey, true);
            found = assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, predicate);
            assertThat(found).hasSize(pageSize);
            assertThat(found.stream().map(AssetType::getId).collect(Collectors.toList()))
                .containsExactlyElementsOf(all.subList(offset, offset + pageSize).stream()
                    .map(AssetType::getId).collect(Collectors.toList()));
            offset += pageSize;
            sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        }

        predicate.setPagingInfo(0, pageSize, sortKey, true);
        assertThat(assetTypePersistencyService.findAllAssetTypes(TestUtils.TEST_TENANT, predicate)).isEmpty();
    }

    Map<String, BaseDataModel> setupData() throws IOException {
        return PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService, assetPersistencyService);
    }
}
