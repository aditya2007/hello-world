/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.template;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.PlaceholderType;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholder;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderType;
import com.ge.apm.alm.persistence.jpa.model.TestTemplate;
import com.ge.apm.alm.persistence.jpa.utils.TestTemplateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */
public class PlaceholderTypePersistSvcTests extends TemplatePersistSvcBaseTests {

    private static final String ASSET_TYPE_NAME = "GE90";

    @Test
    @Transactional
    public void testCreatePlaceholderType() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType = createTestPlaceholderType(testPlaceholder, assetType);

        // make sure that retrieve Placeholder, PlaceholderType also returned.
        Placeholder dbPlaceholder = placeholderPersistencyService
            .getPlaceholderById(TestUtils.TEST_TENANT, testPlaceholder.getId());
        assertThat(dbPlaceholder).isNotNull();
        assertThat(dbPlaceholder.getId()).isEqualTo(testPlaceholder.getId());
        assertThat(dbPlaceholder.getPlaceholderTypes().get(0).getId()).isEqualTo(testPlaceholderType.getId());
        assertThat(dbPlaceholder.getPlaceholderTypes().get(0).getTypeId()).isEqualTo(testPlaceholderType.getTypeId());

        // delete template cascade
        List<TestPlaceholderType> testPlaceholderTypes = new ArrayList<>();
        testPlaceholderTypes.add(testPlaceholderType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderType_missingId() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderType testPlaceholderType = TestTemplateUtils.buildPlaceholderType(uuid, uuid);
        testPlaceholderType.setId(null);
        placeholderTypePersistencyService.createPlaceholderType(TestUtils.TEST_TENANT, testPlaceholderType);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderType_missingPlaceholderId() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderType testPlaceholderType = TestTemplateUtils.buildPlaceholderType(uuid, uuid);
        testPlaceholderType.setPlaceholderId(null);
        placeholderTypePersistencyService.createPlaceholderType(TestUtils.TEST_TENANT, testPlaceholderType);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderType_missingTypeId() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderType testPlaceholderType = TestTemplateUtils.buildPlaceholderType(uuid, uuid);
        testPlaceholderType.setTypeId(null);
        placeholderTypePersistencyService.createPlaceholderType(TestUtils.TEST_TENANT, testPlaceholderType);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholderType_missingStatus() {
        String uuid = TestTemplateUtils.getNewUuid();
        TestPlaceholderType testPlaceholderType = TestTemplateUtils.buildPlaceholderType(uuid, uuid);
        testPlaceholderType.setStatus(null);
        placeholderTypePersistencyService.createPlaceholderType(TestUtils.TEST_TENANT, testPlaceholderType);
    }


    @Test
    @Transactional
    public void testCreatePlaceholderTypes() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType1 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        AssetType assetType2 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);

        List<PlaceholderType> placeholderTypes = new ArrayList<>();
        final String placeholderId = testPlaceholder.getId();
        placeholderTypes.add(TestTemplateUtils.buildPlaceholderType(placeholderId, assetType1.getId()));
        placeholderTypes.add(TestTemplateUtils.buildPlaceholderType(placeholderId, assetType2.getId()));

        final String tenantId = TestUtils.TEST_TENANT;
        int counter = placeholderTypePersistencyService.createPlaceholderTypes(tenantId, new ArrayList<>());
        assertThat(counter).isEqualTo(0);

        counter = placeholderTypePersistencyService.createPlaceholderTypes(tenantId, placeholderTypes);
        assertThat(counter).isEqualTo(placeholderTypes.size());

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTypes(Collections.unmodifiableList(placeholderTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testUpdatePlaceholderType() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType = createTestPlaceholderType(testPlaceholder, assetType);

        testPlaceholderType.setStatus("Inactive");
        PlaceholderType savedPlaceholderType = placeholderTypePersistencyService
            .updatePlaceholderType(TestUtils.TEST_TENANT, testPlaceholderType);
        assertThat(savedPlaceholderType).isNotNull();
        assertThat(savedPlaceholderType.getId()).isEqualTo(testPlaceholderType.getId());
        assertThat(savedPlaceholderType.getStatus()).isEqualTo(testPlaceholderType.getStatus());

        // delete template cascade
        List<TestPlaceholderType> testPlaceholderTypes = new ArrayList<>();
        testPlaceholderTypes.add(testPlaceholderType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testUpdatePlaceholderTypes() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType1 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        AssetType assetType2 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);

        List<PlaceholderType> placeholderTypes = new ArrayList<>();
        final String placeholderId = testPlaceholder.getId();
        placeholderTypes.add(TestTemplateUtils.buildPlaceholderType(placeholderId, assetType1.getId()));
        placeholderTypes.add(TestTemplateUtils.buildPlaceholderType(placeholderId, assetType2.getId()));

        final String tenantId = TestUtils.TEST_TENANT;
        int counter = placeholderTypePersistencyService.updatePlaceholderTypes(tenantId, new ArrayList<>());
        assertThat(counter).isEqualTo(0);

        counter = placeholderTypePersistencyService.createPlaceholderTypes(tenantId, placeholderTypes);
        assertThat(counter).isEqualTo(2);

        AssetType assetType3 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        placeholderTypes.add(TestTemplateUtils.buildPlaceholderType(placeholderId, assetType3.getId()));
        counter = placeholderTypePersistencyService.updatePlaceholderTypes(tenantId, placeholderTypes);
        assertThat(counter).isEqualTo(3);

        // delete template cascade
        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTypes(Collections.unmodifiableList(placeholderTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testDeletePlaceholderType_Id() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType = createTestPlaceholderType(testPlaceholder, assetType);

        int counter = placeholderTypePersistencyService
            .deletePlaceholderType(TestUtils.TEST_TENANT, testPlaceholderType.getId());
        assertThat(counter).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholderType> testPlaceholderTypes = new ArrayList<>();
        testPlaceholderTypes.add(testPlaceholderType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeletePlaceholderType_Id_NotFoundException() throws PersistencyServiceException {
        placeholderTypePersistencyService.deletePlaceholderType(TestUtils.TEST_TENANT,
            TestTemplateUtils.getNewUuid());
    }


    @Test
    @Transactional
    public void testDeletePlaceholderType_placeholderId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType = createTestPlaceholderType(testPlaceholder, assetType);

        int counter = placeholderTypePersistencyService
            .deletePlaceholderTypeByPlaceholderId(TestUtils.TEST_TENANT, testPlaceholderType.getPlaceholderId());
        assertThat(counter).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholderType> testPlaceholderTypes = new ArrayList<>();
        testPlaceholderTypes.add(testPlaceholderType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeletePlaceholderType_placeholderId_NotFoundException() throws PersistencyServiceException {
        placeholderTypePersistencyService.deletePlaceholderTypeByPlaceholderId(TestUtils.TEST_TENANT,
            TestTemplateUtils.getNewUuid());
    }

    @Test
    @Transactional
    public void testDeletePlaceholderTypeByPlaceholderIdAndTypeId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType = createTestPlaceholderType(testPlaceholder, assetType);

        int counter = placeholderTypePersistencyService
            .deletePlaceholderTypeByPlaceholderIdAndTypeId(TestUtils.TEST_TENANT,
                testPlaceholderType.getPlaceholderId(),
                testPlaceholderType.getTypeId());
        assertThat(counter).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholderType> testPlaceholderTypes = new ArrayList<>();
        testPlaceholderTypes.add(testPlaceholderType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test(expected = ObjectNotFoundException.class)
    public void testDeletePlaceholderTypeByPlaceholderIdAndTypeId_NotFoundException()
        throws PersistencyServiceException {
        String uuid = TestTemplateUtils.getNewUuid();
        placeholderTypePersistencyService.deletePlaceholderTypeByPlaceholderIdAndTypeId(TestUtils.TEST_TENANT,
            uuid, uuid);
    }

    @Test
    @Transactional
    public void testGetPlaceholderTypeById() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType = createTestPlaceholderType(testPlaceholder, assetType);

        PlaceholderType dbPlaceholderType = placeholderTypePersistencyService
            .getPlaceholderTypeById(TestUtils.TEST_TENANT, testPlaceholderType.getId());
        assertThat(dbPlaceholderType).isNotNull();
        assertThat(dbPlaceholderType.getId()).isEqualTo(testPlaceholderType.getId());

        // delete template cascade
        List<TestPlaceholderType> testPlaceholderTypes = new ArrayList<>();
        testPlaceholderTypes.add(testPlaceholderType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    public void testGetPlaceholderTypeById_EmptyResultDataAccessException() {
        assertThat(placeholderTypePersistencyService
            .getPlaceholderTypeById(TestUtils.TEST_TENANT, TestTemplateUtils.getNewUuid())).isNull();
    }

    @Test
    @Transactional
    public void testGetPlaceholderTypeByPlaceholderIdAndTypeId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType = createTestPlaceholderType(testPlaceholder, assetType);

        PlaceholderType dbPlaceholderType = placeholderTypePersistencyService
            .getPlaceholderTypeByPlaceholderIdAndTypeId(TestUtils.TEST_TENANT, testPlaceholderType.getPlaceholderId(),
                testPlaceholderType.getTypeId());
        assertThat(dbPlaceholderType).isNotNull();
        assertThat(dbPlaceholderType.getId()).isEqualTo(testPlaceholderType.getId());

        // delete template cascade
        List<TestPlaceholderType> testPlaceholderTypes = new ArrayList<>();
        testPlaceholderTypes.add(testPlaceholderType);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes));
        testPlaceholders.add(testPlaceholder);
        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    public void testGetPlaceholderTypeByPlaceholderIdAndTypeId_EmptyResultDataAccessException() {
        String uuid = TestTemplateUtils.getNewUuid();
        assertThat(placeholderTypePersistencyService
            .getPlaceholderTypeByPlaceholderIdAndTypeId(TestUtils.TEST_TENANT, uuid, uuid)).isNull();
    }

    @Test
    @Transactional
    public void testGetPlaceholderTypes_placeholderId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType1 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType1 = createTestPlaceholderType(testPlaceholder1, assetType1);

        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN02");
        AssetType assetType2 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType2 = createTestPlaceholderType(testPlaceholder2, assetType2);

        final String tenantId = TestUtils.TEST_TENANT;
        assertThat(placeholderTypePersistencyService.getPlaceholderTypes(tenantId, new ArrayList<>())).isEmpty();

        List<PlaceholderType> foundPlaceholders = placeholderTypePersistencyService
            .getPlaceholderTypes(tenantId, testPlaceholder1.getId());
        assertThat(foundPlaceholders.size()).isEqualTo(1);
        assertThat(foundPlaceholders.get(0).getId()).isEqualTo(testPlaceholderType1.getId());

        // delete template cascade
        List<TestPlaceholderType> testPlaceholderTypes1 = new ArrayList<>();
        List<TestPlaceholderType> testPlaceholderTypes2 = new ArrayList<>();
        testPlaceholderTypes1.add(testPlaceholderType1);
        testPlaceholderTypes2.add(testPlaceholderType2);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes1));
        testPlaceholder2.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes2));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);

        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testGetPlaceholderTypes_placeholderIdAndStatus() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType1 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType1 = createTestPlaceholderType(testPlaceholder1, assetType1);

        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN02");
        AssetType assetType2 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType2 = createTestPlaceholderType(testPlaceholder2, assetType2);

        List<PlaceholderType> foundPlaceholders = placeholderTypePersistencyService
            .getPlaceholderTypes(TestUtils.TEST_TENANT, testPlaceholderType1.getPlaceholderId(),
                testPlaceholderType1.getStatus());
        assertThat(foundPlaceholders.size()).isEqualTo(1);
        assertThat(foundPlaceholders.get(0).getId()).isEqualTo(testPlaceholderType1.getId());

        // delete template cascade
        List<TestPlaceholderType> testPlaceholderTypes1 = new ArrayList<>();
        List<TestPlaceholderType> testPlaceholderTypes2 = new ArrayList<>();
        testPlaceholderTypes1.add(testPlaceholderType1);
        testPlaceholderTypes2.add(testPlaceholderType2);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes1));
        testPlaceholder2.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes2));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);

        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);
    }

    @Test
    @Transactional
    public void testGetPlaceholderTypes_placeholderIds() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN01");
        AssetType assetType1 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType1 = createTestPlaceholderType(testPlaceholder1, assetType1);

        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN02");
        AssetType assetType2 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType2 = createTestPlaceholderType(testPlaceholder2, assetType2);

        List<String> placeholderIds = new ArrayList<>();
        placeholderIds.add(testPlaceholder1.getId());
        placeholderIds.add(testPlaceholder2.getId());

        List<PlaceholderType> foundPlaceholders = placeholderTypePersistencyService
            .getPlaceholderTypes(TestUtils.TEST_TENANT, placeholderIds);
        assertThat(foundPlaceholders.size()).isEqualTo(2);
        assertThat(foundPlaceholders.get(0).getId()).isEqualTo(testPlaceholderType1.getId());

        // make sure that retrieve Placeholder, PlaceholderType also returned.
        Template dbTemplate = templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, testTemplate.getId());
        assertThat(dbTemplate).isNotNull();
        assertThat(dbTemplate.getPlaceholders().size()).isEqualTo(2);
        assertThat(dbTemplate.getPlaceholders().get(0).getPlaceholderTypes().size()).isEqualTo(1);
        assertThat(dbTemplate.getPlaceholders().get(1).getPlaceholderTypes().size()).isEqualTo(1);

        // delete template cascade
        List<TestPlaceholderType> testPlaceholderTypes1 = new ArrayList<>();
        List<TestPlaceholderType> testPlaceholderTypes2 = new ArrayList<>();
        testPlaceholderTypes1.add(testPlaceholderType1);
        testPlaceholderTypes2.add(testPlaceholderType2);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes1));
        testPlaceholder2.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes2));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);

        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);

    }

    @Test
    @Transactional
    public void testGetPlaceholderTypeByTemplateId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestPlaceholder testPlaceholder1 = createTestPlaceholder(testTemplate, "PPN10");
        AssetType assetType1 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType1 = createTestPlaceholderType(testPlaceholder1, assetType1);

        TestPlaceholder testPlaceholder2 = createTestPlaceholder(testTemplate, "PPN11");
        AssetType assetType2 = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType2 = createTestPlaceholderType(testPlaceholder2, assetType2);

        List<PlaceholderType> foundPlaceholders = placeholderTypePersistencyService
            .getPlaceholderTypeByTemplateId(TestUtils.TEST_TENANT, testTemplate.getId());
        assertThat(foundPlaceholders.size()).isEqualTo(2);
        assertThat(foundPlaceholders.get(0).getId()).isEqualTo(testPlaceholderType1.getId());

        // delete template cascade
        List<TestPlaceholderType> testPlaceholderTypes1 = new ArrayList<>();
        List<TestPlaceholderType> testPlaceholderTypes2 = new ArrayList<>();
        testPlaceholderTypes1.add(testPlaceholderType1);
        testPlaceholderTypes2.add(testPlaceholderType2);

        List<TestPlaceholder> testPlaceholders = new ArrayList<>();
        testPlaceholder1.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes1));
        testPlaceholder2.setPlaceholderTypes(Collections.unmodifiableList(testPlaceholderTypes2));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);

        testTemplate.setPlaceholders(Collections.unmodifiableList(testPlaceholders));

        deleteTestTemplateCascade(testTemplate);

    }

    private void deleteTestTemplateCascade(TestTemplate testTemplate) throws PersistencyServiceException {
        String templateId = testTemplate.getId();
        final String tenantId = TestUtils.TEST_TENANT;
        templatePersistencyService.deleteTemplateById(tenantId, templateId);
        assertThat(templatePersistencyService.getTemplateById(tenantId, templateId)).isNull();

        List<Placeholder> placeholders = testTemplate.getPlaceholders();
        for (Placeholder placeholder : placeholders) {
            assertThat(placeholderPersistencyService.getPlaceholderById(tenantId, placeholder.getId()))
                .isNull();

            List<PlaceholderType> placeholderTypes = placeholder.getPlaceholderTypes();
            if (!CollectionUtils.isEmpty(placeholderTypes)) {
                placeholderTypes.forEach(placeholderType -> assertThat(
                    placeholderTypePersistencyService.getPlaceholderTypeById(tenantId, placeholderType.getId()))
                    .isNull());

            }
        }
    }

}
