/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.Direction;
import com.ge.apm.alm.model.Edge;
import com.ge.apm.alm.model.Network;
import com.ge.apm.alm.model.NetworkHierarchy;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.NetworkPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.model.TestEdge;
import com.ge.apm.alm.persistence.jpa.model.TestNetwork;
import com.ge.apm.alm.persistence.jpa.model.TestNetworkHierarchy;

public final class NetworkUtils {

    private NetworkUtils() {
    }

    public static Network createNetwork() throws IOException {
        return createNetwork(null);
    }

    public static Network createNetwork(String assetId) throws IOException {
        return createNetwork(null, assetId);
    }

    public static Network createNetwork(String name, String assetId) throws IOException {
        String id = UUID.randomUUID().toString();
        name = StringUtils.isBlank(name) ? "network-name-" + id : name;
        return TestNetwork.builder().id(id).assetId(assetId).sourceKey("sourceKey-" + name).name(name).description(
            "description-" + name).tenantId(TenantTestUtils.getTenantId()).attributes(
            TestUtils.getAttributes("attributes-" + name)).createdBy(TestUtils.TEST_USER).lastModifiedBy(
            TestUtils.TEST_USER).build();
    }

    public static NetworkHierarchy createNetworkHierarchy(String networkNodeId, String parentNetworkId) {
        return TestNetworkHierarchy.builder().id(UUID.randomUUID().toString()).tenantId(TenantTestUtils.getTenantId())
            .createdBy(TestUtils.TEST_USER).lastModifiedBy(TestUtils.TEST_USER).networkNodeId(networkNodeId)
            .parentNetworkId(parentNetworkId).build();
    }

    private static Edge createEdge(String name, String source, String target, Direction direction, String assetId)
        throws IOException {
        String id = UUID.randomUUID().toString();
        name = StringUtils.isBlank(name) ? "edge-name-" + id : name;
        return TestEdge.builder().id(id).name(name).tenantId(TenantTestUtils.getTenantId()).description("description-" + name)
            .source(source).target(target).direction(direction).assetId(assetId).attributes(
                TestUtils.getAttributes("attributes-" + name)).createdBy(TestUtils.TEST_USER).lastModifiedBy(
                TestUtils.TEST_USER).build();
    }

    public static Edge createEdge(String source, String target, Direction direction, String assetId)
        throws IOException {

        return createEdge(null, source, target, direction, assetId);
    }

    /**
     * Set up the following network topology, with 6 networks, 6 assets, and 6 edges each.
     * **********************************************************************************************
     *  -----------------------------------------------------------------------------------------   *
     * |  network-E                                                                              |  *
     * |                                                                                         |  *
     * |   ------------------------------------         ---------------------------------------  |  *
     * |  | network-A                          |       | network-B                             | |  *
     * |                                       |       |  node-A1                              | |  *
     * |  |                                    | <-->  |                             --------- | |  *
     * |  |  node-A1 <--> node-A2 --> node-A3  |       |  node-A4 --> node-A5 --- |network-D|  | |  *
     * |  |           A6                  ^    |       |      ^                     ---------  | |  *
     * |   -------------------------------|----         ------|--------------------------------  |  *
     * |                                  |___________________|                                  |  *
     * |                                     -----------                                         |  *
     * |                                    | network-C |                                        |  *
     * |                                     -----------                                         |  *
     *  -----------------------------------------------------------------------------------------   *
     *                                                                                              *
     *  -----------                                                                                 *
     * | network-F |                                                                                *
     *  -----------                                                                                 *
     * **********************************************************************************************
     */
    public static Map<String, BaseDataModel> setupNetworks(AssetTypePersistencyService assetTypePersistencyService,
        AssetPersistencyService assetPersistencyService, NetworkPersistencyService networkPersistencyService)
        throws IOException, PersistencyServiceException {

        Map<String, BaseDataModel> data = AssetUtils.setupData(assetTypePersistencyService, assetPersistencyService);
        BaseDataModel assetType = data.get("MyAssetType");
        BaseDataModel e1S1Seg1 = data.get("E1_S1_Seg1");
        int totalAssets = 6;
        for (int i = 1; i <= totalAssets; i++) {
            String name = "A" + i;
            data.put(name, TestUtils
                .createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), assetType.getId(),
                    e1S1Seg1.getId(), name));
        }

        List<Network> networks = Arrays.asList(NetworkUtils.createNetwork("network-A-A1,A2,A3", null),
            NetworkUtils.createNetwork("network-B-A1,A4,A5-D", null),
            NetworkUtils.createNetwork("network-C-empty", null),
            NetworkUtils.createNetwork("network-D-empty-child-of-B", null),
            NetworkUtils.createNetwork("network-E-parent-of-A,B,C", null),
            NetworkUtils.createNetwork("network-F-empty", null));

        networkPersistencyService.createNetworks(TenantTestUtils.getTenantId(), TestUtils.getUber(), networks);
        networks.forEach(n -> data.put(n.getName(), n));

        // network A: contains {assets (A1, A2, A3)}, child of network-E
        // network B: contains {assets (A1, A4, A5), network-D}, child of network-E
        // network C: empty, child of network-E
        // network D: empty, child of network-B
        // network E: parent of networks A, B, C
        // network F: stand-alone, empty
        networkPersistencyService.addAssetsToNetwork(TenantTestUtils.getTenantId(), TestUtils.getUber(),
            data.get("network-A-A1,A2,A3").getId(),
            Arrays.asList((Asset) data.get("A1"), (Asset) data.get("A2"), (Asset) data.get("A3")));
        networkPersistencyService.addAssetsToNetwork(TenantTestUtils.getTenantId(), TestUtils.getUber(),
            data.get("network-B-A1,A4,A5-D").getId(), Arrays.asList((Asset) data.get("A4"), (Asset) data.get("A5")));
        networkPersistencyService.addChildrenToNetwork(TenantTestUtils.getTenantId(), TestUtils.getUber(),
            data.get("network-B-A1,A4,A5-D").getId(),
            Collections.singletonList((Network) data.get("network-D-empty-child-of-B")));
        networkPersistencyService.addChildrenToNetwork(TenantTestUtils.getTenantId(), TestUtils.getUber(),
            data.get("network-E-parent-of-A,B,C").getId(), Arrays
                .asList((Network) data.get("network-A-A1,A2,A3"), (Network) data.get("network-B-A1,A4,A5-D"),
                    (Network) data.get("network-C-empty")));

        // edges: assets A1<->A2->A3, A4->A5, A3<->A4 ||| A5 <-> network-D ||| networks A<->B
        List<Asset> assets = new ArrayList<>();
        for (int i = 1; i <= totalAssets; i++) {
            assets.add((Asset) data.get("A" + i));
        }
        Set<String> assetIds = new HashSet<>();
        assets.forEach(a -> assetIds.add(a.getId()));
        Map<String, List<Network>> assetToNetworks = networkPersistencyService.getNodesByAssetIds(
            TenantTestUtils.getTenantId(),
            TestUtils.getUber(), assetIds);
        List<Edge> edges = Arrays.asList(NetworkUtils.createEdge("edge-A1<-->A2", assetToNetworks.get(
            data.get("A1").getId()).get(0).getId(), assetToNetworks.get(data.get("A2").getId()).get(0).getId(),
            Direction.BIDIRECTIONAL, data.get("A6").getId()),
            NetworkUtils.createEdge("edge-A2-->A3", assetToNetworks.get(data.get("A2").getId()).get(0).getId(),
                assetToNetworks.get(data.get("A3").getId()).get(0).getId(), Direction.UNIDIRECTIONAL, null),
            NetworkUtils.createEdge("edge-A4-->A5", assetToNetworks.get(data.get("A4").getId()).get(0).getId(),
                assetToNetworks.get(data.get("A5").getId()).get(0).getId(), Direction.UNIDIRECTIONAL, null),
            NetworkUtils.createEdge("edge-A3<-->A4", assetToNetworks.get(data.get("A3").getId()).get(0).getId(),
                assetToNetworks.get(data.get("A4").getId()).get(0).getId(), Direction.BIDIRECTIONAL, null),
            NetworkUtils.createEdge("edge-A5---network-D", assetToNetworks.get(data.get("A5").getId()).get(0).getId(),
                data.get("network-D-empty-child-of-B").getId(), Direction.UNDIRECTED, null), NetworkUtils
                .createEdge("edge-network-A<-->network-B", data.get("network-A-A1,A2,A3").getId(),
                    data.get("network-B-A1,A4,A5-D").getId(), Direction.BIDIRECTIONAL, null));
        networkPersistencyService.createEdges(TenantTestUtils.getTenantId(), TestUtils.getUber(), edges);
        edges.forEach(edge -> {
            data.put(edge.getName(), edge);
        });

        // add an extra stand-alone node with asset A1 to network-B
        networkPersistencyService.addAssetsToNetwork(TenantTestUtils.getTenantId(), TestUtils.getUber(),
            data.get("network-B-A1,A4,A5-D").getId(), Collections.singletonList((Asset) data.get("A1")));
        return data;
    }
}
