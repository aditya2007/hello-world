/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.tag.correlation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroupItem;
import com.ge.apm.alm.persistence.jpa.utils.TagPredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TagInsertHeadItemTests extends TagCorrelationBaseTest {

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void insertHeadItemToCorrelatedGroup_groupNotFound_asUber() throws IOException, PersistencyServiceException {
        groupPersistencyService
            .insertHeadItemToCorrelatedGroup(TestUtils.TEST_TENANT, TestUtils.getUber(), TestUtils.NULL_UUID,
                TestAssetGroupItem.builder().build());
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void insertHeadItemToCorrelatedGroup_groupNotFound_asUnprivilegedUser()
        throws IOException, PersistencyServiceException {
        groupPersistencyService
            .insertHeadItemToCorrelatedGroup(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), TestUtils.NULL_UUID,
                TestAssetGroupItem.builder().build());
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void insertHeadItemToCorrelatedGroup_notTagCorrelation() throws IOException, PersistencyServiceException {
        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG).name("test").sourceKey("myTestSrcKey")
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG);
        groupPersistencyService
            .insertHeadItemToCorrelatedGroup(TestUtils.TEST_TENANT, TestUtils.getUber(), group.getId(),
                TestAssetGroupItem.builder().build());
    }

    @Test
    @Transactional
    public void insertHeadItemToCorrelatedGroup() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 4;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);
        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group))
            .extracting(AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        // create a correlation with the first 3 typeInstances
        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count - 1; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }
        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1").getId()),
                group.getId(), items)).isEqualTo(items.size());
        assertThat(groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, Collections.singletonList(assets.get("E1_S1_Seg1_Asset1").getId()),
                group.getId())).hasSize(items.size()).extracting(AssetGroupItem::getPosition).containsOnly(1, 2, 3);

        // add the 4th tag at the head, as a uber
        AssetGroupItem item = TagPredicateUtils.newTagCorrelationItem(tags.get(3), group.getId());
        AssetGroupItem addedItem =
            groupPersistencyService
                .insertHeadItemToCorrelatedGroup(TestUtils.TEST_TENANT, TestUtils.getUber(), group.getId(), item);
        assertThat(addedItem.getObjectId()).isEqualTo(item.getObjectId());
        assertThat(addedItem.getPosition()).isEqualTo(1);
        List<AssetGroupItem> retrieved = groupPersistencyService
            .getGroupItems(TestUtils.TEST_TENANT, Collections.singletonList(assets.get("E1").getId()), group.getId());
        assertThat(retrieved.size()).isEqualTo(4);
        int[] index = new int[] { 3, 0, 1, 2 };
        for (int i = 0, size = retrieved.size(); i < size; i++) {
            assertThat(retrieved.get(i).getPosition()).isEqualTo(i + 1);
            assertThat(retrieved.get(i).getObjectId()).isEqualTo(tags.get(index[i]).getId());
        }
    }
}
