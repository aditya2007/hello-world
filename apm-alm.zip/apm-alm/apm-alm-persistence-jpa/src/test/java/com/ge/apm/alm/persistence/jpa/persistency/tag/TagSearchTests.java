/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.tag;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.Sets;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.utils.TagPredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_TAG_TYPE_ID;
import static com.ge.apm.alm.model.query.Operand.OR;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test searching of typeInstances.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TagSearchTests {

    private static final String IDS = "ids";

    JsonNode EMPTY_JSON_NODE = TestUtils.emptyJsonNode();

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private TagPersistencyService tagPersistencyService;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    @After
    public void tearDown() {
        TestUtils.destroyAssetUserPolicies();
    }

    @Test
    @Transactional
    public void getTags_byEmptyPredicate() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);

        TagPredicate predicate = TagPredicate.builder().build();
        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(
            tags.size());
        assertThat(
            tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(tag.getAssetId()), predicate))
            .hasSize(tags.size());
        assertThat(tagPersistencyService
            .getTags(tag.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                predicate)).hasSize(tags.size());
        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void getTags_byName() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);

        TagPredicate predicate = TagPredicate.builder().name(tag.getName()).build();

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(
            tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(tag.getAssetId()), predicate))
            .hasSize(1).extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(tagPersistencyService
            .getTags(tag.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                predicate)).hasSize(1).extracting(Tag::getName).containsOnly(tag.getName());

        predicate = TagPredicate.builder().name(tag.getName().toUpperCase(Locale.getDefault())).build();

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(
            tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(tag.getAssetId()), predicate))
            .hasSize(1).extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(tagPersistencyService
            .getTags(tag.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                predicate)).hasSize(1).extracting(Tag::getName).containsOnly(tag.getName());

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(), predicate)).hasSize(0);
        predicate.setName("name-not-found");
        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void getTags_byDescription() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);

        TagPredicate predicate = TagPredicate.builder().description(tag.getDescription()).build();

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(
            tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(tag.getAssetId()), predicate))
            .hasSize(1).extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(tagPersistencyService
            .getTags(tag.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                predicate)).hasSize(1).extracting(Tag::getName).containsOnly(tag.getName());

        predicate = TagPredicate.builder().description(tag.getDescription().toUpperCase(Locale.getDefault())).build();

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(
            tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(tag.getAssetId()), predicate))
            .hasSize(1).extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(tagPersistencyService
            .getTags(tag.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                predicate)).hasSize(1).extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(), predicate)).hasSize(0);
        predicate.setDescription("description-not-found");
        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void getTags_bySourceKey() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);

        TagPredicate predicate = TagPredicate.builder().sourceKey(tag.getSourceKey()).build();

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(
            tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(tag.getAssetId()), predicate))
            .hasSize(1).extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(tagPersistencyService
            .getTags(tag.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                predicate)).hasSize(1).extracting(Tag::getName).containsOnly(tag.getName());

        predicate = TagPredicate.builder().sourceKey(tag.getSourceKey().toUpperCase(Locale.getDefault())).build();

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(
            tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(tag.getAssetId()), predicate))
            .hasSize(1).extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(tagPersistencyService
            .getTags(tag.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                predicate)).hasSize(1).extracting(Tag::getName).containsOnly(tag.getName());
        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(), predicate)).hasSize(0);
        predicate.setDescription("description-not-found");
        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void getTags_byNameSqlInjection() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);

        TagPredicate predicate = TagPredicate.builder().name("junk' or 'x'='x").build();

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void getTags_bySourceKeySqlInjection() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);

        TagPredicate predicate = TagPredicate.builder().sourceKey("junk' or 'x'='x").build();

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void getTags_byDescriptionSqlInjection() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);

        TagPredicate predicate = TagPredicate.builder().description("junk' or 'x'='x").build();

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void getTags_byAlias() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);

        TagPredicate predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.FULL).alias(
            tag.getName() + "_alias2").build();

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Tag::getAliases).containsOnly(tag.getAliases());
        assertThat(
            tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(tag.getAssetId()), predicate))
            .hasSize(1).extracting(Tag::getAliases).containsOnly(tag.getAliases());
        assertThat(tagPersistencyService
            .getTags(tag.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                predicate)).hasSize(1).extracting(Tag::getAliases).containsOnly(tag.getAliases());

        // alias search is case-insensitive
        predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.FULL).alias(
            (tag.getName() + "_alias2").toUpperCase(Locale.getDefault())).build();

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Tag::getAliases).containsOnly(tag.getAliases());
        assertThat(
            tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(tag.getAssetId()), predicate))
            .hasSize(1).extracting(Tag::getAliases).containsOnly(tag.getAliases());
        assertThat(tagPersistencyService
            .getTags(tag.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                predicate)).hasSize(1).extracting(Tag::getAliases).containsOnly(tag.getAliases());

        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(), predicate)).hasSize(0);
        predicate.setParent(ParentPredicate.builder().ids(Sets.newHashSet(tag.getAssetId())).build());
        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(), predicate)).hasSize(0);
        predicate.setAlias("alias-not-found");
        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void getTags_byNameWithWildcards() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");

        int count = 3;
        List<Tag> tags = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String tagName = i + "_WildcardSearchTest_" + i;
            tags.add(TagPredicateUtils.newTag(types.get("MyTagType").getId(), asset2.getId(), tagName));
        }

        assertThat(tagPersistencyService.createTags(TestUtils.TEST_TENANT, TestUtils.getUber(), tags)).isEqualTo(count);

        assertThat(tags.get(0).getLastModifiedDate()).isBeforeOrEqualTo(OffsetDateTime.now());
        assertThat(tags.get(0).getSuperTypesArray()).hasSize(2).containsOnly(types.get("MyTagType").getId(),
            ROOT_TAG_TYPE_ID);

        TagPredicate predicate = null;
        for (String value : Arrays.asList("*SearchTest*", "*Wildcard*Test*")) {
            predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).description(
                value).sourceKey(value).build();
            List<Tag> foundTags = tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate);
            assertThat(foundTags).hasSize(count).extracting(Tag::getDescription).containsOnly(
                tags.get(0).getDescription(), tags.get(1).getDescription(), tags.get(2).getDescription());
            assertThat(foundTags.get(0).getLastModifiedDate()).isBeforeOrEqualTo(OffsetDateTime.now());
            assertThat(foundTags.get(0).getSuperTypesArray()).hasSize(2).containsOnly(types.get("MyTagType").getId(),
                ROOT_TAG_TYPE_ID);

            predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).build();
            assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(
                count).extracting(Tag::getName).containsOnly(tags.get(0).getName(), tags.get(1).getName(),
                tags.get(2).getName());

            predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).description(value)
                .build();
            assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT,
                TestUtils.getUnPrivileged(assets.get("E1"), assets.get("E1_S1_Seg1")), predicate)).hasSize(count)
                .extracting(Tag::getDescription).containsOnly(tags.get(0).getDescription(),
                tags.get(1).getDescription(), tags.get(2).getDescription());

            predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).sourceKey(value).build();
            assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(
                count).extracting(Tag::getSourceKey).containsOnly(tags.get(0).getSourceKey(),
                tags.get(1).getSourceKey(), tags.get(2).getSourceKey());
        }

        for (int i = 0; i < count; i++) {
            String value = "*_" + i;
            predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).description(
                value).sourceKey(value).build();
            assertThat(tagPersistencyService
                .getTags(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(asset2), predicate)).hasSize(1)
                .extracting(Tag::getDescription).containsOnly(tags.get(i).getDescription());

            predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).build();
            assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
                .extracting(Tag::getName).containsOnly(tags.get(i).getName());

            predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).description(value)
                .build();
            assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
                .extracting(Tag::getDescription).containsOnly(tags.get(i).getDescription());

            predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).sourceKey(value).build();
            assertThat(tagPersistencyService
                .getTags(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(asset2), predicate)).hasSize(1)
                .extracting(Tag::getSourceKey).containsOnly(tags.get(i).getSourceKey());

            value = i + "_*";
            predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).description(
                value).sourceKey(value).build();
            assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
                .extracting(Tag::getDescription).containsOnly(tags.get(i).getDescription());

            predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).build();
            assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
                .extracting(Tag::getName).containsOnly(tags.get(i).getName());

            predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).description(value)
                .build();
            assertThat(tagPersistencyService
                .getTags(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(assets.get("E1_S1")), predicate))
                .hasSize(1).extracting(Tag::getDescription).containsOnly(tags.get(i).getDescription());

            predicate = TagPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).sourceKey(value).build();
            assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
                .extracting(Tag::getSourceKey).containsOnly(tags.get(i).getSourceKey());
        }
    }

    @Test
    @Transactional
    public void getTags_byTypeId() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);

        TagPredicate predicate = TagPredicate.builder().type(
            TypePredicate.builder().ids(Collections.singleton(types.get("MyTagType").getId())).build()).build();
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(
            tags.size());
    }

    @Test
    @Transactional
    public void getTags_byRootTypeId() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);

        TagPredicate predicate = TagPredicate.builder().type(
            TypePredicate.builder().ids(Collections.singleton(ROOT_TAG_TYPE_ID)).build()).build();
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(0);
        predicate.getType().setDeepSearch(true);
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(
            tags.size());
    }

    @Test
    @Transactional
    public void getTags_byNameOrSourceKey() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        TagPredicate predicate = TagPredicate.builder().name(tags.get(0).getName() + "*").childOperand(OR)
            .childPredicates(
                Collections.singletonList(TagPredicate.builder().sourceKey("*" + tags.get(2).getSourceKey()).build()))
            .build();
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(2)
            .extracting(Tag::getName).containsOnly("E1_S1_Seg1_Tag0", "E1_S1_Seg1_Asset1_Tag0");
    }

    @Test
    @Transactional
    public void queryTags_byParentId_noDeepSearch() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        createTagData(types, assets);

        Asset asset1 = assets.get("E1_S1_Seg1_Asset1");
        TagPredicate predicate = TagPredicate.builder().parent(
            ParentPredicate.builder().ids(Sets.newHashSet(asset1.getId())).build()).offset(0).pageSize(1000).build();
        List<Collection<String>> listOfAccessibleResources = new ArrayList<>();
        listOfAccessibleResources.add(TestUtils.getUber());
        listOfAccessibleResources.add(Collections.singletonList(assets.get("E1").getId()));
        listOfAccessibleResources.add(Collections.singletonList(asset1.getId()));
        for (Collection<String> accessibleResources : listOfAccessibleResources) {
            assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT,
                accessibleResources.isEmpty() ? TestUtils.getUber() : TestUtils.getUnPrivileged(accessibleResources),
                predicate)).hasSize(2).extracting(Tag::getAssetId).containsOnly(asset1.getId(), asset1.getId());
        }
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void queryTags_byParentId_noDeepSearch_withAssetTypeDeepSeach()
        throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        createTagData(types, assets);

        Asset asset1 = assets.get("E1_S1_Seg1_Asset1");
        TagPredicate predicate = TagPredicate.builder().parent(ParentPredicate.builder().type(
            TypePredicate.builder().ids(Sets.newHashSet(SeedOOTBData.ROOT_ASSET_TYPE_ID)).deepSearch(true).build())
            .ids(Sets.newHashSet(asset1.getId())).build()).offset(0).pageSize(1000).build();
        List<Collection<String>> listOfAccessibleResources = new ArrayList<>();
        listOfAccessibleResources.add(TestUtils.getUber());
        listOfAccessibleResources.add(Collections.singletonList(assets.get("E1").getId()));
        listOfAccessibleResources.add(Collections.singletonList(asset1.getId()));
        for (Collection<String> accessibleResources : listOfAccessibleResources) {
            assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT,
                accessibleResources.isEmpty() ? TestUtils.getUber() : TestUtils.getUnPrivileged(accessibleResources),
                predicate)).hasSize(2)
                .extracting(Tag::getAssetId).containsOnly(asset1.getId(), asset1.getId());
        }
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void queryTags_byParentId_deepSearch() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);

        // without deep search from site
        Asset site = assets.get("E1_S1");
        ParentPredicate parent = ParentPredicate.builder().ids(Sets.newHashSet(site.getId())).build();
        TagPredicate predicate = TagPredicate.builder().parent(parent).build();
        // site has no tag
        assertThat(tagPersistencyService.getTags(site.getTenantId(), TestUtils.getUber(), predicate)).hasSize(0);
        assertThat(tagPersistencyService
            .getTags(site.getTenantId(), TestUtils.getUnPrivileged(site, assets.get("E1")), predicate)).hasSize(0);
        assertThat(tagPersistencyService.getTags(site.getTenantId(), TestUtils.getUnPrivileged(), predicate)).hasSize(
            0);

        // with deep search from site
        parent.setDeepSearch(true);
        assertThat(tagPersistencyService.getTags(site.getTenantId(), TestUtils.getUber(), predicate)).hasSize(
            tags.size()).extracting(Tag::getAssetId).containsOnly(assets.get("E1_S1_Seg1").getId(),
            assets.get("E1_S1_Seg1_Asset1").getId(), assets.get("E1_S1_Seg1_Asset2").getId());
        assertThat(tagPersistencyService
            .getTags(site.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1")), predicate)).hasSize(
            tags.size()).extracting(Tag::getAssetId).containsOnly(assets.get("E1_S1_Seg1").getId(),
            assets.get("E1_S1_Seg1_Asset1").getId(), assets.get("E1_S1_Seg1_Asset2").getId());
        assertThat(tagPersistencyService.getTags(site.getTenantId(), TestUtils.getUnPrivileged(), predicate)).hasSize(
            0);
        // despite the deep search, user has access only to asset-2, which only has one tag
        assertThat(tagPersistencyService
            .getTags(site.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1_S1_Seg1_Asset2")), predicate))
            .hasSize(1).extracting(Tag::getAssetId).containsOnly(assets.get("E1_S1_Seg1_Asset2").getId());

        // search from segment, which has 2 typeInstances
        // without deep search
        Asset segment = assets.get("E1_S1_Seg1");
        parent.setIds(Sets.newHashSet(segment.getId()));
        parent.setDeepSearch(false);
        assertThat(tagPersistencyService.getTags(segment.getTenantId(), TestUtils.getUber(), predicate)).hasSize(2)
            .extracting(Tag::getAssetId).containsOnly(segment.getId());
        assertThat(tagPersistencyService
            .getTags(segment.getTenantId(), TestUtils.getUnPrivileged(segment, assets.get("E1")), predicate))
            .hasSize(2).extracting(Tag::getAssetId).containsOnly(segment.getId());
        assertThat(tagPersistencyService.getTags(segment.getTenantId(),
            TestUtils.getUnPrivileged(assets.get("E1_S1_Seg1_Asset1"), assets.get("E1_S1_Seg1_Asset2")), predicate))
            .hasSize(0);
        assertThat(tagPersistencyService.getTags(segment.getTenantId(), TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);

        // with deep search
        parent.setDeepSearch(true);
        assertThat(tagPersistencyService.getTags(segment.getTenantId(), TestUtils.getUber(), predicate)).hasSize(
            tags.size()).extracting(Tag::getAssetId).containsOnly(segment.getId(),
            assets.get("E1_S1_Seg1_Asset1").getId(), assets.get("E1_S1_Seg1_Asset2").getId());
        assertThat(tagPersistencyService
            .getTags(segment.getTenantId(), TestUtils.getUnPrivileged(segment, assets.get("E1")), predicate))
            .hasSize(tags.size()).extracting(Tag::getAssetId).containsOnly(segment.getId(),
            assets.get("E1_S1_Seg1_Asset1").getId(), assets.get("E1_S1_Seg1_Asset2").getId());
        assertThat(tagPersistencyService.getTags(segment.getTenantId(),
            TestUtils.getUnPrivileged(assets.get("E1_S1_Seg1_Asset1"), assets.get("E1_S1_Seg1_Asset2")), predicate))
            .hasSize(3).extracting(Tag::getAssetId).containsOnly(assets.get("E1_S1_Seg1_Asset1").getId(),
            assets.get("E1_S1_Seg1_Asset2").getId());
        assertThat(tagPersistencyService
            .getTags(segment.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1_S1_Seg1_Asset1")),
                predicate)).hasSize(2).extracting(Tag::getAssetId).containsOnly(
            assets.get("E1_S1_Seg1_Asset1").getId());
        assertThat(tagPersistencyService
            .getTags(segment.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1_S1_Seg1_Asset2")),
                predicate)).hasSize(1).extracting(Tag::getAssetId).containsOnly(
            assets.get("E1_S1_Seg1_Asset2").getId());
        assertThat(tagPersistencyService.getTags(segment.getTenantId(), TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getTags_byParentRootTypeId() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);

        AssetType myTagSubType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            types.get("MyTagType").getId(), "MyTagSubType");
        Tag tag = TagPredicateUtils.newTag(myTagSubType.getId(), assets.get("E1_S1_Seg1").getId(),
            myTagSubType.getName() + "Tag");
        tagPersistencyService.createTag(TestUtils.TEST_TENANT, TestUtils.getUber(), tag);

        TagPredicate predicate = TagPredicate.builder().type(
            TypePredicate.builder().parent(ParentPredicate.builder().ids(Sets.newHashSet(ROOT_TAG_TYPE_ID)).build())
                .build()).build();
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(
            tags.size());
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(assets.get("E1")),
            predicate)).hasSize(tags.size());
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
        predicate.getType().getParent().setDeepSearch(true);
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(
            tags.size() + 1).extracting(Tag::getName).contains(tag.getName());
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(assets.get("E1")),
            predicate)).hasSize(tags.size() + 1).extracting(Tag::getName).contains(tag.getName());
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getTags_byParentAssetSourceKey_deepSearch() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);

        // without deep search from site
        Asset site = assets.get("E1_S1");
        ParentPredicate parent = ParentPredicate.builder().sourceKey(site.getSourceKey()).build();
        TagPredicate predicate = TagPredicate.builder().parent(parent).build();
        // site has no tag
        assertThat(tagPersistencyService.getTags(site.getTenantId(), TestUtils.getUber(), predicate)).hasSize(0);
        assertThat(tagPersistencyService
            .getTags(site.getTenantId(), TestUtils.getUnPrivileged(site, assets.get("E1")), predicate)).hasSize(0);
        assertThat(tagPersistencyService.getTags(site.getTenantId(), TestUtils.getUnPrivileged(), predicate)).hasSize(
            0);

        // with deep search from site
        parent.setDeepSearch(true);
        assertThat(tagPersistencyService.getTags(site.getTenantId(), TestUtils.getUber(), predicate)).hasSize(
            tags.size()).extracting(Tag::getAssetId).containsOnly(assets.get("E1_S1_Seg1").getId(),
            assets.get("E1_S1_Seg1_Asset1").getId(), assets.get("E1_S1_Seg1_Asset2").getId());
        assertThat(tagPersistencyService
            .getTags(site.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1")), predicate)).hasSize(
            tags.size()).extracting(Tag::getAssetId).containsOnly(assets.get("E1_S1_Seg1").getId(),
            assets.get("E1_S1_Seg1_Asset1").getId(), assets.get("E1_S1_Seg1_Asset2").getId());
        assertThat(tagPersistencyService.getTags(site.getTenantId(), TestUtils.getUnPrivileged(), predicate)).hasSize(
            0);
        assertThat(tagPersistencyService
            .getTags(site.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1")), predicate)).hasSize(
            tags.size());
        // despite the deep search, user has access only to asset-2, which only has one tag
        assertThat(tagPersistencyService
            .getTags(site.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1_S1_Seg1_Asset2")), predicate))
            .hasSize(1).extracting(Tag::getAssetId).containsOnly(assets.get("E1_S1_Seg1_Asset2").getId());

        // search from segment, which has 2 typeInstances
        // without deep search
        Asset segment = assets.get("E1_S1_Seg1");
        parent.setSourceKey(segment.getSourceKey());
        parent.setDeepSearch(false);
        assertThat(tagPersistencyService.getTags(segment.getTenantId(), TestUtils.getUber(), predicate)).hasSize(2)
            .extracting(Tag::getAssetId).containsOnly(segment.getId());
        assertThat(tagPersistencyService
            .getTags(segment.getTenantId(), TestUtils.getUnPrivileged(segment, assets.get("E1")), predicate))
            .hasSize(2).extracting(Tag::getAssetId).containsOnly(segment.getId());
        assertThat(tagPersistencyService.getTags(segment.getTenantId(),
            TestUtils.getUnPrivileged(assets.get("E1_S1_Seg1_Asset1"), assets.get("E1_S1_Seg1_Asset2")), predicate))
            .hasSize(0);
        assertThat(tagPersistencyService.getTags(segment.getTenantId(), TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);

        // with deep search
        parent.setDeepSearch(true);
        assertThat(tagPersistencyService.getTags(segment.getTenantId(), TestUtils.getUber(), predicate)).hasSize(
            tags.size()).extracting(Tag::getAssetId).containsOnly(segment.getId(),
            assets.get("E1_S1_Seg1_Asset1").getId(), assets.get("E1_S1_Seg1_Asset2").getId());
        assertThat(tagPersistencyService
            .getTags(segment.getTenantId(), TestUtils.getUnPrivileged(segment, assets.get("E1")), predicate))
            .hasSize(tags.size()).extracting(Tag::getAssetId).containsOnly(segment.getId(),
            assets.get("E1_S1_Seg1_Asset1").getId(), assets.get("E1_S1_Seg1_Asset2").getId());
        assertThat(tagPersistencyService.getTags(segment.getTenantId(),
            TestUtils.getUnPrivileged(assets.get("E1_S1_Seg1_Asset1"), assets.get("E1_S1_Seg1_Asset2")), predicate))
            .hasSize(3).extracting(Tag::getAssetId).containsOnly(assets.get("E1_S1_Seg1_Asset1").getId(),
            assets.get("E1_S1_Seg1_Asset2").getId());
        assertThat(tagPersistencyService
            .getTags(segment.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1_S1_Seg1_Asset1")),
                predicate)).hasSize(2).extracting(Tag::getAssetId).containsOnly(
            assets.get("E1_S1_Seg1_Asset1").getId());
        assertThat(tagPersistencyService
            .getTags(segment.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1_S1_Seg1_Asset2")),
                predicate)).hasSize(1).extracting(Tag::getAssetId).containsOnly(
            assets.get("E1_S1_Seg1_Asset2").getId());
        assertThat(tagPersistencyService.getTags(segment.getTenantId(), TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getTags_byParentTypeId() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);

        // use query predicate
        TagPredicate predicate = TagPredicate.builder().parent(
            ParentPredicate.builder().ids(Sets.newHashSet(tag.getAssetId())).build()).build();
        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUber(), predicate)).hasSize(2)
            .extracting(Tag::getAssetId).containsOnly(tag.getAssetId());
        assertThat(
            tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(tag.getAssetId()), predicate))
            .hasSize(2).extracting(Tag::getAssetId).containsOnly(tag.getAssetId());
        assertThat(tagPersistencyService
            .getTags(tag.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1"), assets.get("E1_S1")),
                predicate)).hasSize(2).extracting(Tag::getAssetId).containsOnly(tag.getAssetId());
        assertThat(tagPersistencyService.getTags(tag.getTenantId(), TestUtils.getUnPrivileged(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void getTags_byTagMonitoredTypeName() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag = tags.get(0);

        // Create parent predicate and type predicate with name field populated
        ParentPredicate parent = ParentPredicate.builder().ids(
            Sets.newHashSet(tag.getAssetId())).build();
        TypePredicate type = TypePredicate.builder().name("foo").build();
        parent.setType(type);

        // Nest parent within tag predicate
        TagPredicate predicate = TagPredicate.builder().build();
        predicate.setParent(parent);

        // Confirm type predicate properly nested
        assertThat(predicate.getParent().getType().getName()).isEqualTo("foo");

        // Confirm that we get back tags
        List tagResults = tagPersistencyService.getTags(
            TestUtils.TEST_TENANT, TestUtils.getUber(), predicate);

        assertThat(tagResults).hasSize(2);
    }

    @Test
    @Transactional
    public void getTags_byTagTypeName() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        TagPredicate predicate = TagPredicate.builder().type(TypePredicate.builder().name("MyTagType").build()).build();
        assertThat(tagPersistencyService.getTags(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(
            tags.size());
    }

    @Test
    @Transactional
    public void getTags_decommissioned() throws IOException, PersistencyServiceException {
        Map<String, AssetType> types = createTypes();
        Map<String, Asset> assets = createAssets(types);
        List<Tag> tags = createTagData(types, assets);
        Tag tag1 = tags.get(2);
        Tag tag2 = tags.get(3);
        Tag tag3 = tags.get(4);
        Asset asset = assets.get("E1_S1_Seg1_Asset1");
        Asset asset2 = assets.get("E1_S1_Seg1_Asset2");
        Asset site = assets.get("E1_S1");
        ((ObjectNode) asset.getAttributes().path("reservedAttributes").path("state")).put("key", "10");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), asset);
        ((ObjectNode) asset2.getAttributes().path("reservedAttributes").path("state")).put("key", "03");
        assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), asset2);

        TestUtils.createAssetUserPolicies(assetPolicyPersistencyService, TestUtils.VIEW_DECOMM_FCODE,
            SeedOOTBData.ROOT_ASSET_TYPE_ID);

        TagPredicate predicate1 = TagPredicate.builder().parent(
            ParentPredicate.builder().ids(Sets.newHashSet(tag1.getAssetId())).build()).build();
        assertThat(tagPersistencyService.getTags(tag1.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1")),
            predicate1)).hasSize(2).extracting(Tag::getAssetId).containsOnly(tag1.getAssetId());

        ParentPredicate parent = ParentPredicate.builder().sourceKey(site.getSourceKey()).build();
        TagPredicate predicate2 = TagPredicate.builder().parent(parent).build();
        parent.setDeepSearch(true);
        assertThat(tagPersistencyService.getTags(site.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1")),
            predicate2)).hasSize(tags.size()).extracting(Tag::getAssetId).containsOnly(assets.get("E1_S1_Seg1").getId(),
            assets.get("E1_S1_Seg1_Asset1").getId(), assets.get("E1_S1_Seg1_Asset2").getId());

        TestUtils.destroyAssetUserPolicies();

        assertThat(tagPersistencyService.getTags(tag1.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1")),
            predicate1)).hasSize(0);
        assertThat(tagPersistencyService.getTags(site.getTenantId(), TestUtils.getUnPrivileged(assets.get("E1")),
            predicate2)).hasSize(3).extracting(Tag::getAssetId).containsOnly(assets.get("E1_S1_Seg1").getId(),
            assets.get("E1_S1_Seg1_Asset2").getId());
    }

    /**
     * ROOT_ENTERPRISE_TYPE <-- MyEnterpriseType ROOT_SITE_TYPE       <-- MySiteType ROOT_SEGMENT_TYPE    <--
     * MySegmentType ROOT_ASSET_TYPE      <-- MyAssetType <-- MyAssetSubType ROOT_TAG_TYPE        <-- MyTagType
     */
    private Map<String, AssetType> createTypes() throws IOException, PersistencyServiceException {
        return TagPredicateUtils.createTypes(assetTypePersistencyService);
    }

    /**
     * E1 <-- E1_S1 <-- E1_S1_Seg1 <-- E1_S1_Seg1 <-- E1_S1_Seg1_Asset1 <-- E1_S1_Seg1_Asset2
     */
    private Map<String, Asset> createAssets(Map<String, AssetType> types)
        throws IOException, PersistencyServiceException {
        return TagPredicateUtils.createAssets(assetPersistencyService, types);
    }

    /**
     * E1_S1_Seg1        <-- E1_S1_Seg1_Tag0, E1_S1_Seg1_Tag1 E1_S1_Seg1_Asset1 <-- E1_S1_Seg1_Asset1_Tag0,
     * E1_S1_Seg1_Asset1_Tag1 E1_S1_Seg1_Asset2 <-- E1_S1_Seg1_Asset2_Tag3
     */
    private List<Tag> createTagData(Map<String, AssetType> types, Map<String, Asset> assets)
        throws IOException, PersistencyServiceException {
        return TagPredicateUtils.createTagDataForDifferentAssets(tagPersistencyService, types.get("MyTagType").getId(),
            assets);
    }
}