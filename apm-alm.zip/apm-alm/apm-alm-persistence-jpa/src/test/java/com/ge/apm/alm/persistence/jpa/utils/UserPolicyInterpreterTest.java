/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.utils;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.persistence.jpa.entity.AssetUserPolicyEntity;
import com.ge.apm.alm.utils.AlmRequestContext;
import com.ge.apm.alm.utils.AlmRequestContext.AlmRequestContextEnum;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

public class UserPolicyInterpreterTest {

    @Before
    public void initializeContext() {
        AlmRequestContext.put(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_ENABLED, true);
    }

    @Test
    public void constructFilterPredicateTest_SingleSuperType() throws Exception {
        String filterCriteria = "reservedAttributes.state.key=\"10\"";
        String filterSQL = UserPolicyInterpreter.constructFilterPredicate(filterCriteria,
            Arrays.asList(SeedOOTBData.ROOT_ASSET_TYPE_ID));
        assertEquals(" NOT (attributes @> '{\"reservedAttributes\": {\"state\": {\"key\": \"10\"}}}' AND  "
            + "super_types_array && array['" + SeedOOTBData.ROOT_ASSET_TYPE_ID + "'] ) ", filterSQL);
    }

    @Test
    public void constructFilterPredicateTest_MultipleSuperTypes() throws Exception {
        String filterCriteria = "reservedAttributes.who.ha=\"07\"";
        String filterSQL = UserPolicyInterpreter.constructFilterPredicate(filterCriteria,
            Arrays.asList(SeedOOTBData.ROOT_ASSET_TYPE_ID, SeedOOTBData.ROOT_SEGMENT_TYPE_ID));
        assertEquals(
            " NOT (attributes @> '{\"reservedAttributes\": {\"who\": {\"ha\": \"07\"}}}' AND  super_types_array && "
                + "array['" + SeedOOTBData.ROOT_ASSET_TYPE_ID + "', '" + SeedOOTBData.ROOT_SEGMENT_TYPE_ID + "'] ) ",
            filterSQL);
    }

    @Test
    public void filterPoliciesTest() throws Exception {
        String filterCriteria = "reservedAttributes.state.key=\"04\"";
        AssetUserPolicyEntity p1 = new AssetUserPolicyEntity();
        p1.setSuperType(SeedOOTBData.ROOT_SEGMENT_TYPE_ID);
        p1.setFilterCriteria(filterCriteria);
        AssetUserPolicyEntity p2 = new AssetUserPolicyEntity();
        p2.setSuperType(SeedOOTBData.ROOT_SITE_TYPE_ID);
        p2.setFilterCriteria(filterCriteria);

        AlmRequestContext.put(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_AS_LIST, Arrays.asList(p1, p2));
        List<String> policySql = UserPolicyInterpreter.filterPolicies(
            Arrays.asList(SeedOOTBData.ROOT_ASSET_TYPE_ID, SeedOOTBData.ROOT_SEGMENT_TYPE_ID));
        assertEquals(2, policySql.size());
        assertEquals(
            " NOT (attributes @> '{\"reservedAttributes\": {\"state\": {\"key\": \"10\"}}}' AND  super_types_array &&"
                + " array['" + SeedOOTBData.ROOT_ASSET_TYPE_ID + "'] ) ", policySql.get(0));
        assertEquals(
            " NOT (attributes @> '{\"reservedAttributes\": {\"state\": {\"key\": \"04\"}}}' AND  super_types_array &&"
                + " array['" + SeedOOTBData.ROOT_SEGMENT_TYPE_ID + "'] ) ", policySql.get(1));
    }

    @Test
    public void filterPoliciesTest_ViewDecommission() {
        AlmRequestContext.remove(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_AS_LIST);
        List<String> policySql = UserPolicyInterpreter.filterPolicies(
            Arrays.asList(SeedOOTBData.ROOT_ASSET_TYPE_ID, SeedOOTBData.ROOT_SEGMENT_TYPE_ID));
        assertEquals(1, policySql.size());
        assertEquals(
            " NOT (attributes @> '{\"reservedAttributes\": {\"state\": {\"key\": \"10\"}}}' AND  super_types_array && "
                + "array['" + SeedOOTBData.ROOT_ASSET_TYPE_ID + "'] ) ", policySql.get(0));

        AssetUserPolicyEntity p1 = new AssetUserPolicyEntity();
        p1.setSuperType(SeedOOTBData.ROOT_ASSET_TYPE_ID);
        p1.setFeatureCode("VIEW_DECOMMISSIONED_ASSETS");
        AlmRequestContext.put(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_AS_LIST, Arrays.asList(p1));
        policySql = UserPolicyInterpreter.filterPolicies(
            Arrays.asList(SeedOOTBData.ROOT_ASSET_TYPE_ID, SeedOOTBData.ROOT_SEGMENT_TYPE_ID));
        assertEquals(0, policySql.size());

        String filterCriteria = "reservedAttributes.state.key=\"04\"";
        AssetUserPolicyEntity p2 = new AssetUserPolicyEntity();
        p2.setSuperType(SeedOOTBData.ROOT_SEGMENT_TYPE_ID);
        p2.setFilterCriteria(filterCriteria);
        AlmRequestContext.put(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_AS_LIST, Arrays.asList(p1, p2));
        policySql = UserPolicyInterpreter.filterPolicies(
            Arrays.asList(SeedOOTBData.ROOT_ASSET_TYPE_ID, SeedOOTBData.ROOT_SEGMENT_TYPE_ID));
        assertEquals(1, policySql.size());
        assertEquals(
            " NOT (attributes @> '{\"reservedAttributes\": {\"state\": {\"key\": \"04\"}}}' AND  super_types_array &&"
                + " array['"
                + SeedOOTBData.ROOT_SEGMENT_TYPE_ID + "'] ) ", policySql.get(0));
    }

    @Test
    public void testGetSubjectIds() {
        AlmRequestContext.destroy();
        assertThat(UserPolicyInterpreter.getSubjectIds()).hasSize(0);

        AlmRequestContext.put(AlmRequestContextEnum.SUBJECT_UUID, TestUtils.TEST_USER_ID);
        assertThat(UserPolicyInterpreter.getSubjectIds()).hasSize(1).containsOnly(TestUtils.TEST_USER_ID);

        AlmRequestContext.put(AlmRequestContextEnum.SUBJECT_ASSOCIATED_GROUP_UUID_AS_LIST,
            Arrays.asList(SeedOOTBData.ROOT_SEGMENT_TYPE_ID, SeedOOTBData.ROOT_SITE_TYPE_ID));
        assertThat(UserPolicyInterpreter.getSubjectIds()).hasSize(3).containsOnly(TestUtils.TEST_USER_ID,
            SeedOOTBData.ROOT_SEGMENT_TYPE_ID, SeedOOTBData.ROOT_SITE_TYPE_ID);
    }
}