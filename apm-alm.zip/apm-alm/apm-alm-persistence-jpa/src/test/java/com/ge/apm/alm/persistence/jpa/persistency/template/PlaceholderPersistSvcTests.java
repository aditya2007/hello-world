/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.template;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.PlaceholderGroupTagType;
import com.ge.apm.alm.model.PlaceholderTagType;
import com.ge.apm.alm.model.PlaceholderType;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.PlaceholderPredicate;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholder;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderGroupTagType;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderTagType;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderTemplate;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholderType;
import com.ge.apm.alm.persistence.jpa.model.TestTemplate;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestTemplateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

/**
 * Tests the JPA Persistency Layer
 */
@Slf4j
public class PlaceholderPersistSvcTests extends TemplatePersistSvcBaseTests {

    private static final String ASSET_TYPE_NAME = "GE91";
    private static final String TAG_TYPE_NAME = "GE91";


    @Test
    @Transactional
    public void testCreatePlaceholder() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN01", null);

        Placeholder savedPlaceholder = placeholderPersistencyService.createPlaceholder(TestUtils.TEST_TENANT,
            testTemplate.getId(), testPlaceholder);
        Placeholder dbPlaceholder = placeholderPersistencyService.getPlaceholderById(TestUtils.TEST_TENANT,
            testPlaceholder.getId());
        assertThat(dbPlaceholder).isNotNull();
        assertThat(savedPlaceholder.getId()).isEqualTo(testPlaceholder.getId());
        assertThat(dbPlaceholder.getId()).isEqualTo(testPlaceholder.getId());

        deleteTestTemplateCascade(testTemplate.getId(), testPlaceholder);
    }

    @Test
    @Transactional
    public void testCreatePlaceholderForEvents() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN01", null);

        Placeholder savedPlaceholder = placeholderPersistencyService.createPlaceholder(TestUtils.TEST_TENANT,
                testTemplate.getId(), testPlaceholder);
        Placeholder dbPlaceholder = placeholderPersistencyService.getPlaceholderForEventsById(TestUtils.TEST_TENANT,
                testPlaceholder.getId());
        assertThat(dbPlaceholder).isNotNull();
        assertThat(savedPlaceholder.getId()).isEqualTo(testPlaceholder.getId());
        assertThat(dbPlaceholder.getId()).isEqualTo(testPlaceholder.getId());

        deleteTestTemplateCascade(testTemplate.getId(), testPlaceholder);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholder_missingMatchTenantId() throws IOException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);
        TestPlaceholder testPlaceholder = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN01", null);

        placeholderPersistencyService.createPlaceholder(TestUtils.TEST_TENANT, "UNKNOWN_TEMPLATE_ID", testPlaceholder);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholder_missingId() throws IOException {
        String templateId = TestTemplateUtils.getNewUuid();
        TestPlaceholder testPlaceholder = TestTemplateUtils.buildPlaceholder(templateId, "PPN01", null);
        testPlaceholder.setId(null);
        placeholderPersistencyService.createPlaceholder(TestUtils.TEST_TENANT, templateId, testPlaceholder);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholder_missingSourceKey() throws IOException {
        String templateId = TestTemplateUtils.getNewUuid();
        TestPlaceholder testPlaceholder = TestTemplateUtils.buildPlaceholder(templateId, "PPN01", null);
        testPlaceholder.setSourceKey(null);
        placeholderPersistencyService.createPlaceholder(TestUtils.TEST_TENANT, templateId, testPlaceholder);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholder_missingTemplateId() throws IOException {
        String templateId = TestTemplateUtils.getNewUuid();
        TestPlaceholder testPlaceholder = TestTemplateUtils.buildPlaceholder(templateId, "PPN01", null);
        testPlaceholder.setTemplateId(null);
        placeholderPersistencyService.createPlaceholder(TestUtils.TEST_TENANT, templateId, testPlaceholder);
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreatePlaceholder_missingPartPositionNumber() throws IOException {
        String templateId = TestTemplateUtils.getNewUuid();
        TestPlaceholder testPlaceholder = TestTemplateUtils.buildPlaceholder(templateId, "PPN01", null);
        testPlaceholder.setPartPositionNumber(null);
        placeholderPersistencyService.createPlaceholder(TestUtils.TEST_TENANT, templateId, testPlaceholder);
    }

    @Test
    @Transactional
    public void createPlaceholders() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);

        List<Placeholder> testPlaceholders = new ArrayList<>();
        assertThat(placeholderPersistencyService.createPlaceholders(TestUtils.TEST_TENANT, testTemplate.getId(),
            testPlaceholders)).isEqualTo(0);

        TestPlaceholder testPlaceholder1 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN10", null);
        TestPlaceholder testPlaceholder2 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN11",
            testPlaceholder1.getParentId());
        TestPlaceholder testPlaceholder3 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN12",
            testPlaceholder2.getParentId());
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);
        testPlaceholders.add(testPlaceholder3);

        int counter = placeholderPersistencyService.createPlaceholders(TestUtils.TEST_TENANT, testTemplate.getId(),
            testPlaceholders);
        assertThat(counter).isEqualTo(testPlaceholders.size());

        deleteTestTemplateCascade(testTemplate.getId(), testPlaceholders);
    }

    @Test
    @Transactional
    public void testUpdatePlaceholder() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);

        TestPlaceholder testPlaceholder = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN01", null);
        Placeholder savedPlaceholder = placeholderPersistencyService.createPlaceholder(TestUtils.TEST_TENANT,
            testTemplate.getId(), testPlaceholder);
        assertThat(savedPlaceholder).isNotNull();
        assertThat(savedPlaceholder.getId()).isEqualTo(testPlaceholder.getId());

        JsonNode newAttribute = TestTemplateUtils.buildPlaceholderAttributes("03/20/2017 10:30:00");
        testPlaceholder.setAttributes(newAttribute);

        AssetType assetType = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, ASSET_TYPE_NAME);
        TestPlaceholderType testPlaceholderType = createTestPlaceholderType(testPlaceholder, assetType);
        List<PlaceholderType> assetTypes = new ArrayList<>();
        assetTypes.add(testPlaceholderType);
        testPlaceholder.setPlaceholderTypes(assetTypes);

        AssetType tagType = createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, TAG_TYPE_NAME);
        TestPlaceholderTagType testPlaceholderTagType = createTestPlaceholderTagType(testPlaceholder, tagType);
        List<PlaceholderTagType> tagTypesTypes = new ArrayList<>();
        tagTypesTypes.add(testPlaceholderTagType);
        testPlaceholder.setPlaceholderTagTypes(tagTypesTypes);

        TestAssetGroup testAssetGroup = createAssetGroup("GE91_tagType_group");
        TestPlaceholderGroupTagType testPlaceholderGroupTagType = createTestPlaceholderGroupTagType(testPlaceholder,
            testAssetGroup);
        List<PlaceholderGroupTagType> groupTagTypes = new ArrayList<>();
        groupTagTypes.add(testPlaceholderGroupTagType);
        testPlaceholder.setPlaceholderGroupTagTypes(groupTagTypes);

        TestTemplate subTemplate = createTestTemplate("GE90_Fan_template", null, null);
        TestPlaceholderTemplate testPlaceholderTemplate = createTestPlaceholderTemplate(testPlaceholder, subTemplate);
        testPlaceholder.setPlaceholderTemplate(testPlaceholderTemplate);

        placeholderPersistencyService.updatePlaceholder(TestUtils.TEST_TENANT, testTemplate.getId(), testPlaceholder);

        deleteTestTemplateCascade(testTemplate.getId(), testPlaceholder);
    }

    @Test
    @Transactional
    public void testUpdatePlaceholders() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);

        List<Placeholder> testPlaceholders = new ArrayList<>();
        assertThat(placeholderPersistencyService.createPlaceholders(TestUtils.TEST_TENANT, testTemplate.getId(),
            testPlaceholders)).isEqualTo(0);

        TestPlaceholder testPlaceholder1 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN100", null);
        TestPlaceholder testPlaceholder2 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN101",
            testPlaceholder1.getParentId());
        TestPlaceholder testPlaceholder3 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN102",
            testPlaceholder2.getParentId());
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);
        testPlaceholders.add(testPlaceholder3);

        int counter = placeholderPersistencyService.createPlaceholders(TestUtils.TEST_TENANT, testTemplate.getId(),
            testPlaceholders);
        assertThat(counter).isEqualTo(testPlaceholders.size());

        for (int i = 0; i < testPlaceholders.size(); i++) {
            JsonNode newAttribute = TestTemplateUtils.buildPlaceholderAttributes("10/25/2016 10:30:00");
            ((TestPlaceholder) testPlaceholders.get(i)).setAttributes(newAttribute);
        }
        counter = placeholderPersistencyService.updatePlaceholders(TestUtils.TEST_TENANT, testTemplate.getId(),
            testPlaceholders);
        assertThat(counter).isEqualTo(testPlaceholders.size());

        deleteTestTemplateCascade(testTemplate.getId(), testPlaceholders);
    }

    @Test
    @Transactional
    public void testDeletePlaceholderById() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);

        TestPlaceholder testPlaceholder = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN01", null);
        Placeholder savedPlaceholder = placeholderPersistencyService.createPlaceholder(TestUtils.TEST_TENANT,
            testTemplate.getId(), testPlaceholder);
        assertThat(savedPlaceholder).isNotNull();
        assertThat(savedPlaceholder.getId()).isEqualTo(testPlaceholder.getId());

        placeholderPersistencyService.deletePlaceholderById(TestUtils.TEST_TENANT, testPlaceholder.getId());

        deleteTestTemplateCascade(testTemplate.getId(), testPlaceholder);
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeletePlaceholderById_NotFoundException() throws PersistencyServiceException {
        String uuid = TestTemplateUtils.getNewUuid();
        assertThat(placeholderPersistencyService.deletePlaceholderById(TestUtils.TEST_TENANT, uuid)).isEqualTo(0);
    }

    @Test
    @Transactional
    public void testGetPlaceholderById() throws IOException, PersistencyServiceException {
        testCreatePlaceholder();
    }

    @Test
    @Transactional
    public void testGetPlaceholderForEventsById() throws IOException, PersistencyServiceException {
        testCreatePlaceholderForEvents();
    }

    @Test
    @Transactional
    public void testGetPlaceholderById_NotFoundException() {
        final String id = TestTemplateUtils.getNewUuid();
        assertThat(placeholderPersistencyService.getPlaceholderById(TestUtils.TEST_TENANT, id)).isNull();
    }

    @Test
    @Transactional
    public void testGetPlaceholderByTemplateIdAndPartPositionNumber() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);

        TestPlaceholder testPlaceholder = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN01", null);
        Placeholder savedPlaceholder = placeholderPersistencyService.createPlaceholder(TestUtils.TEST_TENANT,
            testTemplate.getId(), testPlaceholder);
        assertThat(savedPlaceholder).isNotNull();
        assertThat(savedPlaceholder.getId()).isEqualTo(testPlaceholder.getId());

        Placeholder dbPlaceholder = placeholderPersistencyService.getPlaceholderByTemplateIdAndPartPositionNumber(
            TestUtils.TEST_TENANT, testTemplate.getId(), testPlaceholder.getPartPositionNumber());
        assertThat(dbPlaceholder).isNotNull();
        assertThat(dbPlaceholder.getId()).isEqualTo(testPlaceholder.getId());

        deleteTestTemplateCascade(testTemplate.getId(), testPlaceholder);
    }

    @Test
    @Transactional
    public void testGetPlaceholderByTemplateIdAndPartPositionNumber_NotFoundException() {
        String uuid = TestTemplateUtils.getNewUuid();
        assertThat(placeholderPersistencyService.getPlaceholderByTemplateIdAndPartPositionNumber(TestUtils.TEST_TENANT,
            uuid, uuid)).isNull();
    }

    @Test
    @Transactional
    public void testGetPlaceholdersByTemplateId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);

        List<Placeholder> testPlaceholders = new ArrayList<>();
        assertThat(placeholderPersistencyService.createPlaceholders(TestUtils.TEST_TENANT, testTemplate.getId(),
            testPlaceholders)).isEqualTo(0);

        TestPlaceholder testPlaceholder1 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN10", null);
        TestPlaceholder testPlaceholder2 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN11",
            testPlaceholder1.getParentId());
        TestPlaceholder testPlaceholder3 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN12",
            testPlaceholder2.getParentId());
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);
        testPlaceholders.add(testPlaceholder3);

        int counter = placeholderPersistencyService.createPlaceholders(TestUtils.TEST_TENANT, testTemplate.getId(),
            testPlaceholders);
        assertThat(counter).isEqualTo(testPlaceholders.size());

        List<Placeholder> foundPlaceholders = placeholderPersistencyService
            .getPlaceholdersByTemplateId(TestUtils.TEST_TENANT, testTemplate.getId());
        assertThat(foundPlaceholders.size()).isEqualTo(testPlaceholders.size());

        deleteTestTemplateCascade(testTemplate.getId(), testPlaceholders);
    }

    @Test
    @Transactional
    public void testGetPlaceholders() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);

        List<Placeholder> testPlaceholders = new ArrayList<>();
        TestPlaceholder testPlaceholder1 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN101", null);
        TestPlaceholder testPlaceholder2 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN102",
            testPlaceholder1.getId());
        TestPlaceholder testPlaceholder3 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN103",
            testPlaceholder2.getId());
        TestPlaceholder testPlaceholder4 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN104",
            testPlaceholder2.getId());

        testPlaceholder2.setAttributes(TestTemplateUtils.buildPlaceholderAttributes("03/25/2017 10:30:00"));
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);
        testPlaceholders.add(testPlaceholder3);
        testPlaceholders.add(testPlaceholder4);
        int counter = placeholderPersistencyService.createPlaceholders(TestUtils.TEST_TENANT, testTemplate.getId(),
            testPlaceholders);
        assertThat(counter).isEqualTo(testPlaceholders.size());

        log.info("==== test case NO wildcard at partPositionNumber");
        List<Placeholder> placeholders = null;

        log.info("test get placeholders by templateId ....");
        PlaceholderPredicate placeholderPredicate = new PlaceholderPredicate();
        placeholderPredicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        placeholderPredicate.setTemplateId(testTemplate.getId());
        placeholderPredicate.setPartPositionNumber(null);
        placeholderPredicate.setParentId(null);
        placeholders = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, placeholderPredicate);
        assertThat(placeholders.size()).isEqualTo(testPlaceholders.size());

        log.info("test get placeholders by templateId, placeholderId....");
        placeholderPredicate = new PlaceholderPredicate();
        placeholderPredicate.setTemplateId(testTemplate.getId());
        placeholderPredicate.setPartPositionNumber(testPlaceholder2.getPartPositionNumber());
        placeholders = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT,
            placeholderPredicate);
        assertThat(placeholders.size()).isEqualTo(1);
        assertThat(placeholders.get(0).getId()).isEqualTo(testPlaceholder2.getId());
        assertThat(placeholders.get(0).getTemplateId()).isEqualTo(testPlaceholder2.getTemplateId());
        assertThat(placeholders.get(0).getPartPositionNumber()).isEqualTo(testPlaceholder2.getPartPositionNumber());

        log.info("test get placeholders by templateId, parentId ....");
        placeholderPredicate = new PlaceholderPredicate();
        placeholderPredicate.setTemplateId(testTemplate.getId());
        placeholderPredicate.setParentId(testPlaceholder2.getId());
        placeholderPredicate.setPartPositionNumber(null);
        placeholderPredicate.setAttributes(null);
        placeholders = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, placeholderPredicate);
        assertThat(placeholders.size()).isEqualTo(2);

        log.info("test get placeholders by templateId, partPositionNumber, parentId ....");
        placeholderPredicate = new PlaceholderPredicate();
        placeholderPredicate.setTemplateId(testTemplate.getId());
        placeholderPredicate.setParentId(testPlaceholder2.getParentId());
        placeholderPredicate.setPartPositionNumber(testPlaceholder2.getPartPositionNumber());
        placeholderPredicate.setAttributes(null);
        placeholders = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, placeholderPredicate);
        assertThat(placeholders.size()).isEqualTo(1);

        log.info("test get placeholders by partPositionNumber, parentId ....");
        placeholderPredicate = new PlaceholderPredicate();
        placeholderPredicate.setTemplateId(null);
        placeholderPredicate.setParentId(testPlaceholder2.getParentId());
        placeholderPredicate.setPartPositionNumber(testPlaceholder2.getPartPositionNumber());
        placeholderPredicate.setAttributes(null);
        placeholders = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, placeholderPredicate);
        assertThat(placeholders.size()).isEqualTo(1);

        log.info("test get placeholders by parentId ....");
        placeholderPredicate = new PlaceholderPredicate();
        placeholderPredicate.setTemplateId(null);
        placeholderPredicate.setParentId(testPlaceholder2.getParentId());
        placeholderPredicate.setPartPositionNumber(null);
        placeholderPredicate.setAttributes(null);
        placeholders = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, placeholderPredicate);
        assertThat(placeholders.size()).isEqualTo(1);

        //TODO: query attribute based on date range is not working for now, will look into it later
        log.info("test get placeholders by templateId, partPositionNumber, parentId, attribute ....");
        placeholderPredicate = new PlaceholderPredicate();
        placeholderPredicate.setTemplateId(testTemplate.getId());
        placeholderPredicate.setParentId(testPlaceholder2.getParentId());
        placeholderPredicate.setPartPositionNumber(testPlaceholder2.getPartPositionNumber());
        Map<String, String> attributeMap = new HashMap<>();
        attributeMap.put("effectivityDate", "03/25/2017 10:30:00");
        placeholders = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, placeholderPredicate);
        assertThat(placeholders.size()).isEqualTo(1);

        log.info("==== test case with wildcard: templateId, partPositionNumber(wildcard) ....");
        new PlaceholderPredicate();
        placeholderPredicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        placeholderPredicate.setTemplateId(testTemplate.getId());
        placeholderPredicate.setPartPositionNumber("PPN1*");
        placeholderPredicate.setParentId(null);
        placeholderPredicate.setAttributes(null);
        placeholders = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, placeholderPredicate);
        assertThat(placeholders.size()).isEqualTo(4);

        log.info("==== test case with wildcard: templateId, partPositionNumber(wildcard), parentId ....");
        new PlaceholderPredicate();
        placeholderPredicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        placeholderPredicate.setTemplateId(testTemplate.getId());
        placeholderPredicate.setPartPositionNumber("PPN1*");
        placeholderPredicate.setParentId(testPlaceholder2.getParentId());
        placeholderPredicate.setAttributes(null);
        placeholders = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, placeholderPredicate);
        assertThat(placeholders.size()).isEqualTo(1);

        log.info("==== test case with wildcard: templateId, partPositionNumber(wildcard), parentId, attribute ....");
        new PlaceholderPredicate();
        placeholderPredicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        placeholderPredicate.setTemplateId(testTemplate.getId());
        placeholderPredicate.setPartPositionNumber("PPN1*");
        Map<String, String> attributeMap2 = new HashMap<>();
        attributeMap2.put("effectivityDate", "03/25/2017 10:30:00");
        placeholderPredicate.setAttributes(attributeMap2);
        placeholders = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, placeholderPredicate);
        assertThat(placeholders.size()).isEqualTo(1);

        log.info("==== test case with wildcard: partPositionNumber(wildcard), parentId ....");
        new PlaceholderPredicate();
        placeholderPredicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        placeholderPredicate.setTemplateId(null);
        placeholderPredicate.setPartPositionNumber("PPN1*");
        placeholderPredicate.setParentId(testPlaceholder2.getParentId());
        placeholderPredicate.setAttributes(null);
        placeholders = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, placeholderPredicate);
        assertThat(placeholders.size()).isEqualTo(1);

        log.info("==== test case with wildcard: partPositionNumber(wildcard), parentId ....");
        new PlaceholderPredicate();
        placeholderPredicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        placeholderPredicate.setTemplateId(testTemplate.getId());
        placeholderPredicate.setPartPositionNumber("PPN1*");
        placeholderPredicate.setParentId(null);
        placeholderPredicate.setAttributes(null);
        placeholders = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, placeholderPredicate);
        assertThat(placeholders.size()).isEqualTo(4);

        deleteTestTemplateCascade(testTemplate.getId(), testPlaceholders);
    }

    @Test
    @Transactional
    public void testGetPlaceholders_PagingWithSortKey() throws IOException {
        int pageSize = 2;
        int numPages = 5;
        TestTemplate testTemplate = createTestTemplate("X Template", null, null);
        for (int i = 0; i < pageSize * numPages; i++) {
            placeholderPersistencyService.createPlaceholders(TestUtils.TEST_TENANT, testTemplate.getId(),
                Collections.singletonList(TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN-" + i,
                    null)));
        }

        PlaceholderPredicate predicate = new PlaceholderPredicate();
        predicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        predicate.setTemplateId(testTemplate.getId());
        predicate.setPageSize(120);
        List<Placeholder> all = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, predicate);
        assertThat(all).hasSize(pageSize * numPages);

        predicate.setPagingInfo(0, pageSize, null, true);
        List<Placeholder> found = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, predicate);
        assertThat(found).hasSize(pageSize);
        assertThat(found.stream().map(Placeholder::getId).collect(Collectors.toList()))
            .containsExactlyElementsOf(all.subList(0, pageSize).stream()
                .map(Placeholder::getId).collect(Collectors.toList()));

        String sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        assertThat(sortKey).isNotEmpty();

        predicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        int offset = pageSize;
        while (offset < pageSize * numPages) {
            predicate.setPagingInfo(1, pageSize, sortKey, true);
            found = placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, predicate);
            assertThat(found).hasSize(pageSize);
            assertThat(found.stream().map(Placeholder::getId).collect(Collectors.toList()))
                .containsExactlyElementsOf(all.subList(offset, offset + pageSize).stream()
                    .map(Placeholder::getId).collect(Collectors.toList()));
            offset += pageSize;
            sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        }

        predicate.setPagingInfo(1, pageSize, sortKey, true);
        assertThat(placeholderPersistencyService.getPlaceholders(TestUtils.TEST_TENANT, predicate)).isEmpty();
    }

    private void deleteTestTemplateCascade(String templateId, Placeholder placeholder)
        throws PersistencyServiceException {
        templatePersistencyService.deleteTemplateById(TestUtils.TEST_TENANT, templateId);

        String partPositionNumber = placeholder.getPartPositionNumber();
        assertThat(templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, templateId)).isNull();
        assertThat(placeholderPersistencyService.getPlaceholderByTemplateIdAndPartPositionNumber(TestUtils.TEST_TENANT,
            templateId, partPositionNumber)).isNull();
    }

    private void deleteTestTemplateCascade(String templateId, List<Placeholder> placeholders)
        throws PersistencyServiceException {
        templatePersistencyService.deleteTemplateById(TestUtils.TEST_TENANT, templateId);

        for (Placeholder placeholder : placeholders) {
            String partPositionNumber = placeholder.getPartPositionNumber();
            assertThat(templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, templateId)).isNull();
            assertThat(
                placeholderPersistencyService.getPlaceholderByTemplateIdAndPartPositionNumber(TestUtils.TEST_TENANT,
                    templateId, partPositionNumber)).isNull();
        }
    }
}
