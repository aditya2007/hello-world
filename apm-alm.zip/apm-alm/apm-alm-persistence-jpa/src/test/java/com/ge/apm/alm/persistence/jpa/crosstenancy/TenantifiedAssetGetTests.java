/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.crosstenancy;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.assertj.core.util.Maps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TenantTestUtils;
import com.ge.apm.alm.persistence.mirror.MirrorTestUtils;
import com.ge.apm.common.support.RequestContext;

/**
 *
 * @author Shu W. Yu 212614203
 * @version 1.0 Apr 30, 2018
 * @since 1.0
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TenantifiedAssetGetTests {

    private final String[] tenantIds = new String[]{
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
    };

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;
    @Autowired
    private AssetPersistencyService assetPersistencyService;
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Test
    public void testNonContextTenantReader() throws IOException, ObjectNotFoundException {
        try {
            MirrorTestUtils.setEventCreationEnabled(false);
            Map<String, BaseDataModel> data = createData();
            setupCrossTenants();

            doTests(data);

        } finally {
            clearCrossTenants();
            clearData();
            MirrorTestUtils.setEventCreationEnabled(true);
        }
    }

    private void doTests(Map<String, BaseDataModel> data) throws ObjectNotFoundException {
        getAssetByIdTest(data);
        getAssetByIdWithComponentTest(data);
        getAssetBySourceKeyTest(data);
        getAssetBySourceKeysTest(data);
        getChildAssetsTest(data);
        getChildAssetsTest(data);
        getAssetsByIdsTest(data);
    }

    private void getAssetByIdTest(Map<String, BaseDataModel> data) {
        Asset created = (Asset) data.get("E1_S1_Seg3_A3");
        Asset found = assetPersistencyService.getAssetById(tenantIds[0], null, created.getId());
        assertThat(found.getId()).isEqualTo(created.getId());
        assertThat(found.getTenantId()).isEqualTo(tenantIds[1]);

        found = assetPersistencyService.getAssetById(tenantIds[0], Collections.singleton(UUID.randomUUID().toString()),
            created.getId());
        assertThat(found.getId()).isEqualTo(created.getId());
        assertThat(found.getTenantId()).isEqualTo(tenantIds[1]);

        RequestContext.put(CrossTenancyCall.ALL_ACCESSIBLE_RESOURCES, Maps.newHashMap(
            tenantIds[1], new String[] {"/prefix/"+ UUID.randomUUID().toString()}));
        found = assetPersistencyService.getAssetById(tenantIds[0], null, created.getId());
        assertThat(found).isNull();
        setupCrossTenants();
    }

    private void getAssetByIdWithComponentTest(Map<String, BaseDataModel> data) {
        Asset created = (Asset) data.get("E1_S1_Seg3_A3");
        Asset found = assetPersistencyService.getAssetById(tenantIds[0], Collections.singleton(UUID.randomUUID()
                .toString()), created.getId(), EnumSet.of(AssetComponent.PARENT), true);
        assertThat(found.getId()).isEqualTo(created.getId());
        assertThat(found.getTenantId()).isEqualTo(tenantIds[1]);
        assertThat(found.getParent().getId()).isEqualTo(created.getParentId());

        RequestContext.put(CrossTenancyCall.ALL_ACCESSIBLE_RESOURCES, Maps.newHashMap(
            tenantIds[1], new String[] {"/assets/"+ created.getId()}));
        found = assetPersistencyService.getAssetById(tenantIds[0], null, created.getId(), EnumSet.of(
            AssetComponent.PARENT), false);
        assertThat(found.getId()).isEqualTo(created.getId());
        assertThat(found.getTenantId()).isEqualTo(tenantIds[1]);
        assertThat(found.getParent()).isNull();
        setupCrossTenants();
    }

    private void getAssetBySourceKeyTest(Map<String, BaseDataModel> data) {
        Asset created = (Asset) data.get("E1_S1_Seg3_A3");
        Asset found = assetPersistencyService.getAssetBySourceKey(tenantIds[0], null,
            OOTBCoreTypesIdLookup.AssetType.name(), created.getSourceKey());
        assertThat(found.getId()).isEqualTo(created.getId());
        assertThat(found.getTenantId()).isEqualTo(tenantIds[1]);
        assertThat(found.getSourceKey()).isEqualTo(created.getSourceKey());

        RequestContext.put(CrossTenancyCall.ALL_ACCESSIBLE_RESOURCES, Maps.newHashMap(
            tenantIds[1], new String[] {"/anyprefix/"+ UUID.randomUUID().toString()}));
        found = assetPersistencyService.getAssetById(tenantIds[0], null, created.getId());
        assertThat(found).isNull();
        setupCrossTenants();
    }

    private void getAssetBySourceKeysTest(Map<String, BaseDataModel> data) {
        Asset created = (Asset) data.get("E1_S1_Seg3_A3");
        List<Asset> assets = assetPersistencyService.getAssetsBySourceKeys(tenantIds[0], null,
            OOTBCoreTypesIdLookup.AssetType.name(), Collections.singletonList(created.getSourceKey()));
        assertThat(assets).hasSize(1);
        Asset found = assets.get(0);
        assertThat(found.getId()).isEqualTo(created.getId());
        assertThat(found.getTenantId()).isEqualTo(tenantIds[1]);
        assertThat(found.getSourceKey()).isEqualTo(created.getSourceKey());
    }

    private void getChildAssetsTest(Map<String, BaseDataModel> data) {
        Asset parent = (Asset) data.get("E1_S1_Seg3");
        List<Asset> assets = assetPersistencyService.getChildAssets(tenantIds[0], null,
            parent.getId(), AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.FULL).build());
        assertThat(assets).hasSize(3);
        assets.forEach(found -> {
            assertThat(found.getParentId()).isEqualTo(parent.getId());
            assertThat(found.getTenantId()).isEqualTo(tenantIds[1]);
        });
    }

    private void getAssetsByIdsTest(Map<String, BaseDataModel> data) throws ObjectNotFoundException {
        Asset created = (Asset) data.get("E1_S2");
        List<Asset> assets = assetPersistencyService.getAssetsByIds(tenantIds[0], null,
            Collections.singleton(created.getId()));
        assertThat(assets).hasSize(1);
        Asset found = assets.get(0);
        assertThat(found.getId()).isEqualTo(created.getId());
        assertThat(found.getTenantId()).isEqualTo(tenantIds[1]);
    }

    private Map<String, BaseDataModel> createData() throws IOException {
        String oldTenantId = TenantTestUtils.setTenantId(tenantIds[1]);
        try {
            return PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService, assetPersistencyService);
        } finally {
            TenantTestUtils.setTenantId(oldTenantId);
        }
    }

    private void setupCrossTenants() {
        RequestContext.destroy();
        String[] star = new String[]{"*"};
        RequestContext.put(RequestContext.TENANT_UUID, tenantIds[0]);
        RequestContext.put(CrossTenancyCall.ALL_ACCESSIBLE_RESOURCES, Maps.newHashMap(
            tenantIds[1].replace("-", ""), star));
    }

    private void clearCrossTenants() {
        RequestContext.destroy();
    }

    private void clearData() {
        jdbcTemplate.update("DELETE FROM apm_alm.asset_instance WHERE tenant_id=?", tenantIds[1]);
        jdbcTemplate.update("DELETE FROM apm_alm.asset_type WHERE tenant_id=?", tenantIds[1]);
    }
}
