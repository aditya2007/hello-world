/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.types;

import java.io.IOException;

import org.assertj.core.util.Maps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.TEST_TENANT;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.createAssetTypeAndAssert;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests asset searches using {@link AssetPredicate}, with emphasis
 * on query by attributes.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TypeSearchByAttributesTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    /**
     *
     */
    @Test
    @Transactional
     public void customAttributeEquals() throws IOException {
        //Creating Custom Enterprise Type
        createAssetTypeAndAssert(assetTypePersistencyService, ROOT_ENTERPRISE_TYPE_ID, "MyEnterpriseType");

        TypePredicate typePredicate =
            TypePredicate.builder().attributes(Maps.newHashMap("test string", "MyEnterpriseType")).build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TEST_TENANT, typePredicate)).hasSize(1);

        typePredicate = TypePredicate.builder().attributes(Maps.newHashMap("test string", "incorrect value")).build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TEST_TENANT, typePredicate)).hasSize(0);

    }

    @Test(expected = DataIntegrityViolationException.class)
    @Transactional
    public void customAttributeEquals_SqlInjection1() throws IOException {
        //Creating Custom Enterprise Type
        createAssetTypeAndAssert(assetTypePersistencyService, ROOT_ENTERPRISE_TYPE_ID, "MyEnterpriseType");

        TypePredicate typePredicate =
            TypePredicate.builder().attributes(Maps.newHashMap("test string", "myenterprisetype\"]}}}') or 1=1)--")).build();
        assertThat(assetTypePersistencyService.findAllAssetTypes(TEST_TENANT, typePredicate)).hasSize(0);


    }

}
