/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency;

import java.io.IOException;
import java.time.OffsetDateTime;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.model.TestAssetInstance;
import com.ge.apm.alm.persistence.jpa.model.TestAssetType;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUber;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class DatesPersistTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Test
    @Transactional
    public void createDataModifiedDateTest() throws IOException {
        AssetType enterpriseType_created =
            TestUtils
                .createAssetTypeAndAssert(assetTypePersistencyService, ROOT_ENTERPRISE_TYPE_ID, "MyEnterpriseType");

        AssetType enterpriseType_found =
            assetTypePersistencyService.getAssetTypeById(TestUtils.TEST_TENANT, enterpriseType_created.getId());

        OffsetDateTime createdDate = enterpriseType_created.getCreatedDate();
        OffsetDateTime foundDate = enterpriseType_found.getCreatedDate();

        assertThat(createdDate).isBeforeOrEqualTo(OffsetDateTime.now());
        assertThat(createdDate).isEqualTo(foundDate);

        AssetType e1_updated;
        AssetType e1_found;
        try {
            e1_found =
                assetTypePersistencyService.getAssetTypeById(TestUtils.TEST_TENANT, enterpriseType_created.getId());
            TestAssetType testAssetType = new TestAssetType();
            BeanUtils.copyProperties(e1_found, testAssetType);
            testAssetType.setDescription("Description Modified");
            e1_updated = assetTypePersistencyService.updateAssetType(TestUtils.TEST_TENANT, testAssetType);
        } catch (PersistencyServiceException e) {
            fail("Unexpected exception", e);
            return;
        }
        assertThat(e1_found.getCreatedDate()).isEqualTo(e1_updated.getCreatedDate());
        assertThat(e1_found.getCreatedDate()).isBefore(e1_updated.getLastModifiedDate());
    }

    @Test
    @Transactional
    public void createDataModifiedDateTestForRowMapper() throws IOException {
        AssetType enterpriseType =
            TestUtils
                .createAssetTypeAndAssert(assetTypePersistencyService, ROOT_ENTERPRISE_TYPE_ID, "MyEnterpriseType");

        //Creating instances based on above types..
        Asset e1 =
            TestUtils.createAssetInstanceAndAssert(assetPersistencyService, getUber(), enterpriseType.getId(), null,
                "E1");

        Asset e1_found = assetPersistencyService.getAssetById(TestUtils.TEST_TENANT, getUber(), e1.getId());

        OffsetDateTime createdDate = e1.getCreatedDate();
        OffsetDateTime foundDate = e1_found.getCreatedDate();

        assertThat(createdDate).isBefore(OffsetDateTime.now());
        assertThat(createdDate.toInstant()).isEqualTo(foundDate.toInstant());

        Asset e1_updated;
        Asset e2_updated;
        try {
            TestAssetInstance testAsset = new TestAssetInstance();
            BeanUtils.copyProperties(e1_found, testAsset);
            testAsset.setDescription("Description Modified");
            e1_updated = assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, getUber(), testAsset);
            assertThat(e1_found.getCreatedDate()).isEqualTo(e1_updated.getCreatedDate());
            assertThat(e1_found.getCreatedDate()).isBefore(e1_updated.getLastModifiedDate());

            //nothing changed, so due to JPA/eclipseLink optimization, Object does not get modified.
            e2_updated = assetPersistencyService.updateAsset(TestUtils.TEST_TENANT, getUber(), e1_updated);
            assertThat(e1_updated.getLastModifiedDate().toInstant()).isEqualTo(e2_updated.getLastModifiedDate().toInstant());
        } catch (PersistencyServiceException e) {
            fail("Unexpected exception", e);
        }
    }
}
