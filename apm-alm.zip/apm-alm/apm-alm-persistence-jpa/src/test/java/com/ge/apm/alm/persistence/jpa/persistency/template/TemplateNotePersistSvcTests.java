/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.template;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.model.TemplateNotes;
import com.ge.apm.alm.model.query.TemplateNotesPredicate;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.model.TestNotes;
import com.ge.apm.alm.persistence.jpa.model.TestTemplate;
import com.ge.apm.alm.persistence.jpa.model.TestTemplateNotes;
import com.ge.apm.alm.persistence.jpa.utils.TestTemplateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */
public class TemplateNotePersistSvcTests extends TemplatePersistSvcBaseTests {

    @Test
    @Transactional
    public void testCreateTemplateNote() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestNotes testNotes = createNotes("updated part replacement");

        TestTemplateNotes templateNotes = createTemplateNotes(testTemplate.getId(), testNotes);

        TemplateNotes dbTemplateNotes = templateNotePersistencyService.getTemplateNoteById(TestUtils.TEST_TENANT,
            templateNotes.getId());
        assertThat(dbTemplateNotes).isNotNull();
        assertThat(dbTemplateNotes.getId()).isEqualTo(templateNotes.getId());
        assertThat(dbTemplateNotes.getTemplateId()).isEqualTo(testTemplate.getId());
        assertThat(dbTemplateNotes.getNotes().getId()).isEqualTo(testNotes.getId());

        //Let's retrieve template and make sure Notes are retrieved as well
        Template dbTemplate = templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, testTemplate.getId());
        assertThat(dbTemplate).isNotNull();
        assertThat(dbTemplate.getTemplateNotes()).isNotNull();
        assertThat(dbTemplate.getTemplateNotes().size()).isEqualTo(1);
        assertThat(dbTemplate.getTemplateNotes().get(0).getTemplateId()).isEqualTo(testTemplate.getId());
        assertThat(dbTemplate.getTemplateNotes().get(0).getNotes().getId()).isEqualTo(testNotes.getId());
        assertThat(dbTemplate.getTemplateNotes().get(0).getNotes().getContent()).isEqualTo(testNotes.getContent());

        deleteTestTemplateCascade(templateNotes);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateTemplateNote_missingTemplateId() {
        TestNotes testNotes = TestTemplateUtils.buildNotes(TestUtils.TEST_TENANT, "updated part replacement");
        TestTemplateNotes templateNotes = TestTemplateUtils.buildTestTemplateNotes(null, testNotes);
        templateNotePersistencyService.createTemplateNote(TestUtils.TEST_TENANT, templateNotes);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateTemplateNote_missingNotesId() {
        TestNotes testNotes = TestTemplateUtils.buildNotes(TestUtils.TEST_TENANT, "updated part replacement");
        testNotes.setId(null);
        TestTemplateNotes templateNotes = TestTemplateUtils.buildTestTemplateNotes(null, testNotes);
        templateNotePersistencyService.createTemplateNote(TestUtils.TEST_TENANT, templateNotes);
    }

    @Test
    @Transactional
    public void testCreateTemplateNotes() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate1 = createTestTemplate("GE90_template1", "TYPE_XXX", 20L);
        TestTemplate testTemplate2 = createTestTemplate("GE90_template2", "TYPE_XXX", 40L);
        TestNotes testNotes2 = createNotes("updated part replacement1");
        TestNotes testNotes1 = createNotes("updated part replacement2");

        List<TemplateNotes> templateNotesList = new ArrayList<>();
        int counter = templateNotePersistencyService.createTemplateNotes(TestUtils.TEST_TENANT, templateNotesList);
        assertThat(counter).isEqualTo(0);

        TestTemplateNotes templateNotes1 = TestTemplateUtils.buildTestTemplateNotes(testTemplate1.getId(), testNotes1);
        TestTemplateNotes templateNotes2 = TestTemplateUtils.buildTestTemplateNotes(testTemplate2.getId(), testNotes2);
        templateNotesList.add(templateNotes1);
        templateNotesList.add(templateNotes2);

        counter = templateNotePersistencyService.createTemplateNotes(TestUtils.TEST_TENANT, templateNotesList);
        assertThat(counter).isEqualTo(2);

        for (TemplateNotes templateNotes : templateNotesList) {
            deleteTestTemplateCascade(templateNotes);
        }
    }

    @Test
    @Transactional
    public void testUpdateTemplateNote() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestNotes testNotes = createNotes("updated part replacement");

        TestTemplateNotes templateNotes = createTemplateNotes(testTemplate.getId(), testNotes);

        final String templateNotesId = templateNotes.getId();
        TemplateNotes dbTemplateNotes = templateNotePersistencyService.getTemplateNoteById(TestUtils.TEST_TENANT,
            templateNotesId);
        assertThat(dbTemplateNotes).isNotNull();
        assertThat(dbTemplateNotes.getId()).isEqualTo(templateNotesId);
        assertThat(dbTemplateNotes.getTemplateId()).isEqualTo(testTemplate.getId());
        assertThat(dbTemplateNotes.getNotes().getId()).isEqualTo(testNotes.getId());

        TestNotes testNotes2 = TestTemplateUtils.buildNotes(TestUtils.TEST_TENANT, "part replacement22");
        notesPersistencyService.createNote(TestUtils.TEST_TENANT, testNotes2);
        templateNotes.setNotes(testNotes2);
        templateNotePersistencyService.updateTemplateNote(TestUtils.TEST_TENANT, templateNotes);

        deleteTestTemplateCascade(templateNotes);
    }

    @Test
    @Transactional
    public void testDeleteTemplateNoteById() throws IOException, PersistencyServiceException {
        testCreateTemplateNote();
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeleteTemplateNoteById_NotFoundException() throws PersistencyServiceException {
        templateNotePersistencyService.deleteTemplateNoteById(TestUtils.TEST_TENANT, TestTemplateUtils.getNewUuid());
    }

    @Test
    @Transactional
    public void testDeleteTemplateNotesByTemplateId() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestNotes testNotes = createNotes("updated part replacement");

        TestTemplateNotes templateNotes = createTemplateNotes(testTemplate.getId(), testNotes);
        TemplateNotes dbTemplateNotes = templateNotePersistencyService.getTemplateNoteById(TestUtils.TEST_TENANT,
            templateNotes.getId());
        assertThat(dbTemplateNotes).isNotNull();
        assertThat(dbTemplateNotes.getId()).isEqualTo(templateNotes.getId());
        assertThat(dbTemplateNotes.getTemplateId()).isEqualTo(testTemplate.getId());
        assertThat(dbTemplateNotes.getNotes().getId()).isEqualTo(testNotes.getId());

        int counter = templateNotePersistencyService.deleteTemplateNotesByTemplateId(TestUtils.TEST_TENANT,
            testTemplate.getId());
        assertThat(counter).isEqualTo(1);

        dbTemplateNotes = templateNotePersistencyService.getTemplateNoteById(TestUtils.TEST_TENANT,
            templateNotes.getId());
        assertThat(dbTemplateNotes).isNull();
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeleteTemplateNoteByTemplateId_NotFoundException() throws PersistencyServiceException {
        templateNotePersistencyService.deleteTemplateNotesByTemplateId(TestUtils.TEST_TENANT,
            TestTemplateUtils.getNewUuid());
    }

    @Test
    @Transactional
    public void testDeleteTemplateNotesById() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate = createTestTemplate("GE90_template", null, null);
        TestNotes testNotes = createNotes("updated part replacement");

        TestTemplateNotes templateNotes = createTemplateNotes(testTemplate.getId(), testNotes);
        TemplateNotes dbTemplateNotes = templateNotePersistencyService.getTemplateNoteById(TestUtils.TEST_TENANT,
            templateNotes.getId());
        assertThat(dbTemplateNotes).isNotNull();
        assertThat(dbTemplateNotes.getId()).isEqualTo(templateNotes.getId());
        assertThat(dbTemplateNotes.getTemplateId()).isEqualTo(testTemplate.getId());
        assertThat(dbTemplateNotes.getNotes().getId()).isEqualTo(testNotes.getId());

        int counter = templateNotePersistencyService.deleteTemplateNoteById(TestUtils.TEST_TENANT,
            templateNotes.getId());
        assertThat(counter).isEqualTo(1);

        dbTemplateNotes = templateNotePersistencyService.getTemplateNoteById(TestUtils.TEST_TENANT,
            templateNotes.getId());
        assertThat(dbTemplateNotes).isNull();
    }

    @Test
    @Transactional
    public void testGetTemplateNoteById() throws IOException, PersistencyServiceException {
        assertThat(templateNotePersistencyService.getTemplateNoteById(TestUtils.TEST_TENANT,
            TestTemplateUtils.getNewUuid())).isNull();
        testCreateTemplateNote();
    }

    @Test
    @Transactional
    public void testGetTemplateNotes() throws IOException, PersistencyServiceException {
        TestTemplate testTemplate1 = createTestTemplate("GE90_template1", null, null);
        TestTemplate testTemplate2 = createTestTemplate("GE90_template2", null, null);
        TestNotes testNotes2 = createNotes("updated part replacement1");
        TestNotes testNotes1 = createNotes("updated part replacement2");

        List<TemplateNotes> templateNotes = new ArrayList<>();
        TestTemplateNotes templateNotes1 = TestTemplateUtils.buildTestTemplateNotes(testTemplate1.getId(), testNotes1);
        TestTemplateNotes templateNotes2 = TestTemplateUtils.buildTestTemplateNotes(testTemplate2.getId(), testNotes2);
        templateNotes.add(templateNotes1);
        templateNotes.add(templateNotes2);
        int counter = templateNotePersistencyService.createTemplateNotes(TestUtils.TEST_TENANT, templateNotes);
        assertThat(counter).isEqualTo(2);

        TemplateNotes dbTemplateNotes = templateNotePersistencyService.getTemplateNoteById(TestUtils.TEST_TENANT,
            templateNotes1.getId());
        assertThat(dbTemplateNotes).isNotNull();
        assertThat(dbTemplateNotes.getId()).isEqualTo(templateNotes1.getId());
        assertThat(dbTemplateNotes.getTemplateId()).isEqualTo(testTemplate1.getId());
        assertThat(dbTemplateNotes.getNotes().getId()).isEqualTo(testNotes1.getId());

        List<TemplateNotes> templateNotesList;
        TemplateNotesPredicate predicate = new TemplateNotesPredicate();

        templateNotesList = templateNotePersistencyService.getTemplateNotes(TestUtils.TEST_TENANT, predicate);
        assertThat(templateNotesList).isNotNull();

        predicate.setTemplateId(null);
        predicate.setNoteId(testNotes1.getId());
        templateNotesList = templateNotePersistencyService.getTemplateNotes(TestUtils.TEST_TENANT, predicate);
        assertThat(templateNotesList).isNotNull();
        assertThat(templateNotesList.size()).isEqualTo(1);
        assertThat(templateNotesList.get(0).getId()).isEqualTo(templateNotes1.getId());
        assertThat(templateNotesList.get(0).getTemplateId()).isEqualTo(testTemplate1.getId());
        assertThat(templateNotesList.get(0).getNotes().getId()).isEqualTo(testNotes1.getId());

        predicate.setTemplateId(testTemplate1.getId());
        predicate.setNoteId(null);
        templateNotesList = templateNotePersistencyService.getTemplateNotes(TestUtils.TEST_TENANT, predicate);
        assertThat(templateNotesList).isNotNull();
        assertThat(templateNotesList.size()).isEqualTo(1);
        assertThat(templateNotesList.get(0).getId()).isEqualTo(templateNotes1.getId());
        assertThat(templateNotesList.get(0).getTemplateId()).isEqualTo(testTemplate1.getId());
        assertThat(templateNotesList.get(0).getNotes().getId()).isEqualTo(testNotes1.getId());

        predicate.setTemplateId(testTemplate1.getId());
        predicate.setNoteId(testNotes1.getId());
        templateNotesList = templateNotePersistencyService.getTemplateNotes(TestUtils.TEST_TENANT, predicate);
        assertThat(templateNotesList).isNotNull();
        assertThat(templateNotesList.size()).isEqualTo(1);
        assertThat(templateNotesList.get(0).getId()).isEqualTo(templateNotes1.getId());
        assertThat(templateNotesList.get(0).getTemplateId()).isEqualTo(testTemplate1.getId());
        assertThat(templateNotesList.get(0).getNotes().getId()).isEqualTo(testNotes1.getId());

        deleteTestTemplateCascade(templateNotes1);
    }

    private void deleteTestTemplateCascade(TemplateNotes templateNotes) throws PersistencyServiceException {
        String templateNotesId = templateNotes.getId();
        String templateId = templateNotes.getTemplateId();
        String notesId = templateNotes.getNotes().getId();

        templatePersistencyService.deleteTemplateById(TestUtils.TEST_TENANT, templateId);

        assertThat(templatePersistencyService.getTemplateById(TestUtils.TEST_TENANT, templateId)).isNull();
        assertThat(templateNotePersistencyService.getTemplateNoteById(TestUtils.TEST_TENANT, templateNotesId)).isNull();
        assertThat(notesPersistencyService.getNoteById(TestUtils.TEST_TENANT, notesId)).isNull();
    }
}
