/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.persistence.EntityManager;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroupItem;
import com.ge.apm.alm.persistence.jpa.model.TestTag;
import com.ge.apm.alm.persistence.jpa.utils.BaseDataModelUtil;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetTagLoaderTests {

    private static final int MAX_TAGS_PER_ASSET = 250;

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private AssetTagLoader assetTagLoader;

    @Autowired
    private TagPersistencyService tagPersistencyService;

    @Autowired
    private GroupPersistencyService groupPersistencyService;

    @Autowired
    private EntityManager entityManager;

    @Test
    @Transactional
    public void testLoadAsset() throws IOException, PersistencyServiceException {
        AssetType assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, "T1");
        Asset asset = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetType.getId(), null, "A1");

        AssetType tagType = assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT,
            TestUtils.createAssetType(SeedOOTBData.ROOT_TAG_TYPE_ID, "T1"));
        List<Tag> tags = createTags(asset, tagType, 5, tagPersistencyService);
        List<AssetGroupItem> groupItems = createAssetGroup(tags, groupPersistencyService, 4);
        entityManager.flush();

        AssetInstanceEntity loadedAsset =
            (AssetInstanceEntity) assetPersistencyService.getAssetById(TestUtils.TEST_TENANT,
                TestUtils.getUber(), asset.getId());
        assertThat(loadedAsset.getTags()).isNull();

        assetTagLoader.postLoad(TestUtils.TEST_TENANT, null, loadedAsset,
            AttributeSelectEnum.FULL, EnumSet.noneOf(AssetComponent.class));
        assertThat(loadedAsset.getTags()).isNull();

        assetTagLoader.postLoad(TestUtils.TEST_TENANT, null, loadedAsset,
            AttributeSelectEnum.FULL, EnumSet.of(AssetComponent.TAGS));
        assertTagsAttached(loadedAsset, tags);
        assetAssetGroupAttached(loadedAsset, groupItems);

        AssetInstanceEntity childAsset = (AssetInstanceEntity) TestUtils.createAssetInstanceAndAssert
            (assetPersistencyService, TestUtils.getUber(), assetType.getId(), asset.getId(), "A2");
        List<Tag> childTags = createTags(childAsset, tagType, 5, tagPersistencyService);
        childAsset.setParent((AssetInstanceEntity) asset);
        assetTagLoader.postLoad(TestUtils.TEST_TENANT, null, childAsset,
            AttributeSelectEnum.FULL, EnumSet.of(AssetComponent.PARENT_TAGS, AssetComponent.TAGS));
        assertTagsAttached(childAsset, childTags);
        assertTagsAttached(childAsset.getParent(), tags);
    }

    @Test
    @Transactional
    public void testLoadAssetList() throws IOException, PersistencyServiceException {
        AssetType tagType = assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT,
            TestUtils.createAssetType(SeedOOTBData.ROOT_TAG_TYPE_ID, "T1"));

        AssetType assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, "T1");
        Asset smallAsset = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetType.getId(), null, "A1");
        List<Tag> smallTags = createTags(smallAsset, tagType, 5, tagPersistencyService);
        List<AssetGroupItem> smallGroupItems = createAssetGroup(smallTags, groupPersistencyService,
            4);

        Asset largeAsset = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetType.getId(), null, "A2");
        List<Tag> largeTags = createTags(largeAsset, tagType, MAX_TAGS_PER_ASSET + 2,
            tagPersistencyService);
        List<AssetGroupItem> largeGroupItems = createAssetGroup(largeTags, groupPersistencyService,
            4);
        entityManager.flush();

        List<AssetInstanceEntity> assets = new ArrayList<>();
        assets.add((AssetInstanceEntity) assetPersistencyService.getAssetById(TestUtils.TEST_TENANT,
            TestUtils.getUber(), smallAsset.getId()));
        assets.add((AssetInstanceEntity) assetPersistencyService.getAssetById(TestUtils.TEST_TENANT,
            TestUtils.getUber(), largeAsset.getId()));
        assertThat(assets.get(0).getTags()).isNull();
        assertThat(assets.get(1).getTags()).isNull();

        assetTagLoader.postLoad(TestUtils.TEST_TENANT, null, assets, AttributeSelectEnum.FULL,
            EnumSet.noneOf(AssetComponent.class));
        assertThat(assets.get(0).getTags()).isNull();
        assertThat(assets.get(1).getTags()).isNull();

        assetTagLoader.postLoad(TestUtils.TEST_TENANT, null, assets, AttributeSelectEnum.FULL,
            EnumSet.of(AssetComponent.TAGS));
        assertTagsAttached(assets.get(0), smallTags);
        assetAssetGroupAttached(assets.get(0), smallGroupItems);
        assertTagsAttached(assets.get(1), largeTags);
        assetAssetGroupAttached(assets.get(1), largeGroupItems);

    }

    @Test
    @Transactional
    public void testLoadAssetsWithoutTags() throws IOException {
        AssetType assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, "T1");
        AssetInstanceEntity parent = (AssetInstanceEntity) TestUtils.createAssetInstanceAndAssert
            (assetPersistencyService, TestUtils.getUber(), assetType.getId(), null, "P1");
        AssetInstanceEntity child = (AssetInstanceEntity) TestUtils.createAssetInstanceAndAssert
            (assetPersistencyService, TestUtils.getUber(), assetType.getId(), parent.getId(), "C1");

        // this will test the loader to set tags when both parent and its child are in the list.
        AssetInstanceEntity parentCopy = new AssetInstanceEntity();
        BeanUtils.copyProperties(parent, parentCopy);
        child.setParent(parentCopy);

        List<AssetInstanceEntity> assets = Arrays.asList(child, parent);
        assetTagLoader.postLoad(TestUtils.TEST_TENANT, null, assets, AttributeSelectEnum.FULL,
            EnumSet.of(AssetComponent.TAGS, AssetComponent.PARENT_TAGS));
        assert(parent.getTags()).isEmpty();
        assert(child.getTags()).isEmpty();
        assert(child.getParent().getTags()).isEmpty();
    }

    private void assertTagsAttached(Asset asset, List<Tag> originalTags) {
        List<Tag> loadedTags = asset.getTags();
        assertThat(loadedTags).hasSize(Math.min(originalTags.size(), MAX_TAGS_PER_ASSET));
        loadedTags.forEach(tag -> {
            Asset container = tag.getAsset();
            assertThat(container).isNotNull();
            assertThat(container.getId()).isEqualTo(asset.getId());
        });
    }

    private void assetAssetGroupAttached(Asset asset, List<AssetGroupItem> groupItems) {
        Map<String, AssetGroupItem> tagIdToAssetGroup = new HashMap<>();
        groupItems.forEach(item -> tagIdToAssetGroup.put(item.getObjectId(), item));

        // handling not loaded tags due to query limit
        Map<String, Tag> tagIdMap = BaseDataModelUtil.toIdMap(asset.getTags(), null);
        new HashMap<>(tagIdToAssetGroup).keySet().forEach(id -> {
            if (!tagIdMap.containsKey(id)) {
                tagIdToAssetGroup.remove(id);
            }
        });

        asset.getTags().forEach(tag -> {
            List<AssetGroup> groups = tag.getAssetGroups();
            if (tagIdToAssetGroup.containsKey(tag.getId())) {
                assertThat(groups).hasSize(1);
                AssetGroup group = groups.get(0);
                assertThat(group.getCategory().equals(AssetGroupCategory.TAG_CORRELATION));
                assertThat(group.getItems()).hasSize(groupItems.size());
            } else {
                assertThat(groups).isNull();
            }
        });
    }

    static List<Tag> createTags(Asset asset, AssetType tagType, int numTags,
        TagPersistencyService tagPersistencyService)
        throws PersistencyServiceException {
        List<Tag> tagList = new ArrayList<>(numTags);
        for (int i = 0; i < numTags; i++) {
            String name = asset.getId() + "tagLoader_" + i;
            Tag tag = TestTag.builder().
                id(UUID.randomUUID().toString()).tenantId(TestUtils.TEST_TENANT).assetId(
                asset.getId())
                .name(name).sourceKey(name).description(name)
                .tagType(tagType.getId())
                .tagCategory("SENSOR")
                .build();

            tag = tagPersistencyService.createTag(TestUtils.TEST_TENANT, TestUtils.getUber(), tag);
            tagList.add(tag);
        }

        return tagList;
    }

    static List<AssetGroupItem> createAssetGroup(List<Tag> tags,
        GroupPersistencyService groupPersistencyService, int numCorrelations)
        throws PersistencyServiceException {
        AssetGroup assetGroup = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT)
            .id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION)
            .build();

        assetGroup = groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, assetGroup);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < numCorrelations; i++) {
            items.add(TestAssetGroupItem.builder().id(UUID.randomUUID().toString()).groupId(
                assetGroup.getId())
                .objectId(tags.get(i).getId()).tenantId(TestUtils.TEST_TENANT).position(i + 1)
                .build());
        }

        groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, TestUtils.getUber(), assetGroup.getId(),
                items);

        return items;
    }
}
