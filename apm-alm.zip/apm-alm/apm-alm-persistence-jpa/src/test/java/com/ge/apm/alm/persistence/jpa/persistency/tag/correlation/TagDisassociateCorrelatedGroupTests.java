/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.tag.correlation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.utils.TagPredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUber;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUnPrivileged;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TagDisassociateCorrelatedGroupTests extends TagCorrelationBaseTest {

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void disassociateCorrelatedGroup_emptyNotAllowed() throws PersistencyServiceException, IOException {
        createTypes(assetTypePersistencyService);
        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION).build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).extracting(
            AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);
        groupPersistencyService.disassociateCorrelatedGroup(TestUtils.TEST_TENANT, getUber(), group.getId(),
            TestUtils.NULL_UUID);
    }

    @Test(expected = UnsupportedOperationException.class)
    @Transactional
    public void disassociateCorrelatedGroup_atTail() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 5;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION).build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).extracting(
            AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")), group.getId(),
                items)).isEqualTo(items.size());

        groupPersistencyService.disassociateCorrelatedGroup(TestUtils.TEST_TENANT, getUber(), group.getId(),
            tags.get(count - 1).getId());
    }

    @Test
    @Transactional
    public void disassociateCorrelatedGroup_secondToLast() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 5;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION).build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).extracting(
            AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

         assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")), group.getId(),
                items)).isEqualTo(items.size());

        assertThat(
            tagPersistencyService.getCorrelatedTagsById(TestUtils.TEST_TENANT, getUber(), tags.get(4).getId())
                .size()).isEqualTo(5);

        groupPersistencyService.disassociateCorrelatedGroup(TestUtils.TEST_TENANT, getUber(), group.getId(),
            tags.get(count - 2).getId());

        List<AssetGroupItem> remaining = groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT,
            getUber(), group.getId());

        assertThat(remaining).hasSize(4).extracting(AssetGroupItem::getObjectId).containsOnly(tags.get(0).getId(),
            tags.get(1).getId(), tags.get(2).getId(), tags.get(3).getId());
        for (int i = 0, size = remaining.size(); i < size; i++) {
            assertThat(remaining.get(i).getPosition()).isEqualTo(i + 1);
        }

        assertThat(tagPersistencyService
            .getCorrelatedTagsById(TestUtils.TEST_TENANT, getUber(), tags.get(4).getId())).isEmpty();
    }

    @Test
    @Transactional
    public void disassociateCorrelatedGroup_fiveItemsAtMiddle() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 5;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION).build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).extracting(
            AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")), group.getId(),
                items)).isEqualTo(items.size());

        assertThat(
            tagPersistencyService.getCorrelatedTagsById(TestUtils.TEST_TENANT, getUber(), tags.get(4).getId())
                .size()).isEqualTo(5);

        groupPersistencyService.disassociateCorrelatedGroup(TestUtils.TEST_TENANT, getUber(), group.getId(),
            tags.get(2).getId());

        assertThat(
            tagPersistencyService.getCorrelatedTagsById(TestUtils.TEST_TENANT, getUber(), tags.get(0).getId())
                .size()).isEqualTo(3);

        assertThat(
            tagPersistencyService.getCorrelatedTagsById(TestUtils.TEST_TENANT, getUber(), tags.get(3).getId())
                .size()).isEqualTo(2);

        List<AssetGroupItem> remaining = groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT,
            getUber(), group.getId());

        assertThat(remaining).hasSize(3).extracting(AssetGroupItem::getObjectId).containsOnly(tags.get(0).getId(),
            tags.get(1).getId(), tags.get(2).getId());
        for (int i = 0, size = remaining.size(); i < size; i++) {
            assertThat(remaining.get(i).getPosition()).isEqualTo(i + 1);
        }

        remaining = groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUber(),
            groupPersistencyService.getCorrelationsForTags(TestUtils.TEST_TENANT, getUber(),
                Collections.singleton(tags.get(3).getId())).get(tags.get(3).getId()).getId());

        assertThat(remaining).hasSize(2).extracting(AssetGroupItem::getObjectId).containsOnly(tags.get(3).getId(),
            tags.get(4).getId());
        for (int i = 0, size = remaining.size(); i < size; i++) {
            assertThat(remaining.get(i).getPosition()).isEqualTo(i + 1);
        }
    }

    @Test
    @Transactional
    public void disassociateCorrelatedGroup_atHead_with2ItemsOnly() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 2;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);
        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION).build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).extracting(
            AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")),
                group.getId(), items)).isEqualTo(items.size());

        assertThat(groupPersistencyService
            .disassociateCorrelatedGroup(TestUtils.TEST_TENANT, getUber(), group.getId(),
                tags.get(0).getId())).isNull();
        assertThat(groupPersistencyService.getAssetGroupById(TestUtils.TEST_TENANT, group.getId())).isNull();
    }

    @Test
    @Transactional
    public void disassociateCorrelatedGroup_atHead() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 6;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);
        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION).build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).extracting(
            AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")), group.getId(),
                items)).isEqualTo(items.size());

        assertThat(groupPersistencyService
            .disassociateCorrelatedGroup(TestUtils.TEST_TENANT, getUber(), group.getId(),
                tags.get(0).getId())).isNull();
        List<AssetGroupItem> remaining = groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT,
            getUber(), group.getId());

        assertThat(remaining).hasSize(5).extracting(AssetGroupItem::getObjectId).containsOnly(tags.get(1).getId(),
            tags.get(2).getId(), tags.get(3).getId(), tags.get(4).getId(), tags.get(5).getId());
        for (int i = 0, size = remaining.size(); i < size; i++) {
            assertThat(remaining.get(i).getPosition()).isEqualTo(i + 1);
        }
    }

    @Test
    @Transactional
    public void disassociateCorrelatedGroup_3Items_atMiddle() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 3;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION).build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).extracting(
            AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")), group.getId(),
                items)).isEqualTo(items.size());

        assertThat(groupPersistencyService
            .disassociateCorrelatedGroup(TestUtils.TEST_TENANT, getUber(), group.getId(),
                tags.get(1).getId())).isNull();
        List<AssetGroupItem> remaining = groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT,
            getUber(), group.getId());

        assertThat(remaining).hasSize(2).extracting(AssetGroupItem::getObjectId).containsOnly(tags.get(0).getId(),
            tags.get(1).getId());
        for (int i = 0, size = remaining.size(); i < size; i++) {
            assertThat(remaining.get(i).getPosition()).isEqualTo(i + 1);
        }
    }

    @Test
    @Transactional
    public void disassociateCorrelatedGroup_createNewGroup() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 6;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        AssetGroup group = TestAssetGroup.builder().tenantId(TestUtils.TEST_TENANT).id(UUID.randomUUID().toString())
            .category(AssetGroupCategory.TAG_CORRELATION).build();
        assertThat(groupPersistencyService.createAssetGroup(TestUtils.TEST_TENANT, group)).extracting(
            AssetGroup::getCategory).containsOnly(AssetGroupCategory.TAG_CORRELATION);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        assertThat(groupPersistencyService
            .createAssetGroupItems(TestUtils.TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")), group.getId(),
                items)).isEqualTo(items.size());

        String newGrpId = groupPersistencyService.disassociateCorrelatedGroup(TestUtils.TEST_TENANT,
            getUber(), group.getId(), tags.get(2).getId());
        assertThat(newGrpId).isNotNull();
        assertThat(groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT, getUber(), group.getId()))
            .hasSize(3).extracting(AssetGroupItem::getObjectId).containsOnly(tags.get(0).getId(), tags.get(1).getId(),
            tags.get(2).getId());
        assertThat(groupPersistencyService.getGroupItems(TestUtils.TEST_TENANT,
            getUnPrivileged(assets.get("E1_S1_Seg1")), newGrpId)).hasSize(3)
            .extracting(AssetGroupItem::getObjectId).containsOnly(tags.get(5).getId(), tags.get(4).getId(),
            tags.get(3).getId());
    }
}
