/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.mirror;

import java.io.IOException;
import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.TEST_TENANT;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.createAssetInstance;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.createAssetTypeAndAssert;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUber;

@RunWith(SpringRunner.class)
public class MirrorAssetPersistSvcTests extends MirrorPersistSvcTests {

    @Autowired
    private AssetPersistencyService assetService;

    @Autowired
    private AssetTypePersistencyService typeService;

    @Test
    @Transactional
    public void testMirrorCRUDAssets() throws IOException, PersistencyServiceException {

        // CREATE

        AssetType siteType = createAssetTypeAndAssert(typeService, SeedOOTBData.ROOT_SITE_TYPE_ID, "SiteType");

        Asset asset = createAssetInstance(siteType.getId(), null, "NewSite");
        assetService.createAsset(TEST_TENANT, getUber(), asset);

        assertEventsContain("CREATE", "Site", asset.getId());

        AssetType tagType = createAssetTypeAndAssert(typeService, SeedOOTBData.ROOT_TAG_TYPE_ID, "TagType");
        AssetType assetType = createAssetTypeAndAssert(typeService, SeedOOTBData.ROOT_ASSET_TYPE_ID, "AssetType");
        AssetType enterpriseType =
            createAssetTypeAndAssert(typeService, SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID, "EnterpriseType");

        Asset asset1 = createAssetInstance(siteType.getId(), null, "NewSite");
        Asset asset2 = createAssetInstance(assetType.getId(), null, "NewAsset");
        Asset asset3 = createAssetInstance(tagType.getId(), null, "NewTag");
        Asset asset4 = createAssetInstance(tagType.getId(), null, "NewTag");
        Asset asset5 = createAssetInstance(enterpriseType.getId(), null, "NewEnterprise");

        assetService.createAssets(TEST_TENANT, getUber(), Arrays.asList(asset1, asset2, asset3, asset4, asset5));

        assertEventsContain(
            "CREATE", "Site", asset1.getId(),
            "CREATE", "Asset", asset2.getId(),
            "CREATE", "Tag", asset3.getId(),
            "CREATE", "Tag", asset4.getId(),
            "CREATE", "Enterprise", asset5.getId()
        );

        // UPDATE

        assetService.updateAsset(TEST_TENANT, getUber(), asset3);

        assertEventsContain("UPDATE", "Tag", asset3.getId());

        assetService.updateAssets(TEST_TENANT, getUber(), Arrays.asList(asset1, asset2, asset4));

        assertEventsContain(
            "UPDATE", "Site", asset1.getId(),
            "UPDATE", "Asset", asset2.getId(),
            "UPDATE", "Tag", asset4.getId()
        );

        // DELETE

        assetService.deleteAsset(TEST_TENANT, getUber(), asset.getId());
        assetService.deleteAsset(TEST_TENANT, getUber(), asset5.getId());

        assertEventsContain(
            "DELETE", "Site", asset.getId(),
            "DELETE", "Enterprise", asset5.getId()
        );
    }
}
