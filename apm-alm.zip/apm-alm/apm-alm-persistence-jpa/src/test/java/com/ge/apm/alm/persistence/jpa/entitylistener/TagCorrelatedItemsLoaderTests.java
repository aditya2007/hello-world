/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.model.view.TagComponent;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.TagInstanceEntity;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TagCorrelatedItemsLoaderTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private TagCorrelatedItemsLoader tagPostLoader;

    @Autowired
    private TagPersistencyService tagPersistencyService;

    @Autowired
    private GroupPersistencyService groupPersistencyService;

    @Autowired
    private EntityManager entityManager;

    @Test
    @Transactional
    public void testLoadTag() throws IOException, PersistencyServiceException {
        AssetType assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, "T1");
        Asset asset = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetType.getId(), null, "A1");

        AssetType tagType = assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT,
            TestUtils.createAssetType(SeedOOTBData.ROOT_TAG_TYPE_ID, "T1"));
        List<Tag> tags = AssetTagLoaderTests.createTags(asset, tagType, 5, tagPersistencyService);
        List<AssetGroupItem> groupItems = AssetTagLoaderTests.createAssetGroup(tags,
            groupPersistencyService, 1);
        entityManager.flush();

        Tag originalTag = tags.get(0);
        TagInstanceEntity loadedTag = (TagInstanceEntity) tagPersistencyService.getTagById(
            TestUtils.TEST_TENANT, TestUtils.getUber(), originalTag.getId());
        assertThat(loadedTag.getAssetGroups()).isNull();

        getPostLoader().postLoad(TestUtils.TEST_TENANT, null, loadedTag, AttributeSelectEnum.FULL,
            getComponentSet());
        assertCorrelation(loadedTag, groupItems);
    }

    @Test
    @Transactional
    public void testLoadTags() throws IOException, PersistencyServiceException {
        AssetType assetType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService,
            SeedOOTBData.ROOT_ASSET_TYPE_ID, "T1");
        Asset asset = TestUtils.createAssetInstanceAndAssert(assetPersistencyService,
            TestUtils.getUber(), assetType.getId(), null, "A1");

        AssetType tagType = assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT,
            TestUtils.createAssetType(SeedOOTBData.ROOT_TAG_TYPE_ID, "T1"));
        List<Tag> tags = AssetTagLoaderTests.createTags(asset, tagType, 5, tagPersistencyService);
        List<AssetGroupItem> groupItems = AssetTagLoaderTests.createAssetGroup(tags,
            groupPersistencyService, tags.size());
        entityManager.flush();

        List<TagInstanceEntity> loadedTags = castTagList(tagPersistencyService
            .getTagsForAsset(TestUtils.TEST_TENANT, TestUtils.getUber(), asset.getId(),
                false, new TagPredicate()));
        loadedTags.forEach(tag -> assertThat(tag.getAssetGroups()).isNull());

        getPostLoader().postLoad(TestUtils.TEST_TENANT, null, loadedTags,
            AttributeSelectEnum.FULL, getComponentSet());
        loadedTags.forEach(tag -> assertCorrelation(tag, groupItems));
    }

    @SuppressWarnings("unchecked")
    private List<TagInstanceEntity> castTagList(List<?> list) {
        return (List<TagInstanceEntity>) list;
    }

    private void assertCorrelation(Tag tag, List<AssetGroupItem> groupItems) {
        List<AssetGroup> groups = tag.getAssetGroups();
        assertThat(groups).hasSize(1);
        AssetGroup group = groups.get(0);
        assertThat(group.getCategory()).isEqualTo(AssetGroupCategory.TAG_CORRELATION);
        assertThat(group.getItems()).hasSize(groupItems.size());

        group.getItems().forEach(item -> {
            assertThat(item.getGroupId()).isEqualTo(groupItems.get(0).getGroupId());
            assertThat(item.getObjectId()).isNotNull();
            assertItemObject(item, groupItems);
        });
    }

    Set<TagComponent> getComponentSet() {
        return EnumSet.of(TagComponent.CORRELATED_ITEMS);
    }

    void assertItemObject(AssetGroupItem item, List<AssetGroupItem> groupItems) {
        // doing nothing.
    }

    PostLoadHandler<TagInstanceEntity, TagComponent> getPostLoader() {
        return this.tagPostLoader;
    }

}
