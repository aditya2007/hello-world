package com.ge.apm.alm.persistence.jpa.persistency.config;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Context;
import com.ge.apm.alm.model.ReservedAttributeContextConfig;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.query.ConfigContextQuery;
import com.ge.apm.alm.persistence.ContextPersistencyService;
import com.ge.apm.alm.persistence.ReservedAttributeContextConfigService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.ContextEntity;
import com.ge.apm.alm.persistence.jpa.entity.ReservedAttributeContextConfigEntity;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class ReservedAttributeContextConfigPersistSvcTests {

    @Autowired
    private ReservedAttributeContextConfigService reservedAttributeContextConfigService;

    @Autowired
    private ContextPersistencyService contextPersistencyService;

    @Test
    @Transactional
    public void testSave_FindByTenantId_Delete() {
        ReservedAttributeContextConfigEntity contextConfig = contextConfigSetup();
        reservedAttributeContextConfigService.save(contextConfig);
        List<ReservedAttributeContextConfig> configList = reservedAttributeContextConfigService.findAllByTenantId(
            TestUtils.TEST_TENANT);
        Assert.assertNotNull(configList);
        Assert.assertEquals(72, configList.size());
        reservedAttributeContextConfigService.delete(contextConfig);
        List<ReservedAttributeContextConfig> list = reservedAttributeContextConfigService.findAllByTenantId(
            TestUtils.TEST_TENANT);
        Assert.assertEquals(71, list.size());
    }

    @Test
    @Transactional
    public void testFindAllByContextAndTenantId() {
        ReservedAttributeContextConfigEntity contextConfig = contextConfigSetup();
        reservedAttributeContextConfigService.save(contextConfig);
        Context context = contextPersistencyService.findByContextName("asset-state");
        List<ReservedAttributeContextConfig> configList = reservedAttributeContextConfigService
            .findAllByContextAndCodeAndTenantId(context.getContextName(), TestUtils.TEST_TENANT,
                contextConfig.getCode());
        Assert.assertNotNull(configList);
        Assert.assertEquals(configList.get(0).getTenantId(), TestUtils.TEST_TENANT);
    }

    @Test
    @Transactional
    public void testFindByContextAndTenantIdAndIsDefaultTrue() {
        ReservedAttributeContextConfigEntity contextConfig = contextConfigSetup();
        reservedAttributeContextConfigService.save(contextConfig);
        Context context = contextPersistencyService.findByContextName("asset-state");
        ReservedAttributeContextConfig config = reservedAttributeContextConfigService
            .findByContextAndTenantIdAndIsDefaultTrue(context.getContextName(), TestUtils.TEST_TENANT);
        Assert.assertNotNull(config);
        Assert.assertEquals(config.getTenantId(), TestUtils.TEST_TENANT);
    }

    @Test
    @Transactional
    public void testFindByContextAndTenantIdAndCode() {
        ReservedAttributeContextConfigEntity contextConfig = contextConfigSetup();
        reservedAttributeContextConfigService.save(contextConfig);
        Context context = contextPersistencyService.findByContextName("asset-state");
        ReservedAttributeContextConfig config = reservedAttributeContextConfigService.findByContextAndTenantIdAndCode(
            context.getContextName(), TestUtils.TEST_TENANT, contextConfig.getCode());
        Assert.assertNotNull(config);
        Assert.assertEquals(config.getTenantId(), TestUtils.TEST_TENANT);
    }

    @Test
    @Transactional
    public void testFindAllByContextAndTenantId2() {
        ReservedAttributeContextConfigEntity contextConfig = contextConfigSetup();
        reservedAttributeContextConfigService.save(contextConfig);
        Context context = contextPersistencyService.findByContextName("asset-state");
        List<ReservedAttributeContextConfig> config = reservedAttributeContextConfigService.findAllByContextAndTenantId(
            context.getContextName(), TestUtils.TEST_TENANT);
        Assert.assertNotNull(config);
        Assert.assertEquals(13, config.size());
        Assert.assertEquals(config.get(config.size() - 1).getTenantId(), TestUtils.TEST_TENANT);
        Assert.assertEquals(config.get(0).getTenantId(), SeedOOTBData.SYSTEM_TENANT_ID);
    }

    @Test
    @Transactional
    public void testFindAllByQuerySpecs() {
        ReservedAttributeContextConfigEntity contextConfig = contextConfigSetup();
        reservedAttributeContextConfigService.save(contextConfig);
        ConfigContextQuery queryConfig = new ConfigContextQuery();
        queryConfig.setDisplayName(new String[] { contextConfig.getDisplayName() });
        queryConfig.setSemanticName(new String[] { contextConfig.getSemanticName() });
        queryConfig.setContext(new String[] { contextConfig.getContext().getContextName() });
        queryConfig.setIsActive(true);
        queryConfig.setCode(new String[] { contextConfig.getCode() });
        Assert.assertEquals(true, queryConfig.isAlmFilter());
        Assert.assertEquals(false, queryConfig.isEmpty());
        List<ReservedAttributeContextConfig> result = reservedAttributeContextConfigService.findAllByQuerySpecs(
            TestUtils.TEST_TENANT, queryConfig);
        Assert.assertEquals(1, result.size());
        Assert.assertEquals(result.get(0).getCode(), contextConfig.getCode());
    }

    private ReservedAttributeContextConfigEntity contextConfigSetup() {
        ReservedAttributeContextConfigEntity contextConfig = new ReservedAttributeContextConfigEntity();
        contextConfig.setCode("code");
        contextConfig.setDescription("description");
        contextConfig.setDisplayName("name");
        contextConfig.setSemanticName("semanticName");
        contextConfig.setIsDefault(true);
        contextConfig.setIsActive(true);
        contextConfig.setContext((ContextEntity) contextPersistencyService.findByContextName("asset-state"));
        contextConfig.setTenantId(TestUtils.TEST_TENANT);
        return contextConfig;
    }
}
