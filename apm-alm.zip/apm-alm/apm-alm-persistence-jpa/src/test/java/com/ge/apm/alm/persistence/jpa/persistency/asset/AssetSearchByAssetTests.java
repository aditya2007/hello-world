/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.google.common.collect.Sets;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.utils.ConfigUtils;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_ASSET_TYPE_ID;
import static com.ge.apm.alm.model.query.Operand.AND;
import static com.ge.apm.alm.model.query.Operand.OR;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests asset searches using {@link com.ge.apm.alm.model.query.AssetPredicate}, with
 * {@link com.ge.apm.alm.model.query.TypePredicate} and
 * {@link com.ge.apm.alm.model.query.ParentPredicate} either separately or in combination.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetSearchByAssetTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Test
    @Transactional
    public void getAssets_withWildcards() throws IOException, PersistencyServiceException {
        //Creating Custom Turbine Type
        AssetType turbineType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, ROOT_ASSET_TYPE_ID,
            "WildcardSearchTestType");

        Asset existingParent = assetPersistencyService.createAsset(TestUtils.TEST_TENANT, TestUtils.getUber(),
            TestUtils.createAssetInstance(turbineType.getId(), null, "wildcardsearchtestparent"));
        assertThat(existingParent.getAncestorsArray()).hasSize(0);

        List<Asset> assets = new ArrayList<>();

        // create assets without parent and children
        int count = 3;
        for (int i = 0; i < count; i++) {
            assets.add(TestUtils.createAssetInstance(turbineType.getId(), null, i + "_WildcardSearchTest_" + i));
        }
        assertThat(assetPersistencyService.createAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), assets)).isEqualTo(
            assets.size());

        AssetPredicate predicate = null;
        for (String value : Arrays.asList("*SearchTest*", "*Wildcard*Test*")) {
            predicate = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).description(
                value).sourceKey(value).build();
            assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
                .hasSize(count + 1).extracting(Asset::getDescription).containsOnly(assets.get(0).getDescription(),
                assets.get(1).getDescription(), assets.get(2).getDescription(), existingParent.getDescription());

            predicate = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).build();
            assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
                .hasSize(count + 1).extracting(Asset::getName).containsOnly(assets.get(0).getName(),
                assets.get(1).getName(), assets.get(2).getName(), existingParent.getName());

            predicate = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).description(value)
                .build();
            assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
                .hasSize(count + 1).extracting(Asset::getDescription).containsOnly(assets.get(0).getDescription(),
                assets.get(1).getDescription(), assets.get(2).getDescription(), existingParent.getDescription());

            predicate = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).sourceKey(value)
                .build();
            assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
                .hasSize(count + 1).extracting(Asset::getSourceKey).containsOnly(assets.get(0).getSourceKey(),
                assets.get(1).getSourceKey(), assets.get(2).getSourceKey(), existingParent.getSourceKey());
        }

        for (int i = 0; i < count; i++) {
            String value = "*_" + i;
            predicate = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).description(
                value).sourceKey(value).build();
            assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
                .hasSize(1).extracting(Asset::getDescription).containsOnly(assets.get(i).getDescription());

            predicate = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).build();
            assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
                .hasSize(1).extracting(Asset::getName).containsOnly(assets.get(i).getName());

            predicate = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).description(value)
                .build();
            assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
                .hasSize(1).extracting(Asset::getDescription).containsOnly(assets.get(i).getDescription());

            predicate = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).sourceKey(value)
                .build();
            assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
                .hasSize(1).extracting(Asset::getSourceKey).containsOnly(assets.get(i).getSourceKey());

            value = i + "_*";
            predicate = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).description(
                value).sourceKey(value).build();
            assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
                .hasSize(1).extracting(Asset::getDescription).containsOnly(assets.get(i).getDescription());

            predicate = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).name(value).build();
            assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
                .hasSize(1).extracting(Asset::getName).containsOnly(assets.get(i).getName());

            predicate = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).description(value)
                .build();
            assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
                .hasSize(1).extracting(Asset::getDescription).containsOnly(assets.get(i).getDescription());

            predicate = AssetPredicate.builder().attributeSelectEnum(AttributeSelectEnum.BASIC).sourceKey(value)
                .build();
            assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate))
                .hasSize(1).extracting(Asset::getSourceKey).containsOnly(assets.get(i).getSourceKey());
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////
    // AssetPredicate tests with AND/OR combinations of name, sourceKey, description
    ////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * (name = "E1_S1_Seg1_A1")
     */
    @Test
    @Transactional
    public void getAssets_byName() throws IOException {
        Map<String, BaseDataModel> data = setupData();

        AssetPredicate predicate = AssetPredicate.builder().name("E1_S1_Seg1_A1").build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1");

        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Collections.singletonList(data.get("E1").getId()), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1_S1").getId(), data.get("E1_S2").getId()),
                predicate)).hasSize(1).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_byName_SqlInjection1() throws IOException {
        setupData();
        AssetPredicate predicate = AssetPredicate.builder().name("Generator' or 'x'='x").build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_byDescription_SqlInjection1() throws IOException {
        setupData();
        AssetPredicate predicate = AssetPredicate.builder().description("Generator' or 'x'='x").build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_bySourceKey_SqlInjection1() throws IOException {
        setupData();
        AssetPredicate predicate = AssetPredicate.builder().sourceKey("Generator' or 'x'='x").build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(0);
    }

    /**
     * (name like "E1_S1_Seg1_*" or (sourceKey like "E1_S2*"))
     */
    @Test
    @Transactional
    public void getAssets_byNameOrName() throws IOException {
        Map<String, BaseDataModel> data = setupData();

        AssetPredicate nameOrName = AssetPredicate.builder().name("E1_S1_Seg1_*").childOperand(OR).childPredicates(
            Collections.singletonList(AssetPredicate.builder().sourceKey("E1_S2*").build())).build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), nameOrName)).hasSize(7)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S2", "E1_S2_Seg4",
            "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");

        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Collections.singletonList(data.get("E1").getId()), nameOrName)).hasSize(7)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S2", "E1_S2_Seg4",
            "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1_S1").getId(), data.get("E1_S2").getId()),
                nameOrName)).hasSize(7).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg1_B1",
            "E1_S2", "E1_S2_Seg4", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), nameOrName))
            .hasSize(0);
    }

    /**
     * (name like "E1_S1_Seg1_A*" or (sourceKey like "E1_S1_Seg*2"))
     */
    @Test
    @Transactional
    public void getAssets_byNameOrSourceKey() throws IOException {
        Map<String, BaseDataModel> data = setupData();

        AssetPredicate nameOrSourceKey = AssetPredicate.builder().name("E1_S1_Seg1_A*").childOperand(OR)
            .childPredicates(Collections.singletonList(AssetPredicate.builder().sourceKey("E1_S1_Seg*2").build()))
            .build();

        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), nameOrSourceKey))
            .hasSize(4).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg2", "E1_S1_Seg2_A2",
            "E1_S1_Seg2_B2");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT,
            Arrays.asList(data.get("E1_S1_Seg1").getId(), data.get("E1_S1_Seg2").getId()), nameOrSourceKey)).hasSize(4)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg2", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), nameOrSourceKey))
            .hasSize(0);
    }

    /**
     * (name like "E1_S1_Seg1_A*" and (sourceKey like "*B2" or description = "*3"))
     * <p>
     * alternatively
     * <p>
     * (name like "E1_S1_Seg1_A*" and (sourceKey like "*B2" or (description = "*3")))
     */
    @Test
    @Transactional
    public void getAssets_byNameAndSourceKeyOrDescription() throws IOException {
        Map<String, BaseDataModel> data = setupData();

        AssetPredicate nameAndSourceKeyOrDescription = AssetPredicate.builder().name("E1_S1_Seg*").childOperand(AND)
            .childPredicates(Arrays.asList(AssetPredicate.builder().sourceKey("*B2").peerOperand(OR).build(),
                AssetPredicate.builder().description("*3").build())).build();
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), nameAndSourceKeyOrDescription)).hasSize(5)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg2_B2", "E1_S1_Seg3", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3",
            "E1_S1_Seg3_C3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Collections.singletonList(data.get("E1_S1").getId()),
                nameAndSourceKeyOrDescription)).hasSize(5).extracting(Asset::getName).containsOnly("E1_S1_Seg2_B2",
            "E1_S1_Seg3", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3", "E1_S1_Seg3_C3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), nameAndSourceKeyOrDescription)).hasSize(0);

        nameAndSourceKeyOrDescription = AssetPredicate.builder().name("E1_S1_Seg*").childOperand(AND).childPredicates(
            Collections.singletonList(AssetPredicate.builder().sourceKey("*B2").childOperand(OR)
                .childPredicates(Collections.singletonList(AssetPredicate.builder().description("*3").build()))
                .build())).build();
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), nameAndSourceKeyOrDescription)).hasSize(5)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg2_B2", "E1_S1_Seg3", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3",
            "E1_S1_Seg3_C3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Collections.singletonList(data.get("E1_S1").getId()),
                nameAndSourceKeyOrDescription)).hasSize(5).extracting(Asset::getName).containsOnly("E1_S1_Seg2_B2",
            "E1_S1_Seg3", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3", "E1_S1_Seg3_C3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), nameAndSourceKeyOrDescription)).hasSize(0);
    }

    /**
     * (name like "E1_S1_Seg1_A*" or (sourceKey like "E1_S1_Seg*2" or description = "E1_S2_Seg4_A4"))
     * <p>
     * alternatively
     * <p>
     * (name like "E1_S1_Seg1_A*" or (sourceKey like "E1_S1_Seg*2" or (description = "E1_S2_Seg4_A4")))
     */
    @Test
    @Transactional
    public void getAssets_byNameOrSourceKeyOrDescription() throws IOException {
        Map<String, BaseDataModel> data = setupData();

        AssetPredicate nameOrSourceKeyOrDescription = AssetPredicate.builder().name("E1_S1_Seg1_A*").childOperand(OR)
            .childPredicates(Arrays.asList(AssetPredicate.builder().sourceKey("E1_S1_Seg*2").peerOperand(OR).build(),
                AssetPredicate.builder().description("*_C*").build())).build();
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), nameOrSourceKeyOrDescription))
            .hasSize(6).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg2", "E1_S1_Seg2_A2",
            "E1_S1_Seg2_B2", "E1_S1_Seg3_C3", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1_S1").getId(), data.get("E1_S2").getId()),
                nameOrSourceKeyOrDescription)).hasSize(6).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1",
            "E1_S1_Seg2", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2", "E1_S1_Seg3_C3", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), nameOrSourceKeyOrDescription)).hasSize(0);

        nameOrSourceKeyOrDescription = AssetPredicate.builder().name("E1_S1_Seg1_A*").childOperand(OR).childPredicates(
            Collections.singletonList(AssetPredicate.builder().sourceKey("E1_S1_Seg*2").childOperand(OR)
                .childPredicates(Collections.singletonList(AssetPredicate.builder().description("*_C*").build()))
                .build())).build();
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), nameOrSourceKeyOrDescription))
            .hasSize(6).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1", "E1_S1_Seg2", "E1_S1_Seg2_A2",
            "E1_S1_Seg2_B2", "E1_S1_Seg3_C3", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1_S1").getId(), data.get("E1_S2").getId()),
                nameOrSourceKeyOrDescription)).hasSize(6).extracting(Asset::getName).containsOnly("E1_S1_Seg1_A1",
            "E1_S1_Seg2", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2", "E1_S1_Seg3_C3", "E1_S2_Seg4_C4");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), nameOrSourceKeyOrDescription)).hasSize(0);
    }

    @Test
    @Transactional
    public void childrenOrderByHierarchy() throws IOException {
        Map<String, BaseDataModel> data = setupData();
        int siteChildrenCount = 2;
        // add enterprise children to E1
        String e1TypeId = data.get("E1Type").getId();
        String e1Id = data.get("E1").getId();
        int enterpriseChildrenCount = 3;
        for (int i = 1; i <= enterpriseChildrenCount; i++) {
            Asset child = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), e1TypeId,
                e1Id, "E1_Child_" + i);
            data.put(child.getName(), child);
        }

        AssetPredicate predicate = AssetPredicate.builder().sortByHierarchy(true).parent(
            ParentPredicate.builder().ids(Sets.newHashSet(e1Id)).build()).offset(0).pageSize(250).build();

        List<Collection<String>> accessibleResourcesList = new ArrayList<>();
        accessibleResourcesList.add(TestUtils.getUber());
        accessibleResourcesList.add(Collections.singletonList(e1Id));

        for (Collection<String> accessibleResources : accessibleResourcesList) {
            List<Asset> immediateChildren = assetPersistencyService.getChildAssets(TestUtils.TEST_TENANT,
                accessibleResources, e1Id, predicate);
            // 3 enterprise and 2 site children
            assertThat(immediateChildren).hasSize(enterpriseChildrenCount + siteChildrenCount);
            assertThat(immediateChildren.subList(0, enterpriseChildrenCount)).hasSize(enterpriseChildrenCount)
                .extracting(Asset::getName).containsOnly("E1_Child_1", "E1_Child_2", "E1_Child_3");
            assertThat(immediateChildren.subList(enterpriseChildrenCount, immediateChildren.size())).hasSize(
                siteChildrenCount).extracting(Asset::getName).containsOnly("E1_S1", "E1_S2");
        }

        // deep search
        predicate.getParent().setDeepSearch(true);
        for (Collection<String> accessibleResources : accessibleResourcesList) {
            List<Asset> allChildren = assetPersistencyService.getChildAssets(TestUtils.TEST_TENANT, accessibleResources,
                e1Id, predicate);
            assertThat(allChildren).hasSize(enterpriseChildrenCount + 16);
            assertThat(allChildren.subList(0, enterpriseChildrenCount)).hasSize(enterpriseChildrenCount).extracting(
                Asset::getName).containsOnly("E1_Child_1", "E1_Child_2", "E1_Child_3");
            assertThat(allChildren.subList(enterpriseChildrenCount, enterpriseChildrenCount + siteChildrenCount))
                .hasSize(siteChildrenCount).extracting(Asset::getName).containsOnly("E1_S1", "E1_S2");
            assertThat(allChildren.subList(5, 9)).hasSize(4).extracting(Asset::getName).containsOnly("E1_S1_Seg1",
                "E1_S1_Seg2", "E1_S1_Seg3", "E1_S2_Seg4");
            assertThat(allChildren.subList(9, allChildren.size())).hasSize(10).extracting(Asset::getName).containsOnly(
                "E1_S1_Seg1_A1", "E1_S1_Seg1_B1", "E1_S1_Seg2_A2", "E1_S1_Seg2_B2", "E1_S1_Seg3_A3", "E1_S1_Seg3_B3",
                "E1_S1_Seg3_C3", "E1_S2_Seg4_A4", "E1_S2_Seg4_B4", "E1_S2_Seg4_C4");
        }
    }

    @Test
    @Transactional
    public void childrenOrderByHierarchy_WithCustomPageSize() throws IOException {
        ReflectionTestUtils.setField(ConfigUtils.class, "isOrderByIdDisabled", false);
        Map<String, BaseDataModel> data = setupData();
        // add enterprise children to E1
        String e1TypeId = data.get("E1Type").getId();
        String e1Id = data.get("E1").getId();
        int enterpriseChildrenCount = 4;
        for (int i = 1; i <= enterpriseChildrenCount; i++) {
            Asset child = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), e1TypeId,
                e1Id, "E1_Child_" + i);
            data.put(child.getName(), child);
        }

        AssetPredicate predicate = AssetPredicate.builder().sortByHierarchy(true).parent(
            ParentPredicate.builder().ids(Sets.newHashSet(e1Id)).build()).offset(0).pageSize(250).build();

        // deep search
        predicate.getParent().setDeepSearch(true);
        List<Asset> allChildren = assetPersistencyService.getChildAssets(TestUtils.TEST_TENANT, TestUtils.getUber(),
            e1Id, predicate);
        assertThat(allChildren).hasSize(enterpriseChildrenCount + 16);

        List<String> allChildrenIds = allChildren.stream().map(Asset::getId).collect(Collectors.toList());

        IntStream.range(0, 10).forEach(i-> {
            predicate.setPageSize(2);
            predicate.setOffset(i * 2);
            List<Asset> children = assetPersistencyService.getChildAssets(TestUtils.TEST_TENANT, TestUtils.getUber(),
                e1Id, predicate);
            List<String> childrenIds = children.stream().map(Asset::getId).collect(Collectors.toList());
            allChildrenIds.removeAll(childrenIds);
        });

        assertThat(allChildrenIds).hasSize(0);
    }

    @Test
    @Transactional
    public void childrenOrderByHierarchy_WithCustomPageSize_orderByDisabled() throws IOException {
        ReflectionTestUtils.setField(ConfigUtils.class, "isOrderByIdDisabled", true);
        Map<String, BaseDataModel> data = setupData();
        // add enterprise children to E1
        String e1TypeId = data.get("E1Type").getId();
        String e1Id = data.get("E1").getId();
        int enterpriseChildrenCount = 4;
        for (int i = 1; i <= enterpriseChildrenCount; i++) {
            Asset child = TestUtils.createAssetInstanceAndAssert(assetPersistencyService, TestUtils.getUber(), e1TypeId,
                e1Id, "E1_Child_" + i);
            data.put(child.getName(), child);
        }

        AssetPredicate predicate = AssetPredicate.builder().sortByHierarchy(true).parent(
            ParentPredicate.builder().ids(Sets.newHashSet(e1Id)).build()).offset(0).pageSize(250).build();

        // deep search
        predicate.getParent().setDeepSearch(true);
        List<Asset> allChildren = assetPersistencyService.getChildAssets(TestUtils.TEST_TENANT, TestUtils.getUber(),
            e1Id, predicate);
        assertThat(allChildren).hasSize(enterpriseChildrenCount + 16);

        List<String> allChildrenIds = allChildren.stream().map(Asset::getId).collect(Collectors.toList());

        IntStream.range(0, 10).forEach(i-> {
            predicate.setPageSize(2);
            predicate.setOffset(i * 2);
            List<Asset> children = assetPersistencyService.getChildAssets(TestUtils.TEST_TENANT, TestUtils.getUber(),
                e1Id, predicate);
            List<String> childrenIds = children.stream().map(Asset::getId).collect(Collectors.toList());
            allChildrenIds.removeAll(childrenIds);
        });

        assertThat(allChildrenIds).isNotEmpty();
        ReflectionTestUtils.setField(ConfigUtils.class, "isOrderByIdDisabled", false);
    }

    @Test
    @Transactional
    public void testFindAssets_PagingWithSortKey() throws IOException {
        setupData();

        AssetPredicate predicate = AssetPredicate.builder().type(
            TypePredicate.builder().ids(Collections.singleton(ROOT_ASSET_TYPE_ID)).deepSearch(true).build())
            .attributeSelectEnum(AttributeSelectEnum.FULL).pageSize(250).build();

        List<Asset> allAssets = assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(),
            predicate);

        int pageSize = 3;
        predicate.setPagingInfo(0, pageSize, null, true);
        List<Asset> found = assetPersistencyService.getAssets(TestUtils.TEST_TENANT, null, predicate);
        assertThat(found).hasSize(pageSize);
        assertThat(found.stream().map(Asset::getId).collect(Collectors.toList()))
            .containsExactlyElementsOf(allAssets
            .subList(0, pageSize).stream()
            .map(Asset::getId).collect(Collectors.toList()));

        String sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        assertThat(sortKey).isNotEmpty();

        predicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        int offset = pageSize;
        int roundCount = (allAssets.size() / pageSize) * pageSize;
        while (offset < roundCount) {
            predicate.setPagingInfo(2, pageSize, sortKey, true);
            found = assetPersistencyService.getAssets(TestUtils.TEST_TENANT, null, predicate);
            assertThat(found).hasSize(pageSize);
            assertThat(found.stream().map(Asset::getId).collect(Collectors.toList()))
                .containsExactlyElementsOf(allAssets
                    .subList(offset, offset + pageSize).stream()
                    .map(Asset::getId).collect(Collectors.toList()));
            offset += pageSize;
            sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        }
    }

    Map<String, BaseDataModel> setupData() throws IOException {
        return PredicateUtils.setupDataForSearchByPredicates(assetTypePersistencyService, assetPersistencyService);
    }
}
