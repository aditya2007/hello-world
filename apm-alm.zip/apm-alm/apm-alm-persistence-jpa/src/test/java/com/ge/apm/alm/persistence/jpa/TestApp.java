/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa;

import java.util.Collections;
import javax.annotation.PostConstruct;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.EclipseLinkJpaVendorAdapter;

import com.ge.apm.alm.utils.AlmRequestContext;
import com.ge.apm.alm.utils.AlmRequestContext.AlmRequestContextEnum;

/**
 * Created by hsiang-aiyu on 3/9/17.
 */
@SpringBootApplication
@PropertySource("classpath:application-test-${env:local}.properties")
@ComponentScan({ "com.ge.apm.alm.persistence" })
public class TestApp {

    @Value("${jpa.persistence.unit.name}")
    private String persistenceUnitName;

    @PostConstruct
    public void setUpRequestContext() {
        AlmRequestContext.put(AlmRequestContextEnum.ALM_ASSET_USER_POLICIES_ENABLED, true);
    }

    @Bean
    LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource) {
        LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactoryBean.setJpaVendorAdapter(new EclipseLinkJpaVendorAdapter());
        entityManagerFactoryBean.setDataSource(dataSource);
        entityManagerFactoryBean.setPersistenceUnitName(persistenceUnitName);
        return entityManagerFactoryBean;
    }

    @Bean
    JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }

    @Bean
    Flyway flyway(DataSource dataSource) {
        Flyway flyway = new Flyway();
        flyway.setBaselineOnMigrate(false);
        flyway.setSchemas("apm_alm");
        flyway.setPlaceholders(Collections.singletonMap("json-data-type", "json"));
        flyway.setDataSource(dataSource);
        flyway.migrate();
        return flyway;
    }
}
