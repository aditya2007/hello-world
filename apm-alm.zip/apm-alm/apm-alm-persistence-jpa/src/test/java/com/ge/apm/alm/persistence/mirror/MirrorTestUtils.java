/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.mirror;

import java.lang.annotation.Annotation;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.BaseDataModel;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;
import com.ge.apm.alm.persistence.jpa.SpringApplicationContext;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public final class MirrorTestUtils {

    private MirrorTestUtils() {
    }

    public static String randomUUID() {
        return UUID.randomUUID().toString();
    }

    public static Mirror createMirror(Type persistType, Class<? extends BaseDataModel> clazz) {
        return new Mirror() {
            @Override
            public Class<? extends Annotation> annotationType() {
                return Mirror.class;
            }

            @Override
            public Type[] type() {
                return (persistType == null) ?
                    new Type[]{} :
                    new Type[]{persistType};
            }

            @Override
            public Class<? extends BaseDataModel>[] clazz() {
                return (clazz == null) ?
                    new Class[]{} :
                    new Class[]{clazz};
            }
        };
    }

    public static Accessible createAccessible() {
        return new Accessible() {
            @Override
            public Class<? extends Annotation> annotationType() {
                return Accessible.class;
            }
        };
    }

    public static Asset createAsset(String id, OOTBCoreTypesIdLookup rootType, OffsetDateTime lastModified) {
        Asset asset = createAsset(rootType);
        when(asset.getId()).thenReturn(id);
        when(asset.getLastModifiedDate()).thenReturn(lastModified);
        return asset;
    }

    private static Asset createAsset(OOTBCoreTypesIdLookup rootType) {
        Asset asset = mock(Asset.class);
        when(asset.getSuperTypesArray()).thenReturn(Collections.singletonList(rootType.getId()));
        when(asset.getSuperTypesArray()).thenReturn(createSuperTypesArray(rootType));
        when(asset.getCoreAssetTypeName()).thenCallRealMethod();
        return asset;
    }

    public static AssetType createAssetType(OOTBCoreTypesIdLookup rootType) {
        AssetType assetType = mock(AssetType.class);
        String uuid = UUID.randomUUID().toString();
        when(assetType.getId()).thenReturn(uuid);
        when(assetType.getSuperTypesArray()).thenReturn(Collections.singletonList(rootType.getId()));
        when(assetType.getSuperTypesArray()).thenReturn(createSuperTypesArray(rootType));
        when(assetType.getCoreAssetTypeName()).thenCallRealMethod();
        return assetType;
    }

    public static AssetGroup createGroup(AssetGroupCategory category) {
        AssetGroup group = mock(AssetGroup.class);
        when(group.getCategory()).thenReturn(category);
        return group;
    }

    public static Tag createTag(String id, String assetId) {
        Tag tag = mock(Tag.class);
        when(tag.getId()).thenReturn(id);
        return tag;
    }

    private static JsonNode createSuperTypesNode(OOTBCoreTypesIdLookup rootType) {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode node = mapper.createObjectNode();
        ArrayNode superTypes = node.putArray("ids");
        superTypes.add(rootType.getId());
        superTypes.add(UUID.randomUUID().toString());
        superTypes.add(UUID.randomUUID().toString());
        return node;
    }

    private static List<String> createSuperTypesArray(OOTBCoreTypesIdLookup rootType) {
        List<String> superTypesArray = new ArrayList<>();
        superTypesArray.add(rootType.getId());
        return superTypesArray;
    }

    public static void setEventCreationEnabled(boolean enabled) {
        SpringApplicationContext.getBeanByClass(MirrorAspect.class).setEnabled(enabled);
    }

}
