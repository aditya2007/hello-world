/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.persistency.template;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Notes;
import com.ge.apm.alm.model.query.NotesPredicate;
import com.ge.apm.alm.persistence.NotesPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.model.TestNotes;
import com.ge.apm.alm.persistence.jpa.sql.QueryUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestTemplateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */
@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class NotesPersistSvcTests {

    @Autowired
    private NotesPersistencyService persistencyService;

    @Test
    @Transactional
    public void testCreateNote() throws PersistencyServiceException {
        TestNotes notesEntity = TestTemplateUtils.buildNotes(TestUtils.TEST_TENANT, "test create notes");
        persistencyService.createNote(TestUtils.TEST_TENANT, notesEntity);

        Notes dbNotes = persistencyService.getNoteById(TestUtils.TEST_TENANT, notesEntity.getId());
        assertThat(dbNotes).isNotNull();
        assertThat(dbNotes.getId()).isEqualTo(notesEntity.getId());
        assertThat(dbNotes.getContent()).isEqualTo(notesEntity.getContent());

        deleteTestNotesById(notesEntity.getId());
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreateNote_requiredFields() {
        TestNotes notesEntity = TestTemplateUtils.buildNotes(TestUtils.TEST_TENANT, "test create notes");
        notesEntity.setContent(null);
        persistencyService.createNote(TestUtils.TEST_TENANT, notesEntity);
    }

    @Test
    @Transactional
    public void testCreateNotes() throws PersistencyServiceException {
        List<Notes> notesEntities = new ArrayList<>();
        int counter = persistencyService.createNotes(TestUtils.TEST_TENANT, notesEntities);
        assertThat(counter).isEqualTo(0);

        notesEntities.add(TestTemplateUtils.buildNotes(TestUtils.TEST_TENANT, "test create notes1"));
        notesEntities.add(TestTemplateUtils.buildNotes(TestUtils.TEST_TENANT, "test create notes2"));

        counter = persistencyService.createNotes(TestUtils.TEST_TENANT, notesEntities);
        assertThat(counter).isEqualTo(2);

        Notes dbNotes1 = persistencyService.getNoteById(TestUtils.TEST_TENANT, notesEntities.get(0).getId());
        assertThat(dbNotes1).isNotNull();
        assertThat(dbNotes1.getId()).isEqualTo(notesEntities.get(0).getId());
        assertThat(dbNotes1.getContent()).isEqualTo(notesEntities.get(0).getContent());

        Notes dbNotes2 = persistencyService.getNoteById(TestUtils.TEST_TENANT, notesEntities.get(1).getId());
        assertThat(dbNotes2).isNotNull();
        assertThat(dbNotes2.getId()).isEqualTo(notesEntities.get(1).getId());
        assertThat(dbNotes2.getContent()).isEqualTo(notesEntities.get(1).getContent());

        for (Notes notes : notesEntities) {
            deleteTestNotesById(notes.getId());
        }
    }

    @Test
    @Transactional
    public void testUpdateNote() throws PersistencyServiceException {
        TestNotes notes = TestTemplateUtils.buildNotes(TestUtils.TEST_TENANT, "test create notes");
        persistencyService.createNote(TestUtils.TEST_TENANT, notes);

        Notes dbNotes = persistencyService.getNoteById(TestUtils.TEST_TENANT, notes.getId());
        assertThat(dbNotes).isNotNull();
        assertThat(dbNotes.getId()).isEqualTo(notes.getId());
        assertThat(dbNotes.getContent()).isEqualTo(notes.getContent());

        String updatedContent = "update test content";
        notes.setContent(updatedContent);
        persistencyService.updateNote(TestUtils.TEST_TENANT, notes);

        dbNotes = persistencyService.getNoteById(TestUtils.TEST_TENANT, notes.getId());
        assertThat(dbNotes).isNotNull();
        assertThat(dbNotes.getId()).isEqualTo(notes.getId());
        assertThat(dbNotes.getContent()).isEqualTo(updatedContent);
    }

    @Test
    @Transactional
    public void testDeleteNote() throws PersistencyServiceException {
        testCreateNote();
    }

    @Test
    @Transactional
    public void testGetNoteById() throws PersistencyServiceException {
        testCreateNote();
    }

    @Test
    @Transactional
    public void testGetNotes() throws PersistencyServiceException {
        List<Notes> notesEntities = Arrays.asList(
            TestTemplateUtils.buildNotes(TestUtils.TEST_TENANT, "test get notes1"),
            TestTemplateUtils.buildNotes(TestUtils.TEST_TENANT, "test get notes2"));
        int counter = persistencyService.createNotes(TestUtils.TEST_TENANT, notesEntities);
        assertThat(counter).isEqualTo(2);

        NotesPredicate predicate = new NotesPredicate();
        predicate.setContent(notesEntities.get(0).getContent());
        List<Notes> foundNotes = persistencyService.getNotes(TestUtils.TEST_TENANT, predicate);
        assertThat(foundNotes).isNotNull();
        assertThat(foundNotes.size()).isEqualTo(1);
        assertThat(foundNotes.get(0).getId()).isEqualTo(notesEntities.get(0).getId());

        predicate.setContent("*" + notesEntities.get(1).getContent());
        foundNotes = persistencyService.getNotes(TestUtils.TEST_TENANT, predicate);
        assertThat(foundNotes).isNotNull();
        assertThat(foundNotes.size()).isEqualTo(1);
        assertThat(foundNotes.get(0).getId()).isEqualTo(notesEntities.get(1).getId());

        for (Notes notes : notesEntities) {
            deleteTestNotesById(notes.getId());
        }
    }

    @Test
    @Transactional
    public void testGetNotes_PagingWithSortKey() {
        int pageSize = 2;
        int numPages = 3;
        for (int i=0; i<pageSize * numPages; i++) {
            persistencyService.createNotes(TestUtils.TEST_TENANT, Collections.singletonList(
                TestTemplateUtils.buildNotes(TestUtils.TEST_TENANT,"notes-" + i)));
        }

        NotesPredicate predicate = new NotesPredicate();
        predicate.setPageSize(pageSize * numPages + 1);
        List<Notes> allNotes = persistencyService.getNotes(TestUtils.TEST_TENANT, predicate);
        assertThat(allNotes).hasSize(pageSize * numPages);

        predicate.setPagingInfo(0, pageSize, null, true);
        List<Notes> found = persistencyService.getNotes(TestUtils.TEST_TENANT, predicate);
        assertThat(found).hasSize(pageSize);
        assertThat(found.stream().map(Notes::getId).collect(Collectors.toList()))
            .containsExactlyElementsOf(allNotes.subList(0, pageSize).stream()
                .map(Notes::getId).collect(Collectors.toList()));

        String sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        assertThat(sortKey).isNotEmpty();

        predicate.setAttributeSelectEnum(AttributeSelectEnum.FULL);
        int offset = pageSize;
        while (offset < pageSize * numPages) {
            predicate.setPagingInfo(1, pageSize, sortKey, true);
            found = persistencyService.getNotes(TestUtils.TEST_TENANT, predicate);
            assertThat(found).hasSize(pageSize);
            assertThat(found.stream().map(Notes::getId).collect(Collectors.toList()))
                .containsExactlyElementsOf(allNotes.subList(offset, offset + pageSize).stream()
                    .map(Notes::getId).collect(Collectors.toList()));
            offset += pageSize;
            sortKey = QueryUtils.getNextPageSortKey(predicate, found.get(pageSize - 1));
        }

        predicate.setPagingInfo(1, pageSize, sortKey, true);
        assertThat(persistencyService.getNotes(TestUtils.TEST_TENANT, predicate)).isEmpty();
    }

    private void deleteTestNotesById(String id) throws PersistencyServiceException {
        persistencyService.deleteNote(TestUtils.TEST_TENANT, id);
        assertThat(persistencyService.getNoteById(TestUtils.TEST_TENANT, id)).isNull();
    }
}
