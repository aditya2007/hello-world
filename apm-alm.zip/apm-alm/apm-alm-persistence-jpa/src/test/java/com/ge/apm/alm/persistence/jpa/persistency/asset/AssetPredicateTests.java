/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.asset;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;

import com.google.common.collect.Sets;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.Sourceable;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.query.ParentPredicate;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.utils.PredicateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID;
import static org.assertj.core.api.Assertions.assertThat;

//import org.springframework.boot.test.SpringApplicationConfiguration;

/**
 * Tests asset queries using {@link com.ge.apm.alm.model.query.AssetPredicate}, using
 * {@link com.ge.apm.alm.model.query.TypePredicate} and
 * {@link com.ge.apm.alm.model.query.ParentPredicate} either separately or in combination.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetPredicateTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;
    @Autowired
    private AssetPersistencyService assetPersistencyService;

    // TypePredicate tests
    @Test
    @Transactional
    public void getAssets_withTypePredicate_fromRootEnterpriseType() throws IOException {
        setupDataForQuryByPredicates();

        AssetPredicate predicate = AssetPredicate.builder()
            .type(TypePredicate.builder()
                .parent(ParentPredicate.builder().ids(Sets.newHashSet(ROOT_ENTERPRISE_TYPE_ID)).build())
                .build()).build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly("E1");
        predicate.getType().getParent().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly("E1");
        predicate.setName("E1");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(Asset::getName).containsOnly("E1");
        predicate.setName("E1-not-exist");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_typePredicate_typeParentIds() throws IOException {
        Map<String, Sourceable> data = setupDataForQuryByPredicates();

        AssetPredicate predicate = AssetPredicate.builder()
            .type(TypePredicate.builder()
                .parent(ParentPredicate.builder().ids(Sets.newHashSet(data.get("Asset1Type").getId())).build())
                .build()).build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(4)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2",
            "E1_S2_Seg3_Asset3_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3",
            "E1_S2_Seg3_Asset4_Asset1TypeSubType3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Collections.singletonList(data.get("E1").getId()), predicate)).hasSize(4)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2",
            "E1_S2_Seg3_Asset3_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3",
            "E1_S2_Seg3_Asset4_Asset1TypeSubType3");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);

        predicate.getType().getParent().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(4)
            .extracting(Asset::getName)
            .containsOnly("E1_S2_Seg3_Asset3_Asset1TypeSubType2", "E1_S2_Seg3_Asset4_Asset1TypeSubType3",
                "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Collections.singletonList(data.get("E1").getId()), predicate)).hasSize(4)
            .extracting(Asset::getName).containsOnly("E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2",
            "E1_S2_Seg3_Asset3_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3",
            "E1_S2_Seg3_Asset4_Asset1TypeSubType3");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_withTypePredicate_equals() throws IOException {
        Map<String, Sourceable> data = setupDataForQuryByPredicates();

        AssetPredicate predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().name("Asset1Type").build())
            .build();
        verifyTypePredicate_equalsQueriesAndDeepSearch(data, predicate);

        predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().description("Asset1Type").build())
            .build();
        verifyTypePredicate_equalsQueriesAndDeepSearch(data, predicate);

        predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().sourceKey("Asset1Type").build())
            .build();
        verifyTypePredicate_equalsQueriesAndDeepSearch(data, predicate);

        // verify search is case-insensitive
        predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().name("Asset1Type".toUpperCase(Locale.getDefault())).build())
            .build();
        verifyTypePredicate_equalsQueriesAndDeepSearch(data, predicate);

        predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().description("Asset1Type".toUpperCase(Locale.getDefault())).build())
            .build();
        verifyTypePredicate_equalsQueriesAndDeepSearch(data, predicate);

        predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().sourceKey("Asset1Type".toUpperCase(Locale.getDefault())).build())
            .build();
        verifyTypePredicate_equalsQueriesAndDeepSearch(data, predicate);

        // check name only
        predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().name("does-not-exist").deepSearch(true).build())
            .build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(0);
    }

    private void verifyTypePredicate_equalsQueriesAndDeepSearch(Map<String, Sourceable> data,
        AssetPredicate predicate) {
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(2)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type");
        assertThat(assetPersistencyService
            .getAssets(TestUtils.TEST_TENANT, Collections.singletonList(data.get("E1").getId()), predicate)).hasSize(2)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);

        predicate.getType().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(6)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S2_Seg3_Asset3_Asset1TypeSubType2", "E1_S2_Seg3_Asset4_Asset1TypeSubType3",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(6)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S2_Seg3_Asset3_Asset1TypeSubType2", "E1_S2_Seg3_Asset4_Asset1TypeSubType3",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_withTypePredicate_likes() throws IOException {
        Map<String, Sourceable> data = setupDataForQuryByPredicates();

        AssetPredicate predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().name("Asset1Type*".toLowerCase(Locale.getDefault())).build())
            .build();
        verifyTypePredicate_likeQueriesAndDeepSearch(data, predicate);

        predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().description("Asset1Type*").build())
            .build();
        verifyTypePredicate_likeQueriesAndDeepSearch(data, predicate);

        predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().sourceKey("Asset1Type*".toUpperCase(Locale.getDefault())).build())
            .build();
        verifyTypePredicate_likeQueriesAndDeepSearch(data, predicate);

        // check name only
        predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().name("*does-not-exist*").deepSearch(true).build())
            .build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(0);
    }

    private void verifyTypePredicate_likeQueriesAndDeepSearch(Map<String, Sourceable> data,
        AssetPredicate predicate) {
        // because of like criteria and the type naming convention, there is no difference between deep search off or on
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(6)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S2_Seg3_Asset3_Asset1TypeSubType2", "E1_S2_Seg3_Asset4_Asset1TypeSubType3",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(6)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S2_Seg3_Asset3_Asset1TypeSubType2", "E1_S2_Seg3_Asset4_Asset1TypeSubType3",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);

        predicate.getType().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(6)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S2_Seg3_Asset3_Asset1TypeSubType2", "E1_S2_Seg3_Asset4_Asset1TypeSubType3",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(6)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S2_Seg3_Asset3_Asset1TypeSubType2", "E1_S2_Seg3_Asset4_Asset1TypeSubType3",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    // ParentPredicate tests
    @Test
    @Transactional
    public void getAssets_withParentPredicate_assetId() throws IOException {
        Map<String, Sourceable> data = setupDataForQuryByPredicates();

        AssetPredicate predicate = AssetPredicate.builder()
            .parent(ParentPredicate.builder().ids(Sets.newHashSet(data.get("E1_S1_Seg1").getId())).build())
            .build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type");

        predicate.getParent().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(3)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
    }

    @Test
    @Transactional
    public void getAssets_withParentPredicate_equals() throws IOException {
        Map<String, Sourceable> data = setupDataForQuryByPredicates();

        AssetPredicate predicate = AssetPredicate.builder()
            .parent(ParentPredicate.builder().name("E1_S1_Seg1").build())
            .build();
        verifyParentPredicate_equalsQueriesAndDeepSearch(data, predicate);

        predicate = AssetPredicate.builder()
            .parent(ParentPredicate.builder().description("E1_S1_Seg1").build())
            .build();
        verifyParentPredicate_equalsQueriesAndDeepSearch(data, predicate);

        predicate = AssetPredicate.builder()
            .parent(ParentPredicate.builder().sourceKey("E1_S1_Seg1").build())
            .build();
        verifyParentPredicate_equalsQueriesAndDeepSearch(data, predicate);

        // check name only
        predicate = AssetPredicate.builder()
            .parent(ParentPredicate.builder().name("does-not-exist").deepSearch(true).build())
            .build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(0);
    }

    private void verifyParentPredicate_equalsQueriesAndDeepSearch(Map<String, Sourceable> data,
        AssetPredicate predicate) {
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(1)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);

        predicate.getParent().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(3)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(3)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getAssets_withParentPredicate_likes() throws IOException {
        Map<String, Sourceable> data = setupDataForQuryByPredicates();

        AssetPredicate predicate = AssetPredicate.builder()
            .parent(ParentPredicate.builder().name("E1_S1_Seg*").build())
            .build();
        verifyParentPredicate_likeQueriesAndDeepSearch(data, predicate);

        predicate = AssetPredicate.builder()
            .parent(ParentPredicate.builder().description("E1_S1_Seg*").build())
            .build();
        verifyParentPredicate_likeQueriesAndDeepSearch(data, predicate);

        predicate = AssetPredicate.builder()
            .parent(ParentPredicate.builder().sourceKey("E1_S1_Seg*").build())
            .build();
        verifyParentPredicate_likeQueriesAndDeepSearch(data, predicate);

        // check name only
        predicate = AssetPredicate.builder()
            .parent(ParentPredicate.builder().name("*does-not-exist*").deepSearch(true).build())
            .build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(0);
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(0);
    }

    private void verifyParentPredicate_likeQueriesAndDeepSearch(Map<String, Sourceable> data,
        AssetPredicate predicate) {
        // because of like criteria and the type naming convention, there is no difference between deep search off or on
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(6)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3",
            "E1_S1_Seg2_Asset2_Asset7_Asset2Type", "E1_S1_Seg2_Asset2_Asset8_Asset2Type");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(6)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3",
            "E1_S1_Seg2_Asset2_Asset7_Asset2Type", "E1_S1_Seg2_Asset2_Asset8_Asset2Type");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);

        predicate.getParent().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(6)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3",
            "E1_S1_Seg2_Asset2_Asset7_Asset2Type", "E1_S1_Seg2_Asset2_Asset8_Asset2Type");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(6)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3",
            "E1_S1_Seg2_Asset2_Asset7_Asset2Type", "E1_S1_Seg2_Asset2_Asset8_Asset2Type");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    // combinations of type and parent predicates

    /**
     * Get all assets of type Asset1Type whose parent is Seg1, with or without deep search.
     */
    @Test
    @Transactional
    public void getAssets_comboQuery_1() throws IOException {
        Map<String, Sourceable> data = setupDataForQuryByPredicates();

        AssetPredicate predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().name("Asset1Type").build())
            .parent(ParentPredicate.builder().name("E1_S1_Seg1").build())
            .build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(1)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(1)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);

        predicate.getType().setDeepSearch(true);
        predicate.getParent().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(3)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(3)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    /**
     * Get all assets whose type name is like "Asset1Type*" and parent name is like "E1_S1_*"; with or without deep
     * search.
     */
    @Test
    @Transactional
    public void getAssets_comboQuery_2() throws IOException {
        Map<String, Sourceable> data = setupDataForQuryByPredicates();
        // no deep search
        AssetPredicate predicate = AssetPredicate.builder()
            .type(TypePredicate.builder().name("Asset1Type*").build())
            .parent(ParentPredicate.builder().name("E1_S1_*").build())
            .build();
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(4)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(4)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);

        // with deep search in ParentPredicate
        predicate.getParent().setDeepSearch(true);
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), predicate)).hasSize(4)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(
            assetPersistencyService.getAssets(TestUtils.TEST_TENANT, Arrays.asList(data.get("E1").getId()), predicate))
            .hasSize(4)
            .extracting(a -> a.getName()).containsOnly("E1_S1_Seg1_Asset1_Asset1Type", "E1_S1_Seg2_Asset2_Asset1Type",
            "E1_S1_Seg1_Asset1_Asset5_Asset1TypeSubType2", "E1_S1_Seg1_Asset1_Asset6_Asset1TypeSubType3");
        assertThat(assetPersistencyService.getAssets(TestUtils.TEST_TENANT, TestUtils.getUnPrivileged(), predicate))
            .hasSize(0);
    }

    private Map<String, Sourceable> setupDataForQuryByPredicates() throws IOException {
        return PredicateUtils.setupDataForQuryByPredicates(assetTypePersistencyService, assetPersistencyService);
    }
}
