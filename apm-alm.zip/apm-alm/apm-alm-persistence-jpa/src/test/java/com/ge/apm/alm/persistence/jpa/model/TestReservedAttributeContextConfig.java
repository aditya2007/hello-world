package com.ge.apm.alm.persistence.jpa.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.ReservedAttributeContextConfig;
import com.ge.apm.alm.persistence.jpa.entity.ContextEntity;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString(callSuper = true)
public class TestReservedAttributeContextConfig implements ReservedAttributeContextConfig {

    private String tenantId;
    private String code;
    private String semanticName;
    private String displayName;
    private String description;
    private Boolean isActive;
    private Boolean isDefault;
    private ContextEntity context;

}
