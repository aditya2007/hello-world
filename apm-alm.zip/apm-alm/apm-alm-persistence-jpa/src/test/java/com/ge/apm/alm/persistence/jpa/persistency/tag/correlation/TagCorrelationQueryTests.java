/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.tag.correlation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.model.TestAssetGroup;
import com.ge.apm.alm.persistence.jpa.utils.TagPredicateUtils;

import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.TEST_TENANT;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUber;
import static com.ge.apm.alm.persistence.jpa.utils.TestUtils.getUnPrivileged;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests the JPA Persistency Layer
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class TagCorrelationQueryTests extends TagCorrelationBaseTest {

    @Test
    @Transactional
    public void getCorrelationsForTags_withACL() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 6;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        // create the first group with 2 tags
        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString()).category(
            AssetGroupCategory.TAG_CORRELATION).build();
        groupPersistencyService.createAssetGroup(TEST_TENANT, group);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        groupPersistencyService.createAssetGroupItems(TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")),
            group.getId(), items);

        // create the 2nd group with 4 tags
        AssetGroup group2 = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString()).category(
            AssetGroupCategory.TAG_CORRELATION).build();
        groupPersistencyService.createAssetGroup(TEST_TENANT, group2);

        List<AssetGroupItem> items2 = new ArrayList<>();
        for (int i = 2; i < count; i++) {
            items2.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group2.getId(), i - 1));
        }
        groupPersistencyService.createAssetGroupItems(TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")),
            group2.getId(), items2);

        Set<String> tagIds = new HashSet<>();
        for (AssetGroupItem item : items) {
            tagIds.add(item.getObjectId());
        }
        Map<String, AssetGroup> rslt = groupPersistencyService.getCorrelationsForTags(TEST_TENANT,
            getUnPrivileged(assets.get("E1_S1_Seg1")), tagIds);
        assertThat(rslt).hasSize(items.size());
        assertThat(rslt.keySet()).containsOnly(items.get(0).getObjectId(), items.get(1).getObjectId());
        assertThat(rslt.values()).extracting(AssetGroup::getId).containsOnly(group.getId(), group.getId());

        tagIds.clear();
        for (AssetGroupItem item : items2) {
            tagIds.add(item.getObjectId());
        }
        rslt = groupPersistencyService.getCorrelationsForTags(TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")),
            tagIds);
        assertThat(rslt).hasSize(items2.size());
        assertThat(rslt.keySet()).containsOnly(items2.get(0).getObjectId(), items2.get(1).getObjectId(),
            items2.get(2).getObjectId(), items2.get(3).getObjectId());
        assertThat(rslt.values()).extracting(AssetGroup::getId).containsOnly(group2.getId(), group2.getId(),
            group2.getId(), group2.getId());

        tagIds.clear();
        tagIds.add(items.get(0).getObjectId());
        tagIds.add(items2.get(0).getObjectId());
        rslt = groupPersistencyService.getCorrelationsForTags(TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")),
            tagIds);
        assertThat(rslt).hasSize(2);
        assertThat(rslt.keySet()).containsOnly(items.get(0).getObjectId(), items2.get(0).getObjectId());
        assertThat(rslt.values()).extracting(AssetGroup::getId).containsOnly(group.getId(), group2.getId());

        tagIds.clear();
        tagIds.add(items.get(0).getId());
        assertThat(groupPersistencyService.getCorrelationsForTags(TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")),
            tagIds)).hasSize(0);
    }

    @Test
    @Transactional
    public void getCorrelationsForTags_asUber() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 6;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        // create the first group with 2 tags
        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString()).category(
            AssetGroupCategory.TAG_CORRELATION).build();
        groupPersistencyService.createAssetGroup(TEST_TENANT, group);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        groupPersistencyService.createAssetGroupItems(TEST_TENANT, getUber(), group.getId(), items);

        // create the 2nd group with 4 tags
        AssetGroup group2 = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString()).category(
            AssetGroupCategory.TAG_CORRELATION).build();
        groupPersistencyService.createAssetGroup(TEST_TENANT, group2);

        List<AssetGroupItem> items2 = new ArrayList<>();
        for (int i = 2; i < count; i++) {
            items2.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group2.getId(), i - 1));
        }
        groupPersistencyService.createAssetGroupItems(TEST_TENANT, getUber(), group2.getId(), items2);

        Set<String> tagIds = new HashSet<>();
        for (AssetGroupItem item : items) {
            tagIds.add(item.getObjectId());
        }
        Map<String, AssetGroup> rslt = groupPersistencyService.getCorrelationsForTags(TEST_TENANT, getUber(), tagIds);
        assertThat(rslt).hasSize(items.size());
        assertThat(rslt.keySet()).containsOnly(items.get(0).getObjectId(), items.get(1).getObjectId());
        assertThat(rslt.values()).extracting(AssetGroup::getId).containsOnly(group.getId(), group.getId());

        tagIds.clear();
        for (AssetGroupItem item : items2) {
            tagIds.add(item.getObjectId());
        }
        rslt = groupPersistencyService.getCorrelationsForTags(TEST_TENANT, getUber(), tagIds);
        assertThat(rslt).hasSize(items2.size());
        assertThat(rslt.keySet()).containsOnly(items2.get(0).getObjectId(), items2.get(1).getObjectId(),
            items2.get(2).getObjectId(), items2.get(3).getObjectId());
        assertThat(rslt.values()).extracting(AssetGroup::getId).containsOnly(group2.getId(), group2.getId(),
            group2.getId(), group2.getId());

        tagIds.clear();
        tagIds.add(items.get(0).getObjectId());
        tagIds.add(items2.get(0).getObjectId());
        rslt = groupPersistencyService.getCorrelationsForTags(TEST_TENANT, getUber(), tagIds);
        assertThat(rslt).hasSize(2);
        assertThat(rslt.keySet()).containsOnly(items.get(0).getObjectId(), items2.get(0).getObjectId());
        assertThat(rslt.values()).extracting(AssetGroup::getId).containsOnly(group.getId(), group2.getId());

        tagIds.clear();
        tagIds.add(items.get(0).getId());
        assertThat(groupPersistencyService.getCorrelationsForTags(TEST_TENANT, getUber(), tagIds)).hasSize(0);
    }

    @Test
    @Transactional
    public void getCorrelationsForTags_asNullUuid() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 6;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        // create the first group with 2 tags
        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString()).category(
            AssetGroupCategory.TAG_CORRELATION).build();
        groupPersistencyService.createAssetGroup(TEST_TENANT, group);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        groupPersistencyService.createAssetGroupItems(TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")),
            group.getId(), items);

        // create the 2nd group with 4 tags
        AssetGroup group2 = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString()).category(
            AssetGroupCategory.TAG_CORRELATION).build();
        groupPersistencyService.createAssetGroup(TEST_TENANT, group2);

        List<AssetGroupItem> items2 = new ArrayList<>();
        for (int i = 2; i < count; i++) {
            items2.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group2.getId(), i - 1));
        }
        groupPersistencyService.createAssetGroupItems(TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")),
            group2.getId(), items2);

        Set<String> tagIds = new HashSet<>();
        for (AssetGroupItem item : items) {
            tagIds.add(item.getObjectId());
        }
        assertThat(groupPersistencyService.getCorrelationsForTags(TEST_TENANT, getUnPrivileged(), tagIds))
            .hasSize(0);

        tagIds.clear();
        for (AssetGroupItem item : items2) {
            tagIds.add(item.getObjectId());
        }
        assertThat(groupPersistencyService.getCorrelationsForTags(TEST_TENANT, getUnPrivileged(), tagIds))
            .hasSize(0);

        tagIds.clear();
        tagIds.add(items.get(0).getObjectId());
        tagIds.add(items2.get(0).getObjectId());
        assertThat(groupPersistencyService.getCorrelationsForTags(TEST_TENANT, getUnPrivileged(), tagIds))
            .hasSize(0);
    }

    @Test
    @Transactional
    public void getCorrelatedTags_withACL() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 6;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        // create the first group with 2 tags
        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString()).category(
            AssetGroupCategory.TAG_CORRELATION).build();
        groupPersistencyService.createAssetGroup(TEST_TENANT, group);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        groupPersistencyService.createAssetGroupItems(TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")),
            group.getId(), items);

        // create the 2nd group with 4 tags
        AssetGroup group2 = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString()).category(
            AssetGroupCategory.TAG_CORRELATION).build();
        groupPersistencyService.createAssetGroup(TEST_TENANT, group2);

        List<AssetGroupItem> items2 = new ArrayList<>();
        for (int i = 2; i < count; i++) {
            items2.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group2.getId(), i - 1));
        }
        groupPersistencyService.createAssetGroupItems(TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")),
            group2.getId(), items2);

        Set<String> tagIds = new HashSet<>();
        for (AssetGroupItem item : items) {
            tagIds.add(item.getObjectId());
        }
        Map<String, List<AssetGroupItem>> rslt = groupPersistencyService.getCorrelatedTags(TEST_TENANT,
            getUnPrivileged(assets.get("E1_S1_Seg1")), tagIds);
        assertThat(rslt).hasSize(items.size());
        assertThat(rslt.keySet()).containsOnly(items.get(0).getObjectId(), items.get(1).getObjectId());
        for (Map.Entry<String, List<AssetGroupItem>> e : rslt.entrySet()) {
            List<AssetGroupItem> value = e.getValue();
            assertThat(value).hasSize(items.size()).extracting(AssetGroupItem::getGroupId).containsOnly(group.getId(),
                group.getId());
            assertThat(value).extracting(AssetGroupItem::getObjectId).containsOnly(items.get(0).getObjectId(),
                items.get(1).getObjectId());
            assertThat(value).extracting(AssetGroupItem::getPosition).containsExactly(1, 2);
        }

        tagIds.clear();
        for (AssetGroupItem item : items2) {
            tagIds.add(item.getObjectId());
        }
        rslt = groupPersistencyService.getCorrelatedTags(TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")), tagIds);
        assertThat(rslt).hasSize(items2.size());
        assertThat(rslt.keySet()).containsOnly(items2.get(0).getObjectId(), items2.get(1).getObjectId(),
            items2.get(2).getObjectId(), items2.get(3).getObjectId());
        for (Map.Entry<String, List<AssetGroupItem>> e : rslt.entrySet()) {
            List<AssetGroupItem> value = e.getValue();
            assertThat(value).hasSize(items2.size()).extracting(AssetGroupItem::getGroupId).containsOnly(group2.getId(),
                group2.getId(), group2.getId(), group2.getId());
            assertThat(value).extracting(AssetGroupItem::getObjectId).containsOnly(items2.get(0).getObjectId(),
                items2.get(1).getObjectId(), items2.get(2).getObjectId(), items2.get(3).getObjectId());
            assertThat(value).extracting(AssetGroupItem::getPosition).containsExactly(1, 2, 3, 4);
        }
        tagIds.clear();
        tagIds.add(items.get(0).getObjectId());
        tagIds.add(items2.get(0).getObjectId());
        rslt = groupPersistencyService.getCorrelatedTags(TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")), tagIds);
        assertThat(rslt).hasSize(2);
        assertThat(rslt.keySet()).containsOnly(items.get(0).getObjectId(), items2.get(0).getObjectId());
        assertThat(rslt.get(items.get(0).getObjectId())).hasSize(2).extracting(AssetGroupItem::getGroupId).containsOnly(
            group.getId(), group.getId());
        assertThat(rslt.get(items.get(0).getObjectId())).extracting(AssetGroupItem::getObjectId).containsOnly(
            items.get(0).getObjectId(), items.get(1).getObjectId());
        assertThat(rslt.get(items.get(0).getObjectId())).extracting(AssetGroupItem::getPosition).containsExactly(1, 2);
        assertThat(rslt.get(items2.get(0).getObjectId())).hasSize(4).extracting(AssetGroupItem::getGroupId)
            .containsOnly(group2.getId(), group2.getId(), group2.getId(), group2.getId());
        assertThat(rslt.get(items2.get(0).getObjectId())).extracting(AssetGroupItem::getObjectId).containsOnly(
            items2.get(0).getObjectId(), items2.get(1).getObjectId(), items2.get(2).getObjectId(),
            items2.get(3).getObjectId());
        assertThat(rslt.get(items2.get(0).getObjectId())).extracting(AssetGroupItem::getPosition).containsExactly(1, 2,
            3, 4);

        tagIds.clear();
        tagIds.add(items.get(0).getId());
        assertThat(groupPersistencyService.getCorrelatedTags(TEST_TENANT, getUnPrivileged(assets.get("E1_S1_Seg1")),
            tagIds)).hasSize(0);
    }

    @Test
    @Transactional
    public void getCorrelatedTags_asUber() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 6;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        // create the first group with 2 tags
        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString()).category(
            AssetGroupCategory.TAG_CORRELATION).build();
        groupPersistencyService.createAssetGroup(TEST_TENANT, group);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

        groupPersistencyService.createAssetGroupItems(TEST_TENANT, getUber(), group.getId(), items);

        // create the 2nd group with 4 tags
        AssetGroup group2 = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString()).category(
            AssetGroupCategory.TAG_CORRELATION).build();
        groupPersistencyService.createAssetGroup(TEST_TENANT, group2);

        List<AssetGroupItem> items2 = new ArrayList<>();
        for (int i = 2; i < count; i++) {
            items2.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group2.getId(), i - 1));
        }
        groupPersistencyService.createAssetGroupItems(TEST_TENANT, getUber(), group2.getId(), items2);

        Set<String> tagIds = new HashSet<>();
        for (AssetGroupItem item : items) {
            tagIds.add(item.getObjectId());
        }
        Map<String, List<AssetGroupItem>> rslt = groupPersistencyService.getCorrelatedTags(TEST_TENANT, getUber(), tagIds);
        assertThat(rslt).hasSize(items.size());
        assertThat(rslt.keySet()).containsOnly(items.get(0).getObjectId(), items.get(1).getObjectId());
        for (Map.Entry<String, List<AssetGroupItem>> e : rslt.entrySet()) {
            List<AssetGroupItem> value = e.getValue();
            assertThat(value).hasSize(items.size()).extracting(AssetGroupItem::getGroupId).containsOnly(group.getId(),
                group.getId());
            assertThat(value).extracting(AssetGroupItem::getObjectId).containsOnly(items.get(0).getObjectId(),
                items.get(1).getObjectId());
            assertThat(value).extracting(AssetGroupItem::getPosition).containsExactly(1, 2);
        }

        tagIds.clear();
        for (AssetGroupItem item : items2) {
            tagIds.add(item.getObjectId());
        }
        rslt = groupPersistencyService.getCorrelatedTags(TEST_TENANT, getUber(), tagIds);
        assertThat(rslt).hasSize(items2.size());
        assertThat(rslt.keySet()).containsOnly(items2.get(0).getObjectId(), items2.get(1).getObjectId(),
            items2.get(2).getObjectId(), items2.get(3).getObjectId());
        for (Map.Entry<String, List<AssetGroupItem>> e : rslt.entrySet()) {
            List<AssetGroupItem> value = e.getValue();
            assertThat(value).hasSize(items2.size()).extracting(AssetGroupItem::getGroupId).containsOnly(group2.getId(),
                group2.getId(), group2.getId(), group2.getId());
            assertThat(value).extracting(AssetGroupItem::getObjectId).containsOnly(items2.get(0).getObjectId(),
                items2.get(1).getObjectId(), items2.get(2).getObjectId(), items2.get(3).getObjectId());
            assertThat(value).extracting(AssetGroupItem::getPosition).containsExactly(1, 2, 3, 4);
        }
        tagIds.clear();
        tagIds.add(items.get(0).getObjectId());
        tagIds.add(items2.get(0).getObjectId());
        rslt = groupPersistencyService.getCorrelatedTags(TEST_TENANT, getUber(), tagIds);
        assertThat(rslt).hasSize(2);
        assertThat(rslt.keySet()).containsOnly(items.get(0).getObjectId(), items2.get(0).getObjectId());
        assertThat(rslt.get(items.get(0).getObjectId())).hasSize(2).extracting(AssetGroupItem::getGroupId).containsOnly(
            group.getId(), group.getId());
        assertThat(rslt.get(items.get(0).getObjectId())).extracting(AssetGroupItem::getObjectId).containsOnly(
            items.get(0).getObjectId(), items.get(1).getObjectId());
        assertThat(rslt.get(items.get(0).getObjectId())).extracting(AssetGroupItem::getPosition).containsExactly(1, 2);
        assertThat(rslt.get(items2.get(0).getObjectId())).hasSize(4).extracting(AssetGroupItem::getGroupId)
            .containsOnly(group2.getId(), group2.getId(), group2.getId(), group2.getId());
        assertThat(rslt.get(items2.get(0).getObjectId())).extracting(AssetGroupItem::getObjectId).containsOnly(
            items2.get(0).getObjectId(), items2.get(1).getObjectId(), items2.get(2).getObjectId(),
            items2.get(3).getObjectId());
        assertThat(rslt.get(items2.get(0).getObjectId())).extracting(AssetGroupItem::getPosition).containsExactly(1, 2,
            3, 4);

        tagIds.clear();
        tagIds.add(items.get(0).getId());
        assertThat(groupPersistencyService.getCorrelatedTags(TEST_TENANT, getUber(), tagIds)).hasSize(0);
    }

    @Test
    @Transactional
    public void getCorrelatedTags_asUnprivileged() throws PersistencyServiceException, IOException {
        Map<String, AssetType> types = createTypes(assetTypePersistencyService);
        Map<String, Asset> assets = createAssets(assetPersistencyService, types);
        int count = 6;
        List<Tag> tags = createTagData(tagPersistencyService, types.get("MyTagType").getId(),
            assets.get("E1_S1_Seg1_Asset1"), count);

        // create the first group with 2 tags
        AssetGroup group = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString()).category(
            AssetGroupCategory.TAG_CORRELATION).build();
        groupPersistencyService.createAssetGroup(TEST_TENANT, group);

        List<AssetGroupItem> items = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            items.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group.getId(), i + 1));
        }

         groupPersistencyService.createAssetGroupItems(TEST_TENANT, getUber(), group.getId(), items);

        // create the 2nd group with 4 tags
        AssetGroup group2 = TestAssetGroup.builder().tenantId(TEST_TENANT).id(UUID.randomUUID().toString()).category(
            AssetGroupCategory.TAG_CORRELATION).build();
        groupPersistencyService.createAssetGroup(TEST_TENANT, group2);

        List<AssetGroupItem> items2 = new ArrayList<>();
        for (int i = 2; i < count; i++) {
            items2.add(TagPredicateUtils.newTagCorrelationItem(tags.get(i), group2.getId(), i - 1));
        }
        groupPersistencyService.createAssetGroupItems(TEST_TENANT, getUber(), group2.getId(), items2);

         Set<String> tagIds = new HashSet<>();
        for (AssetGroupItem item : items) {
            tagIds.add(item.getObjectId());
        }
        assertThat(groupPersistencyService.getCorrelatedTags(TEST_TENANT, getUnPrivileged(), tagIds)).hasSize(0);

        tagIds.clear();
        for (AssetGroupItem item : items2) {
            tagIds.add(item.getObjectId());
        }
        assertThat(groupPersistencyService.getCorrelatedTags(TEST_TENANT, getUnPrivileged(), tagIds)).hasSize(0);

        tagIds.clear();
        tagIds.add(items.get(0).getObjectId());
        tagIds.add(items2.get(0).getObjectId());
        assertThat(groupPersistencyService.getCorrelatedTags(TEST_TENANT, getUnPrivileged(), tagIds)).hasSize(0);

        tagIds.clear();
        tagIds.add(items.get(0).getId());
        assertThat(groupPersistencyService.getCorrelatedTags(TEST_TENANT, getUnPrivileged(), tagIds)).hasSize(0);
    }
}
