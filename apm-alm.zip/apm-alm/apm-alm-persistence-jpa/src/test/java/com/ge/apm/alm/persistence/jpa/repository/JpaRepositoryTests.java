/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.repository;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetTypeEntity;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class JpaRepositoryTests extends BaseRepositoryTest {

    @Autowired
    private AssetTypeRepository assetTypeRepository;

    @Autowired
    private AssetInstanceRepository assetInstanceRepository;

    private AssetTypeEntity myEnterpriseType;

    private AssetTypeEntity mySiteType;

    private AssetTypeEntity mySegmentType;

    private AssetTypeEntity myAssetType;

    @Test
    @Transactional
    public void stg1_creatingAssetTypesAndAssetInstances() throws IOException {

        createTypes();

        assertThat("MyEnterpriseType").isEqualTo(assetTypeRepository.findOne(myEnterpriseType.getId()).getName());
        assertThat("MySiteType").isEqualTo(assetTypeRepository.findOne(mySiteType.getId()).getName());
        assertThat("MySegmentType").isEqualTo(assetTypeRepository.findOne(mySegmentType.getId()).getName());
        assertThat("MyAssetType").isEqualTo(assetTypeRepository.findOne(myAssetType.getId()).getName());
        createEnterpriseHierarchy("E1");
        createEnterpriseHierarchy("E2");
        createEnterpriseHierarchy("E3");
        createEnterpriseHierarchy("E4");
    }

    private void createEnterpriseHierarchy(String enterpriseName) throws IOException {
        //Creating an instance of enterprise
        String entInstanceName = enterpriseName.concat("_").concat(myEnterpriseType.getName()).concat("_I1");
        String entDesc = "Acme Inc";
        AssetInstanceEntity entInstance = AssetInstanceEntity.builder().id(UUID.randomUUID().toString()).name(
            entInstanceName).sourceKey(entInstanceName).
            description(entDesc).assetType(myEnterpriseType.getId()).
            tenantId(TestUtils.TEST_TENANT).attributes(TestUtils.getAttributes("MyEnterpriseType")).
            ancestorsArray(Collections.EMPTY_LIST).
            superTypesArray(myEnterpriseType.getSuperTypesArray()).
            build();
        AssetInstanceEntity entCr = assetInstanceRepository.saveAndFlush(entInstance);

        //Creating an instance of Site
        String siteInstanceName = enterpriseName.concat("_S1_").concat(mySiteType.getName()).concat("_I1");
        String siteDesc = "Acme Inc Site 1";
        AssetInstanceEntity siteInstance = AssetInstanceEntity.builder().id(UUID.randomUUID().toString()).name(
            siteInstanceName).sourceKey(siteInstanceName).
            description(siteDesc).assetType(mySiteType.getId()).
            tenantId(TestUtils.TEST_TENANT).parentId(entCr.getId()).
            attributes(TestUtils.getAttributes("MySiteType")).
            ancestorsArray(Collections.singletonList(entCr.getId())).
            superTypesArray(mySiteType.getSuperTypesArray()).
            build();
        AssetInstanceEntity siteCr = assetInstanceRepository.saveAndFlush(siteInstance);

        //Creating an instance of Site
        String segInstanceName = enterpriseName.concat("_S1_SEG_1").concat(mySegmentType.getName()).concat("_I1");
        String segDesc = "Acme Inc Segment1 1";
        AssetInstanceEntity segInstance = AssetInstanceEntity.builder().id(UUID.randomUUID().toString()).name(
            segInstanceName).sourceKey(segInstanceName).
            description(segDesc).assetType(mySegmentType.getId()).
            tenantId(TestUtils.TEST_TENANT).parentId(siteCr.getId()).
            attributes(TestUtils.getAttributes("MySegmentType")).
            ancestorsArray(Arrays.asList(entCr.getId(), siteCr.getId())).
            superTypesArray(mySegmentType.getSuperTypesArray()).
            build();
        AssetInstanceEntity segCreated = assetInstanceRepository.saveAndFlush(segInstance);

        //Creating an instance of Asset
        String assetInstanceName = enterpriseName.concat("_S1_Seg1_Asset_1_").concat(myAssetType.getName()).concat(
            "_I1");
        String assetDesc = "Asset for Acme COMPANY LIMITED";
        AssetInstanceEntity assetInstance = AssetInstanceEntity.builder().id(UUID.randomUUID().toString()).name(
            assetInstanceName).sourceKey(assetInstanceName).
            description(assetDesc).assetType(myAssetType.getId()).
            tenantId(TestUtils.TEST_TENANT).parentId(segCreated.getId()).
            ancestorsArray(Arrays.asList(entCr.getId(), siteCr.getId(), segCreated.getId())).
            superTypesArray(myAssetType.getSuperTypesArray()).
            attributes(TestUtils.getAttributes("MyAssetType")).build();
        AssetInstanceEntity assetCr = assetInstanceRepository.saveAndFlush(assetInstance);

        AssetInstanceEntity asset1 = assetInstanceRepository.findOne(assetCr.getId());
        assertThat(asset1.getParentId()).isEqualTo(segCreated.getId());

        List<Object[]> values = assetInstanceRepository.findAllImmediateChildren(TestUtils.TEST_TENANT, entCr.getId());
        assertThat(values).hasSize(1);
        assertThat(values.get(0)).hasSize(4);
        assertThat(values.get(0)[0]).isEqualTo(siteCr.getId());
    }

    private void createTypes() throws IOException {
        //creating a new type of enterpriseType
        AssetTypeEntity myEnterpriseType1 = AssetTypeEntity.builder().id(UUID.randomUUID().toString()).name(
            "MyEnterpriseType").sourceKey("MyEnterpriseType").
            description("MyEnterpriseType").superTypeId(SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID).
            tenantId(TestUtils.TEST_TENANT).jsonSchema(EMPTY_JSON_NODE).attributeSchema(EMPTY_JSON_NODE).
            superTypesArray(Collections.singletonList(SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID)).
            typeSemantics(EMPTY_JSON_NODE).build();

        //creating a new type of site Type
        AssetTypeEntity mySiteType1 = AssetTypeEntity.builder().id(UUID.randomUUID().toString()).name("MySiteType")
            .sourceKey("MySiteType").
                description("MySiteType").superTypeId(SeedOOTBData.ROOT_SITE_TYPE_ID).
                tenantId(TestUtils.TEST_TENANT).jsonSchema(EMPTY_JSON_NODE).attributeSchema(EMPTY_JSON_NODE).
                superTypesArray(Collections.singletonList(SeedOOTBData.ROOT_SITE_TYPE_ID)).
                typeSemantics(EMPTY_JSON_NODE).build();

        //creating a new type of Segment Type
        AssetTypeEntity mySegmentType1 = AssetTypeEntity.builder().id(UUID.randomUUID().toString()).name(
            "MySegmentType").sourceKey("MySegmentType").
            description("MySegmentType").superTypeId(SeedOOTBData.ROOT_SEGMENT_TYPE_ID).
            tenantId(TestUtils.TEST_TENANT).jsonSchema(EMPTY_JSON_NODE).attributeSchema(EMPTY_JSON_NODE).
            superTypesArray(Collections.singletonList(SeedOOTBData.ROOT_SEGMENT_TYPE_ID)).
            typeSemantics(EMPTY_JSON_NODE).build();

        //creating a new type of Asset Type
        AssetTypeEntity myAssetType1 = AssetTypeEntity.builder().id(UUID.randomUUID().toString()).name("MyAssetType")
            .sourceKey("MyAssetType").
                description("MyAssetType").superTypeId(SeedOOTBData.ROOT_ASSET_TYPE_ID).
                tenantId(TestUtils.TEST_TENANT).jsonSchema(TestUtils.getAssetTypeSchema()).
                attributeSchema(TestUtils.getAssetTypeSchema()).
                superTypesArray(Collections.singletonList(SeedOOTBData.ROOT_ASSET_TYPE_ID)).
                typeSemantics(EMPTY_JSON_NODE).build();

        myEnterpriseType = assetTypeRepository.saveAndFlush(myEnterpriseType1);
        mySiteType = this.assetTypeRepository.saveAndFlush(mySiteType1);
        mySegmentType = this.assetTypeRepository.saveAndFlush(mySegmentType1);
        myAssetType = this.assetTypeRepository.saveAndFlush(myAssetType1);
    }
}
