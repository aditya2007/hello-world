/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence.jpa.entitylistener;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.alm.model.view.AssetTypeComponent;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.TestApp;
import com.ge.apm.alm.persistence.jpa.entity.AssetTypeEntity;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
@ActiveProfiles("application-test")
public class AssetTypeParentLoaderTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetTypeParentLoader assetTypeParentLoader;

    @Test
    @Transactional
    public void testLoadAssetType() throws IOException, PersistencyServiceException {
        AssetType superType = assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT,
            TestUtils.createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, "T1"));
        AssetType loadType = assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT,
            TestUtils.createAssetType(superType.getId(), "T2"));

        AssetTypeEntity assetType =
            (AssetTypeEntity) assetTypePersistencyService.getAssetTypeById(TestUtils.TEST_TENANT,
                loadType.getId());
        assertThat(assetType.getSuperType()).isNull();

        assetTypeParentLoader.postLoad(TestUtils.TEST_TENANT, null, assetType,
            AttributeSelectEnum.FULL, EnumSet.noneOf(AssetTypeComponent.class));
        assertThat(assetType.getSuperType()).isNull();

        assetTypeParentLoader.postLoad(TestUtils.TEST_TENANT, null, assetType,
            AttributeSelectEnum.FULL, EnumSet.of(AssetTypeComponent.PARENT));
        assertSuperTypeAttached(assetType, superType);
    }

    @Test
    @Transactional
    public void testLoadAssetTypeList() throws IOException, PersistencyServiceException {
        AssetType superType = assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT,
            TestUtils.createAssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID, "T1"));
        AssetType loadType1 = assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT,
            TestUtils.createAssetType(superType.getId(), "T2"));
        AssetType loadType2 = assetTypePersistencyService.createAssetType(TestUtils.TEST_TENANT,
            TestUtils
                .createAssetTypeAndAssert(assetTypePersistencyService, loadType1.getId(), "T3"));

        List<AssetTypeEntity> loadedList = new ArrayList<>(2);
        loadedList.add(
            (AssetTypeEntity) assetTypePersistencyService.getAssetTypeById(TestUtils.TEST_TENANT,
                loadType1.getId()));
        loadedList.add(
            (AssetTypeEntity) assetTypePersistencyService.getAssetTypeById(TestUtils.TEST_TENANT,
                loadType2.getId()));

        assetTypeParentLoader.postLoad(TestUtils.TEST_TENANT, null, loadedList,
            AttributeSelectEnum.FULL, EnumSet.noneOf(AssetTypeComponent.class));
        assertThat(loadedList.get(0).getSuperType()).isNull();
        assertThat(loadedList.get(1).getSuperType()).isNull();

        assetTypeParentLoader.postLoad(TestUtils.TEST_TENANT, null, loadedList,
            AttributeSelectEnum.FULL, EnumSet.of(AssetTypeComponent.PARENT));
        assertSuperTypeAttached(loadedList.get(0), superType);
        assertSuperTypeAttached(loadedList.get(1), loadType1);
    }

    private void assertSuperTypeAttached(AssetTypeEntity loadedAssetType,
        AssetType expectedSuperType) {
        AssetType loadedSuperType = loadedAssetType.getSuperType();
        assertThat(loadedSuperType).isNotNull();
        assertThat(loadedSuperType.getId()).isEqualTo(loadedAssetType.getSuperTypeId());
        assertThat(loadedSuperType.getId()).isEqualTo(expectedSuperType.getId());
    }
}
