/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence.jpa.persistency.template;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetPlaceholder;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPlaceholderPersistencyService;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.entity.AssetPlaceholderEntity;
import com.ge.apm.alm.persistence.jpa.model.TestAssetPlaceholder;
import com.ge.apm.alm.persistence.jpa.model.TestPlaceholder;
import com.ge.apm.alm.persistence.jpa.model.TestTemplate;
import com.ge.apm.alm.persistence.jpa.utils.TestTemplateUtils;
import com.ge.apm.alm.persistence.jpa.utils.TestUtils;

import static com.ge.apm.alm.model.coretypes.SeedOOTBData.ROOT_ASSET_TYPE_ID;
import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
public class AssetPlaceholderPersistencySvcTest extends TemplatePersistSvcBaseTests {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Autowired
    private AssetPlaceholderPersistencyService assetPlaceholderPersistencyService;

    @Test
    public void testAssetPlaceholderEntity() {
        AssetPlaceholderEntity entity = new AssetPlaceholderEntity();
        entity.setId(TestTemplateUtils.getNewUuid());
        entity.setTenantId(TestUtils.TEST_TENANT);
        entity.setAssetId(TestTemplateUtils.getNewUuid());
        entity.setPlaceholderId(TestTemplateUtils.getNewUuid());
        entity.setConformanceFlag(Boolean.TRUE);
        entity.setCreatedBy("testUser");
        entity.setLastModifiedBy("testUser");
        log.info(entity.toString());
        AssetPlaceholderEntity.builder().id(TestTemplateUtils.getNewUuid()).tenantId(TestUtils.TEST_TENANT).assetId(
            TestTemplateUtils.getNewUuid()).placeholderId(TestTemplateUtils.getNewUuid()).conformanceFlag(Boolean.TRUE)
            .createdBy("testUser").lastModifiedBy("testUser").build();
    }

    @Test
    @Transactional
    public void testCreateAssetPlaceholder() throws IOException, PersistencyServiceException {
        String assetId = createAssets().get(0).getId();
        String placeholderId = createTestPlaceholders().get(0).getId();

        TestAssetPlaceholder testAssetPlaceholder = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(assetId).placeholderId(placeholderId).conformanceFlag(Boolean.TRUE)
            .createdBy("testUser").lastModifiedBy("testUser").build();

        AssetPlaceholder dbAssetPlaceholder = assetPlaceholderPersistencyService.createAssetPlaceholder(
            TestUtils.TEST_TENANT, testAssetPlaceholder);

        assertThat(dbAssetPlaceholder).isNotNull();
        assertThat(dbAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreateAssetPlaceholder_missingMatchTenantId() throws IOException, PersistencyServiceException {
        String assetId = createAssets().get(0).getId();
        String placeholderId = createTestPlaceholders().get(0).getId();

        TestAssetPlaceholder testAssetPlaceholder = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId("UNKNOWN_TENANT_ID").assetId(assetId).placeholderId(placeholderId).conformanceFlag(Boolean.TRUE)
            .createdBy("testUser").lastModifiedBy("testUser").build();

        AssetPlaceholder dbAssetPlaceholder = assetPlaceholderPersistencyService.createAssetPlaceholder(
            TestUtils.TEST_TENANT, testAssetPlaceholder);

        assertThat(dbAssetPlaceholder).isNotNull();
        assertThat(dbAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreateAssetPlaceholder_missingId() throws IOException, PersistencyServiceException {
        String assetId = createAssets().get(0).getId();
        String placeholderId = createTestPlaceholders().get(0).getId();

        TestAssetPlaceholder testAssetPlaceholder = TestAssetPlaceholder.builder().id(null).tenantId(
            TestUtils.TEST_TENANT).assetId(assetId).placeholderId(placeholderId).conformanceFlag(Boolean.TRUE)
            .createdBy("testUser").lastModifiedBy("testUser").build();

        AssetPlaceholder dbAssetPlaceholder = assetPlaceholderPersistencyService.createAssetPlaceholder(
            TestUtils.TEST_TENANT, testAssetPlaceholder);

        assertThat(dbAssetPlaceholder).isNotNull();
        assertThat(dbAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreateAssetPlaceholder_missingAssetId() throws IOException {
        String placeholderId = createTestPlaceholders().get(0).getId();

        TestAssetPlaceholder testAssetPlaceholder = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(null).placeholderId(placeholderId).conformanceFlag(Boolean.TRUE)
            .createdBy("testUser").lastModifiedBy("testUser").build();

        AssetPlaceholder dbAssetPlaceholder = assetPlaceholderPersistencyService.createAssetPlaceholder(
            TestUtils.TEST_TENANT, testAssetPlaceholder);

        assertThat(dbAssetPlaceholder).isNotNull();
        assertThat(dbAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());
    }

    @Test(expected = IllegalArgumentException.class)
    @Transactional
    public void testCreateAssetPlaceholder_missingPlaceholderId() throws IOException, PersistencyServiceException {
        String assetId = createAssets().get(0).getId();

        TestAssetPlaceholder testAssetPlaceholder = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(assetId).placeholderId(null).conformanceFlag(Boolean.TRUE)
            .createdBy("testUser").lastModifiedBy("testUser").build();

        AssetPlaceholder dbAssetPlaceholder = assetPlaceholderPersistencyService.createAssetPlaceholder(
            TestUtils.TEST_TENANT, testAssetPlaceholder);

        assertThat(dbAssetPlaceholder).isNotNull();
        assertThat(dbAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());
    }

    @Test
    @Transactional
    public void testCreateAssetPlaceholders() throws IOException, PersistencyServiceException {
        List<Asset> assets = createAssets();
        List<Placeholder> placeholders = createTestPlaceholders();

        List<AssetPlaceholder> assetPlaceholders = new ArrayList<>();
        int counter = assetPlaceholderPersistencyService.createAssetPlaceholders(TestUtils.TEST_TENANT,
            assetPlaceholders);
        assertThat(counter).isEqualTo(0);

        TestAssetPlaceholder testAssetPlaceholder1 = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(assets.get(0).getId()).placeholderId(placeholders.get(0).getId())
            .conformanceFlag(Boolean.TRUE).createdBy("testUser").lastModifiedBy("testUser").build();
        TestAssetPlaceholder testAssetPlaceholder2 = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(assets.get(1).getId()).placeholderId(placeholders.get(1).getId())
            .conformanceFlag(Boolean.TRUE).createdBy("testUser").lastModifiedBy("testUser").build();

        assetPlaceholders.add(testAssetPlaceholder1);
        assetPlaceholders.add(testAssetPlaceholder2);

        counter = assetPlaceholderPersistencyService.createAssetPlaceholders(TestUtils.TEST_TENANT, assetPlaceholders);
        assertThat(counter).isEqualTo(2);
    }

    @Test
    @Transactional
    public void testUpdateAssetPlaceholder() throws IOException, PersistencyServiceException {
        List<Asset> assets = createAssets();
        List<Placeholder> placeholders = createTestPlaceholders();

        TestAssetPlaceholder testAssetPlaceholder1 = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(assets.get(0).getId()).placeholderId(placeholders.get(0).getId())
            .conformanceFlag(Boolean.TRUE).createdBy("testUser").lastModifiedBy("testUser").build();

        AssetPlaceholder dbAssetPlaceholder = assetPlaceholderPersistencyService.createAssetPlaceholder(
            TestUtils.TEST_TENANT, testAssetPlaceholder1);

        assertThat(dbAssetPlaceholder).isNotNull();
        assertThat(dbAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder1.getId());

        // assign asset0 to placeholder1
        testAssetPlaceholder1.setPlaceholderId(placeholders.get(1).getId());
        dbAssetPlaceholder = assetPlaceholderPersistencyService.createAssetPlaceholder(TestUtils.TEST_TENANT,
            testAssetPlaceholder1);

        assertThat(dbAssetPlaceholder).isNotNull();
        assertThat(dbAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder1.getId());
    }

    @Test
    @Transactional
    public void testUpdateAssetPlaceholders() throws IOException, PersistencyServiceException {
        List<Asset> assets = createAssets();
        List<Placeholder> placeholders = createTestPlaceholders();

        List<AssetPlaceholder> assetPlaceholders = new ArrayList<>();
        int counter = assetPlaceholderPersistencyService.createAssetPlaceholders(TestUtils.TEST_TENANT,
            assetPlaceholders);
        assertThat(counter).isEqualTo(0);

        TestAssetPlaceholder testAssetPlaceholder1 = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(assets.get(0).getId()).placeholderId(placeholders.get(0).getId())
            .conformanceFlag(Boolean.TRUE).createdBy("testUser").lastModifiedBy("testUser").build();
        TestAssetPlaceholder testAssetPlaceholder2 = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(assets.get(1).getId()).placeholderId(placeholders.get(1).getId())
            .conformanceFlag(Boolean.TRUE).createdBy("testUser").lastModifiedBy("testUser").build();

        assetPlaceholders.add(testAssetPlaceholder1);
        assetPlaceholders.add(testAssetPlaceholder2);

        counter = assetPlaceholderPersistencyService.createAssetPlaceholders(TestUtils.TEST_TENANT, assetPlaceholders);
        assertThat(counter).isEqualTo(2);

        testAssetPlaceholder1.setPlaceholderId(placeholders.get(1).getId());
        testAssetPlaceholder2.setPlaceholderId(placeholders.get(2).getId());
        counter = assetPlaceholderPersistencyService.updateAssetPlaceholders(TestUtils.TEST_TENANT, assetPlaceholders);
        assertThat(counter).isEqualTo(2);
    }

    @Test
    @Transactional
    public void testDeleteAssetPlaceholderById() throws IOException, PersistencyServiceException {
        String assetId = createAssets().get(0).getId();
        String placeholderId = createTestPlaceholders().get(0).getId();

        TestAssetPlaceholder testAssetPlaceholder = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(assetId).placeholderId(placeholderId).conformanceFlag(Boolean.TRUE)
            .createdBy("testUser").lastModifiedBy("testUser").build();

        AssetPlaceholder dbAssetPlaceholder = assetPlaceholderPersistencyService.createAssetPlaceholder(
            TestUtils.TEST_TENANT, testAssetPlaceholder);

        assertThat(dbAssetPlaceholder).isNotNull();
        assertThat(dbAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());

        assetPlaceholderPersistencyService.deleteAssetPlaceholderById(TestUtils.TEST_TENANT,
            testAssetPlaceholder.getId());

        assertThat(assetPlaceholderPersistencyService
            .getAssetPlaceholderById(TestUtils.TEST_TENANT, testAssetPlaceholder.getId())).isNull();
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeleteAssetPlaceholderById_NotFoundException() throws PersistencyServiceException {
        String uuid = TestTemplateUtils.getNewUuid();
        assertThat(assetPlaceholderPersistencyService.deleteAssetPlaceholderById(TestUtils.TEST_TENANT, uuid))
            .isEqualTo(0);
    }

    @Test
    @Transactional
    public void testDeleteAssetPlaceholderByAssetId() throws IOException, PersistencyServiceException {
        String assetId = createAssets().get(0).getId();
        String placeholderId = createTestPlaceholders().get(0).getId();

        TestAssetPlaceholder testAssetPlaceholder = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(assetId).placeholderId(placeholderId).conformanceFlag(Boolean.TRUE)
            .createdBy("testUser").lastModifiedBy("testUser").build();

        AssetPlaceholder dbAssetPlaceholder = assetPlaceholderPersistencyService.createAssetPlaceholder(
            TestUtils.TEST_TENANT, testAssetPlaceholder);

        assertThat(dbAssetPlaceholder).isNotNull();
        assertThat(dbAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());

        assetPlaceholderPersistencyService.deleteAssetPlaceholderByAssetId(TestUtils.TEST_TENANT,
            testAssetPlaceholder.getAssetId());

        assertThat(assetPlaceholderPersistencyService
            .getAssetPlaceholderById(TestUtils.TEST_TENANT, testAssetPlaceholder.getAssetId())).isNull();
    }

    @Test(expected = ObjectNotFoundException.class)
    @Transactional
    public void testDeleteAssetPlaceholderByAssetId_NotFoundException() throws PersistencyServiceException {
        String uuid = TestTemplateUtils.getNewUuid();
        assertThat(assetPlaceholderPersistencyService.deleteAssetPlaceholderById(TestUtils.TEST_TENANT, uuid))
            .isEqualTo(0);
    }

    @Test
    @Transactional
    public void testGetAssetPlaceholderById() throws IOException, PersistencyServiceException {
        String assetId = createAssets().get(0).getId();
        String placeholderId = createTestPlaceholders().get(0).getId();

        TestAssetPlaceholder testAssetPlaceholder = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(assetId).placeholderId(placeholderId).conformanceFlag(Boolean.TRUE)
            .createdBy("testUser").lastModifiedBy("testUser").build();

        AssetPlaceholder dbAssetPlaceholder = assetPlaceholderPersistencyService.createAssetPlaceholder(
            TestUtils.TEST_TENANT, testAssetPlaceholder);
        assertThat(dbAssetPlaceholder).isNotNull();
        assertThat(dbAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());

        AssetPlaceholder foundAssetPlaceholder = assetPlaceholderPersistencyService.getAssetPlaceholderById(
            TestUtils.TEST_TENANT, testAssetPlaceholder.getId());
        assertThat(foundAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());
    }

    @Test
    @Transactional
    public void testGetAssetPlaceholderById_NotFoundException() {
        final String id = TestTemplateUtils.getNewUuid();
        assertThat(assetPlaceholderPersistencyService.getAssetPlaceholderById(TestUtils.TEST_TENANT, id)).isNull();
    }

    @Test
    @Transactional
    public void testGetAssetPlaceholderByAssetId() throws IOException, PersistencyServiceException {
        String assetId = createAssets().get(0).getId();
        String placeholderId = createTestPlaceholders().get(0).getId();

        TestAssetPlaceholder testAssetPlaceholder = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(assetId).placeholderId(placeholderId).conformanceFlag(Boolean.TRUE)
            .createdBy("testUser").lastModifiedBy("testUser").build();

        AssetPlaceholder dbAssetPlaceholder = assetPlaceholderPersistencyService.createAssetPlaceholder(
            TestUtils.TEST_TENANT, testAssetPlaceholder);
        assertThat(dbAssetPlaceholder).isNotNull();
        assertThat(dbAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());

        AssetPlaceholder foundAssetPlaceholder = assetPlaceholderPersistencyService.getAssetPlaceholderByAssetId(
            TestUtils.TEST_TENANT, testAssetPlaceholder.getAssetId());
        assertThat(foundAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());
    }

    @Test
    @Transactional
    public void testGetAssetPlaceholderByAssetId_NotFoundException() {
        final String id = TestTemplateUtils.getNewUuid();
        assertThat(assetPlaceholderPersistencyService.getAssetPlaceholderByAssetId(TestUtils.TEST_TENANT, id)).isNull();
    }

    @Test
    @Transactional
    public void testGetAssetPlaceholderByTemplateAndPpn() throws IOException, PersistencyServiceException {
        List<Asset> assets = createAssets();
        List<Placeholder> placeholders = createTestPlaceholders();

        String assetId = assets.get(0).getId();
        String placeholderId = placeholders.get(0).getId();
        String templateId = placeholders.get(0).getTemplateId();
        String ppn = placeholders.get(0).getPartPositionNumber();

        TestAssetPlaceholder testAssetPlaceholder = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(TestUtils.TEST_TENANT).assetId(assetId).placeholderId(placeholderId).conformanceFlag(Boolean.TRUE)
            .createdBy("testUser").lastModifiedBy("testUser").build();

        AssetPlaceholder dbAssetPlaceholder = assetPlaceholderPersistencyService.createAssetPlaceholder(
            TestUtils.TEST_TENANT, testAssetPlaceholder);
        assertThat(dbAssetPlaceholder).isNotNull();
        assertThat(dbAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());

        AssetPlaceholder foundAssetPlaceholder = assetPlaceholderPersistencyService.getAssetPlaceholderByTemplateAndPpn(
            TestUtils.TEST_TENANT, templateId, ppn);
        assertThat(foundAssetPlaceholder.getId()).isEqualTo(testAssetPlaceholder.getId());
    }

    @Test
    @Transactional
    public void testGetAssetPlaceholderByTemplateAndPpn_NotFoundException() {
        final String id = TestTemplateUtils.getNewUuid();
        assertThat(assetPlaceholderPersistencyService
            .getAssetPlaceholderByTemplateAndPpn(TestUtils.TEST_TENANT, id, "UNKNOWN_PPN")).isNull();
    }

    @Test
    @Transactional
    public void testGetAssetPlaceholderByAssetIds() throws IOException, PersistencyServiceException {
        final String tenantId = TestUtils.TEST_TENANT;
        List<Asset> assets = createAssets();
        List<Placeholder> placeholders = createTestPlaceholders();

        List<AssetPlaceholder> assetPlaceholders = new ArrayList<>();

        int counter = assetPlaceholderPersistencyService.createAssetPlaceholders(tenantId, assetPlaceholders);
        assertThat(counter).isEqualTo(0);

        TestAssetPlaceholder testAssetPlaceholder1 = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(tenantId).assetId(assets.get(0).getId()).placeholderId(placeholders.get(0).getId())
            .conformanceFlag(Boolean.TRUE).createdBy("testUser").lastModifiedBy("testUser").build();
        TestAssetPlaceholder testAssetPlaceholder2 = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(tenantId).assetId(assets.get(1).getId()).placeholderId(placeholders.get(1).getId())
            .conformanceFlag(Boolean.TRUE).createdBy("testUser").lastModifiedBy("testUser").build();

        assetPlaceholders.add(testAssetPlaceholder1);
        assetPlaceholders.add(testAssetPlaceholder2);

        counter = assetPlaceholderPersistencyService.createAssetPlaceholders(tenantId, assetPlaceholders);
        assertThat(counter).isEqualTo(2);

        List<String> assetIds = new ArrayList<>();
        assetIds.add(testAssetPlaceholder1.getAssetId());
        assetIds.add(testAssetPlaceholder2.getAssetId());
        List<AssetPlaceholder> foundAssetPlaceholders = assetPlaceholderPersistencyService
            .getAssetPlaceholderByAssetIds(tenantId, assetIds);
        assertThat(foundAssetPlaceholders.size()).isEqualTo(2);
    }

    @Test
    @Transactional
    public void testGetAssetPlaceholderByPlaceholderIds() throws IOException, PersistencyServiceException {
        final String tenantId = TestUtils.TEST_TENANT;
        List<Asset> assets = createAssets();
        List<Placeholder> placeholders = createTestPlaceholders();

        List<AssetPlaceholder> assetPlaceholders = new ArrayList<>();

        int counter = assetPlaceholderPersistencyService.createAssetPlaceholders(tenantId, assetPlaceholders);
        assertThat(counter).isEqualTo(0);

        TestAssetPlaceholder testAssetPlaceholder1 = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(tenantId).assetId(assets.get(0).getId()).placeholderId(placeholders.get(0).getId())
            .conformanceFlag(Boolean.TRUE).createdBy("testUser").lastModifiedBy("testUser").build();
        TestAssetPlaceholder testAssetPlaceholder2 = TestAssetPlaceholder.builder().id(TestTemplateUtils.getNewUuid())
            .tenantId(tenantId).assetId(assets.get(1).getId()).placeholderId(placeholders.get(1).getId())
            .conformanceFlag(Boolean.TRUE).createdBy("testUser").lastModifiedBy("testUser").build();

        assetPlaceholders.add(testAssetPlaceholder1);
        assetPlaceholders.add(testAssetPlaceholder2);

        counter = assetPlaceholderPersistencyService.createAssetPlaceholders(tenantId, assetPlaceholders);
        assertThat(counter).isEqualTo(2);

        List<String> placeholderIds = new ArrayList<>();
        placeholderIds.add(testAssetPlaceholder1.getPlaceholderId());
        placeholderIds.add(testAssetPlaceholder2.getPlaceholderId());
        List<AssetPlaceholder> foundAssetPlaceholders = assetPlaceholderPersistencyService
            .getAssetPlaceholderByPlaceholderIds(tenantId, placeholderIds);
        assertThat(foundAssetPlaceholders.size()).isEqualTo(2);
    }

    private List<Asset> createAssets() throws IOException, PersistencyServiceException {
        //Creating Custom Turbine Type
        AssetType turbineType = TestUtils.createAssetTypeAndAssert(assetTypePersistencyService, ROOT_ASSET_TYPE_ID,
            "AssetPlaceholderType");

        Asset existingParent = assetPersistencyService.createAsset(TestUtils.TEST_TENANT, TestUtils.getUber(),
            TestUtils.createAssetInstance(turbineType.getId(), null, "AssetPlaceholder_parentAsset"));
        assertThat(existingParent.getAncestorsArray()).hasSize(0);

        List<Asset> assets = new ArrayList<>();

        // create assets with parent
        int count = 3;
        for (int i = 0; i < count; i++) {
            assets.add(TestUtils
                .createAssetInstance(turbineType.getId(), existingParent.getId(), i + "_assetPlaceholder_" + i));
        }
        assertThat(assetPersistencyService.createAssets(TestUtils.TEST_TENANT, TestUtils.getUber(), assets)).isEqualTo(
            assets.size());
        return assets;
    }

    private List<Placeholder> createTestPlaceholders() throws IOException {
        TestTemplate testTemplate = createTestTemplate("GE90 Engine Template", null, null);

        TestPlaceholder testPlaceholder1 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN10", null);
        TestPlaceholder testPlaceholder2 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN11",
            testPlaceholder1.getParentId());
        TestPlaceholder testPlaceholder3 = TestTemplateUtils.buildPlaceholder(testTemplate.getId(), "PPN12",
            testPlaceholder1.getParentId());

        List<Placeholder> testPlaceholders = new ArrayList<>();
        testPlaceholders.add(testPlaceholder1);
        testPlaceholders.add(testPlaceholder2);
        testPlaceholders.add(testPlaceholder3);

        int counter = placeholderPersistencyService.createPlaceholders(TestUtils.TEST_TENANT, testTemplate.getId(),
            testPlaceholders);
        assertThat(counter).isEqualTo(testPlaceholders.size());

        testTemplate.setPlaceholders(testPlaceholders);

        return testPlaceholders;
    }
}
