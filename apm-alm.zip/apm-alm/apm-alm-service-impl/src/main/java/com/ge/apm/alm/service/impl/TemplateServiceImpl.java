/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.model.Notes;
import com.ge.apm.alm.model.Placeholder;
import com.ge.apm.alm.model.PlaceholderGroupTagType;
import com.ge.apm.alm.model.PlaceholderTagType;
import com.ge.apm.alm.model.PlaceholderTemplate;
import com.ge.apm.alm.model.PlaceholderType;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.model.TemplateNotes;
import com.ge.apm.alm.model.query.TemplatePredicate;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.NotesPersistencyService;
import com.ge.apm.alm.persistence.PlaceholderGroupTagTypePersistencyService;
import com.ge.apm.alm.persistence.PlaceholderPersistencyService;
import com.ge.apm.alm.persistence.PlaceholderTagTypePersistencyService;
import com.ge.apm.alm.persistence.PlaceholderTemplatePersistencyService;
import com.ge.apm.alm.persistence.PlaceholderTypePersistencyService;
import com.ge.apm.alm.persistence.TemplateNotePersistencyService;
import com.ge.apm.alm.persistence.TemplatePersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.service.TemplateService;

@Service
@Transactional
public class TemplateServiceImpl implements TemplateService {

    @Autowired
    protected TemplatePersistencyService templatePersistencyService;
    @Autowired
    protected PlaceholderPersistencyService placeholderPersistencyService;
    @Autowired
    protected PlaceholderTypePersistencyService placeholderTypePersistencyService;
    @Autowired
    protected PlaceholderTemplatePersistencyService placeholderTemplatePersistencyService;
    @Autowired
    protected PlaceholderTagTypePersistencyService placeholderTagTypePersistencyService;
    @Autowired
    protected PlaceholderGroupTagTypePersistencyService placeholderGroupTagTypePersistencyService;
    @Autowired
    protected AssetTypePersistencyService assetTypePersistencyService;
    @Autowired
    protected GroupPersistencyService groupPersistencyService;
    @Autowired
    protected NotesPersistencyService notesPersistencyService;
    @Autowired
    protected TemplateNotePersistencyService templateNotePersistencyService;

    @Override
    public Template createTemplate(String tenantId, Template template) throws PersistencyServiceException {
        templatePersistencyService.createTemplate(tenantId, template);

        final List<TemplateNotes> templateNotes = template.getTemplateNotes();
        if (!CollectionUtils.isEmpty(templateNotes)) {
            List<Notes> notesList = new ArrayList<>();
            templateNotes.stream().forEach(tn -> notesList.add(tn.getNotes()));
            notesPersistencyService.createNotes(tenantId, notesList);
            templateNotePersistencyService.createTemplateNotes(tenantId, templateNotes);
        }

        final List<Placeholder> placeholders = template.getPlaceholders();
        if (!CollectionUtils.isEmpty(placeholders)) {
            placeholderPersistencyService.createPlaceholders(tenantId, template.getId(), placeholders);

            List<PlaceholderType> placeholderTypes = new ArrayList<>();
            List<PlaceholderTemplate> placeholderTemplates = new ArrayList<>();
            List<PlaceholderTagType> placeholderTagTypes = new ArrayList<>();
            List<PlaceholderGroupTagType> placeholderGroupTagTypes = new ArrayList<>();

            placeholders.stream().forEach(placeholder -> {
                placeholderTypes.addAll(placeholder.getPlaceholderTypes());
                placeholderTemplates.add(placeholder.getPlaceholderTemplate());
                placeholderTagTypes.addAll(placeholder.getPlaceholderTagTypes());
                placeholderGroupTagTypes.addAll(placeholder.getPlaceholderGroupTagTypes());
            });

            if (!CollectionUtils.isEmpty(placeholderTypes)) {
                placeholderTypePersistencyService.createPlaceholderTypes(tenantId, placeholderTypes);
            }
            if (!CollectionUtils.isEmpty(placeholderTemplates)) {
                placeholderTemplatePersistencyService.createPlaceholderTemplates(tenantId, placeholderTemplates);
            }
            if (!CollectionUtils.isEmpty(placeholderTagTypes)) {
                placeholderTagTypePersistencyService.createPlaceholderTagTypes(tenantId, placeholderTagTypes);
            }
            if (!CollectionUtils.isEmpty(placeholderGroupTagTypes)) {
                placeholderGroupTagTypePersistencyService
                    .createPlaceholderGroupTagTypes(tenantId, placeholderGroupTagTypes);
            }
        }
        return templatePersistencyService.getTemplateById(tenantId, template.getId());
    }

    @Override
    public Template getTemplateById(String tenantId, String id) {
        return templatePersistencyService.getTemplateById(tenantId, id);
    }

    @Override
    public Template getTemplateBySourceKey(String tenantId, String sourceKey) {
        return templatePersistencyService.getTemplateBySourceKey(tenantId, sourceKey);
    }

    @Override
    public List<Template> getTemplates(String tenantId, TemplatePredicate queryPredicate) {
        return templatePersistencyService.getTemplates(tenantId, queryPredicate);
    }

    @Override
    public void deleteTemplateById(String tenantId, String id)
        throws PersistencyServiceException {
        templatePersistencyService.deleteTemplateById(tenantId, id);
    }
}
