/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.service.impl;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.service.AssetService;

@Service
@Transactional
public class AssetServiceImpl implements AssetService {

    @Autowired
    private AssetPersistencyService assetPersistencyService;

    @Override
    public Asset createAsset(String tenantId, Collection<String> accessibleResources, Asset child)
        throws PersistencyServiceException {
        return assetPersistencyService.createAsset(tenantId, accessibleResources, child);
    }

    @Override
    public Asset createAsset(String tenantId, Collection<String> accessibleResources, String parentId, Asset child)
        throws PersistencyServiceException {
        return assetPersistencyService.createAsset(tenantId, accessibleResources, parentId, child);
    }

    @Override
    public Asset getAssetById(String tenantId, Collection<String> accessibleResources, String id) {
        return assetPersistencyService.getAssetById(tenantId, accessibleResources, id);
    }

    @Override
    public Asset getAssetBySourceKey(String tenantId, Collection<String> accessibleResources, String typeName,
        String sourceKey) {
        return assetPersistencyService.getAssetBySourceKey(tenantId, accessibleResources, typeName, sourceKey);
    }

    @Override
    public List<Asset> getAssets(String tenantId, Collection<String> accessibleResources,
        AssetPredicate queryPredicate) {
        return assetPersistencyService.getAssets(tenantId, accessibleResources, queryPredicate);
    }

    @Override
    public List<Asset> getChildAssets(String tenantId, Collection<String> accessibleResource, String id,
        AssetPredicate childPredicate) {
        return assetPersistencyService.getChildAssets(tenantId, accessibleResource, id, childPredicate);
    }
}
