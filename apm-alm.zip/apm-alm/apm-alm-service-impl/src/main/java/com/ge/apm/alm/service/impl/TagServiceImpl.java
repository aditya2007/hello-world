/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.service.impl;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.persistence.TagPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.service.TagService;

@Service
@Transactional
public class TagServiceImpl implements TagService {

    @Autowired
    private TagPersistencyService tagPersistencyService;

    @Override
    public Tag createTag(String tenantId, Collection<String> accessibleResources, Tag tag)
        throws PersistencyServiceException {
        return tagPersistencyService.createTag(tenantId, accessibleResources, tag);
    }

    @Override
    public int deleteTag(String tenantId, Collection<String> accessibleResources, String tagId)
        throws PersistencyServiceException {
        return tagPersistencyService.deleteTag(tenantId, accessibleResources, tagId);
    }

    @Override
    public Tag getTagById(String tenantId, Collection<String> accessibleResources, String id) {
        return tagPersistencyService.getTagById(tenantId, accessibleResources, id);
    }

    @Override
    public Tag getTagBySourceKey(String tenantId, Collection<String> accessibleResources, String sourceKey) {
        return tagPersistencyService.getTagBySourceKey(tenantId, accessibleResources, sourceKey);
    }

    @Override
    public List<Tag> getTags(String tenantId, Collection<String> accessibleResources,
        TagPredicate tagPredicate) {
        return tagPersistencyService.getTags(tenantId, accessibleResources, tagPredicate);
    }

    @Override
    public List<Tag> getTagsForAsset(String tenantId, Collection<String> accessibleResources, String assetId,
        boolean deepSearch, TagPredicate tagPredicate) {
        return tagPersistencyService.getTagsForAsset(tenantId, accessibleResources, assetId, deepSearch, tagPredicate);
    }
}
