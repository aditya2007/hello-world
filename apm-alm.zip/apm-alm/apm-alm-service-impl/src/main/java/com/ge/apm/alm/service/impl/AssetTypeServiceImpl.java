/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.persistence.AssetTypePersistencyService;
import com.ge.apm.alm.persistence.exceptions.SuperTypeDoesNotExistsException;
import com.ge.apm.alm.service.AssetTypeService;

@Service
@Transactional
public class AssetTypeServiceImpl implements AssetTypeService {

    @Autowired
    private AssetTypePersistencyService assetTypePersistencyService;

    @Override
    public AssetType getAssetTypeById(String tenantId, String id) {
        return assetTypePersistencyService.getAssetTypeById(tenantId, id);
    }

    @Override
    public AssetType getAssetTypeBySuperTypeAndId(String tenantId, String typeName, String id) {
        return assetTypePersistencyService.getAssetTypeBySuperTypeAndId(tenantId, typeName, id);
    }

    @Override
    public AssetType getAssetTypeBySuperTypeAndSourceKey(String tenantId, String typeName, String sourceKey) {
        return assetTypePersistencyService.getAssetTypeBySuperTypeAndSourceKey(tenantId, typeName, sourceKey);
    }

    @Override
    public List<AssetType> findAllAssetTypes(String tenantId, TypePredicate queryPredicate) {
        return assetTypePersistencyService.findAllAssetTypes(tenantId, queryPredicate);
    }

    @Override
    public AssetType createAssetType(String tenantId, AssetType assetType) throws SuperTypeDoesNotExistsException {
        return assetTypePersistencyService.createAssetType(tenantId, assetType);
    }
}
