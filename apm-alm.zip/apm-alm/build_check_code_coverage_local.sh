#!/bin/bash
# This is the script to check code coverage based on clover report

expectedCoverage=90
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

# run clover report
mvn -U clean -Dcheckstyle.skip=true -Dexcludes=**/target/**/* -Pclover.report clover2:setup verify clover2:check clover2:aggregate clover2:clover -s menlo_settings.xml
if [ $? -ne 0 ]; then
    printf "${RED}There are errors when generating clover report for code coverage.\n${NC}"
    return 0
fi

# get code coverage
localDir=./target/site/clover
data=`cat $localDir/project.js`
echo $data | tr -d ' ' | sed 's/.\{2\}$//' | sed 's/^.\{14\}//' > $localDir/formatted.json
actualCoverage=`jq ".stats.TotalPercentageCovered" $localDir/formatted.json | cut -d "." -f1`

# check coverage
if [ $actualCoverage -ge $expectedCoverage ]; then
    printf "%b" "${GREEN}Code coverage check is successful. Code coverage is $actualCoverage, which is above $expectedCoverage.\n${NC}"
    return 0
else
    printf "%b" "${RED}Code coverage check is failed. Code coverage is $actualCoverage, which is below $expectedCoverage.\n${NC}"
    return 1
fi 
