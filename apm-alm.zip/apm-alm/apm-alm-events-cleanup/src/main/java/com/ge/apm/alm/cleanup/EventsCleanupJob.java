/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.cleanup;

import java.util.HashSet;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.datasource.TenantDataSourceService;

/**
 * Created by Yogananda Gowda - 212590467 on 7/11/17.
 */
@ConditionalOnProperty("apm.asset.cleanup.job.enabled")
@Component
@Slf4j
public class EventsCleanupJob {

    @Autowired
    private AssetEventPersistencyService assetEventPersistencyService;

    @Value("${apm.asset.cleanup.job.timeout:864000000}")
    private Long jobTimeoutMillis;

    @Autowired
    private TenantDataSourceService tenantDataSourceService;

    @Scheduled(fixedRateString = "${apm.asset.cleanup.schedule.interval}")
    public void doExecute() {
        for (String tenantId : getDatabases()) {
            try {
                log.trace(String.format("Running Cleanup job for tenant=%s", tenantId));
                RequestContext.put(RequestContext.TENANT_UUID, tenantId);
                int numOfRecDeleted = assetEventPersistencyService.cleanupEvents(
                    AssetEvent.EventStatus.COMPLETED.name(), jobTimeoutMillis + "");
                log.trace("Number of Events got cleaned up are {}, ", numOfRecDeleted);
            } catch (Exception ex) {
                log.error("Exception while cleaning up events ", ex);
            }
        }
    }

    private HashSet<String> getDatabases() {
        HashSet<String> set = new HashSet<>();
        set.add(TenantDataSourceService.DEFAULT_DATASOURCE);
        set.addAll(tenantDataSourceService.getTenants());
        return set;
    }

}
