/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.cleanup;

import lombok.extern.slf4j.Slf4j;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.AssetEventPersistencyServiceImpl;
import com.ge.apm.datasource.TenantDataSourceService;

import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by Yogananda Gowda - 212590467 on 7/13/17.
 */
@Slf4j
public class EventsCleanupTests {

    private AssetEventPersistencyService assetEventPersistencyService;
    private EventsCleanupJob job;

    @Mock
    TenantDataSourceService tenantDataSourceService;

    @Before
    public void setupMock() {
        MockitoAnnotations.initMocks(this);
        job = new EventsCleanupJob();
        ReflectionTestUtils.setField( job, "jobTimeoutMillis", 864000000L );
        assetEventPersistencyService = mock(AssetEventPersistencyServiceImpl.class);
        ReflectionTestUtils.setField( job, "assetEventPersistencyService", assetEventPersistencyService );
        ReflectionTestUtils.setField(job, "tenantDataSourceService", tenantDataSourceService);

    }

    @Test
    public void testDoExecute() throws PersistencyServiceException {
        when(assetEventPersistencyService.cleanupEvents(anyString(), anyLong() + "")).thenReturn(1);
        job.doExecute();
    }

    @Test
    public void testDoExecuteException() throws PersistencyServiceException {
        when(assetEventPersistencyService.cleanupEvents(anyString(), anyLong() + "")).thenThrow(new
            PersistencyServiceException("Testing"));
        job.doExecute();
    }


}
