/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.audit.handler;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.flipkart.zjsonpatch.JsonDiff;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.alm.audit.model.ActionType;
import com.ge.apm.alm.audit.model.AuditPayload;
import com.ge.apm.alm.audit.model.AuditPayloadValue;
import com.ge.apm.alm.audit.util.AuditEventConstant;
import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.ObjectType;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetRestrictionFeature;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.TemplatePersistencyService;

/**
 * Created by Suraj Mohanan on 7/6/17.
 */
@Slf4j
@Component
public final class AuditlogHelper {


    public static final String INGESTOR = "_ingestor";

    public static final String VALUE = "value";

    public static final String ATTRIBUTES_ATTRIBUTES = "/attributes/attributes/";

    public static final String ATTRIBUTES_RESERVED_ATTRIBUTES = "/attributes/reservedAttributes/";

    public static final String KEY = "/key";

    public static final String ATTRIBUTE_SCHEMA_ATTRIBUTES = "/attributeSchema/attributes/";

    public static final String ATTRIBUTE_SCHEMA_RESERVED_ATTRIBUTES = "/attributeSchema/reservedAttributes/";

    public static final String EMPTY = "";

    public static final String SPACE = " ";

    public static final String FORE_SLASH = "/";

    public static final String NAME = "name";

    public static final String SOURCE_KEY = "sourceKey";

    public static final String PATH = "path";

    public static final String TEMPLATE_ID = "templateId";

    public static final String EMBEDDED_TEMPLATE_ID = "embeddedTemplateId";

    public static final String ASSET_ID = "assetId";

    public static final String NULL = "null";

    private static final String OBJECT_ASSET_USER_POLICY = "AssetUserPolicy";

    private static final String OBJECT_ASSET_GROUP_ASSOC = "AssetGroupAssociation";

    @Autowired
    private AssetPersistencyService assetService;

    @Autowired
    private GroupPersistencyService groupService;

    @Autowired
    private TemplatePersistencyService templatePersistencyService;

    @Autowired
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    private static final Map<String, Object> persistencyServices = new HashMap<>();

    private static final Set<String> objectTypes = new HashSet<>(20);


    @PostConstruct
    public void onPostConstruct() {
        log.debug("onPostConstruct() of AuditlogHelper here");
        persistencyServices.put(AssetPersistencyService.class.getSimpleName(), assetService);
        persistencyServices.put(GroupPersistencyService.class.getSimpleName(), groupService);
        persistencyServices.put(TemplatePersistencyService.class.getSimpleName(), templatePersistencyService);
        persistencyServices.put(AssetPolicyPersistencyService.class.getCanonicalName(), assetPolicyPersistencyService);

        objectTypes.add(OBJECT_ASSET_GROUP_ASSOC);
        objectTypes.add(OBJECT_ASSET_USER_POLICY);
    }

    private AuditlogHelper() {
    }

    public static List<AuditPayload> getAuditPayloads(List<AssetEvent> events, List<String> ignorableFieldsForPatch) {
        List<AuditPayload> payLoadList = new ArrayList<>();
        for (AssetEvent event: events) {
            try {
                AssetEvent.Type eventType = event.getEventType();

                boolean isContinue = validateEvent(event);

                if (isContinue) {
                    log.trace("Invalid record. Ignoring from audit log." + event.getId());
                    continue;
                }

                String sourceKey = getValue(event.getPreModifiedObject(), event.getModifiedObject(),
                        SOURCE_KEY, event.getEventType());
                String name = getValue(event.getPreModifiedObject(), event.getModifiedObject(), NAME, event
                    .getEventType());
                name = name == null ? EMPTY : name;
                switch (eventType) {
                    case CREATE:
                        getAuditPayloadForCreate(payLoadList, event, sourceKey, name);
                        break;
                    case UPDATE:
                        getAuditPayloadForUpdate(ignorableFieldsForPatch, payLoadList, event, sourceKey, name);
                        break;
                    case DELETE:
                        getAuditPayloadForDelete(payLoadList, event, sourceKey, name);
                        break;
                    default:break;

                }

            } catch (Exception ex) {
                log.error("Exception while populating audit payload: ", ex);
            }
        }
        return payLoadList;
    }

    private static boolean validateEvent(AssetEvent event) {
        boolean isContinue = false;
        Type eventType = event.getEventType();
        if (eventType == null) {
            isContinue = true;
        } else {
            boolean isCreateInvalid = eventType.equals(Type.CREATE) && event.getModifiedObject() == null;
            boolean isUpdateInvalid = eventType.equals(Type.UPDATE)
                && (event.getModifiedObject() == null || event.getPreModifiedObject() == null);
            boolean isDeleteInvalid = eventType.equals(Type.DELETE) && event.getPreModifiedObject() == null;
            if (isCreateInvalid || isUpdateInvalid || isDeleteInvalid) {
                isContinue = true;
            } else {
                String sourceKey = getValue(event.getPreModifiedObject(), event.getModifiedObject(),
                    SOURCE_KEY, event.getEventType());
                String name = getValue(event.getPreModifiedObject(), event.getModifiedObject(), NAME, event
                    .getEventType());
                if (!objectTypes.contains(event.getObjectType())
                    && StringUtils.isEmpty(sourceKey) && StringUtils.isEmpty(name)) {
                    isContinue = true;
                }
            }
        }
        return isContinue;
    }

    private static void getAuditPayloadForDelete(List<AuditPayload> payLoadList, AssetEvent event, String sourceKey,
                                                 String name) {
        StringBuilder deleteBuilder = new StringBuilder();

        if (ObjectType.ASSET_GROUP_ITEM.equals(event.getObjectType())) {
            String member = getValue(event.getPreModifiedObject(), event.getModifiedObject(),
                "member", event.getEventType());
            deleteBuilder.append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_DELETED)
                .append(event.getObjectType())
                .append(EMPTY)
                .append(EMPTY)
                .append(" " + member + " ")
                .append(" from the group ")
                .append(name + " (")
                .append(sourceKey + ")");
        } else if (OBJECT_ASSET_GROUP_ASSOC.equals(event.getObjectType())) {
            getAssetGroupAssociationDescription(event, deleteBuilder);
        } else if (OBJECT_ASSET_USER_POLICY.equals(event.getObjectType())) {
            getAssetUserPolicyDesc(event, deleteBuilder);
        } else {
            deleteBuilder.append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_DELETED)
                .append(event.getObjectType())
                .append(getDeletionReason(event))
                .append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_INSTANCE)
                .append(name + " (")
                .append(sourceKey + ")");
        }


        payLoadList
                .add(getAuditPayLoad(event.getTenantId(), ActionType.DELETE, deleteBuilder.toString(),
                        name, event));
    }

    /* Builds message for creation and deletion of asset group associations */
    private static void getAssetGroupAssociationDescription(AssetEvent event, StringBuilder builder) {
        String groupId = getValue(event.getPreModifiedObject(), event.getModifiedObject(),
            "groupId",
            event.getEventType());
        String objectId = getValue(event.getPreModifiedObject(), event.getModifiedObject(),
            "objectId",
            event.getEventType());
        Asset asset = ((AssetPersistencyService) persistencyServices.get(
            AssetPersistencyService.class.getSimpleName()))
            .getAssetById(event.getTenantId(), new ArrayList<>(), objectId);
        AssetGroup assetGroup = ((GroupPersistencyService) persistencyServices.get(
            GroupPersistencyService.class.getSimpleName())).getAssetGroupById(event.getTenantId(),
            groupId);

        // Customize message depending on whether action was create or delete
        if (event.getEventType().equals(Type.CREATE)) {
            builder
                .append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_ASSOCIATED)
                .append("group " + assetGroup.getSourceKey())
                .append(" with asset " + asset.getSourceKey());
        } else {
            builder
                .append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_DISASSOCIATED)
                .append("group " + assetGroup.getSourceKey())
                .append(" from asset " + asset.getSourceKey());
        }
    }

    private static void getAssetUserPolicyDesc(AssetEvent event, StringBuilder builder) {
        String policyName;
        String userName = null;
        String userGroupName = null;
        String subjectType;
        String featureCode;
        if (event.getEventType().equals(Type.CREATE)) {
            builder.append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_ASSOCIATED);
            featureCode = getValue(event.getModifiedObject(), "featureCode");
            subjectType = getValue(event.getModifiedObject(), "subjectType");
            if (Objects.nonNull(subjectType)
                    && subjectType.equals(AuditEventConstant.AUDIT_EVENT_MESSAGE_USER.trim())) {
                userName = getValue(event.getModifiedObject(), "userName");
            } else {
                userGroupName = getValue(event.getModifiedObject(), "displayName");
            }
        } else {
            builder.append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_DISASSOCIATED);
            featureCode = getValue(event.getPreModifiedObject(), "featureCode");
            subjectType = getValue(event.getPreModifiedObject(), "subjectType");
            if (Objects.nonNull(subjectType)
                    && subjectType.equals(AuditEventConstant.AUDIT_EVENT_MESSAGE_USER.trim())) {
                userName = getValue(event.getPreModifiedObject(), "userName");
            } else {
                userGroupName = getValue(event.getPreModifiedObject(), "displayName");
            }
        }
        AssetRestrictionFeature feature =
                ((AssetPolicyPersistencyService) persistencyServices.get(AssetPolicyPersistencyService.class.getName()))
                        .getAssetRestrictionFeatureByCode(featureCode);
        policyName = Objects.nonNull(feature) ? feature.getName() : EMPTY;
        builder.append(event.getObjectType()).append(" (").append(policyName)
                .append(") ").append(AuditEventConstant.AUDIT_EVENT_MESSAGE_WITH);
        if (Objects.nonNull(subjectType) && subjectType.equals(AuditEventConstant.AUDIT_EVENT_MESSAGE_USER.trim())) {
            builder.append(AuditEventConstant.AUDIT_EVENT_MESSAGE_USER)
                    .append("(").append(userName).append(")");
        } else {
            builder.append(AuditEventConstant.AUDIT_EVENT_MESSAGE_USER_GROUP)
                    .append("(").append(userGroupName).append(")");
        }
    }

    private static String getDeletionReason(AssetEvent event) {
        String deletionReason = EMPTY;
        if (event.getModifiedObject() != null && event.getModifiedObject().get("deletedReason") != null) {
            String reason = event.getModifiedObject().get("deletedReason").textValue();
            if (!StringUtils.isEmpty(reason)) {
                deletionReason = AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_DELETION_REASON + reason;
            }
        }
        return deletionReason;
    }

    private static void getAuditPayloadForUpdate(List<String> ignorableFieldsForPatch, List<AuditPayload> payLoadList,
                                                 AssetEvent event, String sourceKey, String name) {
        List<AuditPayloadValue> payloadValueList =
            populateAuditPayloadValues(event, ignorableFieldsForPatch);
        List<AuditPayload> tempPayloadList = new ArrayList<>();

        payloadValueList.forEach(o -> {
            StringBuilder updateBuilder = new StringBuilder();
            if (ObjectType.PLACEHOLDER.equals(event.getObjectType()) && (o.getAttributeName().contains("associations")
                || o.getAttributeName().contains("tagAssociations"))) {
                //Existing association types are not captured using the current template update method.
                buildAuditForTemplateUpdate(sourceKey, name, o, updateBuilder);
            } else {
                buildForAuditUpdate(sourceKey, name, o, updateBuilder);
            }
            tempPayloadList.add(getAuditPayLoad(event.getTenantId(), ActionType.UPDATE,
                            updateBuilder.toString(), o.getSourceName(), event));
        });

        if (tempPayloadList.size() > 1) { //Create unique correlation id when more than one attributes are updated.
            for (int i = 1; i < tempPayloadList.size(); i++) {
                tempPayloadList.get(i).setEventId(UUID.randomUUID().toString());
            }
        }

        payLoadList.addAll(tempPayloadList);
    }

    private static void buildForAuditUpdate(String sourceKey, String name, AuditPayloadValue o,
        StringBuilder updateBuilder) {
        updateBuilder
            .append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_UPDATED)
            .append(name + " (")
            .append(sourceKey + ")")
            .append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_ATTRIBUTE)
            .append(o.getAttributeName())
            .append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_FROM)
            .append(o.getOldValue())
            .append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_TO)
            .append(o.getNewValue());
    }

    private static void buildAuditForTemplateUpdate(String sourceKey, String name, AuditPayloadValue o,
        StringBuilder updateBuilder) {
        updateBuilder
            .append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_UPDATED)
            .append(name + " (")
            .append(sourceKey + ")")
            .append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_ATTRIBUTE)
            .append(o.getAttributeName())
            .append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_TO)
            .append(o.getNewValue());
    }

    private static void getAuditPayloadForCreate(List<AuditPayload> payLoadList, AssetEvent event, String sourceKey,
                                                 String name) {
        StringBuilder builder = new StringBuilder();

        if (OBJECT_ASSET_GROUP_ASSOC.equals(event.getObjectType())) {
            getAssetGroupAssociationDescription(event, builder);
        } else if (OBJECT_ASSET_USER_POLICY.equals(event.getObjectType())) {
            getAssetUserPolicyDesc(event, builder);
        } else {
            builder.append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_CREATED)
                .append(event.getObjectType())
                .append(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_INSTANCE)
                .append(name + " (")
                .append(sourceKey + ")");
        }
        payLoadList
                .add(getAuditPayLoad(event.getTenantId(), ActionType.CREATE, builder.toString(), name,
                        event));
    }

    private static String getValue(JsonNode existingNode, JsonNode modifiedNode,
                                   String nodeName, AssetEvent.Type eventType) {
        return eventType == AssetEvent.Type.CREATE
                ? getValue(modifiedNode, nodeName)
                : getValue(existingNode, nodeName);
    }

    private static String getValue(JsonNode node, String nodeName) {
        return node == null || node.path(nodeName) == null ? EMPTY : node.path(nodeName).asText();
    }

    private static List<AuditPayloadValue> populateAuditPayloadValues(AssetEvent event,
                                                              List<String> ignorableFieldsForPatch) {
        List<AuditPayloadValue> auditPayloadValuesList = new ArrayList<>();
        try {
            JsonNode existingObject = event.getPreModifiedObject();
            JsonNode newObject = event.getModifiedObject();
            JsonNode patchNode = JsonDiff.asJson(existingObject, newObject);

            List<AuditPayloadValue> tempAuditPayloadValuesList = new ArrayList<>();
            StreamSupport.stream(patchNode.spliterator(), false)
                .filter(node -> {
                    String path = node.get(PATH).asText();
                    String field = path.replaceFirst(FORE_SLASH, EMPTY);
                    return isIgnorableUpdate(event, ignorableFieldsForPatch, path, field);
                })
                .forEach(filteredNode -> {
                    String path = filteredNode.get(PATH).asText();
                    String newVal = getStringValue(filteredNode.get(VALUE));
                    String oldVal = getStringValue(existingObject.at(path));
                    String name = getValue(existingObject, NAME);
                    String sourceKey = getValue(existingObject, SOURCE_KEY);

                    AuditPayloadValue auditPayloadValue = new AuditPayloadValue();
                    auditPayloadValue.setNewValue(newVal);
                    auditPayloadValue.setOldValue(oldVal);
                    auditPayloadValue.setPath(path);
                    auditPayloadValue.setAttributeName(path);
                    auditPayloadValue.setSourceName(name);
                    auditPayloadValue.setSourceKey(sourceKey);

                    String action = filteredNode.get("op").asText();

                    populateAuditPayloadAction(auditPayloadValue, action);

                    updateParent(auditPayloadValue, event);
                    modifyTemplateInfo(auditPayloadValue, event);

                    tempAuditPayloadValuesList.add(auditPayloadValue);
                });

            tempAuditPayloadValuesList.sort(Comparator.comparing(AuditPayloadValue::getPath));

            Map<String, AuditPayloadValue> groupedPrimitiveArrayValues = new ConcurrentHashMap();

            tempAuditPayloadValuesList.forEach(value -> {
                updateAttributeName(newObject, value);
                modifyPayloadValues(auditPayloadValuesList, existingObject, newObject, groupedPrimitiveArrayValues,
                    value);
            });

            auditPayloadValuesList.addAll(groupedPrimitiveArrayValues.values());


        } catch (Exception ex) {
            log.error("Exception while creating the audit payload for update event with id:" + event.getId(), ex);
        }
        return auditPayloadValuesList.stream()
            .filter(p -> {
                String oldValue = p.getOldValue();
                String newValue = p.getNewValue();
                boolean filter = true;
                if (StringUtils.isEmpty(oldValue) && StringUtils.isEmpty(newValue)) {
                    filter = false;
                } else if (!StringUtils.isEmpty(oldValue)) {
                    filter = !oldValue.equals(newValue);
                } else if (!StringUtils.isEmpty(newValue)) {
                    filter = !newValue.equals(oldValue);
                }
                return filter;
            })
            .peek(p -> {
                if (StringUtils.isEmpty(p.getOldValue())) {
                    p.setOldValue("NIL");
                }
                if (StringUtils.isEmpty(p.getNewValue())) {
                    p.setNewValue("NIL");
                }
            })
            .collect(Collectors.toList());
    }

    private static boolean isIgnorableUpdate(AssetEvent event, List<String> ignorableFieldsForPatch, String path,
        String field) {
        boolean ignoreFlag = !ignorableFieldsForPatch.contains(field);
        //The fields those should be ignored should be handled as a key (using object type) value pair later.
        if (ignoreFlag) {
            ignoreFlag = isIgnorableTemplateUpdate(event, ignorableFieldsForPatch, path);
        }
        if (ignoreFlag && "Edge".equalsIgnoreCase(event.getObjectType())
            && (path.startsWith("/source") || path.startsWith(
            "/target"))) {
            ignoreFlag = false;
        }
        return ignoreFlag;
    }

    private static boolean isIgnorableTemplateUpdate(AssetEvent event, List<String> ignorableFieldsForPatch,
        String path) {
        boolean ignoreFlag = true;
        if (ObjectType.TEMPLATE.equalsIgnoreCase(event.getObjectType())) {
            if (path.startsWith("/placeholders")) {
                ignoreFlag = false;
            } else if (path.contains("/notes")) {
                ignoreFlag = isIgnorableNotesUpdate(ignorableFieldsForPatch, path);
            } else if (path.contains("/templateNotes") && path.contains("/id")) {
                ignoreFlag = false;
            }
        }
        return ignoreFlag;
    }

    private static boolean isIgnorableNotesUpdate(List<String> ignorableFieldsForPatch, String path) {
        boolean flag = true;
        for (String f: ignorableFieldsForPatch) {
            if (path.contains(f)) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    private static void modifyPayloadValues(List<AuditPayloadValue> auditPayloadValuesList,
        JsonNode existingObject, JsonNode newObject, Map<String, AuditPayloadValue> groupedPrimitiveArrayValues,
        AuditPayloadValue value) {

        String path = value.getPath();
        String[] splitPath = path.split(FORE_SLASH);
        if (splitPath.length > 1 && splitPath[splitPath.length - 1].matches("\\d+")) {

            String primitiveArrayKey =  trimArrayIndexFromPath(path, splitPath);


            JsonNode childNodes = newObject.at(path);
            if (StringUtils.isEmpty(childNodes.asText())) {
                childNodes = existingObject.at(path);
            }
            if (childNodes.isTextual() || childNodes.isNumber()) {
                groupPrimitiveArrayValues(existingObject, newObject, groupedPrimitiveArrayValues, value, path,
                    splitPath, primitiveArrayKey);
            } else {
                auditPayloadValuesList.add(value);
            }
        } else {
            auditPayloadValuesList.add(value);
        }
    }

    private static void groupPrimitiveArrayValues(JsonNode existingObject, JsonNode newObject,
        Map<String, AuditPayloadValue> groupedPrimitiveArrayValues, AuditPayloadValue value, String path,
        String[] splitPath, String primitiveArrayKey) {
        int index;
        String attrName = value.getAttributeName();
        if (splitPath[splitPath.length - 2].matches(VALUE)) {
            index = attrName.lastIndexOf("/value/" + splitPath[splitPath.length - 1]);
        } else {
            index = attrName.lastIndexOf(FORE_SLASH + splitPath[splitPath.length - 1]);
        }

        String updatedAttrName = attrName.substring(0, index);
        if (!groupedPrimitiveArrayValues.containsKey(primitiveArrayKey)) {
            JsonNode oldValueNode = existingObject.at(primitiveArrayKey);
            JsonNode newValueNode = newObject.at(primitiveArrayKey);
            String newValue = getStringValue(newValueNode);
            String oldValue = getStringValue(oldValueNode);

            AuditPayloadValue auditPayloadValues = new AuditPayloadValue();
            auditPayloadValues.setNewValue(newValue);
            auditPayloadValues.setOldValue(oldValue);
            auditPayloadValues.setPath(path);
            auditPayloadValues.setSourceName(value.getSourceName());
            auditPayloadValues.setSourceKey(value.getSourceKey());
            auditPayloadValues.setAttributeName(updatedAttrName);
            auditPayloadValues.setAction(value.getAction());
            groupedPrimitiveArrayValues.put(primitiveArrayKey, auditPayloadValues);
        }
    }

    private static String trimArrayIndexFromPath(String path, String... splitPath) {
        StringBuilder pathKey = new StringBuilder();
        if (splitPath[splitPath.length - 1].matches("\\d+")) {
            for (int i = 1; i < splitPath.length - 1; i++) {
                pathKey.append(FORE_SLASH + splitPath[i]);
            }
        } else {
            pathKey.append(path);
        }
        return pathKey.toString();
    }

    private static void updateAttributeName(JsonNode newObject, AuditPayloadValue value) {
        String attrName;
        String path = value.getPath();
        if (path.contains(ATTRIBUTES_ATTRIBUTES)) {
            attrName = path.replace(ATTRIBUTES_ATTRIBUTES, EMPTY);
            if (value.getAction().equals(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_CREATED)) {
                //When a new attribute itself created.
                JsonNode newValue = newObject.at(path);
                String newVal = getStringValue(newValue.get(VALUE));
                value.setNewValue(newVal);
            }
        } else if (path.contains(ATTRIBUTES_RESERVED_ATTRIBUTES)) { //Remove the strings
            // /attributes/reservedAttributes/ and '/key' from attr name
            attrName = path.replace(ATTRIBUTES_RESERVED_ATTRIBUTES, EMPTY);
            if (attrName.endsWith(KEY)) {
                int index = attrName.lastIndexOf(KEY);
                attrName = attrName.substring(0, index);
            }
        } else if (path.contains(ATTRIBUTE_SCHEMA_ATTRIBUTES)) {
            attrName = path.replaceFirst(ATTRIBUTE_SCHEMA_ATTRIBUTES, EMPTY);
        } else if (path.contains(ATTRIBUTE_SCHEMA_RESERVED_ATTRIBUTES)) {
            attrName = path.replaceFirst(ATTRIBUTE_SCHEMA_RESERVED_ATTRIBUTES, EMPTY);
        } else {
            attrName = path.replaceFirst(FORE_SLASH, EMPTY);
        }
        value.setAttributeName(attrName);
    }

    private static String getStringValue(JsonNode jsonNode) {
        String value;
        if (jsonNode == null || jsonNode.isNull()) {
            value = null;
        } else if (jsonNode.isArray()) {
            StringBuilder valueBuilder = new StringBuilder();
            boolean isFirstIteration = true;
            for (JsonNode node: jsonNode) {
                if (isFirstIteration) {
                    isFirstIteration = false;
                } else {
                    valueBuilder.append(", ");
                }
                valueBuilder.append(node.isTextual() ? node.asText() : node.toString());
            }
            value = valueBuilder.toString();
        } else if (jsonNode.isTextual()) {
            value = jsonNode.asText();
        } else {
            value = jsonNode.toString();
        }
        return value;
    }

    private static void populateAuditPayloadAction(AuditPayloadValue auditPayloadValues, String op) {
        switch (op) {
            case "replace": auditPayloadValues.setAction(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_UPDATED);
            break;
            case "add": auditPayloadValues.setAction(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_CREATED);
            break;
            case "remove": auditPayloadValues.setAction(AuditEventConstant.AUDIT_EVENT_MESSAGE_DESCRIPTION_DELETED);
            break;
            default:break;
        }
    }

    private static void updateParent(AuditPayloadValue auditPayloadValue, AssetEvent event) {
        if (("/parentId").equals(auditPayloadValue.getPath())) {
            auditPayloadValue.setPath("/parent");
            String oldParentId = auditPayloadValue.getOldValue();
            String newParentId = auditPayloadValue.getNewValue();
            AssetPersistencyService service = (AssetPersistencyService)
                persistencyServices.get(AssetPersistencyService.class.getSimpleName());
            if (!StringUtils.isEmpty(oldParentId)) {
                Asset oldParent = service.getAssetById(event.getTenantId(), new ArrayList<>(), oldParentId);
                auditPayloadValue.setOldValue(oldParent == null ? null : oldParent.getSourceKey());
            }
            if (!StringUtils.isEmpty(newParentId)) {
                Asset newParent = service.getAssetById(event.getTenantId(), new ArrayList<>(), newParentId);
                auditPayloadValue.setNewValue(newParent == null ? null : newParent.getSourceKey());
            }
        }
    }

    private static void modifyTemplateInfo(AuditPayloadValue auditPayloadValue, AssetEvent event) {
        if (auditPayloadValue.getPath().endsWith("/templateInfo")) {
            JsonNode existingObject = event.getPreModifiedObject();
            JsonNode newObject = event.getModifiedObject();
            JsonNode existingTemplateInfo = existingObject.at(auditPayloadValue.getPath());
            JsonNode newTemplateInfo = newObject.at(auditPayloadValue.getPath());
            modifyTemplateInfo(event, existingObject, existingTemplateInfo);
            modifyTemplateInfo(event, newObject, newTemplateInfo);
            auditPayloadValue.setNewValue(getStringValue(newTemplateInfo));
            auditPayloadValue.setOldValue(getStringValue(existingTemplateInfo));
        }
    }

    private static void modifyTemplateInfo(AssetEvent event, JsonNode assetObject, JsonNode templateInfo) {

        if (templateInfo != null) {
            final String assetId = getValue(templateInfo, ASSET_ID);

            if (templateInfo.has(ASSET_ID) && !StringUtils.isEmpty(assetId) && !NULL.equals(assetId)) {
                ((ObjectNode) templateInfo).put(ASSET_ID, getValue(assetObject, SOURCE_KEY));
            }

            final String templateId = getValue(templateInfo, TEMPLATE_ID);

            if (templateInfo.has(TEMPLATE_ID) && !StringUtils.isEmpty(templateId)
                    && !NULL.equals(templateId)) {
                TemplatePersistencyService service = (TemplatePersistencyService)
                        persistencyServices.get(TemplatePersistencyService.class.getSimpleName());
                Template template = service.getTemplateById(event.getTenantId(), templateId);
                ((ObjectNode) templateInfo).put(TEMPLATE_ID, template.getSourceKey());
            }

            final String embeddedTemplateId = getValue(templateInfo, EMBEDDED_TEMPLATE_ID);

            if (templateInfo.has(EMBEDDED_TEMPLATE_ID) && !StringUtils.isEmpty(embeddedTemplateId)
                    && !NULL.equals(embeddedTemplateId)) {
                TemplatePersistencyService service = (TemplatePersistencyService)
                        persistencyServices.get(TemplatePersistencyService.class.getSimpleName());
                Template template = service.getTemplateById(event.getTenantId(), embeddedTemplateId);
                ((ObjectNode) templateInfo).put(EMBEDDED_TEMPLATE_ID, template.getSourceKey());
            }
        }
    }

    private static AuditPayload getAuditPayLoad(String tenantId, ActionType actionType, String desc,
        String name, AssetEvent event) {
        String action = "";
        // Customize event Action type if asset group association
        if (objectTypes.contains(event.getObjectType())) {
            if (actionType.getActionType().equalsIgnoreCase(Type.CREATE.name())) {
                action = "Associate";
            } else if (actionType.getActionType().equalsIgnoreCase(Type.DELETE.name())) {
                action = "Disassociate";
            }
        } else {
            action = actionType.getActionType();
        }

        return AuditPayload.builder()
            .actionType(action)
            .originator(AuditEventConstant.AUDIT_EVENT_MESSAGE_ORIGINATOR)
            .tenantUUID(tenantId)
            .actorUUID(event.getLastModifiedBy() == null ? tenantId + INGESTOR : event.getLastModifiedBy())
            .resource(event.getObjectType() + SPACE + name)
            .resourceUUID(EMPTY).batchUUID(EMPTY)
            .description(desc)
            .actor(event.getLastModifiedBy() == null ? tenantId + INGESTOR : event.getLastModifiedBy())
            .actorDisplayName(event.getLastModifiedBy() == null
                ? tenantId + INGESTOR :  event.getLastModifiedBy())
            .eventId(event.getId()).build();
    }

    public static List<AuditPayload> getAuditPayLoad(String tenantId, String reason, String context, String code,
        String user, String actor) {
        List<AuditPayload> auditLogs = new ArrayList<>();
        auditLogs.add(createAuditPayLoad(tenantId, reason, context, code, user, actor));
        return auditLogs;
    }

    private static AuditPayload createAuditPayLoad(String tenantId, String reason, String context, String code, String
        user, String actor) {
        StringBuilder detail = new StringBuilder();
        detail.append(reason).append(SPACE).append("ALM configuration ").append(context).append(SPACE).append(code);
        return AuditPayload.builder().actionType(ActionType.DELETE.getActionType())
            .originator(AuditEventConstant.AUDIT_EVENT_MESSAGE_ORIGINATOR)
            .tenantUUID(tenantId)
            .actorUUID(user)
            .resource(context + SPACE + code)
            .description(detail.toString())
            .actor(actor)
            .actorDisplayName(actor)
            .build();
    }


}
