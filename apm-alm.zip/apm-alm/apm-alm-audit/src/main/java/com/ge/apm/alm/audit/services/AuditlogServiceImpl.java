/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.audit.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import com.ge.apm.alm.audit.model.AuditPayLoadEnum;
import com.ge.apm.alm.audit.model.AuditPayload;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.EventsJobType;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.service.instances.ServiceInstances;
import com.ge.apm.service.tenants.TenantsUtil;
import com.ge.predix.audit.sdk.AuditCallback;
import com.ge.predix.audit.sdk.AuditClient;
import com.ge.predix.audit.sdk.AuditClientType;
import com.ge.predix.audit.sdk.FailReport;
import com.ge.predix.audit.sdk.config.AuditConfiguration;
import com.ge.predix.audit.sdk.exception.AuditException;
import com.ge.predix.audit.sdk.message.AuditEnums;
import com.ge.predix.audit.sdk.message.AuditEvent;
import com.ge.predix.audit.sdk.message.AuditEventV2;
import com.ge.predix.audit.sdk.validator.ValidatorReport;
import com.ge.predix.eventhub.EventHubClientException;


@ConditionalOnProperty("apm.asset.auditlog.job.enabled")
@Service
@Slf4j
public class AuditlogServiceImpl implements IAuditlogService {

    private AuditClient auditClient;

    @Value("${asset.audit.event.hub.host}")
    private String ehubHost;

    @Value("${asset.audit.event.hub.zone.id}")
    private String ehubZoneId;

    @Value("${stuf.trustedIssuer}")
    private String uaaUri;

    @Value("${asset.audit.client.id}")
    private String clientId;

    @Value("${asset.audit.client.secret}")
    private String clientSecret;

    @Value("${asset.audit.tracing.interval:600000}")
    private String tracingInterval;

    @Value("${asset.audit.tracing.token:NULL}")
    private String tracingToken;

    @Value("${asset.audit.tracing.url:NULL}")
    private String tracingUrl;

    @Value("${apm.asset.auditlog.job.size:100}")
    private Integer jobSize;

    @Value("${apm.asset.auditlog.schedule.interval:29000}")
    private Long batchWaitTime;

    @Autowired
    private ServiceInstances serviceInstances;

    @Autowired
    private TenantsUtil tenantsUtil;

    @Autowired
    private AssetEventPersistencyService assetEventPersistencyService;

    private final Set<String> downloadedTenants = new HashSet<>();
    private final Lock tenantsLock = new ReentrantLock();
    private final Object ack = new Object();
    private final List<String> successEvents = new ArrayList<>();
    private Long elapsedTime = System.currentTimeMillis() + 29000L;
    private final Map<String, String> messageIdsToTenantMap = new ConcurrentHashMap<>();
    private final Map<String, List<String>> tenantIdToMessageIdsMap = new HashMap<>();

    public AuditCallback auditCallback() {
        return new AuditCallback() {
            @Override
            public void onValidate(AuditEvent auditEvent, List<ValidatorReport> list) {
                log.info("onValidate");
            }

            @Override
            public void onFailure(AuditEvent auditEvent, FailReport failReport, String description) {
                log.error("Audit log failed for {}, {}, {} ", auditEvent.getMessageId() , failReport , description);
                auditLogOnFailure(failReport);
            }

            @Override
            public void onFailure(FailReport failReport, String description) {
                auditLogOnFailure(failReport);
            }

            @Override
            public void onSuccees(AuditEvent auditEvent) {
                auditLogOnSuccess(auditEvent);
            }
        };
    }

    private void auditLogOnSuccess(AuditEvent auditEvent) {
        log.trace(String.format("Successful Audit Message Posted :: %s", auditEvent.getMessageId()));
        try {
            updateEventsStatus(auditEvent.getMessageId());
        } catch (PersistencyServiceException ex) {
            log.error(ex.getMessage(), ex);
        }
    }

    private void auditLogOnFailure(FailReport failReport) {
        if (failReport == FailReport.STREAM_IS_CLOSE) {
            log.error("Audit Service is not reachable, trying to reconnect {} ", failReport);
            try {
                auditClient.reconnect();
            } catch (EventHubClientException ex) {
                log.error(ex.getMessage(), ex);
            }
        }
    }

    private String getPayLoadJsonData(AuditPayload payLoad) {
        ObjectNode objectNode = JsonNodeFactory.instance.objectNode();
        objectNode.put(AuditPayLoadEnum.ACTION_TYPE.getValue(), payLoad.getActionType());
        objectNode.put(AuditPayLoadEnum.ORIGINATOR.getValue(), payLoad.getOriginator());
        objectNode.put(AuditPayLoadEnum.TENANT_UUID.getValue(), payLoad.getTenantUUID());
        objectNode.put(AuditPayLoadEnum.ACTOR_UUID.getValue(), payLoad.getActorUUID());
        objectNode.put(AuditPayLoadEnum.RESOURCE.getValue(), payLoad.getResource());
        objectNode.put(AuditPayLoadEnum.RESOURCE_UUID.getValue(), payLoad.getResourceUUID());
        objectNode.put(AuditPayLoadEnum.BATCH_UUID.getValue(), payLoad.getBatchUUID());
        objectNode.put(AuditPayLoadEnum.ACTOR.getValue(), payLoad.getActor());
        objectNode.put(AuditPayLoadEnum.ACTOR_DISPLAY_NAME.getValue(), payLoad.getActorDisplayName());
        objectNode.put(AuditPayLoadEnum.DESCRIPTION.getValue(), payLoad.getDescription());
        return objectNode.toString();
    }

    @Override
    public void publishAsync(List<AuditPayload> payloads) throws AuditException, EventHubClientException {
        log.debug("Processing Auditlog messages of size {} ", payloads.size());
        List<AuditPayload> subList = payloads.size() > 999 ? payloads.subList(0, 999) : payloads;
        List<AuditEvent> eventList = new ArrayList<>();
        createAuditClient();
        for (AuditPayload load : subList) {
            boolean isOldTenantFound = false;
            String oldTenantId = unFormatTenantId(load.getTenantUUID());
            if (!downloadedTenants.contains(load.getTenantUUID())
                    && !downloadedTenants.contains(oldTenantId)) {
                populateTenants();
            }
            isOldTenantFound = downloadedTenants.contains(oldTenantId);

            AuditEvent eventV2 = AuditEventV2.builder()
                    .payload(getPayLoadJsonData(load))
                    .classifier(AuditEnums.Classifier.SUCCESS)
                    .publisherType(AuditEnums.PublisherType.APP_SERVICE)
                    .categoryType(AuditEnums.CategoryType.API_CALLS)
                    .eventType(AuditEnums.EventType.SUCCESS_API_REQUEST)
                    .tenantUuid(isOldTenantFound ? oldTenantId : load.getTenantUUID())
                    .correlationId(load.getEventId())
                    .messageId(load.getEventId())
                    .build();
            eventList.add(eventV2);
            messageIdsToTenantMap.put(load.getEventId(), load.getTenantUUID());
        }
        auditClient.audit(eventList);
    }

    @Override
    public int updateAuditlogPubStatus(String eventId) throws PersistencyServiceException {
        return assetEventPersistencyService.updateEvent(
                eventId, AssetEvent.EventsJobType.AUDIT, AssetEvent.EventStatus.COMPLETED.name());
    }

    private void updateEventsStatus(String eventId) throws PersistencyServiceException {
        successEvents.add(eventId);
        if (successEvents.size() >= jobSize || System.currentTimeMillis() > elapsedTime) {
            log.debug("Updating the Auditlog acks status with batch size {} : ", successEvents.size());
            List<String> events = new ArrayList<>(successEvents);
            successEvents.clear();
            updateEventsStatus(events);
        }
    }

    private void updateEventsStatus(List<String> events) throws PersistencyServiceException {
        if (!messageIdsToTenantMap.keySet().containsAll(events)) {
            return;
        }

        Map<String, List<String>> tenantToEvents = events.stream().collect(Collectors.groupingBy(eventId ->
            messageIdsToTenantMap.get(eventId)));

        synchronized (ack) {
            tenantIdToMessageIdsMap.putAll(tenantToEvents);
            for (Map.Entry<String, List<String>> entry : tenantIdToMessageIdsMap.entrySet()) {
                try {
                    RequestContext.put(RequestContext.TENANT_UUID, entry.getKey());
                    assetEventPersistencyService.updateEventsStatus(entry.getValue(),
                        EventsJobType.AUDIT, AssetEvent.EventStatus.COMPLETED.name());
                } finally {
                    messageIdsToTenantMap.keySet().removeAll(tenantIdToMessageIdsMap.get(entry.getKey()));
                    RequestContext.destroy();
                }
            } //End of for loop
            tenantIdToMessageIdsMap.clear();
            elapsedTime = System.currentTimeMillis() + (batchWaitTime - 1000);
        } //End of sync
    }

    private void createAuditClient() throws AuditException, EventHubClientException {
        if (auditClient == null) {
            AuditConfiguration auditConfiguration = getAuditConfiguration();
            log.debug("Auditlog Service Details URI : {}  ", auditConfiguration);
            auditConfiguration.setClientType(AuditClientType.ASYNC);
            auditClient = new AuditClient(auditConfiguration, auditCallback());
        }
    }

    private AuditConfiguration getAuditConfiguration() {
        Integer port = null;
        String host = "";

        if (ehubHost != null && ehubHost.contains(":")) {
            String[] ehub = ehubHost.split(":");
            if (ehub != null && ehub.length > 1) {
                host = ehub[0];
                port = Integer.parseInt(ehub[1]);
            }
        }
        return AuditConfiguration.builder()
                .bulkMode(true)
                .clientType(AuditClientType.ASYNC)
                .uaaUrl(uaaUri)
                .uaaClientId(clientId)
                .uaaClientSecret(clientSecret)
                .ehubZoneId(ehubZoneId)
                .ehubHost(host)
                .ehubPort(port)
                .tracingInterval(Long.parseLong(tracingInterval))
                .tracingToken(tracingToken)
                .tracingUrl(tracingUrl)
                .build();
    }

    private String unFormatTenantId(String tenantId) {
        return StringUtils.isNotEmpty(tenantId)
            ? tenantId.replaceAll("-", "").toUpperCase() : tenantId;
    }

    private void populateTenants() {
        if (tenantsLock.tryLock()) {
            try {
                downloadedTenants.clear();

                List<ServiceInstances.TenantInfo> tenants = tenantsUtil.getAllTenantServiceInfo();
                for (ServiceInstances.TenantInfo tenantInfo : tenants) {
                    downloadedTenants.add(tenantInfo.getTenantUuid());
                }
            } finally {
                tenantsLock.unlock();
            }
        }
    }


}