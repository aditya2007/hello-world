/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.audit.util;

public class AuditEventConstant {
    public static final String AUDIT_EVENT_MESSAGE_DESCRIPTION_FROM = " from ";
    public static final String AUDIT_EVENT_MESSAGE_DESCRIPTION_UPDATED = "Updated ";
    public static final String AUDIT_EVENT_MESSAGE_DESCRIPTION_ATTRIBUTE = " attribute ";
    public static final String AUDIT_EVENT_MESSAGE_DESCRIPTION_TO = " to ";
    public static final String AUDIT_EVENT_MESSAGE_DESCRIPTION_CREATED = "Created ";
    public static final String AUDIT_EVENT_MESSAGE_DESCRIPTION_DELETED = "Deleted ";
    public static final String AUDIT_EVENT_MESSAGE_DESCRIPTION_DELETION_REASON = " reason ";
    public static final String AUDIT_EVENT_MESSAGE_DESCRIPTION_INSTANCE = " instance ";
    public static final String AUDIT_EVENT_MESSAGE_ORIGINATOR = "APM Asset";
    public static final String AUDIT_EVENT_MESSAGE_DESCRIPTION_ASSOCIATED = "Associated ";
    public static final String AUDIT_EVENT_MESSAGE_DESCRIPTION_DISASSOCIATED = "Disassociated ";
    public static final String AUDIT_EVENT_MESSAGE_USER = "User ";
    public static final String AUDIT_EVENT_MESSAGE_USER_GROUP = "UserGroup ";
    public static final String AUDIT_EVENT_MESSAGE_WITH = "with ";

}
