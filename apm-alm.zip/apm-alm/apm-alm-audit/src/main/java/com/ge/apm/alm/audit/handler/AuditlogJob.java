/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.audit.handler;

import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.audit.model.AuditPayload;
import com.ge.apm.alm.audit.services.IAuditlogService;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.EventsJobType;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.datasource.TenantDataSourceService;

/**
 * Created by Suraj Mohanan on 7/6/17.
 */
@ConditionalOnProperty("apm.asset.auditlog.job.enabled")
@Component
@Slf4j
public class AuditlogJob {

    @Autowired
    private AssetEventPersistencyService eventService;

    @Autowired
    IAuditlogService auditPublisherService;


    @Value("${apm.asset.auditlog.job.size:100}")
    private Integer jobSize;

    @Value("${apm.asset.auditlog.job.timeout:60000}")
    private Long jobTimeoutMillis;

    @Value("${apm.asset.cleanup.job.timeout:864000000}")
    private Long expiredTimeoutMillis;

    @Value("#{'${asset.audit.ignorableFields}'.split(',')}")
    private List<String> ignorableFieldsForPatch;

    @Autowired
    private TenantDataSourceService tenantDataSourceService;

    @Scheduled(fixedRateString = "${apm.asset.auditlog.schedule.interval}")
    public void doExecute() {

        for (String tenantId : getDatabases()) {
            auditJob(tenantId);
        }
    }

    private void auditJob(String tenantId) {
        log.debug("Running Auditlog job for tenant {} ", tenantId);
        RequestContext.put(RequestContext.TENANT_UUID, tenantId);
        RequestContext.put("AccessibleResources", new String[] {"*"});
        boolean canInterupt = false;
        try {
            List<AssetEvent> events = eventService.getPendingEventBatch(
                    EventsJobType.AUDIT, jobSize, jobTimeoutMillis, expiredTimeoutMillis);
            if (CollectionUtils.isEmpty(events)) {
                log.debug("No Auditlog events found for tenant {} ", tenantId);
                return;
            } else {
                log.debug("Processing Auditlogjob with {} events for tenant {}.", events.size(), tenantId);
                List<AuditPayload> auditPayloads = AuditlogHelper.getAuditPayloads(events, ignorableFieldsForPatch);
                if (!CollectionUtils.isEmpty(auditPayloads)) {
                    auditPublisherService.publishAsync(auditPayloads);
                }
                List<String> eventIds = auditPayloads.stream().map(AuditPayload::getEventId).collect(
                    Collectors.toList());

                List<AssetEvent> noAuditList = events.stream().filter(event -> !eventIds.contains(event.getId()))
                    .collect(Collectors.toList());
                noAuditList.forEach(this::updateAuditEventStatus);
            }
        } catch (Exception ex) {
            log.error("Exception while processing Auditlog events {}, for tenant {} ", ex, tenantId);
            canInterupt = true;
        } finally {
           if (canInterupt) {
                Thread.currentThread().interrupt();
            }
            RequestContext.destroy();
        }
    }

    private void updateAuditEventStatus(AssetEvent e) {
        try {
            auditPublisherService.updateAuditlogPubStatus(e.getId());
        } catch (PersistencyServiceException ex) {
            log.error(ex.getMessage(), ex);
        }
    }

    private HashSet<String> getDatabases() {
        HashSet<String> set = new HashSet<>();
        set.add(TenantDataSourceService.DEFAULT_DATASOURCE);
        set.addAll(tenantDataSourceService.getTenants());
        return set;
    }
}
