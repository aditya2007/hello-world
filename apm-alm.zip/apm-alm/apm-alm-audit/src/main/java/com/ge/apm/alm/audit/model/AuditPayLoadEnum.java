/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.audit.model;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by chandrashekharnathile on 4/17/17.
 */
@Slf4j
public enum AuditPayLoadEnum {

    ACTION_TYPE("actionType"),
    ORIGINATOR("originator"),
    TENANT_UUID("tenantUuid"),
    ACTOR_UUID("actorUuid"),
    RESOURCE("resource"),
    RESOURCE_UUID("resourceUuid"),
    BATCH_UUID("batchUuid"),
    ACTOR("actor"),
    ACTOR_DISPLAY_NAME("actorDisplayName"),
    DESCRIPTION("description");

    private String value;

    private AuditPayLoadEnum(String val) {
        this.value = val;
    }

    public String getValue() {
        return this.value;
    }

}
