package com.ge.apm.alm.audit.handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.util.CollectionUtils;

import com.ge.apm.alm.audit.model.AuditPayload;
import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.persistence.AssetPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.GroupPersistencyService;
import com.ge.apm.alm.persistence.TemplatePersistencyService;
import com.ge.apm.alm.persistence.jpa.entity.AssetEventEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetGroupEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetInstanceEntity;
import com.ge.apm.alm.persistence.jpa.entity.AssetRestrictionFeatureEntity;
import com.ge.apm.alm.persistence.jpa.entity.TemplateEntity;

public class AuditlogHelperTest {

    @Mock
    private AssetPersistencyService assetService;

    @Mock
    private GroupPersistencyService groupService;

    @Mock
    private TemplatePersistencyService templateService;

    @Mock
    private AssetPolicyPersistencyService assetPolicyPersistencyService;

    @InjectMocks
    AuditlogHelper auditlogHelper;


    private static final ObjectMapper CUSTOM_MAPPER = new ObjectMapper();
    private String TENANT_ID = "f743b7ef-42df-4d7e-89dd-90dc3b53b0ac";
    private String EVENT_ID = "385af230-a63d-4c8d-aa5e-e303fe31b819";

    @Before
    public void setupMock() {
        MockitoAnnotations.initMocks(this);
        auditlogHelper.onPostConstruct();

    }

    public static final List<String> IGNORABLE_ATTRIBUTES = Arrays.stream(
        ("createdDate,lastModifiedDate,ancestorsArray,superTypesArray,coreAssetTypeName,typeSemantics,jsonSchema,"
            + "lastModifiedBy,"
            + "createdBy,tenantId"
            + "").split(","))
        .collect(Collectors.toList());

    public static final List<String> SKIP_FROM_CREATE = Arrays.stream("Network_node1,Network_node2".split(","))
        .collect(Collectors
        .toList());
    public static final List<String> SKIP_FROM_DELETE = Arrays.stream("Network_node1,Network_node2".split(","))
        .collect(Collectors
            .toList());

    /**
     *
     * Method: getAuditPayloads(List<AssetEvent> events, List<String> ignorableFieldsForPatch)
     * audit_log.json JSON has 3 keys in the root level: existing, new and expected.
     * existing and new contains existing and new objects for asset, site, segment, enterprise etc.
     * The key should be in such a way that it should start with the corresponding object type name.
     * If there are more test cases for the same type of object use the object type followed by underscore and specifier.
     * For eg asset_null_test, segment_exception_test etc.
     * The expected JSON map holds 3 keys:
     * allPayloadForUpdate, allPayloadForCreate and allPayloadForDelete respectively holds
     * the expected values for Update, Create and Delete operations.
     *
     */
    @Test
    public void testGetAuditPayloads() throws IOException {

        mockForGetPayloads();

        JsonNode updateObjs = CUSTOM_MAPPER.readTree(this.getClass()
                .getResourceAsStream("/audit_log.json"));

        JsonNode existingObjs = updateObjs.get("existing");
        JsonNode newObjs = updateObjs.get("new");


        Iterator<String> iterator = existingObjs.fieldNames();
        List<AssetEvent> events = new ArrayList<>();
        while (iterator.hasNext()) {
            String field = iterator.next();
            JsonNode existingObj = existingObjs.get(field);
            JsonNode newObj = updateObjs.get("new").get(field);

            AssetEvent event = AssetEventEntity.builder()
                    .eventType(AssetEvent.Type.UPDATE)
                    .id(UUID.randomUUID().toString())
                    .tenantId(existingObj.get("tenantId") != null ? existingObj.get("tenantId").textValue() :
            "f743b7ef-42df-4d7e-89dd-90dc3b53b0ac")
                    .objectType(field.split("_")[0])
                    .preModifiedObject(existingObj)
                    .modifiedBizObject(newObj)
                    .lastModifiedBy(newObj!= null && newObj.get("lastModifiedBy") != null ? newObj.get("lastModifiedBy")
                .textValue() : "test")
                    .build();

            events.add(event);

        }

        List<AuditPayload> auditPayloads = auditlogHelper.getAuditPayloads(events, IGNORABLE_ATTRIBUTES);
        System.out.println("Payload: " + CUSTOM_MAPPER.writeValueAsString(auditPayloads));

        assertGetPayloadForUpdate(updateObjs, auditPayloads);

        iterator = newObjs.fieldNames();
        events = new ArrayList<>();
        while (iterator.hasNext()) {
            String field = iterator.next();
            if (SKIP_FROM_CREATE.contains(field)) {
                continue;
            }
            JsonNode existingObj = existingObjs.get(field);
            JsonNode newObj = updateObjs.get("new").get(field);

            AssetEvent event = AssetEventEntity.builder()
                    .eventType(AssetEvent.Type.CREATE)
                    .tenantId(existingObj.get("tenantId") != null ? existingObj.get("tenantId").textValue() :
                        "f743b7ef-42df-4d7e-89dd-90dc3b53b0ac")
                    .objectType(field.split("_")[0])
                    .modifiedBizObject(newObj)
                    .build();

            events.add(event);

        }

        auditPayloads = auditlogHelper.getAuditPayloads(events, IGNORABLE_ATTRIBUTES);
        System.out.println("Payload: " + CUSTOM_MAPPER.writeValueAsString(auditPayloads));
        List<AuditPayload> expectedValues = new ArrayList<>();

        JsonNode expectedPayloadValues = updateObjs.get("expected").get("allPayloadForCreate");
        for (JsonNode expectedPayload : expectedPayloadValues) {
            AuditPayload expectedValue = CUSTOM_MAPPER.treeToValue(expectedPayload, AuditPayload.class);
            expectedValues.add(expectedValue);
        }
        Assert.assertArrayEquals(expectedValues.toArray(), auditPayloads.toArray());


        iterator = existingObjs.fieldNames();
        events = new ArrayList<>();
        while (iterator.hasNext()) {
            String field = iterator.next();
            if (SKIP_FROM_DELETE.contains(field)) {
                continue;
            }
            JsonNode existingObj = existingObjs.get(field);
            JsonNode newObj = updateObjs.get("new").get(field);

            AssetEvent event = AssetEventEntity.builder()
                    .eventType(AssetEvent.Type.DELETE)
                    .tenantId(existingObj.get("tenantId") != null ? existingObj.get("tenantId").textValue() :
                        "f743b7ef-42df-4d7e-89dd-90dc3b53b0ac")
                    .objectType(field.split("_")[0])
                    .preModifiedObject(existingObj)
                    .modifiedBizObject(newObj)
                    .build();
            events.add(event);
        }

        auditPayloads = auditlogHelper.getAuditPayloads(events, IGNORABLE_ATTRIBUTES);
        System.out.println("Payload: " + CUSTOM_MAPPER.writeValueAsString(auditPayloads));
        expectedValues = new ArrayList<>();

        expectedPayloadValues = updateObjs.get("expected").get("allPayloadForDelete");
        for (JsonNode expectedPayload : expectedPayloadValues) {
            AuditPayload expectedValue = CUSTOM_MAPPER.treeToValue(expectedPayload, AuditPayload.class);
            expectedValues.add(expectedValue);
        }
        Assert.assertArrayEquals(expectedValues.toArray(), auditPayloads.toArray());
    }

    @Test
    public void testGetPayloadsForCreateAssetPolicy() throws IOException {
        JsonNode createEventNode =
                CUSTOM_MAPPER.readTree(this.getClass().getResourceAsStream("/asset_policy_create_audit_log.json"));
        List<AssetEvent> events = new ArrayList<>();
        ((ArrayNode) createEventNode).forEach(node -> {
            AssetEvent event = AssetEventEntity.builder().id(EVENT_ID)
                    .tenantId(TENANT_ID)
                    .eventType(Type.CREATE)
                    .objectType("AssetUserPolicy")
                    .modifiedBizObject(node)
                    .preModifiedObject(null).build();
            events.add(event);
        });

        AssetRestrictionFeatureEntity feature = new AssetRestrictionFeatureEntity();
        feature.setFeatureCode("VIEW_DECOMMISSIONED_ASSETS");
        feature.setName("View decommissioned assets");
        Mockito.doReturn(feature)
                .when(assetPolicyPersistencyService).getAssetRestrictionFeatureByCode(feature.getFeatureCode());
        List<AuditPayload> auditPayloads = auditlogHelper.getAuditPayloads(events, IGNORABLE_ATTRIBUTES);
        Assert.assertNotNull(auditPayloads);
        Assert.assertTrue(auditPayloads.size() == 2);
    }

    @Test
    public void testGetPayloadsForDeleteAssetPolicy() throws IOException {
        JsonNode deleteEventNode =
                CUSTOM_MAPPER.readTree(this.getClass().getResourceAsStream("/asset_policy_delete_audit_log.json"));
        List<AssetEvent> events = new ArrayList<>();
        ((ArrayNode) deleteEventNode).forEach(node -> {
            AssetEvent event = AssetEventEntity.builder().id(EVENT_ID)
                    .tenantId(TENANT_ID)
                    .eventType(Type.DELETE)
                    .objectType("AssetUserPolicy")
                    .preModifiedObject(node)
                    .modifiedBizObject(null).build();
            events.add(event);
        });

        AssetRestrictionFeatureEntity feature = new AssetRestrictionFeatureEntity();
        feature.setFeatureCode("VIEW_DECOMMISSIONED_ASSETS");
        feature.setName("View decommissioned assets");
        Mockito.doReturn(feature)
                .when(assetPolicyPersistencyService).getAssetRestrictionFeatureByCode(feature.getFeatureCode());
        List<AuditPayload> auditPayloads = auditlogHelper.getAuditPayloads(events, IGNORABLE_ATTRIBUTES);
        Assert.assertNotNull(auditPayloads);
        Assert.assertTrue(auditPayloads.size() == 2);
    }

    private void assertGetPayloadForUpdate(JsonNode updateObjs, List<AuditPayload> auditPayloads)
        throws com.fasterxml.jackson.core.JsonProcessingException {
        List<AuditPayload> expectedValues = new ArrayList<>();

        JsonNode expectedPayloadValues = updateObjs.get("expected").get("allPayloadForUpdate");
        for (JsonNode expectedPayload : expectedPayloadValues) {
            AuditPayload expectedValue = CUSTOM_MAPPER.treeToValue(expectedPayload, AuditPayload.class);
            expectedValues.add(expectedValue);
        }

        Assert.assertEquals(expectedValues.size(), auditPayloads.size());
        for (int i=0; i < expectedValues.size(); i++) {
            assertAuditPayload(expectedValues.get(i), auditPayloads.get(i));
        }

        Set<String> eventIds = auditPayloads.stream().map(v -> v.getEventId()).collect(Collectors.toSet());
        Assert.assertEquals(eventIds.size(), auditPayloads.size());
    }

    private void mockForGetPayloads() {
        Asset associatedAsset = AssetInstanceEntity.builder().sourceKey("associatedAssetSourceKey")
            .build();
        Mockito.when(assetService.getAssetById(Mockito.anyString(), Mockito.anyCollection(),
            Mockito.eq("4bb4bc50-c924-3a9f-a28c-7767a0ec1f25"))).thenReturn(associatedAsset);

        AssetGroup associatedGroup = AssetGroupEntity.builder().sourceKey("associatedGroupSourceKey")
            .build();
        Mockito.when(groupService.getAssetGroupById(Mockito.anyString(),
            Mockito.eq("3bb4bc50-c924-3a9f-a28c-7767a0ec1f25"))).thenReturn(associatedGroup);

        Asset parentAsset = AssetInstanceEntity.builder().sourceKey("parentAsset")
            .build();
        Mockito.when(assetService.getAssetById(Mockito.anyString(), Mockito.anyCollection(),
            Mockito.eq("d074ae20-ec54-3957-bef6-32bc65a0fce5"))).thenReturn(parentAsset);

        Asset parentSite = AssetInstanceEntity.builder().sourceKey("parentSite")
            .build();
        Mockito.when(assetService.getAssetById(Mockito.anyString(), Mockito.anyCollection(),
            Mockito.eq("e9aaebb4-e252-3190-abfe-468cf93bea3c"))).thenReturn(parentSite);

        Asset site = AssetInstanceEntity.builder().sourceKey("site")
            .build();
        Mockito.when(assetService.getAssetById(Mockito.anyString(), Mockito.anyCollection(),
            Mockito.eq("d074ae20-ec54-3957-bef6-32bc65a0fce8"))).thenReturn(site);

        Template template = TemplateEntity.builder().sourceKey("templateSourceKey").build();
        Mockito.when(templateService.getTemplateById(Mockito.anyString(),
            Mockito.eq("9984bbf3-7387-347d-83ae-6fb94070d185"))).thenReturn(template);

        Template embeddedTemplate = TemplateEntity.builder().sourceKey("embeddedTemplateSourceKey").build();
        Mockito.when(templateService.getTemplateById(Mockito.anyString(),
            Mockito.eq("9984bbf3-7387-347d-83ae-6fb94070d186"))).thenReturn(embeddedTemplate);



    }

    @Test
    public void testGetAuditPayloadsValidation()  {
        List<AssetEvent> events = new ArrayList<>();
        AssetEventEntity event = new AssetEventEntity();
        event.setId("1");
        event.setEventType(null);
        events.add(event);
        List<AuditPayload> auditPayloads = AuditlogHelper.getAuditPayloads(events, IGNORABLE_ATTRIBUTES);
        Assert.assertTrue(CollectionUtils.isEmpty(auditPayloads));

        events = new ArrayList<>();
        event = new AssetEventEntity();
        event.setId("1");
        event.setEventType(Type.CREATE);
        events.add(event);
        auditPayloads = AuditlogHelper.getAuditPayloads(events, IGNORABLE_ATTRIBUTES);
        Assert.assertTrue(CollectionUtils.isEmpty(auditPayloads));

        events = new ArrayList<>();
        event = new AssetEventEntity();
        event.setId("1");
        event.setEventType(Type.UPDATE);
        events.add(event);
        auditPayloads = AuditlogHelper.getAuditPayloads(events, IGNORABLE_ATTRIBUTES);
        Assert.assertTrue(CollectionUtils.isEmpty(auditPayloads));

        events = new ArrayList<>();
        event = new AssetEventEntity();
        event.setId("1");
        event.setEventType(Type.DELETE);
        events.add(event);
        auditPayloads = AuditlogHelper.getAuditPayloads(events, IGNORABLE_ATTRIBUTES);
        Assert.assertTrue(CollectionUtils.isEmpty(auditPayloads));

        events = new ArrayList<>();
        event = new AssetEventEntity();
        event.setId("1");
        event.setEventType(Type.RECURSIVE_ASSET_DELETE);
        events.add(event);
        auditPayloads = AuditlogHelper.getAuditPayloads(events, IGNORABLE_ATTRIBUTES);
        Assert.assertTrue(CollectionUtils.isEmpty(auditPayloads));

    }

    @Test
    public void testGetAuditPayLoad() {
        List<AuditPayload> payloads
         = AuditlogHelper.getAuditPayLoad("test_tenant", "testing", "asset-state", "101",
            "test_user", "test_actor");
        Assert.assertEquals(1, payloads.size());
        AuditPayload payload = payloads.get(0);
        Assert.assertEquals("test_tenant", payload.getTenantUUID());
        Assert.assertEquals("testing ALM configuration asset-state 101", payload.getDescription());
        Assert.assertEquals("asset-state 101", payload.getResource());
        Assert.assertEquals("test_actor", payload.getActor());
        Assert.assertEquals("test_actor", payload.getActorDisplayName());
        Assert.assertEquals("test_user", payload.getActorUUID());
        Assert.assertEquals("Delete", payload.getActionType());
    }

    private void assertAuditPayload(AuditPayload src, AuditPayload target) {
        //Assert.assertEquals(src.getEventId(), target.getEventId());
        Assert.assertEquals(src.getActionType(), target.getActionType());
        Assert.assertEquals(src.getActor(), target.getActor());
        Assert.assertEquals(src.getActorDisplayName(), target.getActorDisplayName());
        Assert.assertEquals(src.getActorUUID(), target.getActorUUID());
        Assert.assertEquals(src.getBatchUUID(), target.getBatchUUID());
        Assert.assertEquals(src.getDescription(), target.getDescription());
        Assert.assertEquals(src.getOriginator(), target.getOriginator());
        Assert.assertEquals(src.getResourceUUID(), target.getResourceUUID());
        Assert.assertEquals(src.getResource(), target.getResource());
        Assert.assertEquals(src.getTenantUUID(), target.getTenantUUID());
    }
}
