/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.audit.services;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.ge.apm.alm.audit.model.AuditPayLoadEnum;
import com.ge.apm.alm.audit.model.AuditPayload;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.service.instances.ServiceInstances;
import com.ge.apm.service.tenants.TenantsUtil;
import com.ge.predix.audit.sdk.AuditClient;
import com.ge.predix.audit.sdk.FailReport;
import com.ge.predix.audit.sdk.config.AuditConfiguration;
import com.ge.predix.audit.sdk.exception.AuditException;
import com.ge.predix.audit.sdk.message.AuditEnums;
import com.ge.predix.audit.sdk.message.AuditEvent;
import com.ge.predix.audit.sdk.message.AuditEventV2;
import com.ge.predix.eventhub.EventHubClientException;

public class AuditlogServiceImplTest {

    protected static final String TEST_TENANT = "f743b7ef-42df-4d7e-89dd-90dc3b53b0ac";

    protected static final String TEST_TENANT1 = "a111b1ce-42df-4d7e-89dd-90dc3b53b1ac";

    @Mock
    private AuditClient auditClient;

    @Mock
    private AssetEventPersistencyService assetEventPersistencyService;

    @InjectMocks
    AuditlogServiceImpl auditlogServiceImpl;

    @Mock
    private ServiceInstances serviceInstances;

    @Mock
    private TenantsUtil tenantsUtil;

    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void after() throws Exception {
    }

    @Test
    public void testPublishAsync() throws AuditException, EventHubClientException {
        List<AuditPayload> payload = new ArrayList<>();

        AuditPayload value = getAuditPayload();
        payload.add(value);

        auditlogServiceImpl.publishAsync(payload);

        Mockito.verify(auditClient, Mockito.times(1))
            .audit(Matchers.argThat(new ArgumentMatcher<List<AuditEvent>>() {
                @Override
                public boolean matches(Object o) {
                    List<AuditEvent> actual = (List<AuditEvent>) o;
                    Assert.assertEquals(1, ((List<AuditEvent>) o).size());
                    return actual.size() == 1;
                }
            }));
    }

    @Test
    public void testPublishAsyncLimit() throws Exception {
        List<AuditPayload> payload = new ArrayList<>();

        for (int i = 0; i < 1001; i++) {
            AuditPayload value = getAuditPayload();
            payload.add(value);
        }

        auditlogServiceImpl.publishAsync(payload);

        Mockito.verify(auditClient, Mockito.times(1))
            .audit(Matchers.argThat(new ArgumentMatcher<List<AuditEvent>>() {
                @Override
                public boolean matches(Object o) {
                    List<AuditEvent> actual = (List<AuditEvent>) o;
                    Assert.assertEquals(999, ((List<AuditEvent>) o).size());
                    return actual.size() == 999;
                }
            }));
    }

    private AuditPayload getAuditPayload() {
        AuditPayload value = new AuditPayload();
        value.setActionType("Delete");
        value.setOriginator("APM Asset");
        value.setTenantUUID("f743b7ef-42df-4d7e-89dd-90dc3b53b0ac");
        value.setActorUUID("f743b7ef-42df-4d7e-89dd-90dc3b53b0ac_ingestor");
        value.setResource("Placeholder 00021");
        value.setDescription("Deleted Placeholder instance 00021 (asset_template_02000)");
        value.setActor("f743b7ef-42df-4d7e-89dd-90dc3b53b0ac_ingestor");
        value.setActorDisplayName("f743b7ef-42df-4d7e-89dd-90dc3b53b0ac_ingestor");
        value.setEventId("12345");
        value.setBatchUUID("");
        value.setResourceUUID("");
        return value;
    }

    @Test
    public void testUpdateAuditlogPubStatus() throws PersistencyServiceException {
        auditlogServiceImpl.updateAuditlogPubStatus("1234");
        Mockito.verify(assetEventPersistencyService, Mockito.times(1))
            .updateEvent(Mockito.eq("1234"),
                Mockito.eq(AssetEvent.EventsJobType.AUDIT),
                Mockito.eq(AssetEvent.EventStatus.COMPLETED.name()));
    }

    @Test
    public void testAuditCallback() throws PersistencyServiceException, NoSuchMethodException,
        NoSuchFieldException, IllegalAccessException {
        setFields();
        AuditEvent auditEvent1 = getAuditEvent();
        auditEvent1.setMessageId("a83d1532-eacf-455c-8200-6a245a820010");
        auditlogServiceImpl.auditCallback().onSuccees(auditEvent1);
        AuditEvent auditEvent2 = getAuditEvent();
        auditEvent2.setMessageId("a83d1532-eacf-455c-8200-6a245a820011");
        auditlogServiceImpl.auditCallback().onSuccees(auditEvent2);
        AuditEvent auditEvent3 = getAuditEvent();
        auditEvent3.setMessageId("b83d1532-eacf-455c-8200-6a245a830012");
        auditlogServiceImpl.auditCallback().onSuccees(auditEvent3);
        List<String> successEvents = new ArrayList<>();
        successEvents.add("a83d1532-eacf-455c-8200-6a245a820010");
        successEvents.add("a83d1532-eacf-455c-8200-6a245a820011");
        Mockito.when(assetEventPersistencyService.updateEventsStatus(
            Mockito.anyObject(), Mockito.anyObject(), Mockito.anyString())).thenReturn(2);
        Mockito.verify(assetEventPersistencyService, Mockito.times(1))
            .updateEventsStatus(Mockito.eq(successEvents),
                Mockito.eq(AssetEvent.EventsJobType.AUDIT),
                Mockito.eq(AssetEvent.EventStatus.COMPLETED.name()));

        auditlogServiceImpl.auditCallback().onValidate(getAuditEvent(), new ArrayList<>());
    }

    @Test
    public void testAuditCallbackPersistencyServiceException() throws PersistencyServiceException,
        NoSuchMethodException, NoSuchFieldException, IllegalAccessException {
        setFields();
        Mockito.doThrow(new PersistencyServiceException("Testing")).when(
            assetEventPersistencyService)
            .updateEventsStatus(Mockito.anyObject(),
                Mockito.any(),
                Mockito.any());
        auditlogServiceImpl.auditCallback().onSuccees(getAuditEvent());
    }

    @Test
    public void testAuditCallbackOnFailureWithEvent() throws PersistencyServiceException {
        auditlogServiceImpl.auditCallback().onFailure(getAuditEvent(), FailReport.ADD_MESSAGE_ERROR,
            "Testing");
    }

    @Test
    public void testAuditCallbackOnFailure()
        throws PersistencyServiceException, EventHubClientException {
        auditlogServiceImpl.auditCallback().onFailure(FailReport.STREAM_IS_CLOSE, "Testing");
        Mockito.verify(auditClient, Mockito.times(1)).reconnect();
    }

    @Test
    public void testAuditCallbackOnFailureBadAck()
        throws PersistencyServiceException, EventHubClientException {
        auditlogServiceImpl.auditCallback().onFailure(FailReport.BAD_ACK, "Testing");
        Mockito.verify(auditClient, Mockito.times(0)).reconnect();
    }

    @Test
    public void testAuditCallbackOnFailureExceptionOnReconnect() throws PersistencyServiceException,
        EventHubClientException {
        Mockito.doThrow(new EventHubClientException("Testing")).when(auditClient).reconnect();
        auditlogServiceImpl.auditCallback().onFailure(FailReport.STREAM_IS_CLOSE, "Testing");
    }

    //@Test - TODO: Fix me later
    public void testGetAuditConfiguration() throws Exception {
        Method method = setFields();

        AuditConfiguration config = (AuditConfiguration) method.invoke(auditlogServiceImpl);
        Assert.assertNotNull(config);

        Field auditClient = auditlogServiceImpl.getClass().getDeclaredField("auditClient");
        auditClient.setAccessible(true);
        auditClient.set(auditlogServiceImpl, null);
        method = auditlogServiceImpl.getClass().getDeclaredMethod("createAuditClient");
        method.setAccessible(true);
        method.invoke(auditlogServiceImpl);

        AuditClient client = (AuditClient) auditClient.get(auditlogServiceImpl);
        Assert.assertNotNull(client);
    }

    @Test(expected = Exception.class)
    public void testGetAuditConfigurationException()
        throws NoSuchMethodException, IllegalAccessException, NoSuchFieldException,
        InvocationTargetException {
        Method method = setFields();

        Field ehubHost = auditlogServiceImpl.getClass().getDeclaredField("ehubHost");
        ehubHost.setAccessible(true);
        ehubHost.set(auditlogServiceImpl, "");

        AuditConfiguration config = (AuditConfiguration) method.invoke(auditlogServiceImpl);
        Assert.assertNotNull(config);
    }

    private Integer jobSize;

    private Long batchWaitTime;

    private Method setFields()
        throws NoSuchMethodException, NoSuchFieldException, IllegalAccessException {
        Method method = auditlogServiceImpl.getClass().getDeclaredMethod("getAuditConfiguration");
        method.setAccessible(true);

        Field ehubHost = auditlogServiceImpl.getClass().getDeclaredField("ehubHost");
        ehubHost.setAccessible(true);
        ehubHost.set(auditlogServiceImpl, "ehub.asv-pr.ice.predix.io:443");

        Field ehubZoneId = auditlogServiceImpl.getClass().getDeclaredField("ehubZoneId");
        ehubZoneId.setAccessible(true);
        ehubZoneId.set(auditlogServiceImpl, "535-3b66-42e3-a450-7c7ea75b0be5");

        Field tracingInterval = auditlogServiceImpl.getClass().getDeclaredField("tracingInterval");
        tracingInterval.setAccessible(true);
        tracingInterval.set(auditlogServiceImpl, "60000");

        Field uaaUri = auditlogServiceImpl.getClass().getDeclaredField("uaaUri");
        uaaUri.setAccessible(true);
        uaaUri.set(auditlogServiceImpl,
            "https://4126b27b-6860-48ee-9dc1-9cba313eac9f.predix-uaa.run.asv-pr.ice.predix.io");

        Field clientId = auditlogServiceImpl.getClass().getDeclaredField("clientId");
        clientId.setAccessible(true);
        clientId.set(auditlogServiceImpl, "asset-pub-id");

        Field clientSecret = auditlogServiceImpl.getClass().getDeclaredField("clientSecret");
        clientSecret.setAccessible(true);
        clientSecret.set(auditlogServiceImpl, "TGR47FK7AAXnYh2ULLL");

        Field tracingToken = auditlogServiceImpl.getClass().getDeclaredField("tracingToken");
        tracingToken.setAccessible(true);
        tracingToken.set(auditlogServiceImpl, "TGR47FK7AAXnYh2ULLL");

        Field tracingUrl = auditlogServiceImpl.getClass().getDeclaredField("tracingUrl");
        tracingUrl.setAccessible(true);
        tracingUrl.set(auditlogServiceImpl,
            "https://4126b27b-6860-48ee-9dc1-9cba313eac9f.predix-uaa.run.asv-pr.ice.predix.io");

        Field jobSize = auditlogServiceImpl.getClass().getDeclaredField("jobSize");
        jobSize.setAccessible(true);
        jobSize.set(auditlogServiceImpl, 3);

        Field batchWaitTime = auditlogServiceImpl.getClass().getDeclaredField("batchWaitTime");
        batchWaitTime.setAccessible(true);
        batchWaitTime.set(auditlogServiceImpl, 1000L);

        Map<String, String> messageIdsToTenantMap = new ConcurrentHashMap<>();
        messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820010", TEST_TENANT);
        messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820011", TEST_TENANT);
        messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820012", TEST_TENANT);
        messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820013", TEST_TENANT);
        messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820014", TEST_TENANT);
        messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820015", TEST_TENANT);
        messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820016", TEST_TENANT);
        messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820017", TEST_TENANT);
        messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820018", TEST_TENANT);
        messageIdsToTenantMap.put("a83d1532-eacf-455c-8200-6a245a820019", TEST_TENANT);
        messageIdsToTenantMap.put("b83d1532-eacf-455c-8200-6a245a830010", TEST_TENANT1);
        messageIdsToTenantMap.put("b83d1532-eacf-455c-8200-6a245a830011", TEST_TENANT1);
        messageIdsToTenantMap.put("b83d1532-eacf-455c-8200-6a245a830012", TEST_TENANT1);
        Field msgIdsToTenantMap = auditlogServiceImpl.getClass().getDeclaredField(
            "messageIdsToTenantMap");
        msgIdsToTenantMap.setAccessible(true);
        msgIdsToTenantMap.set(auditlogServiceImpl, messageIdsToTenantMap);

        Map<String, List<String>> tenantIdToMessageIdsMap = new HashMap<>();
        Field tenantIdToMsgIdsMap = auditlogServiceImpl.getClass().getDeclaredField(
            "tenantIdToMessageIdsMap");
        tenantIdToMsgIdsMap.setAccessible(true);
        tenantIdToMsgIdsMap.set(auditlogServiceImpl, tenantIdToMessageIdsMap);
        return method;
    }

    private AuditEvent getAuditEvent() {
        return AuditEventV2.builder()
            .payload(getPayLoadJsonData(getAuditPayload()))
            .classifier(AuditEnums.Classifier.SUCCESS)
            .publisherType(AuditEnums.PublisherType.APP_SERVICE)
            .categoryType(AuditEnums.CategoryType.API_CALLS)
            .eventType(AuditEnums.EventType.SUCCESS_API_REQUEST)
            .tenantUuid("f743b7ef-42df-4d7e-89dd-90dc3b53b0ac")
            .correlationId("1234")
            .messageId("1234")
            .build();
    }

    private String getPayLoadJsonData(AuditPayload payLoad) {
        ObjectNode objectNode = JsonNodeFactory.instance.objectNode();
        objectNode.put(AuditPayLoadEnum.ACTION_TYPE.getValue(), payLoad.getActionType());
        objectNode.put(AuditPayLoadEnum.ORIGINATOR.getValue(), payLoad.getOriginator());
        objectNode.put(AuditPayLoadEnum.TENANT_UUID.getValue(), payLoad.getTenantUUID());
        objectNode.put(AuditPayLoadEnum.ACTOR_UUID.getValue(), payLoad.getActorUUID());
        objectNode.put(AuditPayLoadEnum.RESOURCE.getValue(), payLoad.getResource());
        objectNode.put(AuditPayLoadEnum.RESOURCE_UUID.getValue(), payLoad.getResourceUUID());
        objectNode.put(AuditPayLoadEnum.BATCH_UUID.getValue(), payLoad.getBatchUUID());
        objectNode.put(AuditPayLoadEnum.ACTOR.getValue(), payLoad.getActor());
        objectNode.put(AuditPayLoadEnum.ACTOR_DISPLAY_NAME.getValue(),
            payLoad.getActorDisplayName());
        objectNode.put(AuditPayLoadEnum.DESCRIPTION.getValue(), payLoad.getDescription());
        return objectNode.toString();
    }

} 
