/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.audit.handler;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.ge.apm.alm.audit.model.AuditPayload;
import com.ge.apm.alm.audit.services.IAuditlogService;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.persistence.AssetEventPersistencyService;
import com.ge.apm.alm.persistence.AssetPolicyPersistencyService;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.jpa.entity.AssetEventEntity;
import com.ge.apm.datasource.TenantDataSourceService;
import com.ge.predix.audit.sdk.exception.AuditException;
import com.ge.predix.eventhub.EventHubClientException;

@RunWith(PowerMockRunner.class)
public class AuditlogJobTest {

    @Mock
    AssetEventPersistencyService eventService;

    @Mock
    IAuditlogService auditPublisherService;

    @Mock
    AssetPolicyPersistencyService assetPolicyPersistencyService;

    @InjectMocks
    AuditlogJob auditlogJob;

    @Mock
    TenantDataSourceService tenantDataSourceService;

    @Before
    public void before() throws Exception {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(auditlogJob, "tenantDataSourceService", tenantDataSourceService);
    }


    @After
    public void after() throws Exception {
    }

    @Test
    @PrepareForTest({AuditlogHelper.class})
    public void testDoExecute() throws PersistencyServiceException, EventHubClientException, AuditException {
        AssetEventEntity event = new AssetEventEntity();
        List<AssetEvent> events = new ArrayList<>();
        event.setId("1");
        events.add(event);
        event = new AssetEventEntity();
        event.setId("2");
        events.add(event);

        Mockito.doReturn(events).when(eventService).getPendingEventBatch(
                Mockito.any(), Mockito.anyInt(), Mockito.anyLong(), Mockito.anyLong());
        PowerMockito.mockStatic(AuditlogHelper.class);
        List<AuditPayload>  values = new ArrayList<>();
        AuditPayload payload = new AuditPayload();
        payload.setEventId("1");
        values.add(payload);
        PowerMockito.when(AuditlogHelper.getAuditPayloads(Matchers.eq(events), Matchers.anyList()))
                .thenReturn(values);
        auditlogJob.doExecute();
        Mockito.verify(auditPublisherService, Mockito.times(1))
                .publishAsync(Matchers.argThat(new ArgumentMatcher<List<AuditPayload>>(){
                    @Override
                    public boolean matches(Object o) {
                        List<AuditPayload>  actual = (List<AuditPayload> ) o;
                        return actual.equals(values);
                    }
                }));
    }

    @Test
    @PrepareForTest({AuditlogHelper.class})
    public void testDoExecuteEmptyList() throws Exception {
        List<AssetEvent> events = new ArrayList<>();
        Mockito.doReturn(events).when(eventService).getPendingEventBatch(
                Mockito.any(), Mockito.anyInt(), Mockito.anyLong(), Mockito.anyLong());
        auditlogJob.doExecute();
    }

    @Test
    @PrepareForTest({AuditlogHelper.class})
    public void testDoExecuteException() throws Exception {
        AssetEvent event = new AssetEventEntity();
        List<AssetEvent> events = new ArrayList<>();
        events.add(event);
        Mockito.doReturn(events).when(eventService).getPendingEventBatch(
                Mockito.any(), Mockito.anyInt(), Mockito.anyLong(), Mockito.anyLong());
        PowerMockito.mockStatic(AuditlogHelper.class);
        List<AuditPayload>  values = new ArrayList<>();
        AuditPayload payload = new AuditPayload();
        values.add(payload);
        PowerMockito.when(AuditlogHelper.getAuditPayloads(Matchers.eq(events), Matchers.anyList()))
                .thenReturn(values);
        Mockito.doThrow(new RuntimeException("Test")).when(auditPublisherService)
                .publishAsync(Mockito.anyListOf(AuditPayload.class));
        auditlogJob.doExecute();
    }

} 
