/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.audit.handler;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.test.util.ReflectionTestUtils;

public class AuditlogSchedulerConfigTest {

    AuditlogSchedulerConfig auditlogSchedulerConfig = new AuditlogSchedulerConfig();

    @Before
    public void before() throws Exception {
        ReflectionTestUtils.setField( auditlogSchedulerConfig, "numOfConcConsumer", 5 );

    }

    @After
    public void after() throws Exception {
    }


    @Test
    public void testConfigureTasks() throws Exception {
        ScheduledTaskRegistrar registrar = new ScheduledTaskRegistrar();
        auditlogSchedulerConfig.configureTasks(registrar);
        Assert.assertNotNull(registrar.getScheduler());
    }
}
