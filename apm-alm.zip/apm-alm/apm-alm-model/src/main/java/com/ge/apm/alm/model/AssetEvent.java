/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.model;

import java.time.OffsetDateTime;

import com.fasterxml.jackson.databind.JsonNode;

public interface AssetEvent extends Auditable {

    /**
     * See {@link AssetEvent.Type}.
     */
    Type getEventType();

    /**
     * The UUID of the object.
     */
    String getObjectId();

    /**
     * The type of object.
     */
    String getObjectType();

    /**
     * The timestamp of which the last persistence operation occurred.
     */
    OffsetDateTime getObjectLastModifiedDate();

    /**
     *  The exisiting biz object
     */
    JsonNode getPreModifiedObject();


    /**
     *  The modified biz object
     */
    JsonNode getModifiedObject();

    /**
     * etrun the Status of Predix Publisher
     * @return
     */
    EventStatus getPredixPubStatus();

    /**
     * Retrun the Status of Eventhub Publisher
     * @return
     */
    EventStatus getEventhubPubStatus();

    /**
     * Retrun the Status of Auditlog Publisher
     * @return
     */
    EventStatus getAuditPubStatus();

    /**
     * Type of event.
     */
    public enum Type {

        /*
         * An entity was created.
         */
        CREATE,

        /*
         * An entity was updated.
         */
        UPDATE,

        /*
         * An entity was deleted..
         */
        DELETE,

        /*
         * All tags of a criterion object was deleted.
         */
        DELETE_TAGS,

        /*
         * An asset type and all of its subtypes were deleted.
         */
        DELETE_TYPE_RECURSIVELY,

        /*
         * A group and all of its items were deleted.
         */
        DELETE_GROUP_AND_ITEMS,

        /*
         * All of a group's items were deleted (not the group itself).
         */
        DELETE_GROUP_ITEMS,

        /*
         * A template and all of its placeholders were deleted
         */
        DELETE_TEMPLATE,

        /*
         * An asset group association was deleted
         */
        DELETE_ASSET_GROUP_ASSOCIATION,

        /*
        * An asset and all of its child assets, tags, associated group items were deleted. By design, this constant does
        * not startwith "DELETE" since the recursive delete API returns an asset hierarchy. The hierarchy includes all
        * its dependencies so events can be created in the afterPersistence joint point aspect.
        */
        RECURSIVE_ASSET_DELETE,

        DELETE_NETWORK;
    }

    enum EventStatus {
        QUEUED,
        PROCESSING,
        COMPLETED
    }

    enum EventsJobType {
        PREDIX,
        AUDIT,
        EVENTHUB;
    }

    interface ObjectType {
        String ENTERPRISE = "Enterprise";

        String SITE = "Site";

        String SEGMENT = "Segment";

        String ASSET = "Asset";

        String TAG = "Tag";

        String ENTERPRISE_TYPE = "EnterpriseType";

        String SITE_TYPE = "SiteType";

        String SEGMENT_TYPE = "SegmentType";

        String ASSET_TYPE = "AssetType";

        String TAG_TYPE = "TagType";

        String ASSET_GROUP = "AssetGroup";

        String ASSET_GROUP_ITEM = "AssetGroupItem";

        String ASSET_GROUP_ASSOCIATION = "AssetGroupAssociation";

        String TEMPLATE = "Template";

        String PLACEHOLDER = "Placeholder";

        String NETWORK = "Network";

        String EDGE = "Edge";

        String NODE = "Node";

        String TAG_CORRELATION = "TagCorrelation";

        String ASSET_USER_POLICY = "AssetUserPolicy";
    }
}
