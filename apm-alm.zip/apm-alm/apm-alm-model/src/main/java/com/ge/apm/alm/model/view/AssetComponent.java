/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.model.view;

public enum AssetComponent {
    // Set the attributes property of Asset
    ATTRIBUTES,

    // Set the type property of Asset
    TYPE,

    // Set the tags property of Asset
    TAGS,

    // Set the templateInfo property of Asset
    TEMPLATE_INFO,

    // Set asset_type, super_types in the direct parent property of Asset
    PARENT_TYPE,

    // Set type entity object in the parent property of Asset, linking all the ancestors.
    PARENT_TYPE_OBJECT,

    // Set the parent property of Asset, linking all the ancestors.
    PARENT,

    // Set tags in the parent property of Asset in addition to that with PARENT
    PARENT_TAGS,
    ;
}
