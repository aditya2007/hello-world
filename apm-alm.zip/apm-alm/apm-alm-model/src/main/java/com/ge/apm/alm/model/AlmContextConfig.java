package com.ge.apm.alm.model;

public interface AlmContextConfig {

    String getTenantId();

    String getValue();

    String getDescription();

    Context getContext();

}
