/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.model.coretypes;

import java.util.HashMap;
import java.util.Map;

public enum OOTBCoreTypesIdLookup {

    EnterpriseType(SeedOOTBData.ROOT_ENTERPRISE_TYPE_ID),
    SiteType(SeedOOTBData.ROOT_SITE_TYPE_ID),
    SegmentType(SeedOOTBData.ROOT_SEGMENT_TYPE_ID),
    AssetType(SeedOOTBData.ROOT_ASSET_TYPE_ID),
    TagType(SeedOOTBData.ROOT_TAG_TYPE_ID);

    private static final Map<String, OOTBCoreTypesIdLookup> LOOKUP = new HashMap<>();

    static {
        for (OOTBCoreTypesIdLookup typeId : OOTBCoreTypesIdLookup.values()) {
            LOOKUP.put(typeId.getId(), typeId);
        }
    }

    private String id;

    OOTBCoreTypesIdLookup(String id) {
        this.id = id;
    }

    public static OOTBCoreTypesIdLookup fromId(String typeId) {
        return LOOKUP.get(typeId);
    }

    public String getId() {
        return id;
    }

}
