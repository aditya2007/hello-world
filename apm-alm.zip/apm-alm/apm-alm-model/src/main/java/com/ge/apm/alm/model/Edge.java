/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.model;

import com.fasterxml.jackson.databind.JsonNode;

/**
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 July 15, 2017
 * @since 1.0
 */
public interface Edge extends Auditable {

    String getName();

    String getDescription();

    String getSource();

    String getTarget();

    Direction getDirection();

    JsonNode getAttributes();

    /**
     * The asset this connector is associated with.
     *
     * @return the asset identifier
     */
    String getAssetId();

    Asset getAsset();

    Network getSourceNetwork();

    Network getTargetNetwork();
}
