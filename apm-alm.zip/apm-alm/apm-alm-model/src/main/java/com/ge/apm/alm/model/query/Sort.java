/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.model.query;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author Shu W. Yu 212614203
 * @version 1.0 Apr 11, 2018
 * @since 1.0
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class Sort {

    private boolean asc;
    private String property;

    public Sort(String property, boolean asc) {
        this.property = property;
        this.asc = asc;
    }
}
