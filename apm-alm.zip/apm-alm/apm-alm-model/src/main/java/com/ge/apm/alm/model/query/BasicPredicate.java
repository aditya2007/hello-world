/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.model.query;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.BeanUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.alm.model.AttributeSelectEnum;

@Getter
@Setter
@ToString(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class BasicPredicate<T extends BasicPredicate<T>> {

    //select
    AttributeSelectEnum attributeSelectEnum = AttributeSelectEnum.BASIC;
    //pagination
    int pageSize = 250;
    int offset = 0;

    @Setter(AccessLevel.PRIVATE)
    String[] nextPageSortValues;

    //predicates
    String name;
    String sourceKey;
    String description;

    /**
     * This operand is for relationship between the main predicate context and the list of child predicates.
     */
    Operand childOperand;

    /**
     * This operand is for relationsip across predicate peers in the <code>predicates</code> list. The last
     * predicate in the list should have a <code>null</code> peer operand; a not-null operand there will be ignored.
     */
    Operand peerOperand;
    List<T> childPredicates;

    public BasicPredicate(AttributeSelectEnum attributeSelectEnum, int pageSize, int offset, String name,
        String sourceKey, String description) {
        this.attributeSelectEnum = attributeSelectEnum;
        this.pageSize = pageSize;
        this.offset = offset;
        this.name = name;
        this.sourceKey = sourceKey;
        this.description = description;
    }

    @SuppressWarnings("squid:S1166")
    public void setPagingInfo(int offset, int pageSize, String sortKey, boolean nextPage) {
        if (!nextPage) {
            throw new IllegalArgumentException("only next page sort key is supported");
        }
        this.offset = offset;
        this.pageSize = pageSize;
        this.nextPageSortValues = null;
        if (StringUtils.isEmpty(sortKey)) {
            return;
        }

        try {
            Decoder decoder = Base64.getDecoder();
            String charset = StandardCharsets.UTF_8.name();
            nextPageSortValues = new String(decoder.decode(sortKey), charset).split(":");
            for (int i = 0; i < nextPageSortValues.length; i++) {
                nextPageSortValues[i] = new String(decoder.decode(nextPageSortValues[i]), charset);
            }
            this.offset = 0;
        } catch (UnsupportedEncodingException e) {
            // use fallback method.
            nextPageSortValues = null;
        }
    }

    @SuppressWarnings("unchecked")
    public T copy() {
        T duplicate = BeanUtils.instantiate((Class<T>) this.getClass());
        BeanUtils.copyProperties(this, duplicate);
        duplicate.nextPageSortValues = this.nextPageSortValues;
        return duplicate;
    }
 }
