/*********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.model.query;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.view.TagComponent;

@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class TagPredicate extends BasicPredicate<TagPredicate> implements Sortable {

    String alias;
    Map<String, String> attributes;
    Map<String, String> reservedAttributes;

    /**
     * Context on the current tag type.
     */
    TypePredicate type;

    /**
     * Context of the monitored entity
     */
    ParentPredicate parent;

    /**
     * convenient method to get multiple Asset objects in one call
     */
    Set<String> ids;

    private Set<TagComponent> components;
    private boolean ignoreComponentAcl;

    @Builder.Default
    private List<Sort> sorts = Collections.singletonList(new Sort("id", true));

    @Builder
    private TagPredicate(AttributeSelectEnum attributeSelectEnum, int pageSize, int offset,
        String name, String sourceKey, String description, Operand childOperand, Operand peerOperand,
        List<TagPredicate> childPredicates, String alias, Map<String, String> attributes,
        Map<String, String> reservedAttributes, Set<String> ids, ParentPredicate parent, TypePredicate type) {
        super(attributeSelectEnum, pageSize, offset, name, sourceKey, description);
        this.alias = alias;
        this.attributes = attributes;
        this.reservedAttributes = reservedAttributes;
        this.ids = ids;
        this.parent = parent;
        this.type = type;
        this.childOperand = childOperand;
        this.peerOperand = peerOperand;
        this.childPredicates = childPredicates;
    }
}
