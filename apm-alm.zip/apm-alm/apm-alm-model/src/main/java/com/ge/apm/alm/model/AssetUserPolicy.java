/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.model;

/**
 * Created by Yogananda Gowda - 212590467 on 9/29/17.
 */
public interface AssetUserPolicy extends Auditable {

    String getSubjectId();

    String getSubjectType();

    String getFeatureId();

    String getUserName();

    String getDisplayName();

    String getSuperType();

    String getFilterCriteria();

    String getFeatureCode();


    public enum SubjectType {
        USER("User"),
        USER_GROUP("UserGroup");

        private String type;
        private SubjectType(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }
    }
}
