/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.model.query;

import java.util.Collections;
import java.util.List;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.AttributeSelectEnum;

@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class NotesPredicate extends BasicPredicate implements Sortable {

    String content;

    @Builder.Default
    private List<Sort> sorts = Collections.singletonList(new Sort("id", true));

    @Builder
    private NotesPredicate(AttributeSelectEnum attributeSelectEnum, int pageSize, int offset, String name,
        String content) {
        super(attributeSelectEnum, pageSize, offset, name, null, null);
        this.content = content;
    }

}
