/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.model.query;

import java.util.Map;
import java.util.Set;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.AttributeSelectEnum;

@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class ParentPredicate extends BasicPredicate<ParentPredicate> {

    Map<String, String> attributes;
    Map<String, String> reservedAttributes;

    /**
     * Search is confined under these identifiers where the semantics of the parent is
     * <ul>
     *     <li>asset instance: identifiers of the parent assets, i.e., <code>parent_id</code></li>
     *     <li>asset type: identifiers of the parent asset types, i.e., <code>super_type_id</code></li>
     *     <li>tag instance: asset identifiers of the tag, i.e., <code>asset_id</code></li>
     * </ul>
     */
    Set<String> ids;

    boolean deepSearch = false;
    TypePredicate type;

    @Builder
    private ParentPredicate(AttributeSelectEnum attributeSelectEnum, int pageSize, int offset,
        String name, String sourceKey, String description, Operand peerOperand, Map<String, String> attributes,
        Map<String, String> reservedAttributes, Set<String> ids, boolean deepSearch, TypePredicate type) {
        super(attributeSelectEnum, pageSize, offset, name, sourceKey, description);
        this.attributes = attributes;
        this.reservedAttributes = reservedAttributes;
        this.ids = ids;
        this.deepSearch = deepSearch;
        this.type = type;
        this.childOperand = childOperand;
        this.peerOperand = peerOperand;
    }
}
