package com.ge.apm.alm.model;

import java.time.OffsetDateTime;

public interface Auditable extends BaseDataModel {

    String getCreatedBy();

    OffsetDateTime getCreatedDate();

    String getLastModifiedBy();

    OffsetDateTime getLastModifiedDate();
}
