/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.model.query;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.view.AssetTypeComponent;

@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class TypePredicate extends BasicPredicate<TypePredicate> implements Sortable {

    Map<String, String> attributes;
    Map<String, String> reservedAttributes;
    boolean deepSearch = false;
    String orderBy;
    String order;
    boolean monitoredEntity = false;

    /**
     * This is the type identifier of the <code>parent</code> type. The semantics of <code>parent</code> depends on the
     * context that this predicate is in. For example, for
     * <ul>
     *  <li>asset instance: it's the asset type identifier, i.e., asset_type.</li>
     *  <li>asset type: it's the parent type identifier, i.e., the super_type_id</li>
     *  <li>tag instance: it's the tag type identifier, i.e., the tag_type</li>
     * </ul>
     * Search will be confined under this identifier, or the presence of this identifier in the denormalized
     * super_types_array if the deep search is <code>true</code>.
     * .
     */
    ParentPredicate parent;

    /**
     * convenient method to get multiple Asset objects in one call
     */
    Set<String> ids;

    private Set<AssetTypeComponent> components;

    @Builder.Default
    private List<Sort> sorts = Collections.singletonList(new Sort("id", true));

    @Builder
    private TypePredicate(AttributeSelectEnum attributeSelectEnum, int pageSize, int offset,
        String name, String sourceKey, String description, Operand childOperand, Operand peerOperand,
        List<TypePredicate> childPredicates, Map<String, String> attributes, Map<String, String> reservedAttributes,
        boolean deepSearch, ParentPredicate parent, Set<String> ids, String orderBy, String order) {
        super(attributeSelectEnum, pageSize, offset, name, sourceKey, description);
        this.attributes = attributes;
        this.reservedAttributes = reservedAttributes;
        this.deepSearch = deepSearch;
        this.parent = parent;
        this.ids = ids;
        this.childOperand = childOperand;
        this.peerOperand = peerOperand;
        this.childPredicates = childPredicates;
        this.orderBy = orderBy;
        this.order = order;
    }

    public void setMonitoredEntity(boolean value) {
        this.monitoredEntity = value;
    }
}
