/*********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.model.query;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AttributeSelectEnum;

@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class GroupPredicate extends BasicPredicate<GroupPredicate> implements Sortable {

    List<AssetGroupCategory> categories;
    Map<String, String> attributes;
    // group does not support reserved attributes
    Set<String> ids;

    @Builder.Default
    private List<Sort> sorts = Collections.singletonList(new Sort("id", true));

    @Builder
    private GroupPredicate(AttributeSelectEnum attributeSelectEnum, int pageSize, int offset,
        String name, String sourceKey, String description, List<AssetGroupCategory> categories, Set<String> ids,
        Operand childOperand, Operand peerOperand, List<GroupPredicate> childPredicates,
        Map<String, String> attributes) {
        super(attributeSelectEnum, pageSize, offset, name, sourceKey, description);
        this.categories = categories;
        this.ids = ids;
        this.attributes = attributes;
        this.childOperand = childOperand;
        this.peerOperand = peerOperand;
        this.childPredicates = childPredicates;
    }
}
