/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.model.query;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.view.AssetComponent;

@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class AssetPredicate extends BasicPredicate<AssetPredicate> implements Sortable {

    boolean sortByHierarchy = false;
    Map<String, String> attributes;
    Map<String, String> reservedAttributes;
    /**
     * convenient method to get multiple Asset objects in one call
     */
    Set<String> ids;

    TypePredicate type;
    ParentPredicate parent;

    /**
     * query asset based on parent & template info
     */
    String templateId;
    String ppn;
    String embeddedTemplateId;
    String embeddedPpn;
    Boolean conformanceFlag;

    private Set<AssetComponent> components;
    private boolean ignoreComponentAcl;
    @Builder.Default
    private List<Sort> sorts = Collections.singletonList(new Sort("id", true));

    @Builder
    private AssetPredicate(AttributeSelectEnum attributeSelectEnum, int pageSize, int offset,
        String name, String sourceKey, String description, Operand childOperand, Operand peerOperand,
        List<AssetPredicate> childPredicates, boolean sortByHierarchy, Map<String, String> attributes,
        Map<String, String> reservedAttributes,
        TypePredicate type, ParentPredicate parent, Set<String> ids, String templateId, String ppn,
        String embeddedTemplateId, String embeddedPpn, Boolean conformanceFlag, Set<AssetComponent> components, boolean ignoreComponentAcl) {
        super(attributeSelectEnum, pageSize, offset, name, sourceKey, description);
        this.sortByHierarchy = sortByHierarchy;
        this.attributes = attributes;
        this.reservedAttributes = reservedAttributes;
        this.type = type;
        this.parent = parent;
        this.ids = ids;
        this.childOperand = childOperand;
        this.peerOperand = peerOperand;
        this.childPredicates = childPredicates;

        this.templateId = templateId;
        this.ppn = ppn;
        this.embeddedTemplateId = embeddedTemplateId;
        this.embeddedPpn = embeddedPpn;
        this.conformanceFlag = conformanceFlag;

        this.components = components;
        this.ignoreComponentAcl = ignoreComponentAcl;
    }
}
