/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.model;

import java.util.List;
import java.util.Map;

import com.ge.apm.alm.model.coretypes.OOTBCoreTypesIdLookup;

/**
 * Encapsulates an asset hierarchy that includes
 * <ul>
 *     <li>root asset</li>
 *     <li>total number of child assets</li>
 *     <li>a list of all immedicate child asset hierarchy</li>
 *     <li>asset instance group items that the root is a member of</li>
 *     <li>tag group items that the root's tags are members of</li>
 *     <li>tag correlation group items that the root's tags are members of</li>
 *     <li>tags of the root asset</li>
 * </ul>
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Jun 1, 2017
 * @since 1.0
 */
public interface AssetHierarchy {

    /**
     * @return the root asset's core type.
     */
    OOTBCoreTypesIdLookup getCoreType();

    /**
     * @return the root asset of this hierarchy
     */
    Asset getAsset();

    /**
     * @return the total number of assets in this hierarchy
     */
    int getAssetCount();

    /**
     * @return list of immediate child asset hierarchies
     */
    List<AssetHierarchy> getChildren();

    /**
     * @return a map of asset group to instance group items that the root asset belongs to
     */
    Map<AssetGroup, AssetGroupItem> getAssetGroups();

    /**
     * @return a map of tag group to tag group items of the root asset
     */
    Map<AssetGroup, List<AssetGroupItem>> getTagGroups();

    /**
     * @return a map of asset group to correlated tags of the root asset
     */
    Map<AssetGroup, List<AssetGroupItem>> getTagCorrelations();

    /**
     * @return all tags of the root asset
     */
    List<Tag> getTags();
}
