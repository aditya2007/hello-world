/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.model.coretypes;

public final class SeedOOTBData {

    public static final String SYSTEM_TENANT_ID = "259dd121-fd2c-43e0-aa5c-c9ebf0cb724c";
    public static final String ROOT_ENTERPRISE_TYPE_ID = "edf150de-d869-3741-8141-6f4c7f80254e";
    public static final String ROOT_SITE_TYPE_ID = "c9fb733c-4c2e-3b43-9e01-47c9256af586";
    public static final String ROOT_SEGMENT_TYPE_ID = "8c8b780b-14e0-382a-aeea-16b18c312dfa";
    public static final String ROOT_ASSET_TYPE_ID = "4012dc78-2339-37f2-bbba-92a980b9ee65";
    public static final String ROOT_TAG_TYPE_ID = "203d4660-702c-3cc9-8399-5663b9378408";

    private SeedOOTBData() {
    }

}
