/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.utils;

import java.util.HashMap;
import java.util.Map;

public abstract class AlmRequestContext {

    public enum AlmRequestContextEnum {
        SUBJECT_UUID,
        SUBJECT_ASSOCIATED_GROUP_UUID_AS_LIST,
        ALM_ASSET_USER_POLICIES_AS_LIST,
        ALM_ASSET_USER_POLICIES_ENABLED;
    }

    private static ThreadLocal<Map<AlmRequestContextEnum, Object>> valueHolder = ThreadLocal.withInitial(
        () -> new HashMap<>());

    public static Object get(AlmRequestContextEnum key) {
        if (getValue().containsKey(key)) {
            return getValue().get(key);
        }
        return null;
    }

    public static <T> T get(AlmRequestContextEnum key, Class<T> type) {
        Object value = get(key);
        if (value == null) {
            if (boolean.class.isAssignableFrom(type)) {
                return (T) Boolean.FALSE;
            }
            return null;
        }
        return type.cast(value);
    }

    public static void put(AlmRequestContextEnum key, Object value) {
        getValue().put(key, value);
    }

    public static boolean contains(AlmRequestContextEnum key) {
        return getValue().containsKey(key);
    }

    public static Object remove(AlmRequestContextEnum key) {
        return getValue().remove(key);
    }

    public static void clear() {
        getValue().clear();
    }

    public static void destroy() {
        valueHolder.remove();
    }

    public static Map<AlmRequestContextEnum, Object> copy() {
        return new HashMap<>(getValue());
    }

    public static void initialize(Map<AlmRequestContextEnum, Object> localValueHolder) {
        valueHolder.set(new HashMap<>(localValueHolder));
    }

    private static Map<AlmRequestContextEnum, Object> getValue() {
        return valueHolder.get();
    }
}
