/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence;

import java.util.List;

import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.Template;
import com.ge.apm.alm.model.query.TemplatePredicate;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.mirror.Mirror;

public interface TemplatePersistencyService {

    // Create API's
    Template createTemplate(String tenantId, @Mirror Template template);

    int createTemplates(String tenantId, @Mirror List<Template> templates);

    // Update API's
    Template updateTemplate(String tenantId, @Mirror Template template) throws PersistencyServiceException;

    int updateTemplates(String tenantId, @Mirror List<Template> templates) throws PersistencyServiceException;

    // Delete API's
    int deleteTemplateById(String tenantId,
        @Mirror(type = AssetEvent.Type.DELETE_TEMPLATE, clazz = Template.class) String id)
        throws PersistencyServiceException;

    // Query API's
    Template getTemplateById(String tenantId, String id);

    Template getTemplateBySourceKey(String tenantId, String sourceKey);

    List<Template> getTemplatesBySourceKeys(String tenantId, List<String> sourceKeys);

    //collections
    List<Template> getTemplates(String tenantId, TemplatePredicate queryPredicate);
}

