/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence;

import java.util.List;

import com.ge.apm.alm.model.TemplateNotes;
import com.ge.apm.alm.model.query.TemplateNotesPredicate;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;

public interface TemplateNotePersistencyService {

    // Create API's
    TemplateNotes createTemplateNote(String tenantId, TemplateNotes templateNote);

    int createTemplateNotes(String tenantId, List<TemplateNotes> templateNotes);

    // Update API's
    TemplateNotes updateTemplateNote(String tenantId, TemplateNotes templateNote) throws PersistencyServiceException;

    // Delete API's
    int deleteTemplateNotesByTemplateId(String tenantId, String templateId) throws PersistencyServiceException;

    int deleteTemplateNoteById(String tenantId, String id) throws PersistencyServiceException;

    // Query API's
    TemplateNotes getTemplateNoteById(String tenantId, String id);

    //collections
    List<TemplateNotes> getTemplateNotes(String tenantId, TemplateNotesPredicate queryPredicate);
}
