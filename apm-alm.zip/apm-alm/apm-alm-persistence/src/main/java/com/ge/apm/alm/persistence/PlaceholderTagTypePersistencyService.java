/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence;

import java.util.List;

import com.ge.apm.alm.model.PlaceholderTagType;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;

public interface PlaceholderTagTypePersistencyService {

    // Create API's
    PlaceholderTagType createPlaceholderTagType(String tenantId, PlaceholderTagType placeholderTagType);

    int createPlaceholderTagTypes(String tenantId, List<PlaceholderTagType> placeholderTagTypes);

    // Update API's
    PlaceholderTagType updatePlaceholderTagType(String tenantId, PlaceholderTagType placeholderTagType)
        throws PersistencyServiceException;

    int updatePlaceholderTagTypes(String tenantId, List<PlaceholderTagType> placeholderTagTypes)
        throws PersistencyServiceException;

    // Delete API's
    int deletePlaceholderTagTypeById(String tenantId, String id) throws PersistencyServiceException;

    int deletePlaceholderTagTypeByPlaceholderIdAndTagTypeId(String tenantId, String placeholderId, String tagTypeId)
        throws PersistencyServiceException;


    int deletePlaceholderTagTypeByPlaceholderId(String tenantId, String placeholderId)
        throws PersistencyServiceException;

    // Query API's
    PlaceholderTagType getPlaceholderTagTypeById(String tenantId, String id);

    PlaceholderTagType getPlaceholderTagTypeByPlaceholderIdAndTagTypeId(String tenantId, String placeholderId,
        String tagTypeId);

    //collections
    List<PlaceholderTagType> getPlaceholderTagTypeByPlaceholderId(String tenantId, String placeholderId);

    List<PlaceholderTagType> getPlaceholderTagTypeByTemplateId(String tenantId, String templateId);

    List<PlaceholderTagType> getPlaceholderTagTypeByPlaceholderIds(String tenantId, List<String> placeholderIds);
}
