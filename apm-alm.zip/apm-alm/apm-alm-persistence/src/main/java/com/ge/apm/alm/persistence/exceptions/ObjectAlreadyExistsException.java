package com.ge.apm.alm.persistence.exceptions;

/**
 * Created by 212578721 on 8/9/17.
 */
public class ObjectAlreadyExistsException extends PersistencyServiceException {

    public ObjectAlreadyExistsException(String message) {
        super(message);
    }

    public ObjectAlreadyExistsException(String message, Throwable cause) {
        super(message, cause);
    }
}
