/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence;

import java.util.List;

import com.ge.apm.alm.model.AssetRestrictionFeature;
import com.ge.apm.alm.model.AssetUserPolicy;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.mirror.Mirror;

/**
 * Created by Yogananda Gowda - 212590467 on 9/28/17.
 */
public interface AssetPolicyPersistencyService {

    List<AssetRestrictionFeature> getAssetRestrictionFeaturesByStatus(boolean isActive);

    List<AssetRestrictionFeature> getAssetRestrictionFeatures();

    //Used only for test case, since Feature Codes are meta data driven
    AssetRestrictionFeature getAssetRestrictionFeatureByCode(String featureCode);

    AssetUserPolicy createUserPolicy(String tenantId, @Mirror AssetUserPolicy assetUserPolicy)
                                                    throws PersistencyServiceException;

    int createUserPolicies(String tenantId, @Mirror List<AssetUserPolicy> assetUserPolicies)
                                                    throws PersistencyServiceException;

    void deleteAssetUserPolicy(String tenantId, @Mirror(clazz = AssetUserPolicy.class) String assetPolicyId)
                                                    throws PersistencyServiceException;
    //Used only for test case, to assert delete calls
    void deleteAllAssetUserPolicy(String tenantId) throws PersistencyServiceException;

    //Used only for test case, to assert delete calls
    AssetUserPolicy getAssetUserPolicyById(String tenantId, String policyId);

    List<AssetUserPolicy> getAssetUserPolicies(String tenantId, String assetFeatureId);

    List<AssetUserPolicy> getAssetUserPoliciesBySubject(String tenantId, String subjectId, String subjectType);

    List<AssetUserPolicy> getAssetUserPoliciesBySubjects(String tenantId, List<String> subjectIds);

    List<AssetUserPolicy> getAssetUserPoliciesByTenant(String tenantId);
}
