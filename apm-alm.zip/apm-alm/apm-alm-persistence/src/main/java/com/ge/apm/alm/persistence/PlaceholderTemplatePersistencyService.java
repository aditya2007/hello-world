/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence;

import java.util.List;

import com.ge.apm.alm.model.PlaceholderTemplate;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;

public interface PlaceholderTemplatePersistencyService {

    // Create API's
    PlaceholderTemplate createPlaceholderTemplate(String tenantId, PlaceholderTemplate placeholderTemplate);

    int createPlaceholderTemplates(String tenantId, List<PlaceholderTemplate> placeholderTemplates);

    // Update API's
    PlaceholderTemplate updatePlaceholderTemplate(String tenantId, PlaceholderTemplate placeholderTemplate)
        throws PersistencyServiceException;

    int updatePlaceholderTemplates(String tenantId, List<PlaceholderTemplate> placeholderTemplates)
        throws PersistencyServiceException;

    // Delete API's
    int deletePlaceholderTemplateById(String tenantId, String id) throws PersistencyServiceException;

    int deletePlaceholderTemplateByPlaceholderIdAndTemplateId(String tenantId, String placeholderId, String templateId)
        throws PersistencyServiceException;

    int deletePlaceholderTemplateByPlaceholderId(String tenantId, String placeholderId)
        throws PersistencyServiceException;

    // Query API's
    PlaceholderTemplate getPlaceholderTemplateById(String tenantId, String id);

    PlaceholderTemplate getPlaceholderTemplateByPlaceholderId(String tenantId, String placeholderId);

    //collections
    List<PlaceholderTemplate> getPlaceholderTemplateByTemplateId(String tenantId, String templateId);

    List<PlaceholderTemplate> getPlaceholderTemplates(String tenantId, List<String> placeholderIds);

    List<PlaceholderTemplate> getPlaceholderTemplates(String tenantId, String compositeTemplateId);
}
