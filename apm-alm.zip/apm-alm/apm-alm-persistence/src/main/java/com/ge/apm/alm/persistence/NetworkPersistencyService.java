/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.model.AttributeSelectEnum;
import com.ge.apm.alm.model.Edge;
import com.ge.apm.alm.model.Network;
import com.ge.apm.alm.model.query.NetworkPredicate;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.mirror.Mirror;

/**
 * @author Albert H. Yu 212365823
 * @version 1.0 July 15, 2017
 * @since 1.0
 */
public interface NetworkPersistencyService {

    /**
     * Creates a single top-level network.
     */
    Network createNetwork(String tenantId, Collection<String> accessibleResources, @Mirror Network network)
        throws PersistencyServiceException;

    /**
     * Creates a collection of top-level networks.
     */
    int createNetworks(String tenantId, Collection<String> accessibleResources, @Mirror List<Network> networks)
        throws PersistencyServiceException;

    Network updateNetwork(String tenantId, Collection<String> accessibleResources, @Mirror Network network)
        throws PersistencyServiceException;

    int updateNetworks(String tenantId, Collection<String> accessibleResources, @Mirror List<Network> networks)
        throws PersistencyServiceException;

    /**
     * @return a map of asset identifier to its corresponding network nodes
     */
    Map<String, List<Network>> getNodesByAssetIds(String tenantId, Collection<String> accessibleResources,
        Set<String> assetIds) throws PersistencyServiceException;

    Map<String, List<Network>> getNodesByAssetIdsForNetwork(String tenantId, Collection<String> accessibleResources,
        String networkId, Set<String> assetIds) throws PersistencyServiceException;

    /**
     * Root networks are those that are not sub-networks and not asset nodes. Asset nodes are those
     * "networks" that contain only a single asset.
     *
     * @return a list of root networks
     */
    List<Network> getRootNetworks(String tenantId, NetworkPredicate predicate);

    Network getNetworkById(String tenantId, Collection<String> accessibleResources, String networkId)
        throws PersistencyServiceException;

    List<Network> deleteNetworkById(String tenantId, Collection<String> accessibleResources,
        @Mirror(type = Type.DELETE_NETWORK, clazz = Network.class)String networkId)
        throws PersistencyServiceException;

    List<Network> getNetworksByIds(String tenantId, Collection<String> accessibleResources, Set<String> networkIds,
        AttributeSelectEnum selectEnum) throws PersistencyServiceException;

    Network getNetworkBySourceKey(String tenantId, String sourceKey) throws PersistencyServiceException;

    List<Network> getNetworksBySourceKeys(String tenantId, Set<String> sourceKeys, AttributeSelectEnum selectEnum)
        throws PersistencyServiceException;

    List<Network> getNetworksByNode(String tenantId, NetworkPredicate predicate);

    int addAssetsToNetwork(String tenantId, Collection<String> accessibleResources, @Mirror(type = Type.UPDATE, clazz
        = Network.class) String parentNetworkId,
        List<Asset> childAssets) throws PersistencyServiceException;

    int removeAssetsFromNetwork(String tenantId, Collection<String> accessibleResources, @Mirror(type = Type.UPDATE, clazz
        = Network.class) String parentNetworkId,
        Set<String> assetIds) throws PersistencyServiceException;

    int addChildrenToNetwork(String tenantId, Collection<String> accessibleResources, String parentNetworkId,
        List<Network> children) throws PersistencyServiceException;

    int removeChildrenFromNetwork(String tenantId, Collection<String> accessibleResources, String parentNetworkId,
        Set<String> networkIds) throws PersistencyServiceException;

    int createEdges(String tenantId, Collection<String> accessibleResources, @Mirror List<Edge> edges)
        throws PersistencyServiceException;

    int updateEdge(String tenantId, Collection<String> accessibleResources, @Mirror Edge edge)
        throws PersistencyServiceException;

    int updateEdges(String tenantId, Collection<String> accessibleResources, @Mirror List<Edge> edges)
        throws PersistencyServiceException;

    Edge getNetworkEdgeById(String tenantId, Collection<String> accessibleResources, String parentNetworkId, String
        edgeId);

    Edge getNetworkEdgeById(String tenantId, Collection<String> accessibleResources, String edgeId);

    int deleteEdgeById(String tenantId, Collection<String> accessibleResources, @Mirror(type = Type.DELETE,
        clazz = Edge.class)String edgeId)
        throws PersistencyServiceException;

    /**
     * Fetch all nodes for a given network
     */
    List<Network> getNodesByNetworkId(String tenantId, Collection<String> accessibleResources, String networkId,
        NetworkPredicate queryPredicate);

    /**
     * Query for edges in the given parent network.
     */
    List<Edge> getNetworkEdges(String tenantId, Collection<String> accessibleResources, String parentNetworkId,
        NetworkPredicate queryPredicate);
}
