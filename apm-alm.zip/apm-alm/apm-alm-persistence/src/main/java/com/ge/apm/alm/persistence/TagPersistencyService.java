/*********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 ********************************************************************************/

package com.ge.apm.alm.persistence;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.Tag;
import com.ge.apm.alm.model.query.TagPredicate;
import com.ge.apm.alm.model.view.TagComponent;
import com.ge.apm.alm.persistence.crosstenancy.CrossTenancyGet;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.mirror.Accessible;
import com.ge.apm.alm.persistence.mirror.Mirror;

/**
 * Created by 212365823 on 3/16/17.
 */
public interface TagPersistencyService {

    // Create API's
    Tag createTag(String tenantId, Collection<String> accessibleResources, @Mirror Tag tag)
        throws PersistencyServiceException;

    int createTags(String tenantId, Collection<String> accessibleResources, @Mirror List<Tag> tags)
        throws PersistencyServiceException;

    // Update API's
    Tag updateTag(String tenantId, Collection<String> accessibleResources, @Mirror Tag tag)
        throws PersistencyServiceException;

    int updateTags(String tenantId, Collection<String> accessibleResources, @Mirror List<Tag> tags)
        throws PersistencyServiceException;

    // Delete API's
    int deleteTag(String tenantId, Collection<String> accessibleResources, @Mirror(clazz = Tag.class) String tagId)
        throws PersistencyServiceException;

    int deleteTags(String tenantId, Collection<String> accessibleResources, String assetId,
        @Mirror(clazz = Tag.class) Set<String> tagIds) throws PersistencyServiceException;

    int deleteTagsForAsset(String tenantId, Collection<String> accessibleResources,
        @Mirror(type = AssetEvent.Type.DELETE_TAGS, clazz = Asset.class) String assetId)
        throws PersistencyServiceException;

    // Query API's
    @CrossTenancyGet
    Tag getTagById(String tenantId, @Accessible Collection<String> accessibleResources, String id);

    Tag getTagById(String tenantId, Collection<String> accessibleResources, String id,
        Set<TagComponent> components);

    List<Tag> getTagsByIdsForUpdate(String tenantId, Collection<String> accessibleResources, List<String> ids);

    Tag getTagBySourceKey(String tenantId, Collection<String> accessibleResources, String sourceKey);

    //collections
    List<Tag> getTagsBySourceKeys(String tenantId, Collection<String> accessibleResources, List<String> sourceKeys);

    @CrossTenancyGet
    List<Tag> getTags(String tenantId, @Accessible Collection<String> accessibleResources, TagPredicate tagPredicate);

    List<Tag> getTagsForAsset(String tenantId, Collection<String> accessibleResources, String assetId,
        boolean deepSearch, TagPredicate tagPredicate);

    /**
     * @param id the identifier of any tag in a given correlation
     *
     * @return the list of all tags in the same correlation as the given <code>id</code>
     */
    @CrossTenancyGet
    List<Tag> getCorrelatedTagsById(String tenantId, @Accessible Collection<String> accessibleResources, String id)
        throws PersistencyServiceException;
}
