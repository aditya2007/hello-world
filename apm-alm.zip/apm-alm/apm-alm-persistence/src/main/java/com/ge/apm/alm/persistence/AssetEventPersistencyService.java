/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.EventsJobType;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;

public interface AssetEventPersistencyService {

    void createEvents(Collection<AssetEvent> events) throws PersistencyServiceException;

    int deleteEvents(Collection<AssetEvent> events) throws PersistencyServiceException;

    List<AssetEvent> getPendingEventBatch(Integer jobSize, Long timeoutMillis) throws PersistencyServiceException;

    List<AssetEvent> getPendingEventBatch(final EventsJobType job, final Integer jobSize,
                                          final Long timeoutMillis, final Long expiredTimeoutMillis)
            throws PersistencyServiceException;

    List<AssetEvent> getEvents(String tenantId, AssetEvent.Type eventType, Set<String> objectIds)
        throws PersistencyServiceException;

    int updateEvents(Collection<AssetEvent> events, AssetEvent.EventsJobType jobType, String status)
                                                                throws PersistencyServiceException;

    int updateEventsStatus(final List<String> events, final AssetEvent.EventsJobType jobType,
                                  final String status) throws PersistencyServiceException;

        int updateEvent(String eventId, AssetEvent.EventsJobType jobType, String status)
                                                                throws PersistencyServiceException;

    int cleanupEvents(String status ,String timout) throws PersistencyServiceException;
}
