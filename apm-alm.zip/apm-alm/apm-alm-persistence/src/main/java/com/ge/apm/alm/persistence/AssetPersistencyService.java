/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetHierarchy;
import com.ge.apm.alm.model.query.AssetPredicate;
import com.ge.apm.alm.model.view.AssetComponent;
import com.ge.apm.alm.persistence.crosstenancy.CrossTenancyGet;
import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.mirror.Accessible;
import com.ge.apm.alm.persistence.mirror.Mirror;

/**
 * Created by 212564021 on 2/22/17.
 */
public interface AssetPersistencyService {

    // Create API's
    Asset createAsset(String tenantId, @Accessible Collection<String> accessibleResources, @Mirror Asset asset)
        throws PersistencyServiceException;

    Asset createAsset(String tenantId, @Accessible Collection<String> accessibleResources, String parentId,
        @Mirror Asset child)
        throws PersistencyServiceException;

    int createAssets(String tenantId, @Accessible Collection<String> accessibleResources, @Mirror List<Asset> assets)
        throws PersistencyServiceException;

    // Update API's
    Asset updateAsset(String tenantId, @Accessible Collection<String> accessibleResources, @Mirror Asset asset)
        throws PersistencyServiceException;

    int updateAssets(String tenantId, @Accessible Collection<String> accessibleResources, @Mirror List<Asset> assets)
        throws PersistencyServiceException;

    // Delete API's
    int deleteAsset(String tenantId, @Accessible Collection<String> accessibleResources,
        @Mirror(clazz = Asset.class) String assetId)
        throws PersistencyServiceException;

    // the return value has all deleted objects, so the event type is made not to trigger event handling in the
    // beforePersistence
    AssetHierarchy deleteAssetRecursively(String tenantId, @Accessible Collection<String> accessibleResources,
        @Mirror(type = AssetEvent.Type.RECURSIVE_ASSET_DELETE, clazz = Asset.class) String assetId, String deleteReason)
        throws PersistencyServiceException;

    // Query API's
    @CrossTenancyGet
    Asset getAssetById(String tenantId, @Accessible Collection<String> accessibleResources, String id);

    @CrossTenancyGet
    Asset getAssetById(String tenantId, @Accessible Collection<String> accessibleResources, String id,
        Set<AssetComponent> components, boolean ignoreComponentAcl);

    @CrossTenancyGet
    Asset getAssetBySourceKey(String tenantId, @Accessible Collection<String> accessibleResources, String typeName,
        String sourceKey);

    //collections
    @CrossTenancyGet
    List<Asset> getAssetsBySourceKeys(String tenantId, @Accessible Collection<String> accessibleResources, String typeName,
        List<String> sourceKeys);

    @CrossTenancyGet(tenantified = false)
    List<Asset> getAssets(String tenantId, @Accessible Collection<String> accessibleResources, AssetPredicate queryPredicate);

    @CrossTenancyGet(tenantified = false)
    List<Asset> getAccessibleResources(String tenantId, @Accessible Collection<String> accessibleResources,
        AssetPredicate queryPredicate);

    @CrossTenancyGet
    List<Asset> getChildAssets(String tenantId, @Accessible Collection<String> accessibleResources, String parentId,
        AssetPredicate childPredicate);

    /**
     * @throws ObjectNotFoundException if no asset is found for any asset identifier in the list
     */
    @CrossTenancyGet
    List<Asset> getAssetsByIds(String tenantId, @Accessible Collection<String> accessibleResources, Set<String> assetIds)
        throws ObjectNotFoundException;
}
