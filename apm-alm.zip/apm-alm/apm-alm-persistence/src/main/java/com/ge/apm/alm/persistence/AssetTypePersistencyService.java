/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetType;
import com.ge.apm.alm.model.query.TypePredicate;
import com.ge.apm.alm.model.view.AssetTypeComponent;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.exceptions.SuperTypeDoesNotExistsException;
import com.ge.apm.alm.persistence.mirror.Mirror;

@Service
public interface AssetTypePersistencyService {

    // Create API's
    AssetType createAssetType(String tenantId, @Mirror AssetType assetType) throws SuperTypeDoesNotExistsException;

    int createAssetTypes(String tenantId, @Mirror List<AssetType> assetTypes) throws SuperTypeDoesNotExistsException;

    // Update API's
    AssetType updateAssetType(String tenantId, @Mirror AssetType assetType) throws PersistencyServiceException;

    // Delete API's
    int deleteAssetType(String tenantId, @Mirror(clazz = AssetType.class) String assetTypeId)
        throws PersistencyServiceException;

    int deleteAssetTypeRecursively(String tenantId,
        @Mirror(type = AssetEvent.Type.DELETE_TYPE_RECURSIVELY, clazz = AssetType.class) String assetTypeId)
        throws PersistencyServiceException;

    // Query API's
    AssetType getAssetTypeById(String tenantId, String assetTypeId);

    AssetType getAssetTypeById(String tenantId, String assetTypeId, Set<AssetTypeComponent> components);

    List<AssetType> findChildAssetTypes(String tenantId, String assetTypeId);

    List<AssetType> findChildAssetTypes(String tenantId, String superTypeId, boolean recursive);

    List<AssetType> findChildAssetTypes(String tenantId, String superTypeId, boolean recursive,
        TypePredicate childQueryPredicate);

    List<AssetType> getAssetTypesBySuperTypeAndSourceKeys(String tenantId, String coreTypeName,
        List<String> sourceKeys);

    //TODO: Need to revisit following most likely will be deleted
    //here typeName is core type (also called ccom type. Since assetTypeId is unique
    //there is no point to support this. Exists to ONLY support legacy V1 REST APIs.

    /**
     * @deprecated
     */
    @Deprecated
    AssetType getAssetTypeBySuperTypeAndId(String tenantId, String coreTypeName, String assetTypeId);

    //global search
    List<AssetType> findAllAssetTypes(String tenantId, TypePredicate queryPredicate);

    List<AssetType> findAllAssetTypesWithNoPrefix(String tenantId, TypePredicate queryPredicate);

    //there could be same source key across multiple ccom types (very unlikely - need to be proved)
    AssetType getAssetTypeBySuperTypeAndSourceKey(String tenantId, String coreTypeName, String sourceKey);

    Map<String, List<String>> getSuperTypesByIds(String tenantId, Set<String> assetTypeIds);

    boolean isTypeASuperType(String tenantId, String superTypeId, String typeId);

    /**
     * @return <code>true</code> if the <code>typeIds</code> are all of the given <code>superTypeId</code>
     */
    boolean allTypesAreCompatibleSuperType(String tenantId, String superTypeId, Set<String> typeIds);
}
