/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence;

import java.util.List;

import com.ge.apm.alm.model.AssetPlaceholder;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;

public interface AssetPlaceholderPersistencyService {

    // Create API's
    AssetPlaceholder createAssetPlaceholder(String tenantId, AssetPlaceholder assetPlaceholder);

    int createAssetPlaceholders(String tenantId, List<AssetPlaceholder> assetPlaceholders);

    // Update API's
    AssetPlaceholder updateAssetPlaceholder(String tenantId, AssetPlaceholder assetPlaceholder)
        throws PersistencyServiceException;

    int updateAssetPlaceholders(String tenantId, List<AssetPlaceholder> assetPlaceholders)
        throws PersistencyServiceException;

    // Delete API's
    int deleteAssetPlaceholderById(String tenantId, String id) throws PersistencyServiceException;

    int deleteAssetPlaceholderByAssetId(String tenantId, String assetId) throws PersistencyServiceException;

    // Query API's
    AssetPlaceholder getAssetPlaceholderById(String tenantId, String id);

    AssetPlaceholder getAssetPlaceholderByAssetId(String tenantId, String assetId);

    AssetPlaceholder getAssetPlaceholderByTemplateAndPpn(String tenantId, String templateId, String ppn);

    //collections

    List<AssetPlaceholder> getAssetPlaceholderByAssetIds(String tenantId, List<String> assetIds);

    List<AssetPlaceholder> getAssetPlaceholderByPlaceholderIds(String tenantId, List<String> placeholderIds);
}
