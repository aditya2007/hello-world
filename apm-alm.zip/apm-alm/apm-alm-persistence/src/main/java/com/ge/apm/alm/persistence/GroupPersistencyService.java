/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupCategory;
import com.ge.apm.alm.model.AssetGroupItem;
import com.ge.apm.alm.model.query.GroupPredicate;
import com.ge.apm.alm.persistence.crosstenancy.CrossTenancyGet;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.mirror.Accessible;
import com.ge.apm.alm.persistence.mirror.Mirror;

public interface GroupPersistencyService {

    AssetGroup createAssetGroup(String tenantId, @Mirror AssetGroup assetGroup) throws PersistencyServiceException;

    int createAssetGroups(String tenantId, @Mirror List<AssetGroup> assetGroup) throws PersistencyServiceException;

    AssetGroup updateAssetGroup(String tenantId, @Mirror AssetGroup assetGroup) throws PersistencyServiceException;

    void deleteAssetGroup(String tenantId, @Mirror(clazz = AssetGroup.class) String assetGroupId)
        throws PersistencyServiceException;

    //This deletes Group and all its items if the user has permissions to related asset items
    void deleteAssetGroupRecursively(String tenantId, Collection<String> accessibleResources,
        @Mirror(type = AssetEvent.Type.DELETE_GROUP_AND_ITEMS, clazz = AssetGroup.class) String assetGroupId)
        throws PersistencyServiceException;

    AssetGroup getAssetGroupById(String tenantId, String id);

    AssetGroup getAssetGroupBySourceKey(String tenantId, String sourceKey);

    List<AssetGroup> getAssetGroupsBySourceKeys(String tenantId, List<String> sourceKeys);

    List<AssetGroup> getAssetGroups(String tenantId, GroupPredicate queryPredicate);

    List<AssetGroup> getAssetGroupsOfItem(String tenantId, AssetGroupCategory category, String objectId);

    Map<String, List<AssetGroup>> getAssetGroupsOfItems(String tenantId, AssetGroupCategory category,
        Collection<String> objectIds, boolean forUpdate);

    @CrossTenancyGet
    Map<String, AssetGroup> getCorrelationsForTags(String tenantId, @Accessible Collection<String> accessibleResources,
        Set<String> tagIds);

    @CrossTenancyGet
    Map<String, List<AssetGroupItem>> getCorrelatedTags(String tenantId, @Accessible Collection<String>
        accessibleResources, Set<String> tagIds);

    //Group Items
    int createAssetGroupItems(String tenantId, @Accessible Collection<String> accessibleResources,
        @Mirror(type = Type.UPDATE, clazz = AssetGroup.class) String groupId, List<AssetGroupItem> assetGroupItems)
        throws PersistencyServiceException;

    @CrossTenancyGet
    List<AssetGroupItem> getGroupItems(String tenantId, @Accessible Collection<String> accessibleResources, String groupId)
        throws PersistencyServiceException;

    int deleteAssetGroupItems(String tenantId, @Accessible Collection<String> accessibleResources,
        @Mirror(type = AssetEvent.Type.DELETE_GROUP_ITEMS, clazz = AssetGroup.class) String groupId)
        throws PersistencyServiceException;

    //Used to delete one or more group items if known

    /**
     * @exception UnsupportedOperationException if it is deleting items from a correlated group
     */
    int deleteAssetGroupItems(String tenantId, @Accessible Collection<String> accessibleResources, String groupId,
        @Mirror(clazz = AssetGroupItem.class) List<String> assetGroupItemIds) throws PersistencyServiceException;

    /**
     * Add a new asset group item to an existing group given by <code>groupId</code>. If the group is a correlated one,
     * then the item is appended to the correlation. A {@link PersistencyServiceException} is thrown if the item already
     * exists in the group or it is an item in a different correlated group.
     *
     * @return the added asset group item
     */
    AssetGroupItem addGroupItem(String tenantId, @Accessible Collection<String> accessibleResources,
        @Mirror(type = Type.UPDATE, clazz = AssetGroup.class) String groupId, AssetGroupItem newItem)
        throws PersistencyServiceException;

    /**
     * Insert a new asset group item as the head of an existing correlated group given by the <code>groupId</code>.
     *
     * @param groupId identifier of an existing correlated group
     *
     * @return the inserted asset group item
     *
     * @exception PersistencyServiceException if the group is missing
     * @exception IllegalArgumentException if the group is not a correlated one, or the new item is already in the
     * group,
     */
    AssetGroupItem insertHeadItemToCorrelatedGroup(String tenantId, @Accessible Collection<String> accessibleResources,
        @Mirror(type = Type.UPDATE, clazz = AssetGroup.class) String groupId, AssetGroupItem headItem)
        throws PersistencyServiceException;

    /**
     * Merge the source and target correlated groups and return the merged list. The target group will be merged behind
     * the tail of the source group. Both source and target groups must share the same asset and must not be empty.
     * After the merge, the target group is deleted.
     *
     * @param srcGroup the source group, this is the group that will remain after the merge
     * @param targetGroup the target group to be merged, removed after the merge
     *
     * @return the merged correlation group
     *
     * @exception PersistencyServiceException if either the source or the target groups do not exist
     * @exception IllegalArgumentException if one of the group or both are empty; or they do not share the same asset
     */
    List<AssetGroupItem> mergeCorrelatedGroups(String tenantId, @Accessible Collection<String> accessibleResources,
        @Mirror(type = AssetEvent.Type.UPDATE) AssetGroup srcGroup,
        @Mirror(type = AssetEvent.Type.DELETE) AssetGroup targetGroup) throws PersistencyServiceException;

    /**
     * Disassociate the given correlated group at the position after the <code>objectId</code>.
     * <p>
     * The following use cases demonstrate the API contract <ul> <li>A-B is disassociated after A: leaving no
     * correlation and no group</li> <li>A-B-C is disassociated after A: leaving B-C; A is deleted</li> <li>A-B-C is
     * disassociated after B: leaving A-B; C is deleted</li> <li>A-B-C-D is disassociated after A: leaving B-C-D; A is
     * deleted</li> <li>A-B-C-D is disassociated after B: leaving A-B, C-D; a new group is created for C-D and its
     * groupId returned</li> <li>A-B-C-D is disassociated at C: leaving A-B-C; D is deleted</li> <li>*-D is
     * disassociated at D: this is an error case, client is expected to use the delete API to delete D instead</li>
     * </ul>
     *
     * @param groupId identifier of the given correlated group
     * @param objectId the identifier of the object where the group will be disassociated
     *
     * @return the identifier of the new group that is created due to this disassociation, or <code>null</code> if no
     * new group is created.
     */
    @Mirror(type = Type.CREATE, clazz = AssetGroup.class)
    String disassociateCorrelatedGroup(String tenantId, @Accessible Collection<String> accessibleResources,
        @Mirror(type = Type.UPDATE, clazz = AssetGroup.class) String groupId, String objectId)
        throws PersistencyServiceException;

    /**
     * Delete the given object from the correlated group. Note that the object itself is NOT deleted, only its
     * association with the correlated group is deleted. Depending on where the deleted object is in the correlation,
     * the group itself may also be deleted.
     * <p>
     * The following use cases demonstrate the API contract <ul> <li>A-B is deleted at A or B: A and B are deleted,
     * leaving no correlation group</li> <li>A-B-C is deleted at A: leaving B-C</li> <li>A-B-C is deleted at B: A, B,
     * and C are deleted, leaving no correlation group</li> <li>A-B-C is deleted at C: leaving A-B</li> <li>A-B-C-D is
     * at at A: leaving B-C-D; A is deleted</li> <li>A-B-C-D is deleted at B: leaving C-D; A and B are deleted</li>
     * <li>A-B-C-D is deleted at C: leaving A-B; C and D are deleted</li> <li>A-B-C-D-E is deleted at C: leaving A-B in
     * the original group, C-D in a new group</li> </ul>
     *
     * @param groupId the correlated group identifier
     * @param objectId the object identifier to be deleted
     *
     * @return the identifier of the new group that is created due to this deletion, or <code>null</code> if no new
     * group is created.
     */
    @Mirror(type = Type.CREATE, clazz = AssetGroup.class)
    String deleteCorrelatedItem(String tenantId, @Accessible Collection<String> accessibleResources,
        @Mirror(type = Type.UPDATE, clazz = AssetGroup.class) String groupId, String objectId)
        throws PersistencyServiceException;
}
