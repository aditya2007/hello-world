/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.alm.persistence;

import java.util.List;

import com.ge.apm.alm.model.PlaceholderType;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;

public interface PlaceholderTypePersistencyService {

    // Create API's
    PlaceholderType createPlaceholderType(String tenantId, PlaceholderType placeholderType);

    int createPlaceholderTypes(String tenantId, List<PlaceholderType> placeholderTypes);

    // Update API's
    PlaceholderType updatePlaceholderType(String tenantId, PlaceholderType placeholderType)
        throws PersistencyServiceException;

    int updatePlaceholderTypes(String tenantId, List<PlaceholderType> placeholderTypes)
        throws PersistencyServiceException;

    // Delete API's
    int deletePlaceholderType(String tenantId, String id) throws PersistencyServiceException;

    int deletePlaceholderTypeByPlaceholderIdAndTypeId(String tenantId, String placeholderId, String typeId)
        throws PersistencyServiceException;

    int deletePlaceholderTypeByPlaceholderId(String tenantId, String placeholderId) throws PersistencyServiceException;

    // Query API's
    PlaceholderType getPlaceholderTypeById(String tenantId, String id);

    PlaceholderType getPlaceholderTypeByPlaceholderIdAndTypeId(String tenantId, String placeholderId, String typeId);

    //collections
    List<PlaceholderType> getPlaceholderTypes(String tenantId, String placeholderId);

    List<PlaceholderType> getPlaceholderTypes(String tenantId, String placeholderId, String status);

    List<PlaceholderType> getPlaceholderTypes(String tenantId, List<String> placeholderIds);

    List<PlaceholderType> getPlaceholderTypeByTemplateId(String tenantId, String templateId);
}
