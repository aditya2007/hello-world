/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ge.apm.alm.model.AlmContextConfig;
import com.ge.apm.alm.model.Context;
import com.ge.apm.alm.model.query.ConfigContextQuery;


public interface AlmContextConfigService {

    List<AlmContextConfig> findAll();

    List<AlmContextConfig> findAllByTenantId(String tenantId);

    List<AlmContextConfig> findAllByContextNameAndTenantId(String contextName, String tenantId);

    AlmContextConfig save(AlmContextConfig persisted);

    List<AlmContextConfig> findAllByQuerySpecs(String tenantId, ConfigContextQuery configContextQuery);
}
