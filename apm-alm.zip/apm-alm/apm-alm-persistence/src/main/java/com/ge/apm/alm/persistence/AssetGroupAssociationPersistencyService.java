/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.alm.persistence;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.ge.apm.alm.model.Asset;
import com.ge.apm.alm.model.AssetEvent;
import com.ge.apm.alm.model.AssetEvent.Type;
import com.ge.apm.alm.model.AssetGroup;
import com.ge.apm.alm.model.AssetGroupAssociation;
import com.ge.apm.alm.persistence.exceptions.PersistencyServiceException;
import com.ge.apm.alm.persistence.mirror.Mirror;

public interface AssetGroupAssociationPersistencyService {

    int deleteAssetGroupAssociations(String tenantId, Collection<String> accessibleResources, @Mirror(type = Type.DELETE_ASSET_GROUP_ASSOCIATION) AssetGroupAssociation assetGroupAssociation) throws PersistencyServiceException;

    void createAssetGroupAssociations(String tenantId, @Mirror List<AssetGroupAssociation> assetGroupAssociations)
        throws PersistencyServiceException;

    List<AssetGroup> getAssociatedGroupsByAssetId(String tenantId, Collection<String> accessibleResources,
        String assetId,
        String category) throws PersistencyServiceException;

    Map<String, List<AssetGroup>> getAssociatedGroupsByAssetIds(String tenantId, Collection<String> accessibleResources,
        Collection<String> assetIds,
        String category) throws PersistencyServiceException;

    List<Asset> getAssociatedAssetsByGroupId(String tenantId, Collection<String> accessibleResources, String
        groupId) throws PersistencyServiceException;

    List<AssetGroupAssociation> getAssetGroupAssociationsByAssetAndGroupURI(String tenantId,Collection<String> accessibleResources, String groupId, String assetId);
}
