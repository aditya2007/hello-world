mvn -o spring-boot:run -s ../menlo_settings.xml
