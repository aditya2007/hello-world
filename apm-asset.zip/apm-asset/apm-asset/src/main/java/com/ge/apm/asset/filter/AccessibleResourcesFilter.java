/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.filter;

import java.io.IOException;
import java.util.Set;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.ge.apm.asset.service.api.IAlmPersistenceService;
import com.ge.apm.asset.util.Constants;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.stuf.context.StufContext;
import com.ge.stuf.exception.ForbiddenException;
import com.ge.stuf.exception.HttpRequestException;
import com.ge.stuf.security.context.SecurityContext;
import com.ge.stuf.tenant.context.TenantContext;

@Component
@Order(2)
@Profile("!mockacl")
public class AccessibleResourcesFilter extends AssetBaseFilter {

    @Value("${acs.performance.enabled:false}")
    private boolean enabled;

    @Autowired
    SecurityContext securityContext;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
        throws ServletException, IOException {

        try {
            Set<String> accessibleResources;
            RequestContext.put(RequestContext.AUTHORIZATION, request.getHeader(HttpHeaders.AUTHORIZATION));
            RequestContext.put(RequestContext.TENANT_UUID, request.getHeader(RequestContext.TENANT));
            //We need this for getting UOM serviceInstanceInfo in UOMService
            RequestContext.put(Constants.TENANT_CTX, TenantContext.getInstance());
            RequestContext.put(Constants.STUF_CTX, StufContext.getInstance());
            final String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
            MDC.put("tenant", tenantUuid);
            if (enabled) {
                StopWatch stufStopWatch = new StopWatch("Stuf service");
                stufStopWatch.start();
                accessibleResources = securityContext.getAccessibleResources();
                stufStopWatch.stop();
                logger.info(stufStopWatch.shortSummary());
            } else {
                accessibleResources = securityContext.getAccessibleResources();
            }

            if (accessibleResources == null || accessibleResources.isEmpty()) {
                //No accessible resource
                throw new ForbiddenException("No accessible resource found");
            } else if (accessibleResources.contains(tenantUuid)) {
                //All resources in the tenant accessible
                RequestContext.put(IAlmPersistenceService.ACCESSIBLE_RESOURCES, IAlmPersistenceService.ALL_RESOURCES);
            } else {
                //Specific resources accessible
                RequestContext.put(IAlmPersistenceService.ACCESSIBLE_RESOURCES,
                    accessibleResources.toArray(new String[accessibleResources.size()]));
            }
            filterChain.doFilter(request, response);
        } catch (HttpRequestException hre) {
            sendErrorResponse(request, response, hre);
        } catch (Exception ex) {
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.ACCESSIBLE_RESOURCES),
                ex.getMessage());
        } finally {
            RequestContext.destroy();
        }
    }
}