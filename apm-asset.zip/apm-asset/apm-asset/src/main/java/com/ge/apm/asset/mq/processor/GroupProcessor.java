/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.config.MqAuthConfig;
import com.ge.apm.asset.mq.factory.ControllerFactory;
import com.ge.apm.asset.mq.redis.SourceKeyLookup;
import com.ge.asset.commons.mq.constants.MessageConstants;

/**
 * Created by 212448111 on 2/9/17.
 */
@Component
@Slf4j
public class GroupProcessor extends DtoProcessor {

    @Autowired
    ControllerFactory controllerFactory;

    @Autowired
    MqAuthConfig mqAuthConfig;

    @Autowired
    SourceKeyLookup sourceKeyLookup;

    /**
     * This processor will set headers for request.
     * [NO LONGER APPLICABLE : "The preprocess specific controller to persist grouptype in predix if it doesn't exist."]
     *
     * @param exchange The camel exchange
     *
     * @exception Exception shall throw exception
     */
    @Override
    public void preProcess(Exchange exchange) {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        String authorization = messageHeaders.get(MessageConstants.AUTHORIZATION).toString();
        String task = messageHeaders.get(MessageConstants.TASK_UUID).toString();
        String traceUuid = messageHeaders.get(MessageConstants.TRACE_UUID).toString();
        MDC.put(STR_TRACEID, traceUuid);
        MDC.put(STR_SUBJECT, task);


        mqAuthConfig.configure(tenantUuid, authorization, Prefixes.GroupTypes, RequestMethod.GET);
        /*
         * As groupTypeUri is fictious, there is not need to create/persist this field
         * in relation DB world. Hence commenting it out.
         */
        /*
        try {
            sourceKeyLookup.lookupObjectUriFor(tenantUuid,
                    Prefixes.GroupTypes + "/" + GroupType.SOURCE_KEY);
        } catch (DependencyViolationException dve) {
            log.error(dve.getMessage(), dve);
            //Create system level GroupType if it doesn't exist
            GroupType groupType = new GroupType();
            groupType.setName(GroupType.SOURCE_KEY);
            groupType.setDescription(GroupType.SOURCE_KEY);
            groupType.setSourceKey(GroupType.SOURCE_KEY);
            List<GroupType> groupTypes = new ArrayList<>();
            groupTypes.add(groupType);

            controllerFactory.getController(Prefixes.GroupTypes).create(groupTypes.toArray(new Attributable[0]));
        }
        */
    }
}
