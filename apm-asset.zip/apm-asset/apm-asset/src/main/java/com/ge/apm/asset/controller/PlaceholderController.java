/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.model.Placeholder;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.ITemplateService;

@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.Placeholders, IBasePath.v3 + Prefixes.Placeholders })
public class PlaceholderController extends AbstractController<Placeholder, ITemplateService> {

    public PlaceholderController() {
        super(Prefixes.Placeholders, Placeholder.class);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/reservedAttributes")
    @ResponseBody
    public Map<String, ReservedAttributeConfig> reservedAttributes() {
        return this.getReservedAttributes();
    }
}
