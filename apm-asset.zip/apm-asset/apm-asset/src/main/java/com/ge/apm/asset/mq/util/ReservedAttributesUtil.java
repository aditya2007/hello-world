/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.javers.common.collections.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.factory.ControllerFactory;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationResult;
import com.ge.asset.commons.validator.Validator;
import com.ge.asset.commons.validator.apm.ReservedAttributeValidation;

@Component
@Slf4j
public class ReservedAttributesUtil<T extends Hierarchical> {

    private static final String VALIDATION_RESULT = "validationResult";

    private static final String CONST_KEYVALUE = "KeyValue";

    private static final String CONST_UnitOfMeasure = "UnitOfMeasure";

    private static final String CONST_KEY = "key";

    @Autowired
    ControllerFactory controllerFactory;

    private static String getPropertyName(Exchange exchange) {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        String taskUuid = messageHeaders.get(MessageConstants.TASK_UUID).toString();
        return VALIDATION_RESULT + "_" + tenantUuid + "_" + taskUuid;
    }

    private static void setValidationResults(Exchange exchange, ValidationResult validationResult) {
        ValidationResult existingValidations = exchange.getProperty(getPropertyName(exchange), ValidationResult.class);
        if (existingValidations == null) {
            exchange.setProperty(getPropertyName(exchange), validationResult);
        } else if (!validationResult.isValid()) {
            existingValidations.setValid(false);
            existingValidations.getErrors().addAll(validationResult.getErrors());
            exchange.setProperty(getPropertyName(exchange), existingValidations);
        }
    }

    private static boolean constructReservedAttributeMap(String key, Map<String, Object> reservedAttributeMap,
        Object attrValue, String reservedAttributeType, Map<String, ReservedAttributeConfig> reservedAttributeConfigMap,
        Exchange exchange) {
        ReservedAttributeConfig reservedAttributeConfig = reservedAttributeConfigMap.get(key);
        String type = reservedAttributeConfig.getType();
        try {
            if (StringUtils.equals(CONST_KEYVALUE, type)) {
                Map<String, String> keyValMap = new HashMap<>();
                keyValMap.put(CONST_KEY, (String) attrValue);
                reservedAttributeMap.put(key, keyValMap);
            } else if (StringUtils.equals(CONST_UnitOfMeasure, type)) {
                String unitValue = (String) attrValue;
                reservedAttributeMap.put(key, unitValue);
            } else if (attrValue instanceof List) {
                reservedAttributeMap.put(key, attrValue);
            } else {
                switch (reservedAttributeType.toUpperCase(Locale.getDefault())) {
                    case "INTEGER":
                        reservedAttributeMap.put(key, Integer.valueOf(attrValue.toString()));
                        break;
                    case "DOUBLE":
                        reservedAttributeMap.put(key, Double.valueOf(attrValue.toString()));
                        break;
                    case "FLOAT":
                        reservedAttributeMap.put(key, Float.valueOf(attrValue.toString()));
                        break;
                    default:
                        reservedAttributeMap.put(key, attrValue);
                        break;
                }
            }
        } catch (ClassCastException cce) {
            log.error(cce.getMessage());
            ValidationResult vr = new ValidationResult();
            vr.setValid(false);
            String message = ErrorProvider.findMessage(ErrorConstants.INCOMPATIBLE_RESERVED_ATTRIBUTE,
                attrValue.toString(), reservedAttributeConfig.getType(), key);
            Error error = new Error(Error.ErrorType.ERROR, ErrorConstants.INCOMPATIBLE_RESERVED_ATTRIBUTE, message);
            vr.getErrors().add(error);
            setValidationResults(exchange, vr);
            return false;
        }
        return true;
    }

    public Map<String, ReservedAttributeConfig> getReservedAttributesConfigMapIfExists(String prefix) {
        Map<String, ReservedAttributeConfig> configMap = new HashMap<>();
        // get reserved attributes configMap if the prefix the assetTypes,
        // measurementTagTypes, templates, and placeholder
        if (prefix.equals(Prefixes.Templates)) {
            configMap = controllerFactory.getController(prefix).reservedAttributes();
        } else if (prefix.equals(Prefixes.AssetTypes) || prefix.equals(Prefixes.MeasurementTagTypes)) {
            configMap = controllerFactory.getController(prefix).reservedAttributes();
        } else if (prefix.equals(Prefixes.Enterprises) || prefix.equals(Prefixes.Segments) || prefix.equals(
            Prefixes.Sites)) {
            configMap = controllerFactory.getController(prefix).reservedAttributes();
        }
        return configMap;
    }

    public ValidationResult getValidationResult(Exchange exchange) {
        if (exchange.getProperty(getPropertyName(exchange)) != null) {
            return (ValidationResult) exchange.getProperty(getPropertyName(exchange));
        }
        return null;
    }

    public void validateReservedAttributesIfExists(String prefix, T dto, String typeUri, Exchange exchange,
        String sourceKey) {
        Map<String, Object> reservedAttributesMap = dto.getReservedAttributes();
        if (reservedAttributesMap != null && !reservedAttributesMap.isEmpty()) {
            // get configMap based on the typeUri
            Map<String, ReservedAttributeConfig> configMap;
            if (prefix.equals(Prefixes.Enterprises) || prefix.equals(Prefixes.Segments) || prefix.equals(
                Prefixes.Sites)) {
                configMap = controllerFactory.getController(prefix).reservedAttributes();
            } else {
                configMap = controllerFactory.getController(prefix).reservedAttributes(typeUri);
            }
            validateReservedAttributes(reservedAttributesMap, configMap, exchange, sourceKey, prefix);
        }
    }

    public void validateReservedAttributes(Map<String, Object> reservedAttributesMap,
        Map<String, ReservedAttributeConfig> configMap, Exchange exchange, String sourceKey, String prefix) {

        // construct reservedAttributeMap based on customized feature
        Iterator<Entry<String, Object>> iter = reservedAttributesMap.entrySet().iterator();
        while (iter.hasNext()) {
            Entry<String, Object> entry = iter.next();
            String key = entry.getKey();
            ReservedAttributeConfig configMapAttribute = configMap.get(key);
            if (configMapAttribute != null) {
                if (!constructReservedAttributeMap(key, reservedAttributesMap, entry.getValue(),
                    configMap.get(key).getType(), configMap, exchange)) {
                    iter.remove();
                }
            }
        }

        // call reservedAttributeValidation
        ReservedAttributeValidation reservedAttributeValidation = new ReservedAttributeValidation();
        reservedAttributeValidation.getValidationContext().put(Validator.CONTEXT_RESERVED_ATTRIBUTE_CONFIG, configMap);
        ValidationResult validationResult = reservedAttributeValidation.validate(reservedAttributesMap);
        setValidationResults(exchange, validationResult);

        // parse validationResult to generate warning message
        if (validationResult != null && !validationResult.isValid()) {
            Map<String, Object> validationResultContextMap = validationResult.getResponseContext();
            if (validationResultContextMap != null && !validationResultContextMap.isEmpty()) {
                validationResultContextMap.forEach((key, value) -> {
                    // remove the unqualified reserved attribute from the map and continue process
                    reservedAttributesMap.remove(key);
                });
            }
            if (validationResult.getErrors() != null) {
                for (com.ge.asset.commons.validator.Error error : validationResult.getErrors()) {
                    List<Object> errList = Arrays.asList(error.getPlaceHolders());
                    errList.add(StringUtils.substringAfterLast(prefix, "/"));
                    errList.add(sourceKey);
                    error.setPlaceHolders(errList.toArray(new String[errList.size()]));
                }
            }
        }
    }
}
