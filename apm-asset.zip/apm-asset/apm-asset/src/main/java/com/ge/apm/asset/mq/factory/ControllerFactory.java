/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.factory;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.controller.base.ISearchController;
import com.ge.apm.asset.controller.base.ISourceKeyController;
import com.ge.apm.asset.controller.base.ITagController;

@Component
public class ControllerFactory implements InitializingBean {

    @Autowired
    List<ICrudController> crudControllers;

    Map<String, ICrudController> crudControllerMap;

    @Autowired
    List<ISourceKeyController> sourceKeyControllers;

    Map<String, ISourceKeyController> sourceKeyControllersMap;

    @Autowired
    List<ITagController> tagControllers;

    Map<String, ITagController> tagControllersMap;

    @Autowired
    List<ISearchController> searchControllers;

    Map<String, ISearchController> searchControllersMap;

    @Override
    public void afterPropertiesSet() throws Exception {

        crudControllerMap = crudControllers.stream().collect(Collectors.toMap(ICrudController::getPrefix, c -> c));

        sourceKeyControllersMap = sourceKeyControllers.stream().collect(
            Collectors.toMap(ISourceKeyController::getPrefix, c -> c));

        tagControllersMap = tagControllers.stream().collect(Collectors.toMap(ITagController::getPrefix, c -> c));

        searchControllersMap = searchControllers.stream().collect(
            Collectors.toMap(ISearchController::getPrefix, c -> c));
    }

    public ICrudController getController(String prefix) {
        if (!crudControllerMap.containsKey(prefix)) {
            throw new AssertionError("Unknown prefix " + prefix + " which has no corresponding ICrudController.");
        }
        return crudControllerMap.get(prefix);
    }

    public ISourceKeyController<?, ?> getSourceController(String prefix) {
        if (!sourceKeyControllersMap.containsKey(prefix)) {
            throw new AssertionError("Unknown prefix " + prefix + " which has no corresponding ISourceKeyController.");
        }
        return sourceKeyControllersMap.get(prefix);
    }

    public ITagController<?, ?> getTagController(String prefix) {
        if (!tagControllersMap.containsKey(prefix)) {
            throw new AssertionError("Unknown prefix " + prefix + " which has no corresponding ITagController.");
        }
        return tagControllersMap.get(prefix);
    }

    public ISearchController<?, ?> getSearchController(String prefix) {
        if (!searchControllersMap.containsKey(prefix)) {
            throw new AssertionError("Unknown prefix " + prefix + " which has no corresponding ISearchController.");
        }
        return searchControllersMap.get(prefix);
    }
}