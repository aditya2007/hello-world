/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.apm.asset.model.AssetFeature;
import com.ge.apm.asset.model.AssetUserPolicy;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.impl.AssetPolicyManagementService;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.support.RequestContext;

@Controller
@Slf4j
@RequestMapping(value = { IBasePath.v1, IBasePath.v3 + Prefixes.Tenants + "/{tenantId}" })
public class AssetPolicyController {

    @Autowired
    private AssetPolicyManagementService assetPolicyManagementService;

    @RequestMapping(value = "/assetRestrictionFeatures", method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.OK)
    public Map<String, List<AssetFeature>> getAssetRestrictionFeatures(@RequestParam(required = false) Boolean active) {
        log.debug("In getAssetRestrictionFeatures with Active Flag: {}", active);
        try {
            return assetPolicyManagementService.getAssetRestrictionFeatures(active);
        } catch (ServiceException ex) {
            log.error("[getAssetRestrictionFeatures:]", ex);
            throw ExceptionUtil.wrapException(ex, ex.getCode());
        }
    }

    @RequestMapping(value = "/assetUserPolicies", method = RequestMethod.POST,
        consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(value = HttpStatus.CREATED)
    public void createAssetUserPolicies(@RequestBody AssetUserPolicy assetUserPolicy) {
        log.debug("In createAssetUserPolicies with AssetUserPolicy: {}", assetUserPolicy);
        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        assetPolicyManagementService.saveAssetUserPolicy(tenantId, assetUserPolicy);
    }

    @RequestMapping(value = "/assetUserPolicies", method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(value = HttpStatus.OK)
    @ResponseBody
    public List<AssetUserPolicy> getAssetUserPoliciesByFeature(@RequestParam String assetRestrictionFeatureId) {
        log.debug("In getAssetUserPoliciesByFeature with assetRestrictionFeatureId: {}", assetRestrictionFeatureId);
        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        return assetPolicyManagementService.getAssetUserPoliciesByFeatureId(tenantId, assetRestrictionFeatureId);
    }

    @RequestMapping(value = "/assetUserPolicies/{uuid}", method = RequestMethod.DELETE)
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void deleteAssetUserPoliciesById(@PathVariable("uuid") String assetUserPolicyId) {
        log.debug("In deleteAssetUserPoliciesById with assetUserPolicyId: {}", assetUserPolicyId);
        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        assetPolicyManagementService.deleteAssetUserPoliciesById(tenantId, assetUserPolicyId);
    }
}
