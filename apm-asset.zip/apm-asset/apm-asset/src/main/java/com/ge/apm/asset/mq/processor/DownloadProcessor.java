/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.apm.blob.client.BlobArchiveClient;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Created by 502670744 on 9/20/17.
 */
@Component
@Slf4j
public abstract class DownloadProcessor implements Processor {

    @Value("${blobStorage.url}")
    private String blobStorageUrl;

    @Autowired
    BlobArchiveClient blobArchiveClient;

    public String archive(Exchange exchange, String json, String fileName) throws IOException,
        ValidationFailedException {
        String jsonFileName = fileName + ".json";
        String zipFileName = fileName + ".zip";
        exchange.getIn().setHeader(Exchange.FILE_NAME, zipFileName);
        exchange.getIn().setHeader(MessageConstants.PERDIX_BLOB_FILE_KEY, zipFileName);
        return blobArchiveClient.archiveBlob(exchange, getZippedStream(json, jsonFileName));
    }

    /*private BlobArchiveClient getBlobArchiveClient() {
        if (this.blobArchiveClient == null) {
            this.blobArchiveClient = new BlobArchiveClient(this.blobStorageUrl);
        }
        return this.blobArchiveClient;
    }*/

    private InputStream getZippedStream(String json, String jsonFileName) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(out);
        try {
            zos.putNextEntry(new ZipEntry(jsonFileName));
            zos.write(json.getBytes("UTF-8"));
        } finally {
            zos.closeEntry();
            zos.close();
        }
        return new ByteArrayInputStream(out.toByteArray());
    }
}
