/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.util;

import java.util.HashMap;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.EnableAsync;
import redis.clients.jedis.JedisPoolConfig;

import com.ge.apm.util.filter.CorsFilter;

@Configuration
@EnableCaching
@EnableAsync
@Profile("cloud")
@Slf4j
public class CloudConfiguration extends CachingConfigurerSupport {

    private static final Logger logger = LoggerFactory.getLogger(CorsFilter.class);

    @Value("${predixObjectsByUriCache.expire.hrs}")
    private Integer predixObjectsByUriCache;

    @Value("${predixObjectsBySrcKeyCache.expire.hrs}")
    private Integer predixObjectsBySrcKeyCache;

    @Value("${apm.reservedAttr.uomCache.expire.hrs}")
    private Integer uomCacheExpireHours;

    @Value("${apm.reservedAttr.reservedAttributeConfigCache.expire.hrs}")
    private Integer reservedAttributeConfigCacheExpireHours;

    @Value("${jedis.pool.config.maxTotal:100}")
    private Integer maxTotal;

    @Value("${jedis.pool.config.maxIdle:100}")
    private Integer maxIdle;

    @Value("${jedis.pool.config.minIdle:25}")
    private Integer minIdle;

    @Value("${jedis.pool.config.blockWhenExhausted:true}")
    private Boolean blockWhenExhausted;

    @Value("${jedis.pool.config.maxWait:500}")
    private Integer maxWait;

    @Value("${jedis.pool.config.timeBetweenEvictionRuns:15000}")
    private Integer timeBetweenEvictionRuns;

    @Value("${jedis.pool.config.testPerEviction:30}")
    private Integer testPerEviction;

    @Bean(name = { "redisTemplate" })
    public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        JedisConnectionFactory jedisConnectionFactory = (JedisConnectionFactory) redisConnectionFactory;
        jedisConnectionFactory.setUsePool(true);
        JedisPoolConfig jedisPoolConfig = jedisConnectionFactory.getPoolConfig();
        jedisPoolConfig.setMaxTotal(maxTotal);
        jedisPoolConfig.setMaxIdle(maxIdle);
        jedisPoolConfig.setMinIdle(minIdle);
        //Setting to true will result in better behavior when unexpected load hits in production
        jedisPoolConfig.setBlockWhenExhausted(blockWhenExhausted);
        jedisPoolConfig.setMaxWaitMillis(maxWait);
        jedisPoolConfig.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRuns);
        jedisPoolConfig.setNumTestsPerEvictionRun(testPerEviction);
        jedisConnectionFactory.afterPropertiesSet();
        RedisTemplate<Object, Object> template = new RedisTemplate();
        template.setConnectionFactory(jedisConnectionFactory);
        return template;
    }

    @Bean
    CacheManager cacheManager(RedisOperations<Object, Object> redisOperations) {
        try {
            JedisPoolConfig jedisPoolConfig = ((JedisConnectionFactory) ((RedisTemplate<Object, Object>) redisOperations).getConnectionFactory())
                .getPoolConfig();
            log.debug(
                "Jedis Configuration Log: maxTotal is {}, maxIdle is {}, minIdle is {}, block when exhausted is {}, " + "max wait is " + "{}, time " + "between evictions is {}, test per eviction is {}",
                jedisPoolConfig.getMaxTotal(), jedisPoolConfig.getMaxIdle(), jedisPoolConfig.getMinIdle(),
                jedisPoolConfig.getBlockWhenExhausted(), jedisPoolConfig.getMaxWaitMillis(), jedisPoolConfig.getTimeBetweenEvictionRunsMillis(), jedisPoolConfig.getNumTestsPerEvictionRun());
        } catch (Exception ex) {
            log.warn("Error Printing out Jedis Pool Configuration!", ex);
        }

        RedisCacheManager redisCacheManager = new RedisCacheManager((RedisTemplate<Object, Object>) redisOperations);
        long expiryHrs = 24;
        redisCacheManager.setDefaultExpiration(expiryHrs * 60 * 60); //default 24 hours
        Map<String, Long> cacheNameAndExpiryMap = new HashMap<>();
        cacheNameAndExpiryMap.put("uomCache", new Long(uomCacheExpireHours * 60 * 60));
        cacheNameAndExpiryMap.put("reservedAttributeConfigCache",
            new Long(reservedAttributeConfigCacheExpireHours * 60 * 60));
        cacheNameAndExpiryMap.put("predixObjectsByUriCache", new Long(predixObjectsByUriCache * 60 * 60));
        cacheNameAndExpiryMap.put("predixObjectsBySrcKeyCache", new Long(predixObjectsBySrcKeyCache * 60 * 60));
        redisCacheManager.setExpires(cacheNameAndExpiryMap);
        redisCacheManager.setUsePrefix(true);
        return redisCacheManager;
    }

    @Bean
    @Override
    public CacheErrorHandler errorHandler() {
        return new CacheErrorHandler() {
            @Override
            public void handleCacheGetError(RuntimeException ex, Cache cache, Object key) {
                log.warn("failed to get from cache {}, key {}", cache.getName(), key, ex);
            }

            @Override
            public void handleCachePutError(RuntimeException ex, Cache cache, Object key, Object value) {
                log.warn("failed to PUT in cache {}, key {}", cache.getName(), key, ex);
            }

            @Override
            public void handleCacheEvictError(RuntimeException ex, Cache cache, Object key) {
                log.warn("failed to EVICT from cache {}, object {}", cache.getName(), key, ex);
            }

            @Override
            public void handleCacheClearError(RuntimeException ex, Cache cache) {
                log.warn("failed to CLEAR cache {}", cache.getName(), ex);
            }
        };
    }
}
