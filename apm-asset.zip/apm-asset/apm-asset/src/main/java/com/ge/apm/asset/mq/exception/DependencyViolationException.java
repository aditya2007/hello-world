/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.exception;

import java.util.ArrayList;
import java.util.List;

import com.ge.apm.common.exception.IErrorCode;
import com.ge.asset.commons.errorprovider.AssetError;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.exception.AssetServiceException;

/**
 * DependencyViolationException is thrown when APM asset hierarchical dependency is not satisfied. For example, when
 * creating an enterprise instance without its parent enterprise type (classification), the application is expected
 * to throw this exception.
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Apr 6, 2016
 * @since 1.0
 */
public class DependencyViolationException extends AssetServiceException {

    private static final long serialVersionUID = -2682385381413604685L;

    public DependencyViolationException(List<DependencyViolationException> exceptions) {
        super(aggregateMsgs(exceptions));
        aggregateErrors(exceptions);
    }

    public DependencyViolationException(String message, Object... messageArgs) {
        super(message, messageArgs);
    }

    public DependencyViolationException(IErrorCode errorCode, Object... messageArgs) {
        super(errorCode, messageArgs);
        if (this.errors == null) {
            this.errors = new ArrayList<>();
        }
        String errCode = errorCode.name() == null ? ErrorConstants.SYSTEM_ERROR : errorCode.name();
        AssetError assetError = ErrorProvider.findError(errCode);
        assetError.setMsg(this.getMessage());
        this.errors.add(assetError);
    }

    public DependencyViolationException(Throwable throwable) {
        super(throwable.getMessage(), throwable, null);
    }

    private static String aggregateMsgs(List<DependencyViolationException> exceptions) {
        StringBuilder aggregated = new StringBuilder();
        for (DependencyViolationException ex : exceptions) {
            aggregated.append(ex.getMessage()).append(" ");
        }
        return aggregated.toString().trim();
    }

    private void aggregateErrors(List<DependencyViolationException> exceptions) {
        if (this.errors == null) {
            this.errors = new ArrayList<>();
        }
        AssetError assetError;
        for (DependencyViolationException exception : exceptions) {
            String errCode = exception.getCode() == null ? ErrorConstants.SYSTEM_ERROR : exception.getCode();
            assetError = ErrorProvider.findError(errCode);
            assetError.setMsg(exception.getMessage());
            this.errors.add(assetError);
        }
    }
}
