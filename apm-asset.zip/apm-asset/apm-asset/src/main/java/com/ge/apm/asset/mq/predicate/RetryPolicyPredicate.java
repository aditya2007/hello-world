/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.predicate;

import java.net.SocketException;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.springframework.http.HttpStatus;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;

import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

/**
 * Created by 212576241 on 2/17/17.
 */
@Component
@Slf4j
public class RetryPolicyPredicate implements Predicate {

    /*
     * Http status codes which indicates temporary outages.
     */
    protected static final List<HttpStatus> RECOVERABLE_HTTP_ERRORS = Arrays.asList(HttpStatus.REQUEST_TIMEOUT,
        HttpStatus.TOO_MANY_REQUESTS, HttpStatus.BAD_GATEWAY, HttpStatus.SERVICE_UNAVAILABLE,
        HttpStatus.GATEWAY_TIMEOUT, HttpStatus.BANDWIDTH_LIMIT_EXCEEDED);

    @Override
    public boolean matches(Exchange exchange) {
        return isRecoverableException(exchange.getException());
    }

    public boolean isRecoverableException(Exception exception) {
        Stack<Throwable> exceptionTrace = unwrapException(exception); //NOSONAR
        while (!exceptionTrace.empty()) {
            Throwable cause = exceptionTrace.pop();
            try {
                throw cause;
            } catch (DependencyViolationException dve) {
                log.error(dve.getMessage());
                return true;
            } catch (SocketException se) {
                log.error(se.getMessage());
                if (se.getMessage() != null && se.getMessage().contains("Connection reset")) {
                    return true;
                }
            } catch (JpaSystemException jse) {
                log.error(jse.getMessage());
                return true;
            } catch (HttpStatusCodeException hsce) {
                log.error(hsce.getMessage());
                if (RECOVERABLE_HTTP_ERRORS.contains(hsce.getStatusCode())) {
                    return true;
                }
            } catch (BadRequestException bre) {
                log.error(bre.getMessage());
                if (bre.getCode() != null && (bre.getCode().equals(ErrorConstants.DUPLICATE_SOURCE_KEY) || bre.getCode()
                    .equals(ErrorConstants.DUPLICATE_SOURCE_KEY_TAG))) {
                    return true;
                }
            } catch (ServiceException se) {
                log.error(se.getMessage());
                String resourceGraphError = org.apache.commons.lang.StringUtils.substringBefore(
                    ErrorProvider.findError(ErrorConstants.RESOURCE_GRAPH).message(), ":");
                if (se.getMessage() != null && se.getMessage().contains(resourceGraphError)) {
                    return true;
                }
            } catch (Throwable ex) { //NOSONAR - To persist even errors we need Throwable
                continue;
            }
        }
        return false;
    }

    private Stack<Throwable> unwrapException(Throwable exception) { //NOSONAR
        Stack<Throwable> exceptionTrace = new Stack<>(); //NOSONAR
        while (exception != null) {
            exceptionTrace.push(exception);
            exception = exception.getCause();
        }
        return exceptionTrace;
    }
}