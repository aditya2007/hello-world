/*
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.
 *
 * The copyright to the computer software herein is the property of GE Digital.
 * The software may be used and/or copied only with the written permission of
 * GE Digital or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the software has been supplied.
 */

package com.ge.apm.asset.filter;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAlmPersistenceService;
import com.ge.apm.asset.util.Constants;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.stuf.context.StufContext;
import com.ge.stuf.exception.HttpRequestException;
import com.ge.stuf.tenant.context.TenantContext;

@Component
@Order(2)
@Profile("mockacl")
public class MockAccessibleResourcesFilter extends AccessibleResourcesFilter {

    @Value("${acs.performance.enabled:false}")
    private boolean enabled;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
        throws IOException {

        try {
            // get the Tenant ID from the HTTP Header
            String tenantId = request.getHeader(RequestContext.TENANT);
            RequestContext.put(RequestContext.TENANT_UUID, tenantId);
            MDC.put("tenant", tenantId);

            RequestContext.put(Constants.TENANT_CTX, TenantContext.getInstance());
            RequestContext.put(Constants.STUF_CTX, StufContext.getInstance());

            // set the Authorization header in request context
            RequestContext.put(RequestContext.AUTHORIZATION, request.getHeader(HttpHeaders.AUTHORIZATION));

            // collect accessible resources
            collectAccessibleResources(request);

            filterChain.doFilter(request, response);
        } catch (HttpRequestException hre) {
            sendErrorResponse(request, response, hre);
        } catch (Exception ex) {
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.ACCESSIBLE_RESOURCES),
                ex.getMessage());
        } finally {
            RequestContext.destroy();
        }
    }

    private void collectAccessibleResources(HttpServletRequest request) {

        String tenantId = request.getHeader(RequestContext.TENANT);
        Set<String> accessibleResources = null;
        String acl = request.getHeader("acl");
        if (StringUtils.isEmpty(acl)) {
            accessibleResources = securityContext.getAccessibleResources();
        } else {
            accessibleResources = new HashSet<>(Arrays.asList(acl.split(",")));
        }

        if (accessibleResources.contains(tenantId)) {
            RequestContext.put(IAlmPersistenceService.ACCESSIBLE_RESOURCES, IAlmPersistenceService.ALL_RESOURCES);
        } else {
            RequestContext.put(IAlmPersistenceService.ACCESSIBLE_RESOURCES,
                accessibleResources.toArray(new String[accessibleResources.size()]));
        }

        HashMap<String, String[]> allAccessibleResourcesMap = new HashMap<>();
        RequestContext.put(IAlmPersistenceService.ALL_ACCESSIBLE_RESOURCES, allAccessibleResourcesMap);

        // put the primary tenant
        allAccessibleResourcesMap.put(tenantId, accessibleResources.toArray(new String[accessibleResources.size()]));

        // other tenants, for testing purpose only
        for (int i = -1; i < 10; i++) {
            String tenant = "cross-tenant";
            if (i >= 0) {
                tenant += i;
            }
            String crossTenantAccessibleResources = request.getHeader(tenant);
            if (StringUtils.isNotEmpty(crossTenantAccessibleResources)) {
                allAccessibleResourcesMap.put(crossTenantAccessibleResources.split("=")[0],
                    crossTenantAccessibleResources.split("=")[1].split(","));
            }
        }

        // Check if the Request URI have Tenant Id and is different then the context tenant
        if (StringUtils.contains(request.getRequestURI(), Prefixes.Tenants + "/")) {
            RequestContext.remove(IAlmPersistenceService.ALL_ACCESSIBLE_RESOURCES);
            // any further operation is in the context of the Tenant specified in URL
            String urlTenantId = StringUtils.substringBetween(request.getRequestURI(), Prefixes.Tenants + "/", "/");
            if (!StringUtils.equals(tenantId, urlTenantId)) {
                RequestContext.remove(IAlmPersistenceService.ACCESSIBLE_RESOURCES);

                Map<String, Object> allAcls = new HashMap<>();
                allAcls.put(urlTenantId, allAccessibleResourcesMap.get(urlTenantId));
                 // get the accessible resources for uri tenant
                RequestContext.put(IAlmPersistenceService.ALL_ACCESSIBLE_RESOURCES, allAcls);
            }
        }

    }

}