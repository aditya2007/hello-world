/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.NextCorrelatedTag;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.config.MqAuthConfig;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.asset.mq.redis.SourceKeyLookup;
import com.ge.apm.asset.mq.util.ReservedAttributesUtil;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.mq.constants.MessageConstants;

/**
 * Created by 212448111 on 2/9/17.
 */
@Component
@Slf4j
public class TagProcessor extends DtoProcessor<MeasurementTag> {

    @Autowired
    MqAuthConfig mqAuthConfig;

    @Autowired
    SourceKeyLookup sourceKeyLookup;

    @Autowired
    ReservedAttributesUtil reservedAttributesUtil;

    /**
     * The process calls specific controller to persist tags in predix and also takes care of tag correlations by
     * persisting.
     *
     * @param exchange The camel exchange
     *
     * @exception DependencyViolationException If there are any tags to remained unacknowledged.
     */
    @Override
    public void process(Exchange exchange) throws DependencyViolationException {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantId = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        String authToken = messageHeaders.get(MessageConstants.AUTHORIZATION).toString();

        MeasurementTag[] tags = (MeasurementTag[]) exchange.getIn().getBody(Object[].class);
        MeasurementTag[] originalTags = (MeasurementTag[]) exchange.getOut().getBody(Object[].class);

        //ASSUMPTION: All tags in the array has same monitoredEntityUri
        String srcKeyWithPrefix = tags[0].getMonitoredEntitySourceKey();
        log.debug("Started ingesting tags for entity {}, size {}", srcKeyWithPrefix, originalTags.length);

        if (!srcKeyWithPrefix.contains("/")) {
            throw new ServiceException(ErrorProvider.findError(ErrorConstants.BAD_REQUEST_SRCKEY_PREFIX));
        }

        String monitoredEntityPrefix = StringUtils.substringBeforeLast(srcKeyWithPrefix, "/");
        String monitoredEntitySrcKey = StringUtils.substringAfterLast(srcKeyWithPrefix, "/");

        String monitoredEntityUri = sourceKeyLookup.lookupObjectUriFor(tenantId, srcKeyWithPrefix);
        String monitoredEntityUuid = StringUtils.substringAfterLast(monitoredEntityUri, "/");

        List<DependencyViolationException> dependencyViolationExceptions = new ArrayList<>();
        //Set correlated tags to null and persist in predix. In next step we send these tags
        // again to persist
        //correlated tags to avoid dependency violation error
        MeasurementTag[] tagsToUpdateArr = new MeasurementTag[tags.length];
        MeasurementTag[] tagsToRetryArr = new MeasurementTag[tags.length];
        for (int idx = 0; idx < tags.length; idx++) {
            MeasurementTag tag = tags[idx];
            tag.setMonitoredEntitySourceKey(monitoredEntitySrcKey);
            if (tag.getNextRelatedTag() != null && !org.springframework.util.StringUtils.isEmpty(
                tag.getNextRelatedTag().getTagUri())) {
                try {
                    String existingSrcKeyUri = sourceKeyLookup.lookupObjectUriFor(tenantId,
                        Prefixes.MeasurementTags + "/" + tag.getNextRelatedTag().getTagUri());
                    tag.getNextRelatedTag().setTagUri(existingSrcKeyUri);
                } catch (DependencyViolationException ex) { //NOSONAR
                    log.debug("Next related tag {} does not exist yet", tag.getNextRelatedTag().getTagUri());
                    tag.setNextRelatedTag(null);
                }
            }
            try {
                String tagTypeUri = sourceKeyLookup.lookupObjectUriFor(tenantId,
                    Prefixes.MeasurementTagTypes + "/" + tag.getType());
                tag.setType(tagTypeUri);
                tagsToUpdateArr[idx] = tag;
                // reserved attributes for tags
                if (tag.getReservedAttributes() != null && !tag.getReservedAttributes().isEmpty()) {
                    Map<String, ReservedAttributeConfig> configMap = controllerFactory.getSourceController(
                        Prefixes.MeasurementTags).reservedAttributes(tagTypeUri);
                    reservedAttributesUtil.validateReservedAttributes(tag.getReservedAttributes(), configMap, exchange,
                        tag.getSourceKey(), exchange.getIn().getHeader(MessageConstants.ASSET_PREFIX, String.class));
                }
            } catch (DependencyViolationException ex) {
                // No tag classfication in predix for tag, requeue the whole batch
                tagsToRetryArr[idx] = originalTags[idx];
                dependencyViolationExceptions.add(ex);
                tagsToUpdateArr[idx] = null;
            }
        }

        // Persist in predix
        persistInPredix(monitoredEntityPrefix, monitoredEntitySrcKey, monitoredEntityUuid, tagsToUpdateArr);
        // Patch tags for tag correlation (Retry now with next related tag
        for (int idx = 0; idx < tagsToUpdateArr.length; idx++) {
            MeasurementTag tag = tags[idx];
            if (tagsToUpdateArr[idx] != null && tag != null && tag.getNextRelatedTag() == null
                && originalTags[idx].getNextRelatedTag() != null) {
                tag.setNextRelatedTag(
                    (NextCorrelatedTag) SerializationUtils.clone(originalTags[idx].getNextRelatedTag()));
                if (tag.getNextRelatedTag() != null && !org.springframework.util.StringUtils.isEmpty(
                    tag.getNextRelatedTag().getTagUri())) {
                    try {
                        String existingSrcKeyUri = sourceKeyLookup.lookupObjectUriFor(tenantId,
                            Prefixes.MeasurementTags + "/" + tag.getNextRelatedTag().getTagUri());
                        tag.getNextRelatedTag().setTagUri(existingSrcKeyUri);
                        tagsToUpdateArr[idx] = tag;
                    } catch (DependencyViolationException ex) {
                        tagsToRetryArr[idx] = originalTags[idx];
                        dependencyViolationExceptions.add(ex);
                        tagsToUpdateArr[idx] = null;
                    }
                } else {
                    tagsToUpdateArr[idx] = null;
                }
            } else {
                tagsToUpdateArr[idx] = null;
            }
        }

        // Persist in predix
        persistInPredix(monitoredEntityPrefix, monitoredEntitySrcKey, monitoredEntityUuid, tagsToUpdateArr);
        tagsToRetryArr = Arrays.stream(tagsToRetryArr).filter(s -> s != null).toArray(MeasurementTag[]::new);
        if (tagsToRetryArr.length > 0) {
            log.debug("Requeue needed for tags for entity {}, size {} ", monitoredEntitySrcKey, tagsToRetryArr.length);
            exchange.getOut().setBody(tagsToRetryArr);
            throw new DependencyViolationException(dependencyViolationExceptions);
        }
    }

    private void persistInPredix(String monitoredEntityPrefix, String monitoredEntitySrcKey, String monitoredEntityUuid,
        MeasurementTag... tagsToUpdate) {

        //Process tags that dont have correlations in bulk
        MeasurementTag[] tagsToUpdateArr = Arrays.stream(tagsToUpdate).filter(
            s -> (s != null && s.getNextRelatedTag() == null)).toArray(MeasurementTag[]::new);

        if (tagsToUpdateArr.length > 0) {
            log.debug("Started ingesting tags for entity {}, size {} ", monitoredEntitySrcKey, tagsToUpdateArr.length);
            controllerFactory.getTagController(monitoredEntityPrefix).associateTags(monitoredEntityUuid,
                tagsToUpdateArr);
        }
        log.debug("Ingested {} tags in predix via TagController", tagsToUpdateArr.length);

        //Process tag that DO have correlations one by one in sepearte transactions in order to acquire locks without
        //deadlocking
        Arrays.stream(tagsToUpdate).forEach(tag -> {
            if (tag != null && tag.getNextRelatedTag() != null) {
                controllerFactory.getTagController(monitoredEntityPrefix).associateTags(monitoredEntityUuid, tag);
            }
        });
    }
}
