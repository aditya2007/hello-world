/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.util;

import org.eclipse.persistence.jpa.jpql.Assert;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ge.apm.asset.model.ContextConfiguration;
import com.ge.apm.common.support.RequestContext;

@Configuration
public class KeyGeneratorConfiguration {

    @Bean
    public KeyGenerator reservedAttributeKeyGenerator() {
        return (objectName, method, params) -> {
            StringBuilder sb = new StringBuilder();
            sb.append(RequestContext.get(RequestContext.TENANT_UUID, String.class));
            sb.append("reservedAttribute");

            if (params[1] instanceof ContextConfiguration) {
                ContextConfiguration contextConfiguration = (ContextConfiguration) params[1];
                Assert.isNotNull(contextConfiguration.getContextType(), "ContextConfiguration type is null");
                sb.append(contextConfiguration.getContextType());
            } else {
                sb.append(params[1].toString().replace("/", ""));
            }

            return sb.toString();
        };
    }
}
