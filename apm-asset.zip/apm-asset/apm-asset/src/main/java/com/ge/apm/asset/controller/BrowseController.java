/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.model.Node;
import com.ge.apm.asset.model.NodeData;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAlmPersistenceService;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.asset.util.SortByResolver;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.exception.ForbiddenException;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

@Controller
@Slf4j
public class BrowseController {

    private static final String ALL_RESOURCES = "All Resources";

    private final Comparator<Hierarchical> byName = (Hierarchical e1, Hierarchical e2) -> e1.getName().compareTo(
        e2.getName());

    @Inject
    private IAssetService assetService;

    @RequestMapping(method = RequestMethod.GET, value = "/v1/browse/instances", produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public Hierarchical[] browseInstances(@RequestParam(required = true) String parent,
        @RequestParam(required = false, defaultValue = AssetComponentResolver.PARENT) String components,
        @RequestParam(required = false) String sortBy) {
        try {
            Hierarchical[] children = null;
            if (parent.trim().isEmpty() || "null".equals(parent)) {
                children = assetService.get(Prefixes.Enterprises, Enterprise.class,
                    AssetComponentResolver.parseComponents(components));
                if (ArrayUtils.isNotEmpty(children)) {
                    children = Arrays.stream(children).filter(child -> child.getParent() == null).toArray(
                        Hierarchical[]::new);
                }
            } else {
                QueryPredicate queryPredicate = new QueryPredicate();
                queryPredicate.setIgnoreComponentAcl(true);
                children = assetService.getChildren(null, parent, AssetComponentResolver.parseComponents(components), queryPredicate);
            }

            // default sorting by name
            if (children != null) {
                if (sortBy != null && sortBy.equals(SortByResolver.ALIAS)) {
                    for (Hierarchical hierarchical : children) {
                        SortByResolver.swapTheNameAndAlias(hierarchical);
                    }
                }
                return Arrays.stream(children).sorted(byName).toArray(Hierarchical[]::new);
            }
            return children;
        } catch (Exception ex) {
            log.error("[browseInstances]", ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.BROWSE_INSTANCE), parent);
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = "/v1/browse/allInstances",
        produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public Hierarchical[] browseAllInstances(@RequestParam(required = true) String parent,
        @RequestParam(required = false, defaultValue = AssetComponentResolver.PARENT) String components,
        @RequestParam(required = false) String sortBy) {
        try {
            Hierarchical[] children = null;
            if (parent.trim().isEmpty() || "null".equals(parent)) {
                // Temporary changes to return 1000 enterprise objects for Power customer
                children = assetService.get(Prefixes.Enterprises, Enterprise.class,
                    AssetComponentResolver.parseComponents(components), false, 1000);
                /*
                // Don't need this filter since persistence layer apply filter as 'parent is null'
                if (ArrayUtils.isNotEmpty(children)) {
                    children = Arrays.stream(children)
                        .filter(child -> child.getParent() == null).toArray(Hierarchical[]::new);
                }*/
            } else {
                QueryPredicate queryPredicate = new QueryPredicate();
                queryPredicate.setParentUri(Optional.of(parent));
                queryPredicate.setIgnoreComponentAcl(true);
                children = assetService.getChildren(null, parent, AssetComponentResolver.parseComponents(components),
                    false, queryPredicate);
            }

            // default sorting by name
            if (children != null) {
                if (sortBy != null && sortBy.equals(SortByResolver.ALIAS)) {
                    for (Hierarchical hierarchical : children) {
                        SortByResolver.swapTheNameAndAlias(hierarchical);
                    }
                }
                return Arrays.stream(children).sorted(byName).toArray(Hierarchical[]::new);
            }
            return children;
        } catch (Exception ex) {
            log.error("[browseAllInstances]", ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.BROWSE_INSTANCE), parent);
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = "/v1/browse/accessibleResources",
        produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public Hierarchical[] accessibleResources() {
        String[] accessibleResourceUris = RequestContext.get(IAlmPersistenceService.ACCESSIBLE_RESOURCES, String[].class);
        if (accessibleResourceUris == null) {
            throw new ForbiddenException(ErrorProvider.findError(ErrorConstants.NO_ACCESSIBLE_RESOURCES));
        } else if (accessibleResourceUris.length == 1 && accessibleResourceUris[0].equals(
            IAlmPersistenceService.ALL_RESOURCES[0])) {
            //All resources in the tenant accessible
            return new Hierarchical[0];
        } else {
            return assetService.getWithoutFiltering(accessibleResourceUris);
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = "/v2/browse/allInstances",
        produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public NodeData browseAllInstancesV2(@RequestParam(required = true) String parent,
        @RequestParam(required = false, defaultValue = "NAME") String sortBy) {
        try {
            if (StringUtils.isEmpty(parent)) {
                log.error("[browseAllInstancesV2] Invalid request. 'parent' param cannot be empty");
                throw new BadRequestException(ErrorProvider.findError(ErrorConstants.BAD_REQUEST));
            }
            String[] accessibleResourceUris = RequestContext.get(IAlmPersistenceService.ACCESSIBLE_RESOURCES,
                String[].class);
            String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
            /*
             * This map stores map between accessibleResourceUri and their fullPath(until
             * enterprise).
             */
            Map<String, String> accessibleObjectsMap = new HashMap<>();
            Hierarchical[] children = null;
            String components = AssetComponentResolver.BASIC;

            if (accessibleResourceUris.length == 1 && accessibleResourceUris[0].equals(
                IAlmPersistenceService.ALL_RESOURCES[0])) {
                accessibleObjectsMap.put(IAlmPersistenceService.ALL_RESOURCES[0], IAlmPersistenceService.ALL_RESOURCES[0]);
            } else {
                Set<Hierarchical> enterprises = new HashSet<>();
                /*
                 * When retrieving children for the parentUri in request and if
                 * accessibleResourceUris is not '*',
                 * then we need to build fullPath(until enterprise) for the accessible resources
                 * uris.
                 */
                accessibleObjectsMap = accessibleObjects(accessibleResourceUris, enterprises);

                /*
                 * When accessible resources is not '*", then set components as 'PARENT' as we
                 * need to check
                 * against the full path of accesssible resources.
                 */
                components = AssetComponentResolver.PARENT;
            }

            /**
             * If parent is 'Tenant UUID', then return all enterprises.
             */
            if (parent.equals(tenantUuid)) {
                // Temporary changes to return 1000 enterprise objects for Power customer
                children = assetService.get(Prefixes.Enterprises, Enterprise.class,
                    AssetComponentResolver.parseComponents(components), false, 1000);
                /*
                 // Don't need this filter since persistence layer apply filter as 'parent is null'
                if (ArrayUtils.isNotEmpty(children)) {
                    children = Arrays.stream(children)
                        .filter(child -> child.getParent() == null).toArray(Hierarchical[]::new);
                }*/
            } else {
                QueryPredicate queryPredicate = new QueryPredicate();
                queryPredicate.setIgnoreComponentAcl(true);
                children = assetService.getChildren(null, parent, AssetComponentResolver.parseComponents(components),
                    false, queryPredicate);
            }

            // default sorting by name
            children = sortHierarchical(sortBy, children);

            return translateHierarchicalArrToNodeData(children, parent, sortBy, accessibleObjectsMap);
        } catch (Exception ex) {
            log.error("[browseAllInstancesV2]", ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.BROWSE_INSTANCE), parent);
        }
    }

    private Hierarchical[] sortHierarchical(String sortBy, Hierarchical... children) {
        if (children != null) {
            if (sortBy != null && sortBy.equals(SortByResolver.ALIAS)) {
                for (Hierarchical hierarchical : children) {
                    SortByResolver.swapTheNameAndAlias(hierarchical);
                }
            }
            children = Arrays.stream(children).sorted(byName).toArray(Hierarchical[]::new);
        }
        return children;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/v2/browse/accessibleResources",
        produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public NodeData accessibleResourcesV2() {
        String[] accessibleResourceUris = RequestContext.get(IAlmPersistenceService.ACCESSIBLE_RESOURCES, String[].class);
        /*
         * This map stores map between accessibleResourceUri and their fullPath(until enterprise).
         */
        Map<String, String> accessibleObjectsMap = new HashMap<>();
        Hierarchical[] children = null;
        if (accessibleResourceUris == null) {
            throw new ForbiddenException(ErrorProvider.findError(ErrorConstants.NO_ACCESSIBLE_RESOURCES));
        } else if (accessibleResourceUris.length == 1 && accessibleResourceUris[0].equals(
            IAlmPersistenceService.ALL_RESOURCES[0])) {
            /*
             * When logged-in user is a tenant admin, then user will have access to all enterprises.
             * It means we need not build fullPath & apply accessible resources filter.
             * If we don't need fullPath, then components can be BASIC.
             * Also setting key-value as '*' in accessibleObjectsMap to indicate that logged-in
             * user is tenant-admin.
             * Also return 'All Resources' in the first call.
             */
            String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
            NodeData nodeData = new NodeData();
            List<Node> nodes = new ArrayList<>();
            nodeData.setData(nodes);

            Node node = new Node();
            node.setId(tenantUuid);
            node.setName(ALL_RESOURCES);
            node.setUri(tenantUuid);
            node.setChildResourcesUri("/v2/browse/allInstances?parent=" + tenantUuid);
            node.setIsOpenable(true);
            node.setHasChildren(true);
            nodes.add(node);

            Map<String, String> meta = new HashMap<>();
            meta.put("parentId", null);
            nodeData.setMeta(meta);
            return nodeData;
        } else {
            Set<Hierarchical> enterprises = new HashSet<>();
            /*
             * For a non-tenant-admin user, they will have selected assets
             * (asset/segment/site/enterprise) assigned
             * to them. Even though user can have access to site or segment or asset, he/she
             * should start from
             * enterprise. So, for the list of 'accessibleResourceUris', we should get
             * corresponding enterprises.
             * 'accessibleObjects' method does two things:
             *    1. Creates map between accessibleResourceUri and their fullPath(until enterprise)
              *   2. Populates list of enterprises, to start with.
             */
            accessibleObjectsMap = accessibleObjects(accessibleResourceUris, enterprises);
            children = enterprises.toArray(new Hierarchical[enterprises.size()]);
        }

        // default sorting by name
        String sortBy = "NAME";
        children = sortHierarchical(sortBy, children);

        return translateHierarchicalArrToNodeData(children, null, null, accessibleObjectsMap);
    }

    private void getParentPath(String uri, StringBuilder path, Set<Hierarchical> enterprises) {
        String prefix = Prefixes.prefixFromUri(uri);
        String parentUri = "";
        switch (prefix) {
            case Prefixes.Assets:
                Asset asset = assetService.getSingle(uri, Asset.class,
                    AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC), true);
                path.append(asset.getUri());
                parentUri = asset.getParent();
                break;
            case Prefixes.Segments:
                Segment segment = assetService.getSingle(uri, Segment.class,
                    AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC), true);
                path.append(segment.getUri());
                parentUri = segment.getParent();
                break;
            case Prefixes.Sites:
                Site site = assetService.getSingle(uri, Site.class,
                    AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC), true);
                path.append(site.getUri());
                parentUri = site.getParent();
                break;
            case Prefixes.Enterprises:
                Enterprise enterprise = assetService.getSingle(uri, Enterprise.class,
                    AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC), true);
                path.append(enterprise.getUri());
                enterprises.add(enterprise);
                return;
            default:
                throw new IllegalStateException("Invalid class");
        }
        if (!StringUtils.isEmpty(parentUri)) {
            getParentPath(parentUri, path, enterprises);
        }
    }

    private Map<String, String> accessibleObjects(String[] accessibleResourceUris, Set<Hierarchical> enterprises) {
        Map<String, String> accessibleObjectsMap = new HashMap<String, String>();
        StringBuilder path = new StringBuilder("");
        for (String uri : accessibleResourceUris) {
            getParentPath(uri, path, enterprises);
            accessibleObjectsMap.put(uri, path.toString());
            path = new StringBuilder("");
        }
        return accessibleObjectsMap;
    }

    private String getNestedSegmentPath(Segment segment, String path, Set<Hierarchical> enterprises) {
        String updatedPath = path + segment.getUri();
        Segment updatedSegment = segment;
        if (segment.getSegment() != null) {
            updatedSegment = segment.getSegment();
            getNestedSegmentPath(updatedSegment, updatedPath, enterprises);
        }
        if (!enterprises.contains(updatedSegment.getSite().getEnterprise())) {
            enterprises.add(updatedSegment.getSite().getEnterprise());
        }

        return updatedPath + updatedSegment.getSite().getUri() + updatedSegment.getSite().getEnterprise().getUri();
    }

    private String getNestedAsset(Asset asset, String path, Set<Hierarchical> enterprises) {
        String updatedPath = path + asset.getUri();
        Asset updatedAsset = asset;
        if (asset.getAsset() != null) {
            updatedAsset = asset.getAsset();
            getNestedAsset(updatedAsset, updatedPath, enterprises);
        }
        Segment segment = updatedAsset.getSegment();
        if (segment != null) {
            updatedPath = getNestedSegmentPath(segment, updatedPath, enterprises);
        }

        if (updatedAsset.getSite() != null) {
            updatedPath = updatedPath + updatedAsset.getSite().getEnterprise().getUri();
        }
        return updatedPath;
    }

    private NodeData translateHierarchicalArrToNodeData(Hierarchical[] hierarchicalArr, String parentId, String sortBy,
        Map<String, String> accessibleObjectsMap) {
        NodeData nodeData = new NodeData();
        List<Node> nodes = new ArrayList<>();
        nodeData.setData(nodes);
        Set<Hierarchical> enterprises = new HashSet<>();

        for (Hierarchical hierarchical : hierarchicalArr) {
            Node node = new Node();
            node.setId(hierarchical.getUri().replaceAll("/", "_"));
            node.setName(hierarchical.getName());
            node.setUri(hierarchical.getUri());
            node.setChildResourcesUri(
                "/v2/browse/allInstances?parent=" + hierarchical.getUri() + "&sortBy=" + (StringUtils.isEmpty(sortBy)
                    ? SortByResolver.NAME : sortBy));
            if (accessibleObjectsMap.size() == 1 && accessibleObjectsMap.values().iterator().next().equals(
                IAlmPersistenceService.ALL_RESOURCES[0])) {
                /*
                 * When logged-in user is a tenant admin, then he will have access to every node
                 * in the
                 * asset hierarchy. Hence by default we set 'Openable' to true.
                 */
                node.setIsOpenable(true);
            } else {
                for (String accessResFullPath : accessibleObjectsMap.values()) {
                    String prefix = Prefixes.prefixFromUri(hierarchical.getUri());
                    String fullPath = "";
                    switch (prefix) {
                        case Prefixes.Assets:
                            Asset asset = (Asset) hierarchical;
                            fullPath = getNestedAsset(asset, fullPath, enterprises);
                            break;
                        case Prefixes.Segments:
                            Segment segment = (Segment) hierarchical;
                            fullPath = getNestedSegmentPath(segment, fullPath, enterprises);
                            break;
                        case Prefixes.Sites:
                            Site site = (Site) hierarchical;
                            fullPath = site.getEnterprise().getUri() + site.getUri();
                            if (!enterprises.contains(site.getEnterprise())) {
                                enterprises.add(site.getEnterprise());
                            }
                            break;
                        case Prefixes.Enterprises:
                            Enterprise enterprise = (Enterprise) hierarchical;
                            fullPath = enterprise.getUri();
                            enterprises.add(enterprise);
                            break;
                        default:
                            throw new IllegalStateException("Invalid class");
                    }
                    if (fullPath.endsWith(accessResFullPath)) {
                        node.setIsOpenable(true);
                        break;
                    }
                }
            }

            /*Hierarchical[] children = assetService.getChildrenInstances(hierarchical.getUri(),
                    AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC),
                    true, null);*/
            node.setHasChildren(true);
            nodes.add(node);
        }
        Map<String, String> meta = new HashMap<>();
        meta.put("parentId", StringUtils.isEmpty(parentId) ? parentId : parentId.replaceAll("/", "_"));
        nodeData.setMeta(meta);
        return nodeData;
    }
}
