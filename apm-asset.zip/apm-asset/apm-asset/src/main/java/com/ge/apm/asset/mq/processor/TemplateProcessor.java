/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.ge.apm.asset.controller.PlaceholderController;
import com.ge.apm.asset.model.Placeholder;
import com.ge.apm.asset.model.PlaceholderAssetTypeAssociation;
import com.ge.apm.asset.model.PlaceholderTagTypeAssociation;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.TagExpression;
import com.ge.apm.asset.model.Template;
import com.ge.apm.asset.mq.redis.SourceKeyLookup;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.ValidationResult;
import com.ge.asset.commons.validator.Validator;
import com.ge.asset.commons.validator.apm.PlaceholdersValidation;
import com.ge.asset.commons.validator.apm.PlaceholdersValidation.PlaceholderValidationRules;
import com.ge.asset.commons.validator.apm.TagExpValidationMap;
import com.ge.asset.commons.validator.apm.TagExpressionValidation;

/**
 * Created by 212448111 on 2/16/17.
 */
@Component
@Slf4j
public class TemplateProcessor extends DtoProcessor<Template> {

    private static final String VALIDATION_RESULT = "validationResult";

    public static final String TEMPLATE_PLACEHOLDERS = "template-placeholders";

    @Value("${apm.assetTemplate.tagExpressions:false}")
    private boolean tagExpressionFeatureEnabled;

    @Value("${apm.asset.tagExpression.max-range:5000}")
    private int maxRange;

    @Autowired
    PlaceholderController placeholderController;

    private Map<String, ReservedAttributeConfig> placeholderConfigMap = new HashMap<>();

    @Autowired
    private SourceKeyLookup sourceKeyLookup;

    @Override
    protected void processDto(Template dto, Exchange exchange) {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        if (dto.getReservedAttributes() != null && !dto.getReservedAttributes().isEmpty()) {
            reservedAttributesUtil.validateReservedAttributes(dto.getReservedAttributes(), reservedAttributesUtil
                    .getReservedAttributesConfigMapIfExists(
                        exchange.getIn().getHeader(MessageConstants.ASSET_PREFIX, String.class)), exchange,
                dto.getSourceKey(), exchange.getIn().getHeader(MessageConstants.ASSET_PREFIX, String.class));
        }

        List<Placeholder> placeholders = dto.getPlaceholders();

        List<Placeholder> sequentialPlaceholders = new ArrayList<>();
        convertToSequential(placeholders, sequentialPlaceholders, dto.getSourceKey());
        if (Boolean.TRUE.equals(tagExpressionFeatureEnabled)) {
            Map<String, Object> validationCtx = new HashMap<>();
            PlaceholderValidationRules[] rules = {
                PlaceholderValidationRules.CHECK_PLACEHOLDER_TAGTYPEASSOCIATIONS_TAGEXPRESSIONS,
                PlaceholderValidationRules.CHECK_PLACEHOLDER_TAGEXPRESSION_MAX_RANGE,
                PlaceholderValidationRules.CHECK_PLACEHOLDER_TAGTYPEASSOCIATIONS_IDEXPR_UNIQUENESS };
            validationCtx.put(PlaceholdersValidation.PLACEHOLDER_VALIDATION_RULES, rules);
            validationCtx.put(TagExpressionValidation.MAX_RANGE, maxRange);
            Validator validator = new Validator(TEMPLATE_PLACEHOLDERS, validationCtx);
            ValidationResult validationResult = validator.validate(sequentialPlaceholders);
            if (validationResult != null && !validationResult.isValid()) {
                setValidationResults(exchange, validationResult);
                removeInvalidTagExpressions(validationResult, sequentialPlaceholders);
            }
        } else {
            setTagExpressionToEmpty(sequentialPlaceholders);
        }

        if (placeholders != null && !placeholders.isEmpty()) {
            placeholderConfigMap = placeholderController.reservedAttributes();
            populateUriForTemplatePlaceholders(placeholders, tenantUuid, exchange);
        }
    }

    private void setTagExpressionToEmpty(List<Placeholder> placeholders) {
        if (CollectionUtils.isEmpty(placeholders)) {
            return;
        } else {
            for (Placeholder placeholder : placeholders) {
                if (!CollectionUtils.isEmpty(placeholder.getTagTypeAssociations())) {
                    placeholder.getTagTypeAssociations().forEach(tagAssociation -> {
                        tagAssociation.setTagExpressions(Collections.emptyList());
                    });
                }
            }
        }
    }

    private void removeInvalidTagExpressions(ValidationResult validationResult, List<Placeholder> placeholders) {
        Map<String, Object> templateValidatorContext = (Map<String, Object>) validationResult.getResponseContext().get(
            Validator.TEMPLATE_PLACEHOLDERS_KEY);
        if (templateValidatorContext != null && !CollectionUtils.isEmpty(placeholders)) {
            Object responseObject = templateValidatorContext.get(TagExpressionValidation.VALID_TAG_EXPRESSIONS_MAP);
            final TagExpValidationMap validationMap = responseObject == null ? new TagExpValidationMap()
                : (TagExpValidationMap) responseObject;

            for (Placeholder placeholder : placeholders) {
                if (!CollectionUtils.isEmpty(placeholder.getTagTypeAssociations())) {
                    placeholder.getTagTypeAssociations().stream().filter(
                        tagTypeAssociation -> tagTypeAssociation != null
                            && tagTypeAssociation.getTagExpressions() != null).forEach(tagTypeAssociation -> {
                        List<TagExpression> validExpressions = validationMap.get(placeholder.getPlaceholderId(),
                            tagTypeAssociation.getEntityUri());
                        tagTypeAssociation.setTagExpressions(
                            CollectionUtils.isEmpty(validExpressions) ? null : validExpressions);
                    });
                    removeTagTypesWithEmptyTagExpressions(placeholder);
                }
            }
        }
    }

    private void removeTagTypesWithEmptyTagExpressions(Placeholder placeholder) {
        if (!CollectionUtils.isEmpty(placeholder.getTagTypeAssociations())) {
            placeholder.setTagTypeAssociations(placeholder.getTagTypeAssociations().stream().filter(
                tagTypeAssociation -> tagTypeAssociation != null && !CollectionUtils
                    .isEmpty(tagTypeAssociation.getTagExpressions())).collect(Collectors.toList()));
            if (CollectionUtils.isEmpty(placeholder.getTagTypeAssociations())) {
                placeholder.setTagTypeAssociations(null);
            }
        }
    }

    private void convertToSequential(List<Placeholder> placeholders, List<Placeholder> sequentialPlaceholders,
        String srcKey) {
        if (!CollectionUtils.isEmpty(placeholders)) {
            for (Placeholder placeholder : placeholders) {
                placeholder.setTemplate(srcKey);
                sequentialPlaceholders.add(placeholder);
                convertToSequential(placeholder.getPlaceholders(), sequentialPlaceholders, srcKey);
            }
        }
    }

    private void populateUriForTemplatePlaceholders(List<Placeholder> placeholders, String tenantUuid,
        Exchange exchange) {

        if (placeholders == null || placeholders.isEmpty()) {
            return;
        }

        for (Placeholder placeholder : placeholders) {
            // populate uri for associations
            List<PlaceholderAssetTypeAssociation> associations = placeholder.getAssetTypeAssociations();

            if (associations != null && !associations.isEmpty()) {
                for (PlaceholderAssetTypeAssociation association : associations) {
                    // adapter sets prefix & sourcekey for entityUri and we do extract & lookup here
                    String entityUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid, association.getEntityUri());
                    association.setEntityUri(entityUri);
                }
            }

            // populate uri for tag associations
            List<PlaceholderTagTypeAssociation> tagAssociations = placeholder.getTagTypeAssociations();
            if (tagAssociations != null && !tagAssociations.isEmpty()) {
                for (PlaceholderTagTypeAssociation tagAssociation : tagAssociations) {
                    // adapter sets prefix & sourcekey for entityUri and we do extract & lookup here
                    String entityUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid, tagAssociation.getEntityUri());
                    tagAssociation.setEntityUri(entityUri);
                }
            }

            // reserved attributes validation for placeholder
            if (placeholder.getReservedAttributes() != null && !placeholder.getReservedAttributes().isEmpty()) {
                reservedAttributesUtil.validateReservedAttributes(placeholder.getReservedAttributes(),
                    placeholderConfigMap, exchange, placeholder.getSourceKey(),
                    exchange.getIn().getHeader(MessageConstants.ASSET_PREFIX, String.class));
            }

            // populate uri RECURSIVELY as placeholders are hierarchical
            if (placeholder.getPlaceholders() != null) {
                populateUriForTemplatePlaceholders(placeholder.getPlaceholders(), tenantUuid, exchange);
            }
        }
    }

    private static String getPropertyName(Exchange exchange) {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        String taskUuid = messageHeaders.get(MessageConstants.TASK_UUID).toString();
        return VALIDATION_RESULT + "_" + tenantUuid + "_" + taskUuid;
    }

    private static void setValidationResults(Exchange exchange, ValidationResult validationResult) {
        ValidationResult existingValidations = exchange.getProperty(getPropertyName(exchange), ValidationResult.class);
        if (existingValidations == null) {
            exchange.setProperty(getPropertyName(exchange), validationResult);
        } else if (!validationResult.isValid()) {
            existingValidations.setValid(false);
            existingValidations.getErrors().addAll(validationResult.getErrors());
            exchange.setProperty(getPropertyName(exchange), existingValidations);
        }
    }
}
