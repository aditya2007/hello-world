/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.controller.base.ISearchController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.model.Edge;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.Network;
import com.ge.apm.asset.model.NetworkNode;
import com.ge.apm.asset.model.NetworkNode.Category;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.service.persistence.PersistenceUtil;
import com.ge.apm.asset.service.util.AssetStateManagerUtil;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.asset.util.CrudOperationsValidator;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.errorprovider.AssetError;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

/**
 * Created by 212326606 on 2/18/16.
 */
@Slf4j
@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.Networks, IBasePath.v3 + Prefixes.Networks,
    IBasePath.v3 + Prefixes.Tenants + "/{tenantId}" + Prefixes.Networks })
public class NetworkController extends AbstractController<Network, IAssetService>
    implements ICrudController<Network, IAssetService>, ISearchController<Network, IAssetService> {

    @Value("${apm.asset.page.size}")
    private int pageSize;

    @Value("${apm.asset.restrictionfeature.enabled:false}")
    private boolean assetRestrictionFeaturesEnabled;

    public NetworkController() {
        super(Prefixes.Networks, Network.class);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{uuid}/nodes", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public NetworkNode[] getNodes(@PathVariable("uuid") String uuid,
        @RequestParam(required = false, defaultValue = AssetComponentResolver.BASIC) String components,
        @RequestParam(required = false, defaultValue = "250") Integer pageSize,
        @RequestParam(required = false) String nextPageLink, @RequestParam(required = false) String nextPageSortKey) {

        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setPageSize(pageSize);
        queryPredicate.setParentUri(Optional.of(Prefixes.Networks + "/" + uuid));
        if (nextPageLink != null && !nextPageLink.isEmpty()) {
            try {
                queryPredicate.setPageNumber(Integer.parseInt(nextPageLink));
                queryPredicate.setNextPageSortKey(nextPageSortKey);
            } catch (Exception ex) {
                getLogger().error(ex.getMessage(), ex);
                throw new BadRequestException(ErrorProvider.findError(ErrorConstants.BAD_REQUEST));
            }
        }
        try {
            return getService().get(Prefixes.Nodes, NetworkNode.class,
                AssetComponentResolver.parseComponents(components), queryPredicate, pageSize);
        } catch (ServiceException ex) {
            getLogger().error("[getNodes:]", ex);
            throw ExceptionUtil.wrapException(ex, ex.getCode());
        } catch (Exception ex) {
            getLogger().error("[getNodes]", ex);
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.GET_BY_CRITERIA), getPrefix());
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/{uuid}/nodes", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(value = HttpStatus.OK)
    public void addNodes(@PathVariable("uuid") String uuid, @RequestBody NetworkNode... nodes) {

        //TODO: Add logic to query persistency layer for existence of
        //TODO: an node(asset already added as node in some other networks)
        //TODO: Logic to prevent adddition of same nodes again
        if (nodes == null) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.EMPTY_NODE));
        }

        try {
            getSingle(uuid, AssetComponentResolver.BASIC);
        } catch (NotFoundException ex) {
            log.error("networkId {} is NOT FOUND", uuid, ex);
            throw new NotFoundException(ErrorProvider.findError(ErrorConstants.NETWORK_NOT_FOUND_FOR_UUID), uuid);
        }

        validateEmptyCategory(nodes);

        //Group by Category
        Map<String, List<String>> sourceKeysMapByCategory = Arrays.stream(nodes).collect(Collectors
            .groupingBy(NetworkNode::getCategory, Collectors.mapping(NetworkNode::getSourceKey, Collectors.toList())));

        validateNodeCategory(sourceKeysMapByCategory);

        List<String> sourceKeys = Arrays.stream(nodes).map(NetworkNode::getSourceKey).collect(Collectors.toList());
        Set<String> distinctSourceKeys = new HashSet<>(sourceKeys);

        validateEmptySourceKey(distinctSourceKeys);

        validateDuplicateSourceKeysInRequest(sourceKeys, distinctSourceKeys);

        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);

        String formattedTenantId = PersistenceUtil.formatTenantId(tenantId);

        List<Attributable> businessObjects = getBusinessObjectsBySourceKey(formattedTenantId, sourceKeysMapByCategory);

        validateBusinessObjectExistence(sourceKeys, businessObjects);

        validateStateOfBusinessObject(businessObjects, "node");

        getService().addNodesToNetwork(tenantId, uuid,
            businessObjects.toArray(new Attributable[businessObjects.size()]));
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/{networkUuid}/nodes",
        consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(value = HttpStatus.OK)
    public void deleteNodesFromNetwork(@PathVariable("networkUuid") String networkUuid,
        @RequestParam(required = true) String[] uris) {

        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);

        HashSet<String> allowedCategories = new HashSet();
        Arrays.stream(Category.values()).map(Enum::name).forEach(allowedCategories::add);

        List<String> invalidUris = Arrays.stream(uris).filter(
            uri -> !allowedCategories.contains(getCategoryFromUri(uri))).collect(Collectors.toList());

        if (!invalidUris.isEmpty()) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_NODE_CATEGORY),
                invalidUris.toString());
        }

        List<String> assetUris = Arrays.stream(uris).filter(uri -> !getCategoryFromUri(uri)
            .equals(Category.NETWORK.name())).collect(Collectors.toList());

        List<String> networkUris = Arrays.stream(uris).filter(
            uri -> getCategoryFromUri(uri).equals(Category.NETWORK.name())).collect(Collectors.toList());

        getService().deleteAssetsFromNetwork(tenantId, networkUuid, assetUris);
        getService().deleteSubNetworkFromNetwork(tenantId, networkUuid, networkUris);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{uuid}/edges", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Edge[] getEdges(@PathVariable("uuid") String uuid,
        @RequestParam(required = false, defaultValue = AssetComponentResolver.BASIC) String components,
        @RequestParam(required = false, defaultValue = "250") Integer pageSize,
        @RequestParam(required = false) String nextPageLink) {

        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setPageSize(pageSize);
        queryPredicate.setParentUri(Optional.of(Prefixes.Networks + "/" + uuid));
        queryPredicate.setComponents(Optional.of(components));
        if (nextPageLink != null && !nextPageLink.isEmpty()) {
            try {
                queryPredicate.setPageNumber(Integer.parseInt(nextPageLink));
            } catch (Exception ex) {
                getLogger().error(ex.getMessage(), ex);
                throw new BadRequestException(ErrorProvider.findError(ErrorConstants.BAD_REQUEST));
            }
        }
        try {
            return getService().get(Prefixes.Edges, Edge.class, AssetComponentResolver.parseComponents(components),
                queryPredicate, pageSize);
        } catch (ServiceException ex) {
            getLogger().error("[getNodes:]", ex);
            throw ExceptionUtil.wrapException(ex, ex.getCode());
        } catch (Exception ex) {
            getLogger().error("[getNodes]", ex);
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.GET_BY_CRITERIA), getPrefix());
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{networkUuid}/edges/{edgeUuid}",
        consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Edge getEdge(@PathVariable("networkUuid") String networkUuid, @PathVariable("edgeUuid") String edgeUuid,
        @RequestParam(required = false, defaultValue = AssetComponentResolver.FULL) String components) {

        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        QueryPredicate queryPredicate = new QueryPredicate();
        if (components.equalsIgnoreCase(AssetComponentResolver.BASIC) || components.equalsIgnoreCase(
            AssetComponentResolver.FULL)) {
            queryPredicate.setComponents(Optional.of(components));
        } else {
            //If any other value is passed in components, we honor the default behaviour. No validations done
            queryPredicate.setComponents(Optional.of(AssetComponentResolver.FULL));
        }
        Edge edge = getService().getEdgeFromNetwork(tenantId, Edge.class, networkUuid, edgeUuid, queryPredicate);
        return edge;
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/{networkUuid}/edges/{edgeUuid}",
        consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(value = HttpStatus.OK)
    public void deleteEdge(@PathVariable("networkUuid") String networkUuid, @PathVariable("edgeUuid") String edgeUuid) {

        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        getService().deleteEdgeFromNetwork(tenantId, networkUuid, edgeUuid);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/{uuid}", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(value = HttpStatus.OK)
    public void deleteNetwork(@PathVariable("uuid") String networkUuid,
        @RequestParam(value = "deletionReason", required = false) String deletionReason) {

        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        getService().deleteNetwork(tenantId, networkUuid, deletionReason);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/{uuid}/edges", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(value = HttpStatus.OK)
    public void addEdges(@PathVariable("uuid") String uuid, @RequestBody Edge... edges) {
        try {
            getSingle(uuid, AssetComponentResolver.BASIC);
        } catch (NotFoundException ex) {
            log.error("networkId {} is NOT FOUND", uuid, ex);
            throw new NotFoundException(ErrorProvider.findError(ErrorConstants.NETWORK_NOT_FOUND_FOR_UUID), uuid);
        }

        validateName(edges);
        validateDirection(edges);
        validateEdgeBusinessObject(edges);
        validateNodesInEdges(edges);
        //Group by Category
        List<NetworkNode> sourceNodes = Arrays.stream(edges).map(Edge::getSource).collect(Collectors.toList());
        List<NetworkNode> targetNodes = Arrays.stream(edges).map(Edge::getTarget).collect(Collectors.toList());

        List<NetworkNode> nodes = Stream.concat(sourceNodes.stream(), targetNodes.stream()).collect(
            Collectors.toList());

        validateEmptyCategory(nodes.toArray(new NetworkNode[nodes.size()]));

        Map<String, List<String>> sourceKeysMapByCategory = nodes.stream().collect(Collectors
            .groupingBy(NetworkNode::getCategory, Collectors.mapping(NetworkNode::getSourceKey, Collectors.toList())));

        validateNodeCategory(sourceKeysMapByCategory, edges);

        Map<String, List<String>> edgeBusinessObjectSrcKeysMapByCategory = new HashMap<>();
        for (Edge edge : edges) {
            if (edge.getBusinessObject() != null) {
                String key = edge.getBusinessObject().getCategory();
                String valueToAdd = edge.getBusinessObject().getSourceKey();

                edgeBusinessObjectSrcKeysMapByCategory.putIfAbsent(key, new ArrayList<>());
                edgeBusinessObjectSrcKeysMapByCategory.get(key).add(valueToAdd);
            }
        }

        validateEdgeBusinessObjectCategory(edgeBusinessObjectSrcKeysMapByCategory);

        List<String> sourceKeys = nodes.stream().map(NetworkNode::getSourceKey).collect(Collectors.toList());
        Set<String> distinctSourceKeys = new HashSet<>(sourceKeys);

        validateEmptySourceKey(distinctSourceKeys);

        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);

        String formattedTenantId = PersistenceUtil.formatTenantId(tenantId);

        List<Attributable> edgeNodeObjects = getBusinessObjectsBySourceKey(formattedTenantId, sourceKeysMapByCategory);

        List<Attributable> edgeBusinessObjects = getBusinessObjectsBySourceKey(formattedTenantId,
            edgeBusinessObjectSrcKeysMapByCategory);

        List<Attributable> businessObjects = Stream.concat(edgeNodeObjects.stream(), edgeBusinessObjects.stream())
            .collect(Collectors.toList());

        validateBusinessObjectExistence(sourceKeys, businessObjects);

        validateStateOfBusinessObject(businessObjects, "edge");

        //Make sure source and target are present in the edge

        //Once we reach this step all the validations are completed. Set the businessObjectUri's for sourceKeys.
        populateEdges(edges, businessObjects);

        getService().addEdgesToNetwork(tenantId, uuid, edges);
    }

    @RequestMapping(method = RequestMethod.PATCH, value = "/{networkUuid}/edges/{edgeUuid}",
        consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void updateEdge(@PathVariable("networkUuid") String networkUuid, @PathVariable("edgeUuid") String edgeUuid,
        @RequestBody PatchOperation... patchOperations) {
        try {
            String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
            List<String> requiredFields = Arrays.asList("/sourceKey", "/source", "/target", "/businessObject");

            List<String> invalidRemovePaths = Arrays.stream(patchOperations).filter(
                patchOp -> patchOp.getOp().equals("remove") && requiredFields.contains(patchOp.getPath())).map(
                PatchOperation::getPath).collect(Collectors.toList());

            if (!invalidRemovePaths.isEmpty()) {
                throw new BadRequestException(
                    "The following path(s) cannot be removed: " + invalidRemovePaths.toString());
            }

            CrudOperationsValidator.validatePatchOp(patchOperations, Edge.class);
            Edge edgeAfterPatch = getService().getPatchedNetworkEdge(tenantUuid, Edge.class, networkUuid, edgeUuid,
                patchOperations);

            //Todo: infrastucture to support updating these references in the future through patch
            //null will alert the ALM layer to not touch these values
            edgeAfterPatch.setSource(null);
            edgeAfterPatch.setTarget(null);
            edgeAfterPatch.setBusinessObject(null);

            getService().updateNetworkEdge(tenantUuid, networkUuid, edgeAfterPatch);
        } catch (IllegalArgumentException ex) {
            getLogger().error(ex.getMessage(), ex);
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_REQUEST), ex.getMessage());
        } catch (ServiceException ex) {
            getLogger().error("[updateEdge:]", ex);
            throw ExceptionUtil.wrapException(ex, ex.getCode());
        } catch (Exception ex) {
            getLogger().error("[updateEdge]", ex);
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.UPDATE_SINGLE),
                Prefixes.uri(Prefixes.Edges, edgeUuid));
        }
    }

    private void validateStateOfBusinessObject(List<Attributable> businessObjects, String name) {
        List<String> decommissionedBusinessObjects = new ArrayList<>();
        businessObjects.forEach(businessObject -> {
            if (assetRestrictionFeaturesEnabled && AssetStateManagerUtil.isApplicableType(
                new Attributable[] { businessObject }) && AssetStateManagerUtil.isDecommissioned(businessObject)) {
                decommissionedBusinessObjects.add(businessObject.getSourceKey());
            }
        });
        if (!decommissionedBusinessObjects.isEmpty()) {
            throw new BadRequestException(
                ErrorProvider.findError(ErrorConstants.INVALID_ADDITION_OF_NODES_EDGES_TO_NETWORK), name,
                decommissionedBusinessObjects.toString());
        }
    }

    private void validateName(Edge[] edges) {

        List<Edge> edgeList = Arrays.stream(edges).filter(
            edge -> edge.getName() == null || StringUtils.isEmpty(edge.getName())).collect(Collectors.toList());

        if (!edgeList.isEmpty()) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_EDGE_NAME));
        }
    }

    private void validateDirection(Edge[] edges) {

        List<String> nameList = Arrays.stream(edges).filter(edge -> edge.getDirection() == null).map(Edge::getName)
            .collect(Collectors.toList());

        if (!nameList.isEmpty()) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_EDGE_DIRECTION),
                nameList.toString());
        }
    }

    private void populateEdges(Edge[] edges, List<Attributable> businessObjects) {
        Map<String, String> sourceKeyUriMap = businessObjects.stream().collect(
            Collectors.toMap(Attributable::getSourceKey, Attributable::getUri));

        for (Edge edge : edges) {
            edge.getSource().setUri(sourceKeyUriMap.get(edge.getSource().getSourceKey()));
            edge.getTarget().setUri(sourceKeyUriMap.get(edge.getTarget().getSourceKey()));
            if (edge.getBusinessObject() != null) {
                edge.setBusinessObjectUri(sourceKeyUriMap.get(edge.getBusinessObject().getSourceKey()));
            }
        }
    }

    private List<Attributable> getBusinessObjectsBySourceKey(String formattedTenantId,
        Map<String, List<String>> sourceKeysMapByCategory) {
        List<Attributable> objects = new ArrayList<>();
        sourceKeysMapByCategory.forEach((category, skeys) -> getBusinessObjects(objects, category, skeys));
        return objects;
    }

    private void getBusinessObjects(List<Attributable> objects, String category, List<String> skeys) {
        switch (Category.valueOf(category.toUpperCase())) {
            case ENTERPRISE:
                Enterprise[] rtvdEnterprises = getService().getBySourceKeys(Prefixes.Enterprises, Enterprise.class,
                    skeys.toArray(new String[skeys.size()]));
                objects.addAll(Arrays.asList(rtvdEnterprises));
                break;
            case SITE:
                Site[] rtvdSites = getService().getBySourceKeys(Prefixes.Sites, Site.class,
                    skeys.toArray(new String[skeys.size()]));
                objects.addAll(Arrays.asList(rtvdSites));
                break;
            case SEGMENT:
                Segment[] rtvdSegments = getService().getBySourceKeys(Prefixes.Segments, Segment.class,
                    skeys.toArray(new String[skeys.size()]));
                objects.addAll(Arrays.asList(rtvdSegments));
                break;
            case ASSET:
                Asset[] rtvdAssets = getService().getBySourceKeys(Prefixes.Assets, Asset.class,
                    skeys.toArray(new String[skeys.size()]));
                objects.addAll(Arrays.asList(rtvdAssets));
                break;
            case NETWORK:
                Network[] rtvdNetworks = getService().getBySourceKeys(Prefixes.Networks, Network.class,
                    skeys.toArray(new String[skeys.size()]));
                objects.addAll(Arrays.asList(rtvdNetworks));
                break;
            default:
                throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_NODE_CATEGORY), category);
        }
    }

    private void validateNodeCategory(Map<String, List<String>> sourceKeysMapByCategory, Edge... edges) {
        List<String> badCategories = new ArrayList<>();
        HashSet<String> allowedCategories = new HashSet<>();

        for (Category category : Category.values()) {
            allowedCategories.add(category.name());
        }
        sourceKeysMapByCategory.keySet().forEach(category -> {
            if (!allowedCategories.contains(category)) {
                badCategories.add(category);
            }
        });

        if (!badCategories.isEmpty()) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_NODE_CATEGORY),
                badCategories.toString());
        }

        for (Edge edge : edges) {
            HashSet<String> nonNetworkCategories = new HashSet<>();
            for (Category category : Category.values()) {
                nonNetworkCategories.add(category.name());
            }
            nonNetworkCategories.remove(Category.NETWORK.name());
            if (edge.getSource().getCategory().equals(Category.NETWORK.name()) && !edge.getTarget().getCategory()
                .equals(Category.NETWORK.name())) {
                throw new BadRequestException(ErrorProvider.findError(ErrorConstants.CATEGORY_MISMATCH),
                    edge.getSource().getCategory(), edge.getTarget().getCategory());
            }
            if (nonNetworkCategories.contains(edge.getSource().getCategory()) && edge.getTarget().getCategory().equals(
                Category.NETWORK.name())) {
                throw new BadRequestException(ErrorProvider.findError(ErrorConstants.CATEGORY_MISMATCH),
                    edge.getSource().getCategory(), edge.getTarget().getCategory());
            }
        }
    }

    private void validateEdgeBusinessObjectCategory(Map<String, List<String>> edgeBusinessObjectSrcKeyMapByCategory) {
        List<String> badCategories = new ArrayList<>();
        HashSet<String> allowedCategories = new HashSet<>();

        for (Category category : Category.values()) {
            allowedCategories.add(category.name());
        }

        allowedCategories.remove(Category.NETWORK.name());

        edgeBusinessObjectSrcKeyMapByCategory.keySet().forEach(category -> {
            if (!allowedCategories.contains(category)) {
                badCategories.add(category);
            }
        });

        if (!badCategories.isEmpty()) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_EDGE_BUSINESS_OBJECT_CATEGORY),
                badCategories.toString());
        }
    }

    private void validateEdgeBusinessObject(Edge... edges) {

        List<Edge> edgeList = new ArrayList<>(Arrays.asList(edges));

        List<String> edgeSrcKeyListWithInvalidBusinessObjects = edgeList.stream().filter(
            edge -> edge.getBusinessObject() != null && (StringUtils.isEmpty(edge.getBusinessObject().getCategory())
                || StringUtils.isEmpty(edge.getBusinessObject().getSourceKey()))).map(
            edge -> edge.getBusinessObject().getSourceKey()).collect(Collectors.toList());

        if (!edgeSrcKeyListWithInvalidBusinessObjects.isEmpty()) {
            throw new BadRequestException(
                ErrorProvider.findError(ErrorConstants.EMPTY_BUSINESS_OBJECT_SOURCE_KEY_CATEGORY),
                edgeSrcKeyListWithInvalidBusinessObjects.toString());
        }
    }

    private void validateBusinessObjectExistence(List<String> skeys, List<Attributable> rtvdAssets) {
        List<String> rtvdAssetsSourceKeys = rtvdAssets.stream().map(Attributable::getSourceKey).collect(
            Collectors.toList());
        skeys.removeAll(rtvdAssetsSourceKeys);
        if (!skeys.isEmpty()) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.NO_DATA_FOUND_FOR_SOURCE_KEY),
                skeys.toString());
        }
    }

    private void validateEmptySourceKey(Set<String> distinctSourceKeys) {
        if (distinctSourceKeys.contains(null)) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.NON_EMPTY_SOURCEKEY));
        }
        List<String> emptySrcKeyList = distinctSourceKeys.stream().filter(String::isEmpty).collect(Collectors.toList());
        if (!emptySrcKeyList.isEmpty()) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.NON_EMPTY_SOURCEKEY));
        }
    }

    private void validateEmptyCategory(NetworkNode... networkNodes) {

        List<String> emptyCategorySrckeyList = Arrays.stream(networkNodes).filter(node -> node.getCategory() == null)
            .map(NetworkNode::getSourceKey).collect(Collectors.toList());
        if (!emptyCategorySrckeyList.isEmpty()) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.EMPTY_CATEGORY),
                emptyCategorySrckeyList.toString());
        }
    }

    private void validateNodesInEdges(Edge... edges) {

        List<String> edgeSrcKeyList = Arrays.stream(edges).filter(
            edge -> edge.getSource() == null || edge.getTarget() == null).map(Edge::getSourceKey).collect(
            Collectors.toList());

        if (!edgeSrcKeyList.isEmpty()) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.EMPTY_SOURCE_TARGET_NODE_FOR_EDGE),
                edgeSrcKeyList.toString());
        }
    }

    private void validateDuplicateSourceKeysInRequest(List<String> sourceKeys, Set<String> distinctSourceKeys) {
        if (distinctSourceKeys.size() != sourceKeys.size()) {
            // Identify duplicate elements
            List<String> dupElements = new ArrayList<>();
            final String[] srcKeyTemp = { null };
            sourceKeys.forEach(temp -> {
                if (srcKeyTemp[0] == null) {
                    srcKeyTemp[0] = temp;
                } else if (srcKeyTemp[0].equals(temp)) {
                    dupElements.add(temp);
                } else {
                    srcKeyTemp[0] = temp;
                }
            });
            AssetError assetError = ErrorProvider.findError(ErrorConstants.DUPLICATE_SOURCE_KEY);
            throw new BadRequestException(assetError, "node", dupElements.toString());
        }
    }

    private String getCategoryFromUri(String uri) {
        return Prefixes.prefixFromUri(uri).replace("/", "").replaceAll("s$", "").toUpperCase();
    }
}