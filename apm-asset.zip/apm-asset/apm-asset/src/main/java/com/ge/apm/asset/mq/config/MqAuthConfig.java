/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.Filter;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.validation.constraints.NotNull;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ge.apm.asset.filter.AccessibleResourcesFilter;
import com.ge.apm.asset.filter.AssetRequestContextFilter;
import com.ge.apm.asset.service.api.IAlmPersistenceService;
import com.ge.apm.asset.util.Constants;
import com.ge.apm.common.support.RequestContext;
import com.ge.stuf.security.context.SecurityContext;

//import org.springframework.beans.factory.annotation.Value;
//import com.ge.apm.asset.filter.AssetRequestContextFilter;

/**
 * The configuration class to configure authorization context for non HTTP calls. It retrieves Predix service instance
 * info and Rest template and stores them in the request context.
 *
 * @author Suban Asif 212448111
 * @version Feb 02, 2017
 */
@Component
@Slf4j
public class MqAuthConfig {

    private static final String GZIP = "gzip";

    private static ThreadLocal<Map<String, Object>> localContext = new ThreadLocal();

    /*@Autowired
    PxAssetServiceCredentialsFilter pxAssetServiceCredentialsFilter;*/

    @Autowired
    AccessibleResourcesFilter accessibleResourcesFilter;

    @Autowired
    AssetRequestContextFilter assetRequestContextFilter;

    @Autowired
    SecurityContext securityContext;

    @Autowired
    FilterChainProxy filterChainProxy;

    public void configure(@NotNull String tenantId, @NotNull String authToken, String url, RequestMethod method) {
        RequestContext.destroy();
        RequestContext.put(RequestContext.AUTHORIZATION, authToken);
        RequestContext.put(RequestContext.TENANT, tenantId);

        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader(RequestContext.AUTHORIZATION, authToken);
        request.addHeader(RequestContext.TENANT, tenantId);

        request.setMethod(method.name());
        request.setRequestURI("/v1" + url);
        MockHttpServletResponse response = new MockHttpServletResponse();
        List<Filter> filters = new ArrayList<>();
        filters.add(assetRequestContextFilter);
        filters.addAll(filterChainProxy.getFilterChains().get(0).getFilters());
        filters.add(accessibleResourcesFilter);
        /*filters.add(pxAssetServiceCredentialsFilter);*/

        MockFilterChain mockFilterChain = new MockFilterChain(new MockServlet(),
            filters.toArray(new javax.servlet.Filter[0]));
        try {
            log.trace("Calling filters for {} {}", request.getMethod(), request.getRequestURL());
            mockFilterChain.doFilter(request, response);
        } catch (Exception ex) {
            log.error("Access denied while performing ingestion", ex.getMessage());
        } finally {
            if (localContext.get() != null) {
                RequestContext.put(RequestContext.TENANT_UUID, localContext.get().get(RequestContext.TENANT_UUID));
                RequestContext.put(IAlmPersistenceService.ACCESSIBLE_RESOURCES,
                    localContext.get().get(IAlmPersistenceService.ACCESSIBLE_RESOURCES));

                RequestContext.put(RequestContext.AUTHORIZATION, authToken);
                RequestContext.put(RequestContext.TENANT, tenantId);
                RequestContext.put(Constants.SECURITY_CTX, localContext.get().get(Constants.SECURITY_CTX));
                RequestContext.put(Constants.TENANT_CTX, localContext.get().get(Constants.TENANT_CTX));
                RequestContext.put(Constants.STUF_CTX, localContext.get().get(Constants.STUF_CTX));

                localContext.remove();
            } else {
                log.error("Access denied while accessing {} {}", request.getMethod(), request.getRequestURL());
            }
        }
    }

    public class MockServlet extends HttpServlet {

        @Override
        public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
            //Store in local thread local to prevent destruction of RequestContext while going out of filters
            Map<String, Object> contextMap = new java.util.concurrent.ConcurrentHashMap<>();

            /*contextMap.put(PxAssetServiceCredentialsFilter.ASSET_SERVICE_INFO,
                RequestContext.get(PxAssetServiceCredentialsFilter.ASSET_SERVICE_INFO));

            contextMap.put(PxAssetServiceCredentialsFilter.ASSET_SERVICE_REST_TEMPLATE,
                RequestContext.get(PxAssetServiceCredentialsFilter.ASSET_SERVICE_REST_TEMPLATE));*/

            contextMap.put(IAlmPersistenceService.ACCESSIBLE_RESOURCES,
                RequestContext.get(IAlmPersistenceService.ACCESSIBLE_RESOURCES));

            contextMap.put(RequestContext.AUTHORIZATION, RequestContext.get(RequestContext.AUTHORIZATION));

            contextMap.put(RequestContext.TENANT_UUID, RequestContext.get(RequestContext.TENANT_UUID));

            contextMap.put(Constants.SECURITY_CTX, securityContext);
            contextMap.put(Constants.TENANT_CTX, RequestContext.get(Constants.TENANT_CTX));
            contextMap.put(Constants.STUF_CTX, RequestContext.get(Constants.STUF_CTX));
            RequestContext.put(Constants.SECURITY_CTX, securityContext);

            localContext.set(contextMap);
        }
    }
}
