/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.controller.base.IHierarchyController;
import com.ge.apm.asset.controller.base.ISearchController;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAssetTypeService;
import com.ge.apm.asset.util.ValidationDelegate;

@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.MeasurementTagTypes, IBasePath.v3 + Prefixes.MeasurementTagTypes,
    IBasePath.v3 + Prefixes.Tenants + "/{tenantId}" + Prefixes.MeasurementTagTypes })
public class MeasurementTagTypeController extends AbstractController<MeasurementTagType, IAssetTypeService>
    implements ICrudController<MeasurementTagType, IAssetTypeService>,
    IHierarchyController<MeasurementTagType, IAssetTypeService>,
    ISearchController<MeasurementTagType, IAssetTypeService> {


    @Autowired
    private ValidationDelegate validationDelegate;

    public MeasurementTagTypeController() {
        super(Prefixes.MeasurementTagTypes, MeasurementTagType.class);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/reservedAttributes")
    @ResponseBody
    public Map<String, ReservedAttributeConfig> reservedAttributes() {
        return this.getReservedAttributes();
    }

    private boolean hasGroupAssociations(String uri) {
        /*
        //TODO - QueryPredicate for GROUPS is pending
        StringBuilder expression = new StringBuilder();
        expression.append("(fromUri=").append(uri).append(")");
        IFilterExpression filterExpression = new FilterExpression(expression);

        GroupAssociation[] groupAssociations = getService().get(Prefixes.GroupAssociations, GroupAssociation.class,
                AssetComponentResolver.parseComponents("BASIC"), filterExpression, null, 250);

        return groupAssociations != null && groupAssociations.length > 0;
        */
        return getService().isMemberPartOfAGroup(uri, "TAG_TYPE");
    }
}
