/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.db;

import java.util.Properties;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.SharedCacheMode;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.boot.actuate.health.DataSourceHealthIndicator;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.jpa.support.ClasspathScanningPersistenceUnitPostProcessor;
import org.springframework.data.jpa.support.MergingPersistenceUnitManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.persistenceunit.PersistenceUnitManager;
import org.springframework.orm.jpa.vendor.EclipseLinkJpaVendorAdapter;

@Slf4j
@Configuration
@PropertySource("classpath:application.properties")
//@EnableJpaRepositories({ "com.ge.apm.asset.tag", "com.ge.apm.alm" })
@EnableJpaRepositories({ "com.ge.apm.alm" })
public class PersistenceConfigAsset {

    /*This bean is to create the JPA Vendor*/
    @Bean
    public JpaVendorAdapter jpaVendorAdapter() {
        EclipseLinkJpaVendorAdapter jpaVendorAdapter = new EclipseLinkJpaVendorAdapter();
        return jpaVendorAdapter;
    }

    /*
    * This bean is to merge the various persistence unit.
    * setSharedCacheMode should be set if any of the persistence unit uses it. Otherwise it will
    * use default and
    * you might run into issues. MergingPersistenceUnitManager only merges the entity classes but
     * not the settings.
    * */
    @Bean
    public PersistenceUnitManager persistenceUnitManager(DataSource dataSource) {
        MergingPersistenceUnitManager persistenceUnitManager = new MergingPersistenceUnitManager();
        persistenceUnitManager.setDefaultDataSource(dataSource);
        persistenceUnitManager.setDefaultPersistenceUnitName("compositePU");
        persistenceUnitManager.setSharedCacheMode(SharedCacheMode.ENABLE_SELECTIVE);
        //persistenceUnitManager.setPackagesToScan("com.ge.apm.asset.tag.persistence", "com.ge.apm.alm.persistence");
        persistenceUnitManager.setPackagesToScan("com.ge.apm.alm.persistence");
        return persistenceUnitManager;
    }

    /*
     * This bean creates the entityManagerFactory. The ClasspathScanningPersistenceUnitPostProcessor
     * is used to scan the entity classes and the corresponding mapping files used per
     * persistence unit.
     *
     */
    @Bean
    public FactoryBean<EntityManagerFactory> entityManagerFactory(PersistenceUnitManager persistenceUnitManager,
        JpaVendorAdapter jpaVendorAdapter) {

        ClasspathScanningPersistenceUnitPostProcessor persistenceUnitPostProcessor
            = new ClasspathScanningPersistenceUnitPostProcessor("com.ge.apm");
        persistenceUnitPostProcessor.setMappingFileNamePattern("*.xml");
        LocalContainerEntityManagerFactoryBean emfFactoryBean = new LocalContainerEntityManagerFactoryBean();
        emfFactoryBean.setJpaVendorAdapter(jpaVendorAdapter);
        emfFactoryBean.setPersistenceUnitManager(persistenceUnitManager);
        emfFactoryBean.setPersistenceUnitPostProcessors(persistenceUnitPostProcessor);
        Properties jpaProperties = new Properties();
        jpaProperties.setProperty("eclipselink.weaving", "static");
        jpaProperties.setProperty("eclipselink.composite-unit", "true");
        emfFactoryBean.setJpaProperties(jpaProperties);
        return emfFactoryBean;
    }

    @Bean
    EntityManager entityManager(EntityManagerFactory emf) {
        return emf.createEntityManager();
    }

    @Bean
    JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }

    /*
    Creating the HealthIndicator Bean manually and setting the query to default SELECT 1
     */
    @Bean
    public HealthIndicator dbHealthIndicator(DataSource dataSource) {
        DataSourceHealthIndicator indicator = new DataSourceHealthIndicator(dataSource);
        indicator.setQuery("SELECT 1");
        return indicator;
    }
}