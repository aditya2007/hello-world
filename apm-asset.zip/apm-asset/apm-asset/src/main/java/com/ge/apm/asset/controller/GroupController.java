/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.controller.base.ISearchController;
import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.model.Base;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.model.GroupAssociation;
import com.ge.apm.asset.model.GroupType;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.service.util.AssetStateManagerUtil;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.common.util.IdGenerator;
import com.ge.asset.commons.errorprovider.AssetError;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.util.AssetConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationResult;
import com.ge.asset.commons.validator.apm.CallBack;

/**
 * Created by 212326606 on 2/18/16.
 */
@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.Groups, IBasePath.v3 + Prefixes.Groups,
    IBasePath.v3 + Prefixes.Tenants + "/{tenantId}" + Prefixes.Groups })
public class GroupController extends AbstractController<Group, IAssetService>
    implements ICrudController<Group, IAssetService>, ISearchController<Group, IAssetService> {

    @Value("${apm.asset.page.size}")
    private int pageSize;

    @Value("${apm.asset.restrictionfeature.enabled:false}")
    private boolean assetRestrictionFeaturesEnabled;

    public GroupController() {
        super(Prefixes.Groups, Prefixes.GroupTypes, Group.class);
    }

    @Override
    @RequestMapping(method = RequestMethod.DELETE, value = "/{uuid}")
    @ResponseStatus(value = HttpStatus.OK)
    public void delete(@PathVariable("uuid") String uuid) {
        throw ExceptionUtil.wrapException(new ServiceException(ErrorConstants.TEMP_OPERATION_STOP),
            ErrorProvider.findError(ErrorConstants.DELETE), Prefixes.uri(getPrefix(), uuid));
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{uuid}/members")
    @ResponseBody
    public <T> Attributable[] getAssociateMembers(@PathVariable("uuid") String uuid) {
        try {
            Group group = getSingle(uuid, AssetComponentResolver.BASIC);
            if (getLogger().isDebugEnabled()) {
                getLogger().debug("[]: Get Associate members for Category:{}, class:{}", group.getCategory(),
                    GroupCategory.getEnum(group.getCategory()));
            }
            return getService().getMembersOfGroup(getPrefix() + "/" + uuid);
        } catch (NotFoundException ex) {
            // Don't log the stack trace, in most cases, if not all, 404 is a normal response
            // from querying Predix
            // Asset to determine if to create or update an entity
            if (getLogger().isDebugEnabled()) {
                getLogger().info("[getAssociateMembers] ({}) ({}) {}", getPrefix(), uuid, ex.getMessage());
            }
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.GET_BY_GROUP_MEMBERS),
                getPrefix(), uuid);
        } catch (ServiceException ex) {
            getLogger().error(String.format("[getAssociateMembers:] (%s) %s", uuid, ex.getMessage()), ex);
            throw ExceptionUtil.wrapException(ex, ex.getCode());
        } catch (Exception ex) {
            getLogger().error(String.format("[getAssociateMembers] (%s) %s", uuid, ex.getMessage()), ex);
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.GET_BY_GROUP_MEMBERS),
                getPrefix(), uuid);
        }
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/{uuid}/members",
        consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(value = HttpStatus.OK)
    public <T extends Attributable> void disassociateMembers(@PathVariable("uuid") String uuid,
        @RequestBody String... memberSourceKeys) {
        Group group;
        try {
            group = getSingle(uuid, AssetComponentResolver.BASIC);
        } catch (NotFoundException ex) {
            throw new NotFoundException(ErrorProvider.findError(ErrorConstants.GET_GROUP_BY_UUID), ex, uuid);
        } catch (Exception ex) {
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.GET_GROUP_BY_UUID), uuid);
        }
        List<String> memberSourceKeysAsList = Arrays.asList(memberSourceKeys);

        // append group source key and object source key to generate group association source key
        Map<String, String> paramSourceKeySet = Arrays.stream(memberSourceKeys).distinct().collect(
            Collectors.toMap(e -> e, e -> generateSourceKey(e, group.getSourceKey())));

        try {
            /*
            // Retrieve group association array for given group source key
            GroupAssociation[] groupAssociations = getGroupAssociationByGroupUri(group.getUri());

            // Retrieve group association source keys set
            Set<String> associationSourceKeys =
                Arrays.stream(groupAssociations).map(GroupAssociation::getSourceKey).collect
                (Collectors.toSet());

            // List of  source keys not in Group associations
            Set<String> sourceKeysNotAssociated = paramSourceKeySet.entrySet().stream()
                .filter(s -> !associationSourceKeys.contains(s.getValue()))
                .map(s -> s.getKey())
                .collect(Collectors.toSet());

            if (sourceKeysNotAssociated.isEmpty()) {
                Arrays.stream(groupAssociations)
                    .filter(ga -> paramSourceKeySet.containsValue(ga.getSourceKey()))
                    .forEach(ga -> getService().delete(ga.getUri(), GroupAssociation.class));
            } else {
                throw new NotFoundException(ErrorProvider.findError(ErrorConstants
                .DELETE_ASSOCIATIONS_NOT_EXISTS),
                    group.getSourceKey(), StringUtils.join(sourceKeysNotAssociated, ","));
            }
            */
            T[] members = getService().getMembersOfGroup(group.getUri());
            String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
            List<String> existingMemberSourceKeys = Arrays.stream(members).map(Attributable::getSourceKey).collect(
                Collectors.toList());
            List<GroupAssociation> groupAssociationList = new ArrayList<>();
            if (existingMemberSourceKeys.containsAll(memberSourceKeysAsList)) {
                memberSourceKeysAsList.stream().forEach(memberSourceKey -> {
                    Optional<T> mappedMember = Arrays.stream(members).filter(
                        member -> member.getSourceKey().compareTo(memberSourceKey) == 0).findFirst();
                    mappedMember.ifPresent(value -> {
                        GroupAssociation groupAssociation = new GroupAssociation();
                        groupAssociation.setSourceKey(generateSourceKey(value.getSourceKey(), group.getSourceKey()));
                        groupAssociation.setUri(Prefixes.uri(Prefixes.GroupAssociations, IdGenerator
                            .generateFrom("/", tenantUuid, Prefixes.GroupAssociations,
                                groupAssociation.getSourceKey())));
                        groupAssociation.setFromUri(value.getUri());
                        groupAssociation.setToUri(group.getUri());
                        groupAssociationList.add(groupAssociation);
                    });
                });
                getService().disassociateMembersFromGroup(group.getUri(),
                    groupAssociationList.toArray(new GroupAssociation[groupAssociationList.size()]));
            } else {
                throw new NotFoundException(ErrorProvider.findError(ErrorConstants.DELETE_ASSOCIATIONS_NOT_EXISTS),
                    group.getSourceKey(), StringUtils.join(memberSourceKeys, ","));
            }
        } catch (ServiceException ex) {
            getLogger().error("[deleteGroupAssociations:] ({}) {}", Prefixes.GroupAssociations, ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ex.getCode());
        } catch (Exception ex) {
            getLogger().error("[deleteGroupAssociations] ({}) {}", Prefixes.GroupAssociations, ex.getMessage());
            throw ex;
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/{uuid}/members", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(value = HttpStatus.OK)
    public void associateMembers(@PathVariable("uuid") String uuid, @RequestBody String... members) {
        Group group;
        try {
            group = getSingle(uuid, AssetComponentResolver.BASIC);
        } catch (NotFoundException ex) {
            throw new NotFoundException(ErrorProvider.findError(ErrorConstants.GET_GROUP_BY_UUID), ex, uuid);
        } catch (Exception ex) {
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.GET_GROUP_BY_UUID), uuid);
        }
        GroupAssociation[] groupAssociationDtos = validate(group, members);
        String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        try {
            if (groupAssociationDtos != null && groupAssociationDtos.length > 0) {
                getService().add(tenantUuid, Prefixes.GroupAssociations, groupAssociationDtos, GroupAssociation.class);
            }
        } catch (ServiceException ex) {
            getLogger().error("[createGroupAssociations:] ({}) {}", Prefixes.GroupAssociations, ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ex.getCode());
        } catch (Exception ex) {
            getLogger().error("[createGroupAssociations] ({}) {}", Prefixes.GroupAssociations, ex.getMessage());
            throw ex;
        }
    }

/*    @Override
    public Group[] create(@RequestBody Group[] objects) {
        *//*

        There is no need to validate type as it is ficticious. Category is validated in
        EntityMapper. Hence below
        code is commented.

        for (Group group : objects) {
            try {
                Map<String, Object> validationCtx = initGroupValidationContext();
                Validator validator = new Validator("group-s95-validation", validationCtx);
                ValidationResult validationResult = validator.validate(group);
                validateResult(validationResult, ErrorProvider.findMessage(ErrorConstants
                .VALI_ERR_GPS));
            } catch (ServiceException ex) {
                getLogger().error("[create:]", ex);
                throw ExceptionUtil.wrapException(ex, ex.getCode());
            } catch (Exception ex) {
                throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants
                .CREATE),
                  group.getSourceKey());
            }
        }
        *//*
        return ICrudController.super.create(objects);
    }*/

    private GroupAssociation[] validate(Group group, String... members) {
        String groupuuid = group.getUri().substring(group.getUri().lastIndexOf("/") + 1);
        HashSet<String> existingMembers = new HashSet<>(Arrays.stream(getAssociateMembers(groupuuid))
            .map(Attributable::getSourceKey).collect(Collectors.toList()));
        String[] uniqueMembers = Arrays.stream(members).distinct().filter(m -> !existingMembers.contains(m)).toArray(
            String[]::new);
        GroupAssociation[] memberDtos = null;
        if (uniqueMembers.length > 0) {
            memberDtos = new GroupAssociation[uniqueMembers.length];
            String prefix = Prefixes.getPrefixByCategory(group.getCategory());
            Attributable[] memberObjects = getService().getBySourceKeys(prefix, Prefixes.getClass(prefix),
                uniqueMembers);
            Map<String, Attributable> memberObjectsMap = Arrays.stream(memberObjects).collect(
                Collectors.toMap(Attributable::getSourceKey, Function.identity()));
            Map<String, Attributable> monitoredEntities = new HashMap<>();
            if (prefix.equals(Prefixes.MeasurementTags)) {
                validateTagGroupMembers(group, uniqueMembers, prefix, (MeasurementTag[]) memberObjects,
                    memberObjectsMap, monitoredEntities, memberDtos);
            } else {
                validateNonTagGroupMembers(group, uniqueMembers, prefix, memberObjectsMap, memberDtos);
            }
        }
        return memberDtos;
    }

    private void validateTagGroupMembers(Group group, String[] uniqueMembers, String prefix,
        MeasurementTag[] memberObjects, Map<String, Attributable> memberObjectsMap,
        Map<String, Attributable> monitoredEntities, GroupAssociation[] memberDtos) {
        Map<String, Set<String>> monitoredEntitySourceKeyMap;
        monitoredEntitySourceKeyMap = Arrays.stream(memberObjects).collect(Collectors
            .groupingBy(p -> Prefixes.prefixFromUri(p.getMonitoredEntityUri()),
                Collectors.mapping(MeasurementTag::getMonitoredEntitySourceKey, Collectors.toSet())));

        monitoredEntitySourceKeyMap.forEach((monitoredEntityPrefix, monitoredEntitySourceKeys) -> {
            Attributable[] monitored = getService().getBySourceKeys(monitoredEntityPrefix,
                Prefixes.getClass(monitoredEntityPrefix),
                monitoredEntitySourceKeys.toArray(new String[monitoredEntitySourceKeys.size()]));
            Arrays.stream(monitored).collect(Collectors.toMap(Attributable::getUri, Function.identity())).forEach(
                monitoredEntities::putIfAbsent);
        });
        //Collect sourceKeys and call alm
        for (int idx = 0; idx < uniqueMembers.length; idx++) {
            try {
                MeasurementTag entity = (MeasurementTag) memberObjectsMap.get(uniqueMembers[idx]);
                validateMemberExist(group, uniqueMembers[idx], prefix, entity);
                Attributable tagMonitoredEntity = monitoredEntities.get(entity.getMonitoredEntityUri());
                validateDecommissionedState(tagMonitoredEntity);
                memberDtos[idx] = createGroupAssociationDto(group, entity);
            } catch (Exception ex) {
                getLogger().error("[getMemberBySourceKey] ({}) ({}) {}", prefix, uniqueMembers[idx], ex.getMessage());
                throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.CREATE_GROUP_ASSOCIATIONS),
                    group.getSourceKey(), uniqueMembers[idx], prefix);
            }
        }
    }

    private void validateNonTagGroupMembers(Group group, String[] uniqueMembers, String prefix,
        Map<String, Attributable> memberObjectsMap, GroupAssociation[] memberDtos) {
        for (int idx = 0; idx < uniqueMembers.length; idx++) {
            try {
                Attributable entity = memberObjectsMap.get(uniqueMembers[idx]);
                validateMemberExist(group, uniqueMembers[idx], prefix, entity);
                validateDecommissionedState(entity);
                memberDtos[idx] = createGroupAssociationDto(group, entity);
            } catch (Exception ex) {
                getLogger().error("[getMemberBySourceKey] ({}) ({}) {}", prefix, uniqueMembers[idx], ex.getMessage());
                throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.CREATE_GROUP_ASSOCIATIONS),
                    group.getSourceKey(), uniqueMembers[idx], prefix);
            }
        }
    }

    private void validateDecommissionedState(Attributable entity) {
        if (assetRestrictionFeaturesEnabled && AssetStateManagerUtil.isApplicableType(new Attributable[] { entity })
            && AssetStateManagerUtil.isDecommissioned(entity)) {
            throw new BadRequestException(
                ErrorProvider.findError(ErrorConstants.INVALID_GROUP_ASSOCIATION_OF_DECOMMISSIONED_ASSET),
                entity.getSourceKey());
        }
    }

    private void validateMemberExist(Group group, String uniqueMember, String prefix, Attributable entity) {
        if (entity == null) {
            String errMessage = String.format("Member with sourceKey %s in Group category %s is not found",
                uniqueMember, group.getCategory());
            getLogger().error(errMessage);
            //TODO: This needs to be thrown as BADREQUEST
            throw new NotFoundException(ErrorProvider.findError(ErrorConstants.CREATE_GROUP_ASSOCIATIONS),
                group.getSourceKey(), uniqueMember, prefix);
        }
    }

    private GroupAssociation createGroupAssociationDto(Group g, Base m) {
        String associationSourceKey = generateSourceKey(m.getSourceKey(), g.getSourceKey());
        GroupAssociation ga = new GroupAssociation();
        ga.setFromUri(m.getUri());
        ga.setToUri(g.getUri());
        ga.setType(g.getType());
        ga.setDescription(associationSourceKey);
        ga.setName(associationSourceKey);
        ga.setSourceKey(associationSourceKey);
        return ga;
    }

    private String generateSourceKey(String fromSourceKey, String toSourceKey) {
        return fromSourceKey + " to " + toSourceKey + " association";
    }

    private Map<String, Object> initGroupValidationContext() {
        Map<String, Object> validationCtx = new HashMap<>();
        validationCtx.put(AssetConstants.EXISTING_OBJECT, null);
        validationCtx.put(AssetConstants.CALL_BACK_OBJECT, new CallBackEvent());
        return validationCtx;
    }

    private void validateResult(ValidationResult validationResult, String defaultErrorMessage) {
        if (validationResult != null && !validationResult.isValid()) {
            List<Error> errors = validationResult.getErrors();
            String errorMessage = "";
            if (errors != null && !errors.isEmpty()) {
                for (Error error : errors) {
                    if (error.getMessage() == null) {
                        AssetError assetError = ErrorProvider.findError(error.getErrorCode());
                        error.setMessage(String.format(assetError.getMsg(), error.getPlaceHolders()));
                    }
                    errorMessage += error.getMessage() + " ";
                }
            } else {
                errorMessage = defaultErrorMessage;
            }
            getLogger().error("Validation framework: Validation failed with error messages:" + errorMessage);
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_REQUEST), errorMessage);
        }
    }

    class CallBackEvent implements CallBack {

        public <T extends Attributable> T[] get(Map<String, Object> inputParams) {
            T[] returnObjects = null;
            if (inputParams != null) {
                if (inputParams.get(AssetConstants.GET_OBJECT_BY_SOURCE_KEY) != null) {
                    returnObjects = (T[]) Array.newInstance(GroupType.class, 1);
                    Map<String, Object> sourceKeyParams = (Map) inputParams.get(
                        AssetConstants.GET_OBJECT_BY_SOURCE_KEY);
                    String prefix = (String) sourceKeyParams.get(AssetConstants.PREFIX);
                    returnObjects[0] = (T) getService().getSingleBySourceKey(prefix, Prefixes.getClass(prefix),
                        (String) sourceKeyParams.get(AssetConstants.SOURCE_KEY));
                } else if (inputParams.get(AssetConstants.GET_OBJECT_BY_URI) != null) {
                    returnObjects = (T[]) Array.newInstance(GroupType.class, 1);
                    Map<String, Object> uriParams = (Map) inputParams.get(AssetConstants.GET_OBJECT_BY_URI);
                    String prefix = (String) uriParams.get(AssetConstants.PREFIX);
                    returnObjects[0] = (T) getService().getSingle((String) uriParams.get(AssetConstants.URI),
                        Prefixes.getClass(prefix),
                        AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC));
                }
            }
            return returnObjects;
        }
    }
}
