/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.filter;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.ge.apm.common.support.RequestContext;
import com.ge.stuf.exception.ForbiddenException;
import com.ge.stuf.exception.HttpRequestException;

@Component
@Order(1)
public class ApiRequestFilter extends AssetBaseFilter {

    private static final Logger log = LoggerFactory.getLogger(ApiRequestFilter.class);

    private static final String PATH_V3_PREFIX = "/v3";

    private static final String PATH_TENANT = "/tenants";

    private static final String DELIMITER = "/";

    @Value("#{'${apm.asset.disabled.endpoints.list}'.split(',')}")
    private List<String> disabledEndpoints;

    @Override
    public void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
        FilterChain filterChain) throws IOException, ServletException {

        try {
            String path = httpServletRequest.getServletPath();

            String method = httpServletRequest.getMethod();
            if (!HttpMethod.GET.name().equalsIgnoreCase(method)) {
                // check cross tenancy reference in path param
                if (path.startsWith(PATH_V3_PREFIX + PATH_TENANT)
                    && !RequestContext.get(RequestContext.TENANT_UUID).equals(path.split(DELIMITER)[3])) {
                    throw new ForbiddenException("No access to modify the cross tenancy data: " + path);
                }
                // check cross tenancy reference in query params
                Map<String, String[]> queryParams = httpServletRequest.getParameterMap();
                StringBuffer invalidValues = new StringBuffer();
                if (!CollectionUtils.isEmpty(queryParams)) {
                    queryParams.values().forEach(values -> {
                        if(values != null && values.length > 0) {
                            for(String value : values) {
                                if (value.startsWith(PATH_TENANT)
                                    && !RequestContext.get(RequestContext.TENANT_UUID).equals(value.split(DELIMITER)[2])) {
                                    invalidValues.append(value);
                                }
                            }
                        }
                    });
                }
                if (invalidValues.length() > 0) {
                    throw new ForbiddenException("No access to modify the cross tenancy data: "
                        + invalidValues.toString());
                }
            }

            if (disabledEndpoints != null) {
                disabledEndpoints.stream().map(String::trim).filter(endpoint -> !StringUtils.isEmpty(endpoint)).forEach(
                    endpoint -> {
                        if (path.startsWith(endpoint)) { //endpoint should include PATH_PREFIX
                            throw new ForbiddenException("Access is denied.");
                        }
                    });
            }
            filterChain.doFilter(httpServletRequest, httpServletResponse);
        } catch (HttpRequestException hre) {
            sendErrorResponse(httpServletRequest, httpServletResponse, hre);
        } catch (Exception ex) {
            log.error("Unexpected exception in feature flag filter", ex);
            throw ex;
        } finally {
            RequestContext.destroy();
        }
    }
}
