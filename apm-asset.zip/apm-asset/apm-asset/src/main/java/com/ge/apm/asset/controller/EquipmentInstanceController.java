/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.EquipmentInstanceConnection;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IEquipmentInstanceService;
import com.ge.apm.asset.service.api.ITemplateService;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.validator.ValidationFailedException;

@Slf4j
@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.equipmentInstances, IBasePath.v3 + Prefixes.equipmentInstances,
    IBasePath.v3 + Prefixes.Tenants + "/{tenantId}" + Prefixes.equipmentInstances })
public class EquipmentInstanceController extends AbstractController<EquipmentInstanceConnection,
    IEquipmentInstanceService> {

    @Autowired
    ITemplateService templateService;

    private static final String PREVIEW = "preview";


    public EquipmentInstanceController() {
        super(Prefixes.equipmentInstances, EquipmentInstanceConnection.class);
    }

    @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE,
        consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Asset[] createEquipmentInstances(
        @SuppressWarnings("unchecked") @RequestBody EquipmentInstanceConnection equipmentInstanceConnection,
        @RequestParam(required = false) String op,
        @RequestParam(required = false, defaultValue = "true") Boolean isApi) throws ValidationFailedException {

        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        if (PREVIEW.equals(op)) {
            return this.getService().preview(tenantId, getPrefix(), equipmentInstanceConnection, getObjectClass());
        } else {
            return this.getService().add(tenantId, getPrefix(), equipmentInstanceConnection, getObjectClass(), isApi);
        }
    }

    @RequestMapping(method = RequestMethod.PATCH, value = "/{uuid}", produces = MediaType
        .APPLICATION_JSON_VALUE,
        consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void updateEquipmentInstance(@PathVariable("uuid") String uuid,
        @RequestParam(required = false, defaultValue = "true") Boolean isApi,
        @RequestBody PatchOperation... patchOperations) {
        try {
            // CrudOperationsValidator.validatePatchOp(patchOperations, getObjectClass());
            String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
            this.getService().update(tenantId, uuid, isApi, patchOperations);
        } catch (Exception ex) {
            getLogger().error("[updateSingle]", ex);
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.UPDATE_SINGLE),
                Prefixes.uri(getPrefix(), uuid));
        }

    }
}

