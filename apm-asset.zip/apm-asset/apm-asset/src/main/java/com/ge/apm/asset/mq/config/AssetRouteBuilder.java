/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.config;

import java.net.SocketException;
import java.util.concurrent.TimeUnit;

import com.rabbitmq.client.AlreadyClosedException;
import org.apache.camel.LoggingLevel;
import org.apache.camel.component.rabbitmq.RabbitMQConstants;
import org.apache.camel.model.DataFormatDefinition;
import org.apache.camel.model.RedeliveryPolicyDefinition;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.dataformat.SerializationDataFormat;
import org.apache.camel.processor.interceptor.Tracer;
import org.apache.camel.spi.ExecutorServiceManager;
import org.apache.camel.spi.ThreadPoolProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;

import com.ge.apm.asset.model.DownloadTask;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.asset.mq.predicate.RetryPolicyPredicate;
import com.ge.apm.asset.mq.processor.ConnectionProcessor;
import com.ge.apm.asset.mq.processor.DownloadTypeProcessor;
import com.ge.apm.asset.mq.processor.DtoProcessor;
import com.ge.apm.asset.mq.processor.GroupAssociationProcessor;
import com.ge.apm.asset.mq.processor.GroupProcessor;
import com.ge.apm.asset.mq.processor.InstanceGroupMapProcessor;
import com.ge.apm.asset.mq.processor.TagProcessor;
import com.ge.apm.asset.mq.processor.TaskExceptionProcessor;
import com.ge.apm.asset.mq.processor.TemplateConnectionProcessor;
import com.ge.apm.asset.mq.processor.TemplateProcessor;
import com.ge.apm.asset.mq.redis.TaskStatusLookup;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.exception.AssetServiceException;
import com.ge.asset.commons.mq.config.BaseRouteBuilder;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.mq.util.CryptoHelper;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
public class AssetRouteBuilder extends BaseRouteBuilder {

    protected final DataFormatDefinition byteArrayDataFormat;

    @Autowired
    TemplateConnectionProcessor templateConnectionProcessor;

    @Autowired
    TaskExceptionProcessor taskExceptionProcessor;

    @Value("${message.redelivery.delay:150000}")
    private Long redeliveryDelay;

    @Value("${message.maximum.redeliveries:5}")
    private Integer maxRedeliveries;

    @Autowired
    private TagProcessor tagProcessor;

    @Autowired
    private ConnectionProcessor connectionProcessor;

    @Autowired
    private GroupProcessor groupProcessor;

    @Autowired
    private GroupAssociationProcessor groupAssociationProcessor;

    @Autowired
    private InstanceGroupMapProcessor instanceGroupMapProcessor;

    @Autowired
    private TemplateProcessor templateProcessor;

    @Autowired
    private DtoProcessor<?> dtoProcessor;

    @Autowired
    private RetryPolicyPredicate retryPolicyPredicate;

    @Autowired
    private TaskStatusLookup taskStatusLookup;

    @Autowired
    private DownloadTypeProcessor downloadTypeProcessor;

    @Autowired
    public AssetRouteBuilder(CryptoHelper cryptoHelper) {
        super(AssetRoutes.ASSET_APP_ID, cryptoHelper);
        this.byteArrayDataFormat = new SerializationDataFormat();
    }

    @Override
    public void configure() throws Exception {
        ((Tracer) getContext().getDefaultTracer()).getDefaultTraceFormatter().setShowHeaders(false);
        ((Tracer) getContext().getDefaultTracer()).getDefaultTraceFormatter().setShowOutHeaders(false);
        ((Tracer) getContext().getDefaultTracer()).getDefaultTraceFormatter().setShowBody(false);

        getContext().setErrorHandlerBuilder(defaultErrorHandler().logExhaustedMessageHistory(false));

        this.getContext().setAllowUseOriginalMessage(false);
        ExecutorServiceManager manager = this.getContext().getExecutorServiceManager();
        ThreadPoolProfile defaultProfile = manager.getDefaultThreadPoolProfile();

        // customize the profile settings.
        defaultProfile.setMaxQueueSize(10000);
        configureExceptionDef();

        super.configure();

        this.getContext().getShutdownStrategy().setTimeUnit(TimeUnit.NANOSECONDS);
        this.getContext().getShutdownStrategy().setTimeout(1);
        this.getContext().getShutdownStrategy().setShutdownNowOnTimeout(true);

        configureMain();

        configureDownloadMain();

        configureDeadLetter();

        configureCompleted();

        configureDownloadCompleted();

        configureRetry();

        configureRecoverable();
    }

    private void configureExceptionDef() {
        RedeliveryPolicyDefinition dependencyPolicyDef = redeliveryPolicyDefinition(true, redeliveryDelay,
            maxRedeliveries);

        RedeliveryPolicyDefinition systemRecoverablePolicyDef = redeliveryPolicyDefinition(true, redeliveryDelay,
            maxRedeliveries);

        this.onException(DependencyViolationException.class).onWhen(retryPolicyPredicate).handled(true).to(
            AssetRoutes.DIRECT_DTO_DEAD_LETTER).setRedeliveryPolicy(dependencyPolicyDef);

        this.onException(BadRequestException.class).onWhen(retryPolicyPredicate).handled(true).to(
            AssetRoutes.DIRECT_DTO_DEAD_LETTER).setRedeliveryPolicy(dependencyPolicyDef);

        this.onException(HttpStatusCodeException.class).onWhen(retryPolicyPredicate).handled(true).to(
            AssetRoutes.DIRECT_DTO_DEAD_LETTER).setRedeliveryPolicy(systemRecoverablePolicyDef);

        this.onException(SocketException.class).onWhen(retryPolicyPredicate).handled(true).to(
            AssetRoutes.DIRECT_DTO_DEAD_LETTER).setRedeliveryPolicy(systemRecoverablePolicyDef);

        this.onException(JpaSystemException.class).onWhen(retryPolicyPredicate).handled(true).to(
            AssetRoutes.DIRECT_DTO_DEAD_LETTER).setRedeliveryPolicy(systemRecoverablePolicyDef);

        this.onException(Throwable.class, ServiceException.class, AssetServiceException.class,
            ValidationFailedException.class).handled(true).to(AssetRoutes.DIRECT_DTO_DEAD_LETTER);
    }

    private RedeliveryPolicyDefinition redeliveryPolicyDefinition(boolean async, Long redeliveryDelay,
        int maximumRedeliveries) {
        RedeliveryPolicyDefinition redeliveryPolicy = new RedeliveryPolicyDefinition();
        redeliveryPolicy.setAsyncDelayedRedelivery(String.valueOf(async));
        redeliveryPolicy.setRedeliveryDelay(String.valueOf(redeliveryDelay));
        redeliveryPolicy.setMaximumRedeliveries(String.valueOf(maximumRedeliveries));
        redeliveryPolicy.setRetryAttemptedLogLevel(LoggingLevel.WARN);
        redeliveryPolicy.setLogRetryStackTrace(String.valueOf(true));

        return redeliveryPolicy;
    }

    private void configureDeadLetter() {
        from(AssetRoutes.DIRECT_DTO_DEAD_LETTER)
            .log("About to send Ack from deadletter ERROR task: ${headers.ApmTaskUuid}").doTry()
            .choice().when(simple("${headers.ApmOperationName} == 'download'"))
            .routeId(AssetRoutes.DOWNLOAD_ROUTE_ID_ACK_ERROR)
            .log("About to send Ack for Download ERROR task: ${headers.ApmTaskUuid}")
            .setHeader(RabbitMQConstants.DELIVERY_MODE).simple("2").setHeader(RabbitMQConstants.ROUTING_KEY)
            .simple(AssetRoutes.RMQ_ASSET_DOWNLAOD_ACK_ERROR_ROUTING_KEY)
            .process(taskExceptionProcessor)
            .to(getHeaderEncryptorEndpoint()).marshal(byteArrayDataFormat)
            .marshal(zipDataFormat)
            .to(getRabbitmqEndpoint(AssetRoutes.RMQ_ASSET_DOWNLAOD_ACK,
                AssetRoutes.RMQ_ASSET_DOWNLAOD_ACK_ERROR_ROUTING_KEY))
            .endChoice()
            .otherwise()
            .routeId(AssetRoutes.ROUTE_ID_ACK_ERROR)
            .to(AssetRoutes.LOG_ASSET_ERROR)
            .log("About to send Ack for ERROR task: ${headers.ApmTaskUuid}")
            .setHeader(RabbitMQConstants.DELIVERY_MODE).simple("2").setHeader(RabbitMQConstants.ROUTING_KEY)
            .simple(AssetRoutes.RMQ_ASSET_DTO_ACK_ERROR_ROUTING_KEY)
            .process(taskExceptionProcessor).bean(taskStatusLookup, "markTaskDone")
            .to(getHeaderEncryptorEndpoint())
            .marshal(byteArrayDataFormat)
            .marshal(zipDataFormat)
            .to(getRabbitmqEndpoint(AssetRoutes.RMQ_ASSET_DTO_ACK,
                AssetRoutes.RMQ_ASSET_DTO_ACK_ERROR_ROUTING_KEY)).endChoice()
            .end();
    }

    private void configureCompleted() {
        // Sending the ack back to a different RMQ
        from(AssetRoutes.DIRECT_ASSET_DTO_ACK_COMPLETE)
            .doTry().routeId(AssetRoutes.ROUTE_ID_ACK_COMPLETE)
                .log("About to send Ack for COMPLETED task: ${headers.ApmTaskUuid}")
                .setHeader(RabbitMQConstants.DELIVERY_MODE)
                .simple("2").setHeader(RabbitMQConstants.ROUTING_KEY)
                .simple(AssetRoutes.RMQ_ASSET_DTO_ACK_COMPLETE_ROUTING_KEY)
                .bean(taskStatusLookup, "markTaskDone")
                .setBody().constant(null)
                .to(getHeaderEncryptorEndpoint())
                .marshal(byteArrayDataFormat)
                .marshal(zipDataFormat)
                .to(getRabbitmqEndpoint(AssetRoutes.RMQ_ASSET_DTO_ACK,
                        AssetRoutes.RMQ_ASSET_DTO_ACK_COMPLETE_ROUTING_KEY))
            .doCatch(AlreadyClosedException.class)
                .bean(taskExceptionProcessor, "rabbitmqException")
            .endDoTry()
            .end();
    }

    private void configureMain() {
        from(getRabbitmqEndpoint(AssetRoutes.RMQ_ASSET_DTO, AssetRoutes.RMQ_ASSET_DTO_ROUTING_KEY))
            .routeId(AssetRoutes.ROUTE_ID_DTO_IN)
            .to(getHeaderDecryptorEndpoint())
            .log("Task ${headers.ApmTaskUuid} has been consumed from RabbitMQ!")
            .unmarshal(zipDataFormat)
            .unmarshal(byteArrayDataFormat)
            .choice()
                .when().method(taskStatusLookup, "isTaskInProgress")
                    .log("Task ${headers.ApmTaskUuid} in progress")
                    .delay(1000)
                    .to(AssetRoutes.DIRECT_HANDLE_RECOVERY)
            .endChoice().when().method(taskStatusLookup, "isTaskDone")
                .bean(taskStatusLookup, "disposeTask")
            .endChoice()
            .otherwise()
                // Process these dtos as normal
                .doTry()
                    .to(AssetRoutes.DIRECT_ASSET_RETRY_OR_PROCESS)
                .doCatch(Exception.class).onWhen(retryPolicyPredicate)
                    .to(AssetRoutes.DIRECT_HANDLE_RECOVERY)
                .endDoTry()
            .endChoice()
            .end();

        from(AssetRoutes.DIRECT_ASSET_RETRY_OR_PROCESS)
            .routeId(AssetRoutes.ROUTE_ID_RETRY_OR_PROCESS)
            .errorHandler(noErrorHandler())
            .choice()
                .when(simple("${headers.ApmAssetPrefix} == '/tags'"))
                    .bean(tagProcessor, dispatch())
                .endChoice()
                .when(simple("${headers.ApmAssetPrefix} == '/assetGroups'"))
                    .bean(groupProcessor, dispatch())
                .endChoice()
                .when(simple("${headers.ApmAssetPrefix} == '/groupAssociations'"))
                    .bean(groupAssociationProcessor, dispatch())
                .endChoice()
                .when(simple("${headers.ApmAssetPrefix} == '/assetgroupassociations'"))
                    .bean(instanceGroupMapProcessor, dispatch())
                .endChoice()
                .when(simple("${headers.ApmAssetPrefix} == '/assetTemplates'"))
                    .bean(templateProcessor, dispatch())
                .endChoice()
                .when(simple("${headers.ApmAssetPrefix} == '/assetTemplateConnections'"))
                    .bean(templateConnectionProcessor, dispatch())
                .endChoice()
                .when(simple("${headers.ApmAssetPrefix} == '/connections'"))
                    .bean(connectionProcessor, dispatch())
                .endChoice()
            .otherwise()
                .bean(dtoProcessor, dispatch())
            .endChoice()
            .end()
            .to(AssetRoutes.DIRECT_ASSET_DTO_ACK_COMPLETE).end();
    }

    private void configureRecoverable() {
        from(AssetRoutes.DIRECT_HANDLE_RECOVERY)
            .routeId(AssetRoutes.ROUTE_ID_RECOVERY)
            .marshal(byteArrayDataFormat)
            .marshal(zipDataFormat)
            .choice()
                .when(e -> {
                    return (taskStatusLookup.isTaskInProgress(e)
                                && !taskStatusLookup.isTaskStale(e)) || taskStatusLookup
                    .isTaskDone(e);
                })
                .to(getHeaderEncryptorEndpoint())
                .to(getRabbitmqEndpoint(AssetRoutes.RMQ_ASSET_DTO, AssetRoutes.RMQ_ASSET_DTO_ROUTING_KEY))
            .endChoice()
            .otherwise()
                .setHeader(MessageConstants.TASK_STARTTIME,
                        simple("${bean:java.lang.System?method=currentTimeMillis}"))
                .bean(taskStatusLookup, "markTaskInProgress")
                .to(getHeaderEncryptorEndpoint())
                .to(getRabbitmqEndpoint(AssetRoutes.RMQ_ASSET_DTO, AssetRoutes.RMQ_ASSET_DTO_ROUTING_KEY))
                .to(AssetRoutes.VM_RETRY).endChoice()
            .end();
    }

    private void configureRetry() {
        from(AssetRoutes.VM_RETRY)
            .routeId(AssetRoutes.ROUTE_ID_RETRY)
            .log("Redelivery in progress.. Due to recoverable errors in messages.")
            .to(getHeaderDecryptorEndpoint())
            .bean(taskStatusLookup, "markTaskInProgress")
            .unmarshal(zipDataFormat)
            .unmarshal(byteArrayDataFormat)
            .log("in retry endpoint ${headers.ApmTaskStartTime}")
            .to(AssetRoutes.DIRECT_ASSET_RETRY_OR_PROCESS);
    }

    private void configureDownloadMain() {
        from(getRabbitmqEndpoint(AssetRoutes.RMQ_DOWNLOAD_TASK,
            AssetRoutes.RMQ_DOWNLOAD_TASK_ROUTING_KEY)).routeId(AssetRoutes.ROUTE_ID_DOWNLOAD_IN)
            .to(getHeaderDecryptorEndpoint())
            .unmarshal().json(JsonLibrary.Gson, DownloadTask.class)
            .choice().when(
            simple("${headers.ApmDownloadType} == 'classifications'"))
            .bean(downloadTypeProcessor)
            .endChoice()
            .otherwise()
            .bean(downloadTypeProcessor)
            .endChoice().end()
            .to(AssetRoutes.DIRECT_DOWNLOAD_ACK_COMPLETE)
            .end();

    }

    private void configureDownloadCompleted() {
        // Sending the ack back to a different RMQ
        from(AssetRoutes.DIRECT_DOWNLOAD_ACK_COMPLETE)
            .routeId(AssetRoutes.ROUTE_ID_DOWNLOAD_ACK_COMPLETE)
            .log("Received from task: ${headers.ApmTaskUuid}")
            .doTry()
            .log("About to send Ack for COMPLETED  Download task: ${headers.ApmTaskUuid}")
            .setHeader(RabbitMQConstants.DELIVERY_MODE).simple("2")
            .setHeader(RabbitMQConstants.ROUTING_KEY).simple(AssetRoutes
            .RMQ_ASSET_DOWNLAOD_ACK_COMPLETE_ROUTING_KEY)
            .to(getHeaderEncryptorEndpoint())
            .marshal().json(JsonLibrary.Gson)
            .to(getRabbitmqEndpoint(AssetRoutes.RMQ_ASSET_DOWNLAOD_ACK,
                AssetRoutes.RMQ_ASSET_DOWNLAOD_ACK_COMPLETE_ROUTING_KEY))
            .doCatch(AlreadyClosedException.class)
            .bean(taskExceptionProcessor, "rabbitmqException")
            .endDoTry()
            .end();
    }

    public String dispatch() {
        return "dispatch";
    }
}