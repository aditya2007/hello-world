/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.multipart.MultipartFile;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.model.ConfigContextQuery;
import com.ge.apm.asset.model.ContextConfigValue;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.impl.ContextConfigService;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.errorprovider.ContextConfigError;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.util.fileUtil.FileValidator;

import static com.ge.apm.asset.service.contextConfig.commons.ContextConfigUtils.badRequest;
import static com.ge.asset.commons.errorprovider.ErrorConstants.INVALID_CONFIG_ZIP_FORMAT;

/**
 * Created by 502670744 on 3/10/17.
 */
@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.ContextConfig, IBasePath.v3 + Prefixes.ContextConfig })
public class ContextConfigController extends AbstractController<ContextConfigValue, ContextConfigService> {

    public static final String CREATE_ALL_RESERVED_ATTRIBUTE_CONTEXT_CONFIG
        = "[createAllReservedAttributeContextConfig] ({}) {}";

    public ContextConfigController() {
        super(Prefixes.ContextConfig, ContextConfigValue.class);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/{context}", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(value = HttpStatus.OK)
    public void add(@PathVariable("context") String context, @RequestBody ContextConfigValue contextConfigValue) {
        String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        try {
            getContextConfigService().add(tenantUuid, context, contextConfigValue);
        } catch (Exception ex) {
            getLogger().error("[createReservedAttributeContextConfig] ({}) {}", Prefixes.ContextConfig,
                ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.APP_CONTROLLER));
        }
    }

    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity addAll(@RequestBody ContextConfigValue[] contextConfigValues) {
        String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        List<ContextConfigError> contextConfigErrors = new ArrayList<>();
        try {
            for (ContextConfigValue ccv : contextConfigValues) {
                addContextConfig(tenantUuid, contextConfigErrors, ccv);
            }
            return contextConfigErrors.isEmpty() ? new ResponseEntity(HttpStatus.OK) : new ResponseEntity(
                contextConfigErrors, HttpStatus.MULTI_STATUS);
        } catch (Exception ex) {
            getLogger().error(CREATE_ALL_RESERVED_ATTRIBUTE_CONTEXT_CONFIG, Prefixes.ContextConfig, ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.APP_CONTROLLER));
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/upload",
        produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity addAll(@RequestParam(value = "file") final MultipartFile file) {
        String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        List<ContextConfigError> contextConfigErrors = new ArrayList<>();
        try {

            if (!FileValidator.isValidExtension(file.getOriginalFilename(),
                FileValidator.FILE_ZIP_EXTENSION)) {
                throw badRequest(INVALID_CONFIG_ZIP_FORMAT);
            }

            List<ContextConfigValue> contextConfigValues =
                getContextConfigService().getAll(file.getInputStream());

            getLogger().info("CONTEXT CONFIG VALUES :::" + contextConfigValues.size());

            importContextConfigValues(tenantUuid, contextConfigValues, contextConfigErrors);

            return contextConfigErrors.isEmpty() ? new ResponseEntity(HttpStatus.OK)
                : new ResponseEntity(
                    contextConfigErrors, HttpStatus.MULTI_STATUS);

        } catch (Exception ex) {
            getLogger().error("[import config for the given tenant] ({}) {}",
                Prefixes.ContextConfig,
                ex.getMessage());
            throw ExceptionUtil.wrapException(ex,
                ErrorProvider.findError(ErrorConstants.APP_CONTROLLER));
        }
    }

    private void importContextConfigValues(String tenantUuid,
        List<ContextConfigValue> contextConfigValues,
        List<ContextConfigError> contextConfigErrors) {

        for (ContextConfigValue config : contextConfigValues) {
            try {
                String context = config.getContext();
                String code = config.getCode();
                ConfigContextQuery configContextQuery = new ConfigContextQuery();
                configContextQuery.setContext(new String[] {context});
                configContextQuery.setCode(new String[] {code});
                getLogger().info("******CONTEXT CONFIG VALUE :::" + config);
                List<ContextConfigValue> possibleValues =
                    getContextConfigService().getAllByFilter(tenantUuid, configContextQuery);

                if (CollectionUtils.isEmpty(possibleValues)) {
                    // Create new record
                    getLogger().info("******** Create new record :::");
                    addContextConfig(tenantUuid, contextConfigErrors, config);
                } else {
                    // Update existing record
                    getLogger().info("******** Update new record :::");
                    getContextConfigService().update(tenantUuid, context, code, config);
                }
            } catch (BadRequestException bre) {
                getLogger().error("[import config for the given tenant] ({}) {}",
                    Prefixes.ContextConfig,
                    bre.getMessage(),
                    bre);
                contextConfigErrors.add(
                    new ContextConfigError(config.getContext(), config.getCode(),
                        bre.getMessage()));
            } catch (Exception ex) {
                getLogger().error("[import config for the given tenant] ({}) {}",
                    Prefixes.ContextConfig,
                    ex.getMessage(),
                    ex);
                contextConfigErrors.add(
                    new ContextConfigError(config.getContext(), config.getCode(), "System Error"));
            }
        }
    }

    private void addContextConfig(String tenantUuid, List<ContextConfigError> contextConfigErrors,
        ContextConfigValue ccv) {
        try {
            getContextConfigService().add(tenantUuid, ccv.getContext(), ccv);
        } catch (BadRequestException bre) {
            getLogger().error(CREATE_ALL_RESERVED_ATTRIBUTE_CONTEXT_CONFIG, Prefixes.ContextConfig, bre.getMessage(),
                bre);
            contextConfigErrors.add(new ContextConfigError(ccv.getContext(), ccv.getCode(), bre.getMessage()));
        } catch (Exception ex) {
            getLogger().error(CREATE_ALL_RESERVED_ATTRIBUTE_CONTEXT_CONFIG, Prefixes.ContextConfig, ex.getMessage(),
                ex);
            contextConfigErrors.add(new ContextConfigError(ccv.getContext(), ccv.getCode(), "System Error"));
        }
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/{context}/{code}",
        consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity delete(@PathVariable("context") String context, @PathVariable("code") String code) {
        String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        try {
            getContextConfigService().delete(tenantUuid, context, code);
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        } catch (Exception ex) {
            getLogger().error("[deleteReservedAttributeContextConfig] ({}) {}", Prefixes.ContextConfig,
                ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.APP_CONTROLLER));
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{context}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ContextConfigValue>> getAll(@PathVariable("context") String context) {
        String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        try {
            List<ContextConfigValue> possibleValues = context == null ? getContextConfigService().getAll(tenantUuid)
                : getContextConfigService().getAll(context, tenantUuid);
            return CollectionUtils.isEmpty(possibleValues) ? new ResponseEntity<>(HttpStatus.NOT_FOUND)
                : ResponseEntity.ok(possibleValues);
        } catch (Exception ex) {
            getLogger().error("[getAll config for the given tenant and context] ({}) {}", Prefixes.ContextConfig,
                ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.APP_CONTROLLER));
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = "/download", produces = "application/zip")
    public ResponseEntity<byte[]> getAllForDownload() throws IOException {

        String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        try {
            List<ContextConfigValue> contextConfigValues = getContextConfigService().getAll(tenantUuid);
            ObjectMapper mapper = new ObjectMapper();
            String jsonForArchival = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(contextConfigValues);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ZipOutputStream zos = new ZipOutputStream(out);
            try {
                zos.putNextEntry(new ZipEntry("tenantConfig_getAll.json"));
                zos.write(jsonForArchival.getBytes("UTF-8"));
            } finally {
                zos.closeEntry();
                zos.close();
            }
            return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=tenantConfig.zip")
                .body(out.toByteArray());
        } catch (Exception ex) {
            getLogger().error("[getAll config for the given tenant and context] ({}) {}", Prefixes.ContextConfig,
                ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.APP_CONTROLLER));
        }
    }

    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ContextConfigValue>> getAllByFilter(ConfigContextQuery configContextQuery) {
        String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        try {
            List<ContextConfigValue> possibleValues = (configContextQuery == null || configContextQuery.isEmpty())
                ? getContextConfigService().getAll(tenantUuid) : getContextConfigService().getAllByFilter(tenantUuid,
                configContextQuery);
            return CollectionUtils.isEmpty(possibleValues) ? new ResponseEntity<>(HttpStatus.NOT_FOUND)
                : ResponseEntity.ok(possibleValues);
        } catch (Exception ex) {
            getLogger().error("[getAll config for the given tenant and context] ({}) {}", Prefixes.ContextConfig,
                ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.APP_CONTROLLER));
        }
    }

    @RequestMapping(method = RequestMethod.PATCH, value = "/{context}", produces = MediaType.APPLICATION_JSON_VALUE,
        consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity updateSingle(@PathVariable("context") String context,
        @RequestBody PatchOperation... patchOperations) {
        return updateSingle(context, null, patchOperations);
    }

    @RequestMapping(method = RequestMethod.PATCH, value = "/{context}/{code}",
        produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity updateSingle(@PathVariable("context") String context, @PathVariable("code") String code,
        @RequestBody PatchOperation... patchOperations) {
        String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        try {
            getContextConfigService().update(tenantUuid, context, code, patchOperations);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception ex) {
            getLogger().error("[patch config for the given tenant and context] ({}) {}", Prefixes.ContextConfig,
                ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.APP_CONTROLLER));
        }
    }

    public ContextConfigService getContextConfigService() {
        //TODO: Shouldn't be done this way. This was done for Integration test for apidocs
        if (!RequestContext.contains(ContextConfigService.class.getName())) {
            RequestContext.put(ContextConfigService.class.getName(), getService());
        }
        return RequestContext.get(ContextConfigService.class.getName(), ContextConfigService.class);
    }
}
