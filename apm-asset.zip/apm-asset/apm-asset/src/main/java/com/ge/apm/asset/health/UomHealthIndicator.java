/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.health;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.ge.apm.asset.service.api.IUomService;

@Component
@ConditionalOnExpression("${health.custom.uom.enabled:false}")
public class UomHealthIndicator implements HealthIndicator {

    private final IUomService uomService;

    @Autowired
    public UomHealthIndicator(IUomService uomService) {
        this.uomService = uomService;
    }

    @Override
    public Health health() {
        StopWatch watch = new StopWatch();

        watch.start("healthCheck");
        boolean predixAssetUp = uomService.healthStatus();
        watch.stop();

        Health.Builder builder;
        if (predixAssetUp) {
            builder = Health.up();
        } else {
            builder = Health.down();
        }

        builder.withDetail("hubsUom", watch.getLastTaskInfo());
        return builder.build();
    }
}
