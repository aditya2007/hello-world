/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.ge.apm.asset.model.constants.Prefixes;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Slf4j
@Controller
@RequestMapping(value = {"v1/threadcount"})
@ConditionalOnProperty(name = "debug.threadCount.enabled")
public class DebugController {
    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody ThreadsSummary dumpThreads(HttpServletRequest request) {

        Set<Thread> threads = Thread.getAllStackTraces().keySet();

        ThreadsSummary summary = new ThreadsSummary();
        for(Thread t : threads) {
            summary.addThread(t);
        }

        return summary;
    }

}

class ThreadsSummary {

    public Integer count = 0;
    public Map<String, Integer> byName = new HashMap<>();
    public Map<String, GroupSummary> byGroup = new HashMap<>();
    public Map<String, List<List<String>>> stackTraces = new HashMap<>();

    public String timestamp = new Date().toString();
    public Long epoch = System.currentTimeMillis();

    public MemorySummary memory = new MemorySummary();

    public void addThread(Thread t) {
        count++;

        String name = t.getName();
        if (!byName.containsKey(name)) {
            byName.put(name, 0);
            stackTraces.put(name, new ArrayList<>());
        }
        byName.put(name, byName.get(name) + 1);

        List<String> stackTrace = Arrays.stream(t.getStackTrace()).map(Object::toString).collect(Collectors.toList());
        stackTraces.get(name).add(stackTrace);

        ThreadGroup tg = t.getThreadGroup();
        if (tg != null) {
            name = tg.getName();
            if (!byGroup.containsKey(name)) {
                byGroup.put(name, new GroupSummary(tg));
            }
            byGroup.get(name).count++;
        }
    }
}

class GroupSummary {
    public Integer count = 0;
    public Integer activeCount = 0;
    public Integer activeGroupCount = 0;
    public String parentName;

    public GroupSummary(ThreadGroup tg) {
        this.activeCount = tg.activeCount();
        this.activeGroupCount = tg.activeGroupCount();
        if (tg.getParent() != null) {
            this.parentName = tg.getParent().getName();
        }
    }
}

class MemorySummary {

    public Long max = 0L;
    public Long total;
    public Long free;
    public Long totalFree;
    public Integer availableProcs;

    public MemorySummary() {
        Runtime rt = Runtime.getRuntime();

        max = rt.maxMemory();
        total = rt.totalMemory();
        free = rt.freeMemory();
        availableProcs = rt.availableProcessors();
        totalFree = free + (max - total);
    }

}
