/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.config;

import com.ge.asset.commons.mq.config.BaseRoutes;

/**
 * @author Chand Bhaverisetti 212432041
 * @version Feb 24, 2017
 * @since 1.0
 */
public class AssetRoutes extends BaseRoutes {

    public static final String ASSET_APP_ID = "D47303E528AF4EE58CA036FD977FE945";

    public static final String LOG_ASSET_ERROR = "log:ge.apm.asset.createAsset?level=ERROR";

    public static final String DIRECT_DTO_DEAD_LETTER = "direct:dto.dead.letter";

    public static final String DIRECT_ASSET_RETRY_OR_PROCESS = "direct:ge.apm.asset.retry.or.process";

    public static final String DIRECT_ASSET_DTO_ACK_COMPLETE = "direct:ge.apm.asset.dto.ack.complete";

    public static final String DIRECT_DOWNLOAD_ACK_COMPLETE =
        "direct:ge.apm.asset.download.ack.complete";
    public static final String DIRECT_HANDLE_RECOVERY = "direct:handle.recovery";

    public static final String VM_RETRY = "vm:retry?waitForTaskToComplete=Never";

    public static final String ROUTE_ID_DTO_IN = "dto_in";

    public static final String ROUTE_ID_DOWNLOAD_IN = "download_in";
    public static final String ROUTE_ID_DOWNLOAD_ACK_COMPLETE = "download_ack_complete";

    public static final String ROUTE_ID_RETRY_OR_PROCESS = "retry_or_process";
    public static final String ROUTE_ID_RECOVERY = "recovery";
    public static final String ROUTE_ID_RETRY = "retry";
    public static final String ROUTE_ID_ACK_ERROR = "ack_error";
    public static final String ROUTE_ID_ACK_COMPLETE = "ack_complete";

    public static final String DOWNLOAD_ROUTE_ID_ACK_ERROR = "download_ack_error";

}
