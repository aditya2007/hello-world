/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.Typed;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.asset.mq.redis.SourceKeyLookup;
import com.ge.apm.asset.util.PatchBuilder;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.asset.commons.mq.constants.MessageConstants;

/**
 * Created by 212448111 on 2/9/17.
 */
@Component
@Slf4j
public class ConnectionProcessor extends DtoProcessor<Typed> {

    @Autowired
    SourceKeyLookup sourceKeyLookup;

    @Override
    public void preProcess(Exchange exchange) {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        String authorization = messageHeaders.get(MessageConstants.AUTHORIZATION).toString();
        String task = messageHeaders.get(MessageConstants.TASK_UUID).toString();
        String traceUuid = messageHeaders.get(MessageConstants.TRACE_UUID).toString();
        MDC.put(STR_TRACEID, traceUuid);
        MDC.put(STR_SUBJECT, task);

        mqAuthConfig.configure(tenantUuid, authorization, Prefixes.Assets, RequestMethod.GET);
    }

    /**
     * This method has the CORE logic to process collection of Dtos in each message received from
     * RMQ.
     * It performs -
     * 1. Set parent uri based on source key if it exists
     * 2. Set type uri based on source key if it exists
     * 3. Validate and populate Reserved Attributes
     * 4. Any custom logic specific to Dto
     * 5. Logic to determine post or patch
     * This method CANNOT be overridden in corresponding processors as this iterates the entire
     * collection of Dtos of
     * the message. One can override process() method and implement private processDtos()
     * specific to that processor.
     * This rule is to avoid repeated iteration of Dtos collection in preprocess(), process(),
     * processDtos() &
     * postProcess().
     */
    @Override
    public void process(Exchange exchange) throws DependencyViolationException {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        String authToken = messageHeaders.get(MessageConstants.AUTHORIZATION).toString();

        Typed[] dtos = (Typed[]) exchange.getIn().getBody();
        Typed[] preservedDtos = (Typed[]) exchange.getOut().getBody();

        //Map of create and patch bucket for dtos, where key is index of dto in the array.
        Map<Integer, Typed> newDtoMap = new HashMap<>();
        Map<Integer, PatchOperation[]> existingDtoMap = new HashMap<>();

        //preserve dtos in the exchange
        List<Typed> retryDtos = new ArrayList<>();
        List<DependencyViolationException> violationExceptions = new ArrayList<>();
        for (int idx = 0; idx < dtos.length; idx++) {
            Typed dto = dtos[idx];
            try {
                // set parent uri based on the sourceKey if it exists
                String parent = dto.getParent();
                if (parent != null) {
                    String parentUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid, parent);
                    dto.setParent(parentUri);
                }
                // Any custom logic specific to each Dto goes in corresponding processor
                processDto(dto, exchange);

                // Determine whether it's patch call or post call based on if source key
                // exists or not
                String sourceKey = dto.getSourceKey();
                String uri = null;
                uri = sourceKeyLookup.lookupObjectUriFor(tenantUuid, getPrefixFromConnection(dto), sourceKey);
                PatchOperation[] patchOperations = PatchBuilder.build(dto);

                String uuid = StringUtils.substringAfterLast(uri, "/");
                dto.setUri(uuid);
                existingDtoMap.put(idx, patchOperations);
            } catch (DependencyViolationException dve) {
                retryDtos.add(preservedDtos[idx]);
                violationExceptions.add(dve);
            }
        }

        List<Throwable> exceptions = saveDtos(dtos, existingDtoMap, retryDtos, preservedDtos, violationExceptions);
        if (!exceptions.isEmpty()) {
            exchange.setProperty(getErrorPropertyName(exchange), exceptions);
        }

        // throw dependency violation if retryDtos is not empty
        if (!retryDtos.isEmpty()) {
            // put the preserved dtos back to exchange
            Typed[] retryArray = (Typed[]) retryDtos.toArray(
                (Typed[]) Array.newInstance(Typed.class, retryDtos.size()));
            exchange.getOut().setBody(retryArray);
            throw new DependencyViolationException(violationExceptions);
        }
    }

    private String getPrefixFromConnection(Typed connection) {
        if (Site.class.isAssignableFrom(connection.getClass())) {
            return Prefixes.Sites;
        } else if (Segment.class.isAssignableFrom(connection.getClass())) {
            return Prefixes.Segments;
        } else if (Enterprise.class.isAssignableFrom(connection.getClass())) {
            return Prefixes.Enterprises;
        } else if (Asset.class.isAssignableFrom(connection.getClass())) {
            return Prefixes.Assets;
        } else {
            throw new AssertionError("Unknown type which has no corresponding ISourceKeyController.");
        }
    }

    protected List<Throwable> saveDtos(final Typed[] dtos, final Map<Integer, PatchOperation[]> existingDtoMap,
        List<Typed> retryDtos, final Typed[] preservedDtos, List<DependencyViolationException> violationExceptions) {
        List<Throwable> exceptions = new ArrayList<>();
        if (!existingDtoMap.isEmpty()) {
            existingDtoMap.forEach((i, patchOperations) -> {
                try {
                    controllerFactory.getController(getPrefixFromConnection(dtos[i])).updateSingle(dtos[i].getUri(),
                        Arrays.asList(patchOperations));
                } catch (Exception exception) {
                    if (retryPolicyPredicate.isRecoverableException(exception)) {
                        retryDtos.add(preservedDtos[i]);
                        violationExceptions.add(new DependencyViolationException(exception));
                    } else {
                        exceptions.add(exception);
                    }
                }
            });
        }

        return exceptions;
    }
}
