/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.filter;

import java.io.IOException;
import java.util.Collections;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.http.HttpHeaders;
import org.springframework.web.filter.OncePerRequestFilter;

import com.ge.apm.util.exceptions.model.RestServiceError;
import com.ge.apm.util.exceptions.model.RestServiceError.ErrorInfo;
import com.ge.stuf.exception.HttpRequestException;

public abstract class AssetBaseFilter extends OncePerRequestFilter {

    protected static void sendErrorResponse(HttpServletRequest httpServletRequest, HttpServletResponse response,
        HttpRequestException e) throws IOException {
        response.setStatus(e.getStatus());
        response.resetBuffer();
        ErrorInfo errorInfo = new ErrorInfo(Response.Status.fromStatusCode(e.getStatus()).getReasonPhrase(),
            Response.Status.fromStatusCode(e.getStatus()).getReasonPhrase(), e.getMessage());
        RestServiceError restServiceError = new RestServiceError(Collections.singletonList(errorInfo));
        restServiceError.setTraceId("");
        restServiceError.setPath("[" + httpServletRequest.getMethod() + "] " + httpServletRequest.getRequestURL());
        response.setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
        response.getWriter().write(restServiceError.getFormattedMessage());
    }

    @Override
    public void destroy() {

    }
}
