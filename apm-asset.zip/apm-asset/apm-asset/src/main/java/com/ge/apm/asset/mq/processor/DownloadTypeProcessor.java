/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.commons.collections4.ListUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.apm.asset.model.DownloadTask;
import com.ge.apm.asset.model.Type;
import com.ge.apm.asset.service.api.IAssetTypeService;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.s95.converter.ClassificationConverter;
import com.ge.apm.s95.model.Classification;
import com.ge.apm.s95.model.ClassificationHolder;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.ValidationFailedException;

import static java.util.stream.Collectors.partitioningBy;
import static java.util.stream.Collectors.toList;

/**
 * Created by 502670744 on 9/20/17.
 */
@Slf4j
@Component
public class DownloadTypeProcessor extends DownloadProcessor {

    @Value("${export.query.page.size:1000}")
    private Integer exportQueryPageSize;

    @Value("${export.query.zip.contents.size:10000}")
    private Integer zipContentsSize;

    @Autowired
    IAssetTypeService assetTypeService;

    private Map<String, String> idSrcKeyMap = new HashMap<>();

    @Override
    public void process(Exchange exchange) throws Exception {

        try {

            List<Type> allTypes = getAllTypes(exchange);
            allTypes = processSourceKeysOfParents(allTypes);
            Map<String, String> archivedUrlMap = getArchivedUrlMap(exchange, allTypes);
            createResponse(exchange, archivedUrlMap);

        } catch (Exception ex) {
            log.error(
                "An error has occurred while processing download : " + ex.getMessage());
            throw ex;
        }
    }

    private List<Type> getAllTypes(Exchange exchange) {
        RequestContext.put(RequestContext.TENANT_UUID,
            exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class));
        boolean moreData = false;
        int pageNumber = 1;
        List<Type> allTypesList = new ArrayList<>();
        do {
            Type[] types = assetTypeService.get(pageNumber, exportQueryPageSize);
            allTypesList.addAll(Arrays.asList(types));
            pageNumber++;
            moreData = types.length < exportQueryPageSize ? false : true;
        } while (moreData);
        return allTypesList;
    }

    private List<Type> processSourceKeysOfParents(List<Type> allTypes) {
        createParentIdToSrcKeyMap(allTypes);
        return replaceIdWithSrcKeyForParent(allTypes);
    }

    private Map<String, String> getArchivedUrlMap(Exchange exchange, List<Type> allTypes) throws IOException,
            ValidationFailedException {
        Map<String, String> downloadUrlMap = new HashMap<>();
        List<List<Type>> typesChunks = ListUtils.partition(allTypes, zipContentsSize);
        int fileCounter = 1;
        for (List<Type> chunk: typesChunks) {
            downloadUrlMap.put("url" + fileCounter, getArchivedUrl(exchange, chunk, fileCounter));
            fileCounter++;
        }
        return downloadUrlMap;
    }

    private void createResponse(Exchange exchange, Object object) throws JsonProcessingException,
            ValidationFailedException {
        DownloadTask downloadTask = (DownloadTask) exchange.getIn().getBody();
        JsonObject jsonObject = new JsonObject();
        jsonObject.add("responseUri", new Gson().toJsonTree(object));
        downloadTask.setTaskResponse(jsonObject);
        exchange.getIn().setBody(downloadTask);
    }

    private void createParentIdToSrcKeyMap(List<Type> allTypesList) {
        ListIterator<Type> iterFromLast = allTypesList.listIterator(allTypesList.size());
        while (iterFromLast.hasPrevious()) {
            Type type = iterFromLast.previous();
            if (idSrcKeyMap.containsKey(type.getUri())) {
                idSrcKeyMap.put(type.getUri(), type.getSourceKey());
            }
            if (type.getParent() != null && idSrcKeyMap.get(type.getParent()) == null) {
                idSrcKeyMap.put(type.getParent(), null);
            }
        }
    }

    private List<Type> replaceIdWithSrcKeyForParent(List<Type> allTypesList) {
        allTypesList.forEach(t -> t.setParent(idSrcKeyMap.get(t.getParent())));
        return allTypesList;
    }

    private String getArchivedUrl(Exchange exchange, List<Type> chunk, int fileCounter) throws IOException,
            ValidationFailedException {
        String jsonForArchival = convertToS95Json(chunk);
        String fileName = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class) + "-"
            + "CLASSIFICATIONS" + "-" + fileCounter;
        return archive(exchange, jsonForArchival, fileName);
    }

    private String convertToS95Json(List<Type> allTypes) throws JsonProcessingException {
        List<Classification> classifications = convertToS95Model(allTypes);
        Map<Boolean, List<Classification>> partitionedList = classifications.stream().collect(
            partitioningBy(i -> i.getCcomClass() == MimosaCcomCategory.TAG_TYPE));
        List<Classification> tagClassifications = partitionedList.get(true);
        List<Classification> nonTagClassifications = partitionedList.get(false);

        ObjectMapper mapper = new ObjectMapper();
        ClassificationHolder typeHolder = new ClassificationHolder();
        typeHolder.setClassifications(nonTagClassifications);
        typeHolder.setTagClassifications(tagClassifications);
        return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(typeHolder);
    }

    private List<Classification> convertToS95Model(List<Type> allTypes) throws JsonProcessingException {
        ClassificationConverter converter = new ClassificationConverter();
        return allTypes.stream()
                        .map(converter::assetModelToS95)
                        .collect(toList());
    }
}