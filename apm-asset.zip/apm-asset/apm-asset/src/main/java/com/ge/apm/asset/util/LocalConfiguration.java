/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.util;

import java.util.HashMap;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.EnableAsync;
import redis.clients.jedis.JedisPoolConfig;

@Configuration
@EnableCaching
@EnableAsync
@Profile({ "local" })
@Slf4j
public class LocalConfiguration extends CachingConfigurerSupport {

    @Value("${predixObjectsByUriCache.expire.hrs}")
    private Integer predixObjectsByUriCache;

    @Value("${predixObjectsBySrcKeyCache.expire.hrs}")
    private Integer predixObjectsBySrcKeyCache;

    @Value("${apm.reservedAttr.uomCache.expire.hrs}")
    private Integer uomCacheExpireHours;

    @Value("${apm.reservedAttr.reservedAttributeConfigCache.expire.hrs}")
    private Integer reservedAttributeConfigCacheExpireHours;

    @Value("${jedis.pool.config.maxTotal:100}")
    private Integer maxTotal;

    @Value("${jedis.pool.config.maxIdle:100}")
    private Integer maxIdle;

    @Value("${jedis.pool.config.minIdle:25}")
    private Integer minIdle;

    @Value("${jedis.pool.config.blockWhenExhausted:true}")
    private Boolean blockWhenExhausted;

    @Value("${jedis.pool.config.maxWait:500}")
    private Integer maxWait;

    @Value("${jedis.pool.config.timeBetweenEvictionRuns:15000}")
    private Integer timeBetweenEvictionRuns;

    @Value("${jedis.pool.config.testPerEviction:30}")
    private Integer testPerEviction;

    @Bean
    JedisConnectionFactory connectionFactory() {
        JedisConnectionFactory connectionFactory = new JedisConnectionFactory();
        connectionFactory.setUsePool(true);
        JedisPoolConfig jedisPoolConfig = connectionFactory.getPoolConfig();
        jedisPoolConfig.setMaxTotal(maxTotal);
        jedisPoolConfig.setMaxIdle(maxIdle);
        jedisPoolConfig.setMinIdle(minIdle);
        //Setting to true will result in better behavior when unexpected load hits in production
        jedisPoolConfig.setBlockWhenExhausted(blockWhenExhausted);
        jedisPoolConfig.setMaxWaitMillis(maxWait);
        jedisPoolConfig.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRuns);
        jedisPoolConfig.setNumTestsPerEvictionRun(testPerEviction);
        connectionFactory.afterPropertiesSet();
        return connectionFactory;
    }

    @Bean
    RedisTemplate<Object, Object> redisTemplate(JedisConnectionFactory connectionFactory) {
        RedisTemplate<Object, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    CacheManager cacheManager(RedisTemplate<?, ?> redisTemplate) {
        RedisCacheManager redisCacheManager = new RedisCacheManager(redisTemplate);
        long expiryHrs = 24;
        redisCacheManager.setDefaultExpiration(expiryHrs * 60 * 60); //24 hours
        Map<String, Long> cacheNameAndExpiryMap = new HashMap<>();
        cacheNameAndExpiryMap.put("uomCache", new Long(uomCacheExpireHours * 60 * 60));
        cacheNameAndExpiryMap.put("reservedAttributeConfigCache",
            new Long(reservedAttributeConfigCacheExpireHours * 60 * 60));
        cacheNameAndExpiryMap.put("predixObjectsByUriCache", new Long(predixObjectsByUriCache * 60 * 60));
        cacheNameAndExpiryMap.put("predixObjectsBySrcKeyCache", new Long(predixObjectsBySrcKeyCache * 60 * 60));
        redisCacheManager.setExpires(cacheNameAndExpiryMap);
        redisCacheManager.setUsePrefix(true);
        return redisCacheManager;
    }

    @Bean
    @Override
    public CacheErrorHandler errorHandler() {
        return new CacheErrorHandler() {
            @Override
            public void handleCacheGetError(RuntimeException ex, Cache cache, Object key) {
                log.warn("failed to get from cache {}, key {}", cache.getName(), key, ex);
            }

            @Override
            public void handleCachePutError(RuntimeException ex, Cache cache, Object key, Object value) {
                log.warn("failed to PUT in cache {}, key {}", cache.getName(), key, ex);
            }

            @Override
            public void handleCacheEvictError(RuntimeException ex, Cache cache, Object key) {
                log.warn("failed to EVICT from cache {}, object {}", cache.getName(), key, ex);
            }

            @Override
            public void handleCacheClearError(RuntimeException ex, Cache cache) {
                log.warn("failed to CLEAR cache {}", cache.getName(), ex);
            }
        };
    }
}
