/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.controller.base.IHierarchyController;
import com.ge.apm.asset.controller.base.ISearchController;
import com.ge.apm.asset.controller.base.ITagController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.Type;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.exception.ForbiddenException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.Assets, IBasePath.v3 + Prefixes.Assets,
    IBasePath.v3 + Prefixes.Tenants + "/{tenantId}" + Prefixes.Assets })
public class AssetController extends AbstractController<Asset, IAssetService>
    implements ICrudController<Asset, IAssetService>, IHierarchyController<Asset, IAssetService>,
    ITagController<Asset, IAssetService>, ISearchController<Asset, IAssetService> {

    @Value("${apm.asset.page.size}")
    private int pageSize;

    public AssetController() {
        super(Prefixes.Assets, Prefixes.AssetTypes, Asset.class);
    }

    @Override
    public int getPageSize() {
        return pageSize;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/reservedAttributes")
    @ResponseBody
    public Map<String, ReservedAttributeConfig> reservedAttributes(@RequestParam(required = false) String typeUri) {

        Type assetType = null;
        if (!StringUtils.isEmpty(typeUri)) {
            assetType = getService().getType(typeUri, Asset.class,
                AssetComponentResolver.getParentComponents(new ArrayList<>()));
        }
        return this.getReservedAttributes(assetType);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/{uuid}")
    @ResponseStatus(value = HttpStatus.OK)
    public void delete(@PathVariable("uuid") String uuid) {
        try {
            if (getLogger().isDebugEnabled()) {
                getLogger().debug("[delete]: Delete with prefix:{}, objectClass:{}", Prefixes.uri(getPrefix(), uuid),
                    getObjectClass());
            }
            if (!getObjectClass().isAssignableFrom(getService()
                .getSingle(Prefixes.uri(getPrefix(), uuid), Asset.class, AssetComponentResolver.getBasicComponents())
                .getClass())) {
                throw new ForbiddenException("Access Forbidden");
            }
            QueryPredicate queryPredicate = new QueryPredicate();
            queryPredicate.setPageSize(1);
            Hierarchical[] children = getService().getChildren(getPrefix(), getTypePrefix(),
                Prefixes.uri(getPrefix(), uuid), getObjectClass(), AssetComponentResolver.getBasicComponents(),
                queryPredicate, false, null, true);
            if (ArrayUtils.isEmpty(children)) {
                getService().deleteAssetRecursively(Prefixes.uri(getPrefix(), uuid), "", getObjectClass());
            } else {
                throw new BadRequestException(ErrorProvider.findMessage(ErrorConstants.APP_CONTROLLER_DELETE_CHILDREN),
                    getObjectClass().getSimpleName());
            }
        } catch (IllegalArgumentException ex) {
            getLogger().error(ex.getMessage(), ex);
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_REQUEST), ex.getMessage());
        } catch (ServiceException ex) {
            getLogger().error("[delete:]", ex);
            throw ExceptionUtil.wrapException(ex, ex.getCode());
        } catch (Exception ex) {
            getLogger().error("[delete]", ex);
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.DELETE),
                Prefixes.uri(getPrefix(), uuid));
        }
    }

    private boolean hasGroupAssociations(String uri) {
        return getService().isMemberPartOfAGroup(uri, "ASSET");
    }
}
