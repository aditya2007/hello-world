/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;
/**
 * Created by 212368581 on 5/27/16.
 */

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.Attribute;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAssetTypeService;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.asset.util.Constants;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

@Controller
@RequestMapping(value = { IBasePath.v1 + Constants.App, IBasePath.v3 + Constants.App })
@Slf4j
public class AppController {

    @Inject
    private IAssetTypeService assetTypeService;

    @RequestMapping(method = RequestMethod.GET, value = "tagTypes/{uuid}/inheritedAttributes",
        produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public MeasurementTagType tagTypeAttributes(@PathVariable("uuid") String uuid) {
        try {
            MeasurementTagType tagType = assetTypeService.getDetailedSingle(
                Prefixes.uri(Prefixes.MeasurementTagTypes, uuid), MeasurementTagType.class,
                AssetComponentResolver.parseComponents(AssetComponentResolver.FULL));

            List<String> allKeysInLowerCase = new ArrayList<>();

            LinkedHashMap<String, Attribute> inheritedAttributes = new LinkedHashMap<>();

            LinkedHashMap<String, Attribute> attributes;
            if (tagType != null && tagType.getAttributes() != null && tagType.getAttributes().size() > 0) {
                attributes = tagType.getAttributes();

                allKeysInLowerCase.addAll(
                    attributes.keySet().stream().map(String::toLowerCase).collect(Collectors.toList()));
            }
            MeasurementTagType parent = tagType.getParentInfo();
            while (parent != null) {
                if (parent.getAttributes() != null) {
                    for (String key : parent.getAttributes().keySet()) {
                        if (key != null && !allKeysInLowerCase.contains(key.toLowerCase(Locale.US))) {
                            inheritedAttributes.put(key, parent.getAttributes().get(key));
                            allKeysInLowerCase.add(key.toLowerCase(Locale.US));
                        }
                    }
                }
                parent = parent.getParentInfo();
            }
            tagType.setParentInfo(null);
            tagType.setAttributes(inheritedAttributes);

            return tagType;
        } catch (IllegalArgumentException ex) {
            log.error(ex.getMessage());
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_REQUEST), ex.getMessage());
        } catch (Exception ex) {
            log.error("[tagTypes/{uuid}/inheritedAttributes]", ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.APP_CONTROLLER), uuid);
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = "/assetTypes/{uuid}/inheritedAttributes",
        produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public AssetType assetTypeAttributes(@PathVariable("uuid") String uuid) {
        try {
            AssetType assetType = assetTypeService.getDetailedSingle(Prefixes.uri(Prefixes.AssetTypes, uuid),
                AssetType.class, AssetComponentResolver.parseComponents("FULL"));

            List<String> allKeysInLowerCase = new ArrayList<>();

            LinkedHashMap<String, Attribute> inheritedAttributes = new LinkedHashMap<>();

            LinkedHashMap<String, Attribute> attributes;
            if (assetType != null && assetType.getAttributes() != null && assetType.getAttributes().size() > 0) {
                attributes = assetType.getAttributes();

                allKeysInLowerCase.addAll(
                    attributes.keySet().stream().map(String::toLowerCase).collect(Collectors.toList()));
            }
            AssetType parent = assetType.getParentInfo();
            while (parent != null) {
                if (parent.getAttributes() != null) {
                    for (String key : parent.getAttributes().keySet()) {
                        if (key != null && !allKeysInLowerCase.contains(key.toLowerCase(Locale.US))) {
                            inheritedAttributes.put(key, parent.getAttributes().get(key));
                            allKeysInLowerCase.add(key.toLowerCase(Locale.US));
                        }
                    }
                }
                parent = parent.getParentInfo();
            }
            assetType.setParentInfo(null);
            assetType.setAttributes(inheritedAttributes);

            return assetType;
        } catch (IllegalArgumentException ex) {
            log.error(ex.getMessage());
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_REQUEST), ex.getMessage());
        } catch (Exception ex) {
            log.error("[/assetTypes/{uuid}/inheritedAttributes]", ex.getMessage());
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.APP_CONTROLLER), uuid);
        }
    }
}