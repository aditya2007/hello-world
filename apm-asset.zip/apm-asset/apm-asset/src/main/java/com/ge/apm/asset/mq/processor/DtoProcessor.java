/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.model.Monitored;
import com.ge.apm.asset.model.Named;
import com.ge.apm.asset.model.Template;
import com.ge.apm.asset.model.Typed;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.config.MqAuthConfig;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.asset.mq.factory.ControllerFactory;
import com.ge.apm.asset.mq.predicate.RetryPolicyPredicate;
import com.ge.apm.asset.mq.redis.SourceKeyLookup;
import com.ge.apm.asset.mq.util.ReservedAttributesUtil;
import com.ge.apm.asset.util.PatchBuilder;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.json.patch.AddOperation;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.asset.commons.errorprovider.AssetError;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.exception.AssetServiceException;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.ValidationFailedException;
import com.ge.asset.commons.validator.ValidationResult;
import com.ge.asset.commons.validator.Validator;

@Slf4j
@Component
public class DtoProcessor<T extends Hierarchical> implements Processor {

    protected static final String STR_TRACEID = "X-B3-TraceId";

    protected static final String STR_SUBJECT = "subject";

    private static final ObjectReader READER = new ObjectMapper().configure(
        DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false).reader(ServiceException.class);

    private static final String ERRORS = "errors";

    private static final String ACCUMULATED_SERVICE_EXCEPTIONS_COUNT = "accumulatedServiceExceptionCount";

    @Autowired
    MqAuthConfig mqAuthConfig;

    @Autowired
    ControllerFactory controllerFactory;

    @Autowired
    ReservedAttributesUtil reservedAttributesUtil;

    @Autowired
    RetryPolicyPredicate retryPolicyPredicate;

    @Autowired
    private SourceKeyLookup sourceKeyLookup;

    /**
     * The method is called for each message consumed from RMQ. This delegates to specific processors based on prefix
     * specified in RouteBuilder. Input parameter is exchange Exception Could be {com.ge.apm.asset.mq.exception
     * .DependencyViolationException} which needs to remain unacknowledged on the queue. This method CANNOT be
     * overridden in specific processors as this dictates message consumption process flow. This method is invoked by
     * camel directly based on prefix specified in RouteBuilder.
     *
     * @param exchange The Camel exchange object to manipulate body and headers.
     */
    public final void dispatch(Exchange exchange) throws Exception {
        if (exchange.getProperty(MessageConstants.TASK_RETRY_DTOS) != null) {
            exchange.getIn().setBody(exchange.getProperty(MessageConstants.TASK_RETRY_DTOS));
        }
        checkExchangeBodyIsEmpty(exchange);

        T[] dtos = (T[]) exchange.getIn().getBody(Object[].class);
        T[] copy;
        int dependencyExceptionCount = 0;

        if (exchange.getIn().getHeader(MessageConstants.ASSET_PREFIX, "").equals(
            MessageConstants.ASSET_CONNECTION_PREFIX)) {
            copy = (T[]) SerializationUtils.clone(
                Arrays.asList(dtos).toArray((T[]) Array.newInstance(Typed.class, dtos.length)));
        } else {
            copy = (T[]) SerializationUtils.clone(
                Arrays.asList(dtos).toArray((T[]) Array.newInstance(dtos[0].getClass(), dtos.length)));
        }
        exchange.getOut().setBody(copy);
        try {
            preProcess(exchange);

            process(exchange);

            postProcess(exchange);
        } catch (DependencyViolationException dve) {
            dependencyExceptionCount = ((T[]) exchange.getOut().getBody()).length;
            throw dve;
        } catch (ServiceException sve) {
            // Only set the count to 0 for processing non-instance objs.
            // In the case of instance objs, the count is set within process()
            if (getErrors(exchange).isEmpty()) {

                int previousCount = (int) exchange.getIn().getHeader(ACCUMULATED_SERVICE_EXCEPTIONS_COUNT, 0);
                exchange.getIn().setHeader(ACCUMULATED_SERVICE_EXCEPTIONS_COUNT, previousCount + dtos.length);
            }
            throw sve;
        } finally {
            int completedEntities = (int) exchange.getIn().getHeader(MessageConstants.TASK_ENTITY_TOTAL);
            completedEntities -= (int) exchange.getIn().getHeader(ACCUMULATED_SERVICE_EXCEPTIONS_COUNT, 0);
            completedEntities -= dependencyExceptionCount;

            //Swap the in into out when sending out the message
            exchange.setProperty(MessageConstants.TASK_RETRY_DTOS, exchange.getOut().getBody());
            exchange.getOut().setHeaders(exchange.getIn().getHeaders());
            exchange.getOut().setHeader(MessageConstants.TASK_ENTITY_COMPLETE, completedEntities);
        }
    }

    /**
     * This method is called before process() to check if message is empty and perform authentication and authorization.
     * Any custom logic that needs to be performed before processing Dtos will go into this method.
     */
    public void preProcess(Exchange exchange) {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        String prefix = messageHeaders.get(MessageConstants.ASSET_PREFIX).toString();
        String authorization = messageHeaders.get(MessageConstants.AUTHORIZATION).toString();
        String task = messageHeaders.get(MessageConstants.TASK_UUID).toString();
        String traceUuid = messageHeaders.get(MessageConstants.TRACE_UUID).toString();
        MDC.put(STR_TRACEID, traceUuid);
        MDC.put(STR_SUBJECT, task);

        mqAuthConfig.configure(tenantUuid, authorization, prefix, RequestMethod.GET);

        reservedAttributesUtil.getReservedAttributesConfigMapIfExists(prefix);
    }

    private void checkExchangeBodyIsEmpty(Exchange exchange) {
        T[] dtos = (T[]) exchange.getIn().getBody(Object[].class);
        if (dtos == null || dtos.length == 0) {
            String errorMessage = "No Dtos available.";
            log.error(errorMessage);
            throw new ServiceException(ErrorProvider.findError(ErrorConstants.NO_DATA), errorMessage);
        }
    }

    /**
     * This method is called after process() to check for any validation errors/warnings and mark the task status.
     */
    public void postProcess(Exchange exchange) throws ValidationFailedException {

        List<Exception> exceptions = getErrors(exchange);
        if (exceptions != null && exceptions.size() > 0) {
            List<AssetError> assetErrors = new ArrayList<>();
            AssetError assetError;
            for (Exception exception : exceptions) {
                if (exception instanceof ServiceException) {
                    ServiceException se = (ServiceException) exception;
                    assetError = ErrorProvider.findError(se.getCode());
                    assetError.setMsg(se.getMessage());
                } else {
                    assetError = ErrorProvider.findError(ErrorConstants.SYSTEM_ERROR);
                    assetError.setMsg(exception.getMessage());
                }
                assetError.setActualMsg(getStackTrace(exception));
                assetErrors.add(assetError);
            }
            AssetServiceException assetServiceEx = new AssetServiceException(ErrorConstants.SYSTEM_ERROR);
            assetServiceEx.setErrors(assetErrors);
            throw assetServiceEx;
        }

        ValidationResult validationResult = reservedAttributesUtil.getValidationResult(exchange);
        if (validationResult != null && !validationResult.isValid()) {
            StringBuilder sb = new StringBuilder();
            validationResult.getResponseContext().forEach((key, value) -> {
                sb.append("reserved attribute " + key + " is not valid because " + value);
            });
            log.warn(sb.toString());
            throw new ValidationFailedException(validationResult.getErrors());
        }
    }

    private String getStackTrace(Throwable ex) {
        StringBuilder builder = new StringBuilder();
        String[] stackTrace = ExceptionUtils.getRootCauseStackTrace(ex);
        Arrays.stream(stackTrace).forEach(s -> builder.append(builder.length() < 5000 ? s : ""));
        return builder.toString();
    }

    /**
     * This method processes the Dtos and all the consumption logic goes here. Specific processors can override this
     * method if Dtos need to be processed differently
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        String prefix = messageHeaders.get(MessageConstants.ASSET_PREFIX).toString();

        processDtos(tenantUuid, prefix, exchange);
    }

    /**
     * This method has all the processor specific custom logic for processing each Dto and need to be overridden in
     * corresponding specific processors. To avoid repeated iteration of Dtos collection this overridden method is
     * called from processDtos().
     */
    protected void processDto(T dto, Exchange exchange) {
    }

    /**
     * This method has the CORE logic to process collection of Dtos in each message received from RMQ. It performs - 1.
     * Set parent uri based on source key if it exists 2. Set type uri based on source key if it exists 3. Validate and
     * populate Reserved Attributes 4. Any custom logic specific to Dto 5. Logic to determine post or patch This method
     * CANNOT be overridden in corresponding processors as this iterates the entire collection of Dtos of the message.
     * One can override process() method and implement private processDtos() specific to that processor. This rule is to
     * avoid repeated iteration of Dtos collection in preprocess(), process(), processDtos() & postProcess().
     */
    private void processDtos(String tenantUuid, String prefix, Exchange exchange) {
        T[] dtos = (T[]) exchange.getIn().getBody();
        T[] preservedDtos = (T[]) exchange.getOut().getBody();

        //Map of create and patch bucket for dtos, where key is index of dto in the array.
        Map<Integer, T> newDtoMap = new HashMap<>();
        Map<Integer, PatchOperation[]> existingDtoMap = new HashMap<>();

        //preserve dtos in the exchange
        List<T> retryDtos = new ArrayList<>();
        List<DependencyViolationException> violationExceptions = new ArrayList<>();
        for (int idx = 0; idx < dtos.length; idx++) {
            T dto = dtos[idx];
            try {
                // set parent uri based on the sourceKey if it exists
                String parent = dto.getParent();
                if (parent != null) {
                    String parentUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid, parent);
                    dto.setParent(parentUri);
                }

                // set type to uri based on the sourceKey if it exists
                if (dto instanceof Typed && !StringUtils.isEmpty(((Typed) dto).getType())) {
                    String typeUri = null;
                    typeUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid, ((Typed) dto).getType());
                    ((Typed) dto).setType(typeUri);
                    reservedAttributesUtil.validateReservedAttributesIfExists(prefix, dto, typeUri, exchange,
                        dto.getSourceKey());
                }

                // reserved attributes for assetType
                if ((prefix.equals(Prefixes.AssetTypes) || prefix.equals(Prefixes.MeasurementTagTypes))
                    && dto.getReservedAttributes() != null && !dto.getReservedAttributes().isEmpty()) {
                    reservedAttributesUtil.validateReservedAttributes(dto.getReservedAttributes(),
                        reservedAttributesUtil.getReservedAttributesConfigMapIfExists(prefix), exchange,
                        dto.getSourceKey(), prefix);
                }

                // specific customized logic to each Dto goes in corresponding processor
                processDto(dto, exchange);

                /*
                 * In relational DB world, there is nothing like 'sourceKey' for
                 * 'GroupAssociations'.
                 * Hence there is no need to do sourceKey lookup.
                 */
                if (Prefixes.GroupAssociations.compareTo(prefix) == 0 || Prefixes.AssetGroupAssociations.compareTo(
                    prefix) == 0) {
                    newDtoMap.put(idx, dto);
                } else {
                    // Determine whether it's patch call or post call based on if source key
                    // exists or not
                    String sourceKey = dto.getSourceKey();
                    String uri = null;
                    try {
                        uri = sourceKeyLookup.lookupObjectUriFor(tenantUuid, prefix, sourceKey);
                        PatchOperation[] patchOperations = PatchBuilder.build(dto);

                        //Allow setting NULL values for patch operations via Template
                        if (dto instanceof Template) {
                            patchOperations = updatePatchOpsForTemplate(dto, patchOperations);
                        }

                        String uuid = StringUtils.substringAfterLast(uri, "/");
                        dto.setUri(uuid);
                        existingDtoMap.put(idx, patchOperations);
                    } catch (DependencyViolationException dve) {
                        if (parent != null && dto instanceof Monitored) {
                            throw dve;
                        } else {
                            newDtoMap.put(idx, dto);
                        }
                    }
                }
            } catch (DependencyViolationException dve) {
                retryDtos.add(preservedDtos[idx]);
                violationExceptions.add(dve);
            }
        }

        List<Throwable> exceptions = saveDtos(prefix, dtos, newDtoMap, existingDtoMap, retryDtos, preservedDtos,
            violationExceptions);
        if (!exceptions.isEmpty()) {
            exchange.setProperty(getErrorPropertyName(exchange), exceptions);

            int previousCount = (int) exchange.getIn().getHeader(ACCUMULATED_SERVICE_EXCEPTIONS_COUNT, 0);
            exchange.getIn().setHeader(ACCUMULATED_SERVICE_EXCEPTIONS_COUNT, previousCount + exceptions.size());
        }

        // throw dependency violation if retryDtos is not empty
        if (!retryDtos.isEmpty()) {
            // put the preserved dtos back to exchange
            T[] retryArray = (T[]) retryDtos.toArray(
                (T[]) Array.newInstance(retryDtos.get(0).getClass(), retryDtos.size()));
            exchange.getOut().setBody(retryArray);
            throw new DependencyViolationException(violationExceptions);
        }
    }

    protected List<Throwable> saveDtos(final String prefix, final T[] dtos, Map<Integer, T> newDtoMap,
        final Map<Integer, PatchOperation[]> existingDtoMap, List<T> retryDtos, final T[] preservedDtos,
        List<DependencyViolationException> violationExceptions) {
        List<Throwable> exceptions = new ArrayList<>();
        if (!existingDtoMap.isEmpty()) {
            existingDtoMap.forEach((i, patchOperations) -> {
                try {
                    controllerFactory.getController(prefix).updateSingle(dtos[i].getUri(),
                        patchOperations == null ? new ArrayList<PatchOperation>() : Arrays.asList(patchOperations));
                } catch (Exception exception) {
                    if (retryPolicyPredicate.isRecoverableException(exception)) {
                        retryDtos.add(preservedDtos[i]);
                        violationExceptions.add(new DependencyViolationException(exception));
                    } else {
                        exceptions.add(exception);
                    }
                }
            });
        }

        List<T> newDtoList = new ArrayList<>();
        newDtoMap.forEach((index, newDto) -> {
            boolean skipTheList = false;
            if (Prefixes.Assets.compareTo(prefix) == 0) {
                ValidationResult validationResult = checkForDecommissionedAssets((Asset) newDto);
                if (!validationResult.isValid()) {
                    exceptions.add(new ServiceException(
                        ErrorProvider.findError(ErrorConstants.ASSET_WITH_DECOMMISSIONED_STATE_IS_NOT_ALLOWED),
                        validationResult.getErrors().get(0).getPlaceHolders()));
                    skipTheList = true;
                }
            }
            if (!skipTheList) {
                newDtoList.add(newDto);
            }
        });

        if (!newDtoList.isEmpty()) {
            try {
                saveDto(prefix, newDtoList);
            } catch (Exception exception) {
                if (retryPolicyPredicate.isRecoverableException(exception)) {
                    for (Integer index : newDtoMap.keySet()) {
                        retryDtos.add(preservedDtos[index]);
                    }
                    violationExceptions.add(new DependencyViolationException(exception));
                } else {
                    exceptions.add(exception);
                }
            }
        }
        return exceptions;
    }

    private ValidationResult checkForDecommissionedAssets(Asset asset) {
        Validator validator = new Validator(Validator.ASSET_INSTANCE_VALIDATION, new HashMap<>());
        return validator.validate(asset);
    }

    protected void saveDto(String prefix, List<T> newDtoList) {
        controllerFactory.getController(prefix).create(newDtoList);
    }

    private List<Exception> getErrors(Exchange exchange) {
        if (exchange.getProperty(getErrorPropertyName(exchange)) != null) {
            return (List<Exception>) exchange.getProperty(getErrorPropertyName(exchange));
        }
        return Collections.EMPTY_LIST;
    }

    protected String getErrorPropertyName(Exchange exchange) {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        String taskUuid = messageHeaders.get(MessageConstants.TASK_UUID).toString();
        return ERRORS + "_" + tenantUuid + "_" + taskUuid;
    }

    protected String getExchangeKey(Exchange exchange, String key) {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        String taskUuid = messageHeaders.get(MessageConstants.TASK_UUID).toString();
        return key + "_" + tenantUuid + "_" + taskUuid;
    }

    protected Object getExchangeFieldValue(Exchange exchange, String key, Object defaultValue) {
        String uniqueKey = getExchangeKey(exchange, key);
        return exchange.getProperty(uniqueKey, defaultValue);
    }

    protected void setExchangeFieldValue(Exchange exchange, String key, Object value) {
        String uniqueKey = getExchangeKey(exchange, key);
        exchange.setProperty(uniqueKey, value);
    }

    protected PatchOperation[] updatePatchOpsForTemplateConnection(T dto, PatchOperation[] patchOperations) {
        List<PatchOperation> templateConnPatchOps = new ArrayList<>();
        if (dto.getParent() == null) {
            templateConnPatchOps.add(new AddOperation("/" + Hierarchical.Parent, null));
        }
        if (((Asset) dto).getTemplateInfo() == null) {
            templateConnPatchOps.add(new AddOperation("/" + Asset.TemplateInfo, null));
        }
        if (!templateConnPatchOps.isEmpty()) {
            List<PatchOperation> tempPatchOps = new ArrayList<>();
            tempPatchOps.addAll(Arrays.asList(patchOperations));
            tempPatchOps.addAll(templateConnPatchOps);
            patchOperations = tempPatchOps.stream().toArray(PatchOperation[]::new);
        }
        return patchOperations;
    }

    protected PatchOperation[] updatePatchOpsForTemplate(T dto, PatchOperation[] patchOperations) {
        Template templateDto = (Template) dto;
        List<PatchOperation> templatePatchOps = new ArrayList<>();

        if (templateDto.getDescription() == null) {
            templatePatchOps.add(new AddOperation("/" + Named.Description, null));
        }
        if (templateDto.getRevision() == null) {
            templatePatchOps.add(new AddOperation("/revision", null));
        }
        if (templateDto.getPlaceholders() == null) {
            templatePatchOps.add(new AddOperation("/placeholders", null));
        }

        if (!CollectionUtils.isEmpty(templatePatchOps)) {
            List<PatchOperation> returnedTemplatePatchOps = new ArrayList<>();
            returnedTemplatePatchOps.addAll(Arrays.asList(patchOperations));
            returnedTemplatePatchOps.addAll(templatePatchOps);
            patchOperations = returnedTemplatePatchOps.stream().toArray(PatchOperation[]::new);
        }

        return patchOperations;
    }
}
