/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.asset.controller.AssetGroupAssociationController;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.model.InstanceGroupMap;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.asset.mq.redis.SourceKeyLookup;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.mq.constants.MessageConstants;

@Component
@Slf4j
public class InstanceGroupMapProcessor extends DtoProcessor {

    @Autowired
    private SourceKeyLookup sourceKeyLookup;

    @Autowired
    private AssetGroupAssociationController assetGroupAssociationController;

    @Override
    protected void processDto(Hierarchical dto, Exchange exchange) {
        // set toUri and fromUri if dto is GroupAssociation
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();

        // adapter sets prefix & sourcekey for uri and we do extract & lookup here
        String groupUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid, Prefixes.Groups,
            ((InstanceGroupMap) dto).getGroupSourceKey());
        ((InstanceGroupMap) dto).setGroupUri(groupUri);
    }

    @Override
    protected void saveDto(String prefix, List newDtoList) {
        for (Object newDto : newDtoList) {
            InstanceGroupMap instanceGroupMap = (InstanceGroupMap) newDto;
            LinkedHashMap<String, Object> assetGroupAssociationRequest = new LinkedHashMap<>();
            assetGroupAssociationRequest.put("assetGroupUri", instanceGroupMap.getGroupUri());
            LinkedHashMap<String, Object> typeSrcKeyMap = new LinkedHashMap<>();
            typeSrcKeyMap.put("type", instanceGroupMap.getInstancePrefix());
            List<String> tempArr = new ArrayList<>();
            tempArr.add(instanceGroupMap.getInstanceSourceKey());
            typeSrcKeyMap.put("sourceKeys", tempArr);
            List<Map<String, Object>> typeSrcKeyMapList = new ArrayList<>();
            typeSrcKeyMapList.add(typeSrcKeyMap);
            LinkedHashMap<String, Object> assetsSourceKeyMap = new LinkedHashMap<>();
            assetsSourceKeyMap.put("sourceKeys", typeSrcKeyMapList);
            assetGroupAssociationRequest.put("assets", assetsSourceKeyMap);
            try {
                assetGroupAssociationController.associateGroupToAssets(assetGroupAssociationRequest,
                    instanceGroupMap.getGroupUri());
            } catch (BadRequestException excep) {
                if (ErrorConstants.SOURCE_KEYS_MISMATCH.compareTo(excep.getCode()) == 0) {
                    throw new DependencyViolationException(excep);
                } else {
                    throw excep;
                }
            }
        }
    }
}
