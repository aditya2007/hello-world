/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.controller.base.IHierarchyController;
import com.ge.apm.asset.model.SegmentType;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAssetTypeService;

@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.SegmentTypes, IBasePath.v3 + Prefixes.SegmentTypes,
    IBasePath.v3 + Prefixes.Tenants + "/{tenantId}" + Prefixes.SegmentTypes })
public class SegmentTypeController extends AbstractController<SegmentType, IAssetTypeService>
    implements ICrudController<SegmentType, IAssetTypeService>, IHierarchyController<SegmentType, IAssetTypeService> {

    public SegmentTypeController() {
        super(Prefixes.SegmentTypes, SegmentType.class);
    }
}
