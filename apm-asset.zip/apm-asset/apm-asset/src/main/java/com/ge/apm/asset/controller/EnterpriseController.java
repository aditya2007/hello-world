/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.Map;
import java.util.Optional;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.controller.base.IHierarchyController;
import com.ge.apm.asset.controller.base.ISearchController;
import com.ge.apm.asset.controller.base.ITagController;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.Enterprises, IBasePath.v3 + Prefixes.Enterprises,
    IBasePath.v3 + Prefixes.Tenants + "/{tenantId}" + Prefixes.Enterprises })
public class EnterpriseController extends AbstractController<Enterprise, IAssetService>
    implements ICrudController<Enterprise, IAssetService>, ITagController<Enterprise, IAssetService>,
    ISearchController<Enterprise, IAssetService>, IHierarchyController<Enterprise, IAssetService> {

    @Value("${apm.asset.page.size}")
    private int pageSize;

    public EnterpriseController() {
        super(Prefixes.Enterprises, Prefixes.EnterpriseTypes, Enterprise.class);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{uuid}/sites", produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public Hierarchical[] getSites(@PathVariable("uuid") String uuid, @RequestParam(required = false) String components,
        @RequestParam(required = false) String name,
        @RequestParam(required = false, defaultValue = "false") boolean deepSearch,
        @RequestParam(required = false) String nextPageLink) {
        try {
            QueryPredicate queryPredicate = new QueryPredicate();

            if (!StringUtils.isEmpty(name)) {
                queryPredicate.setName(Optional.of(name));
            }
            if (pageSize > MAX_PAGE_SIZE) {
                pageSize = MAX_PAGE_SIZE;
            }
            queryPredicate.setPageSize(pageSize);

            if (!StringUtils.isEmpty(nextPageLink)) {
                getPageNumberFromNextPageLink(nextPageLink, queryPredicate);
            }
            return getService().getChildren(getPrefix(), Prefixes.Sites, Prefixes.uri(getPrefix(), uuid),
                getObjectClass(), AssetComponentResolver.parseComponents(components), queryPredicate,
                deepSearch, null, false);
        } catch (Exception ex) {
            getLogger().error("[getSites]", ex);
            throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.GET_CHILDREN),
                Prefixes.uri(getPrefix(), uuid));
        }
    }

    private void getPageNumberFromNextPageLink(String nextPageLink, QueryPredicate queryPredicate) {
        try {
            queryPredicate.setPageNumber(Integer.parseInt(nextPageLink));
        } catch (Exception ex) {
            getLogger().error("Page Number value is missing in nextPageLink param: {}", nextPageLink, ex);
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.BAD_REQUEST));
        }
    }

    @Override
    public int getPageSize() {
        return pageSize;
    }

    @Override
    @RequestMapping(method = RequestMethod.DELETE, value = "/{uuid}")
    @ResponseStatus(value = HttpStatus.OK)
    public void delete(@PathVariable("uuid") String uuid) {
        throw ExceptionUtil.wrapException(new ServiceException(ErrorConstants.TEMP_OPERATION_STOP),
            ErrorProvider.findError(ErrorConstants.DELETE), Prefixes.uri(getPrefix(), uuid));
    }

    @Override
    @RequestMapping(method = RequestMethod.GET, value = "/reservedAttributes")
    @ResponseBody
    public Map<String, ReservedAttributeConfig> reservedAttributes() {
        return this.getReservedAttributes(null);
    }
}
