/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.controller.base.ISearchController;
import com.ge.apm.asset.model.AssetGroupAssociation;
import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.model.Constants;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.model.Typed;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.factory.ControllerFactory;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.service.util.AssetStateManagerUtil;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

@Controller
@RequestMapping(
    value = { IBasePath.v1 + Prefixes.AssetGroupAssociations, IBasePath.v3 + Prefixes.AssetGroupAssociations })
public class AssetGroupAssociationController extends AbstractController<AssetGroupAssociation, IAssetService> {

    private static final String LOCATION_HEADER = "Location";

    @Value("${apm.asset.restrictionfeature.enabled:false}")
    private boolean assetRestrictionFeaturesEnabled;

    @Autowired
    public ControllerFactory controllerFactory;

    public AssetGroupAssociationController() {
        super(Prefixes.AssetGroupAssociations, AssetGroupAssociation.class);
    }

    @RequestMapping(method = RequestMethod.DELETE)
    @ResponseStatus(value = HttpStatus.OK)
    public void disassociate(@RequestParam(required = false) String assetgroupuri,
        @RequestParam(required = false) String asseturi) {
        if (StringUtils.isEmpty(assetgroupuri) && StringUtils.isEmpty(asseturi)) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.MISSING_MANDATORY_PARAM),
                "assetgroupuri and/or asseturi");
        } else {
            if ((assetgroupuri != null && assetgroupuri.isEmpty()) || (asseturi != null && asseturi.isEmpty())) {
                throw new BadRequestException(ErrorProvider.findError(ErrorConstants.BAD_REQUEST));
            }
            String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
            getService().disassociateAssetGroup(tenantId, assetgroupuri, asseturi);
        }
    }

    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(value = HttpStatus.CREATED)
    public void associate(@RequestBody Map<String, Object> associations) {
        String groupUri = associations.get("assetGroupUri") == null ? null : associations.get("assetGroupUri")
            .toString();
        String assetUri = associations.get("assetUri") == null ? null : associations.get("assetUri").toString();
        if (!StringUtils.isEmpty(groupUri) && !StringUtils.isEmpty(assetUri)) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_ASSOCIATION_REQUEST));
        } else {
            String locationUri = "";
            if (!StringUtils.isEmpty(groupUri)) {
                associateGroupToAssets(associations, groupUri);
                if (groupUri != null) {
                    locationUri = "?assetgroupuri=" + (groupUri.startsWith("/") ? groupUri : "/" + groupUri);
                }
            } else if (!StringUtils.isEmpty(assetUri)) {
                associateAssetToGroups(associations, assetUri);
                locationUri = "?asseturi=" + assetUri;
            } else {
                throw new BadRequestException(ErrorProvider.findError(ErrorConstants.ASSOCIATED_MANDATORY_FIELDS));
            }
            RequestContext.put(Constants.CONST_LOCATION_URI, locationUri);
        }
    }

    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Typed[] getAssociatedAssetsOrGroups(@RequestParam(required = false) String asseturi,
        @RequestParam(required = false) String category, @RequestParam(required = false) String assetgroupuri) {
        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        if (!StringUtils.isEmpty(asseturi) && !StringUtils.isEmpty(assetgroupuri) || StringUtils.isEmpty(asseturi)
            && StringUtils.isEmpty(assetgroupuri)) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_REQUEST));
        } else if (!StringUtils.isEmpty(asseturi)) {
            return getService().getAssociatedGroupsOfAnAsset(tenantId, asseturi, category);
        } else {
            return getService().getAssociatedAssetsOfAGroup(tenantId, assetgroupuri);
        }
    }

    /**
     * Function to associate list of groups to an Asset.
     *
     * @param associations Map
     * @param assetUri String
     */
    private void associateAssetToGroups(Map<String, Object> associations, String assetUri) {

        Attributable asset;
        try {
            final String prefix = Prefixes.prefixFromUri(assetUri);
            final ICrudController assetController = controllerFactory.getController(prefix);
            asset = assetController.getSingle(assetUri.split("/")[2], AssetComponentResolver.BASIC);
            checkIfAssociationIsHappeningWithDecommissionedAssets(asset);
        } catch (ArrayIndexOutOfBoundsException | AssertionError assertionError) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_ASSET_URI), assetUri,
                assetUri);
        }
        if (asset == null) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_ASSET_URI), assetUri,
                assetUri);
        }
        Map<String, List> mappedAssetGroupRefs = (Map<String, List>) associations.get("assetGroups");
        List<AssetGroupAssociation> assetGroupAssociationsList = new ArrayList<>();
        List<String> assetGroupSourceKeys = (ArrayList<String>) mappedAssetGroupRefs.get("sourceKeys");
        if (!CollectionUtils.isEmpty(assetGroupSourceKeys)) {
            assetGroupAssociationsList.addAll(findGroups(assetGroupSourceKeys, asset, "sourceKey="));
        }
        List<String> assetGroupUris = (ArrayList<String>) mappedAssetGroupRefs.get("uris");
        if (!CollectionUtils.isEmpty(assetGroupUris)) {
            assetGroupAssociationsList.addAll(findGroups(assetGroupUris, asset, "uri="));
        }

        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        getService().add(tenantId, getPrefix(),
            assetGroupAssociationsList.stream().distinct().toArray(AssetGroupAssociation[]::new),
            AssetGroupAssociation.class);
    }

    /**
     * Function to associate list of assets to a group.
     *
     * @param associations Map
     * @param groupUri String
     */
    public void associateGroupToAssets(Map<String, Object> associations, String groupUri) {

        Group assetGroup;
        try {
            final ICrudController groupController = controllerFactory.getController(Prefixes.Groups);
            assetGroup = (Group) groupController.getSingle(groupUri.split("/")[2], AssetComponentResolver.BASIC);
        } catch (ArrayIndexOutOfBoundsException | AssertionError assertionError) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_GROUP_URI), groupUri);
        }

        if (assetGroup == null) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_GROUP_URI), groupUri);
        }
        Map<String, List> mappedAssetRefs = (Map<String, List>) associations.get("assets");
        ArrayList assetSourceKeys = (ArrayList) mappedAssetRefs.get("sourceKeys");
        ArrayList assetUris = (ArrayList) mappedAssetRefs.get("uris");

        List<AssetGroupAssociation> assetGroupAssociationsList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(assetSourceKeys)) {
            assetSourceKeys.forEach(assetSourceKey -> {
                assetGroupAssociationsList.addAll(findObjectsBySourceKey((LinkedHashMap) assetSourceKey, assetGroup));
            });
        }
        if (!CollectionUtils.isEmpty(assetUris)) {
            assetGroupAssociationsList.addAll(findObjectsByUri(assetUris, assetGroup));
        }

        String tenantId = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        getService().add(tenantId, getPrefix(),
            assetGroupAssociationsList.stream().distinct().toArray(AssetGroupAssociation[]::new),
            AssetGroupAssociation.class);
    }

    private ArrayList<String> removeDuplicates(ArrayList<String> list) {
        Set<String> hs = new HashSet<>(list);
        list.clear();
        list.addAll(hs);
        return list;
    }

    /**
     * find all asset objects for the given source keys.
     *
     * @param assetSourceKey LinkedHashMap
     * @param assetGroup Group
     *
     * @return List
     */
    private List<AssetGroupAssociation> findObjectsBySourceKey(LinkedHashMap assetSourceKey, Group assetGroup) {
        String prefix = (String) assetSourceKey.get("type");
        ArrayList<String> assetSourceKeys = (ArrayList<String>) assetSourceKey.get("sourceKeys");

        List<AssetGroupAssociation> assetGroupAssociations = new ArrayList<>();
        final String keyValue = "sourceKey=";
        if (!StringUtils.isEmpty(prefix) && !CollectionUtils.isEmpty(assetSourceKeys)) {

            assetSourceKeys = removeDuplicates(assetSourceKeys);

            String query = assetSourceKeys.stream().map(Object::toString).collect(Collectors.joining("|" + keyValue));
            Attributable[] associatedObjects;
            try {
                final ISearchController controller = controllerFactory.getSearchController(prefix);
                associatedObjects = controller.query(keyValue + query, AssetComponentResolver.BASIC, 250, null, null);
            } catch (AssertionError assertionError) {
                throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_TYPE_SOURCE_KEY), prefix);
            }

            // If it's not matching, then it couldn't find an object for one/more of the sourceKey
            if (associatedObjects != null && assetSourceKeys.size() != associatedObjects.length) {
                throw new BadRequestException(ErrorProvider.findError(ErrorConstants.SOURCE_KEYS_MISMATCH));
            }
            checkIfAssociationIsHappeningWithDecommissionedAssets(associatedObjects);
            validateAssociations(associatedObjects, assetGroup);
            assetGroupAssociations = Arrays.stream(associatedObjects).map(
                attributable -> createAssetGroupAssociationDto(attributable, assetGroup)).collect(Collectors.toList());
        }
        return assetGroupAssociations;
    }

    private void checkIfAssociationIsHappeningWithDecommissionedAssets(Attributable... attributables) {
        Arrays.stream(attributables).forEach(attributable -> {
            if (assetRestrictionFeaturesEnabled && attributable != null && Prefixes.Assets.compareTo(
                Prefixes.prefixFromUri(attributable.getUri())) == 0) {
                if (AssetStateManagerUtil.isDecommissioned(attributable)) {
                    throw new BadRequestException(
                        ErrorProvider.findError(ErrorConstants.REFERENCING_DECOMMISSIONED_ASSET_IS_NOT_ALLOWED));
                }
            }
        });
    }

    /**
     * Retrieve all asset objects for the given asset URIs.
     *
     * @param assetUris ArrayList
     * @param assetGroup Group
     *
     * @return List
     */
    private List<AssetGroupAssociation> findObjectsByUri(ArrayList<String> assetUris, Group assetGroup) {
        Set<String> enterpriseUrisToGet = new HashSet<>();
        Set<String> siteUrisToGet = new HashSet<>();
        Set<String> segmentUrisToGet = new HashSet<>();
        Set<String> assetUrisToGet = new HashSet<>();

        assetUris = removeDuplicates(assetUris);

        categorizeAssetUris(assetUris, enterpriseUrisToGet, siteUrisToGet, segmentUrisToGet, assetUrisToGet);
        final String keyValue = "uri=";

        List<AssetGroupAssociation> assetGroupAssociations = new ArrayList<>();
        if (!CollectionUtils.isEmpty(enterpriseUrisToGet)) {
            final ISearchController controller = controllerFactory.getSearchController(Prefixes.Enterprises);
            Attributable[] enterpriseObjects = controller.query(
                keyValue + enterpriseUrisToGet.stream().collect(Collectors.joining("|" + keyValue)),
                AssetComponentResolver.BASIC, 250, null, null);
            validateAssociations(enterpriseObjects, assetGroup);
            assetGroupAssociations.addAll(Arrays.stream(enterpriseObjects)
                .map(attributable -> createAssetGroupAssociationDto(attributable, assetGroup))
                .collect(Collectors.toList()));
        }

        if (!CollectionUtils.isEmpty(siteUrisToGet)) {
            final ISearchController controller = controllerFactory.getSearchController(Prefixes.Sites);
            Attributable[] siteObjects = controller.query(
                keyValue + siteUrisToGet.stream().collect(Collectors.joining("|" + keyValue)),
                AssetComponentResolver.BASIC, 250, null, null);
            validateAssociations(siteObjects, assetGroup);
            assetGroupAssociations.addAll(Arrays.stream(siteObjects)
                .map(attributable -> createAssetGroupAssociationDto(attributable, assetGroup))
                .collect(Collectors.toList()));
        }

        if (!CollectionUtils.isEmpty(segmentUrisToGet)) {
            final ISearchController controller = controllerFactory.getSearchController(Prefixes.Segments);
            Attributable[] segmentObjects = controller.query(
                keyValue + segmentUrisToGet.stream().collect(Collectors.joining("|" + keyValue)),
                AssetComponentResolver.BASIC, 250, null, null);
            validateAssociations(segmentObjects, assetGroup);
            assetGroupAssociations.addAll(Arrays.stream(segmentObjects)
                .map(attributable -> createAssetGroupAssociationDto(attributable, assetGroup))
                .collect(Collectors.toList()));
        }

        if (!CollectionUtils.isEmpty(assetUrisToGet)) {
            final ISearchController controller = controllerFactory.getSearchController(Prefixes.Assets);
            Attributable[] assetObjects = controller.query(
                keyValue + assetUrisToGet.stream().collect(Collectors.joining("|" + keyValue)),
                AssetComponentResolver.BASIC, 250, null, null);
            checkIfAssociationIsHappeningWithDecommissionedAssets(assetObjects);
            validateAssociations(assetObjects, assetGroup);
            assetGroupAssociations.addAll(Arrays.stream(assetObjects)
                .map(attributable -> createAssetGroupAssociationDto(attributable, assetGroup))
                .collect(Collectors.toList()));
        }

        // If it's not matching, then it couldn't find an object for one/more of the URI
        if (assetUris.size() != assetGroupAssociations.size()) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.URI_MISMATCH));
        }

        return assetGroupAssociations;
    }

    /**
     * Validate all asset objects can be associated to group.
     *
     * @param associateObjects Attributable[]
     * @param assetGroup Group
     */
    //TODO - Why do we need to do this validation
    private void validateAssociations(Attributable[] associateObjects, Group assetGroup) {
        List<String> allowedBusinessHierarchy = getAllowedBusinessHierarchy(assetGroup);
        if (!Arrays.stream(associateObjects).allMatch(
            associatedObject -> allowedBusinessHierarchy.contains(Prefixes.prefixFromUri(associatedObject.getUri())))) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_ASSET_GROUP),
                assetGroup.getUri(), String.join(",", allowedBusinessHierarchy), assetGroup.getCategory(),
                assetGroup.getCategory());
        }
    }

    private void categorizeAssetUris(ArrayList<String> uris, Set<String> enterpriseUris, Set<String> siteUris,
        Set<String> segmentUris, Set<String> assetUris) {
        for (String assetUri : uris) {
            switch (Prefixes.prefixFromUri(assetUri)) {
                case Prefixes.Enterprises:
                    enterpriseUris.add(assetUri);
                    break;
                case Prefixes.Sites:
                    siteUris.add(assetUri);
                    break;
                case Prefixes.Segments:
                    segmentUris.add(assetUri);
                    break;
                case Prefixes.Assets:
                    assetUris.add(assetUri);
                    break;
                default:
                    throw new IllegalStateException("Invalid Prefix of URI:" + assetUri);
            }
        }
    }

    /**
     * Function to find list of groups for the given assetGroupSourceKeys / assetGroupUris.
     *
     * @param group List
     * @param assetObject Attributable
     * @param keyValue String
     *
     * @return List
     */
    private List<AssetGroupAssociation> findGroups(List<String> group, Attributable assetObject, String keyValue) {
        final ISearchController controller = controllerFactory.getSearchController(Prefixes.Groups);
        Group[] groupObjects = (Group[]) controller.query(
            keyValue + group.stream().collect(Collectors.joining("|" + keyValue)), AssetComponentResolver.BASIC, 250,
            null, null);

        // If it's not matching, then it couldn't find an object for one/more of the sourceKey
        if (group.size() != groupObjects.length) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.SOURCE_KEYS_URIS_MISMATCH));
        }

        List<String> allowedGroupCategory = getAllowedGroupCategory(assetObject);
        if (!Arrays.stream(groupObjects).allMatch(
            groupObject -> allowedGroupCategory.contains(groupObject.getCategory()))) {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_GROUP_ASSET),
                assetObject.getUri(), String.join(",", allowedGroupCategory), assetObject.getUri(),
                assetObject.getUri());
        }
        return Arrays.stream(groupObjects).map(groupObject -> createAssetGroupAssociationDto(assetObject, groupObject))
            .collect(Collectors.toList());
    }

    /**
     * function to create Group Association DTO.
     *
     * @param associatedObject Attributable
     * @param assetGroup Group
     *
     * @return AssetGroupAssociation
     */
    private AssetGroupAssociation createAssetGroupAssociationDto(Attributable associatedObject, Group assetGroup) {
        AssetGroupAssociation assetGroupAssociation = new AssetGroupAssociation();
        assetGroupAssociation.setGroupId(assetGroup.getUri().split("/")[2]);
        assetGroupAssociation.setObjectId(associatedObject.getUri().split("/")[2]);
        // ID of AssetGroupAssociation object will be generated based on sourceKey. If sourceKey is not passed, then
        // it will generate same ID for all objects
        assetGroupAssociation.setSourceKey(associatedObject.getSourceKey() + assetGroup.getSourceKey());
        return assetGroupAssociation;
    }

    /**
     * Return possible Group categories can associate to the given Asset object.
     *
     * @param assetObject Attributable
     *
     * @return List
     */
    private List<String> getAllowedGroupCategory(Attributable assetObject) {
        List<String> possibleGroupCategory = new ArrayList<>();
        switch (Prefixes.prefixFromUri(assetObject.getUri())) {
            case Prefixes.Assets:
            case Prefixes.Segments:
                possibleGroupCategory.add(Category.TAG.name());
                possibleGroupCategory.add(Category.ASSET.name());
                break;
            case Prefixes.Sites:
                possibleGroupCategory.add(Category.TAG.name());
                possibleGroupCategory.add(Category.ASSET.name());
                possibleGroupCategory.add(Category.SEGMENT.name());
                break;
            case Prefixes.Enterprises:
                possibleGroupCategory.add(Category.TAG.name());
                possibleGroupCategory.add(Category.ASSET.name());
                possibleGroupCategory.add(Category.SEGMENT.name());
                possibleGroupCategory.add(Category.SITE.name());
                break;
            default:
                throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_BOH_ASSOCIATION),
                    assetObject.getUri());
        }
        return possibleGroupCategory;
    }

    /**
     * Return Possible Business Hierarchy objects for the given group category.
     *
     * @param assetGroup Group
     *
     * @return List
     */
    private List<String> getAllowedBusinessHierarchy(Group assetGroup) {
        List<String> possibleBusinessObjects = new ArrayList<>();
        switch (Category.valueOf(assetGroup.getCategory())) {
            case TAG:
            case ASSET:
                possibleBusinessObjects.add(Prefixes.Assets);
                possibleBusinessObjects.add(Prefixes.Segments);
                possibleBusinessObjects.add(Prefixes.Sites);
                possibleBusinessObjects.add(Prefixes.Enterprises);
                break;
            case SEGMENT:
                possibleBusinessObjects.add(Prefixes.Sites);
                possibleBusinessObjects.add(Prefixes.Enterprises);
                break;
            case SITE:
                possibleBusinessObjects.add(Prefixes.Enterprises);
                break;
            default:
                throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_GROUP_ASSOCIATION),
                    assetGroup.getCategory());
        }
        return possibleBusinessObjects;
    }

    private enum Category {
        ENTERPRISE,
        SITE,
        SEGMENT,
        ASSET,
        TAG
    }
}
