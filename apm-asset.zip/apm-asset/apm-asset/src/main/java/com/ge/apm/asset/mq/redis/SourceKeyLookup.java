/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.redis;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.asset.mq.factory.ControllerFactory;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.AssetError;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

@Slf4j
@Component
public class SourceKeyLookup {

    @Autowired
    ControllerFactory controllerFactory;

    public String lookupObjectUriFor(String tenantId, String srcKeyWithPrefix) {
        if (!srcKeyWithPrefix.contains("/")) {
            throw new ServiceException(ErrorProvider.findError(ErrorConstants.BAD_REQUEST_SRCKEY_PREFIX));
        }
        String prefix = StringUtils.substringBeforeLast(srcKeyWithPrefix, "/");
        String sourceKey = StringUtils.substringAfterLast(srcKeyWithPrefix, "/");
        return getUri(tenantId, prefix, sourceKey);
    }

    public String lookupObjectUriFor(String tenantId, String prefix, String sourceKey) {
        return getUri(tenantId, prefix, sourceKey);
    }

    public String getUri(String tenantId, String prefix, String sourceKey) {
        String uri;
        try {
            uri = controllerFactory.getSourceController(prefix).getBySourceKey(sourceKey).getUri();
        } catch (NotFoundException se) { //NOSONAR
            log.error("No data found for uri: {} and sourceKey {}", prefix, sourceKey);
            AssetError assetError = ErrorProvider.findError(ErrorConstants.LOOKUP_BY_SOURCE_KEY);
            throw new DependencyViolationException(assetError, prefix, sourceKey);
        }
        return uri;
    }
}
