/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.util.Arrays;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.common.exception.IErrorCode;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.util.JsonBuilder;
import com.ge.asset.commons.errorprovider.AssetError;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.exception.AssetServiceException;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Created by 212448111 on 2/17/17.
 */
@Component
@Slf4j
public class TaskExceptionProcessor implements Processor {

    private static final String DownloadOperation = "download";

    private static Response createErrorResponse(Object data) {
        Response.ResponseBuilder responseBuilder = Response.status(Status.INTERNAL_SERVER_ERROR);
        responseBuilder.entity(JsonBuilder.toNullExcludedJson(data));
        responseBuilder.type(MediaType.APPLICATION_JSON);
        return responseBuilder.build();
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        Throwable throwable = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
        Object operationType = exchange.getIn().getHeader(MessageConstants.OPERATION_NAME);
        if (throwable != null) {
            Throwable exception;
            try {
                throw throwable;
            } catch (DependencyViolationException dve) {
                log.error(dve.getMessage());
                exception = new AssetServiceException(dve.getMessage());
                ((AssetServiceException) exception).setErrors(dve.getErrors());
            } catch (AssetServiceException ase) {
                exception = ase;
            } catch (ServiceException se) {
                log.error(se.getMessage());
                AssetError ae = ErrorProvider.findError(se.getCode());
                if (StringUtils.isEmpty(se.getCode())) {
                    ae = ErrorProvider.findError(ErrorConstants.SYSTEM_ERROR);
                }
                ae.setMsg(se.getMessage());
                AssetServiceException assetServiceException = new AssetServiceException(se.getMessage());
                assetServiceException.setErrors(Arrays.asList(ae));
                assetServiceException.setStackTrace(se.getStackTrace());
                exception = assetServiceException;
            } catch (ValidationFailedException vfe) {
                exception = vfe;
            } catch (Throwable ex) { //NOSONAR - To persist even errors we need Throwable
                log.error(ex.getMessage());
                if (operationType != null && operationType.toString().equals(DownloadOperation)) {
                    IErrorCode errorCode = ErrorProvider.findError(ErrorConstants.DOWNLOAD_ERROR);
                    exception = new ServiceException(errorCode,
                        ex.getMessage() != null ? ex.getMessage() : "");

                } else {
                    IErrorCode errorCode = ErrorProvider.findError(ErrorConstants.SYSTEM_ERROR);
                    exception = new ServiceException(errorCode,
                        ex.getMessage() != null ? ex.getMessage() : "");
                }
            }
            exchange.getOut().setBody(exception, Throwable.class);
        }
        exchange.getOut().setHeaders(exchange.getIn().getHeaders());
    }

    public void rabbitmqException(Exchange exchange) {
        exchange.getOut().setHeaders(exchange.getIn().getHeaders());
        Throwable caused = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
        if (caused != null) {
            AssetError assetError = ErrorProvider.findError(ErrorConstants.RABBITMQ_ERROR);
            exchange.getOut().setBody(createErrorResponse(assetError));
        }
    }
}
