/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.redis;

import java.io.Serializable;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.stereotype.Component;

import com.ge.asset.commons.mq.constants.MessageConstants;

/**
 * The component helps in re-queueing the messages in RMQ while retry of a task in progress. It prevents the parellel
 * processing of the same message by multiple instances of the application. This lookup component is used to store task
 * info once a message is received from RMQ and processing starts. While the processing or retry processing is in
 * progress, the task status remains in IN_PROGRESS. Once the the message processing is complete, the task is evicted
 * from redis cache.
 *
 * @author 212448111
 * @since 4/4/17
 */
@Slf4j
@Component
@CacheConfig(cacheNames = "ApmIngestionStatusCache", cacheManager = "cacheManager")
public class TaskStatusLookup {

    private static final String INGESTION_STATUS_CACHE = "ApmIngestionStatusCache";

    private static final String INGESTION_TASK_STATUS_DONE = "DONE";

    private static final String INGESTION_TASK_STATUS_IN_PROGRESS = "IN_PROGRESS";

    @Autowired
    CacheManager cacheManager;

    @Value("${message.maximum.redeliveries:5}")
    private Integer maxRetryCount;

    @Value("${message.redelivery.delay:5000}")
    private Long messageRedeliveryDelay;

    @Value("${message.processing.time.buffer:3600000}")
    private Long taskProcessingTimeBuffer;

    public boolean isTaskDone(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        TaskInfo taskInfo = getTaskInfoFromCache(taskId);
        boolean isRedeliveredTask = exchange.getIn().getHeaders().containsKey(MessageConstants.TASK_STARTTIME);
        if (taskInfo == null && isRedeliveredTask) {
            log.info("Task {} is DONE: redis down and redelivered", taskId);
            return true;
        }
        boolean status = (taskInfo != null && taskInfo.getTaskStatus() != null && taskInfo.getTaskStatus().equals(
            INGESTION_TASK_STATUS_DONE));
        log.info("Task {} is DONE: {}", taskId, status);
        return status;
    }

    public boolean isTaskInProgress(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        TaskInfo taskInfo = getTaskInfoFromCache(taskId);
        boolean status = (taskInfo != null && taskInfo.getTaskStatus() != null && taskInfo.getTaskStatus().equals(
            INGESTION_TASK_STATUS_IN_PROGRESS));
        log.trace("Task {} is IN PROGRESS: {}", taskId, status);
        return status;
    }

    public void markTaskDone(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        if (getTaskInfoFromCache(taskId) != null) {
            log.info("Mark task {} as DONE", taskId);
            putTaskInfoInCache(taskId, new TaskInfo(taskId, INGESTION_TASK_STATUS_DONE, System.currentTimeMillis()));
        }
    }

    public void markTaskInProgress(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        log.info("Mark task {} as IN PROGRESS", taskId);
        putTaskInfoInCache(taskId, new TaskInfo(taskId, INGESTION_TASK_STATUS_IN_PROGRESS, System.currentTimeMillis()));
    }

    /**
     * Checks if a task in cache for more that a certain time(redeliveryDelay + time taken to process task), then the
     * the task is considered as stale. It becomes a candidate for reprocessing. It can happen if task retry thread was
     * dead before it got chance to evict this key from cache.
     *
     * @param exchange - The camel exchange.
     *
     * @return true if its stale.
     */
    public boolean isTaskStale(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        TaskInfo taskInfo = getTaskInfoFromCache(taskId);
        if (taskInfo != null) {
            Long startTime = taskInfo.getLastUpdatedTime();
            if (startTime != null) {
                Long timeOut = messageRedeliveryDelay + taskProcessingTimeBuffer;
                if ((System.currentTimeMillis() - startTime) > timeOut) {
                    log.info("Task {} is in STALE. Reprocessing required.", taskId);
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Evicts the task from cache.
     *
     * @param exchange - The camel exchange
     */
    public void disposeTask(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        log.info("Task {} is in DONE. Clearing out", taskId);
        evictTaskInfoInCache(taskId);
    }

    private TaskInfo getTaskInfoFromCache(String taskId) {
        try {
            return cacheManager.getCache(INGESTION_STATUS_CACHE).get(taskId, TaskInfo.class);
        } catch (Exception ex) { //NOSONAR
            log.warn("Failed to GET from ingestion cache! - {}", taskId);
            return null;
        }
    }

    private void putTaskInfoInCache(String taskId, TaskInfo taskInfo) {
        try {
            cacheManager.getCache(INGESTION_STATUS_CACHE).put(taskId, taskInfo);
        } catch (Exception ex) { //NOSONAR
            log.warn("Failed to PUT into ingestion cache! - {}", taskId);
        }
    }

    private void evictTaskInfoInCache(String taskId) {
        try {
            cacheManager.getCache(INGESTION_STATUS_CACHE).evict(taskId);
        } catch (Exception ex) { //NOSONAR
            log.warn("Failed to EVICT from ingestion cache! - {}", taskId);
        }
    }

    /**
     * The class that represents the Task which get stored in cache.
     */
    public static class TaskInfo implements Serializable {

        private String taskUuid;

        private String taskStatus;

        private Long lastUpdatedTime;

        public TaskInfo() {

        }

        public TaskInfo(String taskUuid, String taskStatus, Long lastUpdatedTime) {
            this.taskUuid = taskUuid;
            this.taskStatus = taskStatus;
            this.lastUpdatedTime = lastUpdatedTime;
        }

        public Long getLastUpdatedTime() {
            return lastUpdatedTime;
        }

        public String getTaskUuid() {
            return taskUuid;
        }

        public String getTaskStatus() {
            return taskStatus;
        }
    }
}
