/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.FilterInvocation;
import org.springframework.stereotype.Controller;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.controller.base.ISearchController;
import com.ge.apm.asset.controller.base.ISourceKeyController;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.Type;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAlmPersistenceService;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.stuf.security.spring.extensions.acs.AcsClient;

@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.MeasurementTags, IBasePath.v3 + Prefixes.MeasurementTags })
public class MeasurementTagController extends AbstractController<MeasurementTag, IAssetService>
    implements ISourceKeyController<MeasurementTag, IAssetService>, ISearchController<MeasurementTag, IAssetService> {

    @Autowired
    AcsClient acsClient;

    public MeasurementTagController() {
        super(Prefixes.MeasurementTags, Prefixes.MeasurementTagTypes, MeasurementTag.class);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/reservedAttributes")
    @ResponseBody
    public Map<String, ReservedAttributeConfig> reservedAttributes(@RequestParam(required = false) String typeUri) {
        Type tagType = null;
        if (!StringUtils.isEmpty(typeUri)) {
            tagType = getService().getType(typeUri, MeasurementTag.class,
                AssetComponentResolver.getParentComponents(new ArrayList<>()));
        }
        return this.getReservedAttributes(tagType);
    }

    private MeasurementTag[] getTagDetailsApplyingAccessibleResFilter(Authentication authentication,
        String tagSourceKeysCommaSeparated) {
        //Get the accessibleResources from the RequestContext which was set in
        // AccessibleResourcesFilter.
        String[] accessibleResourceUris = RequestContext.get(IAlmPersistenceService.ACCESSIBLE_RESOURCES, String[].class);
        String tenantUuid = RequestContext.get(RequestContext.TENANT_UUID, String.class);
        MeasurementTag[] tags = null;
        if (accessibleResourceUris == null) {
            //If the accessibleResources are NULL then the user doesn't have access any object.
            tags = new MeasurementTag[0];
        } else {
            Set<String> tagSourceKeys = Arrays.stream(tagSourceKeysCommaSeparated.split(",")).collect(
                Collectors.toSet());
            Map<String, Object> contextObjects = RequestContext.copy();
            tags = getService().getBySourceKeys(getPrefix(), MeasurementTag.class,
                tagSourceKeysCommaSeparated.split(","));
            /*
            tags = getAssetTagService().getBySourceKeys(tenantUuid,
                    tagSourceKeys.toArray(new String[tagSourceKeys.size()]));
                    */
            if (!(accessibleResourceUris.length == 1 && accessibleResourceUris[0].equals(
                IAlmPersistenceService.ALL_RESOURCES[0]))) {
                Map<String, List<MeasurementTag>> monitoredEntityVsTagsMap = new HashMap<>();
                Arrays.asList(tags).stream().forEach(tag -> {
                    List<MeasurementTag> tagList = null;
                    if (monitoredEntityVsTagsMap.containsKey(tag.getMonitoredEntityUri())) {
                        tagList = monitoredEntityVsTagsMap.get(tag.getMonitoredEntityUri());
                    } else {
                        tagList = new ArrayList<MeasurementTag>();
                    }
                    tagList.add(tag);
                    monitoredEntityVsTagsMap.put(tag.getMonitoredEntityUri(), tagList);
                });
                //The user has access only to selected objects.
                //Search the tag by tagIdentifier which is sourceKey in internal representation.
                Iterator<String> monitoredEntityUriIter = monitoredEntityVsTagsMap.keySet().iterator();
                while (monitoredEntityUriIter.hasNext()) {
                    String monitoredEntityUri = monitoredEntityUriIter.next();
                    //Construct the FilterInvocation needed for the STUF api to check access.
                    MockHttpServletRequest mockHttpServletRequest = new MockHttpServletRequest();
                    mockHttpServletRequest.setRequestURI("/v1" + monitoredEntityUri);
                    mockHttpServletRequest.setMethod("GET");
                    MockHttpServletResponse mockHttpServletResponse = new MockHttpServletResponse();
                    MockFilterChain chain = new MockFilterChain();
                    FilterInvocation filterInvocation = new FilterInvocation(mockHttpServletRequest,
                        mockHttpServletResponse, chain);
                    if (!acsClient.isAcsAuthorized(authentication, filterInvocation)) {
                        monitoredEntityUriIter.remove();
                    }
                }
                List<MeasurementTag> tagsList = new ArrayList<>();
                monitoredEntityVsTagsMap.forEach((asset, measurementTags) -> {
                    tagsList.addAll(measurementTags);
                });
                tags = tagsList.toArray(new MeasurementTag[tagsList.size()]);
            }
        }
        return tags;
    }

    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public MeasurementTag[] getByCriteria(Authentication authentication,
        @RequestParam(value = "sourceKeys", required = false) String tagSourceKeysCommaSeparated,
        @RequestParam(required = false) String groupSourceKey) {
        MeasurementTag[] tagsToReturn = null;
        if (!StringUtils.isEmpty(tagSourceKeysCommaSeparated)) {
            tagsToReturn = getTagDetailsApplyingAccessibleResFilter(authentication, tagSourceKeysCommaSeparated);
        } else if (!StringUtils.isEmpty(groupSourceKey)) {
            try {

                Group group = getService().getSingleBySourceKey(Prefixes.Groups, Group.class, groupSourceKey);
                // Group group = getService().getSingle(Prefixes.Groups, Group.class,
                //         AssetComponentResolver.getBasicComponents(),
                //         attribute(Base.SourceKey).eq(groupSourceKey),
                //         queryPredicate);

                // getSingle() call returns 206 with next page link, but there won't be more data
                // . so, remove next
                // page link from request context to avoid 206 in response headers
                if (RequestContext.contains(RequestContext.NEXT_PAGE_LINK)) {
                    RequestContext.remove(RequestContext.NEXT_PAGE_LINK);
                }
                tagsToReturn = getMembersByGroupUri(group.getUri(), getPrefix(),
                    ICrudController.GroupCategory.getEnum(group.getCategory()));
            } catch (Exception ex) {
                getLogger().error("[getByCriteria]", ex);
                throw ExceptionUtil.wrapException(ex, ErrorProvider.findError(ErrorConstants.GET_BY_CRITERIA),
                    getPrefix());
            }
        } else {
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.SRCKEY_GPKEY_QUERY_PARAM));
        }
        return tagsToReturn;
    }
}
