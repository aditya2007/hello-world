/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ge.apm.common.filter", "com.ge.apm.asset", "com.ge.stuf",
    "com.ge.asset.commons", "org.apache.camel.spring.boot", "com.ge.apm.alm",
    "com.ge.apm.alm.persistence.aspect.mirror", "com.ge.apm.service", "com.ge.apm.properties", "com.ge.apm.tenants",
    "com.ge.apm.rest.config", "com.ge.apm.common.config", "com.ge.apm.alm.services.impl", "com.ge.apm.datasource",
    "com.ge.apm.commons.logging", "com.ge.apm.blob.client", "com.ge.apm.blob.factory", "com.ge.apm.blob.repository",
    "com.ge.apm.rest", "com.ge.apm.service"})
@ImportResource({ "classpath:security-config.xml"})
public class Application extends SpringBootServletInitializer {

    public static void main(String[] args) {
        new SpringApplicationBuilder(Application.class)
            //.environment(CloudFoundryVcapEnvironmentPostProcessor.class)
            .run(args);
    }
}
