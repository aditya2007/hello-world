/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ge.apm.asset.controller.EquipmentInstanceController;
import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.AssetPlaceholderConnection;
import com.ge.apm.asset.model.EquipmentInstanceConnection;
import com.ge.apm.asset.model.EquipmentInstanceConnection.Category;
import com.ge.apm.asset.model.Placeholder;
import com.ge.apm.asset.model.PlaceholderAssetTypeAssociation;
import com.ge.apm.asset.model.Template;
import com.ge.apm.asset.model.TemplateInfo;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.config.MqAuthConfig;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.asset.mq.factory.ControllerFactory;
import com.ge.apm.asset.mq.predicate.RetryPolicyPredicate;
import com.ge.apm.asset.mq.redis.SourceKeyLookup;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.json.patch.AddOperation;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.json.patch.RemoveOperation;
import com.ge.asset.commons.errorprovider.AssetError;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.exception.AssetServiceException;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;
import com.ge.asset.commons.validator.ValidationResult;

@Component
@Slf4j
public class TemplateConnectionProcessor implements Processor {

    private static final String VALIDATION_RESULT = "validationResultTemplate";

    private static final String ERRORS = "errorsTemplate";

    private static final String ERROR_COUNT = "errorCount";

    private static final String DVE_COUNT = "dveCount";

    private static final String PREVIOUS_ERROR_COUNT = "previousErrorCount";

    protected static final String STR_TRACEID = "X-B3-TraceId";

    protected static final String STR_SUBJECT = "subject";

    public static final String ASSET_PLACEHOLDERS_PATCH_PATH = "/placeholders/";

    private enum EquipmentInstanceOperation {
        CREATE,
        UPDATE,
        REMOVE
    }

    @Autowired
    ControllerFactory controllerFactory;

    @Autowired
    EquipmentInstanceController equipmentInstanceController;

    @Autowired
    DtoProcessor dtoProcessor;

    @Autowired
    MqAuthConfig mqAuthConfig;

    @Autowired
    RetryPolicyPredicate retryPolicyPredicate;

    @Autowired
    private SourceKeyLookup sourceKeyLookup;

    public final void dispatch(Exchange exchange) throws Exception {

        if (exchange.getProperty(MessageConstants.TEMP_CONN_TASK_RETRY_DTOS) != null) {
            exchange.getIn().setBody(exchange.getProperty(MessageConstants.TEMP_CONN_TASK_RETRY_DTOS));
        }
        EquipmentInstanceConnection[] dtos
            = exchange.getIn().getBody(EquipmentInstanceConnection[].class);
        EquipmentInstanceConnection[] copy
            = (EquipmentInstanceConnection[]) org.apache.commons.lang.SerializationUtils.clone(
            Arrays.asList(dtos).toArray((EquipmentInstanceConnection[])
                Array.newInstance(dtos[0].getClass(), dtos.length)));
        exchange.getOut().setBody(copy);
        try {
            this.preProcess(exchange);
            this.process(exchange);
            this.postProcess(exchange);
        } catch (Exception exception) {
            throw exception;
        } finally {
            exchange.getIn().getHeaders()
                .put(MessageConstants.ASSET_PREFIX, Prefixes.TemplateConnections);
            exchange.setProperty(MessageConstants.TEMP_CONN_TASK_RETRY_DTOS,
                exchange.getOut().getBody());
            exchange.getOut().setHeaders(exchange.getIn().getHeaders());
            int completedEntities = getCompletedEntities(exchange, copy);
            exchange.getOut().setHeader(MessageConstants.TASK_ENTITY_COMPLETE, completedEntities);
        }
        exchange.getOut().setHeader(MessageConstants.TASK_ENTITY_COMPLETE,
            exchange.getIn().getHeader(MessageConstants.TASK_ENTITY_TOTAL));
    }

    private int getCompletedEntities(Exchange exchange, EquipmentInstanceConnection[] copy) {
        int totalEntities = (int) exchange.getIn().getHeader(MessageConstants.TASK_ENTITY_TOTAL);

        int errorCount = exchange.getProperty(getPropertyName(exchange, ERROR_COUNT)) == null
            ? 0 : (int) exchange.getProperty(getPropertyName(exchange, ERROR_COUNT));
        int dveCount = exchange.getProperty(getPropertyName(exchange, DVE_COUNT)) == null
            ? 0 : (int) exchange.getProperty(getPropertyName(exchange, DVE_COUNT));
        int previousErrorCount = exchange.getIn().getHeader(getPropertyName(exchange, PREVIOUS_ERROR_COUNT)) == null
            ? 0 : (int)
                exchange.getIn().getHeader(getPropertyName(exchange, PREVIOUS_ERROR_COUNT));

        int completedEntities = totalEntities - (errorCount + dveCount + previousErrorCount);

        exchange.getIn().setHeader(getPropertyName(exchange, PREVIOUS_ERROR_COUNT),
            (errorCount + previousErrorCount));

        return completedEntities;
    }

    public void preProcess(Exchange exchange) {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        String authorization = messageHeaders.get(MessageConstants.AUTHORIZATION).toString();

        String task = messageHeaders.get(MessageConstants.TASK_UUID).toString();
        String traceUuid = messageHeaders.get(MessageConstants.TRACE_UUID).toString();
        MDC.put(STR_TRACEID, traceUuid);
        MDC.put(STR_SUBJECT, task);

        mqAuthConfig.configure(tenantUuid, authorization, Prefixes.Templates, RequestMethod.GET);
        mqAuthConfig.configure(tenantUuid, authorization, Prefixes.Assets, RequestMethod.GET);
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        EquipmentInstanceConnection[] dtos =
            exchange.getIn().getBody(EquipmentInstanceConnection[].class);
        EquipmentInstanceConnection[] preservedDtos =
            exchange.getOut().getBody(EquipmentInstanceConnection[].class);

        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();

        List<EquipmentInstanceConnection> dveList = new ArrayList<>();
        List<DependencyViolationException> violationExceptions = new ArrayList<>();
        List<Throwable> exceptions = new ArrayList<>();

        for (EquipmentInstanceConnection dto : dtos) {
            try {
                /* Check if -
                ** 1. Template exists in the system for which equipment instance is being created
                ** 2. All asset instances mapped to placeholders exist in the system
                ** 3. Parent of the root asset instance exists in the system
                **
                **  if any of above 3 doesn't exist then not throw DependencyViolationException
                */
                String templateUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid,
                    Prefixes.Templates, dto.getTemplateSourceKey());
                if (templateUri == null) {
                    AssetError assetError = ErrorProvider.findError(ErrorConstants.LOOKUP_BY_SOURCE_KEY);
                    throw new DependencyViolationException(assetError, Prefixes.Templates, dto.getTemplateSourceKey());
                }

                if (dto.getParentEntitySrcKey() != null && dto.getParentEntityCategory() != null) {
                    String parentEntityPrefix =
                        Prefixes.getPrefixByCategory(dto.getParentEntityCategory().name());
                    String parentEntityUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid,
                        parentEntityPrefix, dto.getParentEntitySrcKey());
                    if (parentEntityUri == null) {
                        AssetError assetError = ErrorProvider.findError(ErrorConstants.LOOKUP_BY_SOURCE_KEY);
                        throw new DependencyViolationException(assetError, parentEntityPrefix,
                            dto.getParentEntitySrcKey());
                    } else if (parentEntityUri != null && dto.getParentEntityCategory() != null
                        && dto.getParentEntityCategory().equals(Category.ASSET)) {
                        Asset rootAsset = (Asset) controllerFactory.getController(Prefixes.Assets)
                            .getSingle(StringUtils.substringAfterLast(parentEntityUri, "/"),
                                AssetComponentResolver.BASIC);
                        // retry if the component is still connected with an equipment instance
                        if (rootAsset.getTemplateInfo() != null
                            && rootAsset.getTemplateInfo().getEmbeddedTemplateUri() != null) {
                            AssetError assetError = ErrorProvider.findError(ErrorConstants.INVALID_UPDATE_ON_COMPONENT);
                            throw new DependencyViolationException(assetError, parentEntityPrefix,
                                dto.getParentEntitySrcKey());
                        }
                    }

                }

                Template template = (Template) controllerFactory.getController(Prefixes.Templates)
                    .getSingle(StringUtils.substringAfterLast(templateUri, "/"),
                        AssetComponentResolver.FULL);
                List<String> placeholderIds = new ArrayList<>();
                this.populatePlaceholdersWithSubTemplate(template.getPlaceholders(), placeholderIds);

                dto.getConnections().forEach(assetConn -> {
                    if (!StringUtils.isEmpty(assetConn.getAssetSourceKey())) {
                        String assetUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid, Prefixes.Assets, assetConn
                            .getAssetSourceKey());
                        if (assetUri == null) {
                            AssetError assetError = ErrorProvider.findError(ErrorConstants.LOOKUP_BY_SOURCE_KEY);
                            throw new DependencyViolationException(assetError, Prefixes.Assets, assetConn.getAssetSourceKey());
                        }

                        if (!CollectionUtils.isEmpty(placeholderIds)
                            && placeholderIds.contains(assetConn.getPlaceholderId())) {
                            Asset asset = (Asset) controllerFactory.getController(Prefixes.Assets)
                                .getSingle(StringUtils.substringAfterLast(assetUri, "/"),
                                    AssetComponentResolver.FULL);
                            if (asset.getTemplateInfo() == null) {
                                AssetError assetError = ErrorProvider
                                    .findError(ErrorConstants.NOT_AN_EQUIPMENT_INSTANCE);
                                throw new DependencyViolationException(assetError, assetConn.getAssetSourceKey());
                            }
                        }
                    }
                });

                /**
                 * * find out this is Create/Update the Equipment-Instance operation.
                 */
                EquipmentInstanceOperation operationCode = decideOperation(tenantUuid, dto);

                if (operationCode == EquipmentInstanceOperation.CREATE) {
                    equipmentInstanceController.createEquipmentInstances(dto, null, false);
                } else if (operationCode == EquipmentInstanceOperation.UPDATE) {
                    String assetUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid,
                        Prefixes.Assets, dto.getParentEntitySrcKey());
                    String assetUuid = StringUtils.substringAfterLast(assetUri, "/");
                    final LinkedList<PatchOperation> patchOperationsList = new LinkedList<>();

                    dto.getConnections().forEach(assetConn -> {
                        patchOperationsList.add(new AddOperation(
                            ASSET_PLACEHOLDERS_PATCH_PATH + assetConn.getPlaceholderId(),
                            assetConn.getAssetSourceKey()));
                    });
                    equipmentInstanceController.updateEquipmentInstance(assetUuid, false,
                        patchOperationsList.stream().toArray(PatchOperation[]::new));
                } else if (operationCode == EquipmentInstanceOperation.REMOVE) {
                    String assetUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid,
                        Prefixes.Assets, dto.getParentEntitySrcKey());
                    String assetUuid = StringUtils.substringAfterLast(assetUri, "/");
                    final LinkedList<PatchOperation> patchOperationsList = new LinkedList<>();
                    dto.getConnections().forEach(assetConn ->
                        patchOperationsList.add(new RemoveOperation(
                            ASSET_PLACEHOLDERS_PATCH_PATH + assetConn.getPlaceholderId())));
                    equipmentInstanceController.updateEquipmentInstance(assetUuid, false,
                        patchOperationsList.stream().toArray(PatchOperation[]::new));
                } else {
                    throw new ServiceException("Unable to determine Create/Update/Delete action on "
                        + "equipment instance of template " + dto.getTemplateSourceKey());
                }
            } catch (DependencyViolationException dve) {

                Arrays.stream(preservedDtos)
                    .filter(p -> p.equals(dto))
                    .forEach(dveList::add);

                violationExceptions.add(dve);
            } catch (Exception ex) {
                if (retryPolicyPredicate.isRecoverableException(ex)) {
                    Arrays.stream(preservedDtos)
                        .filter(p -> p.equals(dto))
                        .forEach(dveList::add);

                    violationExceptions.add(new DependencyViolationException(ex));
                } else {
                    exceptions.add(ex);
                }
            }

        }

        exchange.setProperty(getPropertyName(exchange, ERROR_COUNT), exceptions.size());
        exchange.setProperty(getPropertyName(exchange, DVE_COUNT), dveList.size());

        if (!exceptions.isEmpty()) {
            exchange.setProperty(getPropertyName(exchange, ERRORS), exceptions);
        }
        if (!dveList.isEmpty()) {
            EquipmentInstanceConnection[] retryArray
                = dveList.toArray(new EquipmentInstanceConnection[dveList.size()]);
            exchange.getOut().setBody(retryArray);
            throw new DependencyViolationException(violationExceptions);
        }
    }

    public void postProcess(Exchange exchange) throws ValidationFailedException {
        List<Exception> exceptions = (List<Exception>) exchange.getProperty(getPropertyName(exchange, ERRORS));
        if (exceptions != null && exceptions.size() > 0) {
            List<AssetError> assetErrors = new ArrayList<>();
            AssetError assetError;
            for (Exception exception : exceptions) {
                if (exception instanceof ServiceException) {
                    ServiceException se = (ServiceException) exception;
                    assetError = ErrorProvider.findError(se.getCode());
                    assetError.setMsg(se.getMessage());
                } else {
                    assetError = ErrorProvider.findError(ErrorConstants.SYSTEM_ERROR);
                    assetError.setMsg(exception.getMessage());
                }
                assetError.setActualMsg(getStackTrace(exception));
                assetErrors.add(assetError);
            }
            AssetServiceException assetServiceEx = new AssetServiceException(ErrorConstants.SYSTEM_ERROR);
            assetServiceEx.setErrors(assetErrors);
            throw assetServiceEx;
        }

        ValidationResult validationResult = exchange.getProperty(getPropertyName(exchange, VALIDATION_RESULT),
            ValidationResult.class);
        if (validationResult != null && !validationResult.isValid()) {
            throw new ValidationFailedException(validationResult.getErrors());
        }
    }

    private String getPropertyName(Exchange exchange, String key) {
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();
        String taskUuid = messageHeaders.get(MessageConstants.TASK_UUID).toString();
        return key + "_" + tenantUuid + "_" + taskUuid;
    }

    private String getStackTrace(Throwable ex) {
        StringBuilder builder = new StringBuilder();
        String[] stackTrace = ExceptionUtils.getRootCauseStackTrace(ex);
        Arrays.stream(stackTrace).forEach(s -> builder.append(builder.length() < 5000 ? s : ""));
        return builder.toString();
    }

    public Asset getAsset(String assetSrcKey) {
        final ICrudController controller = controllerFactory.getController(Prefixes.Assets);
        return (Asset) controller.getBySourceKey(assetSrcKey);
    }

    private void throwValidationFailedException(String errorCode, String... placeholders)
        throws ValidationFailedException {
        String message = ErrorProvider.findMessage(errorCode, placeholders);
        ValidationResult validationResult = new ValidationResult();
        Error error = new Error(Error.ErrorType.ERROR, errorCode, message);
        error.setPlaceHolders(placeholders);
        validationResult.getErrors().add(error);
        validationResult.setValid(false);
        throw new ValidationFailedException(validationResult.getErrors());
    }

    private EquipmentInstanceOperation decideOperation(String tenantUuid,
        EquipmentInstanceConnection equipmentInstConnDto)
        throws ValidationFailedException {
        List<AssetPlaceholderConnection> assetPhConns = equipmentInstConnDto.getConnections();

        if (assetPhConns != null && assetPhConns.size() > 0
            && org.springframework.util.StringUtils.isEmpty(assetPhConns.get(0).getAssetSourceKey())) {
            return EquipmentInstanceOperation.REMOVE;
        }

        String parentEntitySrcKey = equipmentInstConnDto.getParentEntitySrcKey();
        if (parentEntitySrcKey != null
                && equipmentInstConnDto.getParentEntityCategory() == Category.ASSET) {
            Asset dbParentAsset = getAsset(parentEntitySrcKey);
            if (dbParentAsset != null) {
                TemplateInfo templateInfo = dbParentAsset.getTemplateInfo();
                if (templateInfo != null && templateInfo.getTemplateUri() != null) {
                    String templateUri = sourceKeyLookup.getUri(tenantUuid,
                        Prefixes.Templates, equipmentInstConnDto.getTemplateSourceKey());
                    if (templateInfo.getTemplateUri().equals(templateUri)) {
                        return EquipmentInstanceOperation.UPDATE;
                    } else {
                        throwValidationFailedException(ErrorConstants.TEMP_CONN_PARENT_AND_TEMPLATE_MISMATCH,
                            parentEntitySrcKey, equipmentInstConnDto.getTemplateSourceKey());
                    }
                }
            }
        }
        return EquipmentInstanceOperation.CREATE;
    }

    public void populatePlaceholdersWithSubTemplate(List<Placeholder> placeholders, List<String>
        placeholderIds) {

        if (placeholders == null || placeholders.isEmpty()) {
            return;
        }
        for (Placeholder placeholder : placeholders) {
            List<PlaceholderAssetTypeAssociation> association = placeholder.getAssetTypeAssociations();
            if (this.isTemplateAssociation(association)) {
                placeholderIds.add(placeholder.getPlaceholderId());
            }
            this.populatePlaceholdersWithSubTemplate(placeholder.getPlaceholders(), placeholderIds);
        }
    }

    public boolean isTemplateAssociation(List<PlaceholderAssetTypeAssociation> associations) {

        if (!CollectionUtils.isEmpty(associations)) {
            for (PlaceholderAssetTypeAssociation association: associations) {
                if (!StringUtils.isEmpty(association.getEntityUri())
                    && association.getEntityUri().contains(Prefixes.Templates)) {
                    return true;
                }
            }
        }
        return false;
    }

}
