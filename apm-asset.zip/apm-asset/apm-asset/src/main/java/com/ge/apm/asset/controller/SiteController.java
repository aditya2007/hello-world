/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.controller.base.IHierarchyController;
import com.ge.apm.asset.controller.base.ISearchController;
import com.ge.apm.asset.controller.base.ITagController;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.Sites, IBasePath.v3 + Prefixes.Sites,
    IBasePath.v3 + Prefixes.Tenants + "/{tenantId}" + Prefixes.Sites })
public class SiteController extends AbstractController<Site, IAssetService>
    implements ICrudController<Site, IAssetService>, ITagController<Site, IAssetService>,
    ISearchController<Site, IAssetService>, IHierarchyController<Site, IAssetService> {

    @Value("${apm.asset.page.size}")
    private int pageSize;

    public SiteController() {
        super(Prefixes.Sites, Prefixes.SiteTypes, Site.class);
    }

    @Override
    public int getPageSize() {
        return pageSize;
    }

    @Override
    @RequestMapping(method = RequestMethod.DELETE, value = "/{uuid}")
    @ResponseStatus(value = HttpStatus.OK)
    public void delete(@PathVariable("uuid") String uuid) {
        throw ExceptionUtil.wrapException(new ServiceException(ErrorConstants.TEMP_OPERATION_STOP),
            ErrorProvider.findError(ErrorConstants.DELETE), Prefixes.uri(getPrefix(), uuid));
    }

    @Override
    @RequestMapping(method = RequestMethod.GET, value = "/reservedAttributes")
    @ResponseBody
    public Map<String, ReservedAttributeConfig> reservedAttributes() {
        return this.getReservedAttributes(null);
    }
}
