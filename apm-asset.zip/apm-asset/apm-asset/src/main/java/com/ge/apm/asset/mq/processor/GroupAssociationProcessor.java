/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.asset.controller.GroupController;
import com.ge.apm.asset.model.GroupAssociation;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.mq.redis.SourceKeyLookup;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.mq.constants.MessageConstants;

/**
 * Created by 212432041 - Chand Bhaverisetti on 2/9/17.
 */
@Component
@Slf4j
public class GroupAssociationProcessor extends DtoProcessor {

    @Autowired
    private SourceKeyLookup sourceKeyLookup;

    @Autowired
    private GroupController groupController;

    @Override
    protected void processDto(Hierarchical dto, Exchange exchange) {
        // set toUri and fromUri if dto is GroupAssociation
        Map<String, Object> messageHeaders = exchange.getIn().getHeaders();
        String tenantUuid = messageHeaders.get(MessageConstants.TENANT_UUID).toString();

        if (((GroupAssociation) dto).getToUri() == null || ((GroupAssociation) dto).getFromUri() == null) {
            throw new ServiceException(ErrorProvider.findError(ErrorConstants.BAD_REQUEST_TOURI_FROMURI));
        }

        // adapter sets prefix & sourcekey for uri and we do extract & lookup here
        String toUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid, ((GroupAssociation) dto).getToUri());
        ((GroupAssociation) dto).setToUri(toUri);

        String fromUri = sourceKeyLookup.lookupObjectUriFor(tenantUuid, ((GroupAssociation) dto).getFromUri());
        ((GroupAssociation) dto).setFromUri(fromUri);
    }

    @Override
    protected void saveDto(String prefix, List newDtoList) {
        for (Object newDto : newDtoList) {
            String groupAssociationSrcKey = ((GroupAssociation) newDto).getSourceKey();
            String memberSrcKey = StringUtils.substringBeforeLast(groupAssociationSrcKey, " to ");
            String[] groupMemberSrcKeys = new String[] { memberSrcKey };

            String groupUri = ((GroupAssociation) newDto).getToUri();
            String groupUuid = StringUtils.substringAfterLast(groupUri, "/");

            groupController.associateMembers(groupUuid, groupMemberSrcKeys);
        }
    }
}
