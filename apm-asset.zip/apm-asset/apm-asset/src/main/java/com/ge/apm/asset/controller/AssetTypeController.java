/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.controller.base.IHierarchyController;
import com.ge.apm.asset.controller.base.ISearchController;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAssetTypeService;
import com.ge.apm.asset.util.ValidationDelegate;

@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.AssetTypes, IBasePath.v3 + Prefixes.AssetTypes,
    IBasePath.v3 + Prefixes.Tenants + "/{tenantId}" + Prefixes.AssetTypes })
public class AssetTypeController extends AbstractController<AssetType, IAssetTypeService>
    implements ICrudController<AssetType, IAssetTypeService>, IHierarchyController<AssetType, IAssetTypeService>,
    ISearchController<AssetType, IAssetTypeService> {

    @Autowired
    private ValidationDelegate validationDelegate;

    public AssetTypeController() {
        super(Prefixes.AssetTypes, AssetType.class);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/reservedAttributes")
    @ResponseBody
    public Map<String, ReservedAttributeConfig> reservedAttributes() {
        return this.getReservedAttributes();
    }

    private boolean hasGroupAssociations(String uri) {
        return getService().isMemberPartOfAGroup(uri, "ASSET_TYPE");
    }
}
