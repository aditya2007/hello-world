/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.HttpClientErrorException;

import com.ge.apm.asset.controller.base.AbstractController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.Typed;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.exception.ForbiddenException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

@Controller
@RequestMapping(value = { IBasePath.v1 + Prefixes.AssetObjects, IBasePath.v3 + Prefixes.AssetObjects,
    IBasePath.v3 + Prefixes.Tenants + "/{tenantId}" + Prefixes.AssetObjects })
public class AssetObjectsController extends AbstractController<Typed, IAssetService> {

    private static final List<Class<?>> assetClasses = new ArrayList<>();

    static {
        assetClasses.add(Enterprise.class);
        assetClasses.add(Site.class);
        assetClasses.add(Segment.class);
        assetClasses.add(Asset.class);
    }

    public AssetObjectsController() {
        super(Prefixes.AssetObjects, Typed.class);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/{uuid}")
    @ResponseStatus(value = HttpStatus.OK)
    public void delete(@PathVariable("uuid") String uuid,
        @RequestParam(value = "recursive", required = false) boolean recursive,
        @RequestParam(value = "deletionReason", required = false) String deletionReason) {

        if (recursive && StringUtils.isEmpty(deletionReason)) {
            throw ExceptionUtil.wrapException(new HttpClientErrorException(HttpStatus.BAD_REQUEST),
                ErrorProvider.findError(ErrorConstants.DELETE), uuid);
        }

        Typed asset = getService().getAssetByUUid(uuid);
        if (asset != null) {
            if (!assetClasses.contains(asset.getClass())) {
                throw new ForbiddenException("Access Forbidden");
            }
            String uri = asset.getUri();
            getService().deleteAssetIgnoringAssetPolicies(uri, deletionReason, asset.getClass(), recursive);
        } else {
            getLogger().error("[recursive delete] : uuid : {} not found", uuid);
            throw new ForbiddenException("Access Forbidden");
        }
    }
}