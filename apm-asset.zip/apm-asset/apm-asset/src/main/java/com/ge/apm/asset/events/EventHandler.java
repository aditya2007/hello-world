/********************************************************************************
 * Copyright \(c\) 2015-2017 GE Digital. All rights reserved.                   *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.events;

import java.util.Collections;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.ge.apm.common.support.RequestContext;

@Slf4j
@RestController
public class EventHandler {

    @Autowired
    public EventHandler(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    private final DataSource dataSource;

    @PostMapping(value = { "/v1/notify", "/v3/notify" })
    public ResponseEntity handleEvent(@RequestHeader(value = "Tenant") String tenantId) {
        log.info(String.format("Received Tenant=%s creation event", tenantId));
        if (StringUtils.isBlank(tenantId)) {
            log.error("Tenant header is empty");
            return new ResponseEntity("Tenant header is empty", HttpStatus.BAD_REQUEST);
        }
        StopWatch watch = new StopWatch();
        try {
            watch.start();
            log.info(String.format("Executing flyway migration for Tenant=%s", tenantId));
            RequestContext.put(RequestContext.TENANT_UUID, tenantId);
            Flyway flyway = new Flyway();
            flyway.setBaselineOnMigrate(false);
            flyway.setSchemas("apm_alm");
            flyway.setPlaceholders(Collections.singletonMap("json-data-type", "json"));
            flyway.setDataSource(dataSource);
            flyway.migrate();
            log.info(String.format("Successfully executed flyway migration for Tenant=%s", tenantId));
            ((com.ge.apm.datasource.impl.TenantDataSource) dataSource).flush(tenantId);
        } catch (Exception excp) {
            log.error(String.format("Error in executing flyway migration for Tenant=%ss", tenantId), excp);
            return new ResponseEntity(ExceptionUtils.getStackTrace(excp), HttpStatus.INTERNAL_SERVER_ERROR);
        } finally {
            watch.stop();
            log.info(String.format("Flyway migration for Tenant=%s executionTime(mSec) = %s", tenantId,
                watch.getTotalTimeMillis()));
            RequestContext.destroy();
        }
        return new ResponseEntity(HttpStatus.OK);
    }
}
