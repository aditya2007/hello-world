/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.assetgroupassociation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.ge.apm.asset.controller.AssetController;
import com.ge.apm.asset.controller.AssetGroupAssociationController;
import com.ge.apm.asset.controller.GroupController;
import com.ge.apm.asset.controller.base.ISearchController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.AssetGroupAssociation;
import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.factory.ControllerFactory;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.service.impl.AssetService;
import com.ge.apm.common.exception.BadRequestException;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.reflect.Whitebox.invokeMethod;

/**
 * Created by 212319603 on 2/23/16.
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ AssetGroupAssociationController.class, IAssetService.class })
public class CreateAssetGroupAssociationControllerTest {

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    List<AssetGroupAssociation> assetGroupAssociationList = mockAssetGroupAssociation();

    @Mock
    AssetService service;

    @Mock
    private ControllerFactory controllerFactory;

    @Mock
    private AssetController assetController;

    @Mock
    private GroupController groupController;

    @Mock
    private ISearchController searchController;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testAssociate_AssetToGroups() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);

        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());

        Map<String, Object> inputJson = new HashMap<>();
        inputJson.put("assetUri", "/enterprises/1234");
        Map<String, Object> groups = new HashMap<>();
        groups.put("sourceKeys", new ArrayList<>().add("assetGroupSrcKey1"));
        groups.put("uris", new ArrayList<>().add("assetGroupUri1"));
        inputJson.put("assetGroups", groups);

        PowerMockito.doNothing().when(spyController,
            method(AssetGroupAssociationController.class, "associateAssetToGroups", Map.class, String.class))
            .withArguments(Matchers.same(inputJson), eq("/enterprises/1234"));

        spyController.associate(inputJson);
    }

    @Test
    public void testAssociate_GroupToAssets() throws Exception {

        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());

        Map<String, Object> siteSourceKeys = new HashMap<>();
        siteSourceKeys.put("type", "/sites");
        siteSourceKeys.put("sourceKeys", new ArrayList<>().add("siteSrcKey1"));

        Map<String, Object> segmentSourceKeys = new HashMap<>();
        segmentSourceKeys.put("type", "/enterprises");
        segmentSourceKeys.put("sourceKeys", new ArrayList<>().add("enterpriseSrcKey1"));

        ArrayList<Map<String, Object>> srcKeysList = new ArrayList<>();
        srcKeysList.add(siteSourceKeys);
        srcKeysList.add(segmentSourceKeys);

        Map<String, Object> inputJson = new HashMap<>();
        inputJson.put("assetGroupUri", "/assetGroups/assetGroupUri1");
        Map<String, Object> assets = new HashMap<>();
        inputJson.put("assets", assets);
        assets.put("sourceKeys", srcKeysList);
        assets.put("uris", new ArrayList<>().add("assetGroupUri1"));

        PowerMockito.doNothing().when(spyController,
            method(AssetGroupAssociationController.class, "associateGroupToAssets", Map.class, String.class))
            .withArguments(Matchers.same(inputJson), eq("/assetGroups/assetGroupUri1"));

        spyController.associate(inputJson);
    }

    @Test(expected = BadRequestException.class)
    public void throwExceptionIfBothUriExists() throws IOException {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);

        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());

        Map<String, Object> inputJson = new HashMap<>();
        inputJson.put("assetUri", "/enterprises/1234");
        inputJson.put("assetGroupUri", "/assetGroups/assetGroupUri1");

        spyController.associate(inputJson);
        expectedEx.expectMessage("Input payload should contain either assetGroupUri/assetUri , not both");
    }

    @Test(expected = BadRequestException.class)
    public void throwExceptionIfBothUriMissing() throws IOException {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);

        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());

        Map<String, Object> inputJson = new HashMap<>();

        spyController.associate(inputJson);
        expectedEx.expectMessage("Mandatory field assetUri/assetGroupUri is missing for association");
    }

    @Test
    public void testAssociateAssetToGroups() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        request.setRequestURI("http://localhost:7800/v1/assetgroupassociations");

        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        ArrayList<String> assetGroupSourceKeys = new ArrayList<>();
        assetGroupSourceKeys.add("assetGroupSrcKey1");

        ArrayList<String> assetGroupUris = new ArrayList<>();
        assetGroupUris.add("assetGroupUri1");

        Map<String, Object> inputJson = new HashMap<>();
        inputJson.put("assetUri", "/assets/1234");
        Map<String, Object> assetGroups = new HashMap<>();
        inputJson.put("assetGroups", assetGroups);
        assetGroups.put("sourceKeys", assetGroupSourceKeys);
        assetGroups.put("uris", assetGroupUris);

        List<Asset> mockedAsset = mockAssetList(1);

        when(controllerFactory.getController(Prefixes.Assets)).thenReturn(assetController);
        when(assetController.getSingle(Matchers.matches("1234"), Matchers.matches("BASIC"))).thenReturn(
            mockedAsset.get(0));
        PowerMockito.doReturn(assetGroupAssociationList).when(spyController,
            method(AssetGroupAssociationController.class, "findGroups", ArrayList.class, Attributable.class,
                String.class)).withArguments(Matchers.same(assetGroupSourceKeys), any(), eq("sourceKey="));
        PowerMockito.doReturn(assetGroupAssociationList).when(spyController,
            method(AssetGroupAssociationController.class, "findGroups", ArrayList.class, Attributable.class,
                String.class)).withArguments(Matchers.same(assetGroupUris), any(), eq("uri="));
        Mockito.when(spyController.getService()).thenReturn(service);
        Mockito.when(service.add(any(), any(), any(), any())).thenReturn(
            mockedAsset.toArray(new Attributable[mockedAsset.size()]));
        invokeMethod(spyController, "associateAssetToGroups", inputJson, "/assets/1234");
    }

    @Test(expected = BadRequestException.class)
    public void testAssociateAssetToGroupsWithIncorrectAssetUri() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);

        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        Map<String, Object> inputJson = new HashMap<>();
        inputJson.put("assetUri", "/assets/1234");
        List<Asset> mockedAsset = mockAssetList(1);

        when(controllerFactory.getController(Prefixes.Assets)).thenReturn(assetController);
        when(assetController.getSingle(Matchers.matches("1234"), Matchers.matches("BASIC"))).thenReturn(
            mockedAsset.get(0));
        invokeMethod(spyController, "associateAssetToGroups", inputJson, "assets/1234");

        expectedEx.expectMessage(
            "System cannot find a Business Hierarchy object with URI \"assets/1234\" / Group association not "
                + "supported for Business Hierarchy object \"assets/1234\"");
    }

    @Test(expected = BadRequestException.class)
    public void testAssociateAssetToGroupsWithNullAsset() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);

        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        Map<String, Object> inputJson = new HashMap<>();
        inputJson.put("assetUri", "/assets/1234");
        List<Asset> mockedAsset = mockAssetList(1);

        when(controllerFactory.getController(Prefixes.Assets)).thenReturn(assetController);
        when(assetController.getSingle(Matchers.matches("1234"), Matchers.matches("BASIC"))).thenReturn(null);
        invokeMethod(spyController, "associateAssetToGroups", inputJson, "/assets/1234");

        expectedEx.expectMessage(
            "System cannot find a Business Hierarchy object with URI \"assets/1234\" / Group association not "
                + "supported for Business Hierarchy object \"assets/1234\"");
    }

    @Test
    public void testAssociateGroupToAssets() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        request.setRequestURI("http://localhost:7800/v1/assetgroupassociations");

        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        LinkedHashMap siteSourceKeys = new LinkedHashMap();
        siteSourceKeys.put("type", "/sites");
        siteSourceKeys.put("sourceKeys", new ArrayList<>().add("siteSrcKey1"));

        ArrayList<LinkedHashMap<String, Object>> srcKeysList = new ArrayList<>();
        srcKeysList.add(siteSourceKeys);

        ArrayList<String> uriList = new ArrayList<>();
        uriList.add("assetGroupUri1");

        Map<String, Object> inputJson = new HashMap<>();
        inputJson.put("assetGroupUri", "/assetGroups/assetGroupUri1");
        Map<String, Object> assets = new HashMap<>();
        inputJson.put("assets", assets);
        assets.put("sourceKeys", srcKeysList);
        assets.put("uris", uriList);

        List<Group> mockedGroups = mockGroupList(1);
        when(controllerFactory.getController(Prefixes.Groups)).thenReturn(groupController);
        when(groupController.getSingle(Matchers.matches("assetGroupUri1"), Matchers.matches("BASIC"))).thenReturn(
            mockedGroups.get(0));

        PowerMockito.doReturn(assetGroupAssociationList).when(spyController,
            method(AssetGroupAssociationController.class, "findObjectsBySourceKey", LinkedHashMap.class, Group.class))
            .withArguments(siteSourceKeys, mockedGroups.get(0));
        PowerMockito.doReturn(assetGroupAssociationList).when(spyController,
            method(AssetGroupAssociationController.class, "findObjectsByUri", ArrayList.class, Group.class))
            .withArguments(uriList, mockedGroups.get(0));
        Mockito.when(spyController.getService()).thenReturn(service);
        Mockito.when(service.add(any(), any(), any(), any())).thenReturn(
            mockedGroups.toArray(new Attributable[mockedGroups.size()]));
        invokeMethod(spyController, "associateGroupToAssets", inputJson, "/assetGroups/assetGroupUri1");
    }

    @Test(expected = BadRequestException.class)
    public void testAssociateGroupToAssetsWithIncorrectGroupUri() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);

        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        Map<String, Object> inputJson = new HashMap<>();
        inputJson.put("assetGroupUri", "/assetGroups/assetGroupUri1");
        invokeMethod(spyController, "associateGroupToAssets", inputJson, "assetGroups/assetGroupUri1");

        expectedEx.expectMessage("System cannot find a group with URI \"assetGroups/assetGroupUri1\"");
    }

    @Test(expected = BadRequestException.class)
    public void testAssociateGroupToAssetsWithNullGroup() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);

        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        Map<String, Object> inputJson = new HashMap<>();
        inputJson.put("assetGroupUri", "/assetGroups/assetGroupUri1");
        List<Group> mockedGroups = mockGroupList(1);

        when(controllerFactory.getController(Prefixes.Groups)).thenReturn(groupController);
        when(groupController.getSingle(Matchers.matches("assetGroupUri1"), Matchers.matches("BASIC"))).thenReturn(null);
        invokeMethod(spyController, "associateGroupToAssets", inputJson, "/assetGroups/assetGroupUri1");

        expectedEx.expectMessage("System cannot find a group with URI \"assetGroups/assetGroupUri1\"");
    }

    @Test
    public void testFindObjectsBySourceKey() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        ArrayList<String> sourceKeysList = new ArrayList<>();
        sourceKeysList.add("siteSrcKey1");
        sourceKeysList.add("siteSrcKey2");

        LinkedHashMap siteSourceKeys = new LinkedHashMap();
        siteSourceKeys.put("type", "/assets");
        siteSourceKeys.put("sourceKeys", sourceKeysList);

        List<Asset> mockedAssets = mockAssetList(2);
        Attributable[] associatedObjects = mockedAssets.toArray(new Attributable[mockedAssets.size()]);
        List<Group> mockedGroups = mockGroupList(1);

        when(controllerFactory.getSearchController(Prefixes.Assets)).thenReturn(searchController);
        when(searchController
            .query(eq("sourceKey=siteSrcKey1|sourceKey=siteSrcKey2"), Matchers.matches("BASIC"), eq(250), eq(null),
                anyString()))
            .thenReturn(associatedObjects);
        PowerMockito.doNothing().when(spyController,
            method(AssetGroupAssociationController.class, "validateAssociations", Attributable[].class, Group.class))
            .withArguments(associatedObjects, mockedGroups.get(0));
        List<AssetGroupAssociation> returnVal = invokeMethod(spyController, "findObjectsBySourceKey", siteSourceKeys,
            mockedGroups.get(0));
        Assert.assertEquals(associatedObjects.length, returnVal.size());
    }

    @Test
    public void testFindObjectsBySourceKeyWithDuplicateSourceKeys() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        ArrayList<String> sourceKeysList = new ArrayList<>();
        sourceKeysList.add("siteSrcKey1");
        sourceKeysList.add("siteSrcKey1");

        LinkedHashMap siteSourceKeys = new LinkedHashMap();
        siteSourceKeys.put("type", "/assets");
        siteSourceKeys.put("sourceKeys", sourceKeysList);

        List<Asset> mockedAssets = mockAssetList(1);
        Attributable[] associatedObjects = mockedAssets.toArray(new Attributable[mockedAssets.size()]);
        List<Group> mockedGroups = mockGroupList(1);

        when(controllerFactory.getSearchController(Prefixes.Assets)).thenReturn(searchController);
        when(searchController.query(eq("sourceKey=siteSrcKey1"), Matchers.matches("BASIC"), eq(250), eq(null),
            anyString())).thenReturn(associatedObjects);
        PowerMockito.doNothing().when(spyController,
            method(AssetGroupAssociationController.class, "validateAssociations", Attributable[].class, Group.class))
            .withArguments(associatedObjects, mockedGroups.get(0));
        List<AssetGroupAssociation> returnVal = invokeMethod(spyController, "findObjectsBySourceKey", siteSourceKeys,
            mockedGroups.get(0));
        assert (returnVal.size() == 1);
    }

    @Test(expected = BadRequestException.class)
    public void testFindObjectsBySourceKeyWithIncorrectPrefix() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        ArrayList<String> sourceKeysList = new ArrayList<>();
        sourceKeysList.add("siteSrcKey1");
        sourceKeysList.add("siteSrcKey2");

        LinkedHashMap siteSourceKeys = new LinkedHashMap();
        siteSourceKeys.put("type", "assets");
        siteSourceKeys.put("sourceKeys", sourceKeysList);

        List<Asset> mockedAssets = mockAssetList(2);
        Attributable[] associatedObjects = mockedAssets.toArray(new Attributable[mockedAssets.size()]);
        List<Group> mockedGroups = mockGroupList(1);

        when(controllerFactory.getSearchController("assets")).thenReturn(searchController);
        when(searchController
            .query(eq("sourceKey=siteSrcKey1|sourceKey=siteSrcKey2"), Matchers.matches("BASIC"), eq(250), eq(null),
                anyString()))
            .thenThrow(AssertionError.class);
        List<AssetGroupAssociation> returnVal = invokeMethod(spyController, "findObjectsBySourceKey", siteSourceKeys,
            mockedGroups.get(0));
        expectedEx.expectMessage("Invalid type \"/assets\" for assetSourceKeys property");
    }

    @Test
    public void testFindObjectsByUri() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        ArrayList<String> uriList = new ArrayList<>();
        uriList.add("/enterprises/1");
        uriList.add("/sites/2");
        uriList.add("/segments/3");
        uriList.add("/assets/4");
        uriList.add("/assets/5");

        List<Asset> mockedAssets = mockAssetList(2);
        Attributable[] associatedObjects = mockedAssets.toArray(new Attributable[mockedAssets.size()]);
        List<Asset> mockedEnterprises = mockAssetList(1);
        Attributable[] enterpriseObjects = mockedEnterprises.toArray(new Attributable[mockedEnterprises.size()]);
        List<Group> mockedGroups = mockGroupList(1);

        when(controllerFactory.getSearchController(Prefixes.Enterprises)).thenReturn(searchController);
        when(searchController.query(eq("uri=/enterprises/1"), Matchers.matches("BASIC"), eq(250), eq(null),
            anyString())).thenReturn(enterpriseObjects);
        when(controllerFactory.getSearchController(Prefixes.Sites)).thenReturn(searchController);
        when(searchController.query(eq("uri=/sites/2"), Matchers.matches("BASIC"), eq(250), eq(null),
            anyString())).thenReturn(enterpriseObjects);
        when(controllerFactory.getSearchController(Prefixes.Segments)).thenReturn(searchController);
        when(searchController.query(eq("uri=/segments/3"), Matchers.matches("BASIC"), eq(250), eq(null),
            anyString())).thenReturn(enterpriseObjects);
        when(controllerFactory.getSearchController(Prefixes.Assets)).thenReturn(searchController);
        when(searchController.query(eq("uri=/assets/4|uri=/assets/5"), Matchers.matches("BASIC"), eq(250), eq(null),
            anyString())).thenReturn(associatedObjects);
        PowerMockito.doNothing().when(spyController,
            method(AssetGroupAssociationController.class, "validateAssociations", Attributable[].class, Group.class))
            .withArguments(associatedObjects, mockedGroups.get(0));
        PowerMockito.doNothing().when(spyController,
            method(AssetGroupAssociationController.class, "validateAssociations", Attributable[].class, Group.class))
            .withArguments(enterpriseObjects, mockedGroups.get(0));
        List<AssetGroupAssociation> returnVal = invokeMethod(spyController, "findObjectsByUri", uriList,
            mockedGroups.get(0));
        Assert.assertEquals(uriList.size(), returnVal.size());
    }

    @Test
    public void testFindObjectsByUriWithDuplicateUris() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        ArrayList<String> uriList = new ArrayList<>();
        uriList.add("/enterprises/1");
        uriList.add("/enterprises/1");

        List<Asset> mockedEnterprises = mockAssetList(1);
        Attributable[] enterpriseObjects = mockedEnterprises.toArray(new Attributable[mockedEnterprises.size()]);
        List<Group> mockedGroups = mockGroupList(1);

        when(controllerFactory.getSearchController(Prefixes.Enterprises)).thenReturn(searchController);
        when(searchController.query(eq("uri=/enterprises/1"), Matchers.matches("BASIC"), eq(250), eq(null),
            anyString())).thenReturn(enterpriseObjects);
        PowerMockito.doNothing().when(spyController,
            method(AssetGroupAssociationController.class, "validateAssociations", Attributable[].class, Group.class))
            .withArguments(enterpriseObjects, mockedGroups.get(0));
        List<AssetGroupAssociation> returnVal = invokeMethod(spyController, "findObjectsByUri", uriList,
            mockedGroups.get(0));
        assert (returnVal.size() == 1);
    }

    @Test
    public void testFindGroups() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        ArrayList<String> groupSourceKeysList = new ArrayList<>();
        groupSourceKeysList.add("groupSrcKey1");
        groupSourceKeysList.add("groupSrcKey2");

        ArrayList<String> allowedGroupCategory = new ArrayList<>();
        allowedGroupCategory.add("TAG");
        allowedGroupCategory.add("ASSET");

        List<Asset> mockedAssets = mockAssetList(1);
        Attributable[] associatedObjects = mockedAssets.toArray(new Attributable[mockedAssets.size()]);
        List<Group> mockedGroups = mockGroupList(2);
        Group[] associatedGroups = mockedGroups.toArray(new Group[mockedGroups.size()]);

        when(controllerFactory.getSearchController(Prefixes.Groups)).thenReturn(searchController);
        when(searchController
            .query(eq("sourceKey=groupSrcKey1|sourceKey=groupSrcKey2"), Matchers.matches("BASIC"), eq(250), eq(null),
                anyString())).thenReturn(associatedGroups);
        PowerMockito.doReturn(allowedGroupCategory).when(spyController,
            method(AssetGroupAssociationController.class, "getAllowedGroupCategory", Attributable.class)).withArguments(
            associatedObjects[0]);
        List<AssetGroupAssociation> returnVal = invokeMethod(spyController, "findGroups", groupSourceKeysList,
            mockedAssets.get(0), "sourceKey=");
        Assert.assertEquals(groupSourceKeysList.size(), returnVal.size());
    }

    @Test(expected = IllegalStateException.class)
    public void testCategorizeAssetUrisWithIncorrectUri() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        ArrayList<String> uris = new ArrayList<>();
        uris.add("/assets/1234");
        uris.add("/tags/4es2");
        invokeMethod(spyController, "categorizeAssetUris", uris, new HashSet(), new HashSet(), new HashSet(),
            new HashSet());
        expectedEx.expectMessage("Invalid Prefix of URI:/tags/4es2");
    }

    @Test(expected = BadRequestException.class)
    public void testFindGroupsWithDuplicateGroupSrcKey() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        ArrayList<String> groupSourceKeysList = new ArrayList<>();
        groupSourceKeysList.add("groupSrcKey1");
        groupSourceKeysList.add("groupSrcKey1");

        List<Asset> mockedAssets = mockAssetList(1);
        Attributable[] associatedObjects = mockedAssets.toArray(new Attributable[mockedAssets.size()]);
        List<Group> mockedGroups = mockGroupList(1);
        Group[] associatedGroups = mockedGroups.toArray(new Group[mockedGroups.size()]);

        when(controllerFactory.getSearchController(Prefixes.Groups)).thenReturn(searchController);
        when(searchController
            .query(eq("sourceKey=groupSrcKey1|sourceKey=groupSrcKey1"), Matchers.matches("BASIC"), eq(250), eq(null),
                anyString())).thenReturn(associatedGroups);
        List<AssetGroupAssociation> returnVal = invokeMethod(spyController, "findGroups", groupSourceKeysList,
            mockedAssets.get(0), "sourceKey=");
        expectedEx.expectMessage("One or More Group sourceKeys/URIs are duplicate / missing in the system");
    }

    @Test(expected = BadRequestException.class)
    public void testFindGroupsWithIncorrectGroupCategory() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        ArrayList<String> groupSourceKeysList = new ArrayList<>();
        groupSourceKeysList.add("groupSrcKey1");
        groupSourceKeysList.add("groupSrcKey2");

        ArrayList<String> allowedGroupCategory = new ArrayList<>();
        allowedGroupCategory.add("ASSET");
        allowedGroupCategory.add("SITE");

        List<Asset> mockedAssets = mockAssetList(1);
        Attributable[] associatedObjects = mockedAssets.toArray(new Attributable[mockedAssets.size()]);
        List<Group> mockedGroups = mockGroupList(2);
        Group[] associatedGroups = mockedGroups.toArray(new Group[mockedGroups.size()]);

        when(controllerFactory.getSearchController(Prefixes.Groups)).thenReturn(searchController);
        when(searchController
            .query(eq("sourceKey=groupSrcKey1|sourceKey=groupSrcKey2"), Matchers.matches("BASIC"), eq(250), eq(null),
                anyString())).thenReturn(associatedGroups);
        PowerMockito.doReturn(allowedGroupCategory).when(spyController,
            method(AssetGroupAssociationController.class, "getAllowedGroupCategory", Attributable.class)).withArguments(
            associatedObjects[0]);
        List<AssetGroupAssociation> returnVal = invokeMethod(spyController, "findGroups", groupSourceKeysList,
            mockedAssets.get(0), "sourceKey=");
        expectedEx.expectMessage("Invalid to associate one/more groups to Business Hierarchy object \"/assets/1\". "
            + "System will allow to associate only groups with category \"ASSET,SITE\" for Object \"/assets/1\".");
    }

    @Test
    public void testValidateAssociations() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        List<String> allowedBusinessHierarchy = new ArrayList<>();
        allowedBusinessHierarchy.add("/assets");
        allowedBusinessHierarchy.add("/segments");

        List<Asset> mockedAssets = mockAssetList(5);
        Attributable[] associatedObjects = mockedAssets.toArray(new Attributable[mockedAssets.size()]);
        List<Group> mockedGroups = mockGroupList(1);
        PowerMockito.doReturn(allowedBusinessHierarchy).when(spyController,
            method(AssetGroupAssociationController.class, "getAllowedBusinessHierarchy", Group.class)).withArguments(
            mockedGroups.get(0));
        invokeMethod(spyController, "validateAssociations", associatedObjects, mockedGroups.get(0));
    }

    @Test(expected = BadRequestException.class)
    public void testValidateAssociationsThrowException() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        List<String> allowedBusinessHierarchy = new ArrayList<>();
        allowedBusinessHierarchy.add("/sites");
        allowedBusinessHierarchy.add("/segments");
        List<Asset> mockedAssets = mockAssetList(5);
        Attributable[] associatedObjects = mockedAssets.toArray(new Attributable[mockedAssets.size()]);
        List<Group> mockedGroups = mockGroupList(1);

        PowerMockito.doReturn(allowedBusinessHierarchy).when(spyController,
            method(AssetGroupAssociationController.class, "getAllowedBusinessHierarchy", Group.class)).withArguments(
            mockedGroups.get(0));
        invokeMethod(spyController, "validateAssociations", associatedObjects, mockedGroups.get(0));

        expectedEx.expectMessage(
            "Invalid to associate one/more asset objects to group \"/groups/1\". System will allow to associate "
                + "only \"/sites,/segments\" type objects for group with category \"TAG\".");
    }

    @Test
    public void testGetAllowedGroupCategory() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        List<Asset> mockedAssets = mockAssetList(1);
        Attributable[] associatedObjects = mockedAssets.toArray(new Attributable[mockedAssets.size()]);
        List<String> returnVal = invokeMethod(spyController, "getAllowedGroupCategory", associatedObjects[0]);
        Assert.assertEquals(returnVal.size(), 2);
        List<String> expectedArray = new ArrayList<>();
        expectedArray.add("TAG");
        expectedArray.add("ASSET");
        Assert.assertArrayEquals(expectedArray.toArray(new String[returnVal.size()]),
            returnVal.toArray(new String[returnVal.size()]));

        Attributable[] segmentObjects = Arrays.copyOf(associatedObjects, 1);
        segmentObjects[0].setUri("/segments/1234");
        returnVal = invokeMethod(spyController, "getAllowedGroupCategory", segmentObjects);
        Assert.assertEquals(returnVal.size(), 2);
        expectedArray.clear();
        expectedArray.add("TAG");
        expectedArray.add("ASSET");
        Assert.assertArrayEquals(expectedArray.toArray(new String[returnVal.size()]),
            returnVal.toArray(new String[returnVal.size()]));

        Attributable[] siteObjects = Arrays.copyOf(associatedObjects, 1);
        siteObjects[0].setUri("/sites/1234");
        returnVal = invokeMethod(spyController, "getAllowedGroupCategory", siteObjects);
        Assert.assertEquals(returnVal.size(), 3);
        expectedArray.clear();
        expectedArray.add("TAG");
        expectedArray.add("ASSET");
        expectedArray.add("SEGMENT");
        Assert.assertArrayEquals(expectedArray.toArray(new String[returnVal.size()]),
            returnVal.toArray(new String[returnVal.size()]));

        Attributable[] enterpriseObjects = Arrays.copyOf(associatedObjects, 1);
        enterpriseObjects[0].setUri("/enterprises/1234");
        returnVal = invokeMethod(spyController, "getAllowedGroupCategory", enterpriseObjects);
        Assert.assertEquals(returnVal.size(), 4);
        expectedArray.clear();
        expectedArray.add("TAG");
        expectedArray.add("ASSET");
        expectedArray.add("SEGMENT");
        expectedArray.add("SITE");
        Assert.assertArrayEquals(expectedArray.toArray(new String[returnVal.size()]),
            returnVal.toArray(new String[returnVal.size()]));
    }

    @Test
    public void testGetAllowedBusinessHierarchy() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        List<Group> mockedGroups = mockGroupList(1);
        Group[] associatedGroups = mockedGroups.toArray(new Group[mockedGroups.size()]);
        List<String> returnVal = invokeMethod(spyController, "getAllowedBusinessHierarchy", associatedGroups[0]);
        Assert.assertEquals(returnVal.size(), 4);
        List<String> expectedArray = new ArrayList<>();
        expectedArray.add(Prefixes.Assets);
        expectedArray.add(Prefixes.Segments);
        expectedArray.add(Prefixes.Sites);
        expectedArray.add(Prefixes.Enterprises);
        Assert.assertArrayEquals(expectedArray.toArray(new String[returnVal.size()]),
            returnVal.toArray(new String[returnVal.size()]));

        Group[] assetGroups = Arrays.copyOf(associatedGroups, 1);
        assetGroups[0].setCategory("ASSET");
        returnVal = invokeMethod(spyController, "getAllowedBusinessHierarchy", assetGroups);
        Assert.assertEquals(returnVal.size(), 4);
        expectedArray.clear();
        expectedArray.add(Prefixes.Assets);
        expectedArray.add(Prefixes.Segments);
        expectedArray.add(Prefixes.Sites);
        expectedArray.add(Prefixes.Enterprises);
        Assert.assertArrayEquals(expectedArray.toArray(new String[returnVal.size()]),
            returnVal.toArray(new String[returnVal.size()]));

        Group[] segmentGroups = Arrays.copyOf(associatedGroups, 1);
        segmentGroups[0].setCategory("SEGMENT");
        returnVal = invokeMethod(spyController, "getAllowedBusinessHierarchy", segmentGroups);
        Assert.assertEquals(returnVal.size(), 2);
        expectedArray.clear();
        expectedArray.add(Prefixes.Sites);
        expectedArray.add(Prefixes.Enterprises);
        Assert.assertArrayEquals(expectedArray.toArray(new String[returnVal.size()]),
            returnVal.toArray(new String[returnVal.size()]));

        Group[] siteGroups = Arrays.copyOf(associatedGroups, 1);
        siteGroups[0].setCategory("SITE");
        returnVal = invokeMethod(spyController, "getAllowedBusinessHierarchy", siteGroups);
        Assert.assertEquals(returnVal.size(), 1);
        expectedArray.clear();
        expectedArray.add(Prefixes.Enterprises);
        Assert.assertArrayEquals(expectedArray.toArray(new String[returnVal.size()]),
            returnVal.toArray(new String[returnVal.size()]));
    }

    @Test(expected = BadRequestException.class)
    public void testGetAllowedBusinessHierarchyException() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        List<Group> mockedGroups = mockGroupList(1);
        Group[] associatedGroups = mockedGroups.toArray(new Group[mockedGroups.size()]);
        associatedGroups[0].setCategory("ENTERPRISE");
        invokeMethod(spyController, "getAllowedBusinessHierarchy", associatedGroups[0]);
        expectedEx.expectMessage("Group category \"ENTERPRISE\" not supported for association");
    }

    @Test(expected = BadRequestException.class)
    public void testGetAllowedGroupCategoryException() throws Exception {
        AssetGroupAssociationController spyController = PowerMockito.spy(new AssetGroupAssociationController());
        spyController.controllerFactory = controllerFactory;

        List<Asset> mockedAssets = mockAssetList(1);
        Attributable[] associatedObjects = mockedAssets.toArray(new Attributable[mockedAssets.size()]);
        associatedObjects[0].setUri(Prefixes.SegmentTypes);
        invokeMethod(spyController, "getAllowedGroupCategory", associatedObjects[0]);
        expectedEx.expectMessage("Business hierarchy object \"/segmentTypes\" not supported for association");
    }

    private List<AssetGroupAssociation> mockAssetGroupAssociation() {
        List<AssetGroupAssociation> assetGroupAssociationList = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            AssetGroupAssociation assetGroupAssociation = new AssetGroupAssociation();
            assetGroupAssociation.setGroupId("GroupId" + i);
            assetGroupAssociation.setObjectId("AssetId" + i);
            assetGroupAssociation.setSourceKey("SourceKey" + i);
            assetGroupAssociationList.add(assetGroupAssociation);
        }
        return assetGroupAssociationList;
    }

    private List<Asset> mockAssetList(int numberOfInstances) {
        List<Asset> assetList = new ArrayList<>();
        for (int i = 1; i <= numberOfInstances; i++) {
            Asset assetObject = new Asset();
            assetObject.setSourceKey("SourceKey" + i);
            assetObject.setName("Name" + i);
            assetObject.setUri("/assets/" + i);
            assetObject.setDescription("Description " + i);
            assetList.add(assetObject);
        }
        return assetList;
    }

    private List<Group> mockGroupList(int numberOfInstances) {
        List<Group> groupList = new ArrayList<>();
        for (int i = 1; i <= numberOfInstances; i++) {
            Group groupObject = new Group();
            groupObject.setSourceKey("SourceKey" + i);
            groupObject.setName("Name" + i);
            groupObject.setUri("/groups/" + i);
            groupObject.setDescription("Description " + i);
            groupObject.setCategory("TAG");
            groupList.add(groupObject);
        }
        return groupList;
    }
}
