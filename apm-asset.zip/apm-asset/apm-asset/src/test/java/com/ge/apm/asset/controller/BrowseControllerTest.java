/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

import com.ge.apm.asset.api.base.AbstractInstanceControllerTest;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.model.Named;
import com.ge.apm.asset.model.NodeData;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAlmPersistenceService;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.asset.util.SortByResolver;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ForbiddenException;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;

import static org.mockito.Matchers.eq;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class })
public class BrowseControllerTest extends AbstractInstanceControllerTest<BrowseController, Enterprise> {

    private final Comparator<Hierarchical> byName = Comparator.comparing(Named::getName);

    private BrowseController browseController;

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        browseController = new BrowseController();
        ReflectionUtils.setField(BrowseController.class, browseController, "assetService", assetService);
    }

    @Test
    public void browseInstances_ParentValueEmptyString() throws IOException {

        setupGetFromPersistence(Prefixes.Enterprises,
            readObjectsFromResourceFile(getPredixPath() + "/enterprises.json", Enterprise.class), Enterprise.class);

        Hierarchical[] fetchedInstances = getController().browseInstances("", AssetComponentResolver.ATTRIBUTES,
            SortByResolver.NAME);
        Enterprise[] expectedInstances = readObjectsFromResourceFile(getOutputPath() + "/enterprises.json",
            Enterprise.class);
        expectedInstances = Arrays.stream(expectedInstances).sorted(byName).toArray(Enterprise[]::new);
        Assert.assertArrayEquals(expectedInstances, fetchedInstances);
    }

    @Test
    public void browseInstances_ParentValueNull() throws IOException {
        setupGetFromPersistence(Prefixes.Enterprises,
            readObjectsFromResourceFile(getPredixPath() + "/enterprises.json", Enterprise.class), Enterprise.class);

        Hierarchical[] fetchedInstances = getController().browseInstances("null", AssetComponentResolver.ATTRIBUTES,
            SortByResolver.NAME);
        Enterprise[] expectedInstances = readObjectsFromResourceFile(getOutputPath() + "/enterprises.json",
            Enterprise.class);
        expectedInstances = Arrays.stream(expectedInstances).sorted(byName).toArray(Enterprise[]::new);

        Assert.assertArrayEquals(expectedInstances, fetchedInstances);
    }

    @Test
    public void browseInstances_ParentIsEnterprise() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID1));
        urlVariables.put("pageSize", 250);

        Map<String, Object> siteVariables = new HashMap<>();
        siteVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID1));
        siteVariables.put("pageSize", 248);

        List<Hierarchical> childInstances = new ArrayList<>();
        childInstances.addAll(Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/sites.json", Site.class)));
        childInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/enterprises.json", Enterprise.class)));

        setupGetChildrenFromPersistence(null, childInstances.toArray(new Hierarchical[0]),
            Prefixes.uri(Prefixes.Enterprises, UUID1), null, null);

        Hierarchical[] fetchedInstances = getController().browseInstances(Prefixes.uri(Prefixes.Enterprises, UUID1),
            AssetComponentResolver.ATTRIBUTES, SortByResolver.NAME);

        List<Hierarchical> expectedInstances = new ArrayList<>();
        expectedInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/enterprises.json", Enterprise.class)));
        expectedInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/sites.json", Site.class)));
        expectedInstances.sort(byName);

        Assert.assertArrayEquals(expectedInstances.toArray(new Hierarchical[expectedInstances.size()]),
            fetchedInstances);
    }

    @Test
    public void browseInstances_ParentIsSite() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Sites, UUID1));
        urlVariables.put("pageSize", 250);

        Map<String, Object> assetVariables = new HashMap<>();
        assetVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Sites, UUID1));
        assetVariables.put("pageSize", 248);

        List<Hierarchical> childInstances = new ArrayList<>();
        childInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/segments.json", Segment.class)));
        childInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/assets.json", Asset.class)));
        setupGetChildrenFromPersistence(null, childInstances.toArray(new Hierarchical[0]),
            Prefixes.uri(Prefixes.Sites, UUID1), null, null);

        Hierarchical[] fetchedInstances = getController().browseInstances(Prefixes.uri(Prefixes.Sites, UUID1),
            AssetComponentResolver.ATTRIBUTES, SortByResolver.NAME);

        List<Hierarchical> expectedInstances = new ArrayList<>();
        expectedInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/segments.json", Segment.class)));
        expectedInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/assets.json", Asset.class)));
        expectedInstances.sort(byName);

        Assert.assertArrayEquals(expectedInstances.toArray(new Hierarchical[expectedInstances.size()]),
            fetchedInstances);
    }

    @Test
    public void browseInstances_ParentIsSegment() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Segments, UUID1));
        urlVariables.put("pageSize", 250);

        urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Segments, UUID1));
        urlVariables.put("pageSize", 248);

        List<Hierarchical> childInstances = new ArrayList<>();
        childInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/segments.json", Segment.class)));
        childInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/assets.json", Asset.class)));

        setupGetChildrenFromPersistence(null, childInstances.toArray(new Hierarchical[0]),
            Prefixes.uri(Prefixes.Segments, UUID1), null, null);

        Hierarchical[] fetchedInstances = getController().browseInstances(Prefixes.uri(Prefixes.Segments, UUID1),
            AssetComponentResolver.ATTRIBUTES, SortByResolver.NAME);

        List<Hierarchical> expectedInstances = new ArrayList<>();
        expectedInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/segments.json", Segment.class)));
        expectedInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/assets.json", Asset.class)));
        expectedInstances.sort(byName);

        Assert.assertArrayEquals(expectedInstances.toArray(new Hierarchical[expectedInstances.size()]),
            fetchedInstances);
    }

    @Test
    public void browseInstances_ParentIsAsset() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Segments, UUID1));
        urlVariables.put("pageSize", 250);

        setupGetChildrenFromPersistence(null,
            readObjectsFromResourceFile(getPredixPath() + "/assets.json", Asset.class),
            Prefixes.uri(Prefixes.Segments, UUID1), null, null);

        Hierarchical[] fetchedInstances = getController().browseInstances(Prefixes.uri(Prefixes.Segments, UUID1),
            AssetComponentResolver.ATTRIBUTES, SortByResolver.NAME);
        Hierarchical[] expectedInstances = readObjectsFromResourceFile(getOutputPath() + "/assets.json", Asset.class);
        expectedInstances = Arrays.stream(expectedInstances).sorted(byName).toArray(Hierarchical[]::new);

        Assert.assertArrayEquals(expectedInstances, fetchedInstances);
    }

    @Test
    public void browseInstances_ParentIsAsset_sortByAlias() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Segments, UUID1));
        urlVariables.put("pageSize", 250);

        setupGetChildrenFromPersistence(null,
            readObjectsFromResourceFile(getPredixPath() + "/assets.json", Asset.class),
            Prefixes.uri(Prefixes.Segments, UUID1), null, null);
        Hierarchical[] fetchedInstances = getController().browseInstances(Prefixes.uri(Prefixes.Segments, UUID1),
            AssetComponentResolver.ATTRIBUTES, SortByResolver.ALIAS);
        Hierarchical[] expectedInstances = readObjectsFromResourceFile(getOutputPath() + "/assets.json", Asset.class);
        for (Hierarchical hierarchical : expectedInstances) {
            SortByResolver.swapTheNameAndAlias(hierarchical);
        }
        expectedInstances = Arrays.stream(expectedInstances).sorted(byName).toArray(Hierarchical[]::new);

        Assert.assertArrayEquals(expectedInstances, fetchedInstances);
    }

    @Test
    public void browseInstances_ParentIsAsset_sortByAlias_emptyAlias() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Segments, UUID1));
        urlVariables.put("pageSize", 250);

        setupGetChildrenFromPersistence(null,
            readObjectsFromResourceFile(getPredixPath() + "/assetsEmptyAlias.json", Asset.class),
            Prefixes.uri(Prefixes.Segments, UUID1), null, null);
        Hierarchical[] fetchedInstances = getController().browseInstances(Prefixes.uri(Prefixes.Segments, UUID1),
            AssetComponentResolver.ATTRIBUTES, SortByResolver.ALIAS);
        Hierarchical[] expectedInstances = readObjectsFromResourceFile(getOutputPath() + "/assetsEmptyAlias.json",
            Asset.class);

        // Empty alias should not be swapped with name
        Assert.assertArrayEquals(expectedInstances, fetchedInstances);
    }

    @Test(expected = ForbiddenException.class)
    public void browseInstances_Error() {
        throwExceptionForGetChildrenFromPersistence(new HttpClientErrorException(HttpStatus.FORBIDDEN), null);
        getController().browseInstances(Prefixes.uri(Prefixes.Segments, UUID1), AssetComponentResolver.ATTRIBUTES,
            SortByResolver.NAME);
    }

    @Test
    public void browseAllInstances_ParentValueEmptyString() throws IOException {
        setupGetFromPersistence(Prefixes.Enterprises,
            readObjectsFromResourceFile(getPredixPath() + "/enterprises.json", Enterprise.class), Enterprise.class);

        Hierarchical[] fetchedInstances = getController().browseAllInstances("", AssetComponentResolver.ATTRIBUTES,
            SortByResolver.NAME);
        Enterprise[] expectedInstances = readObjectsFromResourceFile(getOutputPath() + "/enterprises.json",
            Enterprise.class);
        expectedInstances = Arrays.stream(expectedInstances).sorted(byName).toArray(Enterprise[]::new);
        Assert.assertArrayEquals(expectedInstances, fetchedInstances);
    }

    @Test
    public void browseAllInstances_ParentValueNull() throws IOException {
        setupGetFromPersistence(Prefixes.Enterprises,
            readObjectsFromResourceFile(getPredixPath() + "/enterprises.json", Enterprise.class), Enterprise.class);

        Hierarchical[] fetchedInstances = getController().browseAllInstances("null", AssetComponentResolver.ATTRIBUTES,
            SortByResolver.NAME);
        Enterprise[] expectedInstances = readObjectsFromResourceFile(getOutputPath() + "/enterprises.json",
            Enterprise.class);
        expectedInstances = Arrays.stream(expectedInstances).sorted(byName).toArray(Enterprise[]::new);

        Assert.assertArrayEquals(expectedInstances, fetchedInstances);
    }

    @Test
    public void browseAllInstances_ParentIsEnterprise() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID1));
        urlVariables.put("pageSize", 250);

        Map<String, Object> siteVariables = new HashMap<>();
        siteVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID1));
        siteVariables.put("pageSize", 248);

        List<Hierarchical> childInstances = new ArrayList<>();
        childInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/enterprises.json", Enterprise.class)));
        childInstances.addAll(Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/sites.json", Site.class)));

        setupGetChildrenFromPersistence(null, childInstances.toArray(new Hierarchical[0]),
            Prefixes.uri(Prefixes.Enterprises, UUID1), null);

        Hierarchical[] fetchedInstances = getController().browseAllInstances(Prefixes.uri(Prefixes.Enterprises, UUID1),
            AssetComponentResolver.ATTRIBUTES, SortByResolver.NAME);

        List<Hierarchical> expectedInstances = new ArrayList<>();
        expectedInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/enterprises.json", Enterprise.class)));
        expectedInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/sites.json", Site.class)));
        expectedInstances.sort(byName);

        Assert.assertArrayEquals(expectedInstances.toArray(new Hierarchical[expectedInstances.size()]),
            fetchedInstances);
    }

    @Test
    public void browseAllInstances_ParentIsSite() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Sites, UUID1));
        urlVariables.put("pageSize", 250);

        Map<String, Object> assetVariables = new HashMap<>();
        assetVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Sites, UUID1));
        assetVariables.put("pageSize", 248);

        List<Hierarchical> childInstances = new ArrayList<>();
        childInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/segments.json", Segment.class)));
        childInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/assets.json", Asset.class)));

        setupGetChildrenFromPersistence(null, childInstances.toArray(new Hierarchical[0]),
            Prefixes.uri(Prefixes.Sites, UUID1), null);

        Hierarchical[] fetchedInstances = getController().browseAllInstances(Prefixes.uri(Prefixes.Sites, UUID1),
            AssetComponentResolver.ATTRIBUTES, SortByResolver.NAME);

        List<Hierarchical> expectedInstances = new ArrayList<>();
        expectedInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/segments.json", Segment.class)));
        expectedInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/assets.json", Asset.class)));
        expectedInstances.sort(byName);

        Assert.assertArrayEquals(expectedInstances.toArray(new Hierarchical[expectedInstances.size()]),
            fetchedInstances);
    }

    @Test
    public void browseAllInstances_ParentIsSegment() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Segments, UUID1));
        urlVariables.put("pageSize", 250);

        urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Segments, UUID1));
        urlVariables.put("pageSize", 248);

        List<Hierarchical> childInstances = new ArrayList<>();
        childInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/segments.json", Segment.class)));
        childInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/assets.json", Asset.class)));

        setupGetChildrenFromPersistence(null, childInstances.toArray(new Hierarchical[0]),
            Prefixes.uri(Prefixes.Segments, UUID1), null);

        Hierarchical[] fetchedInstances = getController().browseAllInstances(Prefixes.uri(Prefixes.Segments, UUID1),
            AssetComponentResolver.ATTRIBUTES, SortByResolver.NAME);

        List<Hierarchical> expectedInstances = new ArrayList<>();
        expectedInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/segments.json", Segment.class)));
        expectedInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/assets.json", Asset.class)));
        expectedInstances.sort(byName);

        Assert.assertArrayEquals(expectedInstances.toArray(new Hierarchical[expectedInstances.size()]),
            fetchedInstances);
    }

    @Test
    public void browseAllInstances_ParentIsAsset() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Segments, UUID1));
        urlVariables.put("pageSize", 250);

        setupGetChildrenFromPersistence(null,
            readObjectsFromResourceFile(getPredixPath() + "/assets.json", Asset.class),
            Prefixes.uri(Prefixes.Segments, UUID1), null);

        Hierarchical[] fetchedInstances = getController().browseAllInstances(Prefixes.uri(Prefixes.Segments, UUID1),
            AssetComponentResolver.ATTRIBUTES, SortByResolver.NAME);
        Hierarchical[] expectedInstances = readObjectsFromResourceFile(getOutputPath() + "/assets.json", Asset.class);
        expectedInstances = Arrays.stream(expectedInstances).sorted(byName).toArray(Hierarchical[]::new);

        Assert.assertArrayEquals(expectedInstances, fetchedInstances);
    }

    @Test
    public void browseAllInstances_ParentIsAsset_sortByAlias() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Segments, UUID1));
        urlVariables.put("pageSize", 250);

        setupGetChildrenFromPersistence(null,
            readObjectsFromResourceFile(getPredixPath() + "/assets.json", Asset.class),
            Prefixes.uri(Prefixes.Segments, UUID1), null);

        Hierarchical[] fetchedInstances = getController().browseAllInstances(Prefixes.uri(Prefixes.Segments, UUID1),
            AssetComponentResolver.ATTRIBUTES, SortByResolver.ALIAS);
        Hierarchical[] expectedInstances = readObjectsFromResourceFile(getOutputPath() + "/assets.json", Asset.class);
        for (Hierarchical hierarchical : expectedInstances) {
            SortByResolver.swapTheNameAndAlias(hierarchical);
        }
        expectedInstances = Arrays.stream(expectedInstances).sorted(byName).toArray(Hierarchical[]::new);

        Assert.assertArrayEquals(expectedInstances, fetchedInstances);
    }

    @Test
    public void browseAllInstances_ParentIsAsset_sortByAlias_emptyAlias() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Segments, UUID1));
        urlVariables.put("pageSize", 250);

        setupGetChildrenFromPersistence(null,
            readObjectsFromResourceFile(getPredixPath() + "/assetsEmptyAlias.json", Asset.class),
            Prefixes.uri(Prefixes.Segments, UUID1), null);

        Hierarchical[] fetchedInstances = getController().browseAllInstances(Prefixes.uri(Prefixes.Segments, UUID1),
            AssetComponentResolver.ATTRIBUTES, SortByResolver.ALIAS);
        Hierarchical[] expectedInstances = readObjectsFromResourceFile(getOutputPath() + "/assetsEmptyAlias.json",
            Asset.class);

        // Empty alias should not be swapped with name
        Assert.assertArrayEquals(expectedInstances, fetchedInstances);
    }

    @Test(expected = ForbiddenException.class)
    public void browseAllInstances_Error() {
        throwExceptionForGetChildrenFromPersistence(new HttpClientErrorException(HttpStatus.FORBIDDEN), null);
        getController().browseAllInstances(Prefixes.uri(Prefixes.Segments, UUID1), AssetComponentResolver.ATTRIBUTES,
            SortByResolver.NAME);
    }

    @Test
    public void browseAccessibleResources_OneResource() throws IOException {

        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setQuery(Optional.of("uri=" + Prefixes.uri(Prefixes.Segments, UUID1)));

        Segment[] responseObjects = readObjectsFromResourceFile(getPredixPath() + "/accessibleSegment.json",
            Segment.class);

        PowerMockito.doReturn(responseObjects).when(assetService).get(eq(Prefixes.Segments), eq(Segment.class),
            eq(AssetComponentResolver.parseComponents(AssetComponentResolver.PARENT)), eq(queryPredicate),
            eq(new Integer(1000)));

        String[] accessibleResources = new String[1];
        accessibleResources[0] = "/segments/bb571726-c1a3-4610-99de-435ab7f74000";
        setupMockForAccessibleResource(accessibleResources);

        Hierarchical[] fetchedInstances = browseController.accessibleResources();
        Segment[] expectedInstances = readObjectsFromResourceFile(getOutputPath() + "/accessibleResources.json",
            Segment.class);
        expectedInstances = Arrays.stream(expectedInstances).sorted(byName).toArray(Segment[]::new);
        Assert.assertArrayEquals(expectedInstances, fetchedInstances);
    }

    @Test
    public void browseAccessibleResources_MultipleResources() throws IOException {

        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setQuery(Optional.of("uri=" + Prefixes.uri(Prefixes.Segments, UUID1)));

        Segment[] responseSegmentObjects = readObjectsFromResourceFile(getPredixPath() + "/accessibleSegment.json",
            Segment.class);

        PowerMockito.doReturn(responseSegmentObjects).when(assetService).get(eq(Prefixes.Segments), eq(Segment.class),
            eq(AssetComponentResolver.parseComponents(AssetComponentResolver.PARENT)), eq(queryPredicate),
            eq(new Integer(1000)));

        QueryPredicate siteQueryPredicate = new QueryPredicate();
        siteQueryPredicate.setQuery(Optional.of("uri=" + Prefixes.uri(Prefixes.Sites, UUID2)));

        Site[] responseSiteObjects = readObjectsFromResourceFile(getPredixPath() + "/accessibleSiteV1.json",
            Site.class);

        PowerMockito.doReturn(responseSiteObjects).when(assetService).get(eq(Prefixes.Sites), eq(Site.class),
            eq(AssetComponentResolver.parseComponents(AssetComponentResolver.PARENT)), eq(siteQueryPredicate),
            eq(new Integer(1000)));

        String[] accessibleResources = new String[2];
        accessibleResources[0] = "/segments/bb571726-c1a3-4610-99de-435ab7f74000";
        accessibleResources[1] = "/sites/bb571726-c1a3-4610-99de-435ab7f74001";
        setupMockForAccessibleResource(accessibleResources);

        Hierarchical[] fetchedInstances = getController().accessibleResources();
        Site[] expectedSite = readObjectsFromResourceFile(getOutputPath() + "/accessibleResourcesAdditional.json",
            Site.class);
        expectedSite = Arrays.stream(expectedSite).sorted(byName).toArray(Site[]::new);
        Segment[] expectedSegment = readObjectsFromResourceFile(getOutputPath() + "/accessibleResources.json",
            Segment.class);
        expectedSegment = Arrays.stream(expectedSegment).sorted(byName).toArray(Segment[]::new);
        Assert.assertEquals(expectedSegment[0], fetchedInstances[0]);
        Assert.assertEquals(expectedSite[0], fetchedInstances[1]);
    }

    @Test
    public void browseAccessibleResources_RedundantResources() throws IOException {

        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setQuery(Optional.of("uri=" + Prefixes.uri(Prefixes.Segments, UUID1)));

        Segment[] responseObjects = readObjectsFromResourceFile(getPredixPath() + "/accessibleSegment.json",
            Segment.class);

        PowerMockito.doReturn(responseObjects).when(assetService).get(eq(Prefixes.Segments), eq(Segment.class),
            eq(AssetComponentResolver.parseComponents(AssetComponentResolver.PARENT)), eq(queryPredicate),
            eq(new Integer(1000)));

        String[] accessibleResources = new String[2];
        accessibleResources[0] = "/segments/bb571726-c1a3-4610-99de-435ab7f74000";
        accessibleResources[1] = "/segments/bb571726-c1a3-4610-99de-435ab7f74000";
        setupMockForAccessibleResource(accessibleResources);

        Hierarchical[] fetchedInstances = getController().accessibleResources();
        Segment[] expectedInstances = readObjectsFromResourceFile(getOutputPath() + "/accessibleResources.json",
            Segment.class);
        expectedInstances = Arrays.stream(expectedInstances).sorted(byName).toArray(Segment[]::new);
        Assert.assertArrayEquals(expectedInstances, fetchedInstances);
    }

    @Test(expected = ForbiddenException.class)
    public void accessibleResourcesWithNullUris() {
        setupMockForAccessibleResource(null);
        getController().accessibleResources();
    }

    @Test(expected = ForbiddenException.class)
    public void accessibleResourcesV2WithNullUris() {
        setupMockForAccessibleResource(null);
        getController().accessibleResourcesV2();
    }

    @Test
    public void browseAccessibleResources_AllResources() {
        String[] accessibleResources = new String[1];
        accessibleResources[0] = "*";
        setupMockForAccessibleResource(accessibleResources);

        Hierarchical[] fetchedInstances = getController().accessibleResources();
        Assert.assertArrayEquals(new Hierarchical[0], fetchedInstances);
    }

    @Test(expected = BadRequestException.class)
    public void browseAllInstancesV2_ParentValueEmptyString() {
        getController().browseAllInstancesV2("", SortByResolver.NAME);
    }

    @Test(expected = BadRequestException.class)
    public void browseAllInstancesV2_ParentValueNull() {
        getController().browseAllInstancesV2(null, SortByResolver.NAME);
    }

    @Test
    public void browseAllInstancesV2_ParentAsTenant() throws IOException {
        String[] accessibleResources = new String[1];
        accessibleResources[0] = IAlmPersistenceService.ALL_RESOURCES[0];
        setupMockForAccessibleResource(accessibleResources);

        Mockito.when(RequestContext.get(RequestContext.TENANT_UUID, String.class)).thenReturn("mockedTenant");
        Enterprise[] responseObjects = readObjectsFromResourceFile(getPredixPath() + "/accessibleEnterprise.json",
            Enterprise.class);
        List<String> components = AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC);

        PowerMockito.doReturn(responseObjects).when(assetService).get(eq(Prefixes.Enterprises), eq(Enterprise.class),
            eq(AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC)), eq(false), eq(new Integer(1000)));
        NodeData nodeData = getController().browseAllInstancesV2("mockedTenant", SortByResolver.NAME);
        NodeData[] expectedNodeData = readObjectsFromResourceFile(getOutputPath() + "/enterpriseAndSiteAsNode.json",
            NodeData.class);
        Assert.assertEquals((expectedNodeData[0].getData()).toArray()[0], nodeData.getData().toArray()[0]);
    }

    @Test
    public void browseAllInstancesV2_ParentIsEnterpriseAndSiteHasNoChildren_withTenantAdminPrivileges()
        throws IOException {
        setupMockForAccessibleResource(IAlmPersistenceService.ALL_RESOURCES);
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID1));
        urlVariables.put("pageSize", 250);

        Map<String, Object> siteVariables = new HashMap<>();
        siteVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID1));
        siteVariables.put("pageSize", 249);

        Map<String, Object> urlVariablesForSite1 = new HashMap<>();
        urlVariablesForSite1.put("filter", "parent=" + Prefixes.uri(Prefixes.Sites, UUID1));
        urlVariablesForSite1.put("pageSize", 250);

        setupGetChildrenFromPersistence(null,
            readObjectsFromResourceFile(getPredixPath() + "/accessibleEnterprise.json", Enterprise.class),
            Prefixes.uri(Prefixes.Enterprises, UUID1), null);

        NodeData nodeData = getController().browseAllInstancesV2(Prefixes.uri(Prefixes.Enterprises, UUID1),
            SortByResolver.NAME);
        NodeData[] expectedNodeData = readObjectsFromResourceFile(getOutputPath() + "/enterpriseAndSiteAsNode.json",
            NodeData.class);
        Assert.assertEquals((expectedNodeData[0].getData()).toArray()[0], nodeData.getData().toArray()[0]);
    }

    @Test
    public void browseAllInstancesV2_ParentIsEnterpriseAndSiteHasChildren_withTenantAdminPrivileges()
        throws IOException {
        setupMockForAccessibleResource(IAlmPersistenceService.ALL_RESOURCES);
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID1));
        urlVariables.put("pageSize", 250);

        Map<String, Object> siteVariables = new HashMap<>();
        siteVariables.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID1));
        siteVariables.put("pageSize", 249);

        Map<String, Object> urlVariablesForSite1 = new HashMap<>();
        urlVariablesForSite1.put("filter", "parent=" + Prefixes.uri(Prefixes.Sites, UUID1));
        urlVariablesForSite1.put("pageSize", 250);

        setupGetChildrenFromPersistence(null,
            readObjectsFromResourceFile(getPredixPath() + "/accessibleEnterprise.json", Enterprise.class),
            Prefixes.uri(Prefixes.Enterprises, UUID1), null);

        NodeData nodeData = getController().browseAllInstancesV2(Prefixes.uri(Prefixes.Enterprises, UUID1),
            SortByResolver.NAME);
        NodeData[] expectedNodeData = readObjectsFromResourceFile(getOutputPath() + "/enterpriseAndSiteAsNode.json",
            NodeData.class);
        Assert.assertEquals((expectedNodeData[0].getData()).toArray()[0], nodeData.getData().toArray()[0]);
    }

    @Test
    public void browseAllInstancesV2_withParentAsEnterprise_withAccessToSegment() throws IOException {
        setupMockForAccessibleResource(new String[] { Prefixes.uri(Prefixes.Segments, UUID1) });
        Map<String, Object> urlVariables1 = new HashMap<>();
        urlVariables1.put("pageSize", 1);

        urlVariables1 = new HashMap<>();
        urlVariables1.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID1));
        urlVariables1.put("pageSize", 249);

        urlVariables1 = new HashMap<>();
        urlVariables1.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID1));
        urlVariables1.put("pageSize", 250);

        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Enterprises, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/accessibleEnterprise.json", Enterprise.class)[0], true);

        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Segments, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/accessibleSegment.json", Segment.class)[0], true);

        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Sites, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/accessibleSite.json", Site.class)[0], true);

        setupGetChildrenFromPersistence(null,
            readObjectsFromResourceFile(getPredixPath() + "/accessibleSite.json", Site.class),
            Prefixes.uri(Prefixes.Enterprises, UUID1), null);

        NodeData nodeData = getController().browseAllInstancesV2(Prefixes.uri(Prefixes.Enterprises, UUID1),
            SortByResolver.NAME);
        NodeData[] expectedNodeData = readObjectsFromResourceFile(
            getOutputPath() + "/sitesAsNodeDataWithChildrenButNotOpenable.json", NodeData.class);
        Assert.assertEquals((expectedNodeData[0].getData()).toArray()[0], nodeData.getData().toArray()[0]);
    }

    @Test
    public void browseAllInstancesV2_withParentAsSite_withAccessToSegment() throws IOException {
        setupMockForAccessibleResource(new String[] { Prefixes.uri(Prefixes.Segments, UUID1) });
        Map<String, Object> urlVariables1 = new HashMap<>();
        urlVariables1.put("pageSize", 1);

        urlVariables1 = new HashMap<>();
        urlVariables1.put("filter", "parent=" + Prefixes.uri(Prefixes.Sites, UUID1));
        urlVariables1.put("pageSize", 250);
        urlVariables1 = new HashMap<>();
        urlVariables1.put("filter", "parent=" + Prefixes.uri(Prefixes.Sites, UUID1));
        urlVariables1.put("pageSize", 249);
        urlVariables1 = new HashMap<>();
        urlVariables1.put("filter", "parent=" + Prefixes.uri(Prefixes.Sites, UUID1));
        urlVariables1.put("pageSize", 248);

        urlVariables1 = new HashMap<>();
        urlVariables1.put("filter", "parent=" + Prefixes.uri(Prefixes.Sites, UUID1));
        urlVariables1.put("pageSize", 250);

        setupGetChildrenFromPersistence(null,
            readObjectsFromResourceFile(getPredixPath() + "/accessibleSegment.json", Segment.class),
            Prefixes.uri(Prefixes.Sites, UUID1), null);

        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Sites, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/accessibleSite.json", Site.class)[0], true);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Enterprises, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/accessibleEnterprise.json", Enterprise.class)[0], true);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Segments, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/accessibleSegment.json", Segment.class)[0], true);

        NodeData nodeData = getController().browseAllInstancesV2(Prefixes.uri(Prefixes.Sites, UUID1),
            SortByResolver.NAME);
        NodeData[] expectedNodeData = readObjectsFromResourceFile(
            getOutputPath() + "/segmentAsNodeDataWithNoChildrenButOpenable.json", NodeData.class);
        Assert.assertEquals(expectedNodeData[0].getData().toArray()[0], nodeData.getData().toArray()[0]);
    }

    @Test
    public void browseAllInstancesV2_withParentAsAssetWithInAccessibeSegment() throws IOException {
        setupMockForAccessibleResource(
            new String[] { Prefixes.uri(Prefixes.Segments, UUID1), Prefixes.uri(Prefixes.Assets, UUID2) });
        Map<String, Object> urlVariables1 = new HashMap<>();
        urlVariables1.put("pageSize", 1);

        Asset[] assetObjects = readObjectsFromResourceFile(getPredixPath() + "/accessibleAsset2.json", Asset.class);
        PowerMockito.doReturn(assetObjects[0]).when(assetService).getSingle(eq(Prefixes.uri(Prefixes.Assets, UUID2)),
            eq(Asset.class), eq(AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC)), eq(true));

        urlVariables1 = new HashMap<>();
        urlVariables1.put("filter", "parent=" + Prefixes.uri(Prefixes.Assets, UUID1));
        urlVariables1.put("pageSize", 250);
        urlVariables1 = new HashMap<>();
        urlVariables1.put("pageSize", 1);
        urlVariables1 = new HashMap<>();
        urlVariables1.put("filter", "parent=" + Prefixes.uri(Prefixes.Assets, UUID2));
        urlVariables1.put("pageSize", 250);

        setupGetChildrenFromPersistence(Prefixes.Assets,
            readObjectsFromResourceFile(getPredixPath() + "/accessibleAsset2.json", Asset.class),
            Prefixes.uri(Prefixes.Assets, UUID1), Asset.class);
        setupGetChildrenFromPersistence(Prefixes.Assets, new Asset[0], Prefixes.uri(Prefixes.Assets, UUID2),
            Asset.class);

        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Sites, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/accessibleSite.json", Site.class)[0], true);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Enterprises, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/accessibleEnterprise.json", Enterprise.class)[0], true);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Segments, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/accessibleSegment.json", Segment.class)[0], true);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Assets, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/accessibleAsset.json", Asset.class)[0], true);

        NodeData nodeData = getController().browseAllInstancesV2(Prefixes.uri(Prefixes.Assets, UUID1),
            SortByResolver.NAME);
        NodeData[] expectedNodeData = readObjectsFromResourceFile(
            getOutputPath() + "/assetAsNodeDataWithNoChildrenButOpenable.json", NodeData.class);
        Assert.assertEquals(expectedNodeData[0], nodeData);
    }

    @Test
    public void accessibleResource_WithTenantAdminPrivileges() throws IOException {
        setupMockForAccessibleResource(IAlmPersistenceService.ALL_RESOURCES);
        Map<String, Object> urlVariables1 = new HashMap<>();
        urlVariables1.put("pageSize", 250);

        urlVariables1 = new HashMap<>();
        urlVariables1.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID1));
        urlVariables1.put("pageSize", 250);
        urlVariables1 = new HashMap<>();
        urlVariables1.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID2));
        urlVariables1.put("pageSize", 250);

        NodeData actualNodeData = getController().accessibleResourcesV2();
        NodeData[] expectedNodeData = readObjectsFromResourceFile(getOutputPath() + "/enterprisesAsNodeData.json",
            NodeData.class);
        Assert.assertEquals(expectedNodeData[0], actualNodeData);
    }

    @Test
    public void accessibleResource_WithNonAdminPrivileges_withAccessToSite0InEnterprise0() throws IOException {
        setupMockForAccessibleResource(new String[] { Prefixes.uri(Prefixes.Sites, UUID1) });

        Map<String, Object> urlVariables1 = new HashMap<>();
        urlVariables1.put("pageSize", 1);

        urlVariables1 = new HashMap<>();
        urlVariables1.put("pageSize", 1);
        urlVariables1 = new HashMap<>();
        urlVariables1.put("filter", "parent=" + Prefixes.uri(Prefixes.Enterprises, UUID1));
        urlVariables1.put("pageSize", 250);

        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Enterprises, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/accessibleEnterprise.json", Enterprise.class)[0], true);

        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Sites, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/accessibleSite.json", Site.class)[0], true);

        NodeData actualNodeData = getController().accessibleResourcesV2();
        NodeData[] expectedNodeData = readObjectsFromResourceFile(
            getOutputPath() + "/enterprisesAsNodeDataWithAccessToSite.json", NodeData.class);
        Assert.assertEquals(expectedNodeData[0], actualNodeData);
    }

    @Override
    public Class<Enterprise> getObjectClass() {
        return Enterprise.class;
    }

    @Override
    public BrowseController getController() {
        return browseController;
    }

    @Override
    public String getPredixPath() {
        return "/predix/browse";
    }

    @Override
    public String getOutputPath() {
        return "/output/browse";
    }

    @Override
    public String getTypePrefix() {
        return null;
    }

    @Override
    public String getPrefix() {
        return null;
    }

    public void setupMockForAccessibleResource(String... mockResponse) {
        Mockito.when(RequestContext.get(IAlmPersistenceService.ACCESSIBLE_RESOURCES, String[].class)).thenReturn(
            mockResponse);
    }
}
