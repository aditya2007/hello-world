/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.network;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
import java.util.Optional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.mock.web.MockHttpServletRequest;

import com.ge.apm.alm.persistence.exceptions.ObjectNotFoundException;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.model.BusinessObject;
import com.ge.apm.asset.model.Direction;
import com.ge.apm.asset.model.Edge;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.Network;
import com.ge.apm.asset.model.NetworkNode;
import com.ge.apm.asset.model.NetworkNode.Category;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ForbiddenException;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;
import com.ge.asset.commons.errorprovider.ErrorConstants;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by 212448111 on 8/3/17.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class })
public class NetworkControllerTest extends AbstractNetworkControllerTest {

    @Test
    public void testCreateNetwork() throws IOException {

        Network[] objects = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());

        setupCreateToPersistence(objects);

        Network[] createdObjects = getController().create(Arrays.asList(objects));
        Network[] expectedCreatedObjects = readObjectsFromResourceFile(getOutputPath() + "/create.json",
            getObjectClass());
        Assert.assertArrayEquals(expectedCreatedObjects, createdObjects);
    }

    @Test
    public void testAddNodesToNetwork() throws IOException {

        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        Asset asset1 = new Asset();
        asset1.setSourceKey("Asset_Sample1");

        Asset asset2 = new Asset();
        asset2.setSourceKey("Asset_Sample2");

        Asset[] mockAssetResponse = new Asset[] { asset1, asset2 };

        when(almPersistenceService
            .getBySourceKeys(UUID1, Prefixes.Assets, Asset.class, new String[] { "Asset_Sample1", "Asset_Sample2" }))
            .thenReturn(mockAssetResponse);

        NetworkNode[] networkNodes = readObjectsFromResourceFile(getInputPath() + "/addNodesToNetwork.json",
            NetworkNode.class);

        Mockito.doNothing().when(almPersistenceService).addNodesToNetwork(UUID1, "004066e0-d480-4908-b82d-15af1e4122ab",
            networkNodes);

        networkController.addNodes(UUID1, networkNodes);

        verify(almPersistenceService, times(1)).addNodesToNetwork(UUID1, UUID1, mockAssetResponse);
    }

    @Test
    public void testAddNodesToNetworkWithDecommissionedAsset() throws IOException {

        try {
            Network network = new Network();
            network.setName("network1");
            network.setDescription("network1Description");
            network.setUri("/networks/" + UUID1);
            network.setSourceKey("network1");

            when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
                anyBoolean())).thenReturn(network);

            Asset asset1 = new Asset();
            Map<String, Object> reservedAttrs = new HashMap<>();
            Map<String, Object> keyValuemap = new HashMap<>();
            keyValuemap.put("key", "03");
            reservedAttrs.put("state", keyValuemap);
            asset1.setReservedAttributes(reservedAttrs);
            asset1.setUri("/assets/b18e6bd7-239d-3941-b84a-27644f9cec1b");
            asset1.setSourceKey("Asset_Sample1");

            Asset asset2 = new Asset();
            reservedAttrs = new HashMap<>();
            keyValuemap = new HashMap<>();
            keyValuemap.put("key", "10");
            reservedAttrs.put("state", keyValuemap);
            asset2.setReservedAttributes(reservedAttrs);
            asset2.setUri("/assets/b28e6bd7-239d-3941-b84a-27644f9cec2b");
            asset2.setSourceKey("Asset_Sample2");
            Attributable[] assets = new Attributable[] { asset1, asset2 };

            Asset[] mockAssetResponse = new Asset[] { asset1, asset2 };

            when(almPersistenceService.getBySourceKeys(UUID1, Prefixes.Assets, Asset.class,
                new String[] { "Asset_Sample1", "Asset_Sample2" })).thenReturn(mockAssetResponse);

            NetworkNode[] networkNodes = readObjectsFromResourceFile(getInputPath() + "/addNodesToNetwork.json",
                NetworkNode.class);

            Mockito.doNothing().when(almPersistenceService).addNodesToNetwork(UUID1,
                "004066e0-d480-4908-b82d-15af1e4122ab", networkNodes);

            networkController.addNodes(UUID1, networkNodes);
            Assert.fail("Expecting BadRequestException");
        } catch (Exception ex) {
            Assert.assertTrue(ex instanceof BadRequestException);
            Assert.assertEquals(ErrorConstants.INVALID_ADDITION_OF_NODES_EDGES_TO_NETWORK,
                ((BadRequestException) ex).getCode());
        }
    }

    @Test(expected = BadRequestException.class)
    public void testAddNodesWithoutCategoryToNetwork() {

        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        NetworkNode networkNode1 = new NetworkNode();
        networkNode1.setSourceKey("node1");
        networkController.addNodes(UUID1, networkNode1);
    }

    @Test(expected = BadRequestException.class)
    public void testAddNodesWithInvalidCategoryToNetwork() {
        Network network = new Network();
        network.setName("network2");
        network.setDescription("network2Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network2");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        NetworkNode networkNode1 = new NetworkNode();
        networkNode1.setSourceKey("node1");
        networkNode1.setCategory("TAG");
        networkController.addNodes(UUID1, networkNode1);
    }

    @Test(expected = BadRequestException.class)
    public void testAddNodesWithEmptyNodeSourceKeyToNetwork() {
        Network network = new Network();
        network.setName("network3");
        network.setDescription("network3Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network3");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        NetworkNode networkNode1 = new NetworkNode();
        networkNode1.setCategory(Category.ASSET.name());

        networkController.addNodes(UUID1, networkNode1);
    }

    @Test(expected = BadRequestException.class)
    public void testAddEmptyNodesToNetwork() {

        Network network = new Network();
        network.setName("network3");
        network.setDescription("network3Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network3");

        when(almPersistenceService.getInstanceByUri(anyString(), anyString(), anyBoolean())).thenReturn(network);

        NetworkNode networkNode1 = new NetworkNode();
        networkNode1.setCategory(Category.ASSET.name());

        networkController.addNodes(UUID1, null);
    }

    @Test(expected = BadRequestException.class)
    public void testAddDuplicateNodesToNetwork() {

        Network network = new Network();
        network.setName("network3");
        network.setDescription("network3Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network3");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        NetworkNode networkNode1 = new NetworkNode();
        networkNode1.setCategory(Category.ASSET.name());
        networkNode1.setSourceKey("node1");

        networkController.addNodes(UUID1, networkNode1, networkNode1);
    }

    @Test(expected = BadRequestException.class)
    public void testAddNonExistenceBusinessObjectAsNodeToNetwork() throws IOException {
        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        Asset asset1 = new Asset();
        asset1.setSourceKey("Asset_Sample1");

        Asset[] mockAssetResponse = new Asset[] { asset1 };

        when(almPersistenceService
            .getBySourceKeys(UUID1, Prefixes.Assets, Asset.class, new String[] { "Asset_Sample1", "Asset_Sample2" }))
            .thenReturn(mockAssetResponse);

        NetworkNode[] networkNodes = readObjectsFromResourceFile(getInputPath() + "/addNodesToNetwork.json",
            NetworkNode.class);

        networkController.addNodes(UUID1, networkNodes);
    }

    @Test
    public void addEdgesToNetwork() throws IOException {

        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(), anyBoolean()))
            .thenReturn(network);

        Asset asset1 = new Asset();
        asset1.setSourceKey("Asset_Sample1");
        asset1.setUri("/assets/f53cbb7a-3d02-440c-8dcd-1263c583385c");

        Asset asset2 = new Asset();
        asset2.setSourceKey("Asset_Sample2");
        asset2.setUri("/assets/10cbf6ee-a96a-4ab4-8754-95a73a6b3eff");

        Asset asset3 = new Asset();
        asset3.setSourceKey("Asset_Sample3");
        asset3.setUri("/assets/611c053c-dfef-4bf0-a6fc-50e0f6867b34");

        Asset[] mockResponse1 = new Asset[] { asset1, asset2 };

        Asset[] mockResponse2 = new Asset[] { asset3 };

        when(almPersistenceService
            .getBySourceKeys(UUID1, Prefixes.Assets, Asset.class, new String[] { "Asset_Sample1", "Asset_Sample2" }))
            .thenReturn(mockResponse1);

        when(almPersistenceService
            .getBySourceKeys(UUID1, Prefixes.Assets, Asset.class, new String[] { "Asset_Sample3" })).thenReturn(
            mockResponse2);

        Edge[] edges = readObjectsFromResourceFile(getInputPath() + "/addEdgesToNetwork.json", Edge.class);

        Mockito.doNothing().when(almPersistenceService).addEdgesToNetwork(UUID1, "004066e0-d480-4908-b82d-15af1e4122ab",
            edges);

        networkController.addEdges(UUID1, edges);

        verify(almPersistenceService, times(1)).addEdgesToNetwork(UUID1, UUID1, edges);
    }

    @Test
    public void addEdgesToNetworkWithDecommissionedAsset() throws IOException {

        try {
            Network network = new Network();
            network.setName("network1");
            network.setDescription("network1Description");
            network.setUri("/networks/" + UUID1);
            network.setSourceKey("network1");

            when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
                anyBoolean())).thenReturn(network);

            Asset asset1 = new Asset();
            asset1.setSourceKey("Asset_Sample1");
            asset1.setUri("/assets/f53cbb7a-3d02-440c-8dcd-1263c583385c");

            Asset asset2 = new Asset();
            asset2.setSourceKey("Asset_Sample2");
            asset2.setUri("/assets/10cbf6ee-a96a-4ab4-8754-95a73a6b3eff");

            Asset asset3 = new Asset();
            asset3.setSourceKey("Asset_Sample3");
            asset3.setUri("/assets/611c053c-dfef-4bf0-a6fc-50e0f6867b34");
            Map<String, Object> reservedAttrs = new HashMap<>();
            Map<String, Object> keyValuemap = new HashMap<>();
            keyValuemap.put("key", "10");
            reservedAttrs.put("state", keyValuemap);
            asset3.setReservedAttributes(reservedAttrs);
            asset3.setUri("/assets/b28e6bd7-239d-3941-b84a-27644f9cec2b");

            Asset[] mockResponse1 = new Asset[] { asset1, asset2 };

            Asset[] mockResponse2 = new Asset[] { asset3 };

            when(almPersistenceService.getBySourceKeys(UUID1, Prefixes.Assets, Asset.class,
                new String[] { "Asset_Sample1", "Asset_Sample2" })).thenReturn(mockResponse1);

            when(almPersistenceService
                .getBySourceKeys(UUID1, Prefixes.Assets, Asset.class, new String[] { "Asset_Sample3" })).thenReturn(
                mockResponse2);

            Edge[] edges = readObjectsFromResourceFile(getInputPath() + "/addEdgesToNetwork.json", Edge.class);

            Mockito.doNothing().when(almPersistenceService).addEdgesToNetwork(UUID1,
                "004066e0-d480-4908-b82d-15af1e4122ab", edges);

            networkController.addEdges(UUID1, edges);
            Assert.fail("Expecting BadRequestException");
        } catch (Exception ex) {
            Assert.assertTrue(ex instanceof BadRequestException);
            Assert.assertEquals(ErrorConstants.INVALID_ADDITION_OF_NODES_EDGES_TO_NETWORK,
                ((BadRequestException) ex).getCode());
        }
    }

    @Test(expected = BadRequestException.class)
    public void addEdgesToNetworkWithoutTargetNode() {

        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        NetworkNode source = new NetworkNode();
        source.setSourceKey("node1");
        source.setCategory(Category.ASSET.name());

        Edge edge = new Edge();
        edge.setName("edge1");
        edge.setSourceKey("edge1");
        edge.setSource(source);

        BusinessObject businessObject = new BusinessObject();
        businessObject.setSourceKey("asset1");
        businessObject.setCategory(Category.ASSET.name());
        edge.setBusinessObject(businessObject);
        networkController.addEdges(UUID1, edge);
    }

    @Test(expected = BadRequestException.class)
    public void addEdgesWithInvalidBusinessObjectCategory() {
        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        NetworkNode source = new NetworkNode();
        source.setSourceKey("node1");
        source.setCategory(Category.ASSET.name());

        NetworkNode target = new NetworkNode();
        target.setSourceKey("node2");
        target.setCategory(Category.ASSET.name());

        Edge edge = new Edge();
        edge.setName("edge1");
        edge.setSourceKey("edge1");
        edge.setSource(source);
        edge.setTarget(target);
        edge.setDirection(Direction.UNIDIRECTIONAL);

        BusinessObject businessObject = new BusinessObject();
        businessObject.setSourceKey("asset1");
        businessObject.setCategory(Category.NETWORK.name());
        edge.setBusinessObject(businessObject);
        networkController.addEdges(UUID1, edge);
    }

    @Test(expected = BadRequestException.class)
    public void addEdgesWithMissingBusinessObjectCategory() {

        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        NetworkNode source = new NetworkNode();
        source.setSourceKey("node1");
        source.setCategory(Category.ASSET.name());

        NetworkNode target = new NetworkNode();
        target.setSourceKey("node2");
        target.setCategory(Category.ASSET.name());

        Edge edge = new Edge();
        edge.setName("edge1");
        edge.setSourceKey("edge1");
        edge.setSource(source);
        edge.setTarget(target);
        edge.setDirection(Direction.UNIDIRECTIONAL);

        BusinessObject businessObject = new BusinessObject();
        businessObject.setSourceKey("asset1");
        edge.setBusinessObject(businessObject);
        networkController.addEdges(UUID1, edge);
    }

    private void setupEdgeForUpdate() {
        NetworkNode source = new NetworkNode();
        source.setSourceKey("node1");
        source.setCategory(Category.ASSET.name());

        NetworkNode target = new NetworkNode();
        target.setSourceKey("node2");
        target.setCategory(Category.ASSET.name());

        Edge edge = new Edge();
        edge.setName("edge1");
        edge.setSourceKey("edge1");
        edge.setSource(source);
        edge.setTarget(target);
        edge.setDirection(Direction.UNIDIRECTIONAL);

        when(almPersistenceService.getEdgeFromNetwork(anyString(), anyString(), anyString(), anyObject())).thenReturn(
            edge);
    }

    @Test
    public void updateEdgeWithValidOps() {
        setupEdgeForUpdate();
        PatchOperation[] patchOps = { new PatchOperation("add", "/name", (Object) "updated_name"), new PatchOperation(
            "add", "/description", (Object) "updated_description"), new PatchOperation("add", "/reservedAttributes",
            (Object) null), new PatchOperation("add", "/attributes", (Object) null), };
        networkController.updateEdge(UUID1, UUID2, patchOps);
    }

    @Test(expected = BadRequestException.class)
    public void updateEdgeWithInvalidOps() {
        setupEdgeForUpdate();
        PatchOperation[] patchOps = { new PatchOperation("remove", "/name", (Object) "updated_name") };
        networkController.updateEdge(UUID1, UUID2, patchOps);
    }

    @Test(expected = BadRequestException.class)
    public void updateEdgeWithInvalidOps2() {
        setupEdgeForUpdate();
        PatchOperation[] patchOps = { new PatchOperation("replace", "/source", (Object) ""), new PatchOperation(
            "replace", "/target", (Object) ""), new PatchOperation("replace", "/businessObject", (Object) "") };
        networkController.updateEdge(UUID1, UUID2, patchOps);
    }

    @Test(expected = BadRequestException.class)
    public void updateEdgeWithInvalidOps3() {
        setupEdgeForUpdate();
        PatchOperation[] patchOps = { new PatchOperation("remove", "/source", (Object) ""), new PatchOperation("remove",
            "/target", (Object) ""), new PatchOperation("remove", "/businessObject", (Object) "") };
        networkController.updateEdge(UUID1, UUID2, patchOps);
    }

    @Test
    public void testGetNetworkNodes() throws IOException {
        NetworkNode[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/nodes.json",
            NetworkNode.class);

        when(almPersistenceService
            .findAllByPrefix(anyString(), eq(Prefixes.Nodes), anyObject(), eq(NetworkNode.class), anyBoolean(),
                anyBoolean())).thenReturn(expectedFetchedObjects);

        NetworkNode[] nodes = networkController.getNodes(UUID1, AssetComponentResolver.FULL, 2, "1", null);
        Assert.assertNotNull("Returned nodes are null", nodes);
        Assert.assertNotNull("Returned nodes reserved attributes are null", nodes[0].getReservedAttributes());
    }

    @Test
    public void testGetSubNetworks() throws IOException {
        NetworkNode[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/subNetworks.json",
            NetworkNode.class);

        when(almPersistenceService
            .findAllByPrefix(anyString(), eq(Prefixes.Nodes), anyObject(), eq(NetworkNode.class), anyBoolean(),
                anyBoolean())).thenReturn(expectedFetchedObjects);

        NetworkNode[] nodes = networkController.getNodes(UUID1, AssetComponentResolver.ATTRIBUTES, 2, "1", null);
        Assert.assertNotNull("Returned nodes are null", nodes);
        Assert.assertNotNull("Returned nodes reserved attributes are null", nodes[0].getReservedAttributes());
    }

    @Test
    public void testGetNetworkEdges() throws IOException {
        Edge[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/edges.json", Edge.class);

        when(almPersistenceService
            .findAllByPrefix(anyString(), eq(Prefixes.Edges), anyObject(), eq(Edge.class), anyBoolean(), anyBoolean()))
            .thenReturn(expectedFetchedObjects);

        Edge[] edges = networkController.getEdges(UUID1, AssetComponentResolver.ATTRIBUTES, 2, "1");
        Assert.assertNotNull("Returned edges are null", edges);
        Assert.assertNotNull("Returned edges reserved attributes are null", edges[0].getReservedAttributes());
    }

    @Test
    public void testGetNetworkEdgeByUri() throws IOException {

        Edge edge = new Edge();
        edge.setUri("/e1");
        edge.setName("e1");
        edge.setDirection(Direction.UNIDIRECTIONAL);

        NetworkNode source = new NetworkNode();
        source.setName("a1");
        source.setUri("/a1");
        source.setCategory("ASSET");

        NetworkNode target = new NetworkNode();
        target.setName("a2");
        target.setUri("/a2");
        target.setCategory("ASSET");

        edge.setSource(source);
        edge.setTarget(target);

        BusinessObject businessObject = new BusinessObject();
        businessObject.setName("a3");
        businessObject.setUri("/a3");
        businessObject.setCategory("ASSET");
        edge.setBusinessObject(businessObject);

        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setComponents(Optional.of("FULL"));
        when(almPersistenceService.getEdgeFromNetwork(anyString(), anyString(), anyString(), eq(queryPredicate)))
            .thenReturn(edge);

        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        Edge outEdge = networkController.getEdge(UUID1, UUID2, AssetComponentResolver.FULL);
        Assert.assertNotNull("Returned edge is null", outEdge);
        Assert.assertNotNull("Returned edges reserved attributes are null", outEdge.getReservedAttributes());

        QueryPredicate queryPredicate1 = new QueryPredicate();
        queryPredicate1.setComponents(Optional.of("ATTRIBUTES"));
        when(almPersistenceService.getEdgeFromNetwork(anyString(), anyString(), anyString(), eq(queryPredicate1)))
            .thenReturn(edge);

        outEdge = networkController.getEdge(UUID1, UUID2, AssetComponentResolver.ATTRIBUTES);
        Assert.assertNotNull("Returned edge is null", outEdge);
        Assert.assertNotNull("Returned edges reserved attributes are null", outEdge.getReservedAttributes());
    }

    @Test(expected = ForbiddenException.class)
    public void testGetEdgeByUri_nonExistingObject() {

        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setComponents(Optional.of("FULL"));
        when(almPersistenceService.getEdgeFromNetwork(anyString(), anyString(), anyString(), eq(queryPredicate)))
            .thenReturn(null);
        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        networkController.getEdge(UUID1, UUID2, AssetComponentResolver.FULL);
    }

    @Test
    public void testDeleteEdgeByUri() {
        Edge edge = new Edge();
        edge.setUri("/e1");

        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setComponents(Optional.of(AssetComponentResolver.BASIC));
        when(almPersistenceService.getEdgeFromNetwork(anyString(), anyString(), anyString(), eq(queryPredicate)))
            .thenReturn(edge);
        doNothing().when(almPersistenceService).deleteEdgeFromNetwork(anyString(), anyString());

        networkController.deleteEdge(UUID1, UUID2);
    }

    @Test(expected = NotFoundException.class)
    public void testDeleteEdgeByUri_NonExisting() {
        Edge edge = new Edge();
        edge.setUri("/e1");

        doNothing().when(almPersistenceService).deleteEdgeFromNetwork(anyString(), anyString());

        networkController.deleteEdge(UUID1, UUID2);
    }

    @Test()
    public void testDeleteNodesFromNetwork_assetsAndNetworks() {
        String[] urisToDelete = { Prefixes.Assets + "/" + UUID1, Prefixes.Networks + "/" + UUID1 };
        doNothing().when(almPersistenceService).deleteAssetsFromNetwork(anyString(), anyString(), anyList());
        doNothing().when(almPersistenceService).deleteSubNetworkFromNetwork(anyString(), anyString(), anyList());

        networkController.deleteNodesFromNetwork(UUID1, urisToDelete);
    }

    @Test()
    public void testDeleteNodesFromNetwork_assetsOnly() {
        String[] urisToDelete = { Prefixes.Assets + "/" + UUID1, Prefixes.Assets + "/" + UUID2 };
        doNothing().when(almPersistenceService).deleteAssetsFromNetwork(anyString(), anyString(), anyList());

        networkController.deleteNodesFromNetwork(UUID1, urisToDelete);
    }

    @Test()
    public void testDeleteNodesFromNetwork_subnetworksOnly() {
        String[] urisToDelete = { Prefixes.Networks + "/" + UUID1, Prefixes.Networks + "/" + UUID1 };
        doNothing().when(almPersistenceService).deleteSubNetworkFromNetwork(anyString(), anyString(), anyList());

        networkController.deleteNodesFromNetwork(UUID1, urisToDelete);
    }

    @Test(expected = BadRequestException.class)
    public void testDeleteNodesFromNetwork_containInvalidPrefixes() {
        String[] urisToDelete = { "BAD_PREFIX" + "/" + UUID1, Prefixes.Networks + "/" + UUID1 };
        doNothing().when(almPersistenceService).deleteAssetsFromNetwork(anyString(), anyString(), anyList());
        doNothing().when(almPersistenceService).deleteSubNetworkFromNetwork(anyString(), anyString(), anyList());

        networkController.deleteNodesFromNetwork(UUID1, urisToDelete);
    }

    @Test
    public void testDeleteNetworkByUri() {
        Network network = new Network();
        network.setUri("/n1");
        Network[] mockNetworks = new Network[] { network };
        doReturn(mockNetworks).when(almPersistenceService).deleteNetwork(anyString(), anyString());
        networkController.deleteNetwork(UUID1, UUID2);
    }

    @Test(expected = ObjectNotFoundException.class)
    public void testDeleteNetworkByUri_NonExisting() {
        Network network = new Network();
        network.setUri("/n1");
        doThrow(ObjectNotFoundException.class).when(almPersistenceService).deleteNetwork(anyString(), anyString());
        networkController.deleteNetwork(UUID1, UUID2);
    }

    @Test
    public void testAddNodesToNetwork_Segments() throws IOException {

        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        Segment segment1 = new Segment();
        segment1.setSourceKey("Segment_Sample1");

        Segment segment2 = new Segment();
        segment2.setSourceKey("Segment_Sample2");

        Segment[] mockSegmentResponse = new Segment[] { segment1, segment2 };

        when(almPersistenceService.getBySourceKeys(UUID1, Prefixes.Segments, Segment.class,
            new String[] { "Segment_Sample1", "Segment_Sample2" })).thenReturn(mockSegmentResponse);

        NetworkNode networkNode1 = new NetworkNode();
        networkNode1.setSourceKey("Segment_Sample1");
        networkNode1.setCategory("SEGMENT");

        NetworkNode networkNode2 = new NetworkNode();
        networkNode2.setSourceKey("Segment_Sample2");
        networkNode2.setCategory("SEGMENT");

        NetworkNode[] networkNodes = new NetworkNode[] { networkNode1, networkNode2 };

        Mockito.doNothing().when(almPersistenceService).addNodesToNetwork(UUID1, "004066e0-d480-4908-b82d-15af1e4122ab",
            networkNodes);

        networkController.addNodes(UUID1, networkNodes);

        verify(almPersistenceService, times(1)).addNodesToNetwork(UUID1, UUID1, mockSegmentResponse);
    }

    @Test
    public void testAddNodesToNetwork_Sites() throws IOException {

        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        Site site1 = new Site();
        site1.setSourceKey("Site_Sample1");

        Site site2 = new Site();
        site2.setSourceKey("Site_Sample2");

        Site[] mockSiteResponse = new Site[] { site1, site2 };

        when(almPersistenceService
            .getBySourceKeys(UUID1, Prefixes.Sites, Site.class, new String[] { "Site_Sample1", "Site_Sample2" }))
            .thenReturn(mockSiteResponse);

        NetworkNode networkNode1 = new NetworkNode();
        networkNode1.setSourceKey("Site_Sample1");
        networkNode1.setCategory("SITE");

        NetworkNode networkNode2 = new NetworkNode();
        networkNode2.setSourceKey("Site_Sample2");
        networkNode2.setCategory("SITE");

        NetworkNode[] networkNodes = new NetworkNode[] { networkNode1, networkNode2 };

        Mockito.doNothing().when(almPersistenceService).addNodesToNetwork(UUID1, "004066e0-d480-4908-b82d-15af1e4122ab",
            networkNodes);

        networkController.addNodes(UUID1, networkNodes);

        verify(almPersistenceService, times(1)).addNodesToNetwork(UUID1, UUID1, mockSiteResponse);
    }

    @Test
    public void testAddNodesToNetwork_Enterprises() throws IOException {

        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        Enterprise e1 = new Enterprise();
        e1.setSourceKey("Enterprise_Sample1");

        Enterprise e2 = new Enterprise();
        e2.setSourceKey("Enterprise_Sample2");

        Enterprise[] mockSiteResponse = new Enterprise[] { e1, e2 };

        when(almPersistenceService.getBySourceKeys(UUID1, Prefixes.Enterprises, Enterprise.class,
            new String[] { "Enterprise_Sample1", "Enterprise_Sample2" })).thenReturn(mockSiteResponse);

        NetworkNode networkNode1 = new NetworkNode();
        networkNode1.setSourceKey("Enterprise_Sample1");
        networkNode1.setCategory("ENTERPRISE");

        NetworkNode networkNode2 = new NetworkNode();
        networkNode2.setSourceKey("Enterprise_Sample2");
        networkNode2.setCategory("ENTERPRISE");

        NetworkNode[] networkNodes = new NetworkNode[] { networkNode1, networkNode2 };

        Mockito.doNothing().when(almPersistenceService).addNodesToNetwork(UUID1, "004066e0-d480-4908-b82d-15af1e4122ab",
            networkNodes);

        networkController.addNodes(UUID1, networkNodes);

        verify(almPersistenceService, times(1)).addNodesToNetwork(UUID1, UUID1, mockSiteResponse);
    }

    @Test
    public void testAddNodesToNetwork_Networks() throws IOException {

        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        Network n1 = new Network();
        n1.setSourceKey("Network_Sample1");

        Network n2 = new Network();
        n2.setSourceKey("Network_Sample2");

        Network[] mockNetworkResponse = new Network[] { n1, n2 };

        when(almPersistenceService.getBySourceKeys(UUID1, Prefixes.Networks, Network.class,
            new String[] { "Network_Sample1", "Network_Sample2" })).thenReturn(mockNetworkResponse);

        NetworkNode networkNode1 = new NetworkNode();
        networkNode1.setSourceKey("Network_Sample1");
        networkNode1.setCategory("NETWORK");

        NetworkNode networkNode2 = new NetworkNode();
        networkNode2.setSourceKey("Network_Sample2");
        networkNode2.setCategory("NETWORK");

        NetworkNode[] networkNodes = new NetworkNode[] { networkNode1, networkNode2 };

        Mockito.doNothing().when(almPersistenceService).addNodesToNetwork(UUID1, "004066e0-d480-4908-b82d-15af1e4122ab",
            networkNodes);

        networkController.addNodes(UUID1, networkNodes);

        verify(almPersistenceService, times(1)).addNodesToNetwork(UUID1, UUID1, mockNetworkResponse);
    }

    @Test(expected = NotFoundException.class)
    public void testAddNodesToNetwork_NonExistingNetwork() throws IOException {
        Mockito.doThrow(NotFoundException.class).when(almPersistenceService).getAssetInstanceByUri(anyString(),
            anyString(), anyBoolean(), any(), anyBoolean());
        NetworkNode[] networkNodes = readObjectsFromResourceFile(getInputPath() + "/addNodesToNetwork.json",
            NetworkNode.class);
        networkController.addNodes(UUID1, networkNodes);
    }

    @Test(expected = BadRequestException.class)
    public void addEdgesToNetwork_InvalidNodeCategory1() throws IOException {

        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        Edge edge1 = new Edge();
        edge1.setName("e1");
        edge1.setDirection(Direction.UNIDIRECTIONAL);

        NetworkNode source = new NetworkNode();
        source.setSourceKey("a1");
        source.setCategory("ASSET");

        NetworkNode target = new NetworkNode();
        target.setSourceKey("n1");
        target.setCategory("NETWORK");

        edge1.setSource(source);
        edge1.setTarget(target);

        Edge[] edges = new Edge[] { edge1 };

        Mockito.doNothing().when(almPersistenceService).addEdgesToNetwork(UUID1, "004066e0-d480-4908-b82d-15af1e4122ab",
            edges);

        networkController.addEdges(UUID1, edges);

        verify(almPersistenceService, times(1)).addEdgesToNetwork(UUID1, UUID1, edges);
    }

    @Test(expected = BadRequestException.class)
    public void addEdgesToNetwork_InvalidNodeCategory2() throws IOException {

        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(),
            anyBoolean())).thenReturn(network);

        Edge edge1 = new Edge();
        edge1.setName("e1");
        edge1.setDirection(Direction.UNIDIRECTIONAL);

        NetworkNode target = new NetworkNode();
        target.setSourceKey("a1");
        target.setCategory("ASSET");

        NetworkNode source = new NetworkNode();
        source.setSourceKey("n1");
        source.setCategory("NETWORK");

        edge1.setSource(source);
        edge1.setTarget(target);

        Edge[] edges = new Edge[] { edge1 };

        Mockito.doNothing().when(almPersistenceService).addEdgesToNetwork(UUID1, "004066e0-d480-4908-b82d-15af1e4122ab",
            edges);

        networkController.addEdges(UUID1, edges);

        verify(almPersistenceService, times(1)).addEdgesToNetwork(UUID1, UUID1, edges);
    }

    @Test(expected = BadRequestException.class)
    public void addEdgesToNetwork_EmptySource() throws IOException {

        Network network = new Network();
        network.setName("network1");
        network.setDescription("network1Description");
        network.setUri("/networks/" + UUID1);
        network.setSourceKey("network1");

        when(almPersistenceService.getAssetInstanceByUri(anyString(), anyString(), anyBoolean(), any(), anyBoolean()))
            .thenReturn(network);

        Edge edge1 = new Edge();
        edge1.setName("e1");
        edge1.setDirection(Direction.UNIDIRECTIONAL);

        NetworkNode target = new NetworkNode();
        target.setSourceKey("a1");
        target.setCategory("ASSET");

        edge1.setTarget(target);

        Edge[] edges = new Edge[] { edge1 };

        Mockito.doNothing().when(almPersistenceService).addEdgesToNetwork(UUID1, "004066e0-d480-4908-b82d-15af1e4122ab",
            edges);

        networkController.addEdges(UUID1, edges);
    }

    @Test(expected = NotFoundException.class)
    public void testAddEdgesToNetwork_NonExistingNetwork() throws IOException {
        Mockito.doThrow(NotFoundException.class).when(almPersistenceService).getAssetInstanceByUri(anyString(),
            anyString(), anyBoolean(), any(), anyBoolean());
        Edge[] edges = readObjectsFromResourceFile(getInputPath() + "/addEdgesToNetwork.json", Edge.class);
        networkController.addEdges(UUID1, edges);
    }

    //Just for Coverage
    @Test(expected = BadRequestException.class)
    public void testUpdateEdge_InvalidUUid() {

        Mockito.doThrow(IllegalArgumentException.class).when(almPersistenceService).getEdgeFromNetwork(anyString(),
            anyString(), anyString(), anyObject());
        PatchOperation[] patchOps = { new PatchOperation("add", "/name", (Object) "updated_name"), new PatchOperation(
            "add", "/description", (Object) "updated_description"), new PatchOperation("add", "/reservedAttributes",
            (Object) null), new PatchOperation("add", "/attributes", (Object) null), };
        networkController.updateEdge(UUID1, UUID2, patchOps);
    }

    //Just for Coverage
    @Test(expected = Exception.class)
    public void testUpdateEdge_Exception() {

        Mockito.doThrow(Exception.class).when(almPersistenceService).getEdgeFromNetwork(anyString(), anyString(),
            anyString(), anyObject());
        PatchOperation[] patchOps = { new PatchOperation("add", "/name", (Object) "updated_name"), new PatchOperation(
            "add", "/description", (Object) "updated_description"), new PatchOperation("add", "/reservedAttributes",
            (Object) null), new PatchOperation("add", "/attributes", (Object) null), };
        networkController.updateEdge(UUID1, UUID2, patchOps);
    }

    @Test(expected = BadRequestException.class)
    public void testGetNetworkNodes_InvalidPageNumber() {
        networkController.getNodes(UUID1, AssetComponentResolver.FULL, 2, "xyz", null);
    }

    //Just for Coverage
    @Test(expected = ServiceException.class)
    public void testGetNetworkNodes_ServiceException() {

        Mockito.doThrow(ServiceException.class).when(almPersistenceService).findAllByPrefix(anyString(),
            eq(Prefixes.Nodes), anyObject(), eq(NetworkNode.class), anyBoolean(), anyBoolean());

        networkController.getNodes(UUID1, AssetComponentResolver.FULL, 2, "1", null);
    }

    //Just for Coverage
    @Test(expected = Exception.class)
    public void testGetNetworkNodes_Exception() {

        Mockito.doThrow(Exception.class).when(almPersistenceService).findAllByPrefix(anyString(), eq(Prefixes.Nodes),
            anyObject(), eq(NetworkNode.class), anyBoolean(), anyBoolean());

        networkController.getNodes(UUID1, AssetComponentResolver.FULL, 2, "1", null);
    }

    @Test(expected = BadRequestException.class)
    public void testGetNetworkEdges_InvalidPageNumber() {
        networkController.getEdges(UUID1, AssetComponentResolver.FULL, 2, "xyz");
    }

    //Just for Coverage
    @Test(expected = ServiceException.class)
    public void testGetNetworkEdges_ServiceException() {

        Mockito.doThrow(ServiceException.class).when(almPersistenceService).findAllByPrefix(anyString(),
            eq(Prefixes.Edges), anyObject(), eq(Edge.class), anyBoolean(), anyBoolean());

        networkController.getEdges(UUID1, AssetComponentResolver.FULL, 2, "1");
    }

    //Just for Coverage
    @Test(expected = Exception.class)
    public void testGetNetworkEdges_Exception() {

        Mockito.doThrow(Exception.class).when(almPersistenceService).findAllByPrefix(anyString(), eq(Prefixes.Nodes),
            anyObject(), eq(NetworkNode.class), anyBoolean(), anyBoolean());

        networkController.getEdges(UUID1, AssetComponentResolver.FULL, 2, "1");
    }
}
