///********************************************************************************
// * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
// *                                                                              *
// * The copyright to the computer software herein is the property of GE Digital. *
// * The software may be used and/or copied only with the written permission of   *
// * GE Digital or in accordance with the terms and conditions stipulated in the  *
// * agreement/contract under which the software has been supplied.               *
// ********************************************************************************/
//
//package com.ge.apm.asset.controller;
//
//import java.io.IOException;
//import java.io.InputStream;
//
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.fasterxml.jackson.databind.node.ArrayNode;
//
//import org.apache.commons.lang3.StringUtils;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.Mock;
//import org.mockito.invocation.InvocationOnMock;
//import org.mockito.runners.MockitoJUnitRunner;
//import org.mockito.stubbing.Answer;
//
//import com.ge.apm.asset.event.handler.EventhubSubscriber;
//import com.ge.apm.asset.event.model.EventHubInfoProvider;
//import com.ge.apm.asset.event.util.EventHubUtil;
//import com.ge.apm.common.support.RequestContext;
//import com.ge.predix.eventhub.EventHubClientException;
//import com.ge.predix.eventhub.client.Client;
//import com.ge.predix.eventhub.configuration.EventHubConfiguration;
//import com.ge.predix.eventhub.configuration.SubscribeConfiguration;
//
//import static org.junit.Assert.assertNotNull;
//import static org.mockito.Mockito.when;
//
///**
// * Created by 212590467 on 3/6/17.
// */
//@RunWith(MockitoJUnitRunner.class)
//public class AssetEventsSubscribeControllerTest {
//
//    @Mock
//    EventhubSubscriber subscriber;
//    @Mock
//    AssetEventsSubscribeController subscribeController;
//
//    @Test
//    public void testSubscribe() throws EventHubClientException {
//        RequestContext.put("tenantUuid", "f743b7ef-42df-4d7e-89dd-90dc3b53b0ac");
//        Client eventHubClient = new Client(constructEventHubConfig(EventHubUtil.SUBSCRIBE_PATH));
//        assertNotNull("Failed to create Eventhub client for fdd5e0ad-8ea3-4c9a-8381-9c98109ebd37", eventHubClient);
//        try {
//            when(subscribeController.subscribe()).thenAnswer(new Answer<Object>() {
//                public String answer(InvocationOnMock invocation) {
//                    //invocation.getMock();
//                    return "Subscription invoked.....";
//                }
//            });
//        } catch(Exception e ){}
//
//    }
//
//    protected EventHubConfiguration constructEventHubConfig(String path) {
//        EventHubConfiguration configuration = null;
//        try {
//            EventHubInfoProvider eventHubInfo = getServiceInstanceInfoProperty(
//                    EventHubUtil.SERVICE_NAME, path, EventHubInfoProvider.class);
//
//            String[] hostPort = null;
//            String authScopes = null;
//            for (EventHubInfoProvider.ProtocolDetails protocol : eventHubInfo.getProtocolDetails()) {
//                if (EventHubUtil.PROTOCOL.equals(protocol.getProtocol())) {
//                    hostPort = getHostAndPort(protocol.getUri());
//                    authScopes = (protocol.getTokenScopes() != null
//                            && protocol.getTokenScopes().size() > 0)
//                            ? String.join(",", protocol.getTokenScopes()) : null;
//                }
//            }
//
//            if (null != hostPort && hostPort.length > 1 && StringUtils.isNotEmpty(authScopes)) {
//                configuration = new EventHubConfiguration.Builder()
//                        .host(hostPort[0])
//                        .port(Integer.parseInt(hostPort[1]))
//                        .zoneID(eventHubInfo.getZoneHeaderValue())
//                        .clientID("12pspvp704hwlacshcbvfwe7mn5qaj90t3kepi")
//                        .clientSecret("zwu8eiug1yvwdxyh6rkdt8rgjdfnjfeu40hyy")
//                        .authURL(
//                                "https://4126b27b-6860-48ee-9dc1-9cba313eac9f.predix-uaa.run.asv-pr.ice.predix
// .io/oauth/token")
//                        .authScopes(authScopes)
//                        .subscribeConfiguration(
//                                new SubscribeConfiguration.Builder()
//                                        .subscriberName("apm-asset-client")
//                                        .subscriberInstance("apm-asset-id").build())
//                        .build();
//            }
//        } catch (EventHubClientException.InvalidConfigurationException eh) {
//            eh.printStackTrace();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        System.out.println(configuration);
//        return configuration;
//    }
//
//    private <T> T getServiceInstanceInfoProperty( String serviceName,
//                                                  String propertyPath,
//                                                  Class<T> targetClass) {
//
//        String effectiveTenantId = (String) RequestContext.get("tenantUuid");
//        ObjectMapper mapper = new ObjectMapper();
//
//        if (effectiveTenantId == null) {
//            throw new RuntimeException("Tenant not found");
//        } else {
//            System.out.println("Getting all service instances in tenant {} " + effectiveTenantId);
//
//            JsonNode tenantInfoNode;
//            try {
//                if( effectiveTenantId.equals("f743b7ef-42df-4d7e-89dd-90dc3b53b0ac") ) {
//                    tenantInfoNode = mapper.readTree(readEventHubInfoFromFile("/sample2_tenant_info.json"));
//                } else if( effectiveTenantId.equals("fdd5e0ad-8ea3-4c9a-8381-9c98109ebd37") ) {
//                    tenantInfoNode = mapper.readTree(readEventHubInfoFromFile("/apmpubsub_tenant_info.json"));
//                } else {
//                    throw new RuntimeException("Error getting service instances in tenant " + effectiveTenantId);
//                }
//            } catch (Throwable var14) {
//                System.out.println("Failed to get service instances for tenant "
//                        + effectiveTenantId + " " + var14.getMessage());
//                throw new RuntimeException("Error getting service instances in tenant " + effectiveTenantId);
//            }
//
//            if (tenantInfoNode == null) {
//                throw new RuntimeException("Cannot find any service instances in tenant " + effectiveTenantId);
//            } else if (serviceName != null && !serviceName.isEmpty()) {
//                System.out.println("Getting service instance info for service {} "
//                        + serviceName + " in tenant {} " + effectiveTenantId);
//                ArrayNode serviceInstancesNode = (ArrayNode) tenantInfoNode.get("serviceInstances");
//                JsonNode serviceInstanceNode = null;
//
//                for (int serviceInstancePropertyNode = 0;
//                     serviceInstancePropertyNode < serviceInstancesNode.size();
//                     ++serviceInstancePropertyNode) {
//                    JsonNode ex = serviceInstancesNode.get(serviceInstancePropertyNode);
//                    JsonNode serviceNameNode = ex.get("serviceName");
//                    if (serviceNameNode != null && serviceName.equals(serviceNameNode.asText())) {
//                        serviceInstanceNode = ex;
//                        break;
//                    }
//                }
//
//                if (serviceInstanceNode == null) {
//                    throw new RuntimeException(
//                            "Cannot find uri/credentials for service \'%s\' in tenant " + effectiveTenantId);
//                } else if (propertyPath == null) {
//                    System.out.println(
//                            "Property name is not specified, so returning the entire service instance info");
//
//                    try {
//                        return mapper.convertValue(serviceInstanceNode, targetClass);
//                    } catch (IllegalArgumentException var12) {
//                        throw new RuntimeException("Unexpected uri/credentials format for service "
//                                + serviceName + " in tenant " + effectiveTenantId);
//                    }
//                } else {
//                    System.out.println(
//                            "Property name {} is specified, so extracting property from service instance info : "
//                                    + propertyPath);
//                    JsonNode var15 = serviceInstanceNode.at(propertyPath);
//                    if (var15 != null && !var15.isMissingNode()) {
//                        try {
//                            return mapper.convertValue(var15, targetClass);
//                        } catch (IllegalArgumentException var13) {
//                            throw new RuntimeException("Unexpected " + propertyPath
//                                    + " format for service " + serviceName + " in tenant " + effectiveTenantId);
//                        }
//                    } else {
//                        throw new RuntimeException("Cannot find " + propertyPath
//                                + " for service " + serviceName + " in tenant " + effectiveTenantId);
//                    }
//
//                }
//            } else {
//                throw new RuntimeException("Invalid service name for getting instance info");
//            }
//        }
//    }
//
//    private String getInstanceType(String uri) {
//        return org.springframework.util.StringUtils.isEmpty(uri)
//                ?  null : "/" + org.apache.commons.lang3.StringUtils.split(uri, "/")[0];
//    }
//
//
//    private InputStream readEventHubInfoFromFile(String filePath ) throws IOException {
//        return this.getClass().getResourceAsStream(filePath);
//    }
//
//
//    private String[] getHostAndPort(String uri) {
//        return uri != null ? uri.split(":") : null;
//    }
//
//
//}
