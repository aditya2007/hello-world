/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAssetConfigService;
import com.ge.apm.asset.service.component.AssetConfigService;
import com.ge.apm.asset.util.ReservedAttributeUtility;

public class ReservedAttributeUtilityTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static final ObjectReader ASSET_TYPE_READER = MAPPER.reader(AssetType.class);

    private List<String> reservedAttributesApplicableResources;

    @Before
    public void setUp() {
        reservedAttributesApplicableResources = new ArrayList<>();
        reservedAttributesApplicableResources.add(Prefixes.Assets);
        reservedAttributesApplicableResources.add(Prefixes.AssetTypes);
        reservedAttributesApplicableResources.add(Prefixes.MeasurementTags);
        reservedAttributesApplicableResources.add(Prefixes.MeasurementTagTypes);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testUpdateReservedAttributesConfigForType_updateConfigWithPossibleValues() throws IOException {
        Map<String, ReservedAttributeConfig> reservedAttributeConfigMap = getReservedAttributeConfigMap(
            Prefixes.AssetTypes);
        String filename = "/input/assetTypes/updateReservedAttributeConfigWithRangeOfValues.json";
        AssetType assetType = ASSET_TYPE_READER.readValue(this.getClass().getResourceAsStream(filename));

        List<Object> faultModeValuesFromType = (List<Object>) (assetType.getReservedAttributes().get("faultMode"));
        List<Object> faultModeValuesFromConfigBefore = reservedAttributeConfigMap.get("faultMode").getPossibleValues();

        Assert.assertTrue(faultModeValuesFromConfigBefore.isEmpty());

        ReservedAttributeUtility.mergeReservedAttributesConfigWithTypeConfig(reservedAttributeConfigMap, assetType,
            reservedAttributesApplicableResources);
        IAssetConfigService assetConfigService = new AssetConfigService();
        assetConfigService.updateReservedAttributeConfigForInstanceApplicability(Prefixes.Assets,
            reservedAttributeConfigMap);

        List<Object> faultModeValuesFromConfigAfter = reservedAttributeConfigMap.get("faultMode").getPossibleValues();
        String faultModeArrayTypeAfter = reservedAttributeConfigMap.get("faultMode").getArrayType();
        Assert.assertFalse(faultModeValuesFromConfigAfter.isEmpty());
        Assert.assertEquals(faultModeValuesFromConfigAfter, new ArrayList<Object>(
            faultModeValuesFromType.stream().collect(Collectors.toCollection(LinkedHashSet::new))));
        Assert.assertEquals(faultModeArrayTypeAfter, ReservedAttributeConfig.ArrayTypeEnum.ONE_DIMENSIONAL.name());
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testUpdateReservedAttributesConfigForType_childTypeOverridesValuesFromParentTypeForFaultMode()
        throws IOException {
        Map<String, ReservedAttributeConfig> reservedAttributeConfigMap = getReservedAttributeConfigMap(
            Prefixes.AssetTypes);
        String filename = "/input/assetTypes/updateReservedAttributesConfigWithRangeOfValuesWithParentTypes.json";
        AssetType assetType = ASSET_TYPE_READER.readValue(this.getClass().getResourceAsStream(filename));

        List<Object> faultModeValuesFromChildType = (List<Object>) (assetType.getReservedAttributes().get("faultMode"));
        List<Object> faultModeValuesFromParentType = (List<Object>) (assetType.getParentInfo().getReservedAttributes()
            .get("faultMode"));
        List<Object> faultModeValuesFromGrandparentType = (List<Object>) (assetType.getParentInfo().getParentInfo()
            .getReservedAttributes().get("faultMode"));
        List<Object> faultModeValuesFromConfigBefore = reservedAttributeConfigMap.get("faultMode").getPossibleValues();

        Assert.assertTrue(faultModeValuesFromConfigBefore.isEmpty());

        ReservedAttributeUtility.mergeReservedAttributesConfigWithTypeConfig(reservedAttributeConfigMap, assetType,
            reservedAttributesApplicableResources);
        IAssetConfigService assetConfigService = new AssetConfigService();
        assetConfigService.updateReservedAttributeConfigForInstanceApplicability(Prefixes.Assets,
            reservedAttributeConfigMap);

        List<Object> faultModeValuesFromConfigAfter = reservedAttributeConfigMap.get("faultMode").getPossibleValues();
        String faultModeArrayTypeAfter = reservedAttributeConfigMap.get("faultMode").getArrayType();
        Assert.assertFalse(faultModeValuesFromConfigAfter.isEmpty());
        Assert.assertEquals(faultModeValuesFromConfigAfter, new ArrayList<Object>(
            faultModeValuesFromChildType.stream().collect(Collectors.toCollection(LinkedHashSet::new))));
        Assert.assertNotEquals(faultModeValuesFromConfigAfter, faultModeValuesFromParentType);
        Assert.assertNotEquals(faultModeValuesFromConfigAfter, faultModeValuesFromGrandparentType);
        Assert.assertEquals(faultModeArrayTypeAfter, ReservedAttributeConfig.ArrayTypeEnum.ONE_DIMENSIONAL.name());
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testUpdateReservedAttributesConfigForType_parentTypeHasNoValuesForFaultMode() throws IOException {
        Map<String, ReservedAttributeConfig> reservedAttributeConfigMap = getReservedAttributeConfigMap(
            Prefixes.AssetTypes);
        String filename = "/input/assetTypes/updateReservedAttributesConfigWithRangeOfValuesWithParentTypes.json";
        AssetType assetType = ASSET_TYPE_READER.readValue(this.getClass().getResourceAsStream(filename));

        List<Object> faultModeValuesFromChildType = (List<Object>) (assetType.getReservedAttributes().get("faultMode"));
        List<Object> faultModeValuesFromParentType = (List<Object>) (assetType.getParentInfo().getReservedAttributes()
            .get("faultMode"));
        assetType.getParentInfo().getParentInfo().getReservedAttributes().put("faultMode", new ArrayList<>());
        List<Object> faultModeValuesFromGrandparentType = (List<Object>) (assetType.getParentInfo().getParentInfo()
            .getReservedAttributes().get("faultMode"));
        List<Object> faultModeValuesFromConfigBefore = reservedAttributeConfigMap.get("faultMode").getPossibleValues();

        Assert.assertTrue(faultModeValuesFromConfigBefore.isEmpty());

        ReservedAttributeUtility.mergeReservedAttributesConfigWithTypeConfig(reservedAttributeConfigMap, assetType,
            reservedAttributesApplicableResources);
        IAssetConfigService assetConfigService = new AssetConfigService();
        assetConfigService.updateReservedAttributeConfigForInstanceApplicability(Prefixes.Assets,
            reservedAttributeConfigMap);

        List<Object> faultModeValuesFromConfigAfter = reservedAttributeConfigMap.get("faultMode").getPossibleValues();
        String faultModeArrayTypeAfter = reservedAttributeConfigMap.get("faultMode").getArrayType();
        Assert.assertFalse(faultModeValuesFromConfigAfter.isEmpty());
        Assert.assertEquals(faultModeValuesFromConfigAfter, new ArrayList<Object>(
            faultModeValuesFromChildType.stream().collect(Collectors.toCollection(LinkedHashSet::new))));
        Assert.assertEquals(faultModeArrayTypeAfter, ReservedAttributeConfig.ArrayTypeEnum.ONE_DIMENSIONAL.name());
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testUpdateReservedAttributesConfigForType_childTypeHasNoValuesForFaultMode() throws IOException {
        Map<String, ReservedAttributeConfig> reservedAttributeConfigMap = getReservedAttributeConfigMap(
            Prefixes.AssetTypes);
        String filename = "/input/assetTypes/updateReservedAttributesConfigWithRangeOfValuesWithParentTypes.json";
        AssetType assetType = ASSET_TYPE_READER.readValue(this.getClass().getResourceAsStream(filename));

        assetType.getReservedAttributes().put("faultMode", new ArrayList<>());
        List<Object> faultModeValuesFromChildType = (List<Object>) (assetType.getReservedAttributes().get("faultMode"));
        List<Object> faultModeValuesFromParentType = (List<Object>) (assetType.getParentInfo().getReservedAttributes()
            .get("faultMode"));
        List<Object> faultModeValuesFromGrandparentType = (List<Object>) (assetType.getParentInfo().getParentInfo()
            .getReservedAttributes().get("faultMode"));
        List<Object> faultModeValuesFromConfigBefore = reservedAttributeConfigMap.get("faultMode").getPossibleValues();

        Assert.assertTrue(faultModeValuesFromConfigBefore.isEmpty());

        ReservedAttributeUtility.mergeReservedAttributesConfigWithTypeConfig(reservedAttributeConfigMap, assetType,
            reservedAttributesApplicableResources);
        IAssetConfigService assetConfigService = new AssetConfigService();
        assetConfigService.updateReservedAttributeConfigForInstanceApplicability(Prefixes.Assets,
            reservedAttributeConfigMap);

        List<Object> faultModeValuesFromConfigAfter = reservedAttributeConfigMap.get("faultMode").getPossibleValues();
        String faultModeArrayTypeAfter = reservedAttributeConfigMap.get("faultMode").getArrayType();
        Assert.assertTrue(faultModeValuesFromConfigAfter.isEmpty());
        Assert.assertEquals(faultModeValuesFromConfigAfter, faultModeValuesFromChildType);
        Assert.assertNotEquals(faultModeValuesFromConfigAfter, faultModeValuesFromParentType);
        Assert.assertNotEquals(faultModeValuesFromConfigAfter, faultModeValuesFromGrandparentType);
        Assert.assertEquals(faultModeArrayTypeAfter, ReservedAttributeConfig.ArrayTypeEnum.ONE_DIMENSIONAL.name());
    }

    @Test
    public void testUpdateReservedAttributesConfigForType_noPossibleValuesDefinedInTypeHierarchy() throws IOException {
        Map<String, ReservedAttributeConfig> reservedAttributeConfigMap = getReservedAttributeConfigMap(
            Prefixes.AssetTypes);
        String filename = "/input/assetTypes/updateReservedAttributesConfigWithRangeOfValuesWithParentTypes.json";
        AssetType assetType = ASSET_TYPE_READER.readValue(this.getClass().getResourceAsStream(filename));

        assetType.getReservedAttributes().put("faultMode", new ArrayList<>());
        assetType.getParentInfo().getReservedAttributes().put("faultMode", new ArrayList<>());
        assetType.getParentInfo().getParentInfo().getReservedAttributes().put("faultMode", new ArrayList<>());
        List<Object> faultModeValuesFromConfigBefore = reservedAttributeConfigMap.get("faultMode").getPossibleValues();

        Assert.assertTrue(faultModeValuesFromConfigBefore.isEmpty());

        ReservedAttributeUtility.mergeReservedAttributesConfigWithTypeConfig(reservedAttributeConfigMap, assetType,
            reservedAttributesApplicableResources);
        IAssetConfigService assetConfigService = new AssetConfigService();
        assetConfigService.updateReservedAttributeConfigForInstanceApplicability(Prefixes.Assets,
            reservedAttributeConfigMap);

        List<Object> faultModeValuesFromConfigAfter = reservedAttributeConfigMap.get("faultMode").getPossibleValues();
        String faultModeArrayTypeAfter = reservedAttributeConfigMap.get("faultMode").getArrayType();
        Assert.assertTrue(faultModeValuesFromConfigAfter.isEmpty());
        Assert.assertEquals(faultModeArrayTypeAfter, ReservedAttributeConfig.ArrayTypeEnum.ONE_DIMENSIONAL.name());
    }

    private Map<String, ReservedAttributeConfig> getReservedAttributeConfigMap(String prefix) throws IOException {
        ReservedAttributeConfig[] reservedAttributesConfig = MAPPER.reader(ReservedAttributeConfig[].class).readValue(
            this.getClass().getResourceAsStream("/reservedAttributes" + prefix + ".json"));
        return Arrays.asList(reservedAttributesConfig).stream().collect(
            Collectors.toMap(ReservedAttributeConfig::getName, Function.<ReservedAttributeConfig>identity(), (u, v) -> {
                throw new IllegalStateException(String.format("Duplicate key %s", u));
            }, LinkedHashMap::new));
    }
}