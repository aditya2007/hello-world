/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.segment;

import java.text.ParseException;

import org.junit.Before;

import com.ge.apm.asset.api.base.AbstractInstanceControllerTest;
import com.ge.apm.asset.controller.SegmentController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.ObjectInfo;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.SegmentType;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.util.ReflectionUtils;

public abstract class AbstractSegmentControllerTest extends AbstractInstanceControllerTest<SegmentController, Segment> {

    protected SegmentController segmentController;

    public AbstractSegmentControllerTest() {
        // define an explicit constructor
    }

    protected AbstractSegmentControllerTest(boolean accessControlledTest) {
        super(accessControlledTest);
    }

    public Class<SegmentType> getTypeClass() {
        return SegmentType.class;
    }

    @Override
    public Class<Segment> getObjectClass() {
        return Segment.class;
    }

    @Override
    public SegmentController getController() {
        return segmentController;
    }

    @Override
    public String getTypePrefix() {
        return Prefixes.SegmentTypes;
    }

    @Override
    public String getPrefix() {
        return Prefixes.Segments;
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        segmentController = new SegmentController();
        ReflectionUtils.setField(SegmentController.class, segmentController, "service", assetService);
        ReflectionUtils.setField(SegmentController.class, segmentController, "assetConfigService", assetConfigService);
        ReflectionUtils.setField(SegmentController.class, segmentController, "pageSize", 10);
    }

    public ObjectInfo[] getChildrenInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.Segments, "childSegments.json", Segment.class),
            new ObjectInfo(Prefixes.Assets, "childAssets.json", Asset.class) };
    }

    public ObjectInfo[] getParentInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.Sites, "parentSite.json", Site.class), new ObjectInfo(
            Prefixes.Segments, "parentSegment.json", Segment.class) };
    }
}
