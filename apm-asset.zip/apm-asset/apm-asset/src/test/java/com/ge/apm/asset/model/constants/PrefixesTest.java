/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.model.constants;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.EnterpriseType;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.model.GroupAssociation;
import com.ge.apm.asset.model.GroupType;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.MeasurementTagLookup;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.SegmentType;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.SiteType;

public class PrefixesTest {

    @Test
    public void testUri() {
        String prefix = Prefixes.Assets;
        String uuid = "bb571726-c1a3-4610-99de-435ab7f74000";
        String expectedUri = Prefixes.Assets + "/" + uuid;
        String actualUri = Prefixes.uri(prefix, uuid);
        Assert.assertEquals(expectedUri, actualUri);
    }

    @Test
    public void testGetClass() {
        String uuid = "bb571726-c1a3-4610-99de-435ab7f74000";
        Map<String, Class<?>> uriToClass = new HashMap<>();
        uriToClass.put("/assets/" + uuid, Asset.class);
        uriToClass.put("/segments/" + uuid, Segment.class);
        uriToClass.put("/sites/" + uuid, Site.class);
        uriToClass.put("/enterprises/" + uuid, Enterprise.class);
        uriToClass.put("/tags/" + uuid, MeasurementTag.class);
        uriToClass.put("/assetTypes/" + uuid, AssetType.class);
        uriToClass.put("/segmentTypes/" + uuid, SegmentType.class);
        uriToClass.put("/siteTypes/" + uuid, SiteType.class);
        uriToClass.put("/enterpriseTypes/" + uuid, EnterpriseType.class);
        uriToClass.put("/tagTypes/" + uuid, MeasurementTagType.class);
        uriToClass.put("/assetGroups/" + uuid, Group.class);
        uriToClass.put("/groupAssociations/" + uuid, GroupAssociation.class);
        uriToClass.put("/groupTypes/" + uuid, GroupType.class);
        uriToClass.put("/tagLookups/" + uuid, MeasurementTagLookup.class);
        for (String uri : uriToClass.keySet()) {
            Class<?> clazz = Prefixes.getClass(uri);
            Assert.assertEquals(uriToClass.get(uri), clazz);
        }
    }

    @Test
    public void testPrefixFromUri() {
        String uri = "/sites/bb571726-c1a3-4610-99de-435ab7f74000";
        String expectedPrefix = "/sites";
        String actualPrefix = Prefixes.prefixFromUri(uri);
        Assert.assertEquals(expectedPrefix, actualPrefix);
    }

    @Test
    public void test_getTypePrefix() {
        Assert.assertEquals(Prefixes.EnterpriseTypes, Prefixes.getTypePrefix(Prefixes.Enterprises));
        Assert.assertEquals(Prefixes.SiteTypes, Prefixes.getTypePrefix(Prefixes.Sites));
        Assert.assertEquals(Prefixes.SegmentTypes, Prefixes.getTypePrefix(Prefixes.Segments));
        Assert.assertEquals(Prefixes.AssetTypes, Prefixes.getTypePrefix(Prefixes.Assets));
        Assert.assertEquals(Prefixes.GroupTypes, Prefixes.getTypePrefix(Prefixes.Groups));
    }

    @Test(expected = IllegalStateException.class)
    public void test_getTypePrefix_invalidPrefix() {
        Prefixes.getTypePrefix("Test");
    }

    @Test
    public void test_getParentPrefixes() {
        Assert.assertArrayEquals(new String[] { Prefixes.EnterpriseTypes },
            Prefixes.getParentPrefixes(Prefixes.EnterpriseTypes).toArray());
        Assert.assertArrayEquals(new String[] { Prefixes.SiteTypes },
            Prefixes.getParentPrefixes(Prefixes.SiteTypes).toArray());
        Assert.assertArrayEquals(new String[] { Prefixes.SegmentTypes },
            Prefixes.getParentPrefixes(Prefixes.SegmentTypes).toArray());
        Assert.assertArrayEquals(new String[] { Prefixes.AssetTypes },
            Prefixes.getParentPrefixes(Prefixes.AssetTypes).toArray());
        Assert.assertArrayEquals(new String[] { Prefixes.MeasurementTagTypes },
            Prefixes.getParentPrefixes(Prefixes.MeasurementTagTypes).toArray());
        Assert.assertArrayEquals(new String[] { null }, Prefixes.getParentPrefixes(Prefixes.GroupTypes).toArray());

        Assert.assertArrayEquals(new String[] { Prefixes.Enterprises, Prefixes.noParent },
            Prefixes.getParentPrefixes(Prefixes.Enterprises).toArray());
        Assert.assertArrayEquals(new String[] { Prefixes.Enterprises, Prefixes.Sites, Prefixes.noParent },
            Prefixes.getParentPrefixes(Prefixes.Sites).toArray());
        Assert.assertArrayEquals(new String[] { Prefixes.Sites, Prefixes.Segments, Prefixes.noParent },
            Prefixes.getParentPrefixes(Prefixes.Segments).toArray());
        Assert.assertArrayEquals(new String[] { Prefixes.Sites, Prefixes.Segments, Prefixes.Assets, Prefixes.noParent },
            Prefixes.getParentPrefixes(Prefixes.Assets).toArray());
    }

    @Test(expected = IllegalStateException.class)
    public void test_getParentPrefixes_invalidPrefix() {
        Prefixes.getTypePrefix("Test");
    }

    @Test
    public void test_isValidType() {
        Assert.assertTrue(Prefixes.isValidType(Prefixes.Enterprises, Prefixes.EnterpriseTypes));
        Assert.assertTrue(Prefixes.isValidType(Prefixes.Sites, Prefixes.SiteTypes));
        Assert.assertTrue(Prefixes.isValidType(Prefixes.Segments, Prefixes.SegmentTypes));
        Assert.assertTrue(Prefixes.isValidType(Prefixes.Assets, Prefixes.AssetTypes));
        Assert.assertTrue(Prefixes.isValidType(Prefixes.MeasurementTags, Prefixes.MeasurementTagTypes));
        Assert.assertTrue(Prefixes.isValidType(Prefixes.Groups, Prefixes.GroupTypes));
        Assert.assertFalse(Prefixes.isValidType(Prefixes.Assets, "invalid"));
    }

    @Test
    public void test_isValidParent() {
        Assert.assertTrue(Prefixes.isValidParent(Prefixes.Enterprises, Prefixes.noParent));
        Assert.assertTrue(Prefixes.isValidParent(Prefixes.Sites, Prefixes.Enterprises));
        Assert.assertTrue(Prefixes.isValidParent(Prefixes.Segments, Prefixes.Segments));
        Assert.assertTrue(Prefixes.isValidParent(Prefixes.Segments, Prefixes.Sites));
        Assert.assertTrue(Prefixes.isValidParent(Prefixes.Assets, Prefixes.Assets));
        Assert.assertTrue(Prefixes.isValidParent(Prefixes.Assets, Prefixes.Segments));
        Assert.assertTrue(Prefixes.isValidParent(Prefixes.Assets, Prefixes.Sites));
        Assert.assertFalse(Prefixes.isValidParent(Prefixes.Assets, Prefixes.Enterprises));

        Assert.assertTrue(Prefixes.isValidParent(Prefixes.EnterpriseTypes, Prefixes.EnterpriseTypes));
        Assert.assertTrue(Prefixes.isValidParent(Prefixes.SiteTypes, Prefixes.SiteTypes));
        Assert.assertTrue(Prefixes.isValidParent(Prefixes.SegmentTypes, Prefixes.SegmentTypes));
        Assert.assertTrue(Prefixes.isValidParent(Prefixes.AssetTypes, Prefixes.AssetTypes));
        Assert.assertTrue(Prefixes.isValidParent(Prefixes.GroupTypes, null));
        Assert.assertFalse(Prefixes.isValidParent(Prefixes.GroupTypes, Prefixes.GroupTypes));
    }
}