/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.api.base;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.springframework.http.HttpEntity;

import com.ge.apm.asset.adapter.api.ITypedAdapter;
import com.ge.apm.asset.adapter.impl.AssetTypeAdapter;
import com.ge.apm.asset.adapter.impl.EnterpriseTypeAdapter;
import com.ge.apm.asset.adapter.impl.MeasurementTagTypeAdapter;
import com.ge.apm.asset.adapter.impl.SegmentTypeAdapter;
import com.ge.apm.asset.adapter.impl.SiteTypeAdapter;
import com.ge.apm.asset.model.Type;
import com.ge.apm.asset.service.api.IAssetConfigService;
import com.ge.apm.asset.service.api.IAssetTypeService;
import com.ge.apm.asset.service.component.AssetConfigService;
import com.ge.apm.asset.service.impl.AssetTypeService;
import com.ge.apm.asset.service.persistence.AlmPersistenceService;
import com.ge.apm.asset.util.AssetCacheManager;
import com.ge.apm.asset.util.ReflectionUtils;

import static org.mockito.Mockito.spy;

public abstract class AbstractTypeControllerTest<C, T extends Type> extends AbstractControllerTest<C, T> {

    protected List<ITypedAdapter> typedAdapters;

    @Captor
    protected ArgumentCaptor<HttpEntity<?>> httpEntityCaptor;

    @Captor
    protected ArgumentCaptor<String> urlCaptor;

    static List<ITypedAdapter> spyTypedAdapters(IAssetTypeService ats, IAssetConfigService assetConfigService)
        throws InstantiationException, IllegalAccessException {
        List<ITypedAdapter> typedAdapters = new ArrayList<>();
        typedAdapters.add(spyTypedAdapter(ats, assetConfigService, AssetTypeAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, assetConfigService, MeasurementTagTypeAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, null, EnterpriseTypeAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, null, SegmentTypeAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, null, SiteTypeAdapter.class));
        return typedAdapters;
    }

    static <T extends ITypedAdapter> ITypedAdapter spyTypedAdapter(IAssetTypeService ats,
        IAssetConfigService assetConfigService, Class<T> clazz) throws InstantiationException, IllegalAccessException {
        T typedAdapter = spy(clazz.newInstance());
        if (ats != null) {
            ReflectionUtils.setField(clazz, typedAdapter, "assetTypeService", ats);
        }

        if (assetConfigService != null) {
            ReflectionUtils.setField(clazz, typedAdapter, "assetConfigService", assetConfigService);
        }

        return typedAdapter;
    }

    @Override
    protected void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();

        assetTypeService = spy(new AssetTypeService());
        typedAdapters = spyTypedAdapters(assetTypeService, assetConfigService);

        ReflectionUtils.setField(AssetCacheManager.class, assetCacheManager, "cacheManager", cacheManager);
        ReflectionUtils.setField(AssetTypeService.class, assetTypeService, "assetCacheManager", assetCacheManager);
        ReflectionUtils.setField(AssetTypeService.class, assetTypeService, "typedAdapters", typedAdapters);
        ReflectionUtils.setField(AssetTypeService.class, assetTypeService, "assetConfigService", assetConfigService);
        ReflectionUtils.setField(AssetTypeService.class, assetTypeService, "almPersistenceService",
            almPersistenceService);
        ReflectionUtils.setField(AlmPersistenceService.class, almPersistenceService, "assetTypePersistencyService",
            assetTypePersistencyService);
        ReflectionUtils.setField(AlmPersistenceService.class, almPersistenceService, "assetPersistencyService",
            assetPersistencyService);
        ReflectionUtils.setField(AssetConfigService.class, assetConfigService, "restTemplate", getRestTemplate());
        ReflectionUtils.setField(AssetConfigService.class, assetConfigService, "uomService", uomService);

        assetTypeService.afterPropertiesSet();
    }

    public Class<T> getTypeClass() {
        return null;
    }

}
