/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.app;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.asset.controller.AppController;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.service.api.IAssetTypeService;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Created by 212389934 on 6/5/16.
 */
@RunWith(PowerMockRunner.class)
public class AppControllerTest extends TestCase {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static final ObjectReader MEASUREMENT_TAG_TYPE_READER = MAPPER.reader(MeasurementTagType.class);

    private static final ObjectReader ASSET_TYPE_READER = MAPPER.reader(AssetType.class);

    private static final String uuid = "anyString";

    @InjectMocks
    private AppController appController;

    @Mock
    private IAssetTypeService assetTypeService;

    @Before
    public void setUp() throws Exception {
        appController = new AppController();
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() throws Exception {
        appController = null;
    }

    @SuppressWarnings("unchecked")
    @Test
    public void tagTypeAttributesTest() throws IOException {

        MeasurementTagType inputTagType = MEASUREMENT_TAG_TYPE_READER.readValue(
            this.getClass().getResourceAsStream("/input/App/tagTypesAttributes.json"));

        MeasurementTagType expected = MEASUREMENT_TAG_TYPE_READER.readValue(
            this.getClass().getResourceAsStream("/output/App/tagTypesAttributes.json"));

        when(assetTypeService.getDetailedSingle(anyString(), Mockito.any(Class.class), Mockito.anyList())).thenReturn(
            inputTagType);

        MeasurementTagType fetched = appController.tagTypeAttributes(uuid);

        Assert.assertEquals(fetched, expected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void assetTypeAttributesTest() throws IOException {

        AssetType inputAssetType = ASSET_TYPE_READER.readValue(
            this.getClass().getResourceAsStream("/input/App/assetTypesAttributes.json"));

        AssetType expected = ASSET_TYPE_READER.readValue(
            this.getClass().getResourceAsStream("/output/App/assetTypesAttributes.json"));

        when(assetTypeService.getDetailedSingle(anyString(), Mockito.any(Class.class), Mockito.anyList())).thenReturn(
            inputAssetType);

        AssetType fetched = appController.assetTypeAttributes(uuid);

        Assert.assertEquals(fetched, expected);
    }
}
