package com.ge.apm.asset.controller;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.ge.apm.alm.model.coretypes.SeedOOTBData;
import com.ge.apm.asset.model.AlmContextConfig;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.ConfigContextQuery;
import com.ge.apm.asset.model.Context;
import com.ge.apm.asset.model.ContextConfigValue;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.ReservedAttributeContextConfig;
import com.ge.apm.asset.model.ReservedAttributeMetadata;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAlmConfigService;
import com.ge.apm.asset.service.api.IAlmPersistenceService;
import com.ge.apm.asset.service.api.IContextConfigService;
import com.ge.apm.asset.service.impl.AlmContextConfigService;
import com.ge.apm.asset.service.impl.ContextConfigService;
import com.ge.apm.asset.service.impl.ContextConfigServiceFactory;
import com.ge.apm.asset.service.impl.ReservedAttributeContextConfigService;
import com.ge.apm.asset.service.validators.ContextConfigValidator;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.support.RequestContext;
import com.ge.stuf.security.context.SecurityContext;
import com.ge.stuf.security.context.SecurityPrincipal;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class ContextConfigControllerTest {

    @Mock
    IAlmConfigService almContextConfigService;

    @Mock
    IAlmPersistenceService almPersistenceService;

    @Mock
    SecurityContext securityContext;

    @InjectMocks
    ContextConfigController ccc;

    @InjectMocks
    ContextConfigService configService;

    @InjectMocks
    AlmContextConfigService contextConfigService;

    @InjectMocks
    ReservedAttributeContextConfigService reservedConfigService;

    @InjectMocks
    ContextConfigServiceFactory serviceFactory;

    @Mock
    EntityManager entityManager;

    @Captor
    private ArgumentCaptor<ReservedAttributeContextConfig> reservedAttributeConfigCaptor;



    ContextConfigValidator contextConfigValidator;

    private static final String TEST_TENANT = "testTenant";

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Before
    public void setUp() throws IllegalAccessException {
        MockitoAnnotations.initMocks(this);
        RequestContext.clear();
        RequestContext.put(RequestContext.TENANT_UUID, TEST_TENANT);
        contextConfigValidator = new ContextConfigValidator();
        ReflectionUtils.setField(ContextConfigController.class, ccc, "service", configService);
        ReflectionUtils.setField(ContextConfigService.class, configService, "serviceFactory", serviceFactory);
        ReflectionUtils.setField(ReservedAttributeContextConfigService.class, reservedConfigService,
            "contextConfigValidator", contextConfigValidator);
        ReflectionUtils.setField(AlmContextConfigService.class, contextConfigService, "contextConfigValidator",
            contextConfigValidator);

        Map<Boolean, IContextConfigService> configServiceMap = new HashMap<>();
        configServiceMap.put(true, reservedConfigService);
        configServiceMap.put(false, contextConfigService);
        ReflectionUtils.setField(ContextConfigServiceFactory.class, serviceFactory, "configServiceMap",
            configServiceMap);

        doReturn(new SecurityPrincipal() {
            @Override
            public String getName() {
                return "Test user";
            }

            @Override
            public String getTenantUuid() {
                return TEST_TENANT;
            }
        }).when(securityContext).getPrinicipal();
    }

    @Test
    public void test_Post_ReservedConfig_Valid_NotInUse() {
        Context context = createContext("asset-state", true);
        doReturn(context).when(almContextConfigService).findByContextName(eq(context.getContextName()));
        doReturn(null).when(almContextConfigService).findReservedAttributesContextConfigByContextAndTenantIdAndCode(
            eq(context.getContextName()), eq(TEST_TENANT), eq("103"));
        doReturn(null).when(almContextConfigService).saveReservedAttributeContextConfig(
            reservedAttributeConfigCaptor.capture());
        ContextConfigValue configValue = new ContextConfigValue();
        configValue.setCode("103");
        configValue.setContext(context.getContextName());
        configValue.setSemanticName("testConfig");
        configValue.setIsActive(true);
        ccc.add("asset-state", configValue);

        ReservedAttributeContextConfig racc = reservedAttributeConfigCaptor.getValue();
        Assert.assertEquals(configValue.getCode(), racc.getCode());
        Assert.assertEquals(TEST_TENANT, racc.getTenantId());
        Assert.assertEquals(configValue.getIsActive(), racc.getIsActive());
        Assert.assertEquals(context.getIsReservedAttributeConfig(), racc.getContext().getIsReservedAttributeConfig());
        Assert.assertEquals(context.getContextName(), racc.getContext().getContextName());
    }

    @Test
    public void test_Post_ReservedConfig_Valid_IsDefault() {
        Context context = createContext("asset-state", true);
        ReservedAttributeContextConfig currentDefault = new ReservedAttributeContextConfig();
        currentDefault.setIsDefault(true);
        currentDefault.setId(3L);

        doReturn(context).when(almContextConfigService).findByContextName(eq(context.getContextName()));
        doReturn(null).when(almContextConfigService).findReservedAttributesContextConfigByContextAndTenantIdAndCode(
            eq(context.getContextName()), eq(TEST_TENANT), eq("103"));
        doReturn(null).when(almContextConfigService).saveReservedAttributeContextConfig(
            reservedAttributeConfigCaptor.capture());
        doReturn(currentDefault).when(almContextConfigService)
            .findReservedAttributeByContextConfigAndTenantIdAndIsDefaultTrue(eq(context.getContextName()),
                eq(TEST_TENANT));

        ContextConfigValue configValue = new ContextConfigValue();
        configValue.setCode("103");
        configValue.setContext(context.getContextName());
        configValue.setSemanticName("testConfig");
        configValue.setIsActive(true);
        configValue.setIsDefault(true);
        ccc.add("asset-state", configValue);

        Assert.assertEquals(false, currentDefault.getIsDefault());
        ReservedAttributeContextConfig racc = reservedAttributeConfigCaptor.getValue();
        Assert.assertEquals(configValue.getCode(), racc.getCode());
        Assert.assertEquals(TEST_TENANT, racc.getTenantId());
        Assert.assertEquals(configValue.getIsActive(), racc.getIsActive());
        Assert.assertEquals(context.getIsReservedAttributeConfig(), racc.getContext().getIsReservedAttributeConfig());
        Assert.assertEquals(context.getContextName(), racc.getContext().getContextName());
    }

    @Test(expected = BadRequestException.class)
    public void test_Post_AlmConfig() {
        Context context = createContext("bulk_ingestion_audit", false);
        doReturn(context).when(almContextConfigService).findByContextName(eq(context.getContextName()));
        ContextConfigValue configValue = new ContextConfigValue();
        configValue.setCode("103");
        configValue.setContext(context.getContextName());
        configValue.setSemanticName("testConfig");
        configValue.setIsActive(true);
        ccc.add("bulk_ingestion_audit", configValue);
    }

    @Test(expected = BadRequestException.class)
    public void test_Post_ReservedConfig_ValidCode_InUse() {
        Context context = createContext("asset-state", true);
        doReturn(context).when(almContextConfigService).findByContextName(eq(context.getContextName()));
        doReturn(new ReservedAttributeContextConfig()).when(almContextConfigService)
            .findReservedAttributesContextConfigByContextAndTenantIdAndCode(eq(context.getContextName()),
                eq(TEST_TENANT), eq("103"));

        ContextConfigValue configValue = new ContextConfigValue();
        configValue.setCode("103");
        configValue.setContext(context.getContextName());
        configValue.setSemanticName("testConfig");
        configValue.setIsActive(true);
        ccc.add("asset-state", configValue);
    }

    @Test(expected = BadRequestException.class)
    public void test_Post_ReservedConfig_InvalidCode() {
        Context context = createContext("asset-state", true);
        doReturn(context).when(almContextConfigService).findByContextName(eq(context.getContextName()));

        ContextConfigValue configValue = new ContextConfigValue();
        configValue.setCode("99");
        configValue.setContext(context.getContextName());
        configValue.setSemanticName("testConfig");
        configValue.setIsActive(true);
        ccc.add("asset-state", configValue);
    }

    @Test(expected = BadRequestException.class)
    public void test_Post_ReservedConfig_InvalidActivation() {
        Context context = createContext("asset-state", true);
        doReturn(context).when(almContextConfigService).findByContextName(eq(context.getContextName()));

        ContextConfigValue configValue = new ContextConfigValue();
        configValue.setCode("103");
        configValue.setContext(context.getContextName());
        configValue.setSemanticName("testConfig");
        ccc.add("asset-state", configValue);
    }

    @Test
    public void test_Post_AddAll_Valid() {
        Context context1 = createContext("asset-state", true);
        Context context2 = createContext("asset-status", true);

        ContextConfigValue configValue = new ContextConfigValue();
        configValue.setCode("103");
        configValue.setContext(context1.getContextName());
        configValue.setIsActive(true);
        configValue.setSemanticName("testConfig1");
        ContextConfigValue configValue2 = new ContextConfigValue();
        configValue2.setCode("104");
        configValue2.setIsActive(true);
        configValue2.setContext(context2.getContextName());
        configValue2.setSemanticName("testConfig2");

        doReturn(context1).when(almContextConfigService).findByContextName(eq(context1.getContextName()));
        doReturn(null).when(almContextConfigService).findReservedAttributesContextConfigByContextAndTenantIdAndCode(
            eq(context1.getContextName()), eq(TEST_TENANT), eq(configValue.getCode()));
        doReturn(context2).when(almContextConfigService).findByContextName(eq(context2.getContextName()));
        doReturn(null).when(almContextConfigService).findReservedAttributesContextConfigByContextAndTenantIdAndCode(
            eq(context2.getContextName()), eq(TEST_TENANT), eq(configValue2.getCode()));
        doReturn(null).when(almContextConfigService).saveReservedAttributeContextConfig(
            reservedAttributeConfigCaptor.capture());

        ResponseEntity re = ccc.addAll(new ContextConfigValue[] { configValue, configValue2 });
        Assert.assertEquals(HttpStatus.OK, re.getStatusCode());
        verify(almContextConfigService, times(2)).saveReservedAttributeContextConfig(
            reservedAttributeConfigCaptor.capture());
        Assert.assertEquals(configValue.getCode(), reservedAttributeConfigCaptor.getAllValues().get(0).getCode());
        Assert.assertEquals(configValue2.getCode(), reservedAttributeConfigCaptor.getAllValues().get(1).getCode());
    }

    @Test
    public void test_Post_AddAll_Invalid() {
        Context context1 = createContext("asset-state", true);
        Context context2 = createContext("asset-status", true);

        ContextConfigValue configValue = new ContextConfigValue();
        configValue.setCode("99");
        configValue.setContext(context1.getContextName());
        configValue.setIsActive(true);
        configValue.setSemanticName("testConfig1");
        ContextConfigValue configValue2 = new ContextConfigValue();
        configValue2.setCode("104");
        configValue2.setIsActive(true);
        configValue2.setContext(context2.getContextName());
        configValue2.setSemanticName("testConfig2");

        doReturn(context1).when(almContextConfigService).findByContextName(eq(context1.getContextName()));
        doReturn(null).when(almContextConfigService).findReservedAttributesContextConfigByContextAndTenantIdAndCode(
            eq(context1.getContextName()), eq(TEST_TENANT), eq(configValue.getCode()));
        doReturn(context2).when(almContextConfigService).findByContextName(eq(context2.getContextName()));
        doReturn(null).when(almContextConfigService).findReservedAttributesContextConfigByContextAndTenantIdAndCode(
            eq(context2.getContextName()), eq(TEST_TENANT), eq(configValue2.getCode()));
        doReturn(null).when(almContextConfigService).saveReservedAttributeContextConfig(
            reservedAttributeConfigCaptor.capture());

        ResponseEntity re = ccc.addAll(new ContextConfigValue[] { configValue, configValue2 });
        Assert.assertEquals(HttpStatus.MULTI_STATUS, re.getStatusCode());
        verify(almContextConfigService, times(1)).saveReservedAttributeContextConfig(
            reservedAttributeConfigCaptor.capture());
        Assert.assertEquals(configValue2.getCode(), reservedAttributeConfigCaptor.getValue().getCode());
    }

    @Test
    public void test_Delete() {
        Context context = createContext("asset-state", true);
        ReservedAttributeContextConfig currentDefault = new ReservedAttributeContextConfig();
        currentDefault.setIsDefault(true);
        currentDefault.setId(3L);
        currentDefault.setCode("103");
        currentDefault.setContext(context);
        ReservedAttributeConfig rac = new ReservedAttributeConfig();
        rac.setPossibleValuesContext(context.getContextName());
        rac.setName("state");
        ReservedAttributeMetadata ram = new ReservedAttributeMetadata();
        ram.setType(context.getContextType());
        ram.setConfigJson(new ReservedAttributeConfig[] { rac });

        doReturn(context).when(almContextConfigService).findByContextName(eq(context.getContextName()));
        doReturn(currentDefault).when(almContextConfigService)
            .findReservedAttributesContextConfigByContextAndTenantIdAndCode(eq(context.getContextName()),
                eq(TEST_TENANT), eq("103"));
        doNothing().when(almContextConfigService).deleteReservedAttributeByContextConfig(
            reservedAttributeConfigCaptor.capture());
        doReturn(ram).when(almContextConfigService).findByType(eq(context.getContextType()));
        doReturn(new Asset[0]).when(almPersistenceService).findAllByPrefix(eq(TEST_TENANT), eq("/" + context
                .getContextType()),
            any(QueryPredicate.class), eq(Asset.class), eq(true), eq(true));

        ResponseEntity re = ccc.delete(context.getContextName(), "103");
        Assert.assertEquals(HttpStatus.NO_CONTENT, re.getStatusCode());
        verify(almContextConfigService, times(1)).deleteReservedAttributeByContextConfig
            (reservedAttributeConfigCaptor.capture());
        Assert.assertEquals(currentDefault.getCode(), reservedAttributeConfigCaptor.getValue().getCode());
        Assert.assertEquals(currentDefault.getId(), reservedAttributeConfigCaptor.getValue().getId());
    }

    @Test(expected = BadRequestException.class)
    public void test_Delete_Alm() {
        Context context = createContext("ui-edit", false);
        doReturn(context).when(almContextConfigService).findByContextName(eq(context.getContextName()));

        ccc.delete(context.getContextName(), "103");
    }

    @Test(expected = BadRequestException.class)
    public void test_Delete_DoesNotExist() {
        Context context = createContext("asset-state", true);
        doReturn(null).when(almContextConfigService).findByContextName(eq(context.getContextName()));

        ccc.delete(context.getContextName(), "103");
    }

    @Test(expected = BadRequestException.class)
    public void test_Delete_SystemReservedCode() {
        Context context = createContext("asset-state", true);
        ReservedAttributeContextConfig currentDefault = new ReservedAttributeContextConfig();
        currentDefault.setIsDefault(true);
        currentDefault.setId(3L);
        currentDefault.setCode("40");
        currentDefault.setContext(context);
        ReservedAttributeConfig rac = new ReservedAttributeConfig();
        rac.setPossibleValuesContext(context.getContextName());
        rac.setName("state");
        ReservedAttributeMetadata ram = new ReservedAttributeMetadata();
        ram.setType(context.getContextType());
        ram.setConfigJson(new ReservedAttributeConfig[] { rac });

        doReturn(context).when(almContextConfigService).findByContextName(eq(context.getContextName()));
        doReturn(currentDefault).when(almContextConfigService)
            .findReservedAttributesContextConfigByContextAndTenantIdAndCode(eq(context.getContextName()),
                eq(TEST_TENANT), eq("40"));

        ccc.delete(context.getContextName(), currentDefault.getCode());
    }

    @Test(expected = BadRequestException.class)
    public void test_Delete_CodeNotFound() {
        Context context = createContext("asset-state", true);
        ReservedAttributeContextConfig currentDefault = new ReservedAttributeContextConfig();
        currentDefault.setIsDefault(true);
        currentDefault.setId(3L);
        currentDefault.setCode("103");
        currentDefault.setContext(context);
        ReservedAttributeConfig rac = new ReservedAttributeConfig();
        rac.setPossibleValuesContext(context.getContextName());
        rac.setName("state");
        ReservedAttributeMetadata ram = new ReservedAttributeMetadata();
        ram.setType(context.getContextType());
        ram.setConfigJson(new ReservedAttributeConfig[] { rac });

        doReturn(context).when(almContextConfigService).findByContextName(eq(context.getContextName()));
        doReturn(currentDefault).when(almContextConfigService)
            .findReservedAttributesContextConfigByContextAndTenantIdAndCode(eq(context.getContextName()),
                eq(TEST_TENANT), eq("104"));

        ccc.delete(context.getContextName(), currentDefault.getCode());
    }

    @Test(expected = BadRequestException.class)
    public void test_Delete_CodeUsed() {
        Context context = createContext("asset-state", true);
        ReservedAttributeContextConfig currentDefault = new ReservedAttributeContextConfig();
        currentDefault.setIsDefault(true);
        currentDefault.setId(3L);
        currentDefault.setCode("103");
        currentDefault.setContext(context);
        ReservedAttributeConfig rac = new ReservedAttributeConfig();
        rac.setPossibleValuesContext(context.getContextName());
        rac.setName("state");
        ReservedAttributeMetadata ram = new ReservedAttributeMetadata();
        ram.setType(context.getContextType());
        ram.setConfigJson(new ReservedAttributeConfig[] { rac });

        doReturn(context).when(almContextConfigService).findByContextName(eq(context.getContextName()));
        doReturn(currentDefault).when(almContextConfigService)
            .findReservedAttributesContextConfigByContextAndTenantIdAndCode(eq(context.getContextName()),
                eq(TEST_TENANT), eq("103"));
        doNothing().when(almContextConfigService).deleteReservedAttributeByContextConfig(
            reservedAttributeConfigCaptor.capture());
        doReturn(ram).when(almContextConfigService).findByType(eq(context.getContextType()));
        doReturn(new Asset[1]).when(almPersistenceService).findAllByPrefix(eq(TEST_TENANT), eq("/" + context
                .getContextType()),
            any(QueryPredicate.class), eq(Asset.class), eq(true), eq(true));

        ccc.delete(context.getContextName(), "103");
    }

    private Context createContext(String contextName, Boolean isReservedAttribute) {
        Context c = new Context();
        c.setIsReservedAttributeConfig(isReservedAttribute);
        c.setReservedCodeValidationExpression("code > 0 && code <= 100");
        c.setCodeType("integer");
        c.setContextType("assets");
        c.setContextName(contextName);
        return c;
    }

    @Test
    public void test_getContextConfigService() {
        Assert.assertNotNull(ccc.getContextConfigService());
    }

    @Test
    public void test_updateSingle() throws IOException {
        PatchOperation[] pos = MAPPER.readerFor(Array.newInstance(PatchOperation.class, 0).getClass())
            .readValue(this.getClass().getClassLoader()
                .getResource("input/contextConfig/context-config-patch.json"));
        Context context = createContext("asset-state", true);
        Mockito.doReturn(context).when(almContextConfigService).findByContextName(Mockito.anyString());
        Mockito.doReturn(null).when(almContextConfigService)
            .findAllByContextNameAndTenantId(eq(context.getContextName()), eq(TEST_TENANT));
        List<ReservedAttributeContextConfig> raContextConfigs = setRaContextConfigs(context);
        Mockito.doReturn(raContextConfigs).when(almContextConfigService)
            .findAllReservedAttributesContextConfigsByContextAndCodeAndTenantId(
                eq(context.getContextName()), eq("1"), eq(TEST_TENANT));
        AlmContextConfig almContextConfig = new AlmContextConfig();
        almContextConfig.setContext(context);
        almContextConfig.setDescription("description");
        almContextConfig.setTenantId(TEST_TENANT);
        Mockito.doReturn(almContextConfig).when(almContextConfigService).save(almContextConfig);
        ResponseEntity re = ccc.updateSingle("asset-state", "1", pos);
        Assert.assertNotNull(re);
        Assert.assertEquals(re.getStatusCode(), HttpStatus.OK);

    }

    @Test
    public void test_updateSingleWithoutCode() throws IOException {
        PatchOperation[] pos = MAPPER.readerFor(Array.newInstance(PatchOperation.class, 0).getClass())
            .readValue(this.getClass().getClassLoader()
                .getResource("input/contextConfig/context-config-patch.json"));
        Context context = createContext("asset-state", true);
        Mockito.doReturn(context).when(almContextConfigService).findByContextName(Mockito.anyString());
        Mockito.doReturn(null).when(almContextConfigService)
            .findAllByContextNameAndTenantId(eq(context.getContextName()), eq(TEST_TENANT));
        List<ReservedAttributeContextConfig> raContextConfigs = setRaContextConfigs(context);
        Mockito.doReturn(raContextConfigs).when(almContextConfigService)
            .findAllReservedAttributesContextConfigsByContextAndCodeAndTenantId(
                eq(context.getContextName()), Mockito.anyObject(), eq(TEST_TENANT));
        AlmContextConfig almContextConfig = new AlmContextConfig();
        almContextConfig.setContext(context);
        almContextConfig.setDescription("description");
        almContextConfig.setTenantId(TEST_TENANT);
        Mockito.doReturn(almContextConfig).when(almContextConfigService).save(almContextConfig);
        ResponseEntity re = ccc.updateSingle("asset-state", pos);
        Assert.assertNotNull(re);
        Assert.assertEquals(re.getStatusCode(), HttpStatus.OK);

    }

    @Test
    public void test_getAll_RemoveDuplicates() {
        Context context = createContext("asset-state", true);
        List<ReservedAttributeContextConfig> configs = new ArrayList<>();
        ReservedAttributeContextConfig ra1 = new ReservedAttributeContextConfig();
        ra1.setContext(context);
        ra1.setCode("02");
        ra1.setIsDefault(true);
        ra1.setIsActive(true);
        ra1.setTenantId(SeedOOTBData.SYSTEM_TENANT_ID);
        ReservedAttributeContextConfig ra2 = new ReservedAttributeContextConfig();
        ra2.setContext(context);
        ra2.setCode("02");
        ra2.setIsDefault(true);
        ra2.setIsActive(true);
        ra2.setDisplayName("Custom config");
        ra2.setTenantId(TEST_TENANT);
        ReservedAttributeContextConfig ra3 = new ReservedAttributeContextConfig();
        ra3.setContext(context);
        ra3.setCode("01");
        ra3.setIsDefault(false);
        ra3.setIsActive(true);
        ra3.setTenantId(TEST_TENANT);
        ReservedAttributeContextConfig ra4 = new ReservedAttributeContextConfig();
        ra4.setContext(context);
        ra4.setCode("05");
        ra4.setIsDefault(false);
        ra4.setIsActive(true);
        ra4.setTenantId(SeedOOTBData.SYSTEM_TENANT_ID);

        configs.add(ra1);
        configs.add(ra2);
        configs.add(ra3);
        configs.add(ra4);

        Mockito.doReturn(configs).when(almContextConfigService)
            .findAllReservedAttributesContextConfigsByContextAndCodeAndTenantId(
                eq(context.getContextName()), eq(null), eq(TEST_TENANT));
        doReturn(context).when(almContextConfigService).findByContextName(eq(context.getContextName()));

        ResponseEntity<List<ContextConfigValue>> re = ccc.getAll(context.getContextName());
        Assert.assertEquals(HttpStatus.OK, re.getStatusCode());
        List<ContextConfigValue> result = re.getBody();
        Assert.assertEquals(3, result.size());
        Assert.assertEquals(ra3.getCode(), result.get(0).getCode());
        Assert.assertEquals(ra2.getCode(), result.get(1).getCode());
        Assert.assertEquals(ra4.getCode(), result.get(2).getCode());

        Assert.assertEquals(ra2.getDisplayName(), result.get(1).getDisplayName());
    }

    @Test
    public void getAllByFilter_ReservedAndAlmConfig() {
        Context context = createContext("asset-state", true);
        ConfigContextQuery ccq = new ConfigContextQuery();
        ccq.setDisplayName(new String[] {"config1", "config2"});
        ccq.setIsActive(true);

        List<ReservedAttributeContextConfig> configs = new ArrayList<>();
        ReservedAttributeContextConfig ra1 = new ReservedAttributeContextConfig();
        ra1.setContext(context);
        ra1.setCode("02");
        ra1.setIsDefault(true);
        ra1.setDisplayName("config1");
        ra1.setIsActive(true);
        ra1.setTenantId(SeedOOTBData.SYSTEM_TENANT_ID);
        ReservedAttributeContextConfig ra2 = new ReservedAttributeContextConfig();
        ra2.setContext(context);
        ra2.setCode("02");
        ra2.setIsDefault(true);
        ra2.setIsActive(true);
        ra2.setDisplayName("config1");
        ra2.setTenantId(TEST_TENANT);

        configs.add(ra1);
        configs.add(ra2);

        List<AlmContextConfig> configs2 = new ArrayList<>();
        AlmContextConfig a1 = new AlmContextConfig();
        a1.setContext(context);
        a1.setDescription("d1");
        a1.setTenantId(SeedOOTBData.SYSTEM_TENANT_ID);
        AlmContextConfig a2 = new AlmContextConfig();
        a2.setContext(context);
        a2.setDescription("d2");
        a2.setTenantId(TEST_TENANT);

        configs2.add(a1);
        configs2.add(a2);

        doReturn(configs).when(almContextConfigService).findAllReservedAttributesContextConfigsByQuerySpecs(eq
            (TEST_TENANT), eq(ccq));
        doReturn(configs2).when(almContextConfigService).findAllByQuerySpecs(eq
            (TEST_TENANT), eq(ccq));

        ResponseEntity<List<ContextConfigValue>> re = ccc.getAllByFilter(ccq);

        Assert.assertEquals(HttpStatus.OK, re.getStatusCode());
        Assert.assertEquals(2, re.getBody().size());
        Assert.assertEquals(a2.getDescription(), re.getBody().get(0).getDescription());
        Assert.assertEquals(ra2.getCode(), re.getBody().get(1).getCode());
    }

    private List<ReservedAttributeContextConfig> setRaContextConfigs(Context context) {
        ReservedAttributeContextConfig raContextConfig = new ReservedAttributeContextConfig();
        raContextConfig.setIsDefault(true);
        raContextConfig.setId(3L);
        raContextConfig.setCode("1");
        raContextConfig.setIsActive(true);
        raContextConfig.setSemanticName("semanticName");
        raContextConfig.setDescription("description");
        raContextConfig.setContext(context);
        List<ReservedAttributeContextConfig> raContextConfigs = new ArrayList<>();
        raContextConfigs.add(raContextConfig);
        return raContextConfigs;
    }

}
