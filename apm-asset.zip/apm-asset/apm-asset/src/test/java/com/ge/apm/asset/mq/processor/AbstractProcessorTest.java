/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.Before;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ge.apm.asset.controller.base.ICrudController;
import com.ge.apm.asset.mq.config.MqAuthConfig;
import com.ge.apm.asset.mq.factory.ControllerFactory;
import com.ge.apm.asset.mq.redis.SourceKeyLookup;
import com.ge.asset.commons.mq.constants.MessageConstants;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

/**
 * Created by 212448111 on 2/22/17.
 */
public class AbstractProcessorTest {

    @Mock
    Exchange exchange;

    @Mock
    Message message;

    @Mock
    MqAuthConfig mqAuthConfig;

    @Mock
    ControllerFactory controllerFactory;

    @Mock
    SourceKeyLookup sourceKeyLookup;

    @Mock
    ICrudController crudController;

    String tenantId = null;

    String authToken = null;

    String traceId = null;

    Map<String, Object> headerMap = new HashMap<>();

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        tenantId = "TENANT";
        authToken = "AUTH_TOKEN";
        traceId = "TRACE";
        headerMap.put(MessageConstants.TRACE_UUID, tenantId);
        headerMap.put(MessageConstants.TENANT_UUID, tenantId);
        headerMap.put(MessageConstants.AUTHORIZATION, authToken);
        when(exchange.getIn()).thenReturn(message);
        when(exchange.getIn().getHeaders()).thenReturn(headerMap);
        when(exchange.getOut()).thenReturn(message);
        doNothing().when(mqAuthConfig).configure(anyString(), anyString(), anyString(), any(RequestMethod.class));
        when(controllerFactory.getController(anyString())).thenReturn(crudController);
    }
}
