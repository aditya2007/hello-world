/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.measurementtag;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

import com.ge.apm.asset.controller.MeasurementTagTypeController;
import com.ge.apm.asset.model.GroupAssociation;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAssetTypeService;
import com.ge.apm.asset.util.ValidationDelegate;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ForbiddenException;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.UnauthorizedException;
import com.ge.stuf.security.context.SecurityContext;
import com.ge.stuf.security.context.SecurityPrincipal;

import static org.mockito.Matchers.anyString;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ SecurityContext.class })
public class MeasurementTagTypeDeleteExceptionTest {

    @InjectMocks
    private MeasurementTagTypeController measurementTagTypeController;

    @Mock
    private IAssetTypeService service;

    @Mock
    private ValidationDelegate validationDelegate;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private SecurityPrincipal securityPrincipal;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        mockSecurityPrincipal();
    }

    @Ignore("No longer valid due to new persistency layer")
    @Test(expected = ForbiddenException.class)
    public void hasInstances() {
        Mockito.when(validationDelegate.hasInstances(anyString(), anyString(), anyString())).thenReturn(true);
        measurementTagTypeController.delete("testuuid");
    }

    @Ignore("No longer valid due to new persistency layer")
    @Test(expected = ForbiddenException.class)
    public void hasChildren() {

        Mockito.when(validationDelegate.hasChildren(anyString(), anyString(), anyString())).thenReturn(true);
        measurementTagTypeController.delete("testuuid");
    }

    @Ignore("No longer valid due to new persistency layer")
    @Test(expected = ForbiddenException.class)
    public void hasGroupAssociations() {
        GroupAssociation[] groupAssociations = new GroupAssociation[1];
        Mockito.when(validationDelegate.hasInstances(anyString(), anyString(), anyString())).thenReturn(false);
        Mockito.when(validationDelegate.hasChildren(anyString(), anyString(), anyString())).thenReturn(false);
        PowerMockito.when(service.get(anyString(), Mockito.any(Class.class), Matchers.anyListOf(String.class),
            Mockito.any(QueryPredicate.class), Matchers.anyInt())).thenReturn(groupAssociations);
        measurementTagTypeController.delete("testuuid");
    }

    @Test(expected = UnauthorizedException.class)
    public void unauthorized() {
        delete(HttpStatus.UNAUTHORIZED);
    }

    @Test(expected = NotFoundException.class)
    public void notFound() {
        delete(HttpStatus.NOT_FOUND);
    }

    @Test(expected = ForbiddenException.class)
    public void forbidden() {
        delete(HttpStatus.FORBIDDEN);
    }

    @Test(expected = BadRequestException.class)
    public void badRequest() {
        delete(HttpStatus.BAD_REQUEST);
    }

    @SuppressWarnings("unchecked")
    private void delete(HttpStatus httpStatus) {
        HttpClientErrorException exception = new HttpClientErrorException(httpStatus);
        Mockito.when(validationDelegate.hasInstances(anyString(), anyString(), anyString())).thenReturn(false);
        Mockito.when(validationDelegate.hasChildren(anyString(), anyString(), anyString())).thenReturn(false);
        PowerMockito.when(service.get(anyString(), Mockito.any(Class.class), Matchers.anyListOf(String.class),
            Mockito.any(QueryPredicate.class), Matchers.anyInt())).thenReturn(null);
        Mockito.doThrow(exception).when(service).delete(anyString(), Mockito.any(Class.class));
        measurementTagTypeController.delete("testuuid");
    }

    private void mockSecurityPrincipal() {
        PowerMockito.mockStatic(SecurityContext.class);
        //PowerMockito.when(SecurityContext.getInstance()).thenReturn(securityContext);
        PowerMockito.when(securityContext.getPrinicipal()).thenReturn(securityPrincipal);
        PowerMockito.when(securityPrincipal.getName()).thenReturn(null);
    }
}