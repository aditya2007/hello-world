/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.asset.model.GroupAssociation;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.common.exception.ServiceException;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

/**
 * Created by 212448111 on 2/22/17.
 */
public class GroupAssociationProcessorTest extends AbstractProcessorTest {

    @InjectMocks
    @Autowired
    GroupAssociationProcessor groupAssociationProcessor;

    @Before
    public void setup() {
        super.setup();
    }

    @Test
    public void processDto() {
        GroupAssociation mockGroupAssociationDto = new GroupAssociation();
        mockGroupAssociationDto.setToUri("/groupAssociations/MockSourceKey");
        mockGroupAssociationDto.setFromUri("/groupAssociations/MockSourceKey");
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq("/groupAssociations/MockSourceKey"))).thenReturn(
            Prefixes.GroupAssociations + "/mockUri");

        groupAssociationProcessor.processDto(mockGroupAssociationDto, exchange);
        Assert.assertThat("Group association fromUri is null", mockGroupAssociationDto.getFromUri(),
            equalTo(Prefixes.GroupAssociations + "/mockUri"));
        Assert.assertThat("Group association toUri is null", mockGroupAssociationDto.getToUri(),
            equalTo(Prefixes.GroupAssociations + "/mockUri"));
    }

    @Test(expected = DependencyViolationException.class)
    public void processDtoUriNotFound() {
        GroupAssociation mockGroupAssociationDto = new GroupAssociation();
        mockGroupAssociationDto.setToUri("/groupAssociations/MockUri");
        mockGroupAssociationDto.setFromUri("/groupAssociations/MockUri");
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq("/groupAssociations/MockUri"))).thenThrow(
            DependencyViolationException.class);
        groupAssociationProcessor.processDto(mockGroupAssociationDto, exchange);
    }

    @Test(expected = ServiceException.class)
    public void processDtoInvalidUriFormat() {
        GroupAssociation mockGroupAssociationDto = new GroupAssociation();
        mockGroupAssociationDto.setToUri("MockUri");
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq("MockUri"))).thenThrow(
            DependencyViolationException.class);
        groupAssociationProcessor.processDto(mockGroupAssociationDto, exchange);
    }

    @Test(expected = ServiceException.class)
    public void processDtoMissingUri() {
        GroupAssociation mockGroupAssociationDto = new GroupAssociation();
        groupAssociationProcessor.processDto(mockGroupAssociationDto, exchange);
    }
}
