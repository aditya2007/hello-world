/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.service;

import java.net.URI;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.AssetConfig;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.PredixAssetTransitiveDepthConfig;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.service.api.IUomService;
import com.ge.apm.asset.service.component.AssetConfigService;
import com.ge.apm.asset.util.ReflectionUtils;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

public class AssetConfigServiceTest {

    @Mock
    protected RestTemplate restTemplate;

    @Mock
    protected IUomService uomService;

    @InjectMocks
    @Autowired
    private AssetConfigService assetConfigService;

    private PredixAssetTransitiveDepthConfig depthConfig;

    @Before
    public void setUp() throws IllegalAccessException {
        MockitoAnnotations.initMocks(this);

        ReflectionUtils.setField(AssetConfigService.class, assetConfigService, "apmConfigServiceUrl",
            getApmConfigServiceUrl());
        ReflectionUtils.setField(AssetConfigService.class, assetConfigService, "restTemplate", restTemplate);

        depthConfig = new PredixAssetTransitiveDepthConfig();
        depthConfig.setAssets(4);
        depthConfig.setSegments(3);
        depthConfig.setSites(2);
        depthConfig.setEnterprises(1);
    }

    @Test
    public void testGetTransitiveDepth() {
        int actualDepthEnterpriseEnterprise = assetConfigService.getTransitiveDepth(depthConfig, Enterprise.class,
            Enterprise.class);
        Assert.assertEquals(0, actualDepthEnterpriseEnterprise);

        int actualDepthEnterpriseSite = assetConfigService.getTransitiveDepth(depthConfig, Enterprise.class,
            Site.class);
        Assert.assertEquals(2, actualDepthEnterpriseSite);

        int actualDepthEnterpriseSegment = assetConfigService.getTransitiveDepth(depthConfig, Enterprise.class,
            Segment.class);
        Assert.assertEquals(5, actualDepthEnterpriseSegment);

        int actualDepthEnterpriseAsset = assetConfigService.getTransitiveDepth(depthConfig, Enterprise.class,
            Asset.class);
        Assert.assertEquals(9, actualDepthEnterpriseAsset);

        int actualDepthSiteSite = assetConfigService.getTransitiveDepth(depthConfig, Site.class, Site.class);
        Assert.assertEquals(1, actualDepthSiteSite);

        int actualDepthSiteSegment = assetConfigService.getTransitiveDepth(depthConfig, Site.class, Segment.class);
        Assert.assertEquals(4, actualDepthSiteSegment);

        int actualDepthSiteAsset = assetConfigService.getTransitiveDepth(depthConfig, Site.class, Asset.class);
        Assert.assertEquals(8, actualDepthSiteAsset);

        int actualDepthSegmentSegment = assetConfigService.getTransitiveDepth(depthConfig, Segment.class,
            Segment.class);
        Assert.assertEquals(2, actualDepthSegmentSegment);

        int actualDepthSegmentAsset = assetConfigService.getTransitiveDepth(depthConfig, Segment.class, Asset.class);
        Assert.assertEquals(6, actualDepthSegmentAsset);

        int actualDepthAssetAsset = assetConfigService.getTransitiveDepth(depthConfig, Asset.class, Asset.class);
        Assert.assertEquals(3, actualDepthAssetAsset);
    }

    @Ignore("In 'postgres' implementation, there is no concept of transitive depth. Hence ignoring this testcase")
    @Test
    public void test_multipleRequestsReusesDepthConfig() {
        AssetConfig assetConfig = new AssetConfig();
        assetConfig.setTransitiveDepthConfig(depthConfig);

        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(HttpEntity.class), eq(AssetConfig.class)))
            .thenReturn(new ResponseEntity<AssetConfig>(assetConfig, HttpStatus.OK));
        Assert.assertEquals(assetConfigService.getConfiguration(), assetConfig);

        AssetConfig assetConfigNew = new AssetConfig();
        assetConfigNew.setTransitiveDepthConfig(createDepthConfig(1, 1, 1, 1));

        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(HttpEntity.class), eq(AssetConfig.class)))
            .thenReturn(new ResponseEntity<AssetConfig>(assetConfigNew, HttpStatus.OK));

        Assert.assertEquals(assetConfigService.getConfiguration(), assetConfig);
    }

    private PredixAssetTransitiveDepthConfig createDepthConfig(int enterprises, int sites, int segments, int assets) {
        PredixAssetTransitiveDepthConfig dc = new PredixAssetTransitiveDepthConfig();
        dc.setAssets(assets);
        dc.setSegments(segments);
        dc.setSites(sites);
        dc.setEnterprises(enterprises);
        return dc;
    }

    public String getApmConfigServiceUrl() {
        return "http://ApmConfigService";
    }
}