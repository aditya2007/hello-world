/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.assetgroupassociation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.model.Typed;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;
import com.ge.asset.commons.errorprovider.ErrorConstants;

import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class })
public class AssetGroupAssociationControllerTest extends AbstractAssetGroupAssociationControllerTest
        /*implements ICrudControllerTest<AssetGroupAssociation, IAssetService, AssetGroupAssociationController>*/ {

    @Test(expected = BadRequestException.class)
    public void disassociateNoRequestParameter() {
        assetGroupAssociationController.disassociate(null, null);
    }

    @Test(expected = BadRequestException.class)
    public void disassociateEmptyRequestParameter() {
        assetGroupAssociationController.disassociate("", "");
    }

    @Test(expected = BadRequestException.class)
    public void disassociateEmptyAndNullRequestParameter() {
        assetGroupAssociationController.disassociate("", null);
    }

    @Test(expected = BadRequestException.class)
    public void disassociateInvalidRequestParameter() {
        assetGroupAssociationController.disassociate("/assetGroups/330394cd-f383-39df-a1f1-1094b16a0964", "");
    }

    @Captor
    private ArgumentCaptor<String> queryString;

    @Test
    public void disassociateValidRequest() {
        String groupUri = "/assetGroups/330394cd-f383-39df-a1f1-1094b16a0964";
        String assetUri = "/assets/2c513e1b-1a47-3479-a958-7918183dd118";
        Mockito.doNothing().when(assetGroupAssociationController).disassociate(eq(groupUri), eq(assetUri));
        assetGroupAssociationController.disassociate(groupUri, assetUri);
    }

    @Test(expected = NullPointerException.class)
    public void getAssociatedGroupsOfAnAssetTestInvalidRequestParameter() {
        String assetUri = "sites/a08e6bd7-239d-3941-b84a-27644f9cec1e";
        String category = "asset";
        Typed[] result = assetGroupAssociationController.getAssociatedAssetsOrGroups(assetUri, category, null);
    }

    @Test
    public void getAssociatedGroupsOfAnAssetTest() throws IOException {
        String assetUri = "/sites/a08e6bd7-239d-3941-b84a-27644f9cec1e";
        String category = "asset";
        PowerMockito.doReturn(new Typed[2]).when(assetService).getAssociatedGroupsOfAnAsset(anyString(), eq(assetUri),
            eq(category));
        Typed[] result = assetGroupAssociationController.getAssociatedAssetsOrGroups(assetUri, category, null);
    }

    @Test
    public void associateGroup_with_decommissioned_assets_using_sourcekeys() throws Exception {

        try {
            Map<String, Object> associations = new LinkedHashMap<>();
            Map<String, List> mappedAssetRefs = new LinkedHashMap<>();
            ArrayList assetSourceKeys = new ArrayList();
            Map<String, Object> assetSourceKeysAsMap = new LinkedHashMap<>();

            assetSourceKeysAsMap.put("type", "/assets");
            List<String> srcKeyList = new ArrayList<>();
            srcKeyList.add("ASSET1");
            srcKeyList.add("ASSET2");
            assetSourceKeysAsMap.put("sourceKeys", srcKeyList);
            assetSourceKeys.add(assetSourceKeysAsMap);
            mappedAssetRefs.put("sourceKeys", assetSourceKeys);
            associations.put("assets", mappedAssetRefs);
            associations.put("assetGroupUri", "/assetGroups/a08e6bd7-239d-3941-b84a-27644f9cec1e");

            ObjectMapper objectMapper = new ObjectMapper();
            String jsonStr = objectMapper.writeValueAsString(associations);

            String groupUri = "/assetGroups/a08e6bd7-239d-3941-b84a-27644f9cec1e";
            String queryPredicateStr = "sourceKey=ASSET1|ASSET2";
            Group assetGroup = new Group();
            assetGroup.setUri(groupUri);
            PowerMockito.doReturn(assetGroup).when(assetService).getSingle(groupUri, Group.class,
                AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC));

            QueryPredicate queryPredicate = new QueryPredicate();
            queryPredicate.setPageSize(250);
            queryPredicate.setQuery(java.util.Optional.ofNullable(queryPredicateStr));

            Attributable asset = new Attributable();
            Map<String, Object> reservedAttrs = new HashMap<>();
            Map<String, Object> keyValuemap = new HashMap<>();
            keyValuemap.put("key", "03");
            reservedAttrs.put("state", keyValuemap);
            asset.setReservedAttributes(reservedAttrs);
            asset.setUri("/assets/b18e6bd7-239d-3941-b84a-27644f9cec1b");
            asset.setSourceKey("ASSET1");

            Attributable asset2 = new Attributable();
            reservedAttrs = new HashMap<>();
            keyValuemap = new HashMap<>();
            keyValuemap.put("key", "10");
            reservedAttrs.put("state", keyValuemap);
            asset2.setReservedAttributes(reservedAttrs);
            asset2.setUri("/assets/b28e6bd7-239d-3941-b84a-27644f9cec2b");
            asset2.setSourceKey("ASSET2");
            Attributable[] assets = new Attributable[] { asset, asset2 };
            PowerMockito.doReturn(groupController).when(controllerFactory).getController(eq(Prefixes.Groups));
            PowerMockito.doReturn(assetController).when(controllerFactory).getSearchController(eq(Prefixes.Assets));
            PowerMockito.doReturn(assetGroup).when(groupController).getSingle(
                eq("a08e6bd7-239d-3941-b84a-27644f9cec1e"), eq(AssetComponentResolver.BASIC));
            PowerMockito.doReturn(assets).when(assetController).query(anyString(), anyString(), anyInt(), anyString(),
                anyString());

            assetGroupAssociationController.associate(associations);
            Assert.fail("Expecting BadRequestException");
        } catch (Exception ex) {
            Assert.assertTrue(ex instanceof BadRequestException);
            Assert.assertEquals(ErrorConstants.REFERENCING_DECOMMISSIONED_ASSET_IS_NOT_ALLOWED,
                ((BadRequestException) ex).getCode());
        }
    }

    @Test
    public void associateGroup_with_assets_using_sourcekeys_where_sourceKeys_do_not_exist_OR_not_accessible()
        throws Exception {

        try {
            Map<String, Object> associations = new LinkedHashMap<>();
            Map<String, List> mappedAssetRefs = new LinkedHashMap<>();
            ArrayList assetSourceKeys = new ArrayList();
            Map<String, Object> assetSourceKeysAsMap = new LinkedHashMap<>();

            assetSourceKeysAsMap.put("type", "/assets");
            List<String> srcKeyList = new ArrayList<>();
            srcKeyList.add("ASSET1");
            srcKeyList.add("ASSET2");
            assetSourceKeysAsMap.put("sourceKeys", srcKeyList);
            assetSourceKeys.add(assetSourceKeysAsMap);
            mappedAssetRefs.put("sourceKeys", assetSourceKeys);
            associations.put("assets", mappedAssetRefs);
            associations.put("assetGroupUri", "/assetGroups/a08e6bd7-239d-3941-b84a-27644f9cec1e");

            String groupUri = "/assetGroups/a08e6bd7-239d-3941-b84a-27644f9cec1e";
            Group assetGroup = new Group();
            assetGroup.setUri(groupUri);
            PowerMockito.doReturn(assetGroup).when(assetService).getSingle(groupUri, Group.class,
                AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC));

            Attributable asset = new Attributable();
            Map<String, Object> reservedAttrs = new HashMap<>();
            Map<String, Object> keyValuemap = new HashMap<>();
            keyValuemap.put("key", "03");
            reservedAttrs.put("state", keyValuemap);
            asset.setReservedAttributes(reservedAttrs);
            asset.setUri("/assets/b18e6bd7-239d-3941-b84a-27644f9cec1b");
            asset.setSourceKey("ASSET1");

            Attributable[] assets = new Attributable[] { asset };
            PowerMockito.doReturn(groupController).when(controllerFactory).getController(eq(Prefixes.Groups));
            PowerMockito.doReturn(assetController).when(controllerFactory).getSearchController(eq(Prefixes.Assets));
            PowerMockito.doReturn(assetGroup).when(groupController).getSingle(
                eq("a08e6bd7-239d-3941-b84a-27644f9cec1e"), eq(AssetComponentResolver.BASIC));
            PowerMockito.doReturn(assets).when(assetController).query(queryString.capture(), anyString(), anyInt(),
                anyString(), anyString());

            assetGroupAssociationController.associate(associations);
            Assert.fail("Expecting BadRequestException");
        } catch (Exception ex) {
            Assert.assertTrue(ex instanceof BadRequestException);
            Assert.assertEquals(ErrorConstants.SOURCE_KEYS_MISMATCH, ((BadRequestException) ex).getCode());
            Assert.assertEquals("sourceKey=ASSET2|sourceKey=ASSET1", queryString.getValue());
        }
    }

    @Test
    public void associateGroup_with_assets_using_uris_where_one_of_the_asset_is_decommissioned() throws Exception {

        try {
            Map<String, Object> associations = new LinkedHashMap<>();
            Map<String, List> mappedAssetRefs = new LinkedHashMap<>();
            ArrayList asseturis = new ArrayList();
            asseturis.add("/assets/a08e6bd7-239d-3941-b84a-27644f9cec1a");
            asseturis.add("/assets/b08e6bd7-239d-3941-b84a-27644f9cec1b");
            mappedAssetRefs.put("uris", asseturis);
            associations.put("assets", mappedAssetRefs);
            associations.put("assetGroupUri", "/assetGroups/a08e6bd7-239d-3941-b84a-27644f9cec1e");

            ObjectMapper objectMapper = new ObjectMapper();
            String jsonStr = objectMapper.writeValueAsString(associations);

            String groupUri = "/assetGroups/a08e6bd7-239d-3941-b84a-27644f9cec1e";
            String queryPredicateStr = "sourceKey=ASSET1|ASSET2";
            Group assetGroup = new Group();
            assetGroup.setUri(groupUri);
            PowerMockito.doReturn(assetGroup).when(assetService).getSingle(groupUri, Group.class,
                AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC));

            Attributable asset = new Attributable();
            Map<String, Object> reservedAttrs = new HashMap<>();
            Map<String, Object> keyValuemap = new HashMap<>();
            keyValuemap.put("key", "03");
            reservedAttrs.put("state", keyValuemap);
            asset.setReservedAttributes(reservedAttrs);
            asset.setUri("/assets/a08e6bd7-239d-3941-b84a-27644f9cec1a");
            asset.setSourceKey("ASSET1");

            Attributable asset2 = new Attributable();
            reservedAttrs = new HashMap<>();
            keyValuemap = new HashMap<>();
            keyValuemap.put("key", "10");
            reservedAttrs.put("state", keyValuemap);
            asset2.setReservedAttributes(reservedAttrs);
            asset2.setUri("/assets/b08e6bd7-239d-3941-b84a-27644f9cec1b");
            asset2.setSourceKey("ASSET2");
            Attributable[] assets = new Attributable[] { asset, asset2 };

            PowerMockito.doReturn(groupController).when(controllerFactory).getController(eq(Prefixes.Groups));
            PowerMockito.doReturn(assetController).when(controllerFactory).getSearchController(eq(Prefixes.Assets));
            PowerMockito.doReturn(assetGroup).when(groupController).getSingle(
                eq("a08e6bd7-239d-3941-b84a-27644f9cec1e"), eq(AssetComponentResolver.BASIC));
            PowerMockito.doReturn(assets).when(assetController).query(queryString.capture(), anyString(), anyInt(),
                anyString(), anyString());

            assetGroupAssociationController.associate(associations);
            Assert.fail("Expecting BadRequestException");
        } catch (Exception ex) {
            Assert.assertTrue(ex instanceof BadRequestException);
            Assert.assertEquals(ErrorConstants.REFERENCING_DECOMMISSIONED_ASSET_IS_NOT_ALLOWED,
                ((BadRequestException) ex).getCode());
            Assert.assertEquals("uri=/assets/a08e6bd7-239d-3941-b84a-27644f9cec1a|uri=/assets/b08e6bd7-239d-3941"
                + "-b84a-27644f9cec1b", queryString.getValue());
        }
    }

    @Test
    public void associateAsset_with_groups_where_asset_is_decommissioned() throws Exception {

        try {
            Map<String, Object> associations = new LinkedHashMap<>();
            Map<String, List> mappedAssetGroupRefs = new LinkedHashMap<>();
            ArrayList assetGroupUris = new ArrayList();
            assetGroupUris.add("/assetGroups/a08e6bd7-239d-3941-b84a-27644f9cec1a");
            assetGroupUris.add("/assetGroups/b08e6bd7-239d-3941-b84a-27644f9cec1b");
            mappedAssetGroupRefs.put("uris", assetGroupUris);
            associations.put("assetGroups", mappedAssetGroupRefs);
            associations.put("assetUri", "/assets/a08e6bd7-239d-3941-b84a-27644f9cec1e");

            Attributable asset = new Attributable();
            Map<String, Object> reservedAttrs = new HashMap<>();
            Map<String, Object> keyValuemap = new HashMap<>();
            keyValuemap.put("key", "10");
            reservedAttrs.put("state", keyValuemap);
            asset.setReservedAttributes(reservedAttrs);
            asset.setUri("/assets/a08e6bd7-239d-3941-b84a-27644f9cec1e");
            asset.setSourceKey("ASSET1");

            Attributable[] assets = new Attributable[] { asset };

            PowerMockito.doReturn(assetController).when(controllerFactory).getController(eq(Prefixes.Assets));
            PowerMockito.doReturn(asset).when(assetController).getSingle(eq("a08e6bd7-239d-3941-b84a-27644f9cec1e"),
                eq(AssetComponentResolver.BASIC));

            assetGroupAssociationController.associate(associations);
            Assert.fail("Expecting BadRequestException");
        } catch (Exception ex) {
            Assert.assertTrue(ex instanceof BadRequestException);
            Assert.assertEquals(ErrorConstants.REFERENCING_DECOMMISSIONED_ASSET_IS_NOT_ALLOWED,
                ((BadRequestException) ex).getCode());
        }
    }
}
