/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.asset.controller.base.ITagController;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.NextCorrelatedTag;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.common.exception.ServiceException;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Created by 212448111 on 2/16/17.
 */
public class TagProcessorTest extends AbstractProcessorTest {

    @InjectMocks
    @Autowired
    TagProcessor tagProcessor;

    @Mock
    ITagController tagController;

    @Captor
    ArgumentCaptor<MeasurementTag[]> tagsArgCaptor;

    @Before
    public void setup() {
        super.setup();
        doNothing().when(tagController).associateTags(anyString(), anyObject());
        when(controllerFactory.getTagController(anyString())).thenReturn(tagController);
    }

    @Test(expected = ServiceException.class)
    public void processInvalidMonitoredEntitySrcKey() {
        doAnswer(a -> {
            MeasurementTag[] tags = new MeasurementTag[1];
            tags[0] = new MeasurementTag();
            tags[0].setMonitoredEntitySourceKey("monitoredSourceKey1");
            return tags;
        }).when(super.message).getBody(anyObject());
        tagProcessor.process(super.exchange);
    }

    @Test
    public void processInvalidTagTypeSrcKey() {
        doAnswer(a -> {
            String monitoredEntitySrcKey = Prefixes.Assets + "/monitoredSourceKey1";
            MeasurementTag[] tags = new MeasurementTag[1];
            tags[0] = new MeasurementTag();
            tags[0].setMonitoredEntitySourceKey(monitoredEntitySrcKey);
            tags[0].setSourceKey("sourceKey1");
            return tags;
        }).when(super.message).getBody(anyObject());

        when(super.sourceKeyLookup
            .lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.Assets + "/" + "monitoredSourceKey1"))).thenReturn(
            Prefixes.Assets + "/mockUri");
        tagProcessor.process(super.exchange);
    }

    @Test
    public void processSomeTagsWithInvalidTypeSrcKey() {
        String monitoredEntitySrcKey = Prefixes.Assets + "/monitoredSourceKey1";

        doAnswer(a -> {
            MeasurementTag[] tags = new MeasurementTag[2];
            tags[0] = new MeasurementTag();
            tags[0].setMonitoredEntitySourceKey(monitoredEntitySrcKey);
            tags[0].setSourceKey("sourceKey1");

            tags[1] = new MeasurementTag();
            tags[1].setMonitoredEntitySourceKey(monitoredEntitySrcKey);
            tags[1].setSourceKey("sourceKey2");
            tags[1].setType("typeSourceKey");
            return tags;
        }).when(super.message).getBody(anyObject());

        when(super.sourceKeyLookup.lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.Assets + "monitoredSourceKey1")))
            .thenReturn(Prefixes.Assets + "/mockUri");
        when(super.sourceKeyLookup
            .lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.MeasurementTagTypes + "/" + "typeSourceKey")))
            .thenReturn(Prefixes.MeasurementTagTypes + "/mockUri");
        doNothing().when(super.message).setBody(tagsArgCaptor.capture());
        try {
            tagProcessor.process(super.exchange);
        } catch (Exception e) {
            assertThat("Dependency violation not thrown", e, instanceOf(DependencyViolationException.class));
            MeasurementTag[] tagsToRetry = tagsArgCaptor.getValue();
            assertThat("Remaing tags to retry is null", tagsToRetry, notNullValue());
            assertThat("Remaining tags to retry incorrect", tagsToRetry.length, equalTo(1));
        }
    }

    @Test(expected = DependencyViolationException.class)
    public void processSomeTagsWithInvalidRelatedTag() {
        String monitoredEntitySrcKey = Prefixes.Assets + "/monitoredSourceKey1";

        doAnswer(a -> {
            MeasurementTag[] tags = new MeasurementTag[2];
            tags[0] = new MeasurementTag();
            tags[0].setMonitoredEntitySourceKey(monitoredEntitySrcKey);
            tags[0].setSourceKey("sourceKey1");
            NextCorrelatedTag nextCorrelatedTag = new NextCorrelatedTag();
            nextCorrelatedTag.setTagUri("sourceKey3");
            tags[0].setNextRelatedTag(nextCorrelatedTag);

            tags[1] = new MeasurementTag();
            tags[1].setMonitoredEntitySourceKey(monitoredEntitySrcKey);
            tags[1].setSourceKey("sourceKey2");
            tags[1].setType("typeSourceKey");

            return tags;
        }).when(super.message).getBody(anyObject());

        when(super.sourceKeyLookup
            .lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.Assets + "/" + "monitoredSourceKey1"))).thenReturn(
            Prefixes.Assets + "/mockUri");
        when(super.sourceKeyLookup
            .lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.MeasurementTagTypes + "/" + "typeSourceKey")))
            .thenReturn(Prefixes.MeasurementTagTypes + "/mockUri");
        doThrow(DependencyViolationException.class).when(sourceKeyLookup).lookupObjectUriFor(super.tenantId,
            Prefixes.MeasurementTags + "/sourceKey3");
        doNothing().when(super.message).setBody(tagsArgCaptor.capture());
        try {
            tagProcessor.process(super.exchange);
        } catch (Exception e) {
            assertThat("Dependency violation not thrown", e, instanceOf(DependencyViolationException.class));
            MeasurementTag[] tagsToRetry = tagsArgCaptor.getValue();
            assertThat("Remaing tags to retry is null", tagsToRetry, notNullValue());
            assertThat("Remaining tags to retry incorrect", tagsToRetry.length, equalTo(1));
            throw e;
        }
        fail("Dependency violation not thrown");
    }

    @Test(expected = DependencyViolationException.class)
    public void processSomeTagsWithInvalidRelatedTag_TypeDoesNotExist() {
        String monitoredEntitySrcKey = Prefixes.Assets + "/monitoredSourceKey1";

        doAnswer(a -> {
            MeasurementTag[] tags = new MeasurementTag[2];
            tags[0] = new MeasurementTag();
            tags[0].setMonitoredEntitySourceKey(monitoredEntitySrcKey);
            tags[0].setType("typeSourceKey");
            tags[0].setSourceKey("sourceKey1");
            NextCorrelatedTag nextCorrelatedTag = new NextCorrelatedTag();
            nextCorrelatedTag.setTagUri("sourceKey3");
            tags[0].setNextRelatedTag(nextCorrelatedTag);

            tags[1] = new MeasurementTag();
            tags[1].setMonitoredEntitySourceKey(monitoredEntitySrcKey);
            tags[1].setSourceKey("sourceKey2");
            tags[1].setType("typeSourceKey2");

            return tags;
        }).when(super.message).getBody(anyObject());

        when(super.sourceKeyLookup
            .lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.Assets + "/" + "monitoredSourceKey1"))).thenReturn(
            Prefixes.Assets + "/mockUri");
        doThrow(DependencyViolationException.class).when(sourceKeyLookup).lookupObjectUriFor(super.tenantId,
            Prefixes.MeasurementTagTypes + "/" + "typeSourceKey");
        when(super.sourceKeyLookup
            .lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.MeasurementTagTypes + "/" + "typeSourceKey2")))
            .thenReturn(Prefixes.MeasurementTagTypes + "/mockUri");
        doThrow(DependencyViolationException.class).when(sourceKeyLookup).lookupObjectUriFor(super.tenantId,
            Prefixes.MeasurementTags + "/sourceKey3");
        doNothing().when(super.message).setBody(tagsArgCaptor.capture());
        try {
            tagProcessor.process(super.exchange);
        } catch (Exception e) {
            assertThat("Dependency violation not thrown", e, instanceOf(DependencyViolationException.class));
            MeasurementTag[] tagsToRetry = tagsArgCaptor.getValue();
            assertThat("Remaing tags to retry is null", tagsToRetry, notNullValue());
            assertThat("Remaining tags to retry incorrect", tagsToRetry.length, equalTo(1));
            throw e;
        }
        fail("Dependency violation not thrown");
    }
}
