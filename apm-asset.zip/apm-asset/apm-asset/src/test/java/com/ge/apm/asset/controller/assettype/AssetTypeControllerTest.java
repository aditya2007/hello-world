/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.assettype;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.asset.api.crud.ICrudControllerTest;
import com.ge.apm.asset.api.hierarchy.IHierarchyControllerTest;
import com.ge.apm.asset.controller.AssetController;
import com.ge.apm.asset.controller.AssetTypeController;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAssetTypeService;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class })
public class AssetTypeControllerTest extends AbstractAssetTypeControllerTest
    implements ICrudControllerTest<AssetType, IAssetTypeService, AssetTypeController>,
    IHierarchyControllerTest<AssetType, IAssetTypeService, AssetTypeController> {

    @Test
    public void testReservedAttributes() throws IllegalAccessException {
        ReflectionUtils.setField(AssetController.class, getController(), "assetConfigService", assetConfigService);
        Map<String, ReservedAttributeConfig> actual = getController().reservedAttributes();
        Assert.assertNotNull(actual);
        Assert.assertEquals(8, actual.size());
    }

    @Test(expected = BadRequestException.class)
    public void testCreateWithInvalidPayload() throws IOException {
        AssetType[] objects = readObjectsFromResourceFile(getInputPath() + "/create_invalid.json", getObjectClass());
        getController().create(Arrays.asList(objects));
    }

    @Test(expected = BadRequestException.class)
    public void create_withNonReservedAttributes() throws IOException, IllegalAccessException {
        ReflectionUtils.setField(AssetController.class, getController(), "assetConfigService", assetConfigService);
        AssetType[] objects = readObjectsFromResourceFile(getInputPath() + "/create_withNonReservedAttributes.json",
            getObjectClass());
        getController().create(Arrays.asList(objects));
    }

    @Test(expected = BadRequestException.class)
    public void create_ReservedAttributeWithInvalidDataType() throws IOException, IllegalAccessException {
        ReflectionUtils.setField(AssetController.class, getController(), "assetConfigService", assetConfigService);
        AssetType[] objects = readObjectsFromResourceFile(
            getInputPath() + "/create_ReservedAttributeWithInvalidDataType.json", getObjectClass());
        getController().create(Arrays.asList(objects));
    }

    @Test(expected = BadRequestException.class)
    public void updateSingle_withNonReservedAttributes() throws IOException, IllegalAccessException {
        ReflectionUtils.setField(AssetController.class, getController(), "assetConfigService", assetConfigService);
        AssetType[] predixObjects = readObjectsFromResourceFile(getPredixPath() + "/getSingleWithBasic.json",
            getObjectClass());
        setupGetByTypeUriFromPersistence(Prefixes.uri(getPrefix(), UUID1), predixObjects[0]);
        PatchOperation[] patchOperations = readObjectsFromResourceFile(
            getInputPath() + "/updateSingle_withNonReservedAttributes.json", PatchOperation.class);
        setupUpdateTypeToPersistence(Prefixes.uri(getPrefix(), UUID1), patchOperations);
        getController().updateSingle(UUID1, Arrays.asList(patchOperations));
    }

    @Test
    public void getFaultModeAsAnArray() throws IOException, IllegalAccessException {
        ReflectionUtils.setField(AssetController.class, getController(), "assetConfigService", assetConfigService);
        AssetType[] predixObjects = readObjectsFromResourceFile(
            getPredixPath() + "/getByCriteria_withFaultModeAsArray.json", getObjectClass());
        setupGetFromPersistence(predixObjects, getObjectClass());

        AssetType[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/getByCriteria.json",
            getObjectClass());
        AssetType[] actualObjects = getController().getByCriteria(null, null, null, null, null, null,
            AssetComponentResolver.ATTRIBUTES, null, null, null);
        Assert.assertArrayEquals(expectedFetchedObjects, actualObjects);
    }

    @Test
    public void returnReservedAttributesAsPerLatestConfig_PredixAssetHasDiffFromConfig()
        throws IOException, IllegalAccessException {
        ReflectionUtils.setField(AssetController.class, getController(), "assetConfigService", assetConfigService);
        AssetType[] predixObjects = readObjectsFromResourceFile(
            getPredixPath() + "/reservedAttributesInPredixAssetDiffFromConfig.json", getObjectClass());
        setupGetFromPersistence(predixObjects, getObjectClass());
        AssetType[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/getByCriteria.json",
            getObjectClass());
        AssetType[] actualObjects = getController().getByCriteria(null, null, null, null, null, null,
            AssetComponentResolver.ATTRIBUTES, null, null, null);
        Assert.assertArrayEquals(expectedFetchedObjects, actualObjects);
    }
}
