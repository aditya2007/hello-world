/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.group;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;

import com.ge.apm.asset.api.crud.ICrudControllerTest;
import com.ge.apm.asset.controller.GroupController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.model.GroupType;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;
import com.ge.asset.commons.errorprovider.ErrorConstants;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.startsWith;

/**
 * Created by 212319603 on 2/23/16.
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class })
public class GroupControllerTest extends AbstractGroupControllerTest
    implements ICrudControllerTest<Group, IAssetService, GroupController> {

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    @Override
    @Test
    public void create() throws IOException {
        Group[] objects = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        Map<String, Object> urlVariablesForGroupType = new HashMap<>();
        urlVariablesForGroupType.put("pageSize", 1);
        GroupType[] groupTypes = readObjectsFromResourceFile(getPredixPath() + "/type.json", GroupType.class);
        Group[] predixObjects = readObjectsFromResourceFile(getPredixPath() + "/create.json", getObjectClass());

        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 250);
        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());
        urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);
        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());

        setupGetBySourceKeysFromPersistence(new String[] { objects[0].getSourceKey() }, null, getPrefix(),
            getObjectClass());
        setupCreateToPersistence(objects);
        Group[] createdObjects = getController().create(Arrays.asList(objects));
        Group[] expectedCreatedObjects = readObjectsFromResourceFile(getOutputPath() + "/create.json",
            getObjectClass());

        Assert.assertArrayEquals(expectedCreatedObjects, createdObjects);

    }

    @Test(expected = ServiceException.class)
    public void create_Association_Invalid_Group() {
        Mockito.doThrow(ServiceException.class).when(restTemplate).getForObject(
            getPredixBaseUrl() + Prefixes.uri(Prefixes.Groups, "1"), Group.class);
        getController().associateMembers("1", new String[] { "member1", "member2", "member3" });
    }

    @Test
    public void create_Existing_Association_For_Tags() throws IOException {
        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Groups, "1"),
            readObjectsFromResourceFile(getPredixPath() + "/getSingleWithAttributes.json", Group.class)[0], false);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Groups, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/getSingleWithAttributes.json", Group.class)[0], false);
        setupGetGroupMembersFromPersistence(Prefixes.uri(Prefixes.Groups, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/getSingleWithAttributes.json", Group.class));
        setupGetBySourceKeysFromPersistence(new String[] { "Asset1" },
            readObjectsFromResourceFile(getPredixPath() + "/getAssetSingleWithBasic.json", Asset.class),
            Prefixes.Assets, Asset.class);
        MeasurementTag exstTag = new MeasurementTag();
        exstTag.setSourceKey("TagA1");
        exstTag.setMonitoredEntitySourceKey("Asset1");
        exstTag.setMonitoredEntityUri("/assets/bb571726-c1a3-4610-99de-435ab7f74000");
        setupGetBySourceKeysFromPersistence(new String[] { "TagA1" }, new MeasurementTag[] { exstTag },
            Prefixes.MeasurementTags, MeasurementTag.class);
        setupAssociateGroupMembersFromPersistence(Prefixes.GroupAssociations);
        getController().associateMembers("1", new String[] { "TagA1" });
    }

    @Test
    public void create_Existing_Association_For_Tags_With_Asset_Decommissioned() throws Exception {
        try {
            setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Groups, "1"),
                readObjectsFromResourceFile(getPredixPath() + "/getSingleWithAttributes.json", Group.class)[0], false);
            setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Groups, UUID1),
                readObjectsFromResourceFile(getPredixPath() + "/getSingleWithAttributes.json", Group.class)[0], false);
            setupGetGroupMembersFromPersistence(Prefixes.uri(Prefixes.Groups, UUID1),
                readObjectsFromResourceFile(getPredixPath() + "/getSingleWithAttributes.json", Group.class));
            setupGetBySourceKeysFromPersistence(new String[] { "SampleAsset" },
                readObjectsFromResourceFile(getPredixPath() + "/decommissionedAsset.json", Asset.class),
                Prefixes.Assets, Asset.class);

            MeasurementTag exstTag = new MeasurementTag();
            exstTag.setSourceKey("TagA1");
            exstTag.setMonitoredEntityUri("/assets/bb571726-c1a3-4610-99de-435ab7f74000");
            exstTag.setMonitoredEntitySourceKey("SampleAsset");

            setupGetBySourceKeysFromPersistence(new String[] { "TagA1" }, new MeasurementTag[] { exstTag },
                Prefixes.MeasurementTags, MeasurementTag.class);
            setupAssociateGroupMembersFromPersistence(Prefixes.GroupAssociations);
            getController().associateMembers("1", new String[] { "TagA1" });
            Assert.fail("Expecting the test case to fail");
        } catch (Exception ex) {
            Assert.assertTrue(ex instanceof BadRequestException);
            Assert.assertEquals(ErrorConstants.INVALID_GROUP_ASSOCIATION_OF_DECOMMISSIONED_ASSET,
                ((BadRequestException) ex).getCode());
        }
    }

    @Test
    public void create_Existing_Association_For_Assets() throws IOException {

        String groupUri = "/assetGroups/bb571726-c1a3-4610-99de-435ab7f74000";
        Group group = new Group();
        group.setCategory("ASSET");
        group.setUri(groupUri);

        PowerMockito.doReturn(group).when(assetService).getSingle(groupUri, Group.class,
            AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC));

        Asset asset1 = new Asset();
        asset1.setSourceKey("asset1");
        asset1.setName("asset1");
        asset1.setUri("/assets/bb571726-c1a3-4610-99de-435ab7f74000");

        Asset asset2 = new Asset();
        asset2.setSourceKey("asset2");
        asset2.setName("asset2");
        asset2.setUri("/assets/bb571726-c1a3-4610-99de-435ab7f74001");

        PowerMockito.doReturn(new Group[] { group }).when(assetService).getMembersOfGroup(groupUri);

        setupGetBySourceKeysFromPersistence(new String[] { "asset1", "asset2" }, new Asset[] { asset1, asset2 },
            Prefixes.Assets, Asset.class);
        setupAssociateGroupMembersFromPersistence(Prefixes.GroupAssociations);
        getController().associateMembers("bb571726-c1a3-4610-99de-435ab7f74000", new String[] { "asset1", "asset2" });
    }

    @Test
    public void create_Existing_Association_For_Assets_With_Assets_Decommissioned() throws Exception {

        try {
            String groupUri = "/assetGroups/bb571726-c1a3-4610-99de-435ab7f74000";
            Group group = new Group();
            group.setCategory("ASSET");
            group.setUri(groupUri);

            PowerMockito.doReturn(group).when(assetService).getSingle(groupUri, Group.class, AssetComponentResolver.parseComponents(AssetComponentResolver.BASIC));

            Map<String, Object> reservedAttrs = new HashMap<>();
            Map<String, Object> keyValuemap = new HashMap<>();
            keyValuemap.put("key", "10");
            reservedAttrs.put("state", keyValuemap);
            Asset asset1 = new Asset();
            asset1.setSourceKey("asset1");
            asset1.setName("asset1");
            asset1.setUri("/assets/bb571726-c1a3-4610-99de-435ab7f74000");
            asset1.setReservedAttributes(reservedAttrs);

            Asset asset2 = new Asset();
            asset2.setSourceKey("asset2");
            asset2.setName("asset2");
            asset2.setUri("/assets/bb571726-c1a3-4610-99de-435ab7f74001");

            PowerMockito.doReturn(new Group[] { group }).when(assetService).getMembersOfGroup(groupUri);

            setupGetBySourceKeysFromPersistence(new String[] { "asset1", "asset2" }, new Asset[] { asset1, asset2 },
                Prefixes.Assets, Asset.class);
            setupAssociateGroupMembersFromPersistence(Prefixes.GroupAssociations);
            getController().associateMembers("bb571726-c1a3-4610-99de-435ab7f74000", new String[] { "asset1", "asset2" });
        } catch (Exception ex) {
            Assert.assertTrue(ex instanceof BadRequestException);
            Assert.assertEquals(ErrorConstants.INVALID_GROUP_ASSOCIATION_OF_DECOMMISSIONED_ASSET,
                ((BadRequestException) ex).getCode());
        }

    }

    @Test(expected = ServiceException.class)
    public void create_Association_With_Missing_Member() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1000);
        urlVariables.put("filter",
            "(uri=" + Prefixes.uri(Prefixes.Groups, "bb571726-c1a3-4610-99de-435ab7f74000") + ")<toUri");

        Mockito.doThrow(new NotFoundException("")).when(restTemplate).exchange(
            startsWith(getPredixBaseUrl() + Prefixes.MeasurementTags + "?"), eq(HttpMethod.GET), any(HttpEntity.class),
            eq(MeasurementTag.class), any(Map.class));
        getController().associateMembers("1", new String[] { "TagA2" });
    }

    //    @Test
    //    public void deleteAssociatedMember() throws IOException{
    //        Map<String, Object> tagUrlVariables = new HashMap<>();
    //        tagUrlVariables.put("filter", "sourceKey=TagA1");
    //        tagUrlVariables.put("pageSize", 1);
    //
    //        setupGETFor(getPredixBaseUrl() + Prefixes.MeasurementTags,
    //                readObjectsFromResourceFile("/predix/tags/bySourceKey.json", MeasurementTag
    // .class),
    //                tagUrlVariables,MeasurementTag.class);
    //
    //        setupGETFor(getPredixBaseUrl() + Prefixes.uri(Prefixes.Groups, "1"),
    //                readObjectsFromResourceFile("/predix/assetGroups/getSingleWithAttributes
    // .json", Group.class));
    //
    //        Map<String, Object> gaVariables = new HashMap<>();
    //        gaVariables.put("pageSize", 1000);
    //        gaVariables.put("filter",
    //                "(uri=" + Prefixes.uri(Prefixes.Groups,
    // "bb571726-c1a3-4610-99de-435ab7f74000") +")<toUri");
    //        setupGETFor(getPredixBaseUrl() +Prefixes.GroupAssociations,
    //                readObjectsFromResourceFile
    // ("/predix/groupAssociations/getSingleWithSourceKey.json",
    //                        GroupAssociation.class),gaVariables,GroupAssociation.class);
    //
    //        setupDELETEFor(getPredixBaseUrl() + "/groupAssociations/testURI");
    //
    //        GroupAssociation[] objects = readObjectsFromResourceFile
    // ("/predix/groupAssociations/getSingleWithSourceKey.json",
    //            GroupAssociation.class);
    //
    //        getController().disassociateMembers("1", new String[] { "TagA1" });
    //        for (int i = 0; i < objects.length; i++) {
    //            verifyDELETECalled(getPredixBaseUrl() + objects[i].getUri());
    //        }
    //    }

    @Test
    public <T> void getAssociateMembers() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1000);
        urlVariables.put("filter",
            "((uri=" + Prefixes.uri(Prefixes.Groups, "bb571726-c1a3-4610-99de-435ab7f74000") + ")<toUri)>fromUri[t1]");

        Map<String, Object> tagUrlVariables = new HashMap<>();
        tagUrlVariables.put("pageSize", 1);
        tagUrlVariables.put("filter",
            "uri=" + Prefixes.uri(Prefixes.MeasurementTags, "000cf0b4-fe82-4697-a4b7-56acf713664c"));

        Map<String, Object> tagTypeUrlVariables = new HashMap<>();
        tagTypeUrlVariables.put("pageSize", 1);

        Map<String, Object> groupAssociationUrlVariables = new HashMap<>();
        groupAssociationUrlVariables.put("filter", "sourceKey=* to TagGroupType2_instance1 association");
        groupAssociationUrlVariables.put("pageSize", 1000);

        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Groups, "1"),
            readObjectsFromResourceFile(getPredixPath() + "/getSingleWithAttributes.json", Group.class)[0], false);

        setupGetGroupMembersFromPersistence(Prefixes.uri(Prefixes.Groups, "1"),
            readObjectsFromResourceFile("/predix/tags/bySourceKey.json", MeasurementTag.class));

        T[] members = (T[]) getController().getAssociateMembers("1");
        Assert.assertEquals(members.length, 1);
        Assert.assertEquals("TAG URI is not matching", ((MeasurementTag) members[0]).getUri(),
            "/tags/bb571726-c1a3-4610-99de-435ab7f74000");
    }

    @Test
    public void createWithInvalidParentInRequest() {
        //TODO: review needed
    }

    @Test
    public void createWithExistingSourceKey() throws IOException {

        expectedEx.expect(BadRequestException.class);

        Map<String, Object> groupVariables = new HashMap<>();
        groupVariables.put("filter", "sourceKey=TagGroupType2_instance1");
        groupVariables.put("pageSize", 1);

        Group[] objects = readObjectsFromResourceFile(getInputPath() + "/createWithInvalidTypeInRequest.json",
            getObjectClass());
        setupGetBySourceKeyFromPersistence(objects[0].getSourceKey(), objects[0], getObjectClass());

        getController().create(Arrays.asList(objects));
        expectedEx.expectMessage(
            "Invalid type " + objects[0].getType() + " specified for Group: " + objects[0].getSourceKey());
    }

    @Test
    public void createWithInvalidTypeInRequest() throws IOException {

        expectedEx.expect(BadRequestException.class);

        Map<String, Object> groupVariables = new HashMap<>();
        groupVariables.put("filter", "sourceKey=TagGroupType2_instance1");
        groupVariables.put("pageSize", 1);

        Group[] objects = readObjectsFromResourceFile(getInputPath() + "/createWithInvalidTypeInRequest.json",
            getObjectClass());
        setupGetBySourceKeyFromPersistence(objects[0].getSourceKey(), null, getObjectClass());

        Mockito.when(RequestContext.get(RequestContext.SERVICE_REST_TEMPLATE)).thenReturn(restTemplate);
        getController().create(Arrays.asList(objects));
        expectedEx.expectMessage(
            "Invalid type " + objects[0].getType() + " specified for Group: " + objects[0].getSourceKey());
    }

    @Test(expected = BadRequestException.class)
    public void updateWithInvalidType() throws IOException {
        PatchOperation[] objects = readObjectsFromResourceFile(getInputPath() + "/updateWithInvalidType.json",
            PatchOperation.class);
        Group[] predixObject = readObjectsFromResourceFile(getPredixPath() + "/getSingleWithAttributes.json",
            getObjectClass());

        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1), predixObject[0], false);
        getController().updateSingle(UUID1, Arrays.asList(objects));
    }

    @Override
    @Test(expected = BadRequestException.class)
    public void createWithSameSourceKeyInRequest() throws IOException {
        Group[] objects = readObjectsFromResourceFile(getInputPath() + "/createMultipleWithSameSourceKey.json",
            getObjectClass());
        Group[] predixObjects = readObjectsFromResourceFile(getPredixPath() + "/create.json", getObjectClass());
        //setupForType(objects[0]);

        expectedEx.expectMessage(getPrefix() + "with source key " + objects[0].getSourceKey()
            + " already exist in either request/datastore");

        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);
        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());
        setupGetBySourceKeyFromPersistence(objects[0].getSourceKey(), null, getObjectClass());

        urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 250);
        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());

        urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);

        urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);

        urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 250);

        getController().create(Arrays.asList(objects));
    }

    @Override
    @Test
    public void createWithSameSourceKey() throws IOException {

        expectedEx.expect(BadRequestException.class);

        Group[] objects = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        Group[] predixObjects = readObjectsFromResourceFile(getPredixPath() + "/create.json", getObjectClass());

        expectedEx.expectMessage(getPrefix() + " with source key " + Arrays.asList(objects[0].getSourceKey())
            + " already exist in either request/datastore");

        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);
        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());
        setupGetBySourceKeysFromPersistence(new String[] { objects[0].getSourceKey() }, predixObjects, getPrefix(),
            getObjectClass());

        getController().create(Arrays.asList(objects));
    }

    private void setupGroupObjects() {

    }

    @Override
    @Test(expected = Exception.class)
    public void delete() throws IOException {
        getController().delete(UUID1);
    }

    @Override
    @Ignore
    public void searchByCriteriaWithComponentsFull() throws IOException {

    }
}
