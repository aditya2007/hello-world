/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.api.base;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.reflect.Whitebox;
import org.springframework.http.HttpEntity;

import com.ge.apm.asset.AssetStateManageBuilder;
import com.ge.apm.asset.HttpActionType;
import com.ge.apm.asset.adapter.api.ITypedAdapter;
import com.ge.apm.asset.adapter.impl.AssetAdapter;
import com.ge.apm.asset.adapter.impl.AssetTypeAdapter;
import com.ge.apm.asset.adapter.impl.EnterpriseAdapter;
import com.ge.apm.asset.adapter.impl.EnterpriseTypeAdapter;
import com.ge.apm.asset.adapter.impl.GroupAdapter;
import com.ge.apm.asset.adapter.impl.MeasurementTagAdapter;
import com.ge.apm.asset.adapter.impl.MeasurementTagTypeAdapter;
import com.ge.apm.asset.adapter.impl.SegmentAdapter;
import com.ge.apm.asset.adapter.impl.SegmentTypeAdapter;
import com.ge.apm.asset.adapter.impl.SiteAdapter;
import com.ge.apm.asset.adapter.impl.SiteTypeAdapter;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.Typed;
import com.ge.apm.asset.service.DeleteAssetStateManagerImpl;
import com.ge.apm.asset.service.IAssetStateManager;
import com.ge.apm.asset.service.api.IAlmPersistenceService;
import com.ge.apm.asset.service.api.IAssetConfigService;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.service.api.IAssetTypeService;
import com.ge.apm.asset.service.component.AssetConfigService;
import com.ge.apm.asset.service.impl.AssetService;
import com.ge.apm.asset.service.impl.AssetTypeService;
import com.ge.apm.asset.util.ReflectionUtils;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;

public abstract class AbstractInstanceControllerTest<C, T extends Typed> extends AbstractControllerTest<C, T> {

    protected final boolean accessControlledTest;

    protected List<ITypedAdapter> typedAdapters;

    protected AssetService assetService;

    @Captor
    protected ArgumentCaptor<HttpEntity<?>> httpEntityCaptor;

    @Captor
    protected ArgumentCaptor<String> urlCaptor;

    @Mock(name = "createAssetStateManager")
    private IAssetStateManager createAssetStateManager;

    @Mock(name = "updateAssetStateManager")
    private IAssetStateManager updateAssetStateManager;

    @Mock(name = "deleteAssetStateManager")
    private IAssetStateManager deleteAssetStateManager;

    @Mock
    private AssetStateManageBuilder assetStateManageBuilder;

    protected AbstractInstanceControllerTest() {
        this.accessControlledTest = false;
    }

    protected AbstractInstanceControllerTest(boolean accessControlledTest) {
        this.accessControlledTest = accessControlledTest;
    }

    static List<ITypedAdapter> spyTypedAdapters(IAssetTypeService ats, IAssetService as, IAssetConfigService iacs,
        IAlmPersistenceService almPersistenceService) throws InstantiationException, IllegalAccessException {
        List<ITypedAdapter> typedAdapters = new ArrayList<>();
        typedAdapters.add(spyTypedAdapter(ats, as, iacs, almPersistenceService, EnterpriseAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, as, iacs, almPersistenceService, SiteAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, as, iacs, almPersistenceService, SegmentAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, as, iacs, almPersistenceService, AssetAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, null, iacs, almPersistenceService, MeasurementTagAdapter.class));
        typedAdapters.add(spyTypedAdapter(null, null, null, almPersistenceService, GroupAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, null, iacs, null, AssetTypeAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, null, iacs, null, MeasurementTagTypeAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, null, null, null, EnterpriseTypeAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, null, null, null, SegmentTypeAdapter.class));
        typedAdapters.add(spyTypedAdapter(ats, null, null, null, SiteTypeAdapter.class));
        return typedAdapters;
    }

    static <T extends ITypedAdapter> ITypedAdapter spyTypedAdapter(IAssetTypeService ats, IAssetService as,
        IAssetConfigService iacs, IAlmPersistenceService almPersistenceService, Class<T> clazz)
        throws InstantiationException, IllegalAccessException {
        T typedAdapter = Mockito.spy(clazz.newInstance());
        if (ats != null) {
            ReflectionUtils.setField(clazz, typedAdapter, "assetTypeService", ats);
        }
        if (as != null) {
            ReflectionUtils.setField(clazz, typedAdapter, "assetService", as);
        }
        if (iacs != null) {
            ReflectionUtils.setField(clazz, typedAdapter, "assetConfigService", iacs);
        }
        if (almPersistenceService != null) {
            ReflectionUtils.setField(clazz, typedAdapter, "almPersistenceService", almPersistenceService);
        }
        return typedAdapter;
    }

    @Override
    protected void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();

        assetService = Mockito.spy(new AssetService());
        deleteAssetStateManager = new DeleteAssetStateManagerImpl();

        //tagRepository = Mockito.mock(IAssetTagRepository.class);
        assetTypeService = Mockito.spy(new AssetTypeService());
        typedAdapters = spyTypedAdapters(assetTypeService, assetService, assetConfigService, almPersistenceService);

        ReflectionUtils.setField(AssetConfigService.class, assetConfigService, "apmConfigServiceUrl",
            getApmConfigServiceUrl());

        ReflectionUtils.setField(AssetConfigService.class, assetConfigService, "restTemplate", getRestTemplate());
        ReflectionUtils.setField(AssetService.class, assetService, "assetCacheManager", assetCacheManager);
        ReflectionUtils.setField(AssetService.class, assetService, "typedAdapters", typedAdapters);
        ReflectionUtils.setField(AssetService.class, assetService, "assetConfigService", assetConfigService);
        ReflectionUtils.setField(AssetService.class, assetService, "assetRestrictionFeaturesEnabled", true);

        ReflectionUtils.setField(AssetService.class, assetService, "assetStateManageBuilder", assetStateManageBuilder);
        Whitebox.setInternalState(deleteAssetStateManager, "assetRestrictionFeaturesEnabled", true);
        Mockito.doReturn(createAssetStateManager).when(assetStateManageBuilder).build(eq(HttpActionType.CREATE));
        Mockito.doReturn(updateAssetStateManager).when(assetStateManageBuilder).build(eq(HttpActionType.UPDATE));
        Mockito.doReturn(deleteAssetStateManager).when(assetStateManageBuilder).build(eq(HttpActionType.DELETE));
        Mockito.doReturn(false).when(createAssetStateManager).manageAsset(anyString(), any(), any());
        Mockito.doReturn(false).when(updateAssetStateManager).manageAsset(anyString(), any(), any());

        ReflectionUtils.setField(AssetService.class, assetService, "almPersistenceService", almPersistenceService);
        ReflectionUtils.setField(AssetService.class, assetService, "assetCacheManager", assetCacheManager);

        //ReflectionUtils.setField(AssetTagService.class, assetTagService, "tagRepository", tagRepository);
        ReflectionUtils.setField(AssetTypeService.class, assetTypeService, "typedAdapters", typedAdapters);
        ReflectionUtils.setField(AssetTypeService.class, assetTypeService, "almPersistenceService",
            almPersistenceService);

        assetService.afterPropertiesSet();
        assetTypeService.afterPropertiesSet();
    }

    private String[] getParentInternal(T dto) {
        if (dto instanceof Enterprise) {
            return new String[] { getTenantHeader() };
        } else if (dto.getParent() != null && !dto.getParent().trim().isEmpty()) {
            return new String[] { dto.getParent() };
        }
        return new String[0];
    }
}
