/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset;

import org.mockito.Mockito;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.ImportResource;

import com.ge.apm.alm.persistence.jpa.PersistenceConfig;
import com.ge.apm.asset.db.PersistenceConfigAsset;
import com.ge.apm.asset.filter.AccessibleResourcesFilter;
import com.ge.apm.asset.mq.config.AssetRouteBuilder;
import com.ge.apm.asset.mq.config.MqAuthConfig;
import com.ge.apm.asset.mq.processor.DtoProcessor;
import com.ge.apm.asset.mq.processor.TemplateConnectionProcessor;
import com.ge.apm.asset.service.api.IAlmPersistenceService;
import com.ge.stuf.context.StufContextFilter;
import com.ge.stuf.tenant.context.TenantContextFilter;

/**
 * Application context for test
 */
@Configuration
@EnableAutoConfiguration
@ComponentScan(
    value = { "com.ge.apm.common.filter", "com.ge.apm.asset", "com.ge.stuf", "com.ge.apm.alm", "com.ge.asset.commons",
        "org.apache.camel.spring.boot", "com.ge.apm.blob.client", "com.ge.apm.blob.factory", "com.ge.apm.blob.repository",
        "com.ge.apm.rest", "com.ge.apm.service", "com.ge.apm.datasource" },
    excludeFilters = { @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = StufContextFilter.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = TenantContextFilter.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = AccessibleResourcesFilter.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = AssetRouteBuilder.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = MqAuthConfig.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = DtoProcessor.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = TemplateConnectionProcessor.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = PersistenceConfigAsset.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = PersistenceConfig.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = Application.class) })
@ImportResource({ "classpath:security-config.xml" })
public class ApplicationTest {

    @Bean
    IAlmPersistenceService almPersistenceService() {
        return Mockito.mock(IAlmPersistenceService.class);
    }
}
