/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import com.ge.apm.asset.controller.PlaceholderController;
import com.ge.apm.asset.model.Placeholder;
import com.ge.apm.asset.model.PlaceholderAssetTypeAssociation;
import com.ge.apm.asset.model.PlaceholderTagTypeAssociation;
import com.ge.apm.asset.model.TagExpression;
import com.ge.apm.asset.model.Template;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.ValidationResult;
import com.ge.asset.commons.validator.Validator;
import com.ge.asset.commons.validator.apm.TagExpValidationMap;
import com.ge.asset.commons.validator.apm.TagExpressionValidation;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

/**
 * Created by 212432041 - Chand Bhaverisetti on 2/22/17.
 */
public class TemplateProcessorTest extends AbstractProcessorTest {

    @InjectMocks
    @Autowired
    TemplateProcessor templateProcessor;

    @Mock
    PlaceholderController placeholderController;

    @Mock
    Template templateDto;

    private ObjectMapper MAPPER = new ObjectMapper();

    @Before
    public void setup() {
        super.setup();
    }

    @Test
    public void processDto() throws IllegalAccessException {
        when(placeholderController.reservedAttributes()).thenReturn(null);
        String dummySrcKey = "mockSrcKey";
        String dummyPrefix = Prefixes.Assets;
        String dummyUri = dummyPrefix + "/DummyUuid";
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq(dummySrcKey), eq(dummyPrefix))).thenReturn(dummyUri);
        List<Placeholder> placeholders = getPlaceholders(dummySrcKey, dummyPrefix);
        try {

            doReturn(placeholders).when(templateDto).getPlaceholders();

            Exchange exchangeObj = getExchange();
            templateProcessor.processDto(templateDto, exchangeObj);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("processDto throws exception");
        }

        placeholders = templateDto.getPlaceholders();
        Assert.assertThat("placeholders is not null", placeholders, notNullValue());
        Assert.assertThat("placeholders is not empty", placeholders.size(), not(0));

        Assert.assertEquals(0, placeholders.get(0).getTagTypeAssociations().get(0).getTagExpressions().size());

        //TODO - Assert Reserved Attributes
    }

    @Test
    public void processDtoWithTagExpressionEnabled() throws IllegalAccessException {

        ReflectionUtils.setField(TemplateProcessor.class, templateProcessor, "tagExpressionFeatureEnabled", true);
        ReflectionUtils.setField(TemplateProcessor.class, templateProcessor, "maxRange", 5000);

        when(placeholderController.reservedAttributes()).thenReturn(null);
        String dummySrcKey = "mockSrcKey";
        String dummyPrefix = Prefixes.Assets;
        String dummyUri = dummyPrefix + "/DummyUuid";
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq(dummySrcKey), eq(dummyPrefix))).thenReturn(dummyUri);
        List<Placeholder> placeholders = getPlaceholders(dummySrcKey, dummyPrefix);

        doReturn(placeholders).when(templateDto).getPlaceholders();

        Exchange exchangeObj = getExchange();

        templateProcessor.processDto(templateDto, exchangeObj);
        Assert.assertEquals(1, placeholders.get(0).getTagTypeAssociations().get(0).getTagExpressions().size());
    }

    @Test
    public void processDtoWithInvalidTagExpression() throws IllegalAccessException {

        ReflectionUtils.setField(TemplateProcessor.class, templateProcessor, "tagExpressionFeatureEnabled", true);
        ReflectionUtils.setField(TemplateProcessor.class, templateProcessor, "maxRange", 5000);

        when(placeholderController.reservedAttributes()).thenReturn(null);
        String dummySrcKey = "mockSrcKey";
        String dummyPrefix = Prefixes.Assets;
        String dummyUri = dummyPrefix + "/DummyUuid";
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq(dummySrcKey), eq(dummyPrefix))).thenReturn(dummyUri);
        List<Placeholder> placeholders = getPlaceholders(dummySrcKey, dummyPrefix);
        placeholders.get(0).getTagTypeAssociations().get(0).getTagExpressions().get(0).setTimeSeriesLinkExpr(
            "{$ASSET.NAME}.{TAG_TYPE.NAME}");
        Exchange exchangeObj = getExchange();
        doReturn(placeholders).when(templateDto).getPlaceholders();
        Assert.assertNotNull(placeholders.get(0).getTagTypeAssociations());
        templateProcessor.processDto(templateDto, exchangeObj);
        Assert.assertNull(placeholders.get(0).getTagTypeAssociations());
        ValidationResult result = (ValidationResult) exchangeObj.getProperty("validationResult_TENANT_TASK");
        Assert.assertEquals(false, result.isValid());
    }

    @Test
    public void processDtoWithInvalidTagExpression_complex() throws IllegalAccessException {

        ReflectionUtils.setField(TemplateProcessor.class, templateProcessor, "tagExpressionFeatureEnabled", true);
        ReflectionUtils.setField(TemplateProcessor.class, templateProcessor, "maxRange", 5000);

        List<Placeholder> placeholders = getPlaceholders("/input/assetTemplates/placeholders_tagExpressions.json");

        Placeholder p1 = placeholders.get(0);
        Placeholder p2 = placeholders.get(1);

        PlaceholderTagTypeAssociation p1t1 = p1.getTagTypeAssociations().get(0);
        PlaceholderTagTypeAssociation p1t2 = p1.getTagTypeAssociations().get(1);
        PlaceholderTagTypeAssociation p2t1 = p2.getTagTypeAssociations().get(0);
        PlaceholderTagTypeAssociation p2t2 = p2.getTagTypeAssociations().get(1);
        PlaceholderTagTypeAssociation p2t3 = p2.getTagTypeAssociations().get(2);

        when(placeholderController.reservedAttributes()).thenReturn(null);
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq(p1t1.getEntityUri()))).thenReturn(p1t1.getEntityUri());
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq(p1t2.getEntityUri()))).thenReturn(p1t2.getEntityUri());
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq(p2t1.getEntityUri()))).thenReturn(p2t1.getEntityUri());
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq(p2t2.getEntityUri()))).thenReturn(p2t2.getEntityUri());
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq(p2t3.getEntityUri()))).thenReturn(p2t3.getEntityUri());

        Exchange exchangeObj = getExchange();
        doReturn(placeholders).when(templateDto).getPlaceholders();
        templateProcessor.processDto(templateDto, exchangeObj);
        ValidationResult result = (ValidationResult) exchangeObj.getProperty("validationResult_TENANT_TASK");
        Assert.assertEquals(false, result.isValid());
        Assert.assertEquals(6, result.getErrors().size());
        TagExpValidationMap tagExpValidationMap = (TagExpValidationMap) ((Map<String, Object>) result
            .getResponseContext().get(Validator.TEMPLATE_PLACEHOLDERS_KEY)).get(
            TagExpressionValidation.VALID_TAG_EXPRESSIONS_MAP);

        Assert.assertEquals(2, tagExpValidationMap.get(p1.getPlaceholderId(), p1t1.getEntityUri()).size());
        Assert.assertEquals(2, tagExpValidationMap.get(p1.getPlaceholderId(), p1t2.getEntityUri()).size());

        Assert.assertEquals(0, tagExpValidationMap.get(p2.getPlaceholderId(), p2t1.getEntityUri()).size());
        Assert.assertEquals(0, tagExpValidationMap.get(p2.getPlaceholderId(), p2t2.getEntityUri()).size());
        Assert.assertEquals(0, tagExpValidationMap.get(p2.getPlaceholderId(), p2t3.getEntityUri()).size());

        Assert.assertEquals(2, p1.getTagTypeAssociations().get(0).getTagExpressions().size());
        Assert.assertEquals(2, p1.getTagTypeAssociations().get(1).getTagExpressions().size());
        Assert.assertNull(p2.getTagTypeAssociations());
    }

    @Test
    public void processDtoWithInvalidTagExpression_featureDisabled() throws IllegalAccessException {

        ReflectionUtils.setField(TemplateProcessor.class, templateProcessor, "tagExpressionFeatureEnabled", false);
        ReflectionUtils.setField(TemplateProcessor.class, templateProcessor, "maxRange", 5000);

        when(placeholderController.reservedAttributes()).thenReturn(null);
        String dummySrcKey = "mockSrcKey";
        String dummyPrefix = Prefixes.Assets;
        String dummyUri = dummyPrefix + "/DummyUuid";
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq(dummySrcKey), eq(dummyPrefix))).thenReturn(dummyUri);
        List<Placeholder> placeholders = getPlaceholders(dummySrcKey, dummyPrefix);
        placeholders.get(0).getTagTypeAssociations().get(0).getTagExpressions().get(0).setTimeSeriesLinkExpr(
            "{$ASSET.NAME}.{TAG_TYPE.NAME}");
        Exchange exchangeObj = getExchange();
        doReturn(placeholders).when(templateDto).getPlaceholders();
        templateProcessor.processDto(templateDto, exchangeObj);
        Assert.assertTrue(CollectionUtils.isEmpty(placeholders.get(0).getTagTypeAssociations().get(0)
            .getTagExpressions()));
        ValidationResult result = (ValidationResult) exchangeObj.getProperty("validationResult_TENANT_TASK");
        Assert.assertNull(result);
    }

    private List<Placeholder> getPlaceholders(String dummySrcKey, String dummyPrefix) {
        List<Placeholder> placeholders = new ArrayList<>();
        Placeholder placeholder = new Placeholder();

        placeholder.setPlaceholderId("PPN01");

        List<PlaceholderAssetTypeAssociation> associations = new ArrayList<>();
        PlaceholderAssetTypeAssociation placeholderAssociation = new PlaceholderAssetTypeAssociation();
        placeholderAssociation.setEntityUri(dummyPrefix + "/" + dummySrcKey);
        associations.add(placeholderAssociation);
        placeholder.setAssetTypeAssociations(associations);

        List<PlaceholderTagTypeAssociation> tagAssociations = new ArrayList<>();
        PlaceholderTagTypeAssociation tagAssociation = new PlaceholderTagTypeAssociation();
        tagAssociation.setEntityUri("/tagTypes/" + dummySrcKey);

        TagExpression expression = new TagExpression();
        expression.setIdExpr("{ASSET.ID}.{TAG_TYPE.ID}.{range}");
        expression.setNameExpr("{ASSET.NAME}.{TAG_TYPE.NAME}");
        expression.setTimeSeriesLinkExpr("{ASSET.ID}.{TAG_TYPE.ID}");
        expression.setRange("[1 - 4]");
        List<TagExpression> expressions = new ArrayList<>();
        expressions.add(expression);
        tagAssociation.setTagExpressions(expressions);

        tagAssociations.add(tagAssociation);

        placeholder.setTagTypeAssociations(tagAssociations);

        placeholders.add(placeholder);
        return placeholders;
    }

    private Exchange getExchange() {
        CamelContext ctx = new DefaultCamelContext();
        Exchange exchangeObj = new DefaultExchange(ctx);
        //exchangeObj.getIn().setBody(templateConnections.stream().toArray(TemplateConnection[]::new));
        headerMap.put(MessageConstants.TENANT_UUID, tenantId);
        headerMap.put(MessageConstants.AUTHORIZATION, authToken);
        headerMap.put(MessageConstants.TASK_UUID, "TASK");
        headerMap.put(MessageConstants.TASK_ENTITY_TOTAL, 1);
        exchangeObj.getIn().setHeaders(headerMap);
        return exchangeObj;
    }

    private List<Placeholder> getPlaceholders(String filename) {
        List<Placeholder> list = new ArrayList<>();
        try {
            Placeholder[] placeholders = MAPPER.reader(Array.newInstance(Placeholder.class, 0).getClass()).readValue(
                this.getClass().getResourceAsStream(filename));
            list.addAll(Arrays.stream(placeholders).collect(Collectors.toList()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Assert.assertFalse(list.isEmpty());
        return list;
    }
}
