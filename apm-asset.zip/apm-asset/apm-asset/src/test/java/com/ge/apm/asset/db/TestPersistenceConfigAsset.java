/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.db;

import java.util.Collections;
import java.util.Properties;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.SharedCacheMode;
import javax.sql.DataSource;

import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.eclipse.persistence.config.SessionCustomizer;
import org.eclipse.persistence.sessions.Session;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.jpa.support.ClasspathScanningPersistenceUnitPostProcessor;
import org.springframework.data.jpa.support.MergingPersistenceUnitManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.persistenceunit.PersistenceUnitManager;
import org.springframework.orm.jpa.vendor.EclipseLinkJpaVendorAdapter;

@Configuration
@PropertySource("classpath:application-test.properties")
//@EnableJpaRepositories({ "com.ge.apm.asset.tag", "com.ge.apm.alm" })
@EnableJpaRepositories({ "com.ge.apm.alm" })
public class TestPersistenceConfigAsset implements SessionCustomizer {

    @Value("${spring.datasource.driver-class-name}")
    private String dataSourceDriverClassName;

    @Value("${spring.datasource.url}")
    private String dataSourceUrl;

    @Value("${spring.datasource.username}")
    private String dataSourceUsername;

    @Value("${spring.datasource.password}")
    private String dataSourcePassword;

    @Value("${spring.datasource.maxWait}")
    private Integer dataSourceMaxWait;

    /*This bean is to create the JPA Vendor*/
    @Bean
    public JpaVendorAdapter jpaVendorAdapter() {
        EclipseLinkJpaVendorAdapter jpaVendorAdapter = new EclipseLinkJpaVendorAdapter();
        jpaVendorAdapter.setShowSql(true);
        return jpaVendorAdapter;
    }

    /*
    * This bean is to merge the various persistence unit.
    * setSharedCacheMode should be set if any of the persistence unit uses it. Otherwise it will use default and
    * you might run into issues. MergingPersistenceUnitManager only merges the entity classes but not the settings.
    * */
    @Bean
    public PersistenceUnitManager persistenceUnitManager(DataSource dataSource) {
        MergingPersistenceUnitManager persistenceUnitManager = new MergingPersistenceUnitManager();
        persistenceUnitManager.setDefaultDataSource(dataSource);
        persistenceUnitManager.setDefaultPersistenceUnitName("compositePU");
        persistenceUnitManager.setSharedCacheMode(SharedCacheMode.ENABLE_SELECTIVE);
        //persistenceUnitManager.setPackagesToScan("com.ge.apm.asset.tag.persistence", "com.ge.apm.alm.persistence");
        persistenceUnitManager.setPackagesToScan("com.ge.apm.alm.persistence");
        return persistenceUnitManager;
    }

    /*
     * The container app should take responsibility of configuring the flyway beans individually per persistence
     * jar consumption so that we maintain the schemas intact. Make sure each persistence jar has it's flyway
     * locations uniquely defined.
     */
    @Bean(initMethod = "migrate")
    Flyway flyway1(DataSource dataSource) {
        Flyway flyway1 = new Flyway();
        flyway1.setBaselineOnMigrate(false);
        //flyway1.setSchemas("APM_ASSET");
        flyway1.setSchemas("apm_alm");
        flyway1.setPlaceholders(Collections.singletonMap("json-data-type", "text"));
        flyway1.setLocations("classpath:db/asset/migration");
        flyway1.setDataSource(dataSource);
        return flyway1;
    }

    // @Bean(initMethod = "migrate")
    // Flyway flyway2(DataSource dataSource) {
    //     Flyway flyway2 = new Flyway();
    //     flyway2.setBaselineOnMigrate(false);
    //     flyway2.setSchemas("apm_alm");
    //     flyway2.setPlaceholders(Collections.singletonMap("json-data-type", "json"));
    //     flyway2.setDataSource(dataSource);
    //     return flyway2;
    // }

    /*
     * This bean creates the entityManagerFactory. The ClasspathScanningPersistenceUnitPostProcessor
     * is used to scan the entity classes and the corresponding mapping files used per persistence unit.
     *
     */
    @Bean
    @DependsOn({ "flyway1" })
    public FactoryBean<EntityManagerFactory> entityManagerFactory(PersistenceUnitManager persistenceUnitManager,
        JpaVendorAdapter jpaVendorAdapter) {

        ClasspathScanningPersistenceUnitPostProcessor persistenceUnitPostProcessor
            = new ClasspathScanningPersistenceUnitPostProcessor("com.ge.apm");
        persistenceUnitPostProcessor.setMappingFileNamePattern("*.xml");
        LocalContainerEntityManagerFactoryBean emfFactoryBean = new LocalContainerEntityManagerFactoryBean();
        emfFactoryBean.setJpaVendorAdapter(jpaVendorAdapter);
        emfFactoryBean.setPersistenceUnitManager(persistenceUnitManager);
        emfFactoryBean.setPersistenceUnitPostProcessors(persistenceUnitPostProcessor);
        Properties jpaProperties = new Properties();
        jpaProperties.setProperty(PersistenceUnitProperties.WEAVING, "static");
        jpaProperties.setProperty(PersistenceUnitProperties.COMPOSITE_UNIT, "true");
        jpaProperties.setProperty(PersistenceUnitProperties.SESSION_CUSTOMIZER, this.getClass().getName());
        jpaProperties.setProperty(PersistenceUnitProperties.EXCLUDE_ECLIPSELINK_ORM_FILE, "META-INF/orm.xml");
        emfFactoryBean.setJpaProperties(jpaProperties);
        return emfFactoryBean;
    }

    @Bean
    EntityManager entityManager(EntityManagerFactory emf) {
        return emf.createEntityManager();
    }

    @Bean
    JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }

    @Override
    public void customize(Session session) throws Exception {
        session.getLogin().setTableQualifier("apm_asset");
    }

    @Bean(destroyMethod = "close")
    public DataSource dataSource() {
        org.apache.tomcat.jdbc.pool.DataSource dataSource = new org.apache.tomcat.jdbc.pool.DataSource();
        dataSource.setDriverClassName(dataSourceDriverClassName);
        dataSource.setUrl(dataSourceUrl);
        dataSource.setUsername(dataSourceUsername);
        dataSource.setPassword(dataSourcePassword);
        dataSource.setMaxWait(dataSourceMaxWait);
        return dataSource;
    }
}