/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;

import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.model.Attribute;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.TemplateInfo;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAlmPersistenceService;
import com.ge.apm.asset.service.api.IAssetConfigService;
import com.ge.apm.asset.service.component.AssetConfigService;
import com.ge.apm.asset.service.persistence.AlmPersistenceService;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.json.patch.PatchOperation;

import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;

public class BaseAssetServiceTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @InjectMocks
    private BaseAssetService baseAssetService;

    @Mock
    private IAssetConfigService assetConfigService;

    @Mock
    private IAlmPersistenceService almPersistenceService;

    private String prefix;

    private String uri;

    private String tenantId;

    @Before
    public void setUp() throws IllegalAccessException {
        assetConfigService = PowerMockito.spy(new AssetConfigService());
        almPersistenceService = Mockito.spy(new AlmPersistenceService());
        baseAssetService = new AssetService();
        MockitoAnnotations.initMocks(this);
        ReflectionUtils.setField(BaseAssetService.class, baseAssetService, "assetConfigService", assetConfigService);
        ReflectionUtils.setField(BaseAssetService.class, baseAssetService, "almPersistenceService",
            almPersistenceService);

        prefix = "/assets";
        uri = prefix + "/bb571726-c1a3-4610-99de-435ab7f74000";
        tenantId = "bb571726-c1a3-4610-99de-435ab7f74000";

        List<String> list = new ArrayList<>();
        list.add(Prefixes.Assets);
        list.add(Prefixes.AssetTypes);
        list.add(Prefixes.MeasurementTags);
        list.add(Prefixes.MeasurementTagTypes);
        Mockito.when(assetConfigService.getReservedAttributesApplicableResources()).thenReturn(list);
    }

    @Test
    public void testValidateObjectsForAdd_valid() throws IOException {
        testValidateObjectsForAdd("valid.json");
    }

    @Test
    public void testValidateObjectsForAdd_validEmptyAttributeValue() throws IOException {
        testValidateObjectsForAdd("validEmptyAttributeValue.json");
    }

    @Test
    public void testValidateObjectsForAdd_validMultipleAttributeValues() throws IOException {
        testValidateObjectsForAdd("validMultipleAttributeValues.json");
    }

    @Test
    public void testValidateObjectsForAdd_validWithoutAttributes() throws IOException {
        testValidateObjectsForAdd("validWithoutAttributes.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForAdd_invalidAttribute() throws IOException {
        testValidateObjectsForAdd("invalidAttribute.json");
    }

    @Test
    public void testValidateObjectsForAdd_invalidName() throws IOException {
        testValidateObjectsForAdd("invalidName.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForAdd_unsupportedDataType() throws IOException {
        testValidateObjectsForAdd("unsupportedDataType.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForAdd_nullAttributeType() throws IOException {
        testValidateObjectsForAdd("nullAttributeType.json");
    }

    @Test
    public void testValidateObjectsForAdd_nullAttributeValue() throws IOException {
        testValidateObjectsForAdd("nullAttributeValue.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForAdd_multipleValuesSomeInvalid() throws IOException {
        testValidateObjectsForAdd("multipleValuesSomeInvalid.json");
    }

    @Test
    public void testValidateObjectsForUpdate_valid() throws IOException {
        testValidateObjectsForUpdate("valid.json");
    }

    @Test
    public void testValidateObjectsForUpdate_valid_AttributeObject() throws IOException {
        testValidateObjectsForUpdateWithAttributeObject("valid.json");
    }

    @Test
    public void testValidateObjectsForUpdate_validPatchAllAttributesAtOnce() throws IOException {
        testValidateObjectsForUpdate("validPatchAllAttributesAtOnce.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForUpdate_invalidAttribute() throws IOException {
        testValidateObjectsForUpdate("invalidAttribute.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForUpdate_sourceKey() throws IOException {
        testValidateObjectsForUpdate("immutablePath.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForUpdate_unsupportedDataType() throws IOException {
        testValidateObjectsForUpdate("unsupportedDataType.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForUpdate_missingAttributeType() throws IOException {
        testValidateObjectsForUpdate("missingAttributeType.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForUpdate_invalidName() throws IOException {
        testValidateObjectsForUpdate("invalidName.json");
    }

    @Test
    public void testValidateObjectsForUpdate_missingAttributeValue() throws IOException {
        testValidateObjectsForUpdate("missingAttributeValue.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForUpdate_multipleValuesSomeInvalid() throws IOException {
        testValidateObjectsForUpdate("multipleValuesSomeInvalid.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForUpdate_duplicatePaths() throws IOException {
        testValidateObjectsForUpdate("duplicatePaths.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForUpdate_invalidAttributePatch() throws IOException {
        testValidateObjectsForUpdate("invalidAttributePatch.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForUpdate_name_delete() throws IOException {
        testValidateObjectsForUpdate("invalidPatchOperation_delete_name.json");
    }

    @Test(expected = BadRequestException.class)
    public void testValidateObjectsForUpdate_uri_add_replace_delete() throws IOException {
        testValidateObjectsForUpdate("invalidPatchOperation_uri_in_path.json");
    }

    @Test
    public void testValidateReservedAttributesForUpdate_DoesNotAllowSetReservedAttributesToNull() throws IOException {
        PatchOperation[] patchOperations = new PatchOperation[1];
        patchOperations[0] = new PatchOperation("replace", "/reservedAttributes", (Object) null);

        baseAssetService.validateReservedAttributesForUpdate("tenantId", uri, getMockAsset(), patchOperations);

        PatchOperation expectedPatchOperation = new PatchOperation("add", "/reservedAttributes", new HashMap<>());
        Assert.assertEquals(expectedPatchOperation, patchOperations[0]);
    }

    @Test
    public void testValidateReservedAttributesForUpdate_DoesNotAllowRemoveReservedAttributes() throws IOException {
        PatchOperation[] patchOperations = new PatchOperation[1];
        patchOperations[0] = new PatchOperation("remove", "/reservedAttributes", (Object) null);

        baseAssetService.validateReservedAttributesForUpdate("tenantId", uri, getMockAsset(), patchOperations);

        PatchOperation expectedPatchOperation = new PatchOperation("add", "/reservedAttributes", new HashMap<>());
        Assert.assertEquals(expectedPatchOperation, patchOperations[0]);
    }

    @Test
    public void testRemoveUnnecessaryPatchOperations_NothingToRemove() throws IOException {
        Asset existingObject = getMockAsset();
        PatchOperation[] patchOperations = getPatchOperations(
            "testRemoveUnnecessaryPatchOperations_NothingToRemove.json");
        PatchOperation[] filteredPatchOperations = baseAssetService.removeUnnecessaryPatchOperations(existingObject,
            patchOperations);
        Assert.assertArrayEquals(patchOperations, filteredPatchOperations);
    }

    @Test
    public void testRemoveUnnecessaryPatchOperations_RemoveAll() throws IOException {
        Asset existingObject = getMockAsset();
        PatchOperation[] patchOperations = getPatchOperations("testRemoveUnnecessaryPatchOperations_RemoveAll.json");
        PatchOperation[] filteredPatchOperations = baseAssetService.removeUnnecessaryPatchOperations(existingObject,
            patchOperations);
        Assert.assertEquals(patchOperations.length, 2);
        Assert.assertEquals(filteredPatchOperations.length, 0);
    }

    @Test
    public void testRemoveUnnecessaryPatchOperations_RemoveSome() throws IOException {
        Asset existingObject = getMockAsset();
        PatchOperation[] patchOperations = getPatchOperations("testRemoveUnnecessaryPatchOperations_RemoveSome.json");
        PatchOperation[] filteredPatchOperations = baseAssetService.removeUnnecessaryPatchOperations(existingObject,
            patchOperations);
        Assert.assertEquals(patchOperations.length, 2);
        Assert.assertEquals(filteredPatchOperations.length, 1);
    }

    @Test
    public void testRemoveUnnecessaryPatchOperations_RemoveFields() throws IOException {
        Asset existingObject = getMockAsset();
        PatchOperation[] patchOperations = getPatchOperations("testRemoveUnnecessaryPatchOperations_RemoveFields.json");
        PatchOperation[] filteredPatchOperations = baseAssetService.removeUnnecessaryPatchOperations(existingObject,
            patchOperations);
        Assert.assertEquals(patchOperations.length, 3);
        Assert.assertEquals(filteredPatchOperations.length, 1);
    }

    @Test
    public void testRemoveUnnecessaryPatchOperations_UpdateAttributes() throws IOException {
        Asset existingObject = getMockAsset();
        PatchOperation[] patchOperations = getPatchOperations(
            "testRemoveUnnecessaryPatchOperations_UpdateAttributes.json");
        PatchOperation[] filteredPatchOperations = baseAssetService.removeUnnecessaryPatchOperations(existingObject,
            patchOperations);
        Assert.assertEquals(patchOperations.length, 1);
        Assert.assertEquals(filteredPatchOperations.length, 1);
    }

    @Test(expected = ServiceException.class)
    public void testValidateLocationForUpdate_Parent() throws IOException {
        testValidateObjectsForUpdate("invalidLocation.json");
    }

    @Test(expected = ServiceException.class)
    public void testValidateLocationForUpdate_Child() throws IOException {
        testValidateObjectsForUpdate("invalidLocationChild.json");
    }

    @Test(expected = ServiceException.class)
    public void testValidateLocationForUpdate_Multiple() throws IOException {
        testValidateObjectsForUpdate("invalidLocationMultiple.json");
    }

    @Test
    public void testValidateLocationForUpdate_Valid() throws IOException {
        testValidateObjectsForUpdate("validLocation.json");
    }

    @Test
    public void testReplaceParentWithWhiteSpaceString() {
        PatchOperation po = new PatchOperation("replace", "/parent", (Object) "   ");
        Asset asset = new Asset();
        asset.setSourceKey("apple");
        Mockito.doReturn(asset).when(almPersistenceService).getInstanceByUri(anyString(), anyString(), eq(false));
        baseAssetService.validateAgainstEquipmentInstance("anyTenant", "/assets/xyz", Prefixes.Assets, po);
    }

    @Test
    public void testReplaceParentWithNullValue() {
        PatchOperation po = new PatchOperation("replace", "/parent", (Object) null);
        Asset asset = new Asset();
        asset.setSourceKey("apple");
        Mockito.doReturn(asset).when(almPersistenceService).getInstanceByUri(anyString(), anyString(), eq(false));
        baseAssetService.validateAgainstEquipmentInstance("anyTenant", "/assets/xyz", Prefixes.Assets, po);
    }

    @Test
    public void testReplaceParentWithEmptyString() {
        PatchOperation po = new PatchOperation("replace", "/parent", (Object) "");
        Asset asset = new Asset();
        asset.setSourceKey("apple");
        Mockito.doReturn(asset).when(almPersistenceService).getInstanceByUri(anyString(), anyString(), eq(false));
        baseAssetService.validateAgainstEquipmentInstance("anyTenant", "/assets/xyz", Prefixes.Assets, po);
    }

    @Test(expected = BadRequestException.class)
    public void testValidateAgainstEquipmentInstance_ET1069_forUpdate() {
        PatchOperation po = new PatchOperation("add", "/templateInfo/templateUri",
            (Object) ("/assetTemplates/abc").getClass());
        Asset asset = new Asset();
        asset.setSourceKey("apple");
        Mockito.doReturn(asset).when(almPersistenceService).getInstanceByUri(anyString(), anyString(), eq(false));
        try {
            baseAssetService.validateAgainstEquipmentInstance("anyTenant", "/assets/xyz", Prefixes.Assets, po);
        } catch (BadRequestException bre) {
            Assert.assertTrue(bre.getCode().equals("ET1069"));
            throw bre;
        }
    }

    @Test(expected = BadRequestException.class)
    public void testValidateAgainstEquipmentInstance_ET1070_forUpdate() {
        PatchOperation po = new PatchOperation("add", "/parent", (Object) ("/assets/abc"));
        Asset asset = new Asset();
        asset.setUri("/assets/xyz");
        asset.setSourceKey("apple");
        Mockito.doReturn(asset).when(almPersistenceService).getInstanceByUri(anyString(), eq("/assets/xyz"), eq(false));

        Asset requestedParent = new Asset();
        requestedParent.setUri("/assets/abc");
        requestedParent.setSourceKey("pear");
        TemplateInfo templateInfo = new TemplateInfo();
        templateInfo.setTemplateUri("/templateInfo/templateUri");
        requestedParent.setTemplateInfo(templateInfo);
        Mockito.doReturn(requestedParent).when(almPersistenceService).getInstanceByUri(anyString(), eq("/assets/abc"),
            eq(false));
        try {
            baseAssetService.validateAgainstEquipmentInstance("anyTenant", "/assets/xyz", Prefixes.Assets, po);
        } catch (BadRequestException bre) {
            Assert.assertTrue(bre.getCode().equals("ET1070"));
            throw bre;
        }
    }

    @Test
    public void testValidateAgainstEquipmentInstance_ET1070_forUpdate_Asset_To_Segment() {
        PatchOperation po = new PatchOperation("add", "/parent", (Object) ("/segments/abc"));
        Asset asset = new Asset();
        asset.setUri("/assets/xyz");
        asset.setSourceKey("apple");
        Segment currentParent = new Segment();
        currentParent.setUri("/segments/efg");
        currentParent.setSourceKey("banana");
        asset.setParent(currentParent.getUri());
        Mockito.doReturn(asset).when(almPersistenceService).getInstanceByUri(anyString(), eq("/assets/xyz"), eq(false));
        Mockito.doReturn(currentParent).when(almPersistenceService).getInstanceByUri(anyString(), eq("/segments/efg"),
            eq(false));

        Segment requestedParent = new Segment();
        requestedParent.setUri("/segments/abc");
        requestedParent.setSourceKey("pear");
        Mockito.doReturn(requestedParent).when(almPersistenceService).getInstanceByUri(anyString(), eq("/segments/abc"),
            eq(false));
        baseAssetService.validateAgainstEquipmentInstance("anyTenant", "/assets/xyz", Prefixes.Assets, po);
    }

    @Test(expected = BadRequestException.class)
    public void testValidateAgainstEquipmentInstance_ET1071_forUpdate() {
        PatchOperation po = new PatchOperation("add", "/parent", (Object) ("/assets/abc").getClass());
        Asset asset = new Asset();
        asset.setSourceKey("apple");
        TemplateInfo templateInfo = new TemplateInfo();
        templateInfo.setTemplateUri("/templateInfo/templateUri");
        asset.setTemplateInfo(templateInfo);
        Mockito.doReturn(asset).when(almPersistenceService).getInstanceByUri(anyString(), anyString(), eq(false));
        try {
            baseAssetService.validateAgainstEquipmentInstance("anyTenant", "/assets/xyz", Prefixes.Assets, po);
        } catch (BadRequestException bre) {
            Assert.assertTrue(bre.getCode().equals("ET1071"));
            throw bre;
        }
    }

    @Test(expected = BadRequestException.class)
    public void testValidateAgainstEquipmentInstance_ET1069_forCreation() {
        Asset asset = new Asset();
        asset.setSourceKey("apple");
        TemplateInfo templateInfo = new TemplateInfo();
        templateInfo.setTemplateUri("/templateInfo/templateUri");
        asset.setTemplateInfo(templateInfo);
        try {
            baseAssetService.validateAgainstEquipmentInstance(Prefixes.Assets, asset);
        } catch (BadRequestException bre) {
            Assert.assertTrue(bre.getCode().equals("ET1069"));
            throw bre;
        }
    }

    @Test(expected = BadRequestException.class)
    public void testValidateAgainstEquipmentInstance_ET1070_forCreation() {
        Asset asset = new Asset();
        asset.setSourceKey("apple");
        asset.setParent("/assets/xyz");
        Asset parentAsset = new Asset();
        parentAsset.setUri("/assets/xyz");
        TemplateInfo templateInfo = new TemplateInfo();
        templateInfo.setTemplateUri("/templateInfo/templateUri");
        parentAsset.setTemplateInfo(templateInfo);
        Mockito.doReturn(parentAsset).when(almPersistenceService).getInstanceByUri(anyString(), anyString(), eq(false));
        try {
            baseAssetService.validateAgainstEquipmentInstance(Prefixes.Assets, asset);
        } catch (BadRequestException bre) {
            Assert.assertTrue(bre.getCode().equals("ET1070"));
            throw bre;
        }
    }

    private void testValidateObjectsForAdd(String fileName) throws IOException {
        Attributable[] objects = (Attributable[]) MAPPER.reader(Asset[].class).readValue(
            this.getClass().getResourceAsStream(getFilePath("add", fileName)));
        baseAssetService.validateObjectsForAdd("tenantId", prefix, objects, Attributable.class);
    }

    private void testValidateObjectsForUpdate(String fileName) throws IOException {
        PatchOperation[] patchOperations = getPatchOperations(fileName);
        baseAssetService.validateObjectsForUpdate(tenantId, uri, getMockAsset(), patchOperations, Asset.class);
    }

    @SuppressWarnings("unchecked")
    private void testValidateObjectsForUpdateWithAttributeObject(String fileName) throws IOException {
        PatchOperation[] patchOperations = getPatchOperations(fileName);
        PatchOperation patchOperation = patchOperations[0];
        LinkedHashMap<String, Object> attributeFields = (LinkedHashMap<String, Object>) patchOperation.getValue();
        Attribute attribute = new Attribute();
        attribute.setType((String) attributeFields.get("type"));
        attribute.setValue((List<Object>) attributeFields.get("value"));
        PatchOperation newPatchOperation = new PatchOperation(patchOperations[0].getOp(), patchOperations[0].getPath(),
            attribute);
        patchOperations[0] = newPatchOperation;
        baseAssetService.validateObjectsForUpdate(tenantId, uri, getMockAsset(), patchOperations, Asset.class);
    }

    private PatchOperation[] getPatchOperations(String fileName) throws IOException {
        PatchOperation[] patchOperations = MAPPER.reader(PatchOperation[].class).readValue(
            this.getClass().getResourceAsStream(getFilePath("update", fileName)));
        return patchOperations;
    }

    private Asset getMockAsset() throws IOException {
        return MAPPER.reader(Asset.class).readValue(
            this.getClass().getResourceAsStream("/predix/baseAssetService/asset.json"));
    }

    private String getFilePath(String method, String fileName) {
        return String.format("/input/baseAssetService/%s/%s", method, fileName);
    }
}
