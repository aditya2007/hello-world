/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.asset.controller.AssetGroupAssociationController;
import com.ge.apm.asset.model.InstanceGroupMap;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

public class InstanceGroupMapProcessorTest extends AbstractProcessorTest {

    @InjectMocks
    @Autowired
    InstanceGroupMapProcessor instanceGroupMapProcessor;

    @InjectMocks
    @Autowired
    AssetGroupAssociationController assetGroupAssociationController;

    @Before
    public void setup() {
        super.setup();
    }

    @Test
    public void processDto() {
        InstanceGroupMap instanceGroupMapDto = new InstanceGroupMap();
        instanceGroupMapDto.setInstanceSourceKey("GroupSourceKey");
        instanceGroupMapDto.setInstanceSourceKey("MockSiteSourceKey");
        instanceGroupMapDto.setInstancePrefix("/sites");
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq(Prefixes.Groups), eq("GroupSourceKey"))).thenReturn(
            Prefixes.Groups + "/mockUri");

        instanceGroupMapProcessor.processDto(instanceGroupMapDto, exchange);
    }

    @Test(expected = DependencyViolationException.class)
    public void processGroupSrcKeyNotFound() {
        InstanceGroupMap instanceGroupMapDto = new InstanceGroupMap();
        instanceGroupMapDto.setGroupSourceKey("GroupSourceKey");
        instanceGroupMapDto.setInstanceSourceKey("MockSiteSourceKey");
        instanceGroupMapDto.setInstancePrefix("/sites");
        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq(Prefixes.Groups), eq("GroupSourceKey"))).thenThrow(
            DependencyViolationException.class);
        instanceGroupMapProcessor.processDto(instanceGroupMapDto, exchange);
    }

    @Test(expected = DependencyViolationException.class)
    public void processGroupInstanceSourceKeyNotFound() throws Exception {
        assetGroupAssociationController = Mockito.mock(AssetGroupAssociationController.class);
        ReflectionUtils.setField(InstanceGroupMapProcessor.class, instanceGroupMapProcessor,
            "assetGroupAssociationController", assetGroupAssociationController);
        InstanceGroupMap instanceGroupMapDto = new InstanceGroupMap();
        instanceGroupMapDto.setGroupUri(Prefixes.Groups + "/mockUri");
        instanceGroupMapDto.setInstanceSourceKey("MockSiteSourceKey");
        instanceGroupMapDto.setInstancePrefix("/sites");
        BadRequestException badRequestException = new BadRequestException(
            ErrorProvider.findError(ErrorConstants.SOURCE_KEYS_MISMATCH), "/sites");
        Map<String, Object> associationsMap = new HashMap<>();
        associationsMap.put("assetGroupUri", Prefixes.Groups + "/mockUri");
        Map<String, Object> assetMap = new HashMap<>();
        List<Object> assetSrcKeyMapList = new ArrayList<>();
        Map<String, Object> assetSrcKeyMap = new HashMap<>();
        assetSrcKeyMapList.add(assetSrcKeyMap);
        assetSrcKeyMap.put("type", "/sites");
        List srcKeys = new ArrayList<>();
        srcKeys.add("MockSiteSourceKey");
        assetSrcKeyMap.put("sourceKeys", srcKeys);
        assetMap.put("sourceKeys", assetSrcKeyMapList);
        associationsMap.put("assets", assetMap);
        doThrow(badRequestException).when(assetGroupAssociationController).associateGroupToAssets(eq(associationsMap),
            eq(Prefixes.Groups + "/mockUri"));
        List<InstanceGroupMap> dtos = new ArrayList<>();
        dtos.add(instanceGroupMapDto);
        instanceGroupMapProcessor.saveDto(Prefixes.AssetGroupAssociations, dtos);
    }
}
