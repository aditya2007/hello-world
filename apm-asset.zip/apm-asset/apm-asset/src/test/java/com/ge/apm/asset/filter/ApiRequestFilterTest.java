/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.filter;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.support.RequestContext;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;

public class ApiRequestFilterTest {

    @InjectMocks
    @Autowired
    ApiRequestFilter apiRequestFilter;

    private HttpServletRequest request;
    private HttpServletResponse response;
    private FilterChain filterChain;
    private PrintWriter printWriter;
    private RequestContext requestContext;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        request = mock(HttpServletRequest.class);
        response = mock(HttpServletResponse.class);
        filterChain = mock(FilterChain.class);
        printWriter = mock(PrintWriter.class);
    }

    @Test
    public void doFilter() throws Exception {
        ReflectionUtils.setField(ApiRequestFilter.class, apiRequestFilter, "disabledEndpoints",
            Arrays.asList("assets", "assetRestrictionFeatures"));
        when(request.getServletPath()).thenReturn("/v1/allowedPath");
        apiRequestFilter.doFilter(request, response, filterChain);
        Mockito.verify(filterChain, atLeastOnce()).doFilter(request, response);
    }

    @Test
    public void doFilter_Empty() throws Exception {
        ReflectionUtils.setField(ApiRequestFilter.class, apiRequestFilter, "disabledEndpoints",
            new ArrayList());
        when(request.getServletPath()).thenReturn("/v1/allowedPath");
        apiRequestFilter.doFilter(request, response, filterChain);
        Mockito.verify(filterChain, atLeastOnce()).doFilter(request, response);
    }

    @Test
    public void doFilter_EmptyString() throws Exception {
        ReflectionUtils.setField(ApiRequestFilter.class, apiRequestFilter, "disabledEndpoints",
            Arrays.asList(""));
        when(request.getServletPath()).thenReturn("/v1/allowedPath");
        apiRequestFilter.doFilter(request, response, filterChain);
        Mockito.verify(filterChain, atLeastOnce()).doFilter(request, response);
    }

    @Test
    public void doFilter_Forbidden() throws Exception {
        ReflectionUtils.setField(ApiRequestFilter.class, apiRequestFilter, "disabledEndpoints",
            Arrays.asList("/v1/assets", "/v1/assetRestrictionFeatures"));
        when(request.getServletPath()).thenReturn("/v1/assetRestrictionFeatures");
        when(response.getWriter()).thenReturn(printWriter);
        apiRequestFilter.doFilter(request, response, filterChain);
        Mockito.verify(filterChain, never()).doFilter(request, response);
    }

    @Test
    public void doFilter_V3_Forbidden() throws Exception {
        ReflectionUtils.setField(ApiRequestFilter.class, apiRequestFilter, "disabledEndpoints",
            Arrays.asList("/v3"));
        when(request.getServletPath()).thenReturn("/v3/assets");
        when(response.getWriter()).thenReturn(printWriter);
        apiRequestFilter.doFilter(request, response, filterChain);
        Mockito.verify(filterChain, never()).doFilter(request, response);
    }

    @Test
    public void doFilter_crossTenancyInPathParam_valid() throws Exception {
        String tenantUuid = "20988021-dd02-4aae-9b5d-8b5ce111cf5";
        ReflectionUtils.setField(ApiRequestFilter.class, apiRequestFilter, "disabledEndpoints",
            Arrays.asList("assets", "assetRestrictionFeatures"));
        when(request.getServletPath()).thenReturn("/v3/tenants/" + tenantUuid + "/enterpriseTypes");
        when(request.getMethod()).thenReturn("POST");
        RequestContext.put(RequestContext.TENANT_UUID, tenantUuid);
        apiRequestFilter.doFilter(request, response, filterChain);
        Mockito.verify(filterChain, atLeastOnce()).doFilter(request, response);
    }

    @Test
    public void doFilter_crossTenancyInPathParam_invalid() throws Exception {
        String tenantUuid = "20988021-dd02-4aae-9b5d-8b5ce111cf5";
        String anotherTenantUuid = "98802120-dd02-4aae-9b5d-8b5ce111cf5";
        ReflectionUtils.setField(ApiRequestFilter.class, apiRequestFilter, "disabledEndpoints",
            Arrays.asList("assets", "assetRestrictionFeatures"));
        when(request.getServletPath()).thenReturn("/v3/tenants/" + anotherTenantUuid + "/enterpriseTypes");
        when(request.getMethod()).thenReturn("POST");
        when(response.getWriter()).thenReturn(printWriter);
        RequestContext.put(RequestContext.TENANT_UUID, tenantUuid);
        apiRequestFilter.doFilter(request, response, filterChain);
        Mockito.verify(filterChain, never()).doFilter(request, response);
    }

    @Test
    public void doFilter_crossTenancyInQueryParams_valid() throws Exception {
        String tenantUuid = "20988021-dd02-4aae-9b5d-8b5ce111cf5";
        ReflectionUtils.setField(ApiRequestFilter.class, apiRequestFilter, "disabledEndpoints",
            Arrays.asList("assets", "assetRestrictionFeatures"));
        when(request.getServletPath()).thenReturn("/v3/tenants/" + tenantUuid + "/enterpriseTypes");
        when(request.getMethod()).thenReturn("POST");
        Map<String, String[]> queryParams = new HashMap<>();
        queryParams.put("uris", new String[]{"/tags/bb571726-c1a3-4610-99de-435ab7f74000"});
        when(request.getParameterMap()).thenReturn(queryParams);
        RequestContext.put(RequestContext.TENANT_UUID, tenantUuid);
        apiRequestFilter.doFilter(request, response, filterChain);
        Mockito.verify(filterChain, atLeastOnce()).doFilter(request, response);
    }

    @Test
    public void doFilter_crossTenancyInQueryParams_invalid() throws Exception {
        String tenantUuid = "20988021-dd02-4aae-9b5d-8b5ce111cf5";
        String anotherTenantUuid = "98802120-dd02-4aae-9b5d-8b5ce111cf5";
        ReflectionUtils.setField(ApiRequestFilter.class, apiRequestFilter, "disabledEndpoints",
            Arrays.asList("assets", "assetRestrictionFeatures"));
        when(request.getServletPath()).thenReturn("/v3/tenants/" + tenantUuid + "/enterpriseTypes");
        when(request.getMethod()).thenReturn("POST");
        Map<String, String[]> queryParams = new HashMap<>();
        queryParams.put("uris", new String[]{"/tenants/"+ anotherTenantUuid
            + "/tags/bb571726-c1a3-4610-99de-435ab7f74000"});
        when(request.getParameterMap()).thenReturn(queryParams);
        when(response.getWriter()).thenReturn(printWriter);
        RequestContext.put(RequestContext.TENANT_UUID, tenantUuid);
        apiRequestFilter.doFilter(request, response, filterChain);
        Mockito.verify(filterChain, never()).doFilter(request, response);
    }

}