///********************************************************************************
// * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
// *                                                                              *
// * The copyright to the computer software herein is the property of GE Digital. *
// * The software may be used and/or copied only with the written permission of   *
// * GE Digital or in accordance with the terms and conditions stipulated in the  *
// * agreement/contract under which the software has been supplied.               *
// ********************************************************************************/
//
//package com.ge.apm.asset.mq.processor;
//
//import static org.hamcrest.CoreMatchers.equalTo;
//import static org.hamcrest.CoreMatchers.notNullValue;
//import static org.junit.Assert.assertThat;
//import static org.mockito.Matchers.eq;
//import static org.mockito.Mockito.when;
//
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.mockito.ArgumentCaptor;
//import org.mockito.Captor;
//import org.mockito.InjectMocks;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.ge.apm.asset.model.GroupType;
//import com.ge.apm.asset.model.constants.Prefixes;
//import com.ge.apm.asset.mq.exception.DependencyViolationException;
//
//
///**
// * Created by 212448111 on 2/22/17.
// */
//public class GroupProcessorTest extends AbstractProcessorTest {
//
//    @InjectMocks
//    @Autowired
//    GroupProcessor groupProcessor;
//
//    @Captor
//    ArgumentCaptor<GroupType> groupTypeArgCaptor;
//
//    @Before
//    public void setup() {
//        super.setup();
//    }
//
//    @Test
//    public void preProcess() {
//        when(sourceKeyLookup.lookupObjectUriFor(eq(tenantId), eq(Prefixes.GroupTypes + "/" + GroupType.SOURCE_KEY)))
//                .thenThrow(DependencyViolationException.class);
//       when(crudController.create(groupTypeArgCaptor.capture())).thenReturn(null);
//        try {
//            groupProcessor.preProcess(exchange);
//        } catch (Exception e) {
//            e.printStackTrace();
//            Assert.fail("preprocess throws exception");
//        }
//        GroupType groupTypes = groupTypeArgCaptor.getValue();
//        Assert.assertThat("Group type sent is null", groupTypeArgCaptor.getValue(), notNullValue());
//        assertThat("Remaining tags to retry incorrect", groupTypes.getSourceKey(), equalTo(GroupType.SOURCE_KEY));
//    }
//
//}
