/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.group;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.ge.apm.asset.api.base.AbstractInstanceControllerTest;
import com.ge.apm.asset.controller.GroupController;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.model.GroupType;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.support.RequestContext;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.contains;
import static org.mockito.Matchers.eq;

/**
 * Created by 212319603 on 2/23/16.
 */
public abstract class AbstractGroupControllerTest extends AbstractInstanceControllerTest<GroupController, Group> {

    protected GroupController groupController;

    public AbstractGroupControllerTest() {
        // define an explicit constructor
    }

    protected AbstractGroupControllerTest(boolean accessControlledTest) {
        super(accessControlledTest);
    }

    public Class<?> getTypeClass() {
        return GroupType.class;
    }

    @Override
    public Class<Group> getObjectClass() {
        return Group.class;
    }

    @Override
    public GroupController getController() {
        return groupController;
    }

    @Override
    public String getTypePrefix() {
        return Prefixes.GroupTypes;
    }

    @Override
    public String getPrefix() {
        return Prefixes.Groups;
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        groupController = new GroupController();
        ReflectionUtils.setField(GroupController.class, groupController, "service", assetService);
        ReflectionUtils.setField(GroupController.class, groupController, "pageSize", 10);
        ReflectionUtils.setField(GroupController.class, groupController, "assetRestrictionFeaturesEnabled", true);

        Mockito.when(RequestContext.get(RequestContext.SERVICE_REST_TEMPLATE)).thenReturn(restTemplate);
        Mockito.doAnswer(invocation -> null).when(restTemplate).exchange(contains("/v1/assetGroups"),
            eq(HttpMethod.GET), any(HttpEntity.class), eq(Group.class));
        GroupType mockGroupType = new GroupType();
        Mockito.doAnswer(invocation -> new ResponseEntity<GroupType>(mockGroupType, HttpStatus.OK)).when(restTemplate)
            .exchange(contains("/v1/groupTypes"), eq(HttpMethod.GET), any(HttpEntity.class), eq(GroupType.class));

        Map<String, Object> gaVariables = new HashMap<>();
        gaVariables.put("pageSize", 1000);
        gaVariables.put("filter", "toUri=" + Prefixes.uri(Prefixes.Groups, "bb571726-c1a3-4610-99de-435ab7f74000"));
    }
}
