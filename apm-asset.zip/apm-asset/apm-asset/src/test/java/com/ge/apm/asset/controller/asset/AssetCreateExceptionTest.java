/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.asset;

import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;

import com.ge.apm.asset.api.crud.ICreateExceptionTest;
import com.ge.apm.asset.controller.AssetController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ForbiddenException;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.UnauthorizedException;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class })
public class AssetCreateExceptionTest extends AbstractAssetControllerTest
    implements ICreateExceptionTest<Asset, IAssetService, AssetController> {

    @Override
    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
    }

    @Override
    @Test(expected = UnauthorizedException.class)
    public void unauthorized() throws IOException {
        setUpForUnauthorizedException();
        performAssetCreateOperation();
    }

    @Override
    @Test(expected = ForbiddenException.class)
    public void forbidden() throws IOException {
        setUpForForbiddenException();
        performAssetCreateOperation();
    }

    @Override
    @Test(expected = NotFoundException.class)
    public void notFound() throws IOException {
        setUpForNotFoundException();
        performAssetCreateOperation();
    }

    @Override
    @Test(expected = BadRequestException.class)
    public void badRequest() throws IOException {
        setUpForBadRequestException();
        performAssetCreateOperation();
    }

    private void performAssetCreateOperation() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);

        urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 250);

        Asset[] objects = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 250);
        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());
        setupGetBySourceKeysFromPersistence(new String[] { objects[0].getSourceKey() }, null, getPrefix(),
            getObjectClass());
        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.AssetTypes, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/type.json", AssetType.class)[0]);
        Mockito.doReturn(null).when(getRestTemplate()).exchange(anyString(), eq(HttpMethod.DELETE),
            any(HttpEntity.class), eq(Void.class));

       getController().create(Arrays.asList(objects));
    }
}
