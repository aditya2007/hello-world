/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.grouptype;

import java.text.ParseException;

import org.junit.Before;

import com.ge.apm.asset.api.base.AbstractTypeControllerTest;
import com.ge.apm.asset.controller.GroupTypeController;
import com.ge.apm.asset.model.GroupType;
import com.ge.apm.asset.model.ObjectInfo;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.util.ReflectionUtils;

/**
 * Created by 212553303 on 3/1/16.
 */
public class AbstractGroupTypeControllerTest extends AbstractTypeControllerTest<GroupTypeController, GroupType> {

    protected GroupTypeController groupTypeController;

    public AbstractGroupTypeControllerTest() {
        // define an explicit constructor
    }

    @Override
    public Class<GroupType> getObjectClass() {
        return GroupType.class;
    }

    @Override
    public GroupTypeController getController() {
        return groupTypeController;
    }

    @Override
    public String getTypePrefix() {
        return "";
    }

    @Override
    public String getPrefix() {
        return Prefixes.GroupTypes;
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        groupTypeController = new GroupTypeController();
        ReflectionUtils.setField(GroupTypeController.class, groupTypeController, "service", assetTypeService);
    }

    public ObjectInfo[] getChildrenInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.GroupTypes, "groupType.json", GroupType.class) };
    }

    public ObjectInfo[] getParentInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.GroupTypes, "groupType.json", GroupType.class) };
    }
}
