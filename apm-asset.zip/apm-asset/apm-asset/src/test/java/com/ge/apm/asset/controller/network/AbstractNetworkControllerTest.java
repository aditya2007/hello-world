/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.network;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;

import com.ge.apm.asset.AssetStateManageBuilder;
import com.ge.apm.asset.HttpActionType;
import com.ge.apm.asset.adapter.api.ITypedAdapter;
import com.ge.apm.asset.adapter.impl.EdgeAdapter;
import com.ge.apm.asset.adapter.impl.NetworkAdapter;
import com.ge.apm.asset.api.base.AbstractControllerTest;
import com.ge.apm.asset.controller.NetworkController;
import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.model.Network;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.IAssetStateManager;
import com.ge.apm.asset.service.api.IAssetConfigService;
import com.ge.apm.asset.service.impl.AssetService;
import com.ge.apm.asset.service.persistence.AlmPersistenceService;
import com.ge.apm.asset.util.ReflectionUtils;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.spy;

/**
 * Created by 212448111 on 8/3/17.
 */

public abstract class AbstractNetworkControllerTest extends AbstractControllerTest<NetworkController, Network> {

    protected NetworkController networkController;

    protected AssetService assetService;

    protected List<ITypedAdapter> typedAdapters;

    @Captor
    protected ArgumentCaptor<HttpEntity<?>> httpEntityCaptor;

    @Mock
    AlmPersistenceService almPersistenceService;

    @Mock(name = "createAssetStateManager")
    private IAssetStateManager createAssetStateManager;

    @Mock(name = "updateAssetStateManager")
    private IAssetStateManager updateAssetStateManager;

    @Mock
    private AssetStateManageBuilder assetStateManageBuilder;

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        networkController = new NetworkController();
        assetService = spy(new AssetService());
        typedAdapters = new ArrayList<>();
        typedAdapters.add(spyAdapters(assetConfigService, NetworkAdapter.class));
        typedAdapters.add(spyAdapters(assetConfigService, EdgeAdapter.class));
        ReflectionUtils.setField(NetworkController.class, networkController, "service", assetService);
        ReflectionUtils.setField(NetworkController.class, networkController, "assetRestrictionFeaturesEnabled", true);
        ReflectionUtils.setField(AssetService.class, assetService, "assetCacheManager", assetCacheManager);
        ReflectionUtils.setField(AssetService.class, assetService, "typedAdapters", typedAdapters);
        ReflectionUtils.setField(AssetService.class, assetService, "assetConfigService", assetConfigService);
        ReflectionUtils.setField(AssetService.class, assetService, "almPersistenceService", almPersistenceService);
        ReflectionUtils.setField(AssetService.class, assetService, "assetCacheManager", assetCacheManager);

        ReflectionUtils.setField(AssetService.class, assetService, "assetStateManageBuilder", assetStateManageBuilder);
        Mockito.doReturn(createAssetStateManager).when(assetStateManageBuilder).build(eq(HttpActionType.CREATE));
        Mockito.doReturn(updateAssetStateManager).when(assetStateManageBuilder).build(eq(HttpActionType.UPDATE));
        Mockito.doReturn(false).when(createAssetStateManager).manageAsset(anyString(), any(), any());
        Mockito.doReturn(false).when(updateAssetStateManager).manageAsset(anyString(), any(), any());

        assetService.afterPropertiesSet();
    }

    @Override
    public <T extends Attributable> void setupGetByInstanceUriFromPersistence(String uri, T returnObject,
        boolean ignoreAccessibleResourcesFilter) {
        Mockito.doReturn(returnObject).when(almPersistenceService).getInstanceByUri(anyString(), anyString(),
            anyBoolean());
    }

    protected <T extends ITypedAdapter> ITypedAdapter spyAdapters(IAssetConfigService iacs, Class<T> clazz)
        throws InstantiationException, IllegalAccessException {
        T typedAdapter = spy(clazz.newInstance());
        if (iacs != null) {
            ReflectionUtils.setField(clazz, typedAdapter, "assetConfigService", iacs);
        }
        return typedAdapter;
    }

    @Override
    public Class<Network> getObjectClass() {
        return Network.class;
    }

    @Override
    public NetworkController getController() {
        return networkController;
    }

    @Override
    public String getTypePrefix() {
        return null;
    }

    @Override
    public String getPrefix() {
        return Prefixes.Networks;
    }
}
