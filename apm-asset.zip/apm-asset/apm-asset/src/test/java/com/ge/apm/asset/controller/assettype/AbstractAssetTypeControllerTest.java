/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.assettype;

import java.text.ParseException;

import org.junit.Before;

import com.ge.apm.asset.api.base.AbstractTypeControllerTest;
import com.ge.apm.asset.controller.AssetTypeController;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.ObjectInfo;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.util.ReflectionUtils;

public abstract class AbstractAssetTypeControllerTest
    extends AbstractTypeControllerTest<AssetTypeController, AssetType> {

    protected AssetTypeController assetTypeController;

    @Override
    public Class<AssetType> getObjectClass() {
        return AssetType.class;
    }

    @Override
    public AssetTypeController getController() {
        return assetTypeController;
    }

    @Override
    public String getTypePrefix() {
        return "";
    }

    @Override
    public String getPrefix() {
        return Prefixes.AssetTypes;
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        assetTypeController = new AssetTypeController();
        ReflectionUtils.setField(AssetTypeController.class, assetTypeController, "service", assetTypeService);
    }

    public ObjectInfo[] getChildrenInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.AssetTypes, "assetType.json", AssetType.class) };
    }

    public ObjectInfo[] getParentInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.AssetTypes, "assetType.json", AssetType.class) };
    }
}
