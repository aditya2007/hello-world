/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.asset;

import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.asset.controller.AssetController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.stuf.security.context.SecurityContext;
import com.ge.stuf.security.context.SecurityPrincipal;

/**
 * Created by 212389934 on 7/14/16.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ SecurityContext.class, IAssetService.class, SecurityPrincipal.class })
public class AssetDeleteTest extends TestCase {

    private static final String uuid = "anyString";

    @InjectMocks
    private AssetController assetController;

    @Mock(name = "service")
    private IAssetService assetService;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private SecurityPrincipal securityPrincipal;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Ignore("No longer valid due to new persistency layer")
    @SuppressWarnings("unchecked")
    @Test(expected = Exception.class)
    public void hasChildrenExceptionTest() {

        mockSecurityPrincipal();
        PowerMockito.doThrow(new RuntimeException("Exception Throws!")).
            when(assetService).getChildren(Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
            Mockito.any(Class.class), Matchers.anyListOf(String.class), Mockito.any(QueryPredicate.class),
            Mockito.anyBoolean(), Mockito.anyInt(), Matchers.eq(true));

        assetController.delete(uuid);
    }

    @Ignore("No longer valid due to new persistency layer")
    @SuppressWarnings("unchecked")
    @Test(expected = Exception.class)
    public void hasTagExceptionTest() {
        Hierarchical assetChildren[] = new Hierarchical[2];
        mockSecurityPrincipal();
        Mockito.when(assetService
            .getChildren(Matchers.anyString(), Matchers.anyString(), Matchers.anyList(), Mockito.anyBoolean(),
                Mockito.any(QueryPredicate.class))).thenReturn(assetChildren);

        PowerMockito.doThrow(new RuntimeException("Exception Throws!")).
            when(assetService).getSingle(Matchers.anyString(), Mockito.any(Class.class),
            Matchers.anyListOf(String.class));

        assetController.delete(uuid);
    }

    @SuppressWarnings("unchecked")
    @Test(expected = BadRequestException.class)
    public void hasChildrenFailedTest() {

        Hierarchical assetChildren[] = new Hierarchical[2];
        Asset asset = new Asset();
        asset.setName("test");
        asset.setSourceKey("testsourcekey");

        mockSecurityPrincipal();
        PowerMockito.doReturn(new Asset()).when(assetService).getAssetByUUid(uuid);
        PowerMockito.when(assetService
            .getChildren(Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.any(Class.class),
                Matchers.anyList(), Mockito.any(QueryPredicate.class), Mockito.anyBoolean(), Mockito.anyInt(),
                Matchers.eq(true))).thenReturn(assetChildren);

        PowerMockito.when(
            assetService.getSingle(Matchers.anyString(), Mockito.any(Class.class), Matchers.anyListOf(String.class)))
            .thenReturn(asset);
        PowerMockito.doNothing().when(assetService).delete(Matchers.anyString(), Mockito.any(Class.class));
        assetController.delete(uuid);
    }

    @Ignore("No longer valid due to new persistency layer")
    @SuppressWarnings("unchecked")
    @Test(expected = Exception.class)
    public void hasChildrenTest() {
        Hierarchical assetChildren[] = new Hierarchical[1];
        Asset asset = new Asset();
        asset.setName("as");
        assetChildren[0] = asset;

        mockSecurityPrincipal();
        PowerMockito.when(
            assetService.getSingle(Matchers.anyString(), Mockito.any(Class.class), Matchers.anyListOf(String.class)))
            .thenReturn(asset);

        PowerMockito.when(assetService
            .getChildren(Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Mockito.any(Class.class),
                Matchers.anyListOf(String.class), Mockito.any(QueryPredicate.class), Mockito.anyBoolean(),
                Mockito.anyInt(), Matchers.eq(true))).thenReturn(assetChildren);

        assetController.delete(uuid);
    }

    @Ignore("No longer valid due to new persistency layer")
    @SuppressWarnings("unchecked")
    @Test(expected = Exception.class)
    public void hasTagTest() {

        MeasurementTag tag = new MeasurementTag();
        tag.setName("as");
        MeasurementTag[] tags = new MeasurementTag[1];
        tags[0] = tag;

        Asset asset = new Asset();
        asset.setName("as");
        asset.setMeasurementTags(tags);

        mockSecurityPrincipal();

        PowerMockito.when(
            assetService.getSingle(Matchers.anyString(), Mockito.any(Class.class), Matchers.anyListOf(String.class)))
            .thenReturn(asset);

        assetController.delete(uuid);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void hasGroupsTest() {

        Asset asset = new Asset();
        asset.setName("as");
        asset.setMeasurementTags(null);

        mockSecurityPrincipal();

        PowerMockito.when(assetService
            .getChildren(Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.any(Class.class),
                Matchers.anyList(), Mockito.any(QueryPredicate.class), Mockito.anyBoolean(), Mockito.anyInt(),
                Matchers.eq(true))).thenReturn(new Hierarchical[0]);
        PowerMockito.when(
            assetService.getSingle(Matchers.anyString(), Mockito.any(Class.class), Matchers.anyListOf(String.class)))
            .thenReturn(asset);
        PowerMockito.when(assetService
            .get(Matchers.anyString(), Mockito.any(Class.class), Matchers.anyListOf(String.class),
                Mockito.any(QueryPredicate.class), Matchers.anyInt())).thenReturn(null);
        PowerMockito.doReturn(new Asset()).when(assetService).getAssetByUUid(uuid);
        try {
            assetController.delete(uuid);
        } catch (Exception ex) {
            Assert.fail();
        }
    }

    @SuppressWarnings("unchecked")
    @Test(expected = Exception.class)
    public void deleteTest() {
        mockSecurityPrincipal();
        PowerMockito.doThrow(new RuntimeException("Exception Throws!")).when(assetService).delete(Matchers.anyString(),
            Mockito.any(Class.class));

        assetController.delete(uuid);
    }

    private void mockSecurityPrincipal() {
        PowerMockito.mockStatic(SecurityContext.class);
        //PowerMockito.when(SecurityContext.getInstance()).thenReturn(securityContext);
        PowerMockito.when(securityContext.getPrinicipal()).thenReturn(securityPrincipal);
        PowerMockito.when(securityPrincipal.getName()).thenReturn(null);
    }
}
