/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.sitetype;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

import com.ge.apm.asset.controller.SiteTypeController;
import com.ge.apm.asset.service.api.IAssetTypeService;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.exception.ForbiddenException;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.UnauthorizedException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.stuf.security.context.SecurityContext;
import com.ge.stuf.security.context.SecurityPrincipal;

import static org.mockito.Matchers.anyString;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ SecurityContext.class })
public class SiteTypeDeleteExceptionTest {

    @InjectMocks
    private SiteTypeController siteTypeController;

    @Mock
    private IAssetTypeService service;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private SecurityPrincipal securityPrincipal;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        mockSecurityPrincipal();
    }

    @Test(expected = UnauthorizedException.class)
    public void unauthorized() {
        delete(HttpStatus.UNAUTHORIZED);
    }

    @Test(expected = NotFoundException.class)
    public void notFound() {
        delete(HttpStatus.NOT_FOUND);
    }

    @Test(expected = ForbiddenException.class)
    public void forbidden() {
        delete(HttpStatus.FORBIDDEN);
    }

    @Test(expected = BadRequestException.class)
    public void badRequest() {
        delete(HttpStatus.BAD_REQUEST);
    }

    @SuppressWarnings("unchecked")
    private void delete(HttpStatus httpStatus) {
        HttpClientErrorException exception = new HttpClientErrorException(httpStatus);
        Mockito.doThrow(ExceptionUtil.wrapException(exception, ErrorProvider.findError(ErrorConstants.DELETE), ""))
            .when(service).delete(anyString(), Mockito.any(Class.class));
        siteTypeController.delete("testuuid");
    }

    private void mockSecurityPrincipal() {
        PowerMockito.mockStatic(SecurityContext.class);
        //PowerMockito.when(SecurityContext.getInstance()).thenReturn(securityContext);
        PowerMockito.when(securityContext.getPrinicipal()).thenReturn(securityPrincipal);
        PowerMockito.when(securityPrincipal.getName()).thenReturn(null);
    }
}
