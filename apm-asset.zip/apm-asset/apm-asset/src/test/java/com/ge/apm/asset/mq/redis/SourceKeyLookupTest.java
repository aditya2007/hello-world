/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.redis;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.ge.apm.asset.controller.base.ISourceKeyController;
import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.asset.mq.factory.ControllerFactory;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.ServiceException;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

public class SourceKeyLookupTest {

    @Spy
    @InjectMocks
    private SourceKeyLookup sourceKeyLookup;

    @Mock
    private ControllerFactory controllerFactory;

    @Mock
    private ISourceKeyController sourceKeyController;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void test_lookupObjectUriFor() {
        doReturn(sourceKeyController).when(controllerFactory).getSourceController(Matchers.eq("/assets"));
        Attributable asset = new Attributable();
        asset.setUri("/assets/b05d63f0-e2e9-33c8-8169-111111111111");
        doReturn(asset).when(sourceKeyController).getBySourceKey(Matchers.eq("sourceKey"));
        String uri = sourceKeyLookup.lookupObjectUriFor("b05d63f0-e2e9-33c8-8169-111111111111", "/assets/sourceKey");
        Assert.assertEquals("/assets/b05d63f0-e2e9-33c8-8169-111111111111", uri);
    }

    @Test
    public void lookupObjectUriFor() {
        doReturn(sourceKeyController).when(controllerFactory).getSourceController(Matchers.eq("/assets"));
        Attributable asset = new Attributable();
        asset.setUri("/assets/b05d63f0-e2e9-33c8-8169-111111111111");
        doReturn(asset).when(sourceKeyController).getBySourceKey(Matchers.eq("sourceKey"));
        String uri = sourceKeyLookup.lookupObjectUriFor("b05d63f0-e2e9-33c8-8169-111111111111", "/assets", "sourceKey");
        Assert.assertEquals("/assets/b05d63f0-e2e9-33c8-8169-111111111111", uri);
    }

    @Test(expected = DependencyViolationException.class)
    public void test_lookupObjectUriFor_ForDependencyViolationException() {
        doReturn(sourceKeyController).when(controllerFactory).getSourceController(Matchers.eq("/assets"));
        Attributable asset = new Attributable();
        asset.setUri("/assets/b05d63f0-e2e9-33c8-8169-111111111111");
        doThrow(NotFoundException.class).when(sourceKeyController).getBySourceKey(Matchers.eq("sourceKey"));
        sourceKeyLookup.lookupObjectUriFor("b05d63f0-e2e9-33c8-8169-111111111111", "/assets/sourceKey");
    }

    @Test(expected = ServiceException.class)
    public void test_lookupObjectUriFor_ForServiceException() {
        doReturn(sourceKeyController).when(controllerFactory).getSourceController(Matchers.eq("/assets"));
        sourceKeyLookup.lookupObjectUriFor("b05d63f0-e2e9-33c8-8169-111111111111", "assetssourceKey");
    }
}
