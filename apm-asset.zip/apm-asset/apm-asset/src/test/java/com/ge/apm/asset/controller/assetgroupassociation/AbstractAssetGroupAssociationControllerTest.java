/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.assetgroupassociation;

import java.text.ParseException;

import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;

import com.ge.apm.asset.api.base.AbstractInstanceControllerTest;
import com.ge.apm.asset.controller.AssetController;
import com.ge.apm.asset.controller.AssetGroupAssociationController;
import com.ge.apm.asset.controller.GroupController;
import com.ge.apm.asset.model.AssetGroupAssociation;
import com.ge.apm.asset.model.GroupType;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.factory.ControllerFactory;
import com.ge.apm.asset.util.ReflectionUtils;

/**
 * Created by 212319603 on 2/23/16.
 */
public abstract class AbstractAssetGroupAssociationControllerTest
    extends AbstractInstanceControllerTest<AssetGroupAssociationController, AssetGroupAssociation> {

    @Spy
    @InjectMocks
    protected AssetGroupAssociationController assetGroupAssociationController;

    @Mock
    public ControllerFactory controllerFactory;

    @Mock
    public GroupController groupController;

    @Mock
    public AssetController assetController;

    public AbstractAssetGroupAssociationControllerTest() {
        // define an explicit constructor
    }

    protected AbstractAssetGroupAssociationControllerTest(boolean accessControlledTest) {
        super(accessControlledTest);
    }

    public Class<?> getTypeClass() {
        return GroupType.class;
    }

    @Override
    public Class<AssetGroupAssociation> getObjectClass() {
        return AssetGroupAssociation.class;
    }

    @Override
    public AssetGroupAssociationController getController() {
        return assetGroupAssociationController;
    }

    @Override
    public String getTypePrefix() {
        return Prefixes.GroupTypes;
    }

    @Override
    public String getPrefix() {
        return Prefixes.AssetGroupAssociations;
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        //assetGroupAssociationController = spy(new AssetGroupAssociationController());
        ReflectionUtils.setField(AssetGroupAssociationController.class, assetGroupAssociationController, "service",
            assetService);
        ReflectionUtils.setField(AssetGroupAssociationController.class, assetGroupAssociationController,
            "assetRestrictionFeaturesEnabled", true);
    }
}
