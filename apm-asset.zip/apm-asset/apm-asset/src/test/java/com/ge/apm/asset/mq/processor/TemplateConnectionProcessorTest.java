/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ge.apm.asset.controller.AssetController;
import com.ge.apm.asset.controller.EquipmentInstanceController;
import com.ge.apm.asset.controller.TemplateController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.AssetPlaceholderConnection;
import com.ge.apm.asset.model.EquipmentInstanceConnection;
import com.ge.apm.asset.model.EquipmentInstanceConnection.Category;
import com.ge.apm.asset.model.Template;
import com.ge.apm.asset.model.TemplateConnection;
import com.ge.apm.asset.model.TemplateInfo;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.asset.mq.factory.ControllerFactory;
import com.ge.apm.asset.mq.predicate.RetryPolicyPredicate;
import com.ge.apm.asset.mq.redis.SourceKeyLookup;
import com.ge.apm.asset.service.util.EquipmentInstanceCreationHelper;
import com.ge.apm.asset.service.util.EquipmentInstanceUtil;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.json.patch.AddOperation;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.json.patch.RemoveOperation;
import com.ge.apm.util.ResourceUtil;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.mq.constants.MessageConstants;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

public class TemplateConnectionProcessorTest extends AbstractProcessorTest {

    public static final String ERRORS_TEMPLATE = "errorsTemplate";

    public static final String PREVIOUS_ERROR_COUNT = "previousErrorCount";

    public static final String DVE_COUNT = "dveCount";

    public static final String ERROR_COUNT = "errorCount";

    @InjectMocks
    TemplateConnectionProcessor templateConnectionProcessor;

    @Mock
    EquipmentInstanceController equipmentInstanceController;

    @Mock
    EquipmentInstanceCreationHelper connectionCreationBuilder;

    @Mock
    TemplateController templateController;

    @Mock
    EquipmentInstanceUtil templateConnectionUtil;

    @Mock
    ControllerFactory controllerFactory;

    @Mock
    DtoProcessor dtoProcessor;

    @Mock
    TemplateConnection templateConnectionDto;

    @Mock
    SourceKeyLookup sourceKeyLookup;

    @Mock
    RetryPolicyPredicate retryPolicyPredicate;

    @Mock
    AssetController assetController;

    @Captor
    private ArgumentCaptor<EquipmentInstanceConnection> equipmentInstanceConnectionCaptor;

    @Captor
    private ArgumentCaptor<PatchOperation[]> deleteEquipments;

    @Captor
    private ArgumentCaptor<PatchOperation[]> updateEquipments;

    String taskUuid;

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Before
    public void setup() {

        MockitoAnnotations.initMocks(this);
        doNothing().when(mqAuthConfig).configure(anyString(), anyString(), anyString(), any(RequestMethod.class));

        try {
            Mockito.
                doReturn(assetController).
                when(controllerFactory).
                getController(eq(Prefixes.Assets));
            Mockito.
                doReturn(templateController).
                when(controllerFactory).
                getController(eq(Prefixes.Templates));

            ReflectionUtils.setField(TemplateConnectionProcessor.class, templateConnectionProcessor,
                "sourceKeyLookup", sourceKeyLookup);
            ReflectionUtils.setField(TemplateConnectionProcessor.class, templateConnectionProcessor,
                "retryPolicyPredicate", retryPolicyPredicate);
            ReflectionUtils.setField(TemplateConnectionProcessor.class, templateConnectionProcessor,
                "controllerFactory", controllerFactory);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testDispatch() throws Exception {

        mockTemplate();

        List<EquipmentInstanceConnection> equipmentInstanceConnections = readSingleTemplateConnection();
        equipmentInstanceConnections.forEach( connection -> Mockito.when(sourceKeyLookup.lookupObjectUriFor(anyString(),
            eq(Prefixes.Templates), eq(connection.getTemplateSourceKey())))
                    .thenReturn(Prefixes.Templates + "/" + connection.getTemplateSourceKey()));
        equipmentInstanceConnections.forEach( connection -> connection.getConnections().forEach(c ->
            Mockito.when(sourceKeyLookup.lookupObjectUriFor(anyString(),
                eq(Prefixes.Assets), eq(c.getAssetSourceKey())))
                .thenReturn(Prefixes.Assets + "/" + c.getAssetSourceKey())));
        Mockito.doReturn(null).when(equipmentInstanceController).createEquipmentInstances
                (equipmentInstanceConnectionCaptor.capture(), any(), any());

        Exchange exchangeObj = this.getExchange(equipmentInstanceConnections);

        templateConnectionProcessor.dispatch(exchangeObj);
        Assert.assertEquals(equipmentInstanceConnectionCaptor.getValue(), equipmentInstanceConnections.get(0));
        Assert.assertEquals(1, exchangeObj.getOut().getHeader(MessageConstants.TASK_ENTITY_COMPLETE));
        Assert.assertEquals(null, exchangeObj.getProperty(getPropertyName(ERRORS_TEMPLATE)));
        Assert.assertEquals(0, exchangeObj.getOut().getHeader(getPropertyName(PREVIOUS_ERROR_COUNT)));
        Assert.assertEquals(0, exchangeObj.getProperty(getPropertyName(DVE_COUNT)));
        Assert.assertEquals(0, exchangeObj.getProperty(getPropertyName(ERROR_COUNT)));
    }

    @Test
    public void testDispatchForDelete() throws Exception {

        mockTemplate();

        List<EquipmentInstanceConnection> equipmentInstanceConnections = readSingleTemplateConnection();
        equipmentInstanceConnections.
            forEach( connection -> Mockito.
                when(sourceKeyLookup.lookupObjectUriFor(anyString(), eq(Prefixes.Templates),
                    eq(connection.getTemplateSourceKey()))).
                thenReturn(Prefixes.Templates + "/" + connection.getTemplateSourceKey()));

        AssetPlaceholderConnection assetPhConnection = new AssetPlaceholderConnection();
        assetPhConnection.setPlaceholderId("PPN05");
        equipmentInstanceConnections.get(0).setConnections(Arrays.asList(assetPhConnection));
        equipmentInstanceConnections.get(0).setParentEntitySrcKey("PART06");
        equipmentInstanceConnections.get(0).setParentEntityCategory(Category.ASSET);

        Mockito.
            when(sourceKeyLookup.lookupObjectUriFor(anyString(),
                eq(Prefixes.Assets), eq(equipmentInstanceConnections.get(0).getParentEntitySrcKey()))).
            thenReturn(Prefixes.Assets + "/" +equipmentInstanceConnections.get(0).getParentEntitySrcKey());

        Exchange exchangeObj = this.getExchange(equipmentInstanceConnections);

        Mockito.
            doNothing().
            when(equipmentInstanceController).
            updateEquipmentInstance(eq("PART06"), any(), deleteEquipments.capture());

        Asset asset = new Asset();
        asset.setSourceKey(equipmentInstanceConnections.get(0).getParentEntitySrcKey());
        Mockito.doReturn(asset).when(assetController).getSingle(any(), eq(AssetComponentResolver
            .BASIC));

        templateConnectionProcessor.dispatch(exchangeObj);

        PatchOperation op = new RemoveOperation("/placeholders/PPN05");
        List<PatchOperation> list = new LinkedList<>();
        list.add(op);

        Assert.assertEquals(list, deleteEquipments.getAllValues());
        Assert.assertEquals(1, exchangeObj.getOut().getHeader(MessageConstants.TASK_ENTITY_COMPLETE));
        Assert.assertEquals(null, exchangeObj.getProperty(getPropertyName(ERRORS_TEMPLATE)));
        Assert.assertEquals(0, exchangeObj.getOut().getHeader(getPropertyName(PREVIOUS_ERROR_COUNT)));
        Assert.assertEquals(0, exchangeObj.getProperty(getPropertyName(DVE_COUNT)));
        Assert.assertEquals(0, exchangeObj.getProperty(getPropertyName(ERROR_COUNT)));
    }

    public void mockTemplate() throws IOException {
        List<Template> templates = readTemplates();
        String uuid = StringUtils.substringAfterLast(templates.get(0).getUri(), "/");
        Mockito.doReturn(templates.get(0)).when(templateController).getSingle(eq(uuid), eq(AssetComponentResolver
            .FULL));
    }

    @Test
    public void testDispatchForUpdate() throws Exception {

        mockTemplate();

        List<EquipmentInstanceConnection> equipmentInstanceConnections = readSingleTemplateConnection();

        equipmentInstanceConnections.
            forEach( connection -> Mockito.
                when(sourceKeyLookup.lookupObjectUriFor(anyString(), eq(Prefixes.Templates),
                    eq(connection.getTemplateSourceKey()))).
                thenReturn(Prefixes.Templates + "/" + connection.getTemplateSourceKey()));

        equipmentInstanceConnections.
            forEach( connection -> Mockito.
                when(sourceKeyLookup.getUri(anyString(), eq(Prefixes.Templates),
                    eq(connection.getTemplateSourceKey()))).
                thenReturn(Prefixes.Templates + "/" + connection.getTemplateSourceKey()));

        AssetPlaceholderConnection assetPhConnection = new AssetPlaceholderConnection();
        assetPhConnection.setPlaceholderId("PPN05");
        assetPhConnection.setAssetSourceKey("PART05B");
        equipmentInstanceConnections.get(0).setConnections(Arrays.asList(assetPhConnection));
        equipmentInstanceConnections.get(0).setParentEntitySrcKey("PART06");
        equipmentInstanceConnections.get(0).setParentEntityCategory(Category.ASSET);

        Mockito.
            when(sourceKeyLookup.lookupObjectUriFor(anyString(),
                eq(Prefixes.Assets), eq(equipmentInstanceConnections.get(0).getParentEntitySrcKey()))).
            thenReturn(Prefixes.Assets + "/" +equipmentInstanceConnections.get(0).getParentEntitySrcKey());
        Mockito.
            when(sourceKeyLookup.lookupObjectUriFor(anyString(),
                eq(Prefixes.Assets), eq("PART05B"))).
            thenReturn(Prefixes.Assets + "/" + "PART05B");

        Asset asset = new Asset();
        asset.setSourceKey(equipmentInstanceConnections.get(0).getParentEntitySrcKey());
        asset.setUri(Prefixes.Assets + "/" + asset.getSourceKey());
        TemplateInfo info = new TemplateInfo();
        info.setTemplateUri(Prefixes.Templates + "/" + equipmentInstanceConnections.get(0).getTemplateSourceKey());
        info.setPlaceholderId("PPN06");
        asset.setTemplateInfo(info);

        Mockito.doReturn(asset).
            when(assetController).
            getBySourceKey(eq(equipmentInstanceConnections.get(0).getParentEntitySrcKey()));

        Exchange exchangeObj = this.getExchange(equipmentInstanceConnections);

        Mockito.
            doNothing().
            when(equipmentInstanceController).
            updateEquipmentInstance(eq("PART06"), any(), updateEquipments.capture());

        Mockito.doReturn(asset).when(assetController).getSingle(any(), eq(AssetComponentResolver
            .BASIC));

        templateConnectionProcessor.dispatch(exchangeObj);

        PatchOperation op = new AddOperation("/placeholders/PPN05", "PART05B");
        List<PatchOperation> list = new LinkedList<>();
        list.add(op);

        Assert.assertEquals(list, updateEquipments.getAllValues());
        Assert.assertEquals(1, exchangeObj.getOut().getHeader(MessageConstants.TASK_ENTITY_COMPLETE));
        Assert.assertEquals(null, exchangeObj.getProperty(getPropertyName(ERRORS_TEMPLATE)));
        Assert.assertEquals(0, exchangeObj.getOut().getHeader(getPropertyName(PREVIOUS_ERROR_COUNT)));
        Assert.assertEquals(0, exchangeObj.getProperty(getPropertyName(DVE_COUNT)));
        Assert.assertEquals(0, exchangeObj.getProperty(getPropertyName(ERROR_COUNT)));
    }


    @Test (expected = DependencyViolationException.class)
    public void testDispatchWithDVEForTemplateId() throws Exception {
        List<EquipmentInstanceConnection> equipmentInstanceConnections = readSingleTemplateConnection();
        Exchange exchangeObj = this.getExchange(equipmentInstanceConnections);
        try {
            templateConnectionProcessor.dispatch(exchangeObj);
        } catch (Exception ex) {
            Assert.assertEquals(0, exchangeObj.getOut().getHeader(MessageConstants.TASK_ENTITY_COMPLETE));
            Assert.assertEquals(null, exchangeObj.getProperty(getPropertyName(ERRORS_TEMPLATE)));
            Assert.assertEquals(0, exchangeObj.getOut().getHeader(getPropertyName(PREVIOUS_ERROR_COUNT)));
            Assert.assertEquals(1, exchangeObj.getProperty(getPropertyName(DVE_COUNT)));
            Assert.assertEquals(0, exchangeObj.getProperty(getPropertyName(ERROR_COUNT)));
            Assert.assertArrayEquals(equipmentInstanceConnections.toArray(new
                EquipmentInstanceConnection[equipmentInstanceConnections.size()]), (EquipmentInstanceConnection[])
                exchangeObj.getProperty(MessageConstants.TEMP_CONN_TASK_RETRY_DTOS));
            String message = ErrorProvider.findMessage(ErrorConstants.LOOKUP_BY_SOURCE_KEY, Prefixes.Templates,
                equipmentInstanceConnections.get(0).getTemplateSourceKey());
            Assert.assertEquals(message, ex.getMessage());
            throw ex;
        }
    }

    @Test (expected = DependencyViolationException.class)
    public void testDispatchWithDVEForAssetId() throws Exception {

        mockTemplate();

        List<EquipmentInstanceConnection> equipmentInstanceConnections = readSingleTemplateConnection();
        equipmentInstanceConnections.forEach( connection -> Mockito.when(sourceKeyLookup.lookupObjectUriFor(anyString(),
            eq(Prefixes.Templates), eq(connection.getTemplateSourceKey())))
            .thenReturn(Prefixes.Templates + "/" + connection.getTemplateSourceKey()));
        Exchange exchangeObj = this.getExchange(equipmentInstanceConnections);
        try {
            templateConnectionProcessor.dispatch(exchangeObj);
        } catch (Exception ex) {
            Assert.assertEquals(null, exchangeObj.getProperty(getPropertyName(ERRORS_TEMPLATE)));
            Assert.assertArrayEquals(equipmentInstanceConnections.toArray(new
                EquipmentInstanceConnection[equipmentInstanceConnections.size()]), (EquipmentInstanceConnection[])
                exchangeObj.getProperty(MessageConstants.TEMP_CONN_TASK_RETRY_DTOS));
            Assert.assertEquals(0, exchangeObj.getOut().getHeader(getPropertyName(PREVIOUS_ERROR_COUNT)));
            Assert.assertEquals(1, exchangeObj.getProperty(getPropertyName(DVE_COUNT)));
            Assert.assertEquals(0, exchangeObj.getProperty(getPropertyName(ERROR_COUNT)));
            String message = ErrorProvider.findMessage(ErrorConstants.LOOKUP_BY_SOURCE_KEY, Prefixes.Assets,
                equipmentInstanceConnections.get(0).getConnections().get(0).getAssetSourceKey());
            Assert.assertEquals(message, ex.getMessage());
            throw ex;
        }
    }

    @Test (expected = DependencyViolationException.class)
    public void testDispatchWithDVEForParentEntity() throws Exception {
        List<EquipmentInstanceConnection> equipmentInstanceConnections = readSingleTemplateConnection();
        equipmentInstanceConnections.get(0).setParentEntitySrcKey("parentSite");
        equipmentInstanceConnections.get(0).setParentEntityCategory(Category.SITE);
        equipmentInstanceConnections.forEach( connection -> Mockito.when(sourceKeyLookup.lookupObjectUriFor(anyString(),
            eq(Prefixes.Templates), eq(connection.getTemplateSourceKey())))
            .thenReturn(Prefixes.Templates + "/" + connection.getTemplateSourceKey()));
        Exchange exchangeObj = this.getExchange(equipmentInstanceConnections);
        try {
            templateConnectionProcessor.dispatch(exchangeObj);
        } catch (Exception ex) {
            Assert.assertEquals(null, exchangeObj.getProperty(getPropertyName(ERRORS_TEMPLATE)));
            Assert.assertArrayEquals(equipmentInstanceConnections.toArray(new
                EquipmentInstanceConnection[equipmentInstanceConnections.size()]), (EquipmentInstanceConnection[])
                exchangeObj.getProperty(MessageConstants.TEMP_CONN_TASK_RETRY_DTOS));
            Assert.assertEquals(0, exchangeObj.getOut().getHeader(getPropertyName(PREVIOUS_ERROR_COUNT)));
            Assert.assertEquals(1, exchangeObj.getProperty(getPropertyName(DVE_COUNT)));
            Assert.assertEquals(0, exchangeObj.getProperty(getPropertyName(ERROR_COUNT)));
            String message = ErrorProvider.findMessage(ErrorConstants.LOOKUP_BY_SOURCE_KEY, Prefixes.Sites,
                equipmentInstanceConnections.get(0).getParentEntitySrcKey());
            Assert.assertEquals(message, ex.getMessage());
            throw ex;
        }
    }

    @Test (expected = DependencyViolationException.class)
    public void testDispatchWithRetryException() throws Exception {
        mockTemplate();
        List<EquipmentInstanceConnection> equipmentInstanceConnections = readSingleTemplateConnection();
        equipmentInstanceConnections.forEach( connection -> Mockito.when(sourceKeyLookup.lookupObjectUriFor(anyString(),
            eq(Prefixes.Templates), eq(connection.getTemplateSourceKey())))
            .thenReturn(Prefixes.Templates + "/" + connection.getTemplateSourceKey()));
        equipmentInstanceConnections.forEach( connection -> connection.getConnections().forEach(c ->
            Mockito.when(sourceKeyLookup.lookupObjectUriFor(anyString(),
                eq(Prefixes.Assets), eq(c.getAssetSourceKey())))
                .thenReturn(Prefixes.Assets + "/" + c.getAssetSourceKey())));
        Mockito.doThrow(new DependencyViolationException(ErrorProvider.findError(ErrorConstants
            .LOOKUP_BY_SOURCE_KEY), Prefixes.Assets, "test")).when(equipmentInstanceController)
            .createEquipmentInstances(any(), any(), any());
        Exchange exchangeObj = this.getExchange(equipmentInstanceConnections);
        when(retryPolicyPredicate.isRecoverableException(any())).thenReturn(true);
        try {
            templateConnectionProcessor.dispatch(exchangeObj);
        } catch (Exception ex) {
            Assert.assertEquals(null, exchangeObj.getProperty(getPropertyName(ERRORS_TEMPLATE)));
            Assert.assertArrayEquals(equipmentInstanceConnections.toArray(new
                EquipmentInstanceConnection[equipmentInstanceConnections.size()]), (EquipmentInstanceConnection[])
                exchangeObj.getProperty(MessageConstants.TEMP_CONN_TASK_RETRY_DTOS));
            Assert.assertEquals(0, exchangeObj.getOut().getHeader(getPropertyName(PREVIOUS_ERROR_COUNT)));
            Assert.assertEquals(1, exchangeObj.getProperty(getPropertyName(DVE_COUNT)));
            Assert.assertEquals(0, exchangeObj.getProperty(getPropertyName(ERROR_COUNT)));
            Assert.assertEquals(ErrorProvider.findMessage(ErrorConstants
                .LOOKUP_BY_SOURCE_KEY, Prefixes.Assets, "test"), ex.getMessage());
            throw ex;
        }
    }

    @Test (expected = Exception.class)
    public void testDispatchWithNonRecoverableException() throws Exception {

        mockTemplate();

        List<EquipmentInstanceConnection> equipmentInstanceConnections = readSingleTemplateConnection();
        equipmentInstanceConnections.forEach( connection -> Mockito.when(sourceKeyLookup.lookupObjectUriFor(anyString(),
            eq(Prefixes.Templates), eq(connection.getTemplateSourceKey())))
            .thenReturn(Prefixes.Templates + "/" + connection.getTemplateSourceKey()));
        equipmentInstanceConnections.forEach( connection -> connection.getConnections().forEach(c ->
            Mockito.when(sourceKeyLookup.lookupObjectUriFor(anyString(),
                eq(Prefixes.Assets), eq(c.getAssetSourceKey())))
                .thenReturn(Prefixes.Assets + "/" + c.getAssetSourceKey())));

        RuntimeException exception = new RuntimeException("Test");

        Mockito.doThrow(exception).when(equipmentInstanceController)
            .createEquipmentInstances(any(), any(), any());
        Exchange exchangeObj = this.getExchange(equipmentInstanceConnections);
        when(retryPolicyPredicate.isRecoverableException(any())).thenReturn(false);
        try {
            templateConnectionProcessor.dispatch(exchangeObj);
        } catch (Exception ex) {
            List<RuntimeException> exceptions = Arrays.asList(exception);
            Assert.assertEquals(exceptions, exchangeObj.getProperty(getPropertyName(ERRORS_TEMPLATE)));
            Assert.assertEquals(ErrorConstants.SYSTEM_ERROR, ex.getMessage());
            Assert.assertEquals(1, exchangeObj.getOut().getHeader(getPropertyName(PREVIOUS_ERROR_COUNT)));
            Assert.assertEquals(0, exchangeObj.getProperty(getPropertyName(DVE_COUNT)));
            Assert.assertEquals(1, exchangeObj.getProperty(getPropertyName(ERROR_COUNT)));
            throw ex;
        }
    }

    private Exchange getExchange(List<EquipmentInstanceConnection> templateConnections) {
        CamelContext ctx = new DefaultCamelContext();
        Exchange exchangeObj = new DefaultExchange(ctx);
        exchangeObj.getIn().setBody(templateConnections.stream().toArray(EquipmentInstanceConnection[]::new));

        tenantId = "TENANT";
        authToken = "AUTH_TOKEN";
        traceId = "traceId";
        taskUuid = UUID.randomUUID().toString();

        headerMap.put(MessageConstants.TASK_ENTITY_TOTAL, 1);
        headerMap.put(MessageConstants.TENANT_UUID, tenantId);
        headerMap.put(MessageConstants.AUTHORIZATION, authToken);
        headerMap.put(MessageConstants.TASK_UUID, taskUuid);
        headerMap.put(MessageConstants.TRACE_UUID, traceId);


        exchangeObj.getIn().setHeaders(headerMap);
        return exchangeObj;
    }

    private String getPropertyName(String key) {
        return key + "_" + tenantId + "_" + taskUuid;
    }

    public static List<EquipmentInstanceConnection> readSingleTemplateConnection() throws IOException {
        String content = ResourceUtil
            .readFromRelativeToModuleDirFileAsString("/../test-data/input/equipmentInstances"
                + "/equipmentInstance.json");
        return MAPPER.reader(new TypeReference<List<EquipmentInstanceConnection>>() { }).readValue(content);
    }

    public static List<Template> readTemplates() throws IOException {
        String content = ResourceUtil
            .readFromRelativeToModuleDirFileAsString("/../test-data/input/equipmentInstances"
                + "/template.json");
        return MAPPER.reader(new TypeReference<List<Template>>() { }).readValue(content);
    }
}
