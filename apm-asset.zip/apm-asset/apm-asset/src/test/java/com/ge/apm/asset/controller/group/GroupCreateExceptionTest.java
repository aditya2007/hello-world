/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.group;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.asset.api.crud.ICreateExceptionTest;
import com.ge.apm.asset.controller.GroupController;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ForbiddenException;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.UnauthorizedException;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class })
public class GroupCreateExceptionTest extends AbstractGroupControllerTest
    implements ICreateExceptionTest<Group, IAssetService, GroupController> {

    private void performGroupCreateOperation() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);

        urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 250);

        Group[] groupObjects = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        Map<String, Object> groupVariables = new HashMap<>();
        groupVariables.put("pageSize", 1);
        groupVariables.put("filter", "sourceKey=" + groupObjects[0].getSourceKey());

        Group[] objects = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 250);
        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());

        setupGetBySourceKeysFromPersistence(new String[] { objects[0].getSourceKey() }, null, getPrefix(),
            getObjectClass());
        getController().create(Arrays.asList(objects));
    }

    @Override
    @Test(expected = UnauthorizedException.class)
    public void unauthorized() throws IOException {
        setUpForUnauthorizedException();
        performGroupCreateOperation();
    }

    @Override
    @Test(expected = ForbiddenException.class)
    public void forbidden() throws IOException {
        setUpForForbiddenException();
        performGroupCreateOperation();
    }

    @Override
    @Test(expected = NotFoundException.class)
    public void notFound() throws IOException {
        //TODO - Check with Anba, on which object are we are throwing NotFoundException.
        setUpForNotFoundException();
        performGroupCreateOperation();
    }

    @Override
    @Test(expected = BadRequestException.class)
    public void badRequest() throws IOException {
        setUpForBadRequestException();
        performGroupCreateOperation();
    }
}
