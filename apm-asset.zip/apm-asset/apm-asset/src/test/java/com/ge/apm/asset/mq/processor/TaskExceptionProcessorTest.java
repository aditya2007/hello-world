/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import org.apache.camel.Exchange;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

/**
 * Created by 212448111 on 3/30/17.
 */
public class TaskExceptionProcessorTest extends AbstractProcessorTest {

    @InjectMocks
    @Autowired
    TaskExceptionProcessor taskExceptionProcessor;

    @Test
    public void process_BadRequestException() {
        BadRequestException bre = new BadRequestException(
            ErrorProvider.findError(ErrorConstants.MISSING_MANDATORY_PARAM), "q");
        when(exchange.getProperty(eq(Exchange.EXCEPTION_CAUGHT), eq(Throwable.class))).thenReturn(bre);

        try {
            taskExceptionProcessor.process(exchange);
        } catch (ServiceException ex) {
            assertThat("Cause is not BadRequestException", ex.getCause(), instanceOf(BadRequestException.class));
            assertThat("Message is not formatted", ex.getCause().getMessage(), not(containsString("%s")));
        } catch (Exception ex) {
            fail("No ServiceException was thrown");
        }
    }

    @Test
    public void process_FormattedMessageBadRequestException() {
        BadRequestException bre = new BadRequestException("Invalid request");
        when(exchange.getProperty(eq(Exchange.EXCEPTION_CAUGHT), eq(Throwable.class))).thenReturn(bre);

        try {
            taskExceptionProcessor.process(exchange);
        } catch (ServiceException ex) {

            assertThat("Cause is not BadRequestException", ex.getCause(), instanceOf(BadRequestException.class));
            assertThat("Message is not formatted", ex.getCause().getMessage(), not(containsString("%s")));
        } catch (Exception ex) {
            fail("No ServiceException was thrown");
        }
    }
}
