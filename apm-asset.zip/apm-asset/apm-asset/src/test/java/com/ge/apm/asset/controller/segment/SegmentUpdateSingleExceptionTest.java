/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.segment;

import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.asset.api.crud.IUpdateSingleExceptionTest;
import com.ge.apm.asset.controller.SegmentController;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class })
public class SegmentUpdateSingleExceptionTest extends AbstractSegmentControllerTest
    implements IUpdateSingleExceptionTest<Segment, IAssetService, SegmentController> { }
