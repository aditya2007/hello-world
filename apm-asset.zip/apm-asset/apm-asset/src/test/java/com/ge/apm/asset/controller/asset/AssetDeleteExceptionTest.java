/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.asset;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

import com.ge.apm.asset.controller.AssetController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.exception.ForbiddenException;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.exception.UnauthorizedException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.stuf.security.context.SecurityContext;
import com.ge.stuf.security.context.SecurityPrincipal;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyString;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ SecurityContext.class })
public class AssetDeleteExceptionTest {

    @InjectMocks
    private AssetController assetController;

    @Mock
    private IAssetService service;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private SecurityPrincipal securityPrincipal;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        mockSecurityPrincipal();
        PowerMockito.when(service
            .getChildren(Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.any(Class.class),
                Matchers.anyList(), Mockito.any(QueryPredicate.class), Mockito.anyBoolean(), Mockito.anyInt(),
                Matchers.eq(true))).thenReturn(new Hierarchical[0]);
        PowerMockito.doReturn(new Asset()).when(service).getSingle(anyString(), any(), anyList());
    }

    @Test(expected = UnauthorizedException.class)
    public void unauthorized() {
        delete(HttpStatus.UNAUTHORIZED);
    }

    @Test(expected = NotFoundException.class)
    public void notFound() {
        delete(HttpStatus.NOT_FOUND);
    }

    @Test(expected = ForbiddenException.class)
    public void forbidden() {
        delete(HttpStatus.FORBIDDEN);
    }

    @Test(expected = BadRequestException.class)
    public void badRequest() {
        delete(HttpStatus.BAD_REQUEST);
    }

    @SuppressWarnings("unchecked")
    private void delete(HttpStatus httpStatus) {
        HttpClientErrorException exception = new HttpClientErrorException(httpStatus);
        Mockito.doThrow(ExceptionUtil.wrapException(exception, ErrorProvider.findError(ErrorConstants.DELETE), ""))
            .when(service).deleteAssetRecursively(anyString(), anyString(), Mockito.any(Class.class));
        assetController.delete("testuuid");
    }

    private void mockSecurityPrincipal() {
        PowerMockito.mockStatic(SecurityContext.class);
        //PowerMockito.when(SecurityContext.getInstance()).thenReturn(securityContext);
        PowerMockito.when(securityContext.getPrinicipal()).thenReturn(securityPrincipal);
        PowerMockito.when(securityPrincipal.getName()).thenReturn(null);
    }
}
