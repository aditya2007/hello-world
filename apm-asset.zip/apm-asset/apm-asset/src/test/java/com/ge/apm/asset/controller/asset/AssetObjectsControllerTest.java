/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.asset;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.support.SimpleCacheManager;

import com.ge.apm.asset.controller.AssetObjectsController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.model.Typed;
import com.ge.apm.asset.service.api.IAlmPersistenceService;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.service.impl.AssetService;
import com.ge.apm.asset.util.AssetCacheManager;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.exception.ForbiddenException;
import com.ge.stuf.security.context.SecurityContext;
import com.ge.stuf.security.context.SecurityPrincipal;

import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@PrepareForTest({ SecurityContext.class, IAssetService.class, SecurityPrincipal.class })
public class AssetObjectsControllerTest extends TestCase {

    private static final String uuid = "anyString";

    @Mock(name = "almPersistenceService")
    IAlmPersistenceService almPersistenceService;

    private AssetObjectsController assetObjectsController = new AssetObjectsController();

    @InjectMocks
    private AssetService assetService;

    private CacheManager cacheManager;

    private Cache cache;

    @Mock(name = "assetCacheManager")
    private AssetCacheManager assetCacheManager;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        cacheManager = spy(new SimpleCacheManager());
        assetCacheManager = spy(new AssetCacheManager());
        cache = spy(new ConcurrentMapCache(""));
        when(cacheManager.getCache(anyString())).thenReturn(cache);
        Mockito.doNothing().when(assetCacheManager).cacheObjects(anyList(), anyString());
        ReflectionUtils.setField(AssetCacheManager.class, assetCacheManager, "cacheManager", cacheManager);
        ReflectionUtils.setField(AssetObjectsController.class, assetObjectsController, "service", assetService);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void cascadeDeleteTest() {
        try {
            setupGetChildrenFromPersistence(
                Arrays.asList(readObjectsFromResourceFile("/output/assets/getChildren/childAssets.json", Asset.class)));
            assetObjectsController.delete(uuid, true, "Unit test");
        } catch (Exception ex) {
            ex.printStackTrace();
            Assert.fail();
        }
    }

    @SuppressWarnings("unchecked")
    @Test(expected = ForbiddenException.class)
    public void cascadeDeleteTestException() {
        when(almPersistenceService.getAssetByUUid(Matchers.anyString(), Matchers.anyString())).thenReturn(null);
        assetObjectsController.delete(uuid, true, "Unit test");
    }

    @SuppressWarnings("unchecked")
    @Test
    public void cascadeDeleteTestSecurityException() {
        setupGetChildrenFromPersistence(
            Arrays.asList(readObjectsFromResourceFile("/output/assets/getChildren/childAssets.json", Asset.class)));
        assetObjectsController.delete(uuid, true, "Unit test");
    }

    private <T extends Attributable> void setupGetChildrenFromPersistence(List<Asset> returnObjects) {
        when(almPersistenceService.getAssetByUUid(Matchers.anyString(), Matchers.anyString())).thenReturn(
            getMockAsset());
        Mockito.doReturn(returnObjects).when(almPersistenceService).deleteAssetRecursively(anyString(), anyString(),
            eq(Typed.class));
    }

    private <X> X[] readObjectsFromResourceFile(String filePath, Class<X> clazz) {
        try {
            return new ObjectMapper().reader(Array.newInstance(clazz, 0).getClass()).readValue(
                this.getClass().getResourceAsStream(filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Asset getMockAsset() {
        Asset asset = new Asset();
        asset.setName("as");
        asset.setUri("/assets/testuri");
        asset.setMeasurementTags(null);
        return asset;
    }
}