/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

import com.ge.apm.asset.controller.AssetController;
import com.ge.apm.asset.controller.AssetTypeController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.asset.mq.predicate.RetryPolicyPredicate;
import com.ge.apm.asset.mq.util.ReservedAttributesUtil;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.Error.ErrorType;
import com.ge.asset.commons.validator.ValidationFailedException;
import com.ge.asset.commons.validator.ValidationResult;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.anyVararg;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class DtoProcessorTest extends AbstractProcessorTest {

    @InjectMocks
    @Autowired
    @Spy
    DtoProcessor dtoProcessor;

    @Mock
    AssetTypeController assetTypeController;

    @Mock
    AssetController assetController;

    @Mock
    ReservedAttributesUtil reservedAttributesUtil;

    @Mock
    RetryPolicyPredicate retryPolicyPredicate;

    @Captor
    ArgumentCaptor<AssetType[]> assetTypeArgCaptor;

    @Captor
    ArgumentCaptor<List<Asset>> assetArgCaptor;

    String prefix = null;

    String sourceKey = null;

    String parent = null;

    String uuid = null;

    @Before
    public void setup() {
        super.setup();
        prefix = "/assetTypes";
        uuid = "uuid";
        sourceKey = "sourceKey";
        parent = "parent";
        super.headerMap.put(MessageConstants.ASSET_PREFIX, prefix);
        super.headerMap.put(MessageConstants.TASK_UUID, "abcdef");
        when(super.exchange.getOut()).thenReturn(super.message);

        when(super.controllerFactory.getController(prefix)).thenReturn(assetTypeController);
    }

    @Test(expected = ServiceException.class)
    public void preprocessWithoutData() throws Exception {
        dtoProcessor.dispatch(exchange);
    }

    @Test
    public void preProcessWithData() {
        doAnswer(a -> {
            AssetType[] assetTypes = new AssetType[1];
            assetTypes[0] = new AssetType();
            assetTypes[0].setSourceKey(sourceKey);
            return assetTypes;
        }).when(super.message).getBody(anyObject());
        dtoProcessor.preProcess(super.exchange);
    }

    @Test
    public void processWithValidData() throws Exception {
        doAnswer(a -> {
            AssetType[] assetTypes = new AssetType[1];
            assetTypes[0] = new AssetType();
            assetTypes[0].setSourceKey(sourceKey);
            assetTypes[0].setUri(prefix + "/" + sourceKey);
            return assetTypes;
        }).when(super.message).getBody();

        dtoProcessor.process(super.exchange);
    }

    @Test
    public void processClassificationWithParent() throws Exception {
        doAnswer(a -> {
            AssetType[] assetTypes = new AssetType[1];
            assetTypes[0] = new AssetType();
            assetTypes[0].setSourceKey(sourceKey);
            assetTypes[0].setUri(prefix + "/" + sourceKey);
            assetTypes[0].setParent(parent);
            return assetTypes;
        }).when(super.message).getBody();

        when(super.sourceKeyLookup.lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.EnterpriseTypes + "/" + parent)))
            .thenReturn(Prefixes.EnterpriseTypes + "/mockUri");
        when(super.sourceKeyLookup.lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.AssetTypes), eq(sourceKey)))
            .thenThrow(DependencyViolationException.class);
        doNothing().when(super.message).setBody(assetTypeArgCaptor.capture());
        dtoProcessor.process(super.exchange);
    }

    @Test(expected = DependencyViolationException.class)
    public void processInstanceWithParent() throws Exception {
        doAnswer(a -> {
            Asset[] assetTypes = new Asset[1];
            assetTypes[0] = new Asset();
            assetTypes[0].setSourceKey(sourceKey);
            assetTypes[0].setUri(prefix + "/" + sourceKey);
            assetTypes[0].setParent(parent);
            return assetTypes;
        }).when(super.message).getBody();

        when(super.sourceKeyLookup.lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.EnterpriseTypes + "/" + parent)))
            .thenReturn(Prefixes.EnterpriseTypes + "/mockUri");
        when(super.sourceKeyLookup.lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.AssetTypes), eq(sourceKey)))
            .thenThrow(DependencyViolationException.class);
        doNothing().when(super.message).setBody(assetTypeArgCaptor.capture());
        dtoProcessor.process(super.exchange);
    }

    @Test
    public void processWithoutParent() throws Exception {
        doAnswer(a -> {
            AssetType[] assetTypes = new AssetType[1];
            assetTypes[0] = new AssetType();
            assetTypes[0].setSourceKey(sourceKey);
            assetTypes[0].setUri(prefix + "/" + sourceKey);
            assetTypes[0].setParent(null);
            return assetTypes;
        }).when(super.message).getBody();

        when(super.sourceKeyLookup.lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.EnterpriseTypes + "/" + parent)))
            .thenReturn(Prefixes.EnterpriseTypes + "/mockUri");
        when(super.sourceKeyLookup.lookupObjectUriFor(eq(super.tenantId), eq(Prefixes.AssetTypes), eq(sourceKey)))
            .thenThrow(DependencyViolationException.class);
        doNothing().when(super.message).setBody(assetTypeArgCaptor.capture());
        dtoProcessor.process(super.exchange);
    }

    @Test(expected = ValidationFailedException.class)
    public void postProcess_ValidationFailureForReservedAttributes() throws Exception {
        doAnswer(a -> {
            ValidationResult validationResult = new ValidationResult();
            validationResult.setValid(false);
            validationResult.getErrors().add(new Error(ErrorType.ERROR, "E1001"));
            return validationResult;
        }).when(reservedAttributesUtil).getValidationResult(super.exchange);
        dtoProcessor.postProcess(super.exchange);
    }

    @Test
    public void saveDtos_ServiceException() {

        doThrow(ServiceException.class).when(assetTypeController).updateSingle(anyString(), anyObject());
        Map<Integer, PatchOperation[]> existingDtos = new HashMap<>();
        existingDtos.put(0, null);
        AssetType[] dtos = new AssetType[] { new AssetType() };
        dtos[0].setUri("mockUri");

        List<Exception> exceptions = dtoProcessor.saveDtos(this.prefix, dtos, new HashMap<>(), existingDtos, null, null,
            null);

        assertThat("No exceptions thrown", exceptions, notNullValue());
    }

    @Test
    public void saveDtos_RecoverableHttp() {

        doThrow(new HttpClientErrorException(HttpStatus.BAD_GATEWAY)).when(assetTypeController).updateSingle(
            anyString(), anyObject());
        when(retryPolicyPredicate.isRecoverableException(anyObject())).thenCallRealMethod();

        Map<Integer, PatchOperation[]> existingDtosMap = new HashMap<>();
        existingDtosMap.put(0, null);
        AssetType[] dtos = new AssetType[] { new AssetType() };
        dtos[0].setUri("mockUri");
        Map<Integer, ?> newDtosMap = new HashMap<>();
        List<?> retryDtos = new ArrayList<>();
        List<?> dependencyExceptions = new ArrayList<>();

        dtoProcessor.saveDtos(this.prefix, dtos, newDtosMap, existingDtosMap, retryDtos, dtos, dependencyExceptions);
        assertThat("retry dtos are null or empty", retryDtos.size(), is(1));
        assertThat("retry dtos are null or empty", dependencyExceptions.size(), is(1));
    }

    @Ignore
    @Test
    public void saveDtos_NonRecoverableHttp() {

        doThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND)).when(assetTypeController).updateSingle(anyString(),
            anyObject());
        when(retryPolicyPredicate.isRecoverableException(anyObject())).thenCallRealMethod();

        Map<Integer, PatchOperation[]> existingDtosMap = new HashMap<>();
        existingDtosMap.put(0, null);
        AssetType[] dtos = new AssetType[] { new AssetType() };
        dtos[0].setSourceKey("mockSourceKey");
        dtos[0].setUri("mockUri");
        Map<Integer, ?> newDtosMap = new HashMap<>();
        List<?> retryDtos = new ArrayList<>();
        List<?> dependencyExceptions = new ArrayList<>();

        List<Exception> exceptions = dtoProcessor.saveDtos(this.prefix, dtos, newDtosMap, existingDtosMap, retryDtos,
            dtos, dependencyExceptions);
        assertThat("no exception was thrown", exceptions, notNullValue());
        assertThat("exception list is empty", exceptions.isEmpty(), is(false));

        //verify(sourceKeyLookup).evictObjectUriFor(eq(super.tenantId), eq(this.prefix), eq("mockSourceKey"));
        verify(sourceKeyLookup).lookupObjectUriFor(eq(super.tenantId), eq(this.prefix + "/mockSourceKey"));
    }

    @Ignore
    @Test
    public void saveDtos_NonRecoverableHttp_DoCreate() {

        Map<Integer, PatchOperation[]> existingDtosMap = new HashMap<>();
        existingDtosMap.put(0, null);
        AssetType[] dtos = new AssetType[] { new AssetType() };
        dtos[0].setSourceKey("mockSourceKey");
        dtos[0].setUri("mockUri");
        Map<Integer, ?> newDtosMap = new HashMap<>();
        List<?> retryDtos = new ArrayList<>();
        List<?> dependencyExceptions = new ArrayList<>();

        doThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND)).when(assetTypeController).updateSingle(anyString(),
            anyObject());
        when(assetTypeController.create(Arrays.asList(assetTypeArgCaptor.capture()))).thenReturn(null);

        when(retryPolicyPredicate.isRecoverableException(anyObject())).thenCallRealMethod();

        dtoProcessor.saveDtos(this.prefix, dtos, newDtosMap, existingDtosMap, retryDtos, dtos, dependencyExceptions);

        //verify(sourceKeyLookup, times(1)).evictObjectUriFor(eq(super.tenantId), eq(this.prefix), eq("mockSourceKey"));
        assertThat("Create dtos are null or empty", newDtosMap.size(), is(0));
        verify(assetTypeController, times(1)).create(anyVararg());
        assertThat("new dtos not found", assetTypeArgCaptor.getValue(), notNullValue());
    }

    @Test
    public void saveDtos_RecoverableHttp_Create() {

        doThrow(new HttpClientErrorException(HttpStatus.BAD_GATEWAY)).when(assetTypeController).create(anyVararg());
        when(retryPolicyPredicate.isRecoverableException(anyObject())).thenCallRealMethod();

        Map<Integer, PatchOperation[]> existingDtosMap = new HashMap<>();
        existingDtosMap.put(0, null);
        AssetType[] dtos = new AssetType[] { new AssetType() };
        //        dtos[0].setUri("mockUri");
        Map<Integer, AssetType> newDtosMap = new HashMap<>();
        newDtosMap.put(0, dtos[0]);
        List<?> retryDtos = new ArrayList<>();
        List<?> dependencyExceptions = new ArrayList<>();

        dtoProcessor.saveDtos(this.prefix, dtos, newDtosMap, existingDtosMap, retryDtos, dtos, dependencyExceptions);
        assertThat("retry dtos are null or empty", retryDtos.size(), is(1));
        assertThat("retry dtos are null or empty", dependencyExceptions.size(), is(1));
    }

    @Test
    public void test_saveDtos_forAssetsInDecommissionedState() {
        Asset asset = new Asset();
        Map<String, Object> reservedAttributes = new HashMap<>();
        Map<String, Object> keyValue = new HashMap<>();
        keyValue.put("key", "10");
        reservedAttributes.put("state", keyValue);
        asset.setReservedAttributes(reservedAttributes);
        asset.setSourceKey("TestSourceKey");
        Map<Integer, Asset> newDtosMap = new HashMap<>();
        newDtosMap.put(0, asset);
        List<?> retryDtos = new ArrayList<>();
        List<?> exceptions = new ArrayList<>();
        Asset[] dtos = new Asset[] { new Asset() };
        exceptions = dtoProcessor.saveDtos(Prefixes.Assets, dtos, newDtosMap, new HashMap<>(), retryDtos, dtos,
            exceptions);
        assertEquals(1, exceptions.size());
        assertTrue(exceptions.get(0) instanceof ServiceException);
        assertTrue(((ServiceException) exceptions.get(0)).getCode()
            .compareTo(ErrorConstants.ASSET_WITH_DECOMMISSIONED_STATE_IS_NOT_ALLOWED) == 0);
    }

    @Test
    public void test_saveDtos_forTwoAssets_withOneAssetsInDecommissionedState() {
        Asset asset = new Asset();
        Map<String, Object> reservedAttributes = new HashMap<>();
        Map<String, Object> keyValue = new HashMap<>();
        keyValue.put("key", "10");
        reservedAttributes.put("state", keyValue);
        asset.setReservedAttributes(reservedAttributes);
        asset.setSourceKey("TestSourceKey");
        Map<Integer, Asset> newDtosMap = new HashMap<>();
        newDtosMap.put(0, asset);

        asset = new Asset();
        reservedAttributes = new HashMap<>();
        keyValue = new HashMap<>();
        keyValue.put("key", "03");
        reservedAttributes.put("state", keyValue);
        asset.setReservedAttributes(reservedAttributes);
        asset.setSourceKey("TestSourceKey2");
        newDtosMap.put(1, asset);

        doNothing().when(dtoProcessor).saveDto(eq(Prefixes.Assets), assetArgCaptor.capture());

        List<?> retryDtos = new ArrayList<>();
        List<?> exceptions = new ArrayList<>();
        Asset[] dtos = new Asset[] { new Asset() };
        exceptions = dtoProcessor.saveDtos(Prefixes.Assets, dtos, newDtosMap, new HashMap<>(), retryDtos, dtos,
            exceptions);
        assertEquals(1, exceptions.size());
        assertTrue(exceptions.get(0) instanceof ServiceException);
        assertTrue(((ServiceException) exceptions.get(0)).getCode()
            .compareTo(ErrorConstants.ASSET_WITH_DECOMMISSIONED_STATE_IS_NOT_ALLOWED) == 0);

        assertTrue(assetArgCaptor.getValue().size() == 1);
    }
}
