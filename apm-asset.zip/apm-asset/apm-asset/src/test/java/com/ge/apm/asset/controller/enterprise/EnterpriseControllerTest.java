/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.enterprise;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.codec.binary.Base64;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

import com.ge.apm.asset.api.crud.ICrudControllerTest;
import com.ge.apm.asset.api.hierarchy.IHierarchyControllerTest;
import com.ge.apm.asset.api.tag.ITagControllerTest;
import com.ge.apm.asset.controller.EnterpriseController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.MeasurementTagLookup;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;
import com.ge.stuf.security.context.SecurityContext;

import static org.apache.commons.codec.binary.Hex.encodeHexString;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class, SecurityContext.class })
public class EnterpriseControllerTest extends AbstractEnterpriseControllerTest
    implements ICrudControllerTest<Enterprise, IAssetService, EnterpriseController>,
    IHierarchyControllerTest<Enterprise, IAssetService, EnterpriseController>,
    ITagControllerTest<Enterprise, IAssetService, EnterpriseController> {

    @Test
    public void getChildren() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=/enterprises/bb571726-c1a3-4610-99de-435ab7f74000");
        urlVariables.put("pageSize", 250);

        List<Hierarchical> childInstances = new ArrayList<>();
        childInstances.addAll(
            Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/enterprises.json", Enterprise.class)));
        childInstances.addAll(Arrays.asList(readObjectsFromResourceFile(getPredixPath() + "/sites.json", Site.class)));

        setupGetChildrenFromPersistence(null, childInstances.toArray(new Hierarchical[0]),
            Prefixes.uri(Prefixes.Enterprises, UUID1), null);

        Hierarchical[] fetchedChildren = getController().getChildren(UUID1, AssetComponentResolver.ATTRIBUTES, null,
            null, false, 250, null);
        List<Hierarchical> sortedFetchedChildren = Arrays.asList(fetchedChildren).stream().sorted(
            (node1, node2) -> node1.getName().compareTo(node2.getName())).collect(Collectors.toList());
        List<Hierarchical> expectedChildren = new ArrayList<>();
        expectedChildren.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/enterprises.json", Enterprise.class)));
        expectedChildren.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/sites.json", Site.class)));
        List<Hierarchical> sortedList = expectedChildren.stream().sorted(
            (node1, node2) -> node1.getName().compareTo(node2.getName())).collect(Collectors.toList());
        Assert.assertArrayEquals(sortedList.toArray(new Hierarchical[expectedChildren.size()]),
            sortedFetchedChildren.toArray(new Hierarchical[sortedFetchedChildren.size()]));
    }

    @Test
    public void getChildrenByType() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=/enterprises/bb571726-c1a3-4610-99de-435ab7f74000");
        urlVariables.put("pageSize", 250);
        urlVariables.put("type", "/enterprises");

        Enterprise[] childInstances = readObjectsFromResourceFile(getPredixPath() + "/enterprises.json",
            Enterprise.class);

        setupGetChildrenFromPersistence(Prefixes.Enterprises, childInstances, Prefixes.uri(Prefixes.Enterprises, UUID1),
            Enterprise.class);

        Hierarchical[] fetchedChildren = getController().getChildren(UUID1, AssetComponentResolver.ATTRIBUTES, null,
            "/enterprises", false, 250, null);
        List<Hierarchical> sortedFetchedChildren = Arrays.asList(fetchedChildren).stream().sorted(
            (node1, node2) -> node1.getName().compareTo(node2.getName())).collect(Collectors.toList());
        List<Hierarchical> expectedChildren = new ArrayList<>();
        expectedChildren.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/enterprises.json", Enterprise.class)));
        List<Hierarchical> sortedList = expectedChildren.stream().sorted(
            (node1, node2) -> node1.getName().compareTo(node2.getName())).collect(Collectors.toList());
        Assert.assertArrayEquals(sortedList.toArray(new Hierarchical[expectedChildren.size()]),
            sortedFetchedChildren.toArray(new Hierarchical[sortedFetchedChildren.size()]));
    }

    @Test
    public void getSites() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=/enterprises/bb571726-c1a3-4610-99de-435ab7f74000");
        urlVariables.put("pageSize", 250);

        setupGetChildrenFromPersistence(Prefixes.Enterprises,
            readObjectsFromResourceFile(getPredixPath() + "/enterprises.json", Enterprise.class),
            Prefixes.uri(Prefixes.Enterprises, UUID1), Enterprise.class);

        setupGetChildrenFromPersistence(Prefixes.Sites,
            readObjectsFromResourceFile(getPredixPath() + "/sites.json", Site.class),
            Prefixes.uri(Prefixes.Enterprises, UUID1), Site.class);

        Hierarchical[] fetchedSites = getController().getSites(UUID1, AssetComponentResolver.ATTRIBUTES, null, false,
            null);
        Site[] expectedSites = readObjectsFromResourceFile(getOutputPath() + "/sites.json", Site.class);
        Assert.assertArrayEquals(expectedSites, fetchedSites);
    }

    @Test
    public void getSitesByName() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "name=*Sample*:parent=/enterprises/bb571726-c1a3-4610-99de-435ab7f74000");
        urlVariables.put("pageSize", 250);

        setupGetChildrenFromPersistence(Prefixes.Enterprises,
            readObjectsFromResourceFile(getPredixPath() + "/enterprises.json", Enterprise.class),
            Prefixes.uri(Prefixes.Enterprises, UUID1), Enterprise.class);

        setupGetChildrenFromPersistence(Prefixes.Sites,
            readObjectsFromResourceFile(getPredixPath() + "/sites.json", Site.class),
            Prefixes.uri(Prefixes.Enterprises, UUID1), Site.class);

        Hierarchical[] fetchedSites = getController().getSites(UUID1, AssetComponentResolver.ATTRIBUTES, "*Sample*",
            false, null);
        Site[] expectedSites = readObjectsFromResourceFile(getOutputPath() + "/sites.json", Site.class);
        Assert.assertArrayEquals(expectedSites, fetchedSites);
    }

    @Test
    public void getSitesDeepSearch() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=/enterprises/bb571726-c1a3-4610-99de-435ab7f74000");
        urlVariables.put("pageSize", 250);

        Map<String, Object> urlVariables2 = new HashMap<>();
        urlVariables2.put("filter", "((uri=/enterprises/bb571726-c1a3-4610-99de-435ab7f74000)<parent[t5])");
        urlVariables2.put("pageSize", 250);

        Map<String, Object> urlVariables3 = new HashMap<>();
        urlVariables3.put("filter", "((uri=/enterprises/bb571726-c1a3-4610-99de-435ab7f74000)<parent[t10])");
        urlVariables3.put("pageSize", 250);

        setupGetChildrenFromPersistence(Prefixes.Enterprises,
            readObjectsFromResourceFile(getPredixPath() + "/enterprises.json", Enterprise.class),
            Prefixes.uri(Prefixes.Enterprises, UUID1), Enterprise.class);

        setupGetChildrenFromPersistence(Prefixes.Sites,
            readObjectsFromResourceFile(getPredixPath() + "/sites.json", Site.class),
            Prefixes.uri(Prefixes.Enterprises, UUID1), Site.class);

        Hierarchical[] fetchedChildren = getController().getSites(UUID1, AssetComponentResolver.ATTRIBUTES, null, true,
            null);
        List<Hierarchical> expectedChildren = new ArrayList<>();
        expectedChildren.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/enterprises.json", Enterprise.class)));
        expectedChildren.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/sites.json", Site.class)));
        expectedChildren.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/segments.json", Segment.class)));
        expectedChildren.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/assets.json", Asset.class)));
        expectedChildren.sort(byName);

        List<Hierarchical> expected = expectedChildren.stream().filter(child -> child.getUri().startsWith("/sites/"))
            .collect(Collectors.toList());
        Assert.assertArrayEquals(expected.toArray(new Hierarchical[expected.size()]), fetchedChildren);
    }

    @Override
    @Test
    public void associateTags() throws IOException {
        Map<String, Object> tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 1);
        MeasurementTagType[] tagTypes1 = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag1.json",
            MeasurementTagType.class);
        MeasurementTagType[] tagTypes2 = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag2.json",
            MeasurementTagType.class);

        Map<String, Object> tagLookupUrlVariables = new HashMap<>();
        tagLookupUrlVariables.put("pageSize", 1);
        String encodedUri = Base64.encodeBase64URLSafeString(Prefixes.uri(getPrefix(), UUID1).getBytes());

        Map<String, Object> objectUrlVariables = new HashMap<>();
        objectUrlVariables.put("pageSize", 1);

        tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 250);

        Map<String, Object> tagUrlVariables = new HashMap<>();
        tagUrlVariables.put("pageSize", 250);
        tagUrlVariables.put("filter", "sourceKey=Tag1");
        MeasurementTagLookup expectedTagLookup = new MeasurementTagLookup();
        expectedTagLookup.setUri(Prefixes.uri(Prefixes.MeasurementTagLookups, encodedUri));
        expectedTagLookup = new MeasurementTagLookup();
        expectedTagLookup.setUri(Prefixes.uri(Prefixes.MeasurementTagLookups, encodedUri));
        expectedTagLookup.getTags().put(encodeHexString("Tag1".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID1));

        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/object.json", getObjectClass())[0], false);

        setupGetBySourceKeysFromPersistence(new String[] { "Tag1" },
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tags_2.json", MeasurementTag.class),
            Prefixes.MeasurementTags, MeasurementTag.class);

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag1.json", MeasurementTagType.class)[0]);

        setupUpdateTagsToPersistence();

        MeasurementTag[] tags = readObjectsFromResourceFile(getInputPath() + "/tags_2.json", MeasurementTag.class);
        getController().associateTags(UUID1, tags);
    }

    @Override
    @Test
    public void associateTags_SomeExisting() throws IOException {
        Map<String, Object> tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 1);

        MeasurementTagType[] tagTypes1 = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag1.json",
            MeasurementTagType.class);
        MeasurementTagType[] tagTypes2 = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag2.json",
            MeasurementTagType.class);

        Map<String, Object> tagLookupUrlVariables = new HashMap<>();
        tagLookupUrlVariables.put("pageSize", 1);
        String encodedUri = Base64.encodeBase64URLSafeString(Prefixes.uri(getPrefix(), UUID1).getBytes());
        MeasurementTagLookup existingTagLookup = new MeasurementTagLookup();
        existingTagLookup.setUri(Prefixes.uri(Prefixes.MeasurementTagLookups, encodedUri));
        existingTagLookup.getTags().put(encodeHexString("Tag2".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID2));

        Map<String, Object> objectUrlVariables = new HashMap<>();
        objectUrlVariables.put("pageSize", 1);

        MeasurementTag[] createdTags = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tags.json",
            MeasurementTag.class);

        tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 250);

        Map<String, Object> tagUrlVariables = new HashMap<>();
        tagUrlVariables.put("pageSize", 250);
        tagUrlVariables.put("filter", "sourceKey=Tag1");

        MeasurementTagLookup expectedTagLookup = new MeasurementTagLookup();
        expectedTagLookup.setUri(Prefixes.uri(Prefixes.MeasurementTagLookups, encodedUri));
        expectedTagLookup.getTags().put(encodeHexString("Tag2".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID2));
        expectedTagLookup.getTags().put(encodeHexString("Tag1".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID1));

        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/object.json", getObjectClass())[0], false);

        setupGetBySourceKeysFromPersistence(new String[] { "Tag1", "Tag2" },
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tags_2.json", MeasurementTag.class),
            Prefixes.MeasurementTags, MeasurementTag.class);

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag1.json", MeasurementTagType.class)[0]);

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID2),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag2.json", MeasurementTagType.class)[0]);

        setupUpdateTagsToPersistence();

        MeasurementTag[] tags = readObjectsFromResourceFile(getInputPath() + "/tags.json", MeasurementTag.class);
        getController().associateTags(UUID1, tags);
    }

    @Test(expected = BadRequestException.class)
    public void associateExistingTags_ToDifferentAsset() throws IOException {
        Map<String, Object> tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 1);

        Map<String, Object> tagLookupUrlVariables = new HashMap<>();
        tagLookupUrlVariables.put("pageSize", 1);
        String encodedUri = Base64.encodeBase64URLSafeString(Prefixes.uri(getPrefix(), UUID1).getBytes());
        MeasurementTagLookup existingTagLookup = new MeasurementTagLookup();
        existingTagLookup.setUri(Prefixes.uri(Prefixes.MeasurementTagLookups, encodedUri));
        existingTagLookup.getTags().put(encodeHexString("Tag2".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID2));

        Map<String, Object> objectUrlVariables = new HashMap<>();
        objectUrlVariables.put("pageSize", 1);

        MeasurementTag[] createdTags = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tags.json",
            MeasurementTag.class);

        tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 250);

        Map<String, Object> tagUrlVariables = new HashMap<>();
        tagUrlVariables.put("pageSize", 250);
        tagUrlVariables.put("filter", "sourceKey=Tag1");

        MeasurementTagLookup expectedTagLookup = new MeasurementTagLookup();
        expectedTagLookup.setUri(Prefixes.uri(Prefixes.MeasurementTagLookups, encodedUri));
        expectedTagLookup.getTags().put(encodeHexString("Tag1".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID1));
        expectedTagLookup.getTags().put(encodeHexString("Tag2".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID2));
        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/object.json", getObjectClass())[0], false);

        setupGetBySourceKeysFromPersistence(new String[] { "Tag1", "Tag2" },
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tagWithTag1SourceKey.json",
                MeasurementTag.class), Prefixes.MeasurementTags, MeasurementTag.class);

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag1.json", MeasurementTagType.class)[0]);

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID2),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag2.json", MeasurementTagType.class)[0]);

        setupUpdateTagsToPersistence();

        MeasurementTag[] tags = readObjectsFromResourceFile(getInputPath() + "/tags.json", MeasurementTag.class);
        getController().associateTags(UUID1, tags);
    }

    @Test(expected = NotFoundException.class)
    public void getSites_Error() {
        throwExceptionForGetChildrenFromPersistence(new HttpClientErrorException(HttpStatus.NOT_FOUND),
            Enterprise.class);
        throwExceptionForGetChildrenFromPersistence(new HttpClientErrorException(HttpStatus.NOT_FOUND), Site.class);
        getController().getSites(UUID1, AssetComponentResolver.ATTRIBUTES, null, false, null);
    }

    //    @Test(expected = ServiceException.class)
    //    public void create_deletesObjectFromPredixAfterResourceGraphError() throws IOException {
    //        Enterprise[] objects = readObjectsFromResourceFile(getInputPath() + "/create.json",
    // getObjectClass());
    //        Enterprise[] predixObjects = readObjectsFromResourceFile(getPredixPath() + "/create
    // .json", getObjectClass());
    //        setupForType(objects[0]);
    //
    //        Map<String, Object> urlVariables = new HashMap<>();
    //        urlVariables.put("pageSize", 250);
    //        urlVariables.put("filter", "sourceKey="+objects[0].getSourceKey());
    //        setupGETFor(getPredixBaseUrl() + getPrefix(), null, urlVariables);
    //
    //        setupPOSTFor(getPredixBaseUrl() + getPrefix(), predixObjects);
    //        throwExceptionForAcsCallsForCreate();
    //        try {
    //            getController().create(objects);
    //            Assert.fail();
    //        } catch (ServiceException se) {
    //            verifyAcsCalls(predixObjects);
    //            verifyPOSTCalls(getPredixBaseUrl() + getPrefix());
    //            for (int i = 0; i < objects.length; i++) {
    //                verifyDELETECalled(getPredixBaseUrl() + objects[i].getUri());
    //            }
    //            throw se;
    //        }
    //    }

    @Test(expected = BadRequestException.class)
    public void createWithInvalidTypeInRequest() throws IOException {
        Enterprise[] objects = readObjectsFromResourceFile(getInputPath() + "/createWithInvalidTypeInRequest.json",
            getObjectClass());
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);

        getController().create(Arrays.asList(objects));
    }

    @Test(expected = BadRequestException.class)
    public void testCreateWithInvalidPayload() throws IOException {
        Enterprise[] objects = readObjectsFromResourceFile(getInputPath() + "/create_invalid.json", getObjectClass());
        getController().create(Arrays.asList(objects));
    }

    @Test(expected = BadRequestException.class)
    public void updateWithInvalidType() throws IOException {
        PatchOperation[] objects = readObjectsFromResourceFile(getInputPath() + "/updateWithInvalidType.json",
            PatchOperation.class);
        Enterprise[] predixObject = readObjectsFromResourceFile(getPredixPath() + "/getSingleWithAttributes.json",
            getObjectClass());
        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1), predixObject[0], false);
        getController().updateSingle(UUID1, Arrays.asList(objects));
    }

    @Override
    @Test(expected = Exception.class)
    public void delete() throws IOException {
        getController().delete(UUID1);
    }
}
