/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.api.base;

import java.io.IOException;
import java.text.ParseException;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.fasterxml.jackson.databind.ObjectReader;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.web.client.RestTemplate;

import com.ge.apm.alm.persistence.jpa.AssetPersistencyServiceImpl;
import com.ge.apm.alm.persistence.jpa.AssetTypePersistencyServiceImpl;
import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.UnitGroup;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAlmPersistenceService;
import com.ge.apm.asset.service.component.AssetConfigService;
import com.ge.apm.asset.service.component.AssetReservedAttributeService;
import com.ge.apm.asset.service.impl.AssetTypeService;
import com.ge.apm.asset.service.impl.UomService;
import com.ge.apm.asset.service.persistence.AlmAssetPlaceholderPersistenceService;
import com.ge.apm.asset.service.persistence.AlmPersistenceService;
import com.ge.apm.asset.service.persistence.AlmTemplatePersistenceService;
import com.ge.apm.asset.util.AssetCacheManager;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.config.IServiceInfoProvider;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.support.RequestContext;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

//TODO Revist this persistence dependency
//import com.ge.apm.asset.tag.persistence.repository.IReservedAttributeRepository;

@PrepareForTest({ RequestContext.class })
public abstract class AbstractControllerTest<C, T> implements IBaseControllerTest<C, T> {

    private static final ObjectReader UNIT_GRPS_READER = MAPPER.reader(UnitGroup[].class);

    private static final String RESERVED_ATTRIBUTES_CONST = "/reservedAttributes";

    private static final ObjectReader RESERVED_ATTRIBUTE_READER = MAPPER.reader(ReservedAttributeConfig[].class);

    protected Comparator<Hierarchical> byName = (e1, e2) -> e1.getName().compareTo(e2.getName());

    protected RestTemplate restTemplate;

    protected AssetConfigService assetConfigService;

    protected AssetReservedAttributeService assetReservedAttributeService;

    protected AssetCacheManager assetCacheManager;

    protected AlmPersistenceService almPersistenceService;

    @Mock
    protected AssetTypePersistencyServiceImpl assetTypePersistencyService;

    @Mock
    protected AssetPersistencyServiceImpl assetPersistencyService;

    @Mock
    protected AlmAssetPlaceholderPersistenceService almAssetPlaceholderPersistenceService;

    @Mock
    protected AlmTemplatePersistenceService almTemplatePersistenceService;

    protected CacheManager cacheManager;

    protected Cache cache;

    @Mock
    protected UomService uomService;

    protected AssetTypeService assetTypeService;

    @Mock
    protected IServiceInfoProvider serviceInfoProvider;

    protected List<String> getUris;

    protected List<String> postUris;

    protected List<String> patchUris;

    @Captor
    ArgumentCaptor<QueryPredicate> predicateArgumentCaptor;

    @Override
    public <T extends Attributable> void setupGetBySourceKeyFromPersistence(String sourceKey, T returnObject,
        Class<T> objectClass) {
        Mockito.doReturn(returnObject).when(almPersistenceService).getBySourceKey(anyString(), anyString(),
            eq(getPrefix()), eq(objectClass), eq(sourceKey));
    }

    @Override
    public <T extends Attributable> void setupGetBySourceKeysFromPersistence(String[] sourceKeys, T[] returnObject,
        String prefix, Class<T> objectClass) {
        Mockito.doReturn(returnObject).when(almPersistenceService).getBySourceKeys(anyString(), eq(prefix),
            eq(objectClass), eq(sourceKeys));
    }

    @Override
    public <T extends Attributable> void setupCreateToPersistence(T[] objects) {
        Mockito.doNothing().when(almPersistenceService).createInstance(anyString(), eq(objects));
    }

    @Override
    public <T extends Attributable> void setupCreateTypeToPersistence(T[] objects) {
        Mockito.doNothing().when(almPersistenceService).createType(anyString(), eq(objects));
    }

    @Override
    public <T extends Attributable> void setupUpdateTypeToPersistence(String uri, PatchOperation... patchOperations) {
        Mockito.doNothing().when(almPersistenceService).updateType(anyString(), eq(uri), eq(patchOperations));
    }

    @Override
    public <T extends Attributable> void setupUpdateInstanceToPersistence(String uri,
        PatchOperation... patchOperations) {
        Mockito.doNothing().when(almPersistenceService).updateInstance(anyString(), eq(uri), eq(patchOperations));
    }

    @Override
    public <T extends Attributable> void setupUpdateTagsToPersistence() {
        Mockito.doNothing().when(almPersistenceService).saveTags(anyString(), any(), any(), any());
    }

    @Override
    public <T extends Attributable> void setupGetFromPersistence(String prefix, T[] returnObjects,
        Class<T> objectClass) {
        Mockito.doReturn(returnObjects).when(almPersistenceService).findAllByPrefix(anyString(), eq(prefix),
            predicateArgumentCaptor.capture(), eq(objectClass), anyBoolean(), anyBoolean());
    }

    @Override
    public <T extends Attributable> void setupGetFromPersistence(T[] returnObjects, Class<T> objectClass) {
        setupGetFromPersistence(getPrefix(), returnObjects, objectClass);
    }

    @Override
    public <T extends Attributable> void setupGetFromPersistence(Map<String, ?> urlVariables, T[] returnObjects,
        QueryPredicate mockQueryPredicate, Class<T> objectClass) {
        if (urlVariables != null) {
            if (urlVariables.containsKey("pageSize")) {
                mockQueryPredicate.setPageSize((Integer) urlVariables.get("pageSize"));
            }
            mockQueryPredicate.setName(Optional.ofNullable((String) urlVariables.get("name")));
            mockQueryPredicate.setDescription(Optional.ofNullable((String) urlVariables.get("description")));
            mockQueryPredicate.setSourceKey(Optional.ofNullable((String) urlVariables.get("sourceKey")));
            mockQueryPredicate.setTypeUri(Optional.ofNullable((String) urlVariables.get("type")));
            mockQueryPredicate.setAttributesKeyValue(Optional.ofNullable((Map) urlVariables.get("attributes")));
        }

        setupGetFromPersistence(returnObjects, objectClass);
    }

    @Override
    public <T extends Attributable> void setupGetChildrenFromPersistence(String prefix, T[] returnObjects,
        String parentUri, QueryPredicate queryPredicate, Class<T> objectClass) {
        Mockito.doReturn(returnObjects).when(almPersistenceService).getChildrenInstances(anyString(), eq(prefix),
            eq(parentUri), eq(objectClass), predicateArgumentCaptor.capture(), anyBoolean(), anyBoolean());
    }

    @Override
    public <T extends Attributable> void setupGetChildrenTypeFromPersistence(String parentUri, T[] returnObjects) {
        Mockito.doReturn(returnObjects).when(almPersistenceService).getChildrenTypes(anyString(), eq(parentUri),
            predicateArgumentCaptor.capture(), any(), anyBoolean());
    }

    @Override
    public <T extends Attributable> void setupGetChildrenFromPersistence(String prefix, T[] returnObjects,
        String parentUri, Class<T> objectClass) {
        Mockito.doReturn(returnObjects).when(almPersistenceService).getChildrenInstances(anyString(), eq(prefix),
            eq(parentUri), eq(objectClass), predicateArgumentCaptor.capture(), anyBoolean(), anyBoolean());
    }

    @Override
    public <T extends Attributable> void setupGetByTypeUriFromPersistence(String uri, T returnObject) {
        Mockito.doReturn(returnObject).when(almPersistenceService).getTypeByUri(anyString(), eq(uri));
        Mockito.doReturn(returnObject).when(almPersistenceService).getTypeByUri(anyString(), eq(uri), any());
    }

    @Override
    public <T extends Attributable> void setupGetGroupMembersFromPersistence(String uri, T[] returnObjects) {
        Mockito.doReturn(returnObjects).when(almPersistenceService).getMembersDetailsOfGroup(anyString(), eq(uri));
    }

    @Override
    public void setupAssociateGroupMembersFromPersistence(String prefix) {
        Mockito.doNothing().when(almPersistenceService).associateMembersToGroup(anyString(), eq(prefix), anyObject());
    }

    @Override
    public void setupIsGroupMemberFromPersistence(String uri, Boolean returnValue) {
        Mockito.doReturn(returnValue).when(almPersistenceService).isMemberPartOfAGroup(anyString(), eq(uri),
            anyObject());
    }

    @Override
    public <T extends Attributable> void setupGetTagsFromPersistence(String monitoredUri, T[] returnObject) {
        Mockito.doReturn(returnObject).when(almPersistenceService).getTags(anyString(), eq(monitoredUri),
            predicateArgumentCaptor.capture(), anyBoolean());
    }

    @Override
    public <T extends Attributable> void setupGetTagDetailsFromPersistence(String tagUri, T returnObject) {
        Mockito.doReturn(returnObject).when(almPersistenceService).getTagDetails(anyString(), eq(tagUri), anyBoolean());
    }

    @Override
    public <T extends Attributable> void setupDeleteFromPersistence(String uri, Class<T> objectClass) {
        Mockito.doNothing().when(almPersistenceService).delete(anyString(), eq(uri), eq(objectClass));
    }

    @Override
    public void setupDeleteTagsFromPersistence(String uri, String[] tagUris) {
        Mockito.doNothing().when(almPersistenceService).deleteTags(anyString(), eq(uri), eq(tagUris));
    }

    @Override
    public void verifyQueryPredicateFromPersistenceCall(QueryPredicate predicate) {
        QueryPredicate calledPredicate = predicateArgumentCaptor.getValue();
        Assert.assertEquals("Predicate sent to persistence don't match", calledPredicate, predicate);
    }

    @Override
    public <T extends Attributable> void setupGetByInstanceUriFromPersistence(String uri, T returnObject,
        boolean ignoreAccessibleResourcesFilter) {
        Mockito.doReturn(returnObject).when(almPersistenceService).getInstanceByUri(anyString(), eq(uri),
            eq(ignoreAccessibleResourcesFilter));
        Mockito.doReturn(returnObject).when(almPersistenceService).getAssetInstanceByUri(anyString(), eq(uri),
            eq(ignoreAccessibleResourcesFilter), any(), anyBoolean());
    }

    public RestTemplate getRestTemplate() {
        return restTemplate;
    }

    @Test
    public void emptyTestWithoutWhichTheInterfaceTestsAreNotPicked() {
        //TODO: review needed
    }

    public AlmPersistenceService getPersistenceService() {
        return almPersistenceService;
    }

    protected void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        getUris = new LinkedList<>();
        postUris = new LinkedList<>();
        patchUris = new LinkedList<>();

        restTemplate = spy(new RestTemplate());
        uomService = spy(new UomService());
        assetTypeService = spy(new AssetTypeService());
        assetConfigService = spy(new AssetConfigService());
        almPersistenceService = spy(new AlmPersistenceService());
        almAssetPlaceholderPersistenceService = spy(new AlmAssetPlaceholderPersistenceService());
        assetReservedAttributeService = spy(new AssetReservedAttributeService());

        MockitoAnnotations.initMocks(this);

        PowerMockito.mockStatic(RequestContext.class);
        when(RequestContext.get(RequestContext.TENANT_UUID, String.class)).thenReturn(getTenantHeader());

        mockIdGenerator();
        mockDateTimeUtil();

        cacheManager = spy(new SimpleCacheManager());
        assetCacheManager = spy(new AssetCacheManager());
        cache = spy(new ConcurrentMapCache(""));
        when(cacheManager.getCache(anyString())).thenReturn(cache);
        Mockito.doNothing().when(assetCacheManager).cacheObjects(anyList(), anyString());
        ReflectionUtils.setField(AssetCacheManager.class, assetCacheManager, "cacheManager", cacheManager);

        when(serviceInfoProvider.getZoneHeaderName()).thenReturn("x-tenant");
        when(serviceInfoProvider.getZoneHeaderValue()).thenReturn(getTenantHeader());

        when(RequestContext.get(IAlmPersistenceService.ACCESSIBLE_RESOURCES, String[].class)).thenReturn(
            new String[] { "*" });

        when(uomService.getPossibleValues((RequestContext.get(RequestContext.TENANT_UUID, String.class)))).thenReturn(
            getUnitGroups());

        Mockito.doReturn(getReservedAttributeConfig("/assets")).when(assetReservedAttributeService)
            .getReservedAttributeConfigs("/assets");
        Mockito.doReturn(getReservedAttributeConfig("/assetTypes")).when(assetReservedAttributeService)
            .getReservedAttributeConfigs("/assetTypes");
        Mockito.doReturn(getReservedAttributeConfig("/tags")).when(assetReservedAttributeService)
            .getReservedAttributeConfigs("/tags");
        Mockito.doReturn(getReservedAttributeConfig("/tagTypes")).when(assetReservedAttributeService)
            .getReservedAttributeConfigs("/tagTypes");
        Mockito.doReturn(getReservedAttributeConfig("/assetTemplates")).when(assetReservedAttributeService)
            .getReservedAttributeConfigs("/assetTemplates");
        Mockito.doReturn(getReservedAttributeConfig("/assetTemplatePlaceholders")).when(assetReservedAttributeService)
            .getReservedAttributeConfigs("/assetTemplatePlaceholders");

        Mockito.doReturn(getReservedAttributeConfig("/enterprises")).when(assetReservedAttributeService)
            .getReservedAttributeConfigs("/enterprises");
        Mockito.doReturn(getReservedAttributeConfig("/sites")).when(assetReservedAttributeService)
            .getReservedAttributeConfigs("/sites");
        Mockito.doReturn(getReservedAttributeConfig("/segments")).when(assetReservedAttributeService)
            .getReservedAttributeConfigs("/segments");

        Mockito.doReturn(getReservedAttributeConfig("/networks")).when(assetReservedAttributeService)
            .getReservedAttributeConfigs("/networks");
        Mockito.doReturn(getReservedAttributeConfig("/networks")).when(assetReservedAttributeService)
            .getReservedAttributeConfigs("/edges");

        ReflectionUtils.setField(AssetTypeService.class, assetTypeService, "almPersistenceService",
            almPersistenceService);
        ReflectionUtils.setField(AlmPersistenceService.class, almPersistenceService, "assetTypePersistencyService",
            assetTypePersistencyService);
        ReflectionUtils.setField(AlmPersistenceService.class, almPersistenceService, "assetPersistencyService",
            assetPersistencyService);

        ReflectionUtils.setField(AlmPersistenceService.class, almPersistenceService,
            "almAssetPlaceholderPersistenceService", almAssetPlaceholderPersistenceService);
        ReflectionUtils.setField(AlmPersistenceService.class, almPersistenceService, "assetCacheManager",
            assetCacheManager);
        ReflectionUtils.setField(AssetConfigService.class, assetConfigService, "uomService", uomService);
        ReflectionUtils.setField(AssetConfigService.class, assetConfigService, "assetReservedAttributeService",
            assetReservedAttributeService);
    }

    private UnitGroup[] getUnitGroups() {
        UnitGroup[] unitGroups = new UnitGroup[0];
        try {
            unitGroups = UNIT_GRPS_READER.readValue(
                this.getClass().getResourceAsStream("/reservedAttributes/Uom.json"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return unitGroups;
    }

    protected ReservedAttributeConfig[] getReservedAttributeConfig(String prefix) {
        ReservedAttributeConfig[] reservedAttributeConfig = null;
        try {
            reservedAttributeConfig = RESERVED_ATTRIBUTE_READER.readValue(
                this.getClass().getResourceAsStream(RESERVED_ATTRIBUTES_CONST + prefix + ".json"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return reservedAttributeConfig;
    }
}