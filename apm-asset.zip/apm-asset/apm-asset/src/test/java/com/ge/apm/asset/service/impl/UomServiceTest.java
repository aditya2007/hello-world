/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.service.impl;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Map;
import java.util.function.Supplier;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.ge.apm.asset.filter.model.UomInfoProvider;
import com.ge.apm.asset.model.UnitGroup;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.support.RequestContext;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;

/**
 * Created with IntelliJ IDEA.
 * User: 212402415
 * Date: 9/29/16
 * Time: 9:21 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(UomService.class)
public class UomServiceTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Mock
    protected UomInfoProvider serviceInfoProvider;

    protected UomService uomService;

    @Mock
    protected RestTemplate restTemplate;

    @Mock
    private com.ge.apm.commons.logging.Tracer tracer;

    @Before
    public void setUp() throws Exception {

        restTemplate = PowerMockito.spy(new RestTemplate());
        uomService = PowerMockito.spy(new UomService());
        MockitoAnnotations.initMocks(this);

        Mockito.when(serviceInfoProvider.getUri()).thenReturn("http://HubsUom");
        Mockito.when(serviceInfoProvider.getZoneHeaderName()).thenReturn("x-tenant");
        Mockito.when(serviceInfoProvider.getZoneHeaderValue()).thenReturn("TenantHeader");

        PowerMockito.doReturn(serviceInfoProvider).when(uomService, "getUomServiceInfo");
        PowerMockito.doReturn(restTemplate).when(uomService, "getUomRestTemplate", Matchers.any());

        Mockito.when(tracer.getCurrentTraceId()).thenReturn("trace_id");
        ReflectionUtils.setField(UomService.class, uomService, "tracer", tracer);
    }

    @Test
    public void getUomPossibleValues() throws IOException {
        getPossibleValues(
            () -> uomService.getPossibleValues((RequestContext.get(RequestContext.TENANT_UUID, String.class))));
    }

    @SuppressWarnings("unchecked")
    private void getPossibleValues(Supplier<UnitGroup[]> objectsFetcher) throws IOException {
        UnitGroup[] unitGroups = readObjectsFromResourceFile("/reservedAttributes/Uom.json", UnitGroup.class);

        Mockito.when(restTemplate
            .exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), Matchers.<Class<Object>>any(),
                any(Map.class))).thenReturn(new ResponseEntity<>(unitGroups, HttpStatus.OK));
        objectsFetcher.get();
    }

    private <X> X[] readObjectsFromResourceFile(String filePath, Class<X> clazz) throws IOException {
        return MAPPER.reader(Array.newInstance(clazz, 0).getClass()).readValue(
            this.getClass().getResourceAsStream(filePath));
    }
}
