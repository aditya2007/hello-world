/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.asset.controller.asset.AbstractAssetControllerTest;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.EnterpriseType;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.SegmentType;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.SiteType;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class })
public class OtherAssetScenariosTest extends AbstractAssetControllerTest {

    @Override
    public String getPredixPath() {
        return "/predix/otherAssetScenarios";
    }

    @Override
    public String getOutputPath() {
        return "/output/otherAssetScenarios";
    }

    @Test
    public void getAssetWithDetailedHierarchy() throws IOException {
        setupGETForSingle(Prefixes.EnterpriseTypes, UUID1, "enterpriseType1.json", EnterpriseType.class);
        setupGETForSingle(Prefixes.Enterprises, UUID1, "enterprise1.json", Enterprise.class);

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.EnterpriseTypes, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/enterpriseType1.json", EnterpriseType.class)[0]);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Enterprises, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/enterprise1.json", Enterprise.class)[0], true);

        setupGETForSingle(Prefixes.SiteTypes, UUID1, "siteType1.json", SiteType.class);
        setupGETForSingle(Prefixes.Sites, UUID1, "site1.json", Site.class);
        setupGETForTags(Prefixes.Sites, UUID1, "site1Tags.json");

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.SiteTypes, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/siteType1.json", SiteType.class)[0]);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Sites, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/site1.json", Site.class)[0], true);
        setupGetTagsFromPersistence(Prefixes.uri(Prefixes.Sites, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/site1Tags.json", MeasurementTag.class));

        setupGETForSingle(Prefixes.SegmentTypes, UUID1, "segmentType1.json", SegmentType.class);
        setupGETForSingle(Prefixes.SegmentTypes, UUID2, "segmentType2.json", SegmentType.class);
        setupGETForSingle(Prefixes.Segments, UUID1, "segment1.json", Segment.class);
        setupGETForSingle(Prefixes.Segments, UUID2, "segment2.json", Segment.class);

        setupGETForTags(Prefixes.Segments, UUID1, "segment1Tags.json");
        setupGETForTags(Prefixes.Segments, UUID2, null);

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.SegmentTypes, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/segmentType1.json", SegmentType.class)[0]);
        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.SegmentTypes, UUID2),
            readObjectsFromResourceFile(getPredixPath() + "/segmentType2.json", SegmentType.class)[0]);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Segments, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/segment1.json", Segment.class)[0], true);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Segments, UUID2),
            readObjectsFromResourceFile(getPredixPath() + "/segment2.json", Segment.class)[0], true);
        setupGetTagsFromPersistence(Prefixes.uri(Prefixes.Segments, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/segment1Tags.json", MeasurementTag.class));
        setupGetTagsFromPersistence(Prefixes.uri(Prefixes.Segments, UUID2), null);

        setupGETForSingle(Prefixes.AssetTypes, UUID1, "assetType1.json", AssetType.class);
        setupGETForSingle(Prefixes.AssetTypes, UUID2, "assetType2.json", AssetType.class);
        setupGETForSingle(Prefixes.AssetTypes, UUID3, "assetType3.json", AssetType.class);
        setupGETForSingle(Prefixes.Assets, UUID1, "asset1.json", Asset.class);
        setupGETForSingle(Prefixes.Assets, UUID2, "asset2.json", Asset.class);
        setupGETForSingle(Prefixes.Assets, UUID3, "asset3.json", Asset.class);

        setupGETForTags(Prefixes.Assets, UUID1, null);
        setupGETForTags(Prefixes.Assets, UUID2, "asset2Tags.json");
        setupGETForTags(Prefixes.Assets, UUID3, null);

        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Assets, UUID3),
            readObjectsFromResourceFile(getPredixPath() + "/asset3.json", Asset.class)[0], false);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Assets, UUID2),
            readObjectsFromResourceFile(getPredixPath() + "/asset2.json", Asset.class)[0], true);
        // setupGetByInstanceUriFromPersistence(Prefixes.uri(Prefixes.Assets, UUID1),
        //     readObjectsFromResourceFile(getPredixPath() + "/asset1.json", Asset.class)[0]);

        // setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.AssetTypes, UUID1),
        //     readObjectsFromResourceFile(getPredixPath() + "/assetType1.json", AssetType.class)[0]);
        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.AssetTypes, UUID2),
            readObjectsFromResourceFile(getPredixPath() + "/assetType2.json", AssetType.class)[0]);
        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.AssetTypes, UUID3),
            readObjectsFromResourceFile(getPredixPath() + "/assetType3.json", AssetType.class)[0]);

        // setupGetTagsFromPersistence(Prefixes.uri(Prefixes.Assets, UUID1), null);
        setupGetTagsFromPersistence(Prefixes.uri(Prefixes.Assets, UUID2),
            readObjectsFromResourceFile(getPredixPath() + "/asset2Tags.json", MeasurementTag.class));
        setupGetTagsFromPersistence(Prefixes.uri(Prefixes.Assets, UUID3), null);

        Asset fetchedDetailedAsset = getController().getSingle(UUID3, AssetComponentResolver.DETAILED);
        Asset expectedDetailedAsset = readObjectsFromResourceFile(getOutputPath() + "/detailedAsset.json",
            Asset.class)[0];
        System.out.println(fetchedDetailedAsset);
        System.out.println(expectedDetailedAsset);
        Assert.assertEquals(expectedDetailedAsset, fetchedDetailedAsset);
    }

    private <X> void setupGETForSingle(String prefix, String uuid, String fileName, Class<X> clazz) throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);
    }

    private <X> void setupGETForTags(String prefix, String uuid, String fileName) throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "monitoredEntityUri=" + Prefixes.uri(prefix, uuid));
        urlVariables.put("pageSize", 250);

        MeasurementTag[] tags = new MeasurementTag[0];
        if (fileName != null) {
            tags = readObjectsFromResourceFile(getPredixPath() + "/" + fileName, MeasurementTag.class);
        }
    }
}
