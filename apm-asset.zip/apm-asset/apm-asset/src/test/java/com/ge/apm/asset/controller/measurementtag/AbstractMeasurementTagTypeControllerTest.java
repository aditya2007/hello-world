/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.measurementtag;

import java.text.ParseException;

import org.junit.Before;

import com.ge.apm.asset.api.base.AbstractTypeControllerTest;
import com.ge.apm.asset.controller.MeasurementTagTypeController;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.ObjectInfo;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.service.component.AssetConfigService;
import com.ge.apm.asset.util.ReflectionUtils;

public abstract class AbstractMeasurementTagTypeControllerTest
    extends AbstractTypeControllerTest<MeasurementTagTypeController, MeasurementTagType> {

    protected MeasurementTagTypeController measurementTagTypeController;

    @Override
    public Class<MeasurementTagType> getObjectClass() {
        return MeasurementTagType.class;
    }

    @Override
    public MeasurementTagTypeController getController() {
        return measurementTagTypeController;
    }

    @Override
    public String getTypePrefix() {
        return "";
    }

    @Override
    public String getPrefix() {
        return Prefixes.MeasurementTagTypes;
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        measurementTagTypeController = new MeasurementTagTypeController();
        ReflectionUtils.setField(MeasurementTagTypeController.class, measurementTagTypeController, "service",
            assetTypeService);
        ReflectionUtils.setField(MeasurementTagTypeController.class, measurementTagTypeController, "assetConfigService",
            assetConfigService);
        ReflectionUtils.setField(AssetConfigService.class, assetConfigService, "uomService", uomService);
    }

    public ObjectInfo[] getChildrenInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.MeasurementTagTypes, "tag.json", MeasurementTagType.class) };
    }

    public ObjectInfo[] getParentInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.MeasurementTagTypes, "tag.json", MeasurementTagType.class) };
    }
}
