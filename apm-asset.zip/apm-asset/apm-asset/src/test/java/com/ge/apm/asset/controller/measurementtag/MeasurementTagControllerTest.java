/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.measurementtag;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.asset.api.sourcekey.ISourceKeyControllerTest;
import com.ge.apm.asset.controller.MeasurementTagController;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;
import com.ge.stuf.security.context.SecurityContext;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class, SecurityContext.class })
public class MeasurementTagControllerTest extends AbstractMeasurementTagControllerTest
    implements ISourceKeyControllerTest<MeasurementTag, IAssetService, MeasurementTagController> {

    @Test
    @Override
    public void getBySourceKey() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);
        urlVariables.put("filter", "sourceKey=SampleSourceKey");

        setupGetBySourceKeyFromPersistence("SampleSourceKey",
            readObjectsFromResourceFile(getPredixPath() + "/bySourceKey.json", getObjectClass())[0], getObjectClass());

        MeasurementTag expectedObject = readObjectsFromResourceFile(getOutputPath() + "/bySourceKey2.json",
            getObjectClass())[0];
        MeasurementTag fetchedObject = getController().getBySourceKey("SampleSourceKey");
        Assert.assertEquals(expectedObject, fetchedObject);
    }

    @Test
    public void testReservedAttributesWithTypeUri() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);
        String typeUri = "/tagTypes/" + UUID1;
        setupGetByTypeUriFromPersistence(typeUri,
            readObjectsFromResourceFile(getPredixPath() + "/type.json", MeasurementTagType.class)[0]);

        Map<String, ReservedAttributeConfig> actual = getController().reservedAttributes(typeUri);
        Assert.assertNotNull(actual);
        Assert.assertEquals(30, actual.size());
    }

    MeasurementTag[] query(Map<String, ?> urlVariables, QueryPredicate queryPredicate,
        Supplier<MeasurementTag[]> objectsFetcher) throws IOException {
        MeasurementTag[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/bySourceKey.json",
            getObjectClass());

        setupGetFromPersistence(urlVariables,
            readObjectsFromResourceFile(getPredixPath() + "/bySourceKey.json", getObjectClass()), queryPredicate,
            getObjectClass());
        MeasurementTag[] fetchedObjects = objectsFetcher.get();
        Assert.assertArrayEquals(expectedFetchedObjects, fetchedObjects);
        verifyQueryPredicateFromPersistenceCall(queryPredicate);
        return fetchedObjects;
    }

    @Test
    public void query_SourceKey() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "(sourceKey=SampleSourceKey)");
        urlVariables.put("pageSize", 250);
        QueryPredicate mockQueryPredicate = new QueryPredicate();
        mockQueryPredicate.setQuery(Optional.of("sourceKey=SampleSourceKey"));
        query(urlVariables, mockQueryPredicate,
            () -> getController().query("sourceKey=SampleSourceKey", "BASIC", 250, null, null));
    }

    @Test
    public void query_Name_Paginate() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "(name=Tag_1)");
        urlVariables.put("pageSize", 5);
        QueryPredicate mockQueryPredicate = new QueryPredicate();
        mockQueryPredicate.setQuery(Optional.of("name=Tag_1"));
        query(urlVariables, mockQueryPredicate, () -> getController().query("name=Tag_1", "BASIC", 5, null, null));
    }

    @Test(expected = ServiceException.class)
    public void query_NullObjectFromPredixThrowsError() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "(name=Tag_1)");
        urlVariables.put("pageSize", 250);
        Supplier<MeasurementTag[]> objectsFetcher = () -> getController().query("name=Tag_1", null, null, null, null);
        MeasurementTag[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/bySourceKey.json",
            getObjectClass());
        MeasurementTag[] predixObjects = readObjectsFromResourceFile(getPredixPath() + "/bySourceKey.json",
            getObjectClass());
        predixObjects[0] = null;
        MeasurementTag[] fetchedObjects = objectsFetcher.get();
        Assert.assertArrayEquals(expectedFetchedObjects, fetchedObjects);
    }

    @Test
    public void query_multiCriteria() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "(name=Tag_1)|((sourceKey=SampleSourceKey)<type[t10])");
        urlVariables.put("pageSize", 250);

        QueryPredicate mockQueryPredicate = new QueryPredicate();
        mockQueryPredicate.setQuery(Optional.of("name=Tag_1|type->sourceKey=SampleSourceKey"));

        MeasurementTag[] fetchedObjects = query(urlVariables, mockQueryPredicate,
            () -> getController().query("name=Tag_1|type->sourceKey=SampleSourceKey", "BASIC", 250, null, null));

        MeasurementTag[] expectedObjects = readObjectsFromResourceFile(getOutputPath() + "/bySourceKey.json",
            MeasurementTag.class);
        Assert.assertArrayEquals(expectedObjects, fetchedObjects);
    }
}