/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.asset;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.asset.api.crud.ICrudControllerTest;
import com.ge.apm.asset.api.hierarchy.IHierarchyControllerTest;
import com.ge.apm.asset.api.sourcekey.ISourceKeyControllerTest;
import com.ge.apm.asset.api.tag.ITagControllerTest;
import com.ge.apm.asset.controller.AssetController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.MeasurementTagLookup;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.NextCorrelatedTag;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.stuf.security.context.SecurityContext;

import static org.apache.commons.codec.binary.Hex.encodeHexString;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class, SecurityContext.class })
public class AssetControllerTest extends AbstractAssetControllerTest
    implements ICrudControllerTest<Asset, IAssetService, AssetController>,
    IHierarchyControllerTest<Asset, IAssetService, AssetController>,
    ITagControllerTest<Asset, IAssetService, AssetController>,
    ISourceKeyControllerTest<Asset, IAssetService, AssetController> {

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    @Override
    @Test
    public void associateTags_SomeExisting() throws IOException {

        Map<String, Object> typeUrlVariables = new HashMap<>();
        typeUrlVariables.put("pageSize", 1);

        Map<String, Object> tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 1);
        MeasurementTagType[] tagTypes1 = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag1.json",
            MeasurementTagType.class);
        MeasurementTagType[] tagTypes2 = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag2.json",
            MeasurementTagType.class);

        setupGetBySourceKeysFromPersistence(new String[] { "Tag2" }, null, Prefixes.MeasurementTags,
            MeasurementTag.class);

        Map<String, Object> tagLookupUrlVariables = new HashMap<>();
        tagLookupUrlVariables.put("pageSize", 1);
        String encodedUri = org.apache.commons.codec.binary.Base64.encodeBase64URLSafeString(
            Prefixes.uri(getPrefix(), UUID1).getBytes());
        MeasurementTagLookup existingTagLookup = new MeasurementTagLookup();
        existingTagLookup.setUri(Prefixes.uri(Prefixes.MeasurementTagLookups, encodedUri));
        existingTagLookup.getTags().put(encodeHexString("Tag2".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID2));

        Map<String, Object> tagUrlVariables = new HashMap<>();
        tagUrlVariables.put("pageSize", 250);
        tagUrlVariables.put("filter", "sourceKey=Tag1");

        setupGetBySourceKeysFromPersistence(new String[] { "Tag1" }, null, Prefixes.MeasurementTags,
            MeasurementTag.class);

        Map<String, Object> objectUrlVariables = new HashMap<>();
        objectUrlVariables.put("pageSize", 1);

        setupGetBySourceKeyFromPersistence("SampleAsset",
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/object.json", getObjectClass())[0],
            getObjectClass());
        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/object.json", getObjectClass())[0], false);

        MeasurementTag[] createdTags = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tags.json",
            MeasurementTag.class);

        tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 250);

        MeasurementTagLookup expectedTagLookup = new MeasurementTagLookup();
        expectedTagLookup.setUri(Prefixes.uri(Prefixes.MeasurementTagLookups, encodedUri));
        expectedTagLookup.getTags().put(encodeHexString("Tag2".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID2));
        expectedTagLookup.getTags().put(encodeHexString("Tag1".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID1));

        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/object.json", getObjectClass())[0], false);

        setupGetBySourceKeysFromPersistence(new String[] { "Tag1", "Tag2" },
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tags_2.json", MeasurementTag.class),
            Prefixes.MeasurementTags, MeasurementTag.class);

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag1.json", MeasurementTagType.class)[0]);

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID2),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag2.json", MeasurementTagType.class)[0]);

        setupUpdateTagsToPersistence();

        MeasurementTag[] tags = readObjectsFromResourceFile(getInputPath() + "/test_associateTags_SomeExisting.json",
            MeasurementTag.class);
        getController().associateTags(UUID1, tags);
    }

    @Test(expected = BadRequestException.class)
    public void associateExistingTags_ToDifferentAsset() throws IOException {

        Map<String, Object> typeUrlVariables = new HashMap<>();
        typeUrlVariables.put("pageSize", 1);

        Map<String, Object> tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 1);

        Map<String, Object> tagLookupUrlVariables = new HashMap<>();
        tagLookupUrlVariables.put("pageSize", 1);
        String encodedUri = org.apache.commons.codec.binary.Base64.encodeBase64URLSafeString(
            Prefixes.uri(getPrefix(), UUID1).getBytes());
        MeasurementTagLookup existingTagLookup = new MeasurementTagLookup();
        existingTagLookup.setUri(Prefixes.uri(Prefixes.MeasurementTagLookups, encodedUri));
        existingTagLookup.getTags().put(encodeHexString("Tag2".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID2));

        Map<String, Object> tagUrlVariables = new HashMap<>();
        tagUrlVariables.put("pageSize", 250);
        tagUrlVariables.put("filter", "sourceKey=Tag1");

        Map<String, Object> objectUrlVariables = new HashMap<>();
        objectUrlVariables.put("pageSize", 1);

        MeasurementTag[] createdTags = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tags.json",
            MeasurementTag.class);

        tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 250);

        MeasurementTagLookup expectedTagLookup = new MeasurementTagLookup();
        expectedTagLookup.setUri(Prefixes.uri(Prefixes.MeasurementTagLookups, encodedUri));
        expectedTagLookup.getTags().put(encodeHexString("Tag1".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID1));
        expectedTagLookup.getTags().put(encodeHexString("Tag2".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID2));

        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/object.json", getObjectClass())[0], false);

        setupGetBySourceKeysFromPersistence(new String[] { "Tag1", "Tag2" },
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tagWithTag1SourceKey.json",
                MeasurementTag.class), Prefixes.MeasurementTags, MeasurementTag.class);

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag1.json", MeasurementTagType.class)[0]);

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID2),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag2.json", MeasurementTagType.class)[0]);

        setupUpdateTagsToPersistence();
        MeasurementTag[] tags = readObjectsFromResourceFile(getInputPath() + "/test_associateTags_SomeExisting.json",
            MeasurementTag.class);
        getController().associateTags(UUID1, tags);
    }

    @Test
    public void getChildren() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "parent=/assets/85d56827-add1-4c4c-8afe-1db2478e6ee1");
        urlVariables.put("pageSize", 250);
        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setPageSize(250);
        setupGetChildrenFromPersistence(Prefixes.Assets,
            readObjectsFromResourceFile(getPredixPath() + "/getSingleWithParentUri.json", Asset.class),
            "/assets/85d56827-add1-4c4c-8afe-1db2478e6ee1", queryPredicate, Asset.class);

        Hierarchical[] fetchedChildren = getController().getChildren("85d56827-add1-4c4c-8afe-1db2478e6ee1",
            AssetComponentResolver.ATTRIBUTES, null, null, false, 250, null);
        List<Hierarchical> expectedChildren = new ArrayList<>();
        expectedChildren.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/getSingleWithParentUri.json", Asset.class)));
        Assert.assertArrayEquals(expectedChildren.toArray(new Hierarchical[expectedChildren.size()]), fetchedChildren);
    }

    @Test
    public void query_SourceKey() throws IOException {
        Map<String, Object> typeUrlVariables = new HashMap<>();
        typeUrlVariables.put("pageSize", 1);
        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setPageSize(1);
        setupGetByTypeUriFromPersistence(getTypePrefix() + "/" + UUID1,
            readObjectsFromResourceFile("/predix" + getTypePrefix() + "/getByCriteria.json", AssetType.class)[0]);

        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "(sourceKey=SampleSourceKey)");
        urlVariables.put("pageSize", 250);
        queryPredicate = new QueryPredicate();
        queryPredicate.setQuery(Optional.of("sourceKey=SampleSourceKey"));
        query(urlVariables, queryPredicate,
            () -> getController().query("sourceKey=SampleSourceKey", AssetComponentResolver.ATTRIBUTES, 250, null, null));
    }

    @Test
    public void query_without_q_and_nextPageLink() throws IOException {
        expectedEx.expect(ServiceException.class);
        expectedEx.expectMessage("Missing mandatory request parameter \"q\"");
        getController().query(null, AssetComponentResolver.ATTRIBUTES, null, null, null);
    }

    @Test
    public void query_Name_Paginate() throws IOException {
        Map<String, Object> typeUrlVariables = new HashMap<>();
        typeUrlVariables.put("pageSize", 1);

        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "(name=some name)");
        urlVariables.put("pageSize", 5);
        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setQuery(Optional.of("name=some name"));
        query(urlVariables, queryPredicate,
            () -> getController().query("name=some name", AssetComponentResolver.ATTRIBUTES, 5, null, null));
    }

    @Test(expected = ServiceException.class)
    public void query_NullObjectFromPredixThrowsError() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "(name=some name)");
        urlVariables.put("pageSize", 250);
        Supplier<Asset[]> objectsFetcher = () -> getController().query("name=some name",
            AssetComponentResolver.ATTRIBUTES, null, null, null);
        Asset[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/getByCriteria.json",
            getObjectClass());
        Asset[] predixObjects = readObjectsFromResourceFile(getPredixPath() + "/getByCriteria.json", getObjectClass());
        predixObjects[0] = null;
        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setQuery(Optional.of("name=some name"));
        setupGetFromPersistence(urlVariables, null, queryPredicate, getObjectClass());
        Asset[] fetchedObjects = objectsFetcher.get();
        Assert.assertArrayEquals(expectedFetchedObjects, fetchedObjects);
    }

    void query(Map<String, ?> urlVariables, QueryPredicate queryPredicate, Supplier<Asset[]> objectsFetcher)
        throws IOException {
        Asset[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/getByCriteria.json",
            getObjectClass());
        setupGetFromPersistence(urlVariables,
            readObjectsFromResourceFile(getPredixPath() + "/getByCriteria.json", getObjectClass()), queryPredicate,
            getObjectClass());
        Asset[] fetchedObjects = objectsFetcher.get();
        Assert.assertArrayEquals(expectedFetchedObjects, fetchedObjects);
        verifyQueryPredicateFromPersistenceCall(queryPredicate);
    }

    @Test
    public void query_multiCriteria() throws IOException {
        Map<String, Object> typeUrlVariables = new HashMap<>();
        typeUrlVariables.put("pageSize", 1);
        setupGetByTypeUriFromPersistence(getPredixBaseUrl() + getTypePrefix() + "/" + UUID1,
            readObjectsFromResourceFile("/predix" + getTypePrefix() + "/getByCriteria.json", AssetType.class)[0]);

        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "(name=some name)|((sourceKey=SampleAssetTypeSourceKey)<type[t10])");
        urlVariables.put("pageSize", 250);
        setupGetFromPersistence(readObjectsFromResourceFile(getPredixPath() + "/getByQuery.json", Asset.class),
            Asset.class);
        Asset[] fetchedObjects = getController().query("name=some name|type->sourceKey=SampleAssetTypeSourceKey",
            AssetComponentResolver.ATTRIBUTES, null, null, null);
        Asset[] expectedObjects = readObjectsFromResourceFile(getOutputPath() + "/getByQuery.json", Asset.class);
        Assert.assertArrayEquals(expectedObjects, fetchedObjects);
    }

    @Test
    public void getChildrenWithNameFilter() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("filter", "name=Sample*:parent=/assets/85d56827-add1-4c4c-8afe-1db2478e6ee1");
        urlVariables.put("pageSize", 250);
        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setName(Optional.of("Sample*"));
        queryPredicate.setPageSize(250);
        setupGetChildrenFromPersistence(Prefixes.Assets,
            readObjectsFromResourceFile(getPredixPath() + "/getSingleWithParentUri.json", Asset.class),
            Prefixes.Assets + "/85d56827-add1-4c4c-8afe-1db2478e6ee1", queryPredicate, Asset.class);
        Hierarchical[] fetchedChildren = getController().getChildren("85d56827-add1-4c4c-8afe-1db2478e6ee1",
            AssetComponentResolver.ATTRIBUTES, "Sample*", null, false, 250, null);
        List<Hierarchical> expectedChildren = new ArrayList<>();
        expectedChildren.addAll(
            Arrays.asList(readObjectsFromResourceFile(getOutputPath() + "/getSingleWithParentUri.json", Asset.class)));
        Assert.assertArrayEquals(expectedChildren.toArray(new Hierarchical[expectedChildren.size()]), fetchedChildren);
    }

    @Override
    @Test
    public void create() throws IOException {

        Asset[] objects = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        Map<String, Object> urlVariablesForAssetType = new HashMap<>();
        urlVariablesForAssetType.put("pageSize", 1);
        AssetType[] assetTypes = readObjectsFromResourceFile(getPredixPath() + "/type.json", AssetType.class);

        Asset[] predixObjects = readObjectsFromResourceFile(getPredixPath() + "/create.json", getObjectClass());

        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 250);
        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());

        setupGetByTypeUriFromPersistence(Prefixes.uri(getTypePrefix(), UUID1), assetTypes[0]);
        setupGetBySourceKeysFromPersistence(new String[] { objects[0].getSourceKey() }, null, getPrefix(),
            getObjectClass());
        setupCreateToPersistence(objects);

        Asset[] createdObjects = getController().create(Arrays.asList(objects));
        Asset[] expectedCreatedObjects = readObjectsFromResourceFile(getOutputPath() + "/create.json",
            getObjectClass());
        Assert.assertArrayEquals(expectedCreatedObjects, createdObjects);
        //verifyPOSTCalls(getPredixBaseUrl() + getPrefix());
    }

    @Test(expected = BadRequestException.class)
    public void testCreateWithInvalidPayload() throws IOException {
        Asset[] objects = readObjectsFromResourceFile(getInputPath() + "/create_invalid.json", getObjectClass());
        getController().create(Arrays.asList(objects));
    }

    @Override
    @Test(expected = BadRequestException.class)
    public void createWithSameSourceKeyInRequest() throws IOException {
        Asset[] objects = readObjectsFromResourceFile(getInputPath() + "/createMultipleWithSameSourceKey.json",
            getObjectClass());
        Map<String, Object> urlVariablesForAssetType = new HashMap<>();
        urlVariablesForAssetType.put("pageSize", 1);

        Asset[] predixObjects = readObjectsFromResourceFile(getPredixPath() + "/create.json", getObjectClass());

        setupGetByTypeUriFromPersistence(Prefixes.uri(getTypePrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/type.json", AssetType.class)[0]);
        setupGetByTypeUriFromPersistence(Prefixes.uri(getTypePrefix(), UUID3),
            readObjectsFromResourceFile(getPredixPath() + "/type.json", AssetType.class)[0]);
        setupCreateToPersistence(predixObjects);

        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 250);
        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());

        getController().create(Arrays.asList(objects));
    }

    @Override
    @Test(expected = BadRequestException.class)
    public void createWithSameSourceKey() throws IOException {
        Asset[] objects = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        Map<String, Object> urlVariablesForAssetType = new HashMap<>();
        urlVariablesForAssetType.put("pageSize", 1);
        Asset[] predixObjects = readObjectsFromResourceFile(getPredixPath() + "/create.json", getObjectClass());

        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 250);
        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());

        setupGetBySourceKeysFromPersistence(new String[] { objects[0].getSourceKey() }, predixObjects, getPrefix(),
            getObjectClass());
        String[] srcKeys = Arrays.stream(objects).map(Asset::getSourceKey).collect(Collectors.toList()).toArray(
            new String[objects.length]);
        setupGetBySourceKeysFromPersistence(srcKeys, objects, Prefixes.Assets, getObjectClass());

        setupGetByTypeUriFromPersistence(Prefixes.uri(getTypePrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/type.json", AssetType.class)[0]);
        setupCreateToPersistence(predixObjects);

        getController().create(Arrays.asList(objects));
    }

    //    @Test(expected = ServiceException.class)
    //    public void create_deletesObjectFromPredixAfterResourceGraphError() throws IOException{
    //        Asset[] objects = readObjectsFromResourceFile(getInputPath() + "/create.json",
    // getObjectClass());
    //        Map<String, Object> urlVariablesForAssetType = new HashMap<>();
    //        urlVariablesForAssetType.put("pageSize", 1);
    //        setupGETFor(getPredixBaseUrl() + Prefixes.uri(getTypePrefix(), UUID1),
    //                readObjectsFromResourceFile(getPredixPath() + "/type.json", AssetType
    // .class), urlVariablesForAssetType,
    //                AssetType.class);
    //        Asset[] predixObjects = readObjectsFromResourceFile(getPredixPath() + "/create
    // .json", getObjectClass());
    //        setupForType(objects[0]);
    //
    //        Map<String, Object> urlVariables = new HashMap<>();
    //        urlVariables.put("pageSize", 250);
    //        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());
    //        setupGETFor(getPredixBaseUrl() + getPrefix(), null, urlVariables);
    //
    //        setupPOSTFor(getPredixBaseUrl() + getPrefix(), predixObjects);
    //        throwExceptionForAcsCallsForCreate();
    //
    //        try {
    //            getController().create(objects);
    //            Assert.fail();
    //        } catch (ServiceException se) {
    //            verifyAcsCalls(predixObjects);
    //            verifyPOSTCalls(getPredixBaseUrl() + getPrefix());
    //            for (int i = 0; i < objects.length; i++) {
    //                verifyDELETECalled(getPredixBaseUrl() + objects[i].getUri());
    //            }
    //            throw se;
    //        }
    //    }

    @Test
    public void updateSingle_createsObjectsIfNotInResourceGraph() throws IOException {
        PatchOperation[] patchOperations = readObjectsFromResourceFile(getInputPath() + "/updateParent.json",
            PatchOperation.class);
        Asset[] predixObject = readObjectsFromResourceFile(getPredixPath() + "/getSingleWithAttributes.json",
            getObjectClass());
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);

        setupGetByTypeUriFromPersistence(Prefixes.uri(getTypePrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/type.json", getTypeClass())[0]);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1), predixObject[0], false);
        setupGetByInstanceUriFromPersistence(patchOperations[0].getValue().toString(), null, false);

        getController().updateSingle(UUID1, Arrays.asList(patchOperations));
        Asset[] acsObjects = new Asset[2];
        acsObjects[0] = predixObject[0];
        acsObjects[0].setUri(Prefixes.uri(getPrefix(), UUID2));
        acsObjects[1] = new Asset();
        acsObjects[1].setUri(Prefixes.uri(getPrefix(), UUID1));
        acsObjects[1].setParent(Prefixes.uri(getPrefix(), UUID2));
        //verifyPATCHCalls(getPredixBaseUrl() + Prefixes.uri(getPrefix(), UUID1));
    }

    @Test
    public void getTagWithCorrelations() throws IOException {
        Map<String, Object> tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 1);

        Map<String, Object> urlVariables1 = new HashMap<>();
        urlVariables1.put("pageSize", 1);

        Map<String, Object> urlVariables2 = new HashMap<>();
        urlVariables2.put("pageSize", 1);

        Map<String, Object> urlVariables3 = new HashMap<>();
        urlVariables3.put("pageSize", 1);

        Map<String, Object> urlVariables4 = new HashMap<>();
        urlVariables4.put("pageSize", 1);

        setupGetTagDetailsFromPersistence(Prefixes.uri(Prefixes.MeasurementTags, UUID2),
            readObjectsFromResourceFile(getPredixPath() + "/Tag0WithCorrelation.json", MeasurementTag.class)[0]);

        MeasurementTag[] fetchedTags = getController().getTagsForAnObject(UUID1, null, null, null, null, -1, null,
            null, false, null, "/tags/" + UUID2, true);
        MeasurementTag[] expectedTags = readObjectsFromResourceFile(
            getOutputPath() + "/test_getTagWithCorrelations.json", MeasurementTag.class);
        Assert.assertArrayEquals(expectedTags, fetchedTags);
    }

    @Test
    public void getTagWithCorrelationWhereCorrelationUriIsNull() throws IOException {
        Map<String, Object> tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 1);
        Map<String, Object> urlVariables1 = new HashMap<>();
        urlVariables1.put("pageSize", 1);

        setupGetTagDetailsFromPersistence(Prefixes.MeasurementTags + "/" + UUID2,
            readObjectsFromResourceFile(getPredixPath() + "/Tag1WithNoCorrelation.json", MeasurementTag.class)[0]);
        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag1.json", MeasurementTagType.class)[0]);
        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID2),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag2.json", MeasurementTagType.class)[0]);

        MeasurementTag[] fetchedTags = getController().getTagsForAnObject(UUID1, null, null, null, null, -1, null,
            null, false, null, "/tags/" + UUID2, true);

        MeasurementTag[] expectedTags = readObjectsFromResourceFile(
            getOutputPath() + "/outputTagWithNoCorrelations.json", MeasurementTag.class);

        Assert.assertArrayEquals(expectedTags, fetchedTags);
    }

    @Test(expected = ServiceException.class)
    public void getTagWithCorrelationWhichCannotBeFoundInPredixAsset() throws IOException {
        Map<String, Object> urlVariables1 = new HashMap<>();
        urlVariables1.put("pageSize", 1);

        MeasurementTag[] fetchedTags = getController().getTagsForAnObject(UUID1, null, null, null, null, -1, null,
            null, false, null, "/tags/" + UUID2, true);
        Assert.fail("Expected ServiceException not thrown: fetchedTags=" + fetchedTags);
    }

    @Ignore("In persistence layer, there is no way a tag can get associated to multiple monitored entities")
    @Test
    public void getTagWithWrongMonitoredEntityUri() throws IOException {

        Map<String, Object> tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 1);
        Map<String, Object> urlVariables1 = new HashMap<>();
        urlVariables1.put("pageSize", 1);

        setupGetTagDetailsFromPersistence(Prefixes.MeasurementTags + "/" + UUID2,
            readObjectsFromResourceFile(getPredixPath() + "/Tag1WithWrongMonitoredEntityUri.json",
                MeasurementTag.class)[0]);

        setupGetByInstanceUriFromPersistence("WrongMonitoredEntityUri", new Asset(), false);
        MeasurementTag[] fetchedTags = getController().getTagsForAnObject(UUID1, null, null, null, null, -1, null,
            null, false, null, "/tags/" + UUID2, true);

        Assert.assertEquals(1, fetchedTags.length);
        Assert.assertNull(fetchedTags[0]);
    }

    @Test(expected = ServiceException.class)
    public void getTagWithCorrelationWithTagsWhichCannotBeFoundInPredixAsset() throws IOException {
        Map<String, Object> urlVariables1 = new HashMap<>();
        urlVariables1.put("pageSize", 1);

        Map<String, Object> urlVariables2 = new HashMap<>();
        urlVariables2.put("pageSize", 1);

        MeasurementTag[] fetchedTags = getController().getTagsForAnObject(UUID1, null, null, null, null, -1, null,
            null, false, null, "/tags/" + UUID2, true);
        Assert.fail("Expected ServiceException not thrown: fetchedTags=" + fetchedTags);
    }

    @Test
    public void testReservedAttributesWithTypeUri() throws IOException {
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);
        String typeUri = "/assetTypes/" + UUID1;
        setupGetByTypeUriFromPersistence(typeUri,
            readObjectsFromResourceFile(getPredixPath() + "/type.json", AssetType.class)[0]);
        Map<String, ReservedAttributeConfig> actual = getController().reservedAttributes(typeUri);
        Assert.assertNotNull(actual);
        Assert.assertEquals(10, actual.size());
    }

    @Override
    @Test
    public void associateTags() throws IOException {

        Map<String, Object> typeUrlVariables = new HashMap<>();
        typeUrlVariables.put("pageSize", 1);

        Map<String, Object> tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 1);

        MeasurementTagType[] tagTypes1 = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag1.json",
            MeasurementTagType.class);

        MeasurementTagType[] tagTypes2 = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag2.json",
            MeasurementTagType.class);

        Map<String, Object> tagLookupUrlVariables = new HashMap<>();
        tagLookupUrlVariables.put("pageSize", 1);
        String encodedUri = org.apache.commons.codec.binary.Base64.encodeBase64URLSafeString(
            Prefixes.uri(getPrefix(), UUID1).getBytes());

        Map<String, Object> objectUrlVariables = new HashMap<>();
        objectUrlVariables.put("pageSize", 1);

        tagTypeVariables = new HashMap<>();
        tagTypeVariables.put("pageSize", 250);

        Map<String, Object> tagUrlVariables = new HashMap<>();
        tagUrlVariables.put("pageSize", 250);
        tagUrlVariables.put("filter", "sourceKey=Tag1");

        MeasurementTagLookup expectedTagLookup = new MeasurementTagLookup();
        expectedTagLookup.setUri(Prefixes.uri(Prefixes.MeasurementTagLookups, encodedUri));
        expectedTagLookup = new MeasurementTagLookup();
        expectedTagLookup.setUri(Prefixes.uri(Prefixes.MeasurementTagLookups, encodedUri));
        expectedTagLookup.getTags().put(encodeHexString("Tag1".getBytes()),
            Prefixes.uri(Prefixes.MeasurementTags, UUID1));
        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID1), tagTypes1[0]);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/object.json", getObjectClass())[0], false);
        setupGetBySourceKeysFromPersistence(new String[] { "Tag1" }, new MeasurementTag[0], Prefixes.MeasurementTags,
            MeasurementTag.class);
        setupUpdateTagsToPersistence();
        MeasurementTag[] tags = readObjectsFromResourceFile(getInputPath() + "/tags_2.json", MeasurementTag.class);
        tags[0].setNextRelatedTag(new NextCorrelatedTag());
        getController().associateTags(UUID1, tags);
    }

    @Test(expected = BadRequestException.class)
    public void associateTags_ForDecommissionedAsset() throws IOException {

        MeasurementTagType[] tagTypes1 = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tag1.json",
            MeasurementTagType.class);
        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.MeasurementTagTypes, UUID1), tagTypes1[0]);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/decommissionedAsset.json",
                getObjectClass())[0], false);
        setupGetBySourceKeysFromPersistence(new String[] { "Tag1" }, new MeasurementTag[0], Prefixes.MeasurementTags,
            MeasurementTag.class);
        setupUpdateTagsToPersistence();
        MeasurementTag[] tags = readObjectsFromResourceFile(getInputPath() + "/tags_2.json", MeasurementTag.class);
        getController().associateTags(UUID1, tags);
    }

    @Test(expected = BadRequestException.class)
    public void updateTag_ForDecommissionedAsset() throws IOException {

        PatchOperation[] patchOperations = readObjectsFromResourceFile(getInputPath() + "/updateTag.json",
            PatchOperation.class);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/decommissionedAsset.json",
                getObjectClass())[0], false);
        getController().updatePartialTag(UUID1, UUID2, patchOperations);
    }

    @Test(expected = BadRequestException.class)
    public void disassociateTag_FromDecommissionedAsset() throws IOException {

        MeasurementTag[] tagsToDelete = readObjectsFromResourceFile(getPredixPath() + "/associateTags/tags.json",
            MeasurementTag.class);
        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/associateTags/decommissionedAsset.json",
                getObjectClass())[0], false);
        setupGetTagDetailsFromPersistence(Prefixes.uri(Prefixes.MeasurementTags, UUID1), tagsToDelete[0]);
        setupGetTagDetailsFromPersistence(Prefixes.uri(Prefixes.MeasurementTags, UUID2), tagsToDelete[1]);
        setupIsGroupMemberFromPersistence(Prefixes.uri(Prefixes.MeasurementTags, UUID1), false);
        setupIsGroupMemberFromPersistence(Prefixes.uri(Prefixes.MeasurementTags, UUID2), false);

        setupDeleteTagsFromPersistence(Prefixes.uri(getPrefix(), UUID1),
            new String[] { Prefixes.uri(Prefixes.MeasurementTags, UUID1),
                Prefixes.uri(Prefixes.MeasurementTags, UUID2) });

        getController().disassociateTags(UUID1, new String[] { Prefixes.uri(Prefixes.MeasurementTags, UUID1),
            Prefixes.uri(Prefixes.MeasurementTags, UUID2) });

        // getController().disassociateTags(UUID1, );
    }

    @Test(expected = BadRequestException.class)
    public void createAsset_ValidLocation() throws IOException {
        Asset[] objects = readObjectsFromResourceFile(getInputPath() + "/create_geolocation.json", getObjectClass());
        Map<String, Object> urlVariablesForAssetType = new HashMap<>();
        urlVariablesForAssetType.put("pageSize", 1);

        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 250);
        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());
        setupGetBySourceKeysFromPersistence(new String[] { objects[0].getSourceKey() }, null, getPrefix(),
            getObjectClass());
        setupGetByTypeUriFromPersistence(Prefixes.uri(getTypePrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/type.json", AssetType.class)[0]);

        getController().create(Arrays.asList(objects));
    }

    @Test(expected = BadRequestException.class)
    public void updateAsset_ValidLocation() throws IOException {
        PatchOperation[] patchOperations = readObjectsFromResourceFile(getInputPath() + "/update_geolocation.json",
            PatchOperation.class);
        Asset[] predixObject = readObjectsFromResourceFile(getPredixPath() + "/getSingleWithAttributes.json",
            getObjectClass());
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);

        setupGetByTypeUriFromPersistence(Prefixes.uri(getTypePrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/type.json", getTypeClass())[0]);

        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1), predixObject[0], false);
        getController().updateSingle(UUID1, Arrays.asList(patchOperations));
    }

    @Test(expected = BadRequestException.class)
    public void createAsset_GridType() throws IOException {
        Asset[] objects = readObjectsFromResourceFile(getInputPath() + "/create_gridtype.json", getObjectClass());
        Map<String, Object> urlVariablesForAssetType = new HashMap<>();
        urlVariablesForAssetType.put("pageSize", 1);

        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 250);
        urlVariables.put("filter", "sourceKey=" + objects[0].getSourceKey());

        setupGetByTypeUriFromPersistence(Prefixes.uri(getTypePrefix(), UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/type.json", AssetType.class)[0]);

        getController().create(Arrays.asList(objects));
    }

    @Test(expected = BadRequestException.class)
    public void createWithInvalidTypeInRequest() throws IOException {
        Asset[] objects = readObjectsFromResourceFile(getInputPath() + "/createWithInvalidTypeInRequest.json",
            getObjectClass());
        Map<String, Object> urlVariables = new HashMap<>();
        urlVariables.put("pageSize", 1);

        setupGetByTypeUriFromPersistence(Prefixes.uri(Prefixes.SegmentTypes, UUID1),
            readObjectsFromResourceFile(getPredixPath() + "/type.json", AssetType.class)[0]);

        getController().create(Arrays.asList(objects));
    }

    @Test(expected = BadRequestException.class)
    public void updateWithInvalidType() throws IOException {
        PatchOperation[] objects = readObjectsFromResourceFile(getInputPath() + "/updateWithInvalidType.json",
            PatchOperation.class);
        Asset[] predixObject = readObjectsFromResourceFile(getPredixPath() + "/getSingleWithAttributes.json",
            getObjectClass());

        setupGetByInstanceUriFromPersistence(Prefixes.uri(getPrefix(), UUID1), predixObject[0], false);

        getController().updateSingle(UUID1, Arrays.asList(objects));
    }

    @Test(expected = BadRequestException.class)
    public void deleteAssetWithChildren() {
        Mockito.doReturn(new Hierarchical[] { new Asset() }).when(almPersistenceService).getChildrenInstances(
            anyString(), eq("/assets"), eq("/assets/uuid"), any(), any(), anyBoolean(), anyBoolean());
        PowerMockito.doReturn(new Asset()).when(assetService).getSingle(eq("/assets/uuid"), any(), anyList());
        getController().delete("uuid");
    }

    @SuppressWarnings("unchecked")
    @Override
    @Test
    public void delete() throws IOException {
        PowerMockito.doReturn(new Hierarchical[0]).when(assetService).getChildren(Matchers.anyString(),
            Matchers.anyString(), Matchers.anyString(), Matchers.any(Class.class), Matchers.anyList(),
            Mockito.any(QueryPredicate.class), Mockito.anyBoolean(), Mockito.anyInt(), eq(true));
        PowerMockito.doReturn(new Asset()).when(assetService).getSingle(eq("/assets/uuid"), any(), anyList());
        PowerMockito.doNothing().when(assetService).deleteAssetRecursively(Matchers.anyString(), Matchers.anyString(),
            Matchers.any(Class.class));
        getController().delete("uuid");
    }

    @SuppressWarnings("unchecked")
    @Test(expected = BadRequestException.class)
    public void deleteDecommissionedAsset() throws IOException {
        Map<String, String> keyValue = new HashMap<>();
        keyValue.put("key", "10");
        Map<String, Object> reservedAttributes = new HashMap<>();
        reservedAttributes.put("state", keyValue);
        Asset asset = new Asset();
        asset.setName("as");
        asset.setMeasurementTags(null);
        asset.setReservedAttributes(reservedAttributes);

        PowerMockito.doReturn(new Hierarchical[0]).when(assetService).getChildren(Matchers.anyString(),
            Matchers.anyString(), Matchers.anyString(), Matchers.any(Class.class), Matchers.anyList(),
            Mockito.any(QueryPredicate.class), Mockito.anyBoolean(), Mockito.anyInt(), eq(true));
        PowerMockito.doReturn(asset).when(assetService).getSingle(eq("/assets/uuid"), any(), anyList());
        /*PowerMockito.doNothing().when(assetService).deleteAssetRecursively(Matchers.anyString(), Matchers.anyString(),
            Matchers.any(Class.class));*/
        PowerMockito.doReturn(asset).when(almPersistenceService).getInstanceByUri(anyString(), anyString(), eq(false));
        try {
            getController().delete("uuid");
        } catch (BadRequestException ex) {
            Assert.assertEquals(ex.getCode(), ErrorConstants.INVALID_DELETION_OF_DECOMMISSIONED_ASSET);
            throw ex;
        }
    }
}
