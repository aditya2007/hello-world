/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.enterprise;

import java.text.ParseException;

import org.junit.Before;

import com.ge.apm.asset.api.base.AbstractInstanceControllerTest;
import com.ge.apm.asset.controller.EnterpriseController;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.EnterpriseType;
import com.ge.apm.asset.model.ObjectInfo;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.util.ReflectionUtils;

public abstract class AbstractEnterpriseControllerTest
    extends AbstractInstanceControllerTest<EnterpriseController, Enterprise> {

    protected EnterpriseController enterpriseController;

    public AbstractEnterpriseControllerTest() {
        // define an explicit constructor
    }

    protected AbstractEnterpriseControllerTest(boolean accessControlledTest) {
        super(accessControlledTest);
    }

    public Class<EnterpriseType> getTypeClass() {
        return EnterpriseType.class;
    }

    @Override
    public Class<Enterprise> getObjectClass() {
        return Enterprise.class;
    }

    @Override
    public EnterpriseController getController() {
        return enterpriseController;
    }

    @Override
    public String getTypePrefix() {
        return Prefixes.EnterpriseTypes;
    }

    @Override
    public String getPrefix() {
        return Prefixes.Enterprises;
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        enterpriseController = new EnterpriseController();
        ReflectionUtils.setField(EnterpriseController.class, enterpriseController, "service", assetService);
        ReflectionUtils.setField(EnterpriseController.class, enterpriseController, "assetConfigService",
            assetConfigService);
    }

    public ObjectInfo[] getChildrenInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.Enterprises, "childEnterprises.json", Enterprise.class),
            new ObjectInfo(Prefixes.Sites, "childSites.json", Site.class) };
    }

    public ObjectInfo[] getParentInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.Enterprises, "parentEnterprise.json", Enterprise.class) };
    }
}
