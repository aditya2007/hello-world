/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.asset;

import java.text.ParseException;

import org.junit.Before;

import com.ge.apm.asset.api.base.AbstractInstanceControllerTest;
import com.ge.apm.asset.controller.AssetController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.ObjectInfo;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.util.ReflectionUtils;

public abstract class AbstractAssetControllerTest extends AbstractInstanceControllerTest<AssetController, Asset> {

    protected AssetController assetController;

    public AbstractAssetControllerTest() {
        // define an explicit constructor
    }

    protected AbstractAssetControllerTest(boolean accessControlledTest) {
        super(accessControlledTest);
    }

    public Class<AssetType> getTypeClass() {
        return AssetType.class;
    }

    @Override
    public Class<Asset> getObjectClass() {
        return Asset.class;
    }

    @Override
    public AssetController getController() {
        return assetController;
    }

    @Override
    public String getTypePrefix() {
        return Prefixes.AssetTypes;
    }

    @Override
    public String getPrefix() {
        return Prefixes.Assets;
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        assetController = new AssetController();
        ReflectionUtils.setField(AssetController.class, assetController, "service", assetService);
        ReflectionUtils.setField(AssetController.class, assetController, "assetConfigService", assetConfigService);
        ReflectionUtils.setField(AssetController.class, assetController, "pageSize", 10);

    }

    public ObjectInfo[] getChildrenInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.Assets, "childAssets.json", Asset.class) };
    }

    public ObjectInfo[] getParentInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.Sites, "parentSite.json", Site.class), new ObjectInfo(
            Prefixes.Segments, "parentSegment.json", Segment.class), new ObjectInfo(Prefixes.Assets, "parentAsset.json",
            Asset.class) };
    }
}
