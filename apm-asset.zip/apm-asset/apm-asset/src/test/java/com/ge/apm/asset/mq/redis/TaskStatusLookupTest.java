/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.redis;

import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.powermock.reflect.Whitebox;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import redis.clients.jedis.exceptions.JedisException;

import com.ge.apm.asset.mq.redis.TaskStatusLookup.TaskInfo;
import com.ge.asset.commons.mq.constants.MessageConstants;

public class TaskStatusLookupTest {

    @Spy
    @InjectMocks
    private TaskStatusLookup taskStatusLookup;

    @Mock
    private CacheManager cacheManager;

    @Mock
    private Cache cache;

    private TaskInfo taskInfo;

    private Exchange exchange;

    private static final String INGESTION_STATUS_CACHE = "ApmIngestionStatusCache";

    private static final String INGESTION_TASK_STATUS_IN_PROGRESS = "IN_PROGRESS";

    private static final String INGESTION_TASK_STATUS_DONE = "DONE";

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        taskInfo = new TaskInfo("id-1", INGESTION_TASK_STATUS_IN_PROGRESS, 1L);
        exchange = new DefaultExchange(new DefaultCamelContext());

        Whitebox.setInternalState(taskStatusLookup, "messageRedeliveryDelay", 5000L);
        Whitebox.setInternalState(taskStatusLookup, "taskProcessingTimeBuffer", 3600000L);
    }

    @Test
    public void isTaskDone_NotReQueued() {
        exchange.getIn().setHeader(MessageConstants.TASK_UUID, "id-1");
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doReturn(taskInfo).when(cache).get(Matchers.any(), Matchers.eq(TaskInfo.class));
        Assert.assertEquals(taskStatusLookup.isTaskDone(exchange), false);

        taskInfo = new TaskInfo("id-1", INGESTION_TASK_STATUS_DONE, 1L);
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doReturn(taskInfo).when(cache).get(Matchers.any(), Matchers.eq(TaskInfo.class));
        Assert.assertEquals(taskStatusLookup.isTaskDone(exchange), true);
    }

    @Test
    public void isTaskDone_ReQueued() {
        exchange.getIn().setHeader(MessageConstants.TASK_STARTTIME, 1L);
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doReturn(taskInfo).when(cache).get(Matchers.any(), Matchers.eq(TaskInfo.class));
        Assert.assertEquals(taskStatusLookup.isTaskDone(exchange), false);

        exchange.getIn().setHeader(MessageConstants.TASK_STARTTIME, 1L);
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doReturn(null).when(cache).get(Matchers.any(), Matchers.eq(TaskInfo.class));
        Assert.assertEquals(taskStatusLookup.isTaskDone(exchange), true);
    }

    @Test
    public void isTaskDone_RedisException() {
        Mockito.doThrow(new JedisException("Test Exception")).when(cacheManager).getCache(
            Matchers.eq(INGESTION_STATUS_CACHE));
        Assert.assertEquals(taskStatusLookup.isTaskDone(exchange), false);

        exchange.getIn().setHeader(MessageConstants.TASK_STARTTIME, 1L);
        Mockito.doThrow(new JedisException("Test Exception")).when(cacheManager).getCache(
            Matchers.eq(INGESTION_STATUS_CACHE));
        Assert.assertEquals(taskStatusLookup.isTaskDone(exchange), true);
    }

    @Test
    public void isTaskInProgress() {
        exchange.getIn().setHeader(MessageConstants.TASK_UUID, "id-1");
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doReturn(taskInfo).when(cache).get(Matchers.any(), Matchers.eq(TaskInfo.class));
        Assert.assertEquals(taskStatusLookup.isTaskInProgress(exchange), true);

        taskInfo = new TaskInfo("id-1", INGESTION_TASK_STATUS_DONE, 1L);
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doReturn(taskInfo).when(cache).get(Matchers.any(), Matchers.eq(TaskInfo.class));
        Assert.assertEquals(taskStatusLookup.isTaskInProgress(exchange), false);

        Mockito.doThrow(new JedisException("Test Exception")).when(cacheManager).getCache(
            Matchers.eq(INGESTION_STATUS_CACHE));
        Assert.assertEquals(taskStatusLookup.isTaskInProgress(exchange), false);
    }

    @Test
    public void markTaskDone() {
        exchange.getIn().setHeader(MessageConstants.TASK_UUID, "id-1");
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doNothing().when(cache).put(Matchers.eq("id-1"), Matchers.any());
        taskStatusLookup.markTaskDone(exchange);

        exchange.getIn().setHeader(MessageConstants.TASK_UUID, "id-1");
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doThrow(new JedisException("Test Exception")).when(cache).put(Matchers.eq("id-1"), Matchers.any());
        taskStatusLookup.markTaskDone(exchange);
    }

    @Test
    public void markTaskInProgress() throws Exception {
        exchange.getIn().setHeader(MessageConstants.TASK_UUID, "id-1");
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doNothing().when(cache).put(Matchers.eq("id-1"), Matchers.any());
        taskStatusLookup.markTaskInProgress(exchange);

        exchange.getIn().setHeader(MessageConstants.TASK_UUID, "id-1");
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doThrow(new JedisException("Test Exception")).when(cache).put(Matchers.eq("id-1"), Matchers.any());
        taskStatusLookup.markTaskInProgress(exchange);
    }

    @Test
    public void isTaskStale() throws Exception {
        exchange.getIn().setHeader(MessageConstants.TASK_UUID, "id-1");
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doReturn(taskInfo).when(cache).get(Matchers.any(), Matchers.eq(TaskInfo.class));
        Assert.assertEquals(taskStatusLookup.isTaskStale(exchange), true);

        taskInfo = new TaskInfo("id-1", INGESTION_TASK_STATUS_DONE, System.currentTimeMillis());
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doReturn(taskInfo).when(cache).get(Matchers.any(), Matchers.eq(TaskInfo.class));
        Assert.assertEquals(taskStatusLookup.isTaskStale(exchange), false);

        Mockito.doThrow(new JedisException("Test Exception")).when(cacheManager).getCache(
            Matchers.eq(INGESTION_STATUS_CACHE));
        Assert.assertEquals(taskStatusLookup.isTaskStale(exchange), false);
    }

    @Test
    public void disposeTask() throws Exception {
        exchange.getIn().setHeader(MessageConstants.TASK_UUID, "id-1");
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doNothing().when(cache).evict(Matchers.eq("id-1"));
        taskStatusLookup.disposeTask(exchange);

        exchange.getIn().setHeader(MessageConstants.TASK_UUID, "id-1");
        Mockito.doReturn(cache).when(cacheManager).getCache(Matchers.eq(INGESTION_STATUS_CACHE));
        Mockito.doThrow(new JedisException("Test Exception")).when(cache).evict(Matchers.eq("id-1"));
        taskStatusLookup.disposeTask(exchange);
    }
}