/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.UUID;
import java.util.zip.Deflater;

import com.google.gson.Gson;
import org.apache.camel.CamelContext;
import org.apache.camel.ConsumerTemplate;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.gson.GsonDataFormat;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.component.rabbitmq.RabbitMQConstants;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.model.BeanDefinition;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.model.RouteDefinition;
import org.apache.camel.model.dataformat.SerializationDataFormat;
import org.apache.camel.model.dataformat.ZipDataFormat;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.apache.camel.test.spring.CamelTestContextBootstrapper;
import org.apache.camel.test.spring.MockEndpoints;
import org.apache.camel.test.spring.UseAdviceWith;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;

import com.ge.apm.asset.Application;
import com.ge.apm.asset.db.PersistenceConfigAsset;
import com.ge.apm.asset.model.DownloadTask;
import com.ge.apm.asset.mq.config.AssetRouteBuilder;
import com.ge.apm.asset.mq.exception.DependencyViolationException;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.exception.AssetServiceException;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.mq.util.CryptoHelper;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

/**
 * Created by 212576241 on 2/21/17.
 */
@ComponentScan(
    value = { "com.ge.apm.commons.logging", "com.ge.apm.common.filter", "com.ge.apm.asset", "com.ge.asset" + ".commons",
        "org.apache.camel.spring.boot", "com.ge.apm.blob.client", "com.ge.apm.blob.factory",
        "com.ge.apm.blob" + ".repository", "com.ge.apm.rest", "com.ge.apm.service" },
    excludeFilters = { @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = PersistenceConfigAsset.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = Application.class) })
@ActiveProfiles("test")
@RunWith(CamelSpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { AssetRouteBuilderTest.class, CamelTestContextBootstrapper.class })
@MockEndpoints("rabbitmq*")
@UseAdviceWith
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class AssetRouteBuilderTest {

    protected ZipDataFormat zipData;

    protected SerializationDataFormat serializationDataFormat;

    protected GsonDataFormat gsonDataFormat;

    @Autowired
    CamelContext camelContext;

    @Autowired
    AssetRouteBuilder assetRouteBuilder;

    @Autowired
    CryptoHelper cryptoHelper;

    @Autowired
    ProducerTemplate producerTemplate;

    @Autowired
    ConsumerTemplate consumerTemplate;

    @Before
    public void setUp() throws Exception {
        zipData = new ZipDataFormat();
        zipData.setCompressionLevel(Deflater.BEST_COMPRESSION);
        serializationDataFormat = new SerializationDataFormat();
        gsonDataFormat = new GsonDataFormat(new Gson(), DownloadTask.class);

        RouteDefinition route = camelContext.getRouteDefinition("ack_error");
        route.adviceWith(camelContext.adapt(ModelCamelContext.class), new RouteBuilder() {
            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("direct:ge.apm.asset.ingestion.dto.ack.dto.ack.error").to("mock:error")
                    .skipSendToOriginalEndpoint();
            }
        });
        route = camelContext.getRouteDefinition("ack_complete");
        route.adviceWith(camelContext.adapt(ModelCamelContext.class), new RouteBuilder() {
            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("direct:ge.apm.asset.ingestion.dto.ack.dto.ack.complete").to("mock:complete")
                    .skipSendToOriginalEndpoint();
            }
        });
        route = camelContext.getRouteDefinition("download_ack_complete");
        route.adviceWith(camelContext.adapt(ModelCamelContext.class), new RouteBuilder() {
            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("direct:ge.apm.asset.download.task.ack.download.task.ack.complete").to(
                    "mock:download.complete").skipSendToOriginalEndpoint();
            }
        });
    }

    //@Test
    public void testDeadLetter_Positive() throws Exception {
        Exchange defaultExchange = new DefaultExchange(camelContext);
        producerTemplate.send("direct:dto.dead.letter", defaultExchange);
        unmarshalBody(defaultExchange);
        assertNull(defaultExchange.getIn().getBody());
    }

    //@Test
    public void testDeadLetter_DependencyViolationException() throws Exception {
        Exchange defaultExchange = new DefaultExchange(camelContext);
        DependencyViolationException dependencyViolationException = new DependencyViolationException(
            "dependency violation exception", null);
        defaultExchange.setProperty(Exchange.EXCEPTION_CAUGHT, dependencyViolationException);
        producerTemplate.send("direct:dto.dead.letter", defaultExchange);
        unmarshalBody(defaultExchange);
        assertEquals(defaultExchange.getIn().getBody(ServiceException.class).toString(),
            new AssetServiceException(dependencyViolationException.getMessage()).toString());
        assertTrue(validateRoutingKey(defaultExchange, "dto.ack.error"));
    }

    //@Test
    public void testDeadLetter_ServiceException() throws Exception {
        Exchange defaultExchange = new DefaultExchange(camelContext);
        ServiceException serviceException = new ServiceException("service exception");
        defaultExchange.setProperty(Exchange.EXCEPTION_CAUGHT, serviceException);
        producerTemplate.send("direct:dto.dead.letter", defaultExchange);
        unmarshalBody(defaultExchange);
        assertEquals(defaultExchange.getIn().getBody(ServiceException.class).toString(),
            new AssetServiceException("service exception").toString());
        assertTrue(validateRoutingKey(defaultExchange, "dto.ack.error"));
    }

    //@Test
    public void testDeadLetter_Exception() throws Exception {
        Exchange defaultExchange = new DefaultExchange(camelContext);
        Exception exception = new Exception("exception");
        defaultExchange.setProperty(Exchange.EXCEPTION_CAUGHT, exception);
        producerTemplate.send("direct:dto.dead.letter", defaultExchange);
        unmarshalBody(defaultExchange);
        assertEquals(defaultExchange.getIn().getBody(ServiceException.class).toString(),
            "[E10000] com.ge.apm.common.exception.ServiceException: A general system error has " + "occurred.");
        assertTrue(validateRoutingKey(defaultExchange, "dto.ack.error"));
    }

    //@Test
    public void testCompleted() throws Exception {
        Exchange defaultExchange = new DefaultExchange(camelContext);
        producerTemplate.send("direct:ge.apm.asset.dto.ack.complete", defaultExchange);
        unmarshalBody(defaultExchange);
        assertTrue(validateRoutingKey(defaultExchange, "dto.ack.complete"));
    }

    @Test
    public void testMain_Positive_DtoProcessor() throws Exception {
        RouteDefinition route = camelContext.getRouteDefinition("retry_or_process");
        route.adviceWith(camelContext.adapt(ModelCamelContext.class), new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                weaveByType(BeanDefinition.class).selectLast().remove();
            }
        });

        MockEndpoint mockEndpoint = camelContext.getEndpoint("mock:complete", MockEndpoint.class);
        mockEndpoint.expectedHeaderReceived(RabbitMQConstants.ROUTING_KEY, "dto.ack.complete");
        Exchange defaultExchange = new DefaultExchange(camelContext);
        defaultExchange.getIn().setBody("test");
        marshalBody(defaultExchange);
        producerTemplate.send(assetRouteBuilder.getRabbitmqEndpoint("ge.apm.asset.ingestion.dto", "dto.in"),
            defaultExchange);
        mockEndpoint.assertIsSatisfied();
    }

    @Test
    public void testMain_Positive_DownloadProcessor() throws Exception {
        RouteDefinition route = camelContext.getRouteDefinition("download_in");
        route.adviceWith(camelContext.adapt(ModelCamelContext.class), new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                weaveByType(BeanDefinition.class).selectLast().remove();
            }
        });

        MockEndpoint mockEndpoint = camelContext.getEndpoint("mock:download.complete", MockEndpoint.class);
        mockEndpoint.expectedHeaderReceived(RabbitMQConstants.ROUTING_KEY, "download.task.ack.complete");
        Exchange defaultExchange = new DefaultExchange(camelContext);
        String taskUUID = UUID.randomUUID().toString();
        DownloadTask task = new DownloadTask();
        task.setTaskUuid(taskUUID);
        defaultExchange.getIn().setHeader(MessageConstants.ASSET_DOWNLOAD_TYPE, "classifications");
        defaultExchange.getIn().setHeader(MessageConstants.TASK_UUID, taskUUID);
        defaultExchange.getIn().setBody(task);
        marshalToGson(defaultExchange);
        producerTemplate.send(
            assetRouteBuilder.getRabbitmqEndpoint("ge.apm.asset.download.task", "asset.download.task"),
            defaultExchange);
        mockEndpoint.assertIsSatisfied();
        mockEndpoint.expectedBodiesReceived(task);
    }

    @Test
    public void testMain_Positive_TagProcessor() throws Exception {
        RouteDefinition route = camelContext.getRouteDefinition("retry_or_process");
        route.adviceWith(camelContext.adapt(ModelCamelContext.class), new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                weaveByType(BeanDefinition.class).selectFirst().remove();
            }
        });
        MockEndpoint mockEndpoint = camelContext.getEndpoint("mock:complete", MockEndpoint.class);
        mockEndpoint.expectedHeaderReceived(RabbitMQConstants.ROUTING_KEY, "dto.ack.complete");
        Exchange defaultExchange = new DefaultExchange(camelContext);
        defaultExchange.getIn().setHeader("ApmAssetPrefix", "/tags");
        marshalBody(defaultExchange);
        producerTemplate.send(assetRouteBuilder.getRabbitmqEndpoint("ge.apm.asset.ingestion.dto", "dto.in"),
            defaultExchange);
        mockEndpoint.assertIsSatisfied();
    }

    @Test
    public void testMain_Positive_GroupProcessor() throws Exception {
        RouteDefinition route = camelContext.getRouteDefinition("retry_or_process");
        route.adviceWith(camelContext.adapt(ModelCamelContext.class), new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                weaveByType(BeanDefinition.class).selectIndex(1).remove();
            }
        });
        MockEndpoint mockEndpoint = camelContext.getEndpoint("mock:complete", MockEndpoint.class);
        mockEndpoint.expectedHeaderReceived(RabbitMQConstants.ROUTING_KEY, "dto.ack.complete");
        Exchange defaultExchange = new DefaultExchange(camelContext);
        defaultExchange.getIn().setHeader("ApmAssetPrefix", "/assetGroups");
        marshalBody(defaultExchange);
        producerTemplate.send(assetRouteBuilder.getRabbitmqEndpoint("ge.apm.asset.ingestion.dto", "dto.in"),
            defaultExchange);
        mockEndpoint.assertIsSatisfied();
    }

    @Test
    public void testMain_Positive_GroupAssociationProcessor() throws Exception {
        RouteDefinition route = camelContext.getRouteDefinition("retry_or_process");
        route.adviceWith(camelContext.adapt(ModelCamelContext.class), new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                weaveByType(BeanDefinition.class).selectIndex(2).remove();
            }
        });
        MockEndpoint mockEndpoint = camelContext.getEndpoint("mock:complete", MockEndpoint.class);
        mockEndpoint.expectedHeaderReceived(RabbitMQConstants.ROUTING_KEY, "dto.ack.complete");
        Exchange defaultExchange = new DefaultExchange(camelContext);
        defaultExchange.getIn().setHeader("ApmAssetPrefix", "/groupAssociations");
        marshalBody(defaultExchange);
        producerTemplate.send(assetRouteBuilder.getRabbitmqEndpoint("ge.apm.asset.ingestion.dto", "dto.in"),
            defaultExchange);
        mockEndpoint.assertIsSatisfied();
    }

    @Test
    public void testMain_Positive_TemplateProcessor() throws Exception {
        RouteDefinition route = camelContext.getRouteDefinition("retry_or_process");
        route.adviceWith(camelContext.adapt(ModelCamelContext.class), new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                weaveByType(BeanDefinition.class).selectIndex(3).remove();
            }
        });
        MockEndpoint mockEndpoint = camelContext.getEndpoint("mock:complete", MockEndpoint.class);
        mockEndpoint.expectedHeaderReceived(RabbitMQConstants.ROUTING_KEY, "dto.ack.complete");
        Exchange defaultExchange = new DefaultExchange(camelContext);
        defaultExchange.getIn().setHeader("ApmAssetPrefix", "/assetTemplates");
        marshalBody(defaultExchange);
        producerTemplate.send(assetRouteBuilder.getRabbitmqEndpoint("ge.apm.asset.ingestion.dto", "dto.in"),
            defaultExchange);
        mockEndpoint.assertIsSatisfied();
    }

    //@Test
    public void testRetry() throws Exception {
        RouteDefinition route = camelContext.getRouteDefinition("retry");
        route.adviceWith(camelContext.adapt(ModelCamelContext.class), new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("direct:ge.apm.asset.retry.or.process").to("mock:result")
                    .skipSendToOriginalEndpoint();
            }
        });
        MockEndpoint mockEndpoint = camelContext.getEndpoint("mock:result", MockEndpoint.class);
        mockEndpoint.expectedBodiesReceived("retry payload");
        Exchange defaultExchange = new DefaultExchange(camelContext);
        defaultExchange.getIn().setBody("retry payload");
        marshalBody(defaultExchange);
        producerTemplate.send("vm:retry", defaultExchange);
        mockEndpoint.assertIsSatisfied();
    }

    @Test
    public void testRecoverable_Positive_Requeue() throws Exception {
        RouteDefinition route = camelContext.getRouteDefinition("recovery");
        route.adviceWith(camelContext.adapt(ModelCamelContext.class), new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("direct:ge.apm.asset.ingestion.dto.dto.in").to("mock:dto.in")
                    .skipSendToOriginalEndpoint();
                interceptSendToEndpoint("vm:retry?waitForTaskToComplete=Never").to("mock:retry")
                    .skipSendToOriginalEndpoint();
            }
        });
        Exchange defaultExchange = new DefaultExchange(camelContext);
        MockEndpoint dtoEndpoint = camelContext.getEndpoint("mock:dto.in", MockEndpoint.class);
        MockEndpoint retryEndpoint = camelContext.getEndpoint("mock:retry", MockEndpoint.class);
        producerTemplate.send("direct:handle.recovery", defaultExchange);
        Long time = defaultExchange.getIn().getHeader(MessageConstants.TASK_STARTTIME, Long.class);
        dtoEndpoint.expectedHeaderReceived(MessageConstants.TASK_STARTTIME, time);
        retryEndpoint.expectedHeaderReceived(MessageConstants.TASK_STARTTIME, time);
        dtoEndpoint.assertIsSatisfied();
        retryEndpoint.assertIsSatisfied();
    }

    private Object unmarshalBody(Exchange exchange) throws Exception {
        byte[] unzipped = (byte[]) camelContext.resolveDataFormat(zipData.getDataFormatName()).unmarshal(exchange,
            null);
        Object deserialized = camelContext.resolveDataFormat(serializationDataFormat.getDataFormatName()).unmarshal(
            exchange, new ByteArrayInputStream(unzipped));
        exchange.getIn().setBody(deserialized);
        return deserialized;
    }

    private Object marshalBody(Exchange exchange) throws Exception {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        camelContext.resolveDataFormat(serializationDataFormat.getDataFormatName()).marshal(exchange,
            exchange.getIn().getBody(), byteArrayOutputStream);
        exchange.getIn().setBody(byteArrayOutputStream.toByteArray());
        byteArrayOutputStream = new ByteArrayOutputStream();
        camelContext.resolveDataFormat(zipData.getDataFormatName()).marshal(exchange, exchange.getIn().getBody(),
            byteArrayOutputStream);
        exchange.getIn().setBody(byteArrayOutputStream.toByteArray());
        return exchange.getIn().getBody();
    }

    private Object marshalToGson(Exchange exchange) throws Exception {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        gsonDataFormat.marshal(exchange, exchange.getIn().getBody(), byteArrayOutputStream);
        exchange.getIn().setBody(byteArrayOutputStream.toByteArray());
        return exchange.getIn().getBody();
    }

    private boolean validateRoutingKey(Exchange exchange, String routingKey) {
        return exchange.getIn().getHeader(RabbitMQConstants.ROUTING_KEY).equals(routingKey);
    }
}
