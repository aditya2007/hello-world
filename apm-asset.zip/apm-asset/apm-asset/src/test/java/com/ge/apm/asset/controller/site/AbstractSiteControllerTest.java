/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.site;

import java.text.ParseException;

import org.junit.Before;

import com.ge.apm.asset.api.base.AbstractInstanceControllerTest;
import com.ge.apm.asset.controller.SiteController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.ObjectInfo;
import com.ge.apm.asset.model.Segment;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.SiteType;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.util.ReflectionUtils;

public abstract class AbstractSiteControllerTest extends AbstractInstanceControllerTest<SiteController, Site> {

    protected SiteController siteController;

    public AbstractSiteControllerTest() {
        // define an explicit constructor
    }

    protected AbstractSiteControllerTest(boolean accessControlledTest) {
        super(accessControlledTest);
    }

    public Class<SiteType> getTypeClass() {
        return SiteType.class;
    }

    @Override
    public Class<Site> getObjectClass() {
        return Site.class;
    }

    @Override
    public SiteController getController() {
        return siteController;
    }

    @Override
    public String getTypePrefix() {
        return Prefixes.SiteTypes;
    }

    @Override
    public String getPrefix() {
        return Prefixes.Sites;
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        siteController = new SiteController();
        ReflectionUtils.setField(SiteController.class, siteController, "service", assetService);
        ReflectionUtils.setField(SiteController.class, siteController, "assetConfigService", assetConfigService);
        ReflectionUtils.setField(SiteController.class, siteController, "pageSize", 10);
        //Mockito.when(siteController.getAssetTagService()).thenReturn(assetTagService);

    }

    public ObjectInfo[] getChildrenInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.Sites, "childSites.json", Site.class), new ObjectInfo(
            Prefixes.Segments, "childSegments.json", Segment.class), new ObjectInfo(Prefixes.Assets, "childAssets.json",
            Asset.class) };
    }

    public ObjectInfo[] getParentInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.Enterprises, "parentEnterprise.json", Enterprise.class) };
    }
}
