/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.templateConnection;

import java.io.IOException;
import java.lang.reflect.Array;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatcher;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import com.ge.apm.asset.api.base.AbstractControllerTest;
import com.ge.apm.asset.controller.EquipmentInstanceController;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.AssetPlaceholderConnection;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.EquipmentInstanceConnection;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.Placeholder;
import com.ge.apm.asset.model.PlaceholderAssetTypeAssociation;
import com.ge.apm.asset.model.TagExpression;
import com.ge.apm.asset.model.Template;
import com.ge.apm.asset.model.TemplateConnection;
import com.ge.apm.asset.model.TemplateInfo;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.mq.factory.ControllerFactory;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.api.IAssetService;
import com.ge.apm.asset.service.impl.EquipmentInstanceService;
import com.ge.apm.asset.service.util.EquipmentInstanceConformanceChecker;
import com.ge.apm.asset.service.util.EquipmentInstanceCreationHelper;
import com.ge.apm.asset.service.util.EquipmentInstanceUtil;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.json.patch.AddOperation;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;
import com.ge.apm.util.ResourceUtil;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.validator.ValidationResult;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.argThat;
import static org.mockito.Matchers.eq;
import static org.powermock.api.mockito.PowerMockito.when;

@Slf4j
@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class})
public class EquipmentInstanceControllerTest
    extends AbstractControllerTest<EquipmentInstanceController, TemplateConnection> {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    @Mock
    ControllerFactory controllerFactory;

    @InjectMocks
    @Autowired
    private EquipmentInstanceController equipmentInstanceController;

    @InjectMocks
    @Autowired
    private EquipmentInstanceService equipmentInstanceService;

    /*@Mock
    private AlmTemplatePersistenceService almTemplatePersistenceService;*/

    @Captor
    private ArgumentCaptor<String> deleteUris;

    @Captor
    private ArgumentCaptor<PatchOperation[]> deleteEquipments;

    @Mock
    private IAssetService assetService;

    private EquipmentInstanceCreationHelper equipmentInstanceCreationHelper = new EquipmentInstanceCreationHelper();

    private EquipmentInstanceUtil equipmentInstanceUtil = new EquipmentInstanceUtil();

    @Mock
    private EquipmentInstanceConformanceChecker equipmentInstanceConformanceChecker;

    public String getInputPath() {
        return "/../test-data/input" + getPrefix();
    }

    public String getPredixPath() {
        return "/predix" + getPrefix();
    }

    public String getOutputPath() {
        return "/../test-data/output" + getPrefix();
    }

    public <X> X[] readObjectsFromResourceFile(String filePath, Class<X> clazz) throws IOException {
        boolean isReadFileFromShareTestDataFolder = filePath.contains("/test-data/");
        if (isReadFileFromShareTestDataFolder) {
            String content = ResourceUtil.readFromRelativeToModuleDirFileAsString(filePath);
            return MAPPER.reader(Array.newInstance(clazz, 0).getClass()).readValue(content);
        } else {
            return MAPPER.reader(Array.newInstance(clazz, 0).getClass()).readValue(
                this.getClass().getResourceAsStream(filePath));
        }
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();

        ReflectionUtils.setField(EquipmentInstanceController.class, equipmentInstanceController, "service",
            equipmentInstanceService);

        ReflectionUtils.setField(EquipmentInstanceService.class, equipmentInstanceService, "equipmentInstanceUtil",
            equipmentInstanceUtil);
        ReflectionUtils.setField(EquipmentInstanceService.class, equipmentInstanceService,
            "equipmentInstanceCreationHelper", equipmentInstanceCreationHelper);

        ReflectionUtils.setField(EquipmentInstanceService.class, equipmentInstanceService,
            "equipmentInstanceConformanceChecker", equipmentInstanceConformanceChecker);
        ReflectionUtils.setField(EquipmentInstanceService.class, equipmentInstanceService, "almPersistenceService",
            almPersistenceService);

        ReflectionUtils.setField(EquipmentInstanceCreationHelper.class, equipmentInstanceCreationHelper,
            "equipmentInstanceUtil", equipmentInstanceUtil);
        ReflectionUtils.setField(EquipmentInstanceCreationHelper.class, equipmentInstanceCreationHelper,
            "almPersistenceService", almPersistenceService);

        ReflectionUtils.setField(EquipmentInstanceUtil.class, equipmentInstanceUtil, "almPersistenceService",
            almPersistenceService);
    }

    @Override
    public Class<TemplateConnection> getObjectClass() {
        return TemplateConnection.class;
    }

    @Override
    public EquipmentInstanceController getController() {
        return equipmentInstanceController;
    }

    @Override
    public String getTypePrefix() {
        return null;
    }

    @Override
    public String getPrefix() {
        return Prefixes.equipmentInstances;
    }

    //TODO - Ignoring tests as template feature is disabled for Q2 2017 release

    @Test
    public void testCreateEquipmentInstances() throws Exception {

        EquipmentInstanceConnection[] templateConnections = readObjectsFromResourceFile(
            getInputPath() + "/equipmentInstance.json", EquipmentInstanceConnection.class);

        Template[] template = readObjectsFromResourceFile(getInputPath() + "/template.json", Template.class);

        mockForCreateEquipment(template[0], templateConnections[0].getTemplateSourceKey());

        Mockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(), eq(Prefixes.MeasurementTags),
            eq(MeasurementTag.class), any());

        MeasurementTagType tagType1 = new MeasurementTagType();
        tagType1.setSourceKey("PN05-TAG");
        tagType1.setUri("/tagTypes/PN05-TAG");
        MeasurementTagType tagType2 = new MeasurementTagType();
        tagType2.setSourceKey("PN06-TAG");
        tagType2.setUri("/tagTypes/PN06-TAG");
        MeasurementTagType[] tagTypes;
        tagTypes = new MeasurementTagType[]{tagType1, tagType2};

        Mockito.doReturn(tagTypes).when(almPersistenceService).getBySourceKeys(anyString(),
                eq(Prefixes.MeasurementTagTypes), eq(MeasurementTagType.class), any());

        setConformanceChecker();

        Asset[] connectedAssets = equipmentInstanceController.createEquipmentInstances(templateConnections[0], null,
            false);

        Asset[] expectedAssets = readObjectsFromResourceFile(getOutputPath() + "/equipmentInstance.json", Asset.class);

        Assert.assertArrayEquals(expectedAssets, connectedAssets);
    }

    public void setConformanceChecker() throws IllegalAccessException {
        EquipmentInstanceConformanceChecker checker = new EquipmentInstanceConformanceChecker();
        ReflectionUtils.setField(EquipmentInstanceService.class, equipmentInstanceService,
            "equipmentInstanceConformanceChecker", checker);
        ReflectionUtils.setField(EquipmentInstanceConformanceChecker.class, checker, "equipmentInstanceUtil",
            equipmentInstanceUtil);
        ReflectionUtils.setField(EquipmentInstanceConformanceChecker.class, checker, "almPersistenceService",
            almPersistenceService);
    }

    @Test(expected = BadRequestException.class)
    public void testCreateTemplateConnectionsValidateTags() throws Exception {

        EquipmentInstanceConnection[] templateConnections = readObjectsFromResourceFile(
            getInputPath() + "/equipmentInstance.json", EquipmentInstanceConnection.class);

        Template[] template = readObjectsFromResourceFile(getInputPath() + "/template.json", Template.class);

        mockForCreateEquipment(template[0], templateConnections[0].getTemplateSourceKey());

        TagExpression expression = new TagExpression();
        expression.setIdExpr("{ASSET.ID}.{TAG_TYPE.ID}.{range}");
        expression.setNameExpr("{ASSET.NAME}.{TAG_TYPE.NAME}");
        expression.setTimeSeriesLinkExpr("{ASSET.ID}.{TAG_TYPE.ID}");
        expression.setRange("[1 - 4]");
        template[0].getPlaceholders().get(0).getTagTypeAssociations().get(0).getTagExpressions().add(expression);

        try {
            setConformanceChecker();
            equipmentInstanceController.createEquipmentInstances(templateConnections[0], null, false);
        } catch (Exception ex) {
            Assert.assertEquals(ErrorProvider
                .findMessage(ErrorConstants.TAG_EXPRESSION_DUPLICATE_TAG, "[PART05.PN05-TAG.1, " + "PART05.PN05-TAG.2]",
                    "PART05"), ex.getMessage());
            throw ex;
        }
    }

    @Test
    public void testCreateTemplateConnectionsValidateExistingTag() throws Exception {
        Template[] template = readObjectsFromResourceFile(getInputPath() + "/template.json", Template.class);

        EquipmentInstanceConnection[] templateConnections = readObjectsFromResourceFile(
            getInputPath() + "/equipmentInstance.json", EquipmentInstanceConnection.class);

        mockForCreateEquipment(template[0], templateConnections[0].getTemplateSourceKey());

        MeasurementTag tag = new MeasurementTag();
        tag.setSourceKey("PART05.PN05-TAG.1");
        MeasurementTag[] tags = new MeasurementTag[2];
        tags[0] = tag;
        tag = new MeasurementTag();
        tag.setSourceKey("PART05.PN05-TAG.2");
        tags[1] = tag;

        Asset[] expectedAssets = readObjectsFromResourceFile(getOutputPath() + "/equipmentInstance.json", Asset.class);
        List<String> tagSrcKeys = Arrays.stream(expectedAssets).map(a -> a.getMeasurementTags()).flatMap(
            m -> Arrays.stream(m)).map(t -> t.getSourceKey()).collect(Collectors.toList());
        String[] sourceKeys = tagSrcKeys.stream().toArray(String[]::new);

        Mockito.doReturn(tags).when(almPersistenceService).getBySourceKeys(anyString(), eq(Prefixes.MeasurementTags),
            eq(MeasurementTag.class), eq(sourceKeys));

        try {
            setConformanceChecker();
            equipmentInstanceController.createEquipmentInstances(templateConnections[0], null, false);
        } catch (Exception ex) {
            Assert.assertEquals(ErrorProvider
                    .findMessage(ErrorConstants.TAG_EXPRESSION_EXISTING_TAG, "[PART05.PN05-TAG.1, PART05.PN05-TAG.2]"),
                ex.getMessage());
            throw ex;
        }
    }

    @Test(expected = BadRequestException.class)
    public void testUpdateEquipmentInstance() throws Exception {
        PatchOperation po = new PatchOperation("add", "/placeholders/PPN02",
            (Object) ("SMS1-ASSET-11091E-1b").getClass());
        /*PatchOperation[] pos;
        pos = new PatchOperation[] {po};*/
        Asset asset = new Asset();
        asset.setSourceKey("anySourceKey");
        Asset[] assets = new Asset[1];
        assets[0] = asset;
        TemplateInfo templateInfo = new TemplateInfo();
        templateInfo.setTemplateUri("template_uri");
        templateInfo.setPlaceholderId("PPN01");
        asset.setTemplateInfo(templateInfo);
        Mockito.doReturn(asset).when(almPersistenceService).getAssetByUUid(any(), any());
        Template template = new Template();
        template.setUri("template_uri");
        template.setRevision("published");
        Mockito.doReturn(template).when(almTemplatePersistenceService).getTemplateById(any(), any());

        /*Mockito.doReturn(assets).when(almPersistenceService).getBySourceKeys(any(), any(), Asset.class,
            eq(new String[]{asset.getSourceKey()}));*/
        Mockito.doReturn(assets).when(almPersistenceService).getBySourceKeys(any(), any(), eq(Asset.class), any());
        equipmentInstanceController.updateEquipmentInstance("any-uuid", false, po);
    }

    @Test
    public void testUpdateDecommissionedEquipmentInstance() throws Exception {
        try {
            PatchOperation po = new PatchOperation("add", "/placeholders/PPN02", ("SMS1-ASSET-11091E-1b").getClass());
        /*PatchOperation[] pos;
        pos = new PatchOperation[] {po};*/
            Asset asset = new Asset();
            asset.setSourceKey("anySourceKey");
            Map<String, Object> reservedAttrs = new HashMap<>();
            Map<String, Object> keyValuemap = new HashMap<>();
            keyValuemap.put("key", "10");
            reservedAttrs.put("state", keyValuemap);
            asset.setReservedAttributes(reservedAttrs);
            Asset[] assets = new Asset[1];
            assets[0] = asset;
            TemplateInfo templateInfo = new TemplateInfo();
            templateInfo.setTemplateUri("template_uri");
            templateInfo.setPlaceholderId("PPN01");
            asset.setTemplateInfo(templateInfo);
            Mockito.doReturn(asset).when(almPersistenceService).getAssetByUUid(any(), any());
            Template template = new Template();
            template.setUri("template_uri");
            template.setRevision("published");
            Mockito.doReturn(template).when(almTemplatePersistenceService).getTemplateById(any(), any());

            Mockito.doReturn(assets).when(almPersistenceService).getBySourceKeys(any(), any(), eq(Asset.class), any());
            equipmentInstanceController.updateEquipmentInstance("any-uuid", false, po);
        } catch (Exception ex) {
            Assert.assertTrue(ex instanceof BadRequestException);
            Assert.assertEquals(ErrorConstants.INVALID_EQUIPMENT_INSTANCE_UPDATE_WITH_DECOMMISSIONED_ASSET,
                ((BadRequestException) ex).getCode());
        }
    }

    @Test(expected = BadRequestException.class)
    public void testUpdateEquipmentInstanceRefactor() throws Exception {
        String value = "SMS1-ASSET-11091E-1b";
        PatchOperation po = new PatchOperation("add", "/placeholders/PPN02", (Object) value);
        /*PatchOperation[] pos;
        pos = new PatchOperation[] {po};*/
        Asset asset = new Asset();
        asset.setSourceKey("anySourceKey");
        Asset[] assets = new Asset[1];
        assets[0] = asset;
        TemplateInfo templateInfo = new TemplateInfo();
        templateInfo.setTemplateUri("template_uri");
        templateInfo.setPlaceholderId("PPN01");
        asset.setTemplateInfo(templateInfo);
        Mockito.doReturn(asset).when(almPersistenceService).getAssetByUUid(any(), any());
        Template template = new Template();
        template.setUri("template_uri");
        template.setRevision("published");
        Mockito.doReturn(template).when(almTemplatePersistenceService).getTemplateById(any(), any());

        /*Mockito.doReturn(assets).when(almPersistenceService).getBySourceKeys(any(), any(), Asset.class,
            eq(new String[]{asset.getSourceKey()}));*/
        Mockito.doReturn(assets).when(almPersistenceService).getBySourceKeys(any(), any(), eq(Asset.class), any());
        equipmentInstanceController.updateEquipmentInstance("any-uuid", false, po);
    }

    @Test
    public void testRemoveEquipmentInstances() throws Exception {

        PatchOperation[] templateConnections = readObjectsFromResourceFile(
            getInputPath() + "/deleteEquipmentInstance.json", PatchOperation.class);

        mockForDeleteEquipment();

        Mockito.doNothing().when(assetService).updateWithoutValidationOnEquipmentInstance(deleteUris.capture(), deleteEquipments.capture(),
            eq(Asset.class));

        QueryPredicate queryPredicate = new QueryPredicate();
        Asset asset1 = new Asset();
        asset1.setSourceKey("Part06");
        asset1.setParent("/assets/Part05");
        asset1.setUri("/assets/PART06");
        TemplateInfo templateInfo1 = new TemplateInfo();
        templateInfo1.setTemplateUri("/assetTemplates/template1");
        templateInfo1.setPlaceholderId("PPN06");
        asset1.setTemplateInfo(templateInfo1);
        Asset asset2 = new Asset();
        asset2.setSourceKey("Part05");
        Asset[] assetHierarchy = { asset1 };

        mockFindByPrefixQuery(() -> assetHierarchy, "parent->sourceKey=PART05:templateInfo.templateUri=/assetTemplates/template1");
        mockFindByPrefixQuery(() -> new Asset[]{}, "parent->sourceKey=PART05:templateInfo.embeddedTemplateUri=/assetTemplates/template1");
        mockFindByPrefixQuery(() -> new Asset[]{}, "parent->sourceKey=Part06:templateInfo.templateUri=/assetTemplates/template1");
        mockFindByPrefixQuery(() -> new Asset[]{}, "parent->sourceKey=Part06:templateInfo.embeddedTemplateUri=/assetTemplates/template1");

        equipmentInstanceController.updateEquipmentInstance("PART05", false, templateConnections);

        PatchOperation patch1 = new AddOperation("/parent", null);
        PatchOperation patch2 = new AddOperation("/templateInfo", null);
        PatchOperation[] operations = { patch1, patch2 };

        Assert.assertEquals(Arrays.asList("/assets/PART06"), deleteUris.getAllValues());
        Assert.assertArrayEquals(operations, deleteEquipments.getAllValues().get(0));
    }

    private void mockForCreateEquipment(Template toBeReturned, String templateId) throws IOException {
        Mockito.doReturn(toBeReturned).when(almPersistenceService).getBySourceKey(any(), any(), eq(Prefixes.Templates),
            eq(Template.class), eq(templateId));

        Asset[] inAssets = readObjectsFromResourceFile(getInputPath() + "/assets.json", Asset.class);

        Arrays.stream(inAssets).forEach(asset -> {
            Mockito.doReturn(asset).when(almPersistenceService).getBySourceKey(any(), any(), eq(Prefixes.Assets),
                eq(Asset.class), eq(asset.getSourceKey()));
        });

        Asset[] assets = Arrays.stream(inAssets).toArray(Asset[]::new);
        Mockito.doReturn(assets).when(almPersistenceService).getBySourceKeys(any(), eq(Prefixes.Assets),
            eq(Asset.class), any());

        MeasurementTagType[] tagTypes = readObjectsFromResourceFile(getInputPath() + "/tagTypes.json",
            MeasurementTagType.class);

        Arrays.stream(tagTypes).forEach(type -> {
            Mockito.doReturn(type).when(almPersistenceService).getTypeByUri(anyString(), eq(type.getUri()));
            Mockito.doReturn(type).when(almPersistenceService).getBySourceKey(any(), any(),
                eq(Prefixes.MeasurementTagTypes), eq(MeasurementTagType.class), eq(type.getSourceKey()));
        });
    }

    private void mockForDeleteEquipment() throws IOException {

        Template[] template = readObjectsFromResourceFile(getInputPath() + "/template.json", Template.class);
        String templateUuid = template[0].getUri().split("/")[2];
        Mockito.doReturn(template[0]).when(almTemplatePersistenceService).getTemplateById(any(), eq(templateUuid));

        Asset[] outAssets = readObjectsFromResourceFile(getOutputPath() + "/equipmentInstance.json", Asset.class);

        Arrays.stream(outAssets).forEach(asset -> {
            Mockito.doReturn(asset).when(almPersistenceService).getInstanceByUri(any(), eq(asset.getUri()), eq(false));
            String uuid = asset.getUri().split("/")[2];
            Mockito.doReturn(asset).when(almPersistenceService).getAssetByUUid(anyString(), eq(uuid));
        });

        mockFindByPrefixQuery(() -> new Asset[] { outAssets[1] }, "parent->sourceKey=PART05:templateInfo"
            + ".templateUri=/assetTemplates/template1:templateInfo.placeholderId=PPN06");
        mockFindByPrefixQuery(() -> new Asset[0],
            "parent->sourceKey=PART06:" + "templateInfo.templateUri=/assetTemplates/template1");
        mockFindByPrefixQuery(() -> new Asset[0],
            "parent->sourceKey=PART06:" + "templateInfo.embeddedTemplateUri=/assetTemplates/template1");
    }

    private void mockFindByPrefixQuery(Supplier<Asset[]> supplier, final String query1) {
        Mockito.doReturn(supplier.get()).when(almPersistenceService).findAllByPrefix(anyString(), anyString(),
            argThat(new ArgumentMatcher<QueryPredicate>() {
                @Override
                public boolean matches(Object o) {
                    return ((QueryPredicate) o).getQuery().get().equals(query1);
                }
            }), eq(Asset.class), eq(false), anyBoolean());
    }

    private void mockAssociations(List<Placeholder> placeholders) {
        if (CollectionUtils.isEmpty(placeholders)) {
            return;
        }
        for (Placeholder placeholder : placeholders) {
            if (!CollectionUtils.isEmpty(placeholder.getAssetTypeAssociations())) {
                List<PlaceholderAssetTypeAssociation> associations = placeholder.getAssetTypeAssociations();
                associations.stream().filter(a -> a.getEntityUri().startsWith(Prefixes.AssetTypes)).forEach(a -> {
                    AssetType type = new AssetType();
                    type.setSourceKey(a.getEntityUri().split("/")[2]);
                    when(almPersistenceService.getTypeByUri(anyString(), eq(a.getEntityUri()))).thenReturn(type);
                });
            }
            mockAssociations(placeholder.getPlaceholders());
        }
    }

    @Test
    public void testAddEquipmentInstancesWithNonExistingAndDecommissionedAssets() throws Exception {
        try {
            EquipmentInstanceConnection eic = new EquipmentInstanceConnection();
            eic.setTemplateSourceKey("sample_template1");
            List<AssetPlaceholderConnection> connections = new ArrayList<>();
            AssetPlaceholderConnection connection1 = new AssetPlaceholderConnection();
            connection1.setAssetSourceKey("asset-id1");
            connection1.setPlaceholderId("uuid-00001");
            connections.add(connection1);
            AssetPlaceholderConnection connection2 = new AssetPlaceholderConnection();
            connection2.setAssetSourceKey("asset-id2");
            connection2.setPlaceholderId("uuid-00002");
            connections.add(connection2);
            AssetPlaceholderConnection connection3 = new AssetPlaceholderConnection();
            connection3.setAssetSourceKey("asset-id3");
            connection3.setPlaceholderId("uuid-00003");
            connections.add(connection3);
            eic.setConnections(connections);
            Asset asset1 = new Asset();
            asset1.setSourceKey("asset-id1");
            Map<String, Object> reservedAttrs = new HashMap<>();
            Map<String, Object> keyValuemap = new HashMap<>();
            keyValuemap.put("key", "10");
            reservedAttrs.put("state", keyValuemap);
            asset1.setReservedAttributes(reservedAttrs);
            List<Asset> assets = new ArrayList<>();
            assets.add(asset1);
            Asset asset2 = new Asset();
            asset2.setSourceKey("asset-id2");
            assets.add(asset2);

            Template[] templates = readObjectsFromResourceFile("/../test-data/input/assetTemplates/create.json",
                Template.class);
            Mockito.doReturn(templates[0]).when(almPersistenceService).getBySourceKey(anyString(), anyString(),
                anyString(), eq(Template.class), anyString());
            Mockito.doReturn(assets.toArray(new Asset[assets.size()])).when(almPersistenceService).getBySourceKeys(
                anyString(), anyString(), eq(Asset.class), any());
            Asset[] connectedAssets = equipmentInstanceController.createEquipmentInstances(eic, "add", false);
        } catch (Exception ex) {
            Assert.assertTrue(ex instanceof BadRequestException);
            Assert.assertEquals(ErrorConstants.INVALID_EQUIPMENT_INSTANCE_WITH_NON_EXISTENCE_AND_DECOMMISSIONED_ASSET,
                ((BadRequestException) ex).getCode());
        }
    }

    @Test
    public void testAddEquipmentInstancesWithDecommissionedAssets() throws Exception {
        try {
            EquipmentInstanceConnection eic = new EquipmentInstanceConnection();
            eic.setTemplateSourceKey("sample_template1");
            List<AssetPlaceholderConnection> connections = new ArrayList<>();
            AssetPlaceholderConnection connection1 = new AssetPlaceholderConnection();
            connection1.setAssetSourceKey("asset-id1");
            connection1.setPlaceholderId("uuid-00001");
            connections.add(connection1);
            AssetPlaceholderConnection connection2 = new AssetPlaceholderConnection();
            connection2.setAssetSourceKey("asset-id2");
            connection2.setPlaceholderId("uuid-00002");
            connections.add(connection2);
            AssetPlaceholderConnection connection3 = new AssetPlaceholderConnection();
            connection3.setAssetSourceKey("asset-id3");
            connection3.setPlaceholderId("uuid-00003");
            connections.add(connection3);
            eic.setConnections(connections);
            Map<String, Object> reservedAttrs = new HashMap<>();
            Map<String, Object> keyValuemap = new HashMap<>();
            keyValuemap.put("key", "10");
            reservedAttrs.put("state", keyValuemap);
            Asset asset1 = new Asset();
            asset1.setSourceKey("asset-id1");
            asset1.setReservedAttributes(reservedAttrs);
            List<Asset> assets = new ArrayList<>();
            assets.add(asset1);
            Asset asset2 = new Asset();
            asset2.setSourceKey("asset-id2");
            asset2.setReservedAttributes(reservedAttrs);
            assets.add(asset2);
            Asset asset3 = new Asset();
            asset3.setSourceKey("asset-id3");
            asset3.setReservedAttributes(reservedAttrs);
            assets.add(asset3);

            Template[] templates = readObjectsFromResourceFile("/../test-data/input/assetTemplates/create.json",
                Template.class);
            Mockito.doReturn(templates[0]).when(almPersistenceService).getBySourceKey(anyString(), anyString(),
                anyString(), eq(Template.class), anyString());
            Mockito.doReturn(assets.toArray(new Asset[assets.size()])).when(almPersistenceService).getBySourceKeys(
                anyString(), anyString(), eq(Asset.class), any());
            Asset[] connectedAssets = equipmentInstanceController.createEquipmentInstances(eic, "add", false);
        } catch (Exception ex) {
            Assert.assertTrue(ex instanceof BadRequestException);
            Assert.assertEquals(ErrorConstants.INVALID_EQUIPMENT_INSTANCE_WITH_DECOMMISSIONED_ASSET,
                ((BadRequestException) ex).getCode());
        }
    }

    @Test
    public void testAddEquipmentInstancesWithNonExistingAssets() throws Exception {
        try {
            EquipmentInstanceConnection eic = new EquipmentInstanceConnection();
            eic.setTemplateSourceKey("sample_template1");
            List<AssetPlaceholderConnection> connections = new ArrayList<>();
            AssetPlaceholderConnection connection1 = new AssetPlaceholderConnection();
            connection1.setAssetSourceKey("asset-id1");
            connection1.setPlaceholderId("uuid-00001");
            connections.add(connection1);
            AssetPlaceholderConnection connection2 = new AssetPlaceholderConnection();
            connection2.setAssetSourceKey("asset-id2");
            connection2.setPlaceholderId("uuid-00002");
            connections.add(connection2);
            AssetPlaceholderConnection connection3 = new AssetPlaceholderConnection();
            connection3.setAssetSourceKey("asset-id3");
            connection3.setPlaceholderId("uuid-00003");
            connections.add(connection3);
            eic.setConnections(connections);
            List<Asset> assets = new ArrayList<>();

            Template[] templates = readObjectsFromResourceFile("/../test-data/input/assetTemplates/create.json",
                Template.class);
            Mockito.doReturn(templates[0]).when(almPersistenceService).getBySourceKey(anyString(), anyString(),
                anyString(), eq(Template.class), anyString());
            Mockito.doReturn(assets.toArray(new Asset[assets.size()])).when(almPersistenceService).getBySourceKeys(
                anyString(), anyString(), eq(Asset.class), any());
            Asset[] connectedAssets = equipmentInstanceController.createEquipmentInstances(eic, "add", false);
        } catch (Exception ex) {
            Assert.assertTrue(ex instanceof BadRequestException);
            Assert.assertEquals(ErrorConstants.INVALID_ASSET, ((BadRequestException) ex).getCode());
        }
    }

    @Test(expected = BadRequestException.class)
    public void testPreviewEquipmentInstances_withNullEquipmentInstanceConnection() throws Exception {
        equipmentInstanceController.createEquipmentInstances(null, "PREVIEW", false);
    }

    @Test
    public void testPreviewEquipmentInstances_missingLeafChild() throws Exception {
        String tenantId = "aaaa-bbbb-cccc-dddd-eeee";
        EquipmentInstanceConnection eic = new EquipmentInstanceConnection();
        eic.setTemplateSourceKey("sample_template");
        List<AssetPlaceholderConnection> connections = new ArrayList<>();
        AssetPlaceholderConnection connection = new AssetPlaceholderConnection();
        connection.setAssetSourceKey("asset-id");
        connection.setPlaceholderId("uuid-00001");
        connections.add(connection);
        eic.setConnections(connections);
        Asset asset = new Asset();
        asset.setSourceKey("asset-id");
        List<Asset> assets = new ArrayList<>();
        assets.add(asset);
        MeasurementTagType tagType = new MeasurementTagType();
        tagType.setSourceKey("tagType-id");

        Template[] templates = readObjectsFromResourceFile("/../test-data/input/assetTemplates/create.json",
            Template.class);
        Mockito.doReturn(templates[0]).when(almPersistenceService).getBySourceKey(anyString(), anyString(), anyString(),
            eq(Template.class), anyString());
        Mockito.doReturn(assets.toArray(new Asset[assets.size()])).when(almPersistenceService).getBySourceKeys(
            anyString(), anyString(), eq(Asset.class), any());
        Mockito.doReturn(tagType).when(almPersistenceService).getTypeByUri(anyString(), anyString());
        ValidationResult result = new ValidationResult();
        result.setValid(true);
        Mockito.doReturn(result).when(equipmentInstanceConformanceChecker).conformTemplate(any(Template.class),
            anyList(), any(Boolean.class));
        Asset[] connectedAssets = equipmentInstanceController.createEquipmentInstances(eic, "preview", false);
        Assert.assertNotNull(connectedAssets);
        Assert.assertTrue(connectedAssets.length == 1);
        Assert.assertTrue(connectedAssets[0].getMeasurementTags().length == 2);
        Assert.assertEquals(connectedAssets[0].getMeasurementTags()[0].getType(), tagType.getSourceKey());
    }

    @Test(expected = BadRequestException.class)
    public void testPreviewEquipmentInstances_missingNonLeafChild() throws Exception {
        String tenantId = "aaaa-bbbb-cccc-dddd-eeee";
        EquipmentInstanceConnection eic = new EquipmentInstanceConnection();
        eic.setTemplateSourceKey("sample_template");
        List<AssetPlaceholderConnection> connections = new ArrayList<>();
        AssetPlaceholderConnection connection = new AssetPlaceholderConnection();
        connection.setAssetSourceKey("asset-id2");
        connection.setPlaceholderId("uuid-00002");
        connections.add(connection);
        eic.setConnections(connections);
        Asset asset1 = new Asset();
        asset1.setSourceKey("asset-id1");
        Asset asset2 = new Asset();
        asset2.setSourceKey("asset-id2");
        List<Asset> assets = new ArrayList<>();
        assets.add(asset1);
        assets.add(asset2);
        MeasurementTagType tagType = new MeasurementTagType();
        tagType.setSourceKey("tagType-id");

        Template[] templates = readObjectsFromResourceFile("/../test-data/input/assetTemplates/create.json",
            Template.class);
        Mockito.doReturn(templates[0]).when(almPersistenceService).getBySourceKey(anyString(), anyString(), anyString(),
            eq(Template.class), anyString());
        Mockito.doReturn(assets.toArray(new Asset[assets.size()])).when(almPersistenceService).getBySourceKeys(
            anyString(), anyString(), eq(Asset.class), any());
        Mockito.doReturn(tagType).when(almPersistenceService).getTypeByUri(anyString(), anyString());
        Asset[] connectedAssets = equipmentInstanceController.createEquipmentInstances(eic, "PREVIEW", false);
    }

    @Test(expected = BadRequestException.class)
    public void testPreviewEquipmentInstances_assetNotFoundInDB() throws Exception {
        String tenantId = "aaaa-bbbb-cccc-dddd-eeee";
        EquipmentInstanceConnection eic = new EquipmentInstanceConnection();
        eic.setTemplateSourceKey("sample_template");
        List<AssetPlaceholderConnection> connections = new ArrayList<>();
        AssetPlaceholderConnection connection1 = new AssetPlaceholderConnection();
        connection1.setAssetSourceKey("asset-id1");
        connection1.setPlaceholderId("uuid-00001");
        connections.add(connection1);
        AssetPlaceholderConnection connection2 = new AssetPlaceholderConnection();
        connection2.setAssetSourceKey("asset-id2");
        connection2.setPlaceholderId("uuid-00002");
        connections.add(connection2);
        eic.setConnections(connections);
        Asset asset1 = new Asset();
        asset1.setSourceKey("asset-id1");
        Asset asset2 = new Asset();
        asset2.setSourceKey("asset-id2");
        List<Asset> assets = new ArrayList<>();
        assets.add(asset1);
        assets.add(asset2);
        MeasurementTagType tagType = new MeasurementTagType();
        tagType.setSourceKey("tagType-id");

        Template[] templates = readObjectsFromResourceFile("/../test-data/input/assetTemplates/create.json",
            Template.class);
        Mockito.doReturn(templates[0]).when(almPersistenceService).getBySourceKey(anyString(), anyString(), anyString(),
            eq(Template.class), anyString());
        Mockito.doReturn(new Asset[] { asset1 }).when(almPersistenceService).getBySourceKeys(anyString(), anyString(),
            eq(Asset.class), any());
        Mockito.doReturn(tagType).when(almPersistenceService).getTypeByUri(anyString(), anyString());
        Asset[] connectedAssets = equipmentInstanceController.createEquipmentInstances(eic, "PREVIEW", false);
    }

    @Test
    public void testPreviewEquipmentInstances() throws Exception {
        String tenantId = "aaaa-bbbb-cccc-dddd-eeee";
        EquipmentInstanceConnection eic = new EquipmentInstanceConnection();
        eic.setTemplateSourceKey("sample_template");
        List<AssetPlaceholderConnection> connections = new ArrayList<>();
        AssetPlaceholderConnection connection1 = new AssetPlaceholderConnection();
        connection1.setAssetSourceKey("asset-id1");
        connection1.setPlaceholderId("uuid-00001");
        connections.add(connection1);
        AssetPlaceholderConnection connection2 = new AssetPlaceholderConnection();
        connection2.setAssetSourceKey("asset-id2");
        connection2.setPlaceholderId("uuid-00002");
        connections.add(connection2);
        eic.setConnections(connections);
        Asset asset1 = new Asset();
        asset1.setSourceKey("asset-id1");
        asset1.setName("asset-name1");

        asset1.setUri(Prefixes.Assets + "/asset-id1");
        Asset asset2 = new Asset();
        asset2.setSourceKey("asset-id2");
        asset2.setName("asset-name2");
        asset2.setUri(Prefixes.Assets + "/asset-id2");

        List<Asset> assets = new ArrayList<>();
        assets.add(asset1);
        assets.add(asset2);
        MeasurementTagType tagType = new MeasurementTagType();
        tagType.setSourceKey("tagType-id");

        Template[] templates = readObjectsFromResourceFile("/../test-data/input/assetTemplates/create.json",
            Template.class);
        Mockito.doReturn(templates[0]).when(almPersistenceService).getBySourceKey(anyString(), anyString(), anyString(),
            eq(Template.class), anyString());
        Mockito.doReturn(assets.toArray(new Asset[assets.size()])).when(almPersistenceService).getBySourceKeys(
            anyString(), anyString(), eq(Asset.class), any());
        Mockito.doReturn(tagType).when(almPersistenceService).getTypeByUri(anyString(), anyString());

        ValidationResult result = new ValidationResult();
        result.setValid(true);
        Mockito.doReturn(result).when(equipmentInstanceConformanceChecker).conformTemplate(any(Template.class),
            anyList(), any(Boolean.class));

        Asset[] connectedAssets = equipmentInstanceController.createEquipmentInstances(eic, "preview", false);
        Assert.assertNotNull(connectedAssets);
        Assert.assertTrue(connectedAssets.length == 2);
        Assert.assertTrue(connectedAssets[0].getMeasurementTags().length == 2);
        Assert.assertEquals(connectedAssets[0].getMeasurementTags()[0].getType(), tagType.getSourceKey());
    }

    private List<Asset> getMockedAssets(TemplateConnection connection, boolean isCreated) throws Exception {
        List<Asset> inAssets = connection.getAssets();
        Asset[] assets = readObjectsFromResourceFile(getInputPath() + "/assetInstances.json", Asset.class);

        List<Asset> selectedAssets = new ArrayList<>();
        for (Asset inAsset : inAssets) {
            for (Asset asset : assets) {
                if (inAsset.getSourceKey().equals(asset.getSourceKey())) {
                    if (isCreated) {
                        asset.setTemplateInfo(null);
                    }
                    selectedAssets.add(asset);
                }
            }
        }
        return selectedAssets;
    }

    /*@Test
    public void testUpdateTemplateConnectionsWithoutParent() throws Exception {
        expectedEx.expect(ServiceException.class);
        Template[] predixTemplates1 = readObjectsFromResourceFile(getInputPath() + "/template1.json", Template.class);

        TemplateConnection[] templateConnections = readObjectsFromResourceFile(getInputPath()
            + "/templateConnectionForUpdate.json", getObjectClass());

        when(controllerFactory.getController(Prefixes.Assets)).thenReturn(assetController);
        when(controllerFactory.getController(Prefixes.Assets).getBySourceKey(anyString())).thenReturn(new Asset());

        String templateUri1 = predixTemplates1[0].getUri();
        String templateUuid1 = templateUri1.split("/")[2];
        when(controllerFactory.getController(Prefixes.Templates)).thenReturn(templateController);
        when(templateController.getSingle(eq(templateUuid1), eq(AssetComponentResolver.FULL))).thenReturn
        (predixTemplates1[0]);

        //mock list of assets for conform check
        when(controllerFactory.getController(Prefixes.Assets).getBySourceKey(anyString())).thenReturn(new Asset());
        List<Asset> mockedAssets = getMockedAssets(templateConnections[0], true);
        mockedAssets.stream().forEach(asset -> {
            when(assetController.getBySourceKey(eq(asset.getSourceKey()))).thenReturn(asset);
        });

        PowerMockito.doNothing().when(assetService).update(anyString(), any(PatchOperation[].class), eq(Asset.class));

        templateConnectionController.updateTemplateConnections(templateConnections);
        expectedEx.expectMessage("E10305");
    }

    @Test
    public void testUpdateTemplateConnectionsWithSiteParent() throws Exception {
        expectedEx.expect(ServiceException.class);
        Template[] predixTemplates1 = readObjectsFromResourceFile(getInputPath() + "/template1.json", Template.class);

        TemplateConnection[] templateConnections = readObjectsFromResourceFile(getInputPath()
            + "/templateConnectionForUpdate.json", getObjectClass());

        TemplateConnection[] updateConnections = new TemplateConnection[1];
        updateConnections[0] = templateConnections[1];

        when(controllerFactory.getController(Prefixes.Assets)).thenReturn(assetController);
        when(controllerFactory.getController(Prefixes.Assets).getBySourceKey(anyString())).thenReturn(new Asset());

        String templateUri1 = predixTemplates1[0].getUri();
        String templateUuid1 = templateUri1.split("/")[2];
        when(controllerFactory.getController(Prefixes.Templates)).thenReturn(templateController);
        when(templateController.getSingle(eq(templateUuid1), eq(AssetComponentResolver.FULL))).thenReturn
        (predixTemplates1[0]);

        //mock list of assets for conform check
        when(controllerFactory.getController(Prefixes.Assets).getBySourceKey(anyString())).thenReturn(new Asset());
        List<Asset> mockedAssets = getMockedAssets(updateConnections[0], true);
        mockedAssets.stream().forEach(asset -> {
            when(assetController.getBySourceKey(eq(asset.getSourceKey()))).thenReturn(asset);
        });

        PowerMockito.doNothing().when(assetService).update(anyString(), any(PatchOperation[].class), eq(Asset.class));

        templateConnectionController.updateTemplateConnections(updateConnections);
        expectedEx.expectMessage("E10305");
    }


    @Test
    public void testUpdateTemplateConnections() throws Exception {
        Template[] predixTemplates1 = readObjectsFromResourceFile(getInputPath() + "/template1.json", Template.class);

        TemplateConnection[] templateConnections = readObjectsFromResourceFile(getInputPath()
            + "/templateConnectionForUpdate.json", getObjectClass());

        TemplateConnection[] updateConnections = new TemplateConnection[1];
        updateConnections[0] = templateConnections[2];

        when(controllerFactory.getController(Prefixes.Assets)).thenReturn(assetController);

        String templateUri1 = predixTemplates1[0].getUri();
        String templateUuid1 = templateUri1.split("/")[2];
        when(controllerFactory.getController(Prefixes.Templates)).thenReturn(templateController);
        when(templateController.getSingle(eq(templateUuid1), eq(AssetComponentResolver.FULL))).thenReturn
        (predixTemplates1[0]);

        //mock list of assets for conform check
        when(controllerFactory.getController(Prefixes.Assets).getBySourceKey(anyString())).thenReturn(new Asset());
        List<Asset> mockedAssets = getMockedAssets(updateConnections[0], false);
        mockedAssets.stream().forEach(asset -> {
            when(assetController.getBySourceKey(eq(asset.getSourceKey()))).thenReturn(asset);
        });

        PowerMockito.doNothing().when(assetService).update(anyString(), any(PatchOperation[].class), eq(Asset.class));

        templateConnectionController.updateTemplateConnections(updateConnections);
    }
*/
    public void testRemoveTemplateConnections() throws Exception {

    }
}
