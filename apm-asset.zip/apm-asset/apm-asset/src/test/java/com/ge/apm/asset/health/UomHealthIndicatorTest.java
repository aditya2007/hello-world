/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.health;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.actuate.health.Health;

import com.ge.apm.asset.service.api.IUomService;

/**
 * Created by 212402415 on 11/9/16.
 */
public class UomHealthIndicatorTest {

    IUomService uomService;

    UomHealthIndicator uomHealthIndicator;

    @Before
    public void setUp() throws Exception {
        uomService = Mockito.mock(IUomService.class);
        uomHealthIndicator = new UomHealthIndicator(uomService);
    }

    @After
    public void tearDown() throws Exception {
        uomService = null;
        uomHealthIndicator = null;
    }

    @Test
    public void testHealthUp() {

        Mockito.when(uomService.healthStatus()).thenReturn(true);
        Health health = uomHealthIndicator.health();
        Assert.assertEquals("UP", health.getStatus().toString());
    }

    @Test
    public void testHealthDown() {

        Mockito.when(uomService.healthStatus()).thenReturn(false);
        Health health = uomHealthIndicator.health();
        Assert.assertEquals("DOWN", health.getStatus().toString());
    }
}
