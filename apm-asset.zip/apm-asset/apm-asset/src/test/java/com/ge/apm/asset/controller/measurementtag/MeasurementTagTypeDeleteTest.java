/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.measurementtag;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.asset.controller.MeasurementTagTypeController;
import com.ge.apm.asset.service.api.IAssetTypeService;
import com.ge.apm.asset.util.ValidationDelegate;
import com.ge.stuf.security.context.SecurityContext;
import com.ge.stuf.security.context.SecurityPrincipal;

import static org.mockito.Matchers.anyString;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ SecurityContext.class })
public class MeasurementTagTypeDeleteTest {

    @InjectMocks
    private MeasurementTagTypeController measurementTagTypeController;

    @Mock
    private IAssetTypeService service;

    @Mock
    private ValidationDelegate validationDelegate;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private SecurityPrincipal securityPrincipal;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void delete() {
        mockSecurityPrincipal();
        Mockito.when(validationDelegate.hasInstances(anyString(), anyString(), anyString())).thenReturn(false);
        Mockito.when(validationDelegate.hasChildren(anyString(), anyString(), anyString())).thenReturn(false);
        Mockito.doNothing().when(service).delete(anyString(), Mockito.any(Class.class));
        measurementTagTypeController.delete("testuuid");
    }

    private void mockSecurityPrincipal() {
        PowerMockito.mockStatic(SecurityContext.class);
        //PowerMockito.when(SecurityContext.getInstance()).thenReturn(securityContext);
        PowerMockito.when(securityContext.getPrinicipal()).thenReturn(securityPrincipal);
        PowerMockito.when(securityPrincipal.getName()).thenReturn(null);
    }
}