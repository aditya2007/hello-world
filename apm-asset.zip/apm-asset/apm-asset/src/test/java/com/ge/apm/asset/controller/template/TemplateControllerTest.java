/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.template;

import java.io.IOException;
import java.lang.reflect.Array;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Queue;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.asset.adapter.api.ITypedAdapter;
import com.ge.apm.asset.adapter.impl.TemplateAdapter;
import com.ge.apm.asset.api.base.AbstractControllerTest;
import com.ge.apm.asset.controller.TemplateController;
import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.Attributable;
import com.ge.apm.asset.model.Base;
import com.ge.apm.asset.model.EntityAssociation;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.model.Hierarchical;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.Placeholder;
import com.ge.apm.asset.model.PlaceholderAssetTypeAssociation;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.Template;
import com.ge.apm.asset.model.TemplateTagPreview;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.query.constants.Token;
import com.ge.apm.asset.query.persistence.QueryPredicate;
import com.ge.apm.asset.service.impl.BaseAssetService;
import com.ge.apm.asset.service.impl.TemplateService;
import com.ge.apm.asset.service.persistence.AlmPersistenceService;
import com.ge.apm.asset.service.persistence.AlmTemplatePersistenceService;
import com.ge.apm.asset.service.util.EquipmentInstanceUtil;
import com.ge.apm.asset.util.AssetComponentResolver;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;
import com.ge.apm.util.ResourceUtil;

import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

/**
 * Covers the test cases for TemplateController, TemplateService and TemplateAdapter
 */
// @PowerMockIgnore
@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class })
public class TemplateControllerTest extends AbstractControllerTest<TemplateController, Template> {

    public static final String ASSET_PATH = "/assets";

    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    protected TemplateService templateService;

    protected List<ITypedAdapter> typedAdapters;

    protected AlmTemplatePersistenceService almTemplatePersistenceService;

    protected EquipmentInstanceUtil equipmentInstanceUtil;

    private TemplateController templateController;

    public static void verifyReservedAttributes(Map<String, ReservedAttributeConfig> expected,
        Map<String, ReservedAttributeConfig> output) {
        expected.forEach((k, v) -> {
            ReservedAttributeConfig config = output.get(k);
            Assert.assertTrue(config.getName().equals(v.getName()));
            Assert.assertTrue(config.getType().equals(v.getType()));
            Assert.assertTrue(config.getPossibleValues().equals(v.getPossibleValues()));
        });
    }

    public String getInputPath() {
        return "/../test-data/input" + getPrefix();
    }

    public String getPredixPath() {
        return "/predix" + getPrefix();
    }

    public String getOutputPath() {
        return "/output" + getPrefix();
    }

    public <X> X[] readObjectsFromResourceFile(String filePath, Class<X> clazz) throws IOException {
        boolean isReadFileFromShareTestDataFolder = filePath.contains("/test-data/");
        if (isReadFileFromShareTestDataFolder) {
            String content = ResourceUtil.readFromRelativeToModuleDirFileAsString(filePath);
            return MAPPER.reader(Array.newInstance(clazz, 0).getClass()).readValue(content);
        } else {
            return MAPPER.reader(Array.newInstance(clazz, 0).getClass()).readValue(
                this.getClass().getResourceAsStream(filePath));
        }
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        templateService = spy(new TemplateService());
        templateController = new TemplateController();
        typedAdapters = new ArrayList<>();
        almTemplatePersistenceService = PowerMockito.mock(AlmTemplatePersistenceService.class);
        equipmentInstanceUtil = new EquipmentInstanceUtil();

        ITypedAdapter templateAdapter = spy(new TemplateAdapter());

        ReflectionUtils.setField(TemplateController.class, templateController, "service", templateService);
        ReflectionUtils.setField(TemplateController.class, templateController, "assetConfigService",
            assetConfigService);

        ReflectionUtils.setField(TemplateService.class, templateService, "assetConfigService", assetConfigService);
        ReflectionUtils.setField(TemplateService.class, templateService, "equipmentInstanceUtil",
            equipmentInstanceUtil);
        ReflectionUtils.setField(TemplateAdapter.class, templateAdapter, "assetConfigService", assetConfigService);
        ReflectionUtils.setField(TemplateService.class, templateService, "almPersistenceService",
            almPersistenceService);
        ReflectionUtils.setField(TemplateService.class, templateService, "assetCacheManager", assetCacheManager);
        ReflectionUtils.setField(AlmPersistenceService.class, almPersistenceService, "almTemplatePersistenceService",
            almTemplatePersistenceService);
        ReflectionUtils.setField(BaseAssetService.class, templateService, "assetConfigService", assetConfigService);
        ReflectionUtils.setField(EquipmentInstanceUtil.class, equipmentInstanceUtil, "almPersistenceService",
            almPersistenceService);

        typedAdapters.add(templateAdapter);
        ReflectionUtils.setField(TemplateService.class, templateService, "typedAdapters", typedAdapters);
        templateService.afterPropertiesSet();
    }

    //TODO - Ignoring tests as template feature is disabled for Q2 2017 release
    @Test(expected = BadRequestException.class)
    public void createWithEmptyPlaceholderId() throws IOException {

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());

        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        templates[0].getPlaceholders().get(0).setPlaceholderId(null);

        List<Template[][]> data = new ArrayList<>();
        data.add(new Template[][] { templates, templates });

        data.forEach(d -> {
            Template[] input = d[0];
            getController().create(Arrays.asList(input));
        });
    }

    @Test(expected = BadRequestException.class)
    public void createWithEmptyTemplateName() throws IOException {

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());

        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        templates[0].setName(null);

        List<Template[][]> data = new ArrayList<>();
        data.add(new Template[][] { templates, templates });

        data.forEach(d -> {
            Template[] input = d[0];
            getController().create(Arrays.asList(input));
        });
    }

    @Test
    public void createTemplateWithMultipleRootPlaceholder() throws IOException {

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());

        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        templates[0].getPlaceholders().add(1, templates[0].getPlaceholders().get(0));
        String templateId = templates[0].getSourceKey();

        expectedEx.expect(BadRequestException.class);
        expectedEx.expectMessage("ET1017 : Template " + templateId + " has more than one root placeholder.");

        getController().create(Arrays.asList(templates));
    }

    @Test
    public void createTemplateWithEmptyRootPlaceholder() throws Exception {
        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        templates[0].getPlaceholders().clear();

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());
        PowerMockito.doNothing().when(almTemplatePersistenceService).createTemplate(Matchers.anyString(),
            Matchers.any(Template.class));

        Template[] output = getController().create(Arrays.asList(templates));
        Template[] expected = templates;
        Arrays.stream(output).forEach(o -> {
            Assert.assertNotNull(o.getUri());
            Assert.assertNull(o.getPlaceholders());
            Arrays.stream(templates).filter(i -> i.getSourceKey().equals(o.getSourceKey())).collect(Collectors.toList())
                .get(0).setUri(o.getUri());
        });
        Assert.assertArrayEquals(expected, output);
    }

    @Test
    public void createTemplateWithNullPlaceholder() throws Exception {
        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        templates[0].setPlaceholders(null);

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());
        PowerMockito.doNothing().when(almTemplatePersistenceService).createTemplate(Matchers.anyString(),
            Matchers.any(Template.class));

        Template[] output = getController().create(Arrays.asList(templates));
        Template[] expected = templates;
        Arrays.stream(output).forEach(o -> {
            Assert.assertNotNull(o.getUri());
            Assert.assertNull(o.getPlaceholders());
            Arrays.stream(templates).filter(i -> i.getSourceKey().equals(o.getSourceKey())).collect(Collectors.toList())
                .get(0).setUri(o.getUri());
        });
        Assert.assertArrayEquals(expected, output);
    }

    @Test(expected = BadRequestException.class)
    public void createWithDuplicatePlaceholderId() throws IOException {

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());

        String duplicatePlaceholderId = "SAMEPHID";
        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        templates[0].getPlaceholders().get(0).setPlaceholderId(duplicatePlaceholderId);
        templates[0].getPlaceholders().get(0).getPlaceholders().get(0).setPlaceholderId(duplicatePlaceholderId);

        List<Template[][]> data = new ArrayList<>();
        data.add(new Template[][] { templates, templates });

        data.forEach(d -> {
            Template[] input = d[0];
            getController().create(Arrays.asList(input));
        });
    }

    @Test(expected = BadRequestException.class)
    public void createWithEmptyAssociations() throws IOException {

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());

        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        templates[0].getPlaceholders().get(0).setAssetTypeAssociations(null);

        List<Template[][]> data = new ArrayList<>();
        data.add(new Template[][] { templates, templates });

        data.forEach(d -> {
            Template[] input = d[0];
            getController().create(Arrays.asList(input));
        });
    }

    @Test(expected = BadRequestException.class)
    public void createInvalidAssetTypeAssociation() throws Exception {
        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());
        this.mockInvalidAssetAssetTypeAssociations(templates[0].getPlaceholders().get(0).getAssetTypeAssociations());
        PowerMockito.doNothing().when(almTemplatePersistenceService).createTemplate(Matchers.anyString(),
            Matchers.any(Template.class));

        getController().create(Arrays.asList(templates));
    }

    @Test(expected = BadRequestException.class)
    public void createInvalidAssociation() throws Exception {
        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());
        this.mockNullAssetAssetTypeAssociations(templates[0].getPlaceholders().get(0).getAssetTypeAssociations());
        PowerMockito.doNothing().when(almTemplatePersistenceService).createTemplate(Matchers.anyString(),
            Matchers.any(Template.class));

        getController().create(Arrays.asList(templates));
    }

    @Test(expected = BadRequestException.class)
    public void createInvalidTemplateAssociation() throws Exception {
        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());
        this.mockInvalidTemplateAssociations(templates[0].getPlaceholders().get(0).getAssetTypeAssociations());
        PowerMockito.doNothing().when(almTemplatePersistenceService).createTemplate(Matchers.anyString(),
            Matchers.any(Template.class));

        getController().create(Arrays.asList(templates));
    }

    @Test(expected = BadRequestException.class)
    public void createWithInvalidReservedAttribute() throws Exception {
        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());
        PowerMockito.doNothing().when(almTemplatePersistenceService).createTemplate(Matchers.anyString(),
            Matchers.any(Template.class));

        templates[0].getReservedAttributes().forEach(
            (k, v) -> templates[0].getReservedAttributes().put(k, "INVALID_VALUE"));

        getController().create(Arrays.asList(templates));
    }

    @Test(expected = BadRequestException.class)
    public void createWithNullReservedAttribute() throws Exception {
        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());
        PowerMockito.doNothing().when(almTemplatePersistenceService).createTemplate(Matchers.anyString(),
            Matchers.any(Template.class));

        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());
        templates[0].getReservedAttributes().forEach((k, v) -> templates[0].getReservedAttributes().put(k, null));
        getController().create(Arrays.asList(templates));
    }

    @Test
    public void createTest() throws Exception {
        Template[] templates = readObjectsFromResourceFile(getInputPath() + "/create.json", getObjectClass());

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());
        this.mockPlaceholdersForCreate(templates);
        PowerMockito.doNothing().when(almTemplatePersistenceService).createTemplate(Matchers.anyString(),
            Matchers.any(Template.class));

        Template[] output = getController().create(Arrays.asList(templates));
        Template[] expected = templates;
        Arrays.stream(output).forEach(o -> {
            Assert.assertNotNull(o.getUri());
            Arrays.stream(templates).filter(i -> i.getSourceKey().equals(o.getSourceKey())).collect(Collectors.toList())
                .get(0).setUri(o.getUri());
        });
        Assert.assertArrayEquals(expected, output);
    }

    @Test(expected = BadRequestException.class)
    public void createWithInvalidPlaceholderAssetTypeAssociationStatus() throws Exception {
        Template[] templates = readObjectsFromResourceFile(
            getInputPath() + "/createWithInvalidPlaceHolderAssocStatus.json", getObjectClass());

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());
        this.mockPlaceholdersForCreate(templates);
        PowerMockito.doNothing().when(almTemplatePersistenceService).createTemplate(Matchers.anyString(),
            Matchers.any(Template.class));

        getController().create(Arrays.asList(templates));
    }

    @Test(expected = BadRequestException.class)
    public void createWithNullPlaceholderAssetTypeAssociationStatus() throws Exception {
        Template[] templates = readObjectsFromResourceFile(
            getInputPath() + "/createWithNULLPlaceHolderAssocStatus.json", getObjectClass());

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());
        this.mockPlaceholdersForCreate(templates);
        PowerMockito.doNothing().when(almTemplatePersistenceService).createTemplate(Matchers.anyString(),
            Matchers.any(Template.class));

        getController().create(Arrays.asList(templates));
    }

    @Test(expected = BadRequestException.class)
    public void createWithEmptyPlaceholderAssetTypeAssociationStatus() throws Exception {
        Template[] templates = readObjectsFromResourceFile(
            getInputPath() + "/createWithEmptyPlaceHolderAssocStatus.json", getObjectClass());

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());
        this.mockPlaceholdersForCreate(templates);
        PowerMockito.doNothing().when(almTemplatePersistenceService).createTemplate(Matchers.anyString(),
            Matchers.any(Template.class));

        getController().create(Arrays.asList(templates));
    }

    @Test(expected = BadRequestException.class)
    public void createWithEmptySpacePlaceholderAssetTypeAssociationStatus() throws Exception {
        Template[] templates = readObjectsFromResourceFile(
            getInputPath() + "/createWithEmptySpacePlaceHolderAssocStatus.json", getObjectClass());

        PowerMockito.doReturn(null).when(almPersistenceService).getBySourceKeys(anyString(),
            Matchers.eq(Prefixes.Templates), Matchers.eq(Template.class), Matchers.any());
        this.mockPlaceholdersForCreate(templates);
        PowerMockito.doNothing().when(almTemplatePersistenceService).createTemplate(Matchers.anyString(),
            Matchers.any(Template.class));

        getController().create(Arrays.asList(templates));
    }

    @Test
    public void testGetByCriteria() throws IOException {
        Template[] templates = readObjectsFromResourceFile(getPredixPath() + "/getByCriteria.json", getObjectClass());
        //        Placeholder[] p = readObjectsFromResourceFile(getPredixPath() + Prefixes
        // .Placeholders +
        // "/getByCriteria.json",
        //            Placeholder.class);
        Template[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/getByCriteria.json",
            getObjectClass());
        expectedFetchedObjects[0].setRevision(null);
        expectedFetchedObjects[0].setNotes(null);

        this.mockForGetByCriteria(templates);
        //        this.mockGetPlaceholders(templates, p);
        Arrays.stream(expectedFetchedObjects).forEach(o -> {
            o.setAttributes(null);
            o.setPlaceholders(null);
        });

        Template[] fetchedObjects = getController().query(Base.SourceKey + "=" + templates[0].getSourceKey(),
            AssetComponentResolver.BASIC, null, null, null);
        Assert.assertArrayEquals(expectedFetchedObjects, fetchedObjects);
    }

    @Test
    public void testGetBySourceKey() throws IOException {
        Template[] templates = readObjectsFromResourceFile(getPredixPath() + "/getBySourceKey.json", getObjectClass());

        Arrays.stream(templates).forEach(t -> Mockito.doReturn(t).when(almPersistenceService)
            .getBySourceKey(anyString(), Matchers.anyString(), Matchers.contains(getPrefix()),
                Matchers.eq(Template.class), Matchers.eq(t.getSourceKey())));
        //        this.mockGetPlaceholders(templates, p);

        ///v1/assetTemplates/bySourceKey endpoint is not published to customer
        Template output = getController().getBySourceKey(templates[0].getSourceKey());
        output.setRevision(null);
        output.setNotes(null);

        Template[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/getBySourceKey.json",
            getObjectClass());

        Assert.assertEquals(expectedFetchedObjects[0], output);
    }

    @Test
    public void testGetByUri() throws IOException {
        Template[] predixTemplates = readObjectsFromResourceFile(getPredixPath() + "/getByUri.json", getObjectClass());
        //        Placeholder[] p = readObjectsFromResourceFile(getPredixPath() + Prefixes
        // .Placeholders
        //            + "/getByUri.json", Placeholder.class);

        Template[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/getByUri.json",
            getObjectClass());

        predixTemplates[0].setPlaceholders(expectedFetchedObjects[0].getPlaceholders());

        Arrays.stream(predixTemplates).forEach(t -> PowerMockito.doReturn(t).when(almPersistenceService)
            .getInstanceByUri(anyString(), Matchers.eq(t.getUri()), Matchers.eq(false)));
        //        this.mockGetPlaceholders(predixTemplates, p);

        String uri = (String) predixTemplates[0].getUri();
        Template expected = (Template) expectedFetchedObjects[0];
        String uuid = uri.split("/")[2];

        Template output = getController().getSingle(uuid, AssetComponentResolver.FULL);
        Assert.assertEquals(expected, output);
    }

    @Test
    public void testDelete() throws IOException {
        Template[] templates = readObjectsFromResourceFile(getPredixPath() + "/getByUri.json", getObjectClass());
        //        Placeholder[] placeholders = readObjectsFromResourceFile(
        //            this.getPredixPath() + Prefixes.Placeholders + "/getByUri.json",
        // Placeholder.class);
        //        mockGetPlaceholders(templates, placeholders);

        PowerMockito.doReturn(templates[0]).when(almPersistenceService).getInstanceByUri(anyString(),
            Matchers.eq(templates[0].getUri()), Matchers.eq(false));

        PowerMockito.doNothing().when(almPersistenceService).deleteTemplate(anyString(), Matchers.anyString());
        Arrays.stream(templates).forEach(t -> {
            String uuid = t.getUri().split("/")[2];
            getController().delete(uuid);
            verify(almPersistenceService).deleteTemplate(anyString(), Matchers.eq(t.getUri()));
        });
    }

    @Test(expected = BadRequestException.class)
    public void testDeleteTemplateUsedByAnAssetInstance() throws Exception {
        TemplatePatch templatePatch = new TemplatePatch().generate();
        Template template = templatePatch.getTemplate();
        Placeholder[] allPlaceholders = templatePatch.getAllPlaceholders();

        this.mockPlaceholdersForPatch(template, allPlaceholders);

        PowerMockito.doThrow(new BadRequestException("Could not delete template since it is used by asset instances"))
            .when(almPersistenceService).deleteTemplate(Matchers.anyString(), Matchers.anyString());

        String templateUri = template.getUri();
        String uuid = templateUri.split("/")[2];
        getController().delete(uuid);
    }

    @Test(expected = BadRequestException.class)
    public void testUpdateWithDuplicatePlaceholderId() throws IOException {
        TemplatePatch templatePatch = new TemplatePatch().generate();
        PatchOperation[] objects = templatePatch.getObjects();
        Template template = templatePatch.getTemplate();
        Placeholder[] allPlaceholders = templatePatch.getAllPlaceholders();

        setDuplicatePlaceholdersForUpdate(objects);
        this.mockPlaceholdersForPatch(template, allPlaceholders);

        String uri = template.getUri();
        String uuid = uri.split("/")[2];
        getController().updateSingle(uuid, Arrays.asList(objects));
    }

    @Test
    public void testUpdateWithMultipleRootPlaceholders() throws IOException {
        PatchOperation[] objects = readObjectsFromResourceFile(getInputPath() + "/update.json", PatchOperation.class);
        Template template = readObjectsFromResourceFile(getPredixPath() + "/update.json", getObjectClass())[0];
        template.getPlaceholders().add(1, template.getPlaceholders().get(0));
        String templateId = "";

        expectedEx.expect(BadRequestException.class);
        expectedEx.expectMessage("Template " + templateId + " has more than one root placeholder.");

        PowerMockito.doReturn(template).when(almPersistenceService).getInstanceByUri(anyString(),
            Matchers.eq(template.getUri()), Matchers.eq(false));

        PatchOperation operation = objects[0];
        if (operation.getPath().equals(TemplateService.PLACEHOLDER_PATH)) {
            List<Placeholder> list = MAPPER.convertValue(operation.getValue(),
                new TypeReference<List<Placeholder>>() { });
            list.add(1, list.get(0).getPlaceholders().get(0));
            Object newPlaceholder = MAPPER.convertValue(list, Object.class);
            objects[0] = new PatchOperation("add", TemplateService.PLACEHOLDER_PATH, newPlaceholder);
        }
        String uri = template.getUri();
        String uuid = uri.split("/")[2];
        getController().updateSingle(uuid, Arrays.asList(objects));
    }

    //TODO: Refactor this test case: Validate with Empty Root placeholder should not depend on
    // validateJsonAgainstClass of CrudOperationsValidator
    @Test
    public void testUpdateWithEmptyRootPlaceholder() throws IOException {
        PatchOperation[] objects = readObjectsFromResourceFile(getInputPath() + "/update.json", PatchOperation.class);
        PatchOperation operation = objects[0];

        if (operation.getPath().equals(TemplateService.PLACEHOLDER_PATH)) {
            List<Placeholder> list = MAPPER.convertValue(operation.getValue(),
                new TypeReference<List<Placeholder>>() { });
            list.clear();
            Object newPlaceholder = MAPPER.convertValue(list, Object.class);
            objects[0] = new PatchOperation("add", TemplateService.PLACEHOLDER_PATH, newPlaceholder);
        }

        Template template = readObjectsFromResourceFile(getPredixPath() + "/update.json", getObjectClass())[0];
        PowerMockito.doReturn(template).when(almPersistenceService).getInstanceByUri(anyString(),
            Matchers.eq(template.getUri()), Matchers.eq(false));
        PowerMockito.doReturn(template).when(almPersistenceService).getInstanceByUri(anyString(),
            Matchers.any(String.class), Matchers.eq(false));

        Placeholder[] allPlaceholders = readObjectsFromResourceFile(
            getPredixPath() + Prefixes.Placeholders + "/update.json", Placeholder.class);
        Template[] templates = { template };
        this.mockGetPlaceholders(templates, allPlaceholders);

        this.mockPlaceholdersForPatch(template, allPlaceholders);
        PowerMockito.doNothing().when(almPersistenceService).updateTemplate(anyString(), Matchers.any(),
            Matchers.anyBoolean());

        List<Object[]> data = new ArrayList<>();
        data.add(new Object[] { template.getUri(), objects });
        String uri = template.getUri();
        String uuid = uri.split("/")[2];
        getController().updateSingle(uuid, Arrays.asList(objects));
    }

    @Test(expected = BadRequestException.class)
    public void testUpdateWithInvalidAssociation() throws IOException {
        TemplatePatch templatePatch = new TemplatePatch().generate();
        PatchOperation[] objects = templatePatch.getObjects();
        Template template = templatePatch.getTemplate();
        Placeholder[] allPlaceholders = templatePatch.getAllPlaceholders();

        setInvalidAssociationForUpdate(objects);
        this.mockPlaceholdersForPatch(template, allPlaceholders);

        String uri = template.getUri();
        String uuid = uri.split("/")[2];
        getController().updateSingle(uuid, Arrays.asList(objects));
    }

    @Test(expected = BadRequestException.class)
    public void testUpdateWithCyclicTemplateAssociation() throws IOException {
        TemplatePatch templatePatch = new TemplatePatch().generate();
        PatchOperation[] objects = templatePatch.getObjects();
        Template template = templatePatch.getTemplate();
        Placeholder[] allPlaceholders = templatePatch.getAllPlaceholders();

        // PowerMockito.doReturn(templatePatch.getTemplate()).when(almPersistenceService)
        //     .getInstanceByUri(anyString(), anyString());

        setCyclicAssociationForUpdate(template, objects);
        this.mockPlaceholdersForPatch(template, allPlaceholders);

        String uri = template.getUri();
        String uuid = uri.split("/")[2];

        getController().updateSingle(uuid, Arrays.asList(objects));
    }

    @Test
    public void testUpdate() throws IOException {
        TemplatePatch templatePatch = new TemplatePatch().generate();
        PatchOperation[] objects = templatePatch.getObjects();
        Template template = templatePatch.getTemplate();
        Placeholder[] allPlaceholders = templatePatch.getAllPlaceholders();

        this.mockPlaceholdersForPatch(template, allPlaceholders);

        String uri = template.getUri();
        String uuid = uri.split("/")[2];
        getController().updateSingle(uuid, Arrays.asList(objects));
    }

    @Test
    public void testGetReservedAttribute() throws IOException {
        ReservedAttributeConfig[] reservedAttributeConfig = objectMapper.reader(ReservedAttributeConfig[].class)
            .readValue(this.getClass().getResourceAsStream("/reservedAttributes/assetTemplates.json"));
        Map<String, ReservedAttributeConfig> reservedAttributeConfigMap = Arrays.asList(reservedAttributeConfig)
            .stream().collect(Collectors
                .toMap(ReservedAttributeConfig::getName, Function.<ReservedAttributeConfig>identity(), (u, v) -> {
                    throw new IllegalStateException(String.format("Duplicate key %s", u));
                }, LinkedHashMap::new));
        try {
            Map<String, ReservedAttributeConfig> output = getController().reservedAttributes();
            Map<String, ReservedAttributeConfig> expected
                = (Map<String, ReservedAttributeConfig>) reservedAttributeConfigMap;
            verifyReservedAttributes(expected, output);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    @Test
    public void testGetSingleWithResourceFilter() throws IOException {
        Template[] predixTemplates = readObjectsFromResourceFile(getPredixPath() + "/getByUri.json", getObjectClass());
        //        Placeholder[] p = readObjectsFromResourceFile(this.getPredixPath() + Prefixes
        // .Placeholders
        //            + "/getByUri.json", Placeholder.class);
        Template[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/getByUri.json",
            getObjectClass());
        Arrays.stream(predixTemplates).forEach(t -> PowerMockito.doReturn(t).when(almPersistenceService)
            .getInstanceByUri(anyString(), Matchers.eq(t.getUri()), Matchers.eq(false)));
        //        this.mockGetPlaceholders(predixTemplates, p);
        Template expected = expectedFetchedObjects[0];

        Template output = templateService.getSingle(expected.getUri(), this.getObjectClass(),
            AssetComponentResolver.getFullComponents(), false);
        Assert.assertEquals(expected, output);
    }

    @Test
    public void testGetDetailedSingle() throws IOException {
        Template[] predixTemplates = readObjectsFromResourceFile(getPredixPath() + "/getByUri.json", getObjectClass());
        //        Placeholder[] p = readObjectsFromResourceFile(this.getPredixPath() + Prefixes
        // .Placeholders
        //            + "/getByUri.json", Placeholder.class);

        Template[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/getByUri.json",
            getObjectClass());

        Arrays.stream(predixTemplates).forEach(t -> PowerMockito.doReturn(t).when(almPersistenceService)
            .getInstanceByUri(anyString(), Matchers.eq(t.getUri()), Matchers.eq(false)));
        //        this.mockGetPlaceholders(predixTemplates, p);
        Template expected = expectedFetchedObjects[0];
        Template output = templateService.getDetailedSingle(expected.getUri(), this.getObjectClass(),
            AssetComponentResolver.getFullComponents());
        Assert.assertEquals(expected, output);
    }

    @Ignore
    @Test
    public void testGetWithResourceFilter() throws IOException {
        templateService.get((String) null, getObjectClass(), AssetComponentResolver.getDefaultComponents(), false);
    }

    @Test
    public void testGetAll() throws IOException {
        Template[] templates = readObjectsFromResourceFile(getPredixPath() + "/getByCriteria.json", getObjectClass());
        //        Placeholder[] p = readObjectsFromResourceFile(getPredixPath() + Prefixes
        // .Placeholders +
        // "/getByCriteria.json",
        //            Placeholder.class);
        Template[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/getByCriteria.json",
            getObjectClass());
        //        this.mockGetPlaceholders(templates, p);
        PowerMockito.doReturn(templates).when(almPersistenceService).findAllByPrefix(anyString(),
            Matchers.contains(getPrefix()), Matchers.any(QueryPredicate.class), Matchers.eq(Template.class),
            Matchers.anyBoolean(), Matchers.anyBoolean());
        Template[] expected = expectedFetchedObjects;
        Template[] fetchedObjects = templateService.get(getPrefix(), getObjectClass(),
            AssetComponentResolver.getBasicComponents());

        Assert.assertArrayEquals(expected, fetchedObjects);
    }

    @Test
    public void testGetWithReservedAttributeQuery() throws IOException {
        Template[] templates = readObjectsFromResourceFile(getPredixPath() + "/getByCriteria.json", getObjectClass());
        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setQuery(Optional.of("name=*template*|reservedAttributes.status"
            + ".value=*act*:desc=*templateDesc*|reservedAttributes.state" + ".value=draft"));

        QueryPredicate expectedQueryPredicate = new QueryPredicate();
        expectedQueryPredicate.setQuery(Optional
            .of("name=*template*|reservedAttributes.status.key=01," + "02:desc=*templateDesc*|reservedAttributes.state"
                + ".key=01"));

        PowerMockito.doReturn(templates).when(almPersistenceService).findAllByPrefix(anyString(),
            Matchers.contains(getPrefix()), Matchers.argThat(new ArgumentMatcher<QueryPredicate>() {
                @Override
                public boolean matches(Object obj) {
                    QueryPredicate actual = (QueryPredicate) obj;
                    boolean flag;
                    flag = actual.getQuery().equals(expectedQueryPredicate.getQuery());
                    return flag;
                }
            }), Matchers.eq(Template.class), Matchers.anyBoolean(), Matchers.anyBoolean());
        Template[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/getByCriteria.json",
            getObjectClass());
        Template[] expected = expectedFetchedObjects;

        Template[] fetchedObjects = templateService.get(getPrefix(), getObjectClass(),
            AssetComponentResolver.getBasicComponents(), queryPredicate, 250);

        Assert.assertArrayEquals(expected, fetchedObjects);
    }

    @Test
    public void testGetWithIncorrectReservedAttributeValue() throws IOException {
        Template[] templates = readObjectsFromResourceFile(getPredixPath() + "/getByCriteria.json", getObjectClass());
        QueryPredicate queryPredicate = new QueryPredicate();
        queryPredicate.setQuery(Optional.of("reservedAttributes.state.value=01"));

        QueryPredicate expectedQueryPredicate = new QueryPredicate();
        expectedQueryPredicate.setQuery(Optional.of("reservedAttributes.state.value=01"));

        PowerMockito.doReturn(templates).when(almPersistenceService).findAllByPrefix(anyString(),
            Matchers.contains(getPrefix()), Matchers.argThat(new ArgumentMatcher<QueryPredicate>() {
                @Override
                public boolean matches(Object obj) {
                    QueryPredicate actual = (QueryPredicate) obj;
                    boolean flag;
                    flag = actual.getQuery().equals(expectedQueryPredicate.getQuery());
                    return flag;
                }
            }), Matchers.eq(Template.class), Matchers.anyBoolean(), Matchers.anyBoolean());
        Template[] expectedFetchedObjects = readObjectsFromResourceFile(getOutputPath() + "/getByCriteria.json",
            getObjectClass());
        Template[] expected = expectedFetchedObjects;

        Template[] fetchedObjects = templateService.get(getPrefix(), getObjectClass(),
            AssetComponentResolver.getBasicComponents(), queryPredicate, 250);

        Assert.assertArrayEquals(expected, fetchedObjects);
    }

    @Test
    public void testTemplateAdatperMethods() throws IOException, IllegalAccessException {
        TemplateAdapter adapter = new TemplateAdapter();
        Assert.assertFalse(adapter.shouldMerge());

        adapter.updateParent((Attributable) null, AssetComponentResolver.getDefaultComponents(), false);
        Assert.assertArrayEquals(new Hierarchical[0], adapter
            .fetchChildren((String) null, (String) null, AssetComponentResolver.getDefaultComponents(),
                (QueryPredicate) null));
        Assert.assertNull(adapter.fetchParent((Hierarchical) null, AssetComponentResolver.getDefaultComponents()));
        Assert.assertEquals(this.getPrefix(), adapter.getPrefix());
        Template[] templates = readObjectsFromResourceFile(getPredixPath() + "/getByUri.json", getObjectClass());
        ReflectionUtils.setField(TemplateAdapter.class, adapter, "assetConfigService", assetConfigService);
        adapter.sanitize("tenantId", (Attributable) templates[0]);
    }

    @Test
    public void testTemplatePreviewTagsCollections_MultiplePlaceholders() throws IOException {
        Template[] templates = readObjectsFromResourceFile(getPredixPath() +
            "/assetTemplateTagExpressions/getTemplateWithMultipleTagExpressions.json", getObjectClass());
        MeasurementTagType[] tagTypes = readObjectsFromResourceFile(getPredixPath() +
            "/tagTypes/tagTypes.json", MeasurementTagType.class);

        TemplateTagPreview[] expectedPreviewTags = readObjectsFromResourceFile(getPredixPath() + "/tags/previewTags.json",
            TemplateTagPreview.class);

        PowerMockito.doReturn(templates[0]).when(almPersistenceService).getInstanceByUri(eq(getTenantHeader()),
            eq(templates[0].getUri()), eq(false));
        PowerMockito.doReturn(tagTypes[0]).when(almPersistenceService).getTypeByUri(eq(getTenantHeader()),
            eq(tagTypes[0].getUri()));
        PowerMockito.doReturn(tagTypes[1]).when(almPersistenceService).getTypeByUri(eq(getTenantHeader()),
            eq(tagTypes[1].getUri()));

        TemplateTagPreview[] previewTags = templateController.previewAllTags(templates[0].getUri().split("/")[2]);
        Assert.assertArrayEquals(expectedPreviewTags, previewTags);
    }

    @Test
    public void testTemplatePlceholderPreviewTags() throws IOException {
        Template[] templates = readObjectsFromResourceFile(getPredixPath() +
            "/assetTemplateTagExpressions/getTemplateWithMultipleTagExpressions.json", getObjectClass());
        MeasurementTagType[] tagTypes = readObjectsFromResourceFile(getPredixPath() +
            "/tagTypes/tagTypes.json", MeasurementTagType.class);

        TemplateTagPreview[] expectedPreviewTags = readObjectsFromResourceFile(getPredixPath() +
                "/tags/previewTagsPerPlaceholder.json", TemplateTagPreview.class);

        PowerMockito.doReturn(templates[0]).when(almPersistenceService).getInstanceByUri(eq(getTenantHeader()),
            eq(templates[0].getUri()), eq(false));
        PowerMockito.doReturn(tagTypes[0]).when(almPersistenceService).getTypeByUri(eq(getTenantHeader()),
            eq(tagTypes[0].getUri()));
        PowerMockito.doReturn(tagTypes[1]).when(almPersistenceService).getTypeByUri(eq(getTenantHeader()),
            eq(tagTypes[1].getUri()));

        TemplateTagPreview[] previewTags = templateController.previewTags(templates[0].getUri().split("/")[2],
            templates[0].getPlaceholders().get(0).getPlaceholderId());
        Assert.assertArrayEquals(expectedPreviewTags, previewTags);
    }

    @Test
    public void testTemplatePreviewTagsCollections_Empty() throws IOException {
        Template[] templates = readObjectsFromResourceFile(getPredixPath() +
            "/assetTemplateTagExpressions/getTemplateWithNoTagExpressions.json", getObjectClass());

        PowerMockito.doReturn(templates[0]).when(almPersistenceService).getInstanceByUri(eq(getTenantHeader()),
            eq(templates[0].getUri()), eq(false));

        TemplateTagPreview[] previewTags = templateController.previewAllTags(templates[0].getUri().split("/")[2]);
        Assert.assertEquals(0, previewTags.length);
    }

    private void setDuplicatePlaceholdersForUpdate(PatchOperation... objects) {
        for (int idx = 0; idx < objects.length; idx++) {
            PatchOperation operation = objects[idx];
            if (operation.getPath().equals(TemplateService.PLACEHOLDER_PATH)) {
                List<Placeholder> list = MAPPER.convertValue(operation.getValue(),
                    new TypeReference<List<Placeholder>>() { });
                String duplicatePlaceholderId = "SAMEPHID";
                list.get(0).setPlaceholderId(duplicatePlaceholderId);
                list.get(0).getPlaceholders().get(0).setPlaceholderId(duplicatePlaceholderId);
                Object newPlaceholder = MAPPER.convertValue(list, Object.class);
                objects[idx] = new PatchOperation("add", TemplateService.PLACEHOLDER_PATH, newPlaceholder);
            }
        }
    }

    private void mockPlaceholdersForCreate(Template... templates) {
        Arrays.stream(templates).forEach(o -> {
            Queue<Placeholder> queue = new LinkedList<>();
            queue.addAll(o.getPlaceholders());
            while (true) {
                try {
                    final Placeholder element = queue.remove();
                    List<? extends EntityAssociation> associations = element.getAssetTypeAssociations();
                    this.mockAssociations(associations);
                    List<? extends EntityAssociation> tagAssociations = element.getTagTypeAssociations();
                    this.mockAssociations(tagAssociations);
                    if (element.getPlaceholders() != null) {
                        queue.addAll(element.getPlaceholders());
                    }
                } catch (Exception exp) {
                    break;
                }
            }
        });
    }

    private void mockPlaceholdersForPatch(Template t, Placeholder... allPlaceholders) {
        List<Placeholder> list = t.getPlaceholders();
        Queue<Placeholder> queue = new LinkedList<>();
        queue.addAll(list);
        while (true) {
            try {
                final Placeholder element = queue.remove();
                List<PlaceholderAssetTypeAssociation> associations = element.getAssetTypeAssociations();
                this.mockAssociations(associations);
                this.mockAssociations(element.getTagTypeAssociations());

                if (element.getPlaceholders() != null) {
                    queue.addAll(element.getPlaceholders());
                    element.setPlaceholders(null);
                }
            } catch (Exception exp) {
                break;
            }
        }
    }

    private void setInvalidAssociationForUpdate(PatchOperation... objects) {
        for (int idx = 0; idx < objects.length; idx++) {
            PatchOperation operation = objects[idx];
            if (operation.getPath().equals(TemplateService.PLACEHOLDER_PATH)) {
                List<Placeholder> list = MAPPER.convertValue(operation.getValue(),
                    new TypeReference<List<Placeholder>>() {});
                list.get(0).getAssetTypeAssociations().get(0).setEntityUri(null);

                Object newPlaceholder = MAPPER.convertValue(list, Object.class);
                objects[idx] = new PatchOperation("add", TemplateService.PLACEHOLDER_PATH, newPlaceholder);
            }
        }
    }

    private void setCyclicAssociationForUpdate(Template t, PatchOperation... objects) {
        for (int idx = 0; idx < objects.length; idx++) {
            PatchOperation operation = objects[idx];
            if (operation.getPath().equals(TemplateService.PLACEHOLDER_PATH)) {
                List<Placeholder> list = MAPPER.convertValue(operation.getValue(),
                    new TypeReference<List<Placeholder>>() {});
                list.get(0).getPlaceholders().get(0).getPlaceholders().get(0)
                    .getAssetTypeAssociations().get(0).setEntityUri(t.getUri());
                Object newPlaceholder = MAPPER.convertValue(list, Object.class);
                objects[idx] = new PatchOperation("add", TemplateService.PLACEHOLDER_PATH, newPlaceholder);
            }
        }
    }

    private void mockInvalidTemplateAssociations(List<? extends EntityAssociation> associations) {
        if (associations != null) {
            associations.forEach(a -> {
                a.setEntityUri(Prefixes.Templates + "/invaliduri");
                PowerMockito.doThrow(new NotFoundException("")).when(almPersistenceService).getInstanceByUri(
                    anyString(), Matchers.eq(a.getEntityUri()), Matchers.eq(false));
            });
        }
    }

    private void mockInvalidAssetAssetTypeAssociations(List<? extends EntityAssociation> associations) {
        if (associations != null) {
            associations.forEach(a -> {
                a.setEntityUri(Prefixes.AssetTypes + "/invaliduri");
                PowerMockito.doThrow(new NotFoundException("")).when(almPersistenceService).getInstanceByUri(
                    anyString(), Matchers.eq(a.getEntityUri()), Matchers.eq(false));
            });
        }
    }

    private void mockNullAssetAssetTypeAssociations(List<? extends EntityAssociation> associations) {
        if (associations != null) {
            associations.forEach(a -> {
                a.setEntityUri(null);
            });
        }
    }

    private void mockAssociations(List<? extends EntityAssociation> associations) {
        if (associations != null) {
            associations.forEach(a -> {
                if (a.getEntityUri().contains(Prefixes.AssetTypes)) {
                    AssetType assetType = new AssetType();
                    assetType.setUri(a.getEntityUri());
                    PowerMockito.doReturn(assetType).when(almPersistenceService).getTypeByUri(anyString(),
                        Matchers.eq(a.getEntityUri()));
                } else if (a.getEntityUri().contains(Prefixes.Templates)) {
                    Template template = new Template();
                    template.setUri(a.getEntityUri());
                    template.setSourceKey("sub_template");
                    PowerMockito.doReturn(template).when(almPersistenceService).getInstanceByUri(anyString(),
                        Matchers.eq(a.getEntityUri()), Matchers.anyBoolean());

                    //                    Placeholder p = new Placeholder();
                    //                    p.setPlaceholderId(IdGenerator.generateAsString());
                    //                    PlaceholderAssetTypeAssociation association = new
                    // PlaceholderAssetTypeAssociation();
                    //                    association.setEntityUri
                    // ("/assetTypes/536544e3-d176-3a16-a752-cb50deba0083");
                    //                    List<PlaceholderAssetTypeAssociation> placeholderAssociations =
                    // new ArrayList<>();
                    //                    placeholderAssociations.add(association);
                    //                    p.setAssetTypeAssociations(placeholderAssociations);

                    //                    Template[] t = {template};
                    //                    this.mockGetPlaceholders(t, p);
                } else if (a.getEntityUri().contains(Prefixes.Groups)) {
                    Group entity = new Group();
                    entity.setUri(a.getEntityUri());
                    entity.setCategory("TAG_TYPE");
                    PowerMockito.doReturn(entity).when(almPersistenceService).getInstanceByUri(anyString(),
                        Matchers.eq(a.getEntityUri()), Matchers.eq(false));
                } else if (a.getEntityUri().contains(Prefixes.MeasurementTagTypes)) {
                    MeasurementTagType entity = new MeasurementTagType();
                    entity.setUri(a.getEntityUri());
                    PowerMockito.doReturn(entity).when(almPersistenceService).getTypeByUri(anyString(),
                        Matchers.eq(a.getEntityUri()));
                }
            });
        }
    }

    private void mockGetPlaceholders(Template[] templates, Placeholder... p) {
        //TODO - QueryPredicate last param Mockito.any(QueryPredicate.class) needs to be resolved
        //        Arrays.stream(templates).forEach(t -> doReturn(p).when(placeholderService)
        //            .get(Matchers.eq(Prefixes.Placeholders), Matchers.eq(Placeholder.class),
        //                Matchers.eq(AssetComponentResolver.getDetailedComponents()),
        //                Matchers.argThat(new ArgumentMatcher<IFilterExpression>() {
        //                    @Override
        //                    public boolean matches(Object obj) {
        //                        IFilterExpression src = attribute(Placeholder.Template).eq(t
        // .getUri());
        //                        IFilterExpression exp = (IFilterExpression) obj;
        //                        return exp.build().equals(src.build());
        //                    }
        //                }), Mockito.any(QueryPredicate.class)));
    }

    private void mockForGetByCriteria(Template... templates) throws IOException {
        PowerMockito.doReturn(templates).when(almPersistenceService).findAllByPrefix(anyString(),
            Matchers.contains(getPrefix()), Matchers.argThat(new ArgumentMatcher<QueryPredicate>() {
                @Override
                public boolean matches(Object obj) {
                    StringBuilder expression = new StringBuilder();
                    expression.append(Base.SourceKey).append(Token.NameValueSeparator).append(templates[0]
                        .getSourceKey());
                    QueryPredicate queryPredicate = (QueryPredicate) obj;
                    return expression.toString().equals(queryPredicate.getQuery().get());
                }
            }), Matchers.eq(Template.class), Matchers.anyBoolean(), Matchers.anyBoolean());
    }

    @Override
    public Class<Template> getObjectClass() {
        return Template.class;
    }

    @Override
    public TemplateController getController() {
        return templateController;
    }

    @Override
    public String getTypePrefix() {
        return null;
    }

    @Override
    public String getPrefix() {
        return Prefixes.Templates;
    }

    private class TemplatePatch {

        private PatchOperation[] objects;

        private Template template;

        private Placeholder[] allPlaceholders;

        public PatchOperation[] getObjects() {
            return objects;
        }

        public Template getTemplate() {
            return template;
        }

        public Placeholder[] getAllPlaceholders() {
            return allPlaceholders;
        }

        public TemplatePatch generate() throws IOException {
            objects = readObjectsFromResourceFile(getInputPath() + "/update.json", PatchOperation.class);
            template = readObjectsFromResourceFile(getPredixPath() + "/update.json", getObjectClass())[0];
            PowerMockito.doReturn(template).when(almPersistenceService).getInstanceByUri(anyString(),
                Matchers.eq(template.getUri()), Matchers.eq(false));

            allPlaceholders = readObjectsFromResourceFile(getPredixPath() + Prefixes.Placeholders + "/update.json",
                Placeholder.class);

            Template[] templates = { template };

            TemplateControllerTest.this.mockGetPlaceholders(templates, allPlaceholders);

            Arrays.stream(allPlaceholders).forEach(item -> {
                PowerMockito.doReturn(item).when(almPersistenceService).getPlaceholderByTemplateUriAndPlaceholderId(
                    anyString(), Matchers.eq(item.getTemplate()), Matchers.eq(item.getPlaceholderId()));
            });

            PowerMockito.doNothing().when(almPersistenceService).updateTemplate(anyString(), Matchers.any(),
                anyBoolean());
            return this;
        }
    }
}
