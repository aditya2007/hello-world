/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.template.placeholder;

import java.io.IOException;
import java.lang.reflect.Array;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.asset.adapter.api.ITypedAdapter;
import com.ge.apm.asset.api.base.AbstractControllerTest;
import com.ge.apm.asset.controller.PlaceholderController;
import com.ge.apm.asset.controller.TemplateController;
import com.ge.apm.asset.model.ObjectInfo;
import com.ge.apm.asset.model.Placeholder;
import com.ge.apm.asset.model.PredixAssetTransitiveDepthConfig;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.common.util.DateTimeUtil;
import com.ge.apm.common.util.IdGenerator;
import com.ge.apm.util.ResourceUtil;

import static org.mockito.Mockito.spy;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class, DateTimeUtil.class })
public class PlaceholderControllerTest extends AbstractControllerTest<PlaceholderController, Placeholder> {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    PlaceholderController placeholderController;

    List<ITypedAdapter> typedAdapters;

    public String getInputPath() {
        return "/../test-data/input" + Prefixes.Templates + getPrefix();
    }

    public String getPredixPath() {
        return "/predix" + Prefixes.Templates + getPrefix();
    }

    public String getOutputPath() {
        return "/../test-data/output" + Prefixes.Templates + getPrefix();
    }

    public <X> X[] readObjectsFromResourceFile(String filePath, Class<X> clazz) throws IOException {
        boolean isReadFileFromShareTestDataFolder = filePath.contains("/test-data/");
        if (isReadFileFromShareTestDataFolder) {
            String content = ResourceUtil.readFromRelativeToModuleDirFileAsString(filePath);
            return MAPPER.reader(Array.newInstance(clazz, 0).getClass()).readValue(content);
        } else {
            return MAPPER.reader(Array.newInstance(clazz, 0).getClass()).readValue(
                this.getClass().getResourceAsStream(filePath));
        }
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        placeholderController = spy(new PlaceholderController());
        ReflectionUtils.setField(TemplateController.class, placeholderController, "assetConfigService",
            assetConfigService);
        PowerMockito.doReturn(new PredixAssetTransitiveDepthConfig()).when(assetConfigService)
            .getPredixAssetTransitiveDepthConfiguration();
    }

    @Test
    public void testGetReservedAttribute() throws IOException {
        Map<String, ReservedAttributeConfig> actual = getController().reservedAttributes();
        Assert.assertNotNull(actual);
        Assert.assertEquals(2, actual.size());
        Assert.assertEquals(actual.get("state").getPossibleValues().size(), 3);
        Assert.assertEquals(actual.get("status").getPossibleValues().size(), 2);
    }

    public Class<?> getTypeClass() {
        return null;
    }

    public Class<Placeholder> getObjectClass() {
        return Placeholder.class;
    }

    public PlaceholderController getController() {
        return placeholderController;
    }

    public String getTypePrefix() {
        return null;
    }

    public String getPrefix() {
        return Prefixes.Placeholders;
    }

    public ObjectInfo[] getChildrenInfo() {
        return new ObjectInfo[0];
    }

    public ObjectInfo[] getParentInfo() {
        return new ObjectInfo[0];
    }
}
