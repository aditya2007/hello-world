/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.mq.processor;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.ExchangeBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultMessage;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ge.apm.asset.model.AssetType;
import com.ge.apm.asset.model.DownloadTask;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.Type;
import com.ge.apm.asset.service.api.IAssetTypeService;
import com.ge.apm.asset.util.ReflectionUtils;
import com.ge.apm.blob.client.BlobArchiveClient;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;


public class DownloadTypeProcessorTest {

    @Mock
    IAssetTypeService assetTypeService;

    @Mock
    BlobArchiveClient client;

    @InjectMocks
    DownloadTypeProcessor downloadTypeProcessor;

    Exchange exchange = null;

    Message message = null;

    private static final String EXPECTED_DOWNLOAD_URL = "http://localhost/1234/download";

    @Before
    public void setup() throws Exception {
        MockitoAnnotations.initMocks(this);
        exchange = ExchangeBuilder.anExchange(new DefaultCamelContext()).withBody(new Object()).build();
        message = new DefaultMessage();
        message.setBody(new DownloadTask());
        exchange.setIn(message);
        configureMocks();
    }

    @Test
    public void processDownload() throws Exception {
        downloadTypeProcessor.process(exchange);
        DownloadTask downloadTask = (DownloadTask) exchange.getIn().getBody();
        Map<String, String> actualDownloadUrlMap = new Gson().fromJson(downloadTask.getTaskResponse().get
            ("responseUri").toString(), Map.class);
        assertEquals(getExpectedUrlMap(), actualDownloadUrlMap);
    }

    private void configureMocks() throws Exception {
        Field pageSizeField = DownloadTypeProcessor.class.getDeclaredField("exportQueryPageSize");
        pageSizeField.setAccessible(true);
        pageSizeField.set(downloadTypeProcessor, 1000);

        Field zipContentsSizeField = DownloadTypeProcessor.class.getDeclaredField("zipContentsSize");
        zipContentsSizeField.setAccessible(true);
        zipContentsSizeField.set(downloadTypeProcessor, 2);

        ReflectionUtils.setField(DownloadProcessor.class, downloadTypeProcessor, "blobArchiveClient", client);

        doReturn(getTypes()).when(assetTypeService).get(any(Integer.class), any(Integer.class));
        doReturn(EXPECTED_DOWNLOAD_URL).when(client).archiveBlob(any(Exchange.class), any(InputStream.class));
    }

    private Type[] getTypes() {
        Type[] types = new Type[3];
        types[0] = getAssetType("/assetTypes/195d6ca0-8230-35ef-8d62-7431d4c81306", "parent skey", null);
        types[1] = getAssetType("/assetTypes/195d6ca0-8230-35ef-8d62-7431d4c81305", "child1 skey",
            "/assetTypes/195d6ca0-8230-35ef-8d62-7431d4c81306");
        types[2] = getTagType("/tagTypes/195d6ca0-8230-35ef-8d62-7431d4c81305", "child2 skey", null);
        return types;
    }

    private Type getAssetType(String uri, String skey, String parent) {
        return getType(new AssetType(), uri, skey, parent);
    }

    private Type getTagType(String uri, String skey, String parent) {
        return getType(new MeasurementTagType(), uri, skey, parent);
    }

    private Type getType(Type type, String uri, String skey, String parent) {
        type.setUri(uri);
        type.setSourceKey(skey);
        type.setParent(parent);
        return type;
    }

    private Map<String, String> getExpectedUrlMap() {
        Map<String, String> urlMap = new HashMap<>();
        urlMap.put("url1", EXPECTED_DOWNLOAD_URL);
        urlMap.put("url2", EXPECTED_DOWNLOAD_URL);
        return urlMap;
    }
}
