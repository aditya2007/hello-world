/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.asset.controller.sitetype;

import java.text.ParseException;

import org.junit.Before;

import com.ge.apm.asset.api.base.AbstractTypeControllerTest;
import com.ge.apm.asset.controller.SiteTypeController;
import com.ge.apm.asset.model.ObjectInfo;
import com.ge.apm.asset.model.SiteType;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.asset.util.ReflectionUtils;

public abstract class AbstractSiteTypeControllerTest extends AbstractTypeControllerTest<SiteTypeController, SiteType> {

    protected SiteTypeController siteTypeController;

    @Override
    public Class<SiteType> getObjectClass() {
        return SiteType.class;
    }

    @Override
    public SiteTypeController getController() {
        return siteTypeController;
    }

    @Override
    public String getTypePrefix() {
        return "";
    }

    @Override
    public String getPrefix() {
        return Prefixes.SiteTypes;
    }

    @Before
    public void setUp() throws InstantiationException, IllegalAccessException, ParseException {
        super.setUp();
        siteTypeController = new SiteTypeController();
        ReflectionUtils.setField(SiteTypeController.class, siteTypeController, "service", assetTypeService);
    }

    public ObjectInfo[] getChildrenInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.SiteTypes, "siteType.json", SiteType.class) };
    }

    public ObjectInfo[] getParentInfo() {
        return new ObjectInfo[] { new ObjectInfo(Prefixes.SiteTypes, "siteType.json", SiteType.class) };
    }
}
