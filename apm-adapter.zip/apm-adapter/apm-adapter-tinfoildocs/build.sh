#!/usr/bin/env bash
export JAVA_HOME=${JAVA_HOME_ORACLEJDK8}
export PATH=${JAVA_HOME}/bin:${PATH}
wkdir=${PWD};

mvn verify -s ../menlo_settings.xml

#echo "Generating tinfoil docs for apm-adapter-service";
outdir=${wkdir}/target/generated-tinfoildoc

mvn surefire:test -s ../menlo_settings.xml -Dtest=DocGenerator -DfailIfNoTests=false -Ddocs.swagger.outDir=${outdir} -Ddocs.swagger.outFileName=apm-adapter-service.json

# IMPORTANT: This removes the params in the URL.  Unfortunately, the tinfoil swagger validator fails with them. Once it can work, this line should be commented out or removed.
sed -i.bak 's/{?.*}//g' ${outdir}/apm-adapter-service.json
rm ${outdir}/apm-adapter-service.json.bak
