/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.tinfoildoc;

import java.util.Collections;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.Application;
import com.ge.stuf.doc.DocGeneratorBase;
import com.ge.stuf.doc.DocketConfig;

@RunWith(SpringRunner.class)
@Configuration
@SpringBootTest(classes = { Application.class, DocGenerator.class })
public class DocGenerator extends DocGeneratorBase {

    @Bean
    public DocketConfig dockConfig() {
        // TODO: set the title, version, and package to scan for your config
        return new DocketConfig().setTitle("Adapter Service API").setVersion("v1").setPackagesToScan(
            Collections.singleton(Application.class.getPackage().getName()));
    }

    @Test
    @Override
    public void generateSwagger() throws Exception {
        super.generateSwagger();
    }

    @Test
    @Override
    public void generateMarkdown() throws Exception {
        super.generateMarkdown();
    }

    @Test
    @Override
    public void generateSwaggerLegacy() throws Exception {
        super.generateSwaggerLegacy();
    }
}
