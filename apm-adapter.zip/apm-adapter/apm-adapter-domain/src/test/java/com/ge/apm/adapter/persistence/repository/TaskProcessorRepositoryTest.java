/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.persistence.repository;

import java.sql.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.TestApp;
import com.ge.apm.adapter.domain.persistence.entity.IngestionLogMsg;
import com.ge.apm.adapter.domain.persistence.entity.Task;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
public class TaskProcessorRepositoryTest {

    @Autowired
    ITaskProcessorRepository taskProcessorRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Test
    public void testFindAllChildren() {
        List<Task> tasks = taskProcessorRepository.findRootTasks("X");
        Assert.assertNotNull(tasks);
    }

    @Test
    public void testAddIngestionLogWhenOneExists() {
        List<Task> tasks = taskProcessorRepository.findRootTasks("X");
        Assert.assertTrue("No tasks returned", !tasks.isEmpty());
        Task task = tasks.get(0);
        IngestionLogMsg ingestionLogMsg = new IngestionLogMsg();
        ingestionLogMsg.setMsgCode("E!0000");
        ingestionLogMsg.setMsgType("ERROR");
        ingestionLogMsg.setMsg("General Error");
        ingestionLogMsg.setAction("ACTION");
        ingestionLogMsg.setResolution("Resolution");
        ingestionLogMsg.setTaskUuid(task.getUuid());
        Assert.assertNotNull("Ingestion log is empty", task.getIngestionLogMsgList());
        task.getIngestionLogMsgList().add(ingestionLogMsg);
        taskProcessorRepository.save(task);

        Task savedTask = taskProcessorRepository.findOne(task.getId());
        Assert.assertNotNull(savedTask);
        Assert.assertTrue("Ingestion log not saved", !savedTask.getIngestionLogMsgList().isEmpty());
    }

    @Test
    public void testAddIngestionLogWhenNoneExists() {
        Task task = taskProcessorRepository.findByTenantUuidAndUuid("X", "e");
        Assert.assertNotNull(task);
        IngestionLogMsg ingestionLogMsg = new IngestionLogMsg();
        ingestionLogMsg.setMsgCode("E!0000");
        ingestionLogMsg.setMsgType("ERROR");
        ingestionLogMsg.setMsg("General Error");
        ingestionLogMsg.setAction("ACTION");
        ingestionLogMsg.setResolution("Resolution");
        ingestionLogMsg.setTaskUuid(task.getUuid());
        Assert.assertTrue("Ingestion log is not empty", task.getIngestionLogMsgList().isEmpty());
        task.getIngestionLogMsgList().add(ingestionLogMsg);
        taskProcessorRepository.save(task);

        Task savedTask = taskProcessorRepository.findOne(task.getId());
        Assert.assertNotNull(savedTask);
        Assert.assertTrue("Ingestion log not saved", !savedTask.getIngestionLogMsgList().isEmpty());
    }

    @Test
    @Transactional
    public void testFindTaskInTransaction() {
        Task task = entityManager.find(Task.class, 3L, LockModeType.PESSIMISTIC_READ);
        Assert.assertNotNull(task);
    }

    @Test
    public void testCleanUpStaleTasks() {
        Date expired = new Date(System.currentTimeMillis());
        int tasksFinalized = taskProcessorRepository.cleanUpStaleTasks("ERROR: ", expired, "QUEUED", "IN PROGRESS...",
            "DONE PROCESSING");
        Assert.assertEquals(tasksFinalized, 3);

        tasksFinalized = taskProcessorRepository.cleanUpStaleTasks("ERROR: ", expired, "QUEUED", "IN PROGRESS...",
            "DONE PROCESSING");
        Assert.assertEquals(tasksFinalized, 0);

        Task task = taskProcessorRepository.findByTenantUuidAndUuid("X", "c");
        task.setStatus("IN PROGRESS...");
        taskProcessorRepository.saveAndFlush(task);
        tasksFinalized = taskProcessorRepository.cleanUpStaleTasks("ERROR: ", expired, "QUEUED", "IN PROGRESS...",
            "DONE PROCESSING");
        Assert.assertEquals(tasksFinalized, 0);

        expired = new Date(System.currentTimeMillis());
        tasksFinalized = taskProcessorRepository.cleanUpStaleTasks("ERROR: ", expired, "QUEUED", "IN PROGRESS...",
            "DONE PROCESSING");
        Assert.assertEquals(tasksFinalized, 1);
    }
}
