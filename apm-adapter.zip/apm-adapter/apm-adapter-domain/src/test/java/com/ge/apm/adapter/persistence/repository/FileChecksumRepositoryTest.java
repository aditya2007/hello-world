/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.persistence.repository;

import java.sql.Date;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.TestApp;
import com.ge.apm.adapter.domain.persistence.entity.FileChecksum;
import com.ge.apm.adapter.domain.persistence.repository.IFileChecksumRepository;

/**
 * Description of FileChecksumRepositoryTest
 *
 * @author Albert H. Yu hsiang-aiyu
 * @version 1.0 Feb 28, 2017
 * @since 1.0
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApp.class)
public class FileChecksumRepositoryTest {

    @Autowired
    IFileChecksumRepository fileChecksumRepository;

    @Test
    public void findOne() {
        FileChecksum absent = fileChecksumRepository.findOne(Long.MIN_VALUE);
        Assert.assertNull(absent);
    }

    @Test
    public void findByTenantUuidAndTaskId() {
        FileChecksum absent = fileChecksumRepository.findByTenantUuidAndTaskId("dummy-tenant-uuid", Long.MIN_VALUE);
        Assert.assertNull(absent);
    }

    @Test
    public void findByTenantUuidAndChecksum() {
        Assert.assertNull(fileChecksumRepository.findByTenantUuidAndChecksum("tenantUuid", "checksum"));
    }

    @Test
    public void deleteWhenOlderThan() {
        Assert.assertEquals(0, fileChecksumRepository.deleteWhenOlderThan(new Date(0L)));
    }
}
