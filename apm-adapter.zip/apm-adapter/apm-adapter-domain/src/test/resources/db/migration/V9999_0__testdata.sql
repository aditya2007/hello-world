INSERT INTO INGESTION_TASK (id, uuid, created_on, updated_on, description, status, tenant_id, parent_task) VALUES
(1, 'a',CURRENT_DATE, CURRENT_DATE, 'root','DONE PROCESSING','X', NULL),
(2, 'b',CURRENT_DATE, CURRENT_DATE, 'json','IN PROGRESS...','X', 1),
(3, 'c',CURRENT_DATE, CURRENT_DATE, 'leaf','COMPLETED','X', 2),
(4, 'e',CURRENT_DATE, CURRENT_DATE, 'root','QUEUED','X', NULL);

INSERT INTO INGESTION_LOG_MSG (id, task_uuid, msg_code, msg_type, msg, action, resolution, actual_msg) VALUES
(1, 'a','E10000', 'ERROR','General Error', 'System Failure','Contact support','Stacktrace');

