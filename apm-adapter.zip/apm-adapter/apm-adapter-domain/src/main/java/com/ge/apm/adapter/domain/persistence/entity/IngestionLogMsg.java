/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.domain.persistence.entity;

import javax.persistence.Column;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@javax.persistence.Entity
@Table(name = "INGESTION_LOG_MSG")
@Getter
@Setter
@ToString(callSuper = true)
public class IngestionLogMsg extends com.ge.apm.adapter.domain.persistence.entity.Entity {

    private static final long serialVersionUID = 4342354869112892L;

    @Column(name = "MSG_CODE", nullable = false, length = 50)
    private String msgCode;

    @Column(name = "MSG_TYPE", nullable = false, length = 50)
    private String msgType;

    @Column(name = "MSG", nullable = false, length = 5000)
    private String msg;

    @Column(name = "ACTION", nullable = false, length = 500)
    private String action;

    @Column(name = "RESOLUTION", nullable = false, length = 5000)
    private String resolution;

    @Column(name = "ACTUAL_MSG", nullable = true, length = 5000)
    private String actualMsg;

    @Column(name = "task_uuid", nullable = false)
    private String taskUuid;
}
