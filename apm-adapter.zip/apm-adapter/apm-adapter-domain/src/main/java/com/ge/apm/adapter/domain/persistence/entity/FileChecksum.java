/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.domain.persistence.entity;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Description of FileChecksum
 *
 * @author Albert H. Yu hsiang-aiyu
 * @version 1.0 Feb 28, 2017
 * @since 1.0
 */
@javax.persistence.Entity
@Table(name = "FILE_CHECKSUM")
@Getter
@Setter
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class FileChecksum extends com.ge.apm.adapter.domain.persistence.entity.Entity {

    private static final long serialVersionUID = 6410067854869112892L;

    @Column(name = "TENANT_ID", nullable = false, length = 50)
    private String tenantUuid;

    @Column(name = "NAME", nullable = false, length = 500)
    private String name;

    @Column(name = "CHECKSUM", nullable = false)
    private String checksum;

    @OneToOne(optional = false)
    @JoinColumn(name = "INGESTION_TASK_ID", referencedColumnName = "ID")
    private Task task;
}
