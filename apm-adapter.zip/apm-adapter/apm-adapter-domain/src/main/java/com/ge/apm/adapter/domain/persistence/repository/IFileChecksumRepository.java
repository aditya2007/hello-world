/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.domain.persistence.repository;

import java.sql.Date;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.adapter.domain.persistence.IBaseRepository;
import com.ge.apm.adapter.domain.persistence.entity.FileChecksum;

/**
 * Description of IFileChecksumRepository
 *
 * @author Albert H. Yu hsiang-aiyu
 * @version 1.0 Feb 28, 2017
 * @since 1.0
 */
@Repository
@SuppressWarnings("PMD.TooManyMethods")
public interface IFileChecksumRepository extends IBaseRepository<FileChecksum, Long> {

    FileChecksum findByTenantUuidAndChecksum(String tenantUuid, String checksum);

    @Query("SELECT fc FROM FileChecksum fc WHERE fc.tenantUuid = ?1 and fc.task.id = ?2 ")
    FileChecksum findByTenantUuidAndTaskId(String tenantUuid, Long taskId);

    @Modifying
    @Query("DELETE FROM FileChecksum fc WHERE fc.createdOn < ?1")
    @Transactional
    int deleteWhenOlderThan(Date expired);

    @SuppressWarnings("unchecked")
    @Transactional
    @Override
    FileChecksum save(FileChecksum fileChecksum);

    @SuppressWarnings("unchecked")
    @Transactional
    @Override
    FileChecksum saveAndFlush(FileChecksum fileChecksum);
}
