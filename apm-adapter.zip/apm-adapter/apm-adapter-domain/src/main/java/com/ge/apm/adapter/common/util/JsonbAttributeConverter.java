/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.util;

import java.io.IOException;
import javax.persistence.Converter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

import org.postgresql.util.PGobject;

@Converter(autoApply = true)
public class JsonbAttributeConverter implements javax.persistence.AttributeConverter<JsonNode, Object> {

    private final ObjectReader objectReader = new ObjectMapper().reader();

    @Override
    public Object convertToDatabaseColumn(JsonNode objectValue) {
        try {
            PGobject out = new PGobject();
            out.setType("jsonb");
            if (objectValue == null) {
                out.setValue(null);
            } else {
                out.setValue(objectValue.toString());
            }
            return out;
        } catch (Exception ex) {
            throw new IllegalArgumentException("Unable to serialize to json field ", ex);
        }
    }

    @Override
    public JsonNode convertToEntityAttribute(Object dataValue) {
        if (dataValue == null) {
            return null;
        } else if (dataValue instanceof PGobject && "jsonb".equals(((PGobject) dataValue).getType())) {
            try {
                return objectReader.readTree(((PGobject) dataValue).getValue());
            } catch (IOException ioe) {
                throw new IllegalStateException("Unable to read JSONB data from db ", ioe);
            }
        }

        throw new UnsupportedOperationException("Unsupported data type: " + dataValue.getClass());
    }
}
