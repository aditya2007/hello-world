/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.domain.persistence.entity;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Getter;
import lombok.Setter;
import org.eclipse.persistence.annotations.BatchFetch;
import org.eclipse.persistence.annotations.BatchFetchType;

import com.ge.apm.adapter.common.util.JsonbAttributeConverter;

@Entity
@Table(name = "INGESTION_TASK")
@Getter
@Setter
public class Task extends com.ge.apm.adapter.domain.persistence.entity.BaseEntity {

    private static final long serialVersionUID = 6410067854869112892L;

    @Column(name = "TENANT_ID", nullable = false, length = 50)
    private String tenantUuid;

    @Column(name = "DESCRIPTION", nullable = false, length = 500)
    private String description;

    @Column(name = "STATUS", nullable = false, length = 5000)
    private String status;

    @JoinColumn(name = "PARENT_TASK", referencedColumnName = "ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Task parent;

    @BatchFetch(value = BatchFetchType.EXISTS)
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "TASK_UUID", referencedColumnName = "UUID", nullable = true)
    private List<IngestionLogMsg> ingestionLogMsgList;

    @Column(name = "TOTAL_COUNT")
    private Long totalCount = new Long(0);

    @Column(name = "COMPLETED_COUNT")
    private Long completedCount = new Long(0);

    @Column(name = "TASK_TYPE")
    private String taskType;

    @Column(name = "TASK_RESPONSE")
    @Convert(converter = JsonbAttributeConverter.class)
    private JsonNode taskResponse;

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        if (!super.equals(obj)) {
            return false;
        }

        Task task = (Task) obj;

        if (tenantUuid != null ? !tenantUuid.equals(task.tenantUuid) : task.tenantUuid != null) {
            return false;
        }
        if (description != null ? !description.equals(task.description) : task.description != null) {
            return false;
        }
        if (status != null ? !status.equals(task.status) : task.status != null) {
            return false;
        }
        if (parent != null ? !parent.equals(task.parent) : task.parent != null) {
            return false;
        }
        if (ingestionLogMsgList != null ? !ingestionLogMsgList.equals(task.ingestionLogMsgList)
            : task.ingestionLogMsgList != null) {
            return false;
        }
        if (totalCount != null ? !totalCount.equals(task.totalCount) : task.totalCount != null) {
            return false;
        }
        if (completedCount != null ? !completedCount.equals(task.completedCount) : task.completedCount != null) {
            return false;
        }
        return taskType != null ? taskType.equals(task.taskType) : task.taskType == null;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (tenantUuid != null ? tenantUuid.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (parent != null ? parent.hashCode() : 0);
        result = 31 * result + (ingestionLogMsgList != null ? ingestionLogMsgList.hashCode() : 0);
        result = 31 * result + (totalCount != null ? totalCount.hashCode() : 0);
        result = 31 * result + (completedCount != null ? completedCount.hashCode() : 0);
        result = 31 * result + (taskType != null ? taskType.hashCode() : 0);
        return result;
    }
}
