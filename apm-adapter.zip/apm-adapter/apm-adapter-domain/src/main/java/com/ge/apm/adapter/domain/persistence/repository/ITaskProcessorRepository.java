/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.domain.persistence.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ge.apm.adapter.domain.persistence.IBaseRepository;
import com.ge.apm.adapter.domain.persistence.entity.Task;

@Repository
@SuppressWarnings("PMD.TooManyMethods")
public interface ITaskProcessorRepository extends IBaseRepository<Task, Long> {

    Task findByTenantUuidAndUuid(String tenantUuid, String uuid);

    @Query("SELECT t FROM Task t WHERE t.tenantUuid = ?1 and t.parent IS NULL "
            + "and (t.taskType IS NULL or t.taskType NOT IN ('Download'))")
    List<Task> findRootTasks(String tenantUuid);

    @Query("SELECT t FROM Task t WHERE t.tenantUuid = ?1 and t.parent IS NULL "
            + "and (t.taskType IS NULL or t.taskType NOT IN ('Download'))")
    Page<Task> findRootTasks(String tenantUuid, Pageable page);

    @Modifying
    @Query("UPDATE Task SET status = ?1 WHERE updatedOn < ?2 and status IN ?3")
    @Transactional
    int cleanUpStaleTasks(String finalStatus, java.sql.Date expired, String... status);

    @Modifying
    @Query("UPDATE Task SET status = ?1 WHERE updatedOn < ?2 and status IN ?3 and taskType = 'Download'")
    @Transactional
    int cleanUpStaleDownloadTasks(String finalStatus, java.sql.Date expired, String... status);

    @Query("SELECT t.uuid FROM Task t WHERE t.parent IS NULL and t.updatedOn < ?1 and t.status IN ?2 "
            + "and (t.taskType IS NULL or t.taskType NOT IN ('Download'))")
    @Transactional
    List<String> getStaleRootTasksUuid(java.sql.Date expired, String... status);

    @Query("SELECT t FROM Task t WHERE t.tenantUuid = ?1 and t.parent.uuid = ?2 " + " and t.status <> 'ARCHIVED'")
    List<Task> findChildren(String tenantUuid, String parentTaskId);

    @Query("SELECT t FROM Task t LEFT JOIN FETCH t.parent WHERE t.tenantUuid = ?1 and t.parent.uuid = ?2")
    List<Task> findAllChildren(String tenantUuid, String parentTaskId);

    @Query("SELECT t FROM Task t WHERE t.tenantUuid = ?1 and t.parent.uuid = ?2")
    List<Task> findChildrenIncludeArchived(String tenantUuid, String parentTaskId);

    @Query("SELECT sum(t.completedCount) FROM Task t WHERE t.tenantUuid = ?1 and t.parent.uuid = ?2")
    Long findTotalCompletedCountForSiblings(String tenantUuid, String parentTaskId);

    @Query("SELECT count(t.id) FROM Task t WHERE t.parent.uuid = ?1 and t.tenantUuid = ?2")
    Integer findCountOfAllChildren(String taskUuid, String tenantUuid);

    @Query("SELECT count(t.id) FROM Task t WHERE t.parent.id = ?1 AND t.status IN ?2")
    Integer findCountOfChildrenInStatus(Long taskId, String... status);

    @Query("SELECT t FROM Task t WHERE t.parent.id = ?1 AND t.status IN ?2")
    List<Task> findChildrenInStatus(Long taskId, String... status);

    @Query("SELECT count(t.id) FROM Task t WHERE t.parent.id = ?1 AND t.status LIKE ?2")
    Integer findCountOfChildrenInError(Long taskId, String status);

    @SuppressWarnings("unchecked")
    @Override
    Task save(Task task);

    @SuppressWarnings("unchecked")
    @Override
    Task saveAndFlush(Task task);

    @Query("SELECT t FROM Task t WHERE t.tenantUuid = ?1 and t.parent IS NULL AND t.createdOn >= ?2 "
        + "AND t.createdOn <= ?3 and (t.taskType IS NULL or t.taskType NOT IN ('Download'))")
    Page<Task> searchCreatedOn(String tenantUuid, Date startDate, Date endDate, Pageable page);

    @Query("SELECT t FROM Task t WHERE t.tenantUuid = ?1 and t.parent IS NULL AND t.updatedOn >= ?2 "
        + "AND t.updatedOn <= ?3 and (t.taskType IS NULL or t.taskType NOT IN ('Download'))")
    Page<Task> searchUpdatedOn(String tenantUuid, Date startDate, Date endDate, Pageable page);

    @Query("SELECT t FROM Task t WHERE t.tenantUuid = ?1 and t.parent IS NULL AND t.uuid LIKE ?2 "
            + "and (t.taskType IS NULL or t.taskType NOT IN ('Download'))")
    Page<Task> searchUuidWildcard(String tenantUuid, String value, Pageable page);

    @Query("SELECT t FROM Task t WHERE t.tenantUuid = ?1 and t.parent IS NULL AND t.status LIKE ?2 "
            + "and (t.taskType IS NULL or t.taskType NOT IN ('Download'))")
    Page<Task> searchStatusWildcard(String tenantUuid, String value, Pageable page);

    @Query("SELECT sum(t.completedCount), sum(t.totalCount) FROM Task t WHERE t.tenantUuid = ?1 and t.parent.id IN ?2")
    Object[][] findTotalCompletedCountBasedOnJsonParentIds(String tenantUuid, List<Long> parentTaskId);

    @Query("SELECT t FROM Task t WHERE t.tenantUuid = ?1 and t.parent.id IN ?2")
    List<Task> findChildrenTasksBasedOnParentTasks(String tenantUuid, List<Long> parentTaskId);

    @Query("SELECT t FROM Task t WHERE t.tenantUuid = ?1 and t.taskType = 'Download' and t.status = 'IN PROGRESS...'")
    Task findDownloadTaskInProgress(String tenantUuid);

    @Query("SELECT t.uuid FROM Task t WHERE t.updatedOn < ?1 and t.status IN ?2 "
        + "and t.taskType ='Download'")
    @Transactional
    List<String> getStaleDownloadTasksUuid(java.sql.Date expired, String... status);
}
