CREATE TABLE INGESTION_TASK
(
  id bigserial NOT NULL PRIMARY KEY,
  uuid text NOT NULL,
  is_active boolean DEFAULT true,
  created_on timestamp without time zone DEFAULT now(),
  updated_on timestamp without time zone DEFAULT now(),
  description text NOT NULL,
  status text NOT NULL,
  tenant_id text NOT NULL,
  parent_task bigint,
  CONSTRAINT ingestion_task_fk2 FOREIGN KEY (parent_task)
      REFERENCES ingestion_task (id)
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT ingestion_task_uk UNIQUE (uuid)
);

CREATE INDEX idx_18358_ingestion_task_created_on
  ON ingestion_task  (created_on);

CREATE INDEX idx_18358_ingestion_task_updated_on
  ON ingestion_task  (updated_on);

CREATE TABLE INGESTION_LOG_MSG
(
  id bigserial NOT NULL PRIMARY KEY,
  task_uuid text NOT NULL,
  msg_code text NOT NULL,
  created_on timestamp without time zone DEFAULT now(),
  updated_on timestamp without time zone DEFAULT now(),
  msg_type text NOT NULL,
  msg text NOT NULL,
  action text NOT NULL,
  resolution text NOT NULL,
  CONSTRAINT ingestion_log_msg_fk2 FOREIGN KEY (task_uuid)
      REFERENCES ingestion_task (uuid)
      ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE INDEX idx_18358_ingestion_log_msg_created_on
  ON ingestion_log_msg  (created_on);

CREATE INDEX idx_18358_ingestion_log_msg_updated_on
  ON ingestion_log_msg  (updated_on);
