CREATE TABLE FILE_CHECKSUM
(
  id bigserial NOT NULL PRIMARY KEY,
  tenant_id text NOT NULL,
  name text NOT NULL,
  checksum text NOT NULL,
  ingestion_task_id bigint NOT NULL,
  created_on timestamp without time zone DEFAULT now(),
  updated_on timestamp without time zone DEFAULT null,
  CONSTRAINT file_checksum_fk FOREIGN KEY (ingestion_task_id)
      REFERENCES ingestion_task (id)
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT file_checksum_uk1 UNIQUE (tenant_id, checksum),
  CONSTRAINT file_checksum_uk2 UNIQUE (ingestion_task_id)
);

CREATE INDEX idx_18358_file_checksum_checksum
  ON file_checksum  (checksum);

CREATE INDEX idx_18358_file_checksum_created_on
  ON file_checksum  (created_on);

