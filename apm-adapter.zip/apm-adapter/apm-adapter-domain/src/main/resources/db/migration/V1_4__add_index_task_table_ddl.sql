CREATE INDEX idx_ingestion_parent_task
  ON INGESTION_TASK
  (parent_task);
CREATE INDEX idx_ingestion_log_msg_task_uuid
  ON INGESTION_LOG_MSG
  (task_uuid);
