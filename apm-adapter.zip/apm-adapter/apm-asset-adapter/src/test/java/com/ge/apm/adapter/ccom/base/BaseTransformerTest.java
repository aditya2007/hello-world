/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.base;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.ObjectWriter;
import lombok.Data;
import org.junit.Assert;
import org.junit.Before;
import org.mockito.Mockito;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.EntityTransformer;
import com.ge.apm.adapter.common.util.DtoDispatcher;
import com.ge.apm.asset.model.Base;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.CCOMData;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.common.json.patch.PatchOperation;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyVararg;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.startsWith;
import static org.mockito.Mockito.doAnswer;

@SuppressWarnings({ "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public abstract class BaseTransformerTest<T extends Base> {

    protected static final String Id1 = "Id1";

    protected static final String Id2 = "Id2";

    protected static final String Id3 = "Id3";

    protected static final String Id4 = "Id4";

    protected static final String Id5 = "Id5";

    protected static final String Id6 = "Id6";

    protected static final String Uuid1 = "bb571726-c1a3-4610-99de-435ab7f74000";

    protected static final String Uuid2 = "bb571726-c1a3-4610-99de-435ab7f74001";

    protected static final String Uuid3 = "bb571726-c1a3-4610-99de-435ab7f74002";

    protected static final String Uuid4 = "bb571726-c1a3-4610-99de-435ab7f74003";

    protected static final String Uuid5 = "bb571726-c1a3-4610-99de-435ab7f74004";

    protected static final String Uuid6 = "bb571726-c1a3-4610-99de-435ab7f74005";

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static final ObjectReader READER = MAPPER.reader(PatchOperation[].class);

    private static final ObjectWriter WRITER = MAPPER.writer();

    private static Unmarshaller unmarshaller;

    static {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance("com.ge.apm.ccom.model:com.ge.apm.ccom.model.custom");
            unmarshaller = jaxbContext.createUnmarshaller();
        } catch (JAXBException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    @Inject
    protected Configuration configuration;

    @Inject
    protected EntityTransformer entityTransformer;

    @Inject
    protected AssetClient assetClient;

    protected List<String> postUris;

    protected ValidationFailedException validationFailedException;

    protected DtoDispatcher dtoDispatcher;

    protected static String getAssetUrl() {
        return "http://ApmAsset";
    }

    protected static String getTenantUuid() {
        return "TenantUuid";
    }

    protected static String getAuthorization() {
        return "Authorization";
    }

    @Before
    public void setup() {
        postUris = new LinkedList<>();
        validationFailedException = Mockito.mock(ValidationFailedException.class);
        dtoDispatcher = Mockito.mock(DtoDispatcher.class);
        ReflectionTestUtils.setField(assetClient, "dtoDispatcher", configuration.getDtoDispatcher());
    }

    protected abstract String getPrefix();

    protected abstract Class<T> getObjectClass();

    protected void setupPOSTFor(String uri, T[] expectedObjects, T... returnObjects) {
        setupPOSTFor(uri, expectedObjects, returnObjects, returnObjects.getClass());
    }

    @SuppressWarnings("unchecked")
    protected <TDto extends Base, TReturn> void setupPOSTFor(String uri, TDto[] expectedObjects, TReturn returnData,
        Class<?> returnDataClass) {
        doAnswer(invocationOnMock -> {
            postUris.add(uri);
            Object[] calledWithDtos = invocationOnMock.getArguments();
            Assert.assertArrayEquals(expectedObjects, calledWithDtos);
            return returnData;
        }).when(configuration.getDtoDispatcher()).sendDtos(anyVararg());
    }

    @SuppressWarnings("unchecked")
    protected <TDto extends Base, TReturn> void setupPOSTForMultipleCalls(String uri,
        Map<TDto[], TReturn> expectedObjectsReturnDataMap, Class<?> returnDataClass) {

        // This method accepts a map of expected objects to return data, to handle multiple POST calls
        // on the same url.
        doAnswer(invocation -> {
            postUris.add(uri);
            TDto[] callWithDtos = (TDto[]) invocation.getArguments();
            TReturn returnData = null;
            for (TDto[] expectedObjects : expectedObjectsReturnDataMap.keySet()) {
                boolean match = true;
                if (expectedObjects.length == callWithDtos.length) {
                    for (int i = 0; i < expectedObjects.length; i++) {
                        if (!expectedObjects[i].getSourceKey().equals(callWithDtos[i].getSourceKey())) {
                            match = false;
                        }
                    }
                }
                if (match) {
                    returnData = expectedObjectsReturnDataMap.get(expectedObjects);
                }
            }
            Assert.assertNotNull(returnData);
            return returnData;
        }).when(configuration.getDtoDispatcher()).sendDtos(anyVararg());
    }

    protected void throwExceptionForPOST(Exception exception) {
        Mockito.doThrow(exception).when(configuration.getDtoDispatcher()).sendDtos(anyVararg());
    }

    protected void verifyPOSTCalls(String... uris) {
        String[] notFound = Arrays.stream(uris).filter(uri -> !postUris.contains(uri)).toArray(String[]::new);
        Assert.assertTrue("POST not called for uris: " + Arrays.toString(notFound), notFound.length == 0);
    }

    protected List<Entity> fetchEntities(String filePath) throws JAXBException {

        Object data = unmarshaller.unmarshal(this.getClass().getResourceAsStream(filePath));
        Assert.assertTrue(data instanceof CCOMData);
        CCOMData ccomData = (CCOMData) data;
        return ccomData.getEntity();
    }

    protected T[] readObjectsFromResourceFile(String filePath) throws IOException {
        return readObjectsFromResourceFile(filePath, getObjectClass());
    }

    protected void setupLookupObjectUriFor(String sourceKey, String uuid) {
        setupLookupObjectUriFor(sourceKey, getPrefix(), uuid);
    }

    protected void setupLookupObjectUriFor(String sourceKey, String prefix, String uuid) {
        doAnswer(invocation -> {
            Base object = new Base();
            object.setUri(Prefixes.uri(prefix, uuid));
            return new ResponseEntity<>(object, HttpStatus.OK);
        }).when(configuration.restTemplate()).exchange(
            startsWith(getAssetUrl() + prefix + "/bySourceKey?sourceKey=" + sourceKey), eq(HttpMethod.GET),
            any(HttpEntity.class), eq(Base.class));
    }

    protected void setupGetGroup(String uuid, String prefix, String category) {
        doAnswer(invocation -> {
            Group object = new Group();
            object.setCategory(category);
            return new ResponseEntity<>(object, HttpStatus.OK);
        }).when(configuration.restTemplate()).exchange(startsWith(getAssetUrl() + prefix + "/" + uuid),
            eq(HttpMethod.GET), any(HttpEntity.class), eq(Group.class));
    }

    protected void setupReservedAttributeConfig(String prefix, Map<String, String> nameTypeMap) {
        Map<String, ReservedAttributeConfig> reservedAttributeConfigMap = new LinkedHashMap<>();
        for (Map.Entry<String, String> entry : nameTypeMap.entrySet()) {
            ReservedAttributeConfig reservedAttributeConfig = new ReservedAttributeConfig();
            reservedAttributeConfig.setName(entry.getKey());
            reservedAttributeConfig.setDisplayName(entry.getKey());
            reservedAttributeConfig.setType(entry.getValue());
            reservedAttributeConfig.setArrayType("NA");
            List<Object> possibleValues = new ArrayList<>();
            reservedAttributeConfig.setOverwrite(true);
            reservedAttributeConfig.setPossibleValues(possibleValues);
            if (entry.getKey().equals("faultMode")) {
                if (getPrefix().compareTo(Prefixes.Assets) == 0) {
                    reservedAttributeConfig.setArrayType("NA");
                    possibleValues.add("M1");
                    possibleValues.add("M2");
                    reservedAttributeConfig.setOverwrite(true);
                } else if (getPrefix().compareTo(Prefixes.AssetTypes) == 0) {
                    reservedAttributeConfig.setArrayType("ONE_DIMENSIONAL");
                }
            }
            if (entry.getKey().equals("status") && (getPrefix().compareTo(Prefixes.Assets) == 0
                || getPrefix().compareTo(Prefixes.MeasurementTags) == 0)) {
                Map<String, String> keyValMap = new HashMap<>();
                keyValMap.put("key", "01");
                possibleValues.add(keyValMap);
                keyValMap = new HashMap<>();
                keyValMap.put("key", "02");
                possibleValues.add(keyValMap);
                keyValMap = new HashMap<>();
                keyValMap.put("key", "03");
                possibleValues.add(keyValMap);
                reservedAttributeConfig.setOverwrite(false);
                reservedAttributeConfig.setPossibleValues(possibleValues);
            }
            if (entry.getKey().equals("state") && getPrefix().compareTo(Prefixes.Assets) == 0) {
                Map<String, String> keyValMap = new HashMap<>();
                keyValMap.put("key", "01");
                possibleValues.add(keyValMap);
                keyValMap = new HashMap<>();
                keyValMap.put("key", "02");
                possibleValues.add(keyValMap);
                keyValMap = new HashMap<>();
                keyValMap.put("key", "03");
                possibleValues.add(keyValMap);
                keyValMap.put("key", "04");
                possibleValues.add(keyValMap);
                keyValMap.put("key", "05");
                possibleValues.add(keyValMap);
                keyValMap.put("key", "06");
                possibleValues.add(keyValMap);
                reservedAttributeConfig.setOverwrite(false);
                reservedAttributeConfig.setPossibleValues(possibleValues);
            }
            if (entry.getKey().equals("uom") && (getPrefix().compareTo(Prefixes.MeasurementTagTypes) == 0
                || getPrefix().compareTo(Prefixes.MeasurementTags) == 0)) {
                List<Map<String, List<Map<String, String>>>> unitGroups = getUnitGroups();
                reservedAttributeConfig.setPossibleValues(Arrays.asList(unitGroups.toArray()));
                reservedAttributeConfig.setOverwrite(true);
            }

            reservedAttributeConfigMap.put(entry.getKey(), reservedAttributeConfig);
        }

        Mockito.doReturn(new ResponseEntity<>(reservedAttributeConfigMap, HttpStatus.OK)).when(
            configuration.restTemplate()).exchange(startsWith(getAssetUrl() + prefix + "/reservedAttributes"),
            eq(HttpMethod.GET), any(HttpEntity.class),
            eq(new ParameterizedTypeReference<Map<String, ReservedAttributeConfig>>() { }));
    }

    private List<Map<String, List<Map<String, String>>>> getUnitGroups() {
        List<Map<String, List<Map<String, String>>>> unitGroups = new ArrayList<>();

        Map<String, List<Map<String, String>>> map = new HashMap<String, List<Map<String, String>>>();
        Map<String, String> innerMap1 = new HashMap<>();
        Map<String, String> innerMap2 = new HashMap<>();
        innerMap1.put("unit", "meters");
        innerMap2.put("unit", "miles");
        List<Map<String, String>> list1 = new ArrayList<Map<String, String>>();
        list1.add(innerMap1);
        list1.add(innerMap2);
        map.put("measurementUnitResource", list1);
        unitGroups.add(map);
        return unitGroups;
    }

    @SuppressWarnings("unchecked")
    protected <X> X[] readObjectsFromResourceFile(String filePath, Class<X> clazz) throws IOException {
        return (X[]) new ObjectMapper().readValue(this.getClass().getResourceAsStream(filePath),
            Array.newInstance(clazz, 0).getClass());
    }

    protected void testWithNoSourceKeyLookup(String testName)
        throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/" + testName + ".xml");
        T[] expectedObjects = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/" + testName + ".json");
        T[] returnObjects = readObjectsFromResourceFile("/assetOut" + getPrefix() + "/" + testName + ".json");

        setupPOSTFor(getPrefix(), expectedObjects, returnObjects);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    protected void testWithOneSourceKeyLookup(String testName, String sourceKey, String uuid)
        throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/" + testName + ".xml");
        T[] expectedObjects = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/" + testName + ".json");
        T[] returnObjects = readObjectsFromResourceFile("/assetOut" + getPrefix() + "/" + testName + ".json");

        setupLookupObjectUriFor(sourceKey, uuid);
        setupPOSTFor(getPrefix(), expectedObjects, returnObjects);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @org.springframework.context.annotation.Configuration
    @EnableAutoConfiguration(exclude = DataSourceAutoConfiguration.class)
    @ComponentScan(
        { "com.ge.apm.adapter.ccom.transformer", "com.ge.apm.adapter.ccom.rest.client", "com.ge.apm.adapter.ccom.util",
            "com.ge.apm.adapter.common.util" })
    @PropertySource(value = "test-application.properties")
    public static class Configuration {

        private final RestTemplate restTemplate;

        private final DtoDispatcher dtoDispatcher;

        public Configuration() {
            this.restTemplate = Mockito.mock(RestTemplate.class);
            this.dtoDispatcher = Mockito.mock(DtoDispatcher.class);
        }

        @Bean
        public RestTemplate restTemplate() {
            return restTemplate;
        }

        @Bean
        public DtoDispatcher getDtoDispatcher() {
            return this.dtoDispatcher;
        }
    }

    @Data
    protected static class PatchData {

        private String uri;

        private PatchOperation[] patchOperations;
    }
}
