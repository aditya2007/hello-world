/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.ge.apm.adapter.ccom.transformer.instance.DtoTransformer;
import com.ge.apm.asset.model.Named;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.network.topologies.AssetMesh;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.junit.Assert.fail;

/**
 * Description of EntityTransformerTest
 *
 * @author Deepak 212400139
 * @version 1.0 Mar 10, 2016
 * @since 1.0
 */

public class EntityTransformerTest {

    public EntityTransformer et;

    @Mock
    private EntityTransformerFactory entityTransformerFactory;

    @Mock
    private DtoTransformer dtoTransformer;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        et = new EntityTransformer(entityTransformerFactory, dtoTransformer);
    }

    @Test
    public void testTransformEntitiesWithEntitiesNotReturned() throws ValidationFailedException {
        Entity e1 = new AssetMesh();
        Entity e2 = new AssetMesh();
        List<Entity> entities = new ArrayList<Entity>();
        entities.add(e1);
        entities.add(e2);
        Assert.assertEquals("Entities transformed",
            et.transformEntities(entities, "ApmAuthorization", "ApmTenantUuid", "TraceUuid", "", "", false));
    }

    //	@Ignore @Test
    //	public void testTransformEntitiesWithEntitiesReturned() throws ValidationFailedException {
    //		Entity e1 = new AssetMesh();
    //		Entity e2 = new AssetMesh();
    //		List<Entity> entities = new ArrayList<Entity>();
    //		entities.add(e1);
    //		entities.add(e2);
    //
    //		Mockito.when(entityTransformerFactory.getTransformerFor(Mockito.any(AssetMesh.class)))
    //				.thenReturn(new AssetMeshTransformer(null));
    //
    //		Assert.assertEquals("Entities transformed",
    //				et.transformEntities(entities, "ApmAuthorization", "ApmTenantUuid", "TraceUuid"));
    //	}

    @Test
    public void testTransformEntitiesThrowsServiceException() throws ValidationFailedException {
        try {
            Entity e1 = new AssetMesh();
            List<Entity> entities = new ArrayList<Entity>();
            entities.add(e1);
            Mockito.doThrow(new ServiceException("ServiceException", "args")).when(entityTransformerFactory)
                .doDispatch();
            et.transformEntities(entities, "ApmAuthorization", "ApmTenantUuid", "TraceUuid", "", "", false);
            fail("Should throw ServiceException");
        } catch (ServiceException exc) {
            Assert.assertNotNull(et);
        }
    }

    @Test
    public void testTransformEntitiesThrowsGenericException() throws ValidationFailedException {

        try {
            Entity e1 = new AssetMesh();
            List<Entity> entities = new ArrayList<Entity>();
            entities.add(e1);
            Mockito.doThrow(new IllegalArgumentException("GenericException")).when(entityTransformerFactory)
                .doDispatch();
            et.transformEntities(entities, "ApmAuthorization", "ApmTenantUuid", "TraceUuid", "", "", false);
            fail("Should throw ServiceException");
        } catch (ServiceException exc) {
            Assert.assertNotNull(et);
        }
    }

    @Test
    public void testTransformDtos() {
        Named n1 = new Named();
        List<Named> names = new ArrayList<Named>();
        names.add(n1);
        Assert.assertEquals("DTOs transformed",
            et.transformDtos(names, "ApmAuthorization", "ApmTenantUuid", "traceUuid", "taskUuid"));
    }

    @Test
    public void testTransformDtosThrowsServiceException() {
        Named n1 = new Named();
        List<Named> names = new ArrayList<Named>();
        names.add(n1);
        try {
            Mockito.doThrow(new IllegalArgumentException("GenericException")).when(dtoTransformer).transform(
                Mockito.any());
            Assert.assertEquals("DTOs transformed",
                et.transformDtos(names, "ApmAuthorization", "ApmTenantUuid", "traceUuid", "taskUuid"));
            fail("Should throw ServiceException");
        } catch (ServiceException exc) {
            Assert.assertNotNull(et);
        }
    }

    @After
    public void destroy() {
        entityTransformerFactory = null;
        dtoTransformer = null;
        et = null;
    }
}
