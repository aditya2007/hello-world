/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.io.IOException;
import java.util.List;
import javax.xml.bind.JAXBException;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.ccom.base.BaseTransformerTest;
import com.ge.apm.asset.model.Base;
import com.ge.apm.asset.model.Group;
import com.ge.apm.asset.model.GroupType;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.startsWith;

/**
 * Unit test for {@link GroupTransformer}.
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Feb 23, 2016
 * @since 1.0
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BaseTransformerTest.Configuration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class GroupTransformerTest extends BaseTypedTransformerTest<Group> {

    @Override
    protected String getPrefix() {
        return Prefixes.Groups;
    }

    @Override
    protected Class<Group> getObjectClass() {
        return Group.class;
    }

    @Override
    protected String getTypePrefix() {
        return Prefixes.GroupTypes;
    }

    @Override
    protected void setupLookupForCreate() {
        setupGroupTypeLookUp();
    }

    @Override
    protected void setupLookupForUpdate() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetGroup(Uuid1, Prefixes.Groups, "TAG");
        setupGetGroup(Uuid2, Prefixes.Groups, "TAG");
        setupGroupTypeLookUp();
    }

    @Override
    protected void setupLookupForUpdateOne() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetGroup(Uuid1, Prefixes.Groups, "TAG");
        setupGroupTypeLookUp();
    }

    @Ignore("todo")
    @Test
    @Override
    public void createThrowExceptionOnIdMissing() throws IOException {
        //Added an empty line for PMD.
    }

    @Ignore("todo")
    @Test
    @Override
    public void createThrowException() throws IOException {
        //Added an empty line for PMD.
    }

    @Test(expected = ValidationFailedException.class)
    public void createNullSourceKey() throws JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/create.xml");
        entities.get(0).setGUID(null);
        setupLookupForCreate();
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    /**
     * Set up the look up for group type to return 'NOT_FOUND' for the first time so that it executes
     * GroupTransformer.createTagGroupType(). The second time it returns the group type which has been mocked.
     */
    @SuppressWarnings("unchecked")
    private void setupGroupTypeLookUp() {
        GroupType groupType = new GroupType();
        groupType.setUri(Prefixes.uri(getTypePrefix(), Uuid6));
        ResponseEntity<Base> response1 = new ResponseEntity<>(HttpStatus.NOT_FOUND);
        ResponseEntity<Base> response2 = new ResponseEntity<>(groupType, HttpStatus.OK);
        Mockito.when(configuration.restTemplate()
            .exchange(startsWith(getAssetUrl() + getTypePrefix() + "/bySourceKey?sourceKey=" + GroupType.SOURCE_KEY),
                eq(HttpMethod.GET), any(HttpEntity.class), eq(Base.class))).thenReturn(response1, response2);
    }
}
