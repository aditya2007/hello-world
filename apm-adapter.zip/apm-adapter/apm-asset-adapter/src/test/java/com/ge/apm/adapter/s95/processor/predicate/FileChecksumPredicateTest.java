/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.predicate;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.impl.DefaultMessage;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.ge.apm.adapter.domain.persistence.entity.FileChecksum;
import com.ge.apm.adapter.domain.persistence.entity.Task;
import com.ge.apm.adapter.domain.persistence.repository.IFileChecksumRepository;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.asset.commons.mq.constants.MessageConstants;

import static org.mockito.Mockito.doReturn;

public class FileChecksumPredicateTest {

    @Spy
    @InjectMocks
    private FileChecksumPredicate fileChecksumPredicate;

    @Mock
    private ITaskProcessorRepository taskRepository;

    @Mock
    private IFileChecksumRepository fileChecksumRepository;

    @Mock
    private Exchange exchange;

    @Mock
    private Message message;

    @Captor
    private ArgumentCaptor<FileChecksum> fileChecksumArgumentCaptor;

    @Before
    public void setup() {

        MockitoAnnotations.initMocks(this);
        message = new DefaultMessage();
        message.setHeader(MessageConstants.TENANT_UUID, "6cc39e77-612a-3ac7-ad48-194a82e882ee");
        message.setHeader(MessageConstants.TASK_UUID, "6cc39e77-612a-3ac7-ad48-194a82e882ee");
        message.setHeader(Exchange.FILE_NAME, "create.json");
        message.setHeader(MessageConstants.DESCRIPTION, "");
        message.setBody(this.getClass().getResourceAsStream("/assetIn/assetgroupassociations/create.json"));
    }

    @Test
    public void test_matches_existingChecksum() {

        doReturn(message).when(exchange).getIn();

        FileChecksum fileChecksum = new FileChecksum();
        fileChecksum.setChecksum("91bcbb55");
        doReturn(fileChecksum).when(fileChecksumRepository).findByTenantUuidAndChecksum(
            Matchers.eq("6cc39e77-612a-3ac7-ad48-194a82e882ee"), Matchers.eq("91bcbb55"));
        Task task = new Task();
        task.setUuid("6cc39e77-612a-3ac7-ad48-194a82e882ee");
        fileChecksum.setTask(task);
        doReturn(task).when(taskRepository).findOne(Matchers.eq(fileChecksum.getTask().getId()));
        boolean status = fileChecksumPredicate.matches(exchange);
        Assert.assertTrue(status);
        Assert.assertTrue(exchange.getIn().getHeader(MessageConstants.DESCRIPTION, String.class)
            .contains("6cc39e77-612a-3ac7-ad48-194a82e882ee"));
    }

    @Test
    public void test_matches_non_existingChecksum() {

        doReturn(message).when(exchange).getIn();

        FileChecksum fileChecksum1 = new FileChecksum();

        doReturn(null).when(fileChecksumRepository).findByTenantUuidAndChecksum(
            Matchers.eq("6cc39e77-612a-3ac7-ad48-194a82e882ee"), Matchers.eq("91bcbb55"));
        Task task = new Task();
        task.setUuid("6cc39e77-612a-3ac7-ad48-194a82e882ee");
        doReturn(task).when(taskRepository).findByTenantUuidAndUuid(Matchers.eq("6cc39e77-612a-3ac7-ad48-194a82e882ee"),
            Matchers.eq("6cc39e77-612a-3ac7-ad48-194a82e882ee"));

        doReturn(fileChecksum1).when(fileChecksumRepository).saveAndFlush(fileChecksumArgumentCaptor.capture());
        boolean status = fileChecksumPredicate.matches(exchange);
        FileChecksum fileChecksumCaptorValue = fileChecksumArgumentCaptor.getValue();
        Assert.assertNotNull(fileChecksumCaptorValue);
        Assert.assertEquals("6cc39e77-612a-3ac7-ad48-194a82e882ee", fileChecksumCaptorValue.getTenantUuid());
        Assert.assertEquals("91bcbb55", fileChecksumCaptorValue.getChecksum());
        Assert.assertEquals("create.json", fileChecksumCaptorValue.getName());
        Assert.assertFalse(status);
    }
}
