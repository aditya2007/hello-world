/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.instance;

import java.io.IOException;

import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.ccom.model.registry.Segment;
import com.ge.apm.ccom.model.registry.SegmentType;
import com.ge.apm.s95.model.Instance;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Description of AssetInstanceProcessorTest
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Nov 17, 2016
 * @since 1.0
 */
@RunWith(PowerMockRunner.class)
@Slf4j
public class SegmentInstanceProcessorTest {

    @Mock
    Segment segment;

    @Mock
    SegmentType segmentType;

    @Mock
    Instance instance;

    @InjectMocks
    @Autowired
    SegmentInstanceProcessor segmentInstanceProcessor;

    @Test
    public void testAssignEntityType() {
        segment = new Segment();
        segmentType = new SegmentType();
        segmentInstanceProcessor.assignEntityType(segment, segmentType);
        Assert.assertEquals("SegmentType not set:", segment.getType(), segmentType);
    }

    @Test
    public void testProcessOthers() throws IOException, ValidationFailedException {
        segmentInstanceProcessor.processOthers(segment, instance);
    }
}
