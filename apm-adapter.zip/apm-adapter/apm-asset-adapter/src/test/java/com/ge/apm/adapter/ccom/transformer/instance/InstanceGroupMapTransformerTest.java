/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.io.IOException;
import java.util.List;
import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.ccom.base.BaseTransformerTest;
import com.ge.apm.adapter.ccom.transformer.EntityTransformer;
import com.ge.apm.asset.model.InstanceGroupMap;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Unit test for {@link com.ge.apm.adapter.ccom.transformer.instance.InstanceGroupMapTransformerTest}.
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BaseTransformerTest.Configuration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class InstanceGroupMapTransformerTest extends BaseTypedTransformerTest<InstanceGroupMap> {

    @Override
    protected String getPrefix() {
        return Prefixes.AssetGroupAssociations;
    }

    @Override
    protected Class<InstanceGroupMap> getObjectClass() {
        return InstanceGroupMap.class;
    }

    @Override
    protected String getTypePrefix() {
        return Prefixes.GroupTypes;
    }

    @Override
    protected void setupLookupForCreate() {
        setupGetGroup(Uuid2, Prefixes.Groups, "TAG");
    }

    @Override
    protected void setupLookupForUpdate() {
        throw new UnsupportedOperationException("Update asset group association not allowed");
    }

    @Override
    protected void setupLookupForUpdateOne() {
        throw new UnsupportedOperationException("Update asset group association not allowed");
    }

    /**
     * Test verifies that no exception is thrown when trying to create association for group with an inconsistent
     * associatedEntityCcomClass. A warning should be logged and all associations for that group should be skipped.
     */
    @Test
    public void createInstanceMappingForGroupWithInvalidType() throws JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/create.xml");
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Ignore("todo")
    @Test
    @Override
    public void createThrowExceptionOnIdMissing() throws IOException {
        //Added a empty line for PMD check.
    }

    @Test
    public void getMappedEntityPrefix() {
        InstanceGroupMapTransformer transformer = new InstanceGroupMapTransformer(null);
        Assert.assertEquals(Prefixes.Assets, transformer.getEntityPrefix(MimosaCcomCategory.ASSET));
        Assert.assertEquals(Prefixes.Segments, transformer.getEntityPrefix(MimosaCcomCategory.SEGMENT));
        Assert.assertEquals(Prefixes.Sites, transformer.getEntityPrefix(MimosaCcomCategory.SITE));
        Assert.assertEquals(Prefixes.Enterprises, transformer.getEntityPrefix(MimosaCcomCategory.ENTERPRISE));
    }

    /**
     * Test verifies ingestion doesn't throw an error even when a preexisting association is tried to be recreated.
     */
    @Test
    public void createPreexistingAssociation() throws JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/create.xml");
        Assert.assertEquals(EntityTransformer.ENTITIES_TRANSFORMED, entityTransformer
            .transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false));
    }
}
