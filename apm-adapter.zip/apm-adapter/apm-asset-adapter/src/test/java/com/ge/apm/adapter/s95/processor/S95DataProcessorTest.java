/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import com.ge.apm.adapter.common.util.IEntityDispatcher;
import com.ge.apm.adapter.s95.processor.root.ClassificationProcessor;
import com.ge.apm.adapter.s95.util.ReflectionUtils;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * @author 212312392
 */
public class S95DataProcessorTest {

    @Test
    public void testAfterPropertiesSet() throws IllegalAccessException, NoSuchFieldException {
        S95DataProcessor s95DataProcessor = new S95DataProcessor();
        List<IRootLevelProcessor<JsonParser>> rootLevelProcessors = new ArrayList<IRootLevelProcessor<JsonParser>>();
        @SuppressWarnings("unchecked") IRootLevelProcessor<JsonParser> iRootLevelProcessor = Mockito.mock(
            IRootLevelProcessor.class);
        rootLevelProcessors.add(iRootLevelProcessor);
        ReflectionUtils.setField(S95DataProcessor.class, s95DataProcessor, "rootLevelProcessors", rootLevelProcessors);
        s95DataProcessor.afterPropertiesSet();
        Assert.assertNotNull(ReflectionUtils.getField(S95DataProcessor.class, s95DataProcessor, "fieldToProcessorMap"));
    }

    @Test
    public void testAfterPropertiesSetAndNullProcessor() throws IllegalAccessException {
        S95DataProcessor s95DataProcessor = new S95DataProcessor();
        List<IRootLevelProcessor<JsonParser>> rootLevelProcessors = null;
        ReflectionUtils.setField(S95DataProcessor.class, s95DataProcessor, "rootLevelProcessors", rootLevelProcessors);
        s95DataProcessor.afterPropertiesSet();
        Assert.assertNull(rootLevelProcessors);
    }

    @Test
    public void testProcess() throws IOException, IllegalAccessException, NoSuchFieldException {
        S95DataProcessor s95DataProcessor = new S95DataProcessor();
        JsonParser parser = Mockito.mock(JsonParser.class);
        Mockito.when(parser.nextFieldName()).thenReturn("testField").thenReturn(null);
        Mockito.when(parser.hasCurrentToken()).thenReturn(true);
        Mockito.when(parser.hasTokenId(JsonToken.START_OBJECT.id())).thenReturn(true);
        Mockito.when(parser.hasTokenId(JsonToken.START_ARRAY.id())).thenReturn(true);
        Mockito.when(parser.hasTokenId(JsonToken.END_ARRAY.id())).thenReturn(true);
        Mockito.when(parser.isExpectedStartObjectToken()).thenReturn(true).thenReturn(false);
        Mockito.when(parser.hasTokenId(JsonToken.END_OBJECT.id())).thenReturn(true);
        Map<String, IRootLevelProcessor<JsonParser>> fieldToProcessorMap = new HashMap<>();
        ClassificationProcessor cp = Mockito.mock(ClassificationProcessor.class);
        fieldToProcessorMap.put("testField", cp);
        ReflectionUtils.setField(S95DataProcessor.class, s95DataProcessor, "fieldToProcessorMap", fieldToProcessorMap);
        IEntityDispatcher iEntityDispatcher = Mockito.mock(IEntityDispatcher.class);
        ReflectionUtils.setField(S95DataProcessor.class, s95DataProcessor, "entityDispatcher", iEntityDispatcher);
        s95DataProcessor.process(parser);
        Assert.assertNotNull(ReflectionUtils.getField(S95DataProcessor.class, s95DataProcessor, "fieldToProcessorMap"));
    }

    @Test(expected = JsonParseException.class)
    public void testProcessException()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        S95DataProcessor s95DataProcessor = new S95DataProcessor();
        JsonParser parser = Mockito.mock(JsonParser.class);
        Mockito.when(parser.hasCurrentToken()).thenReturn(true);
        s95DataProcessor.process(parser, "Test Uuid");
    }

    @Test(expected = JsonParseException.class)
    public void testProcessLogError()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        S95DataProcessor s95DataProcessor = new S95DataProcessor();
        JsonParser parser = Mockito.mock(JsonParser.class);
        Mockito.when(parser.nextFieldName()).thenReturn("newField").thenReturn(null);
        Mockito.when(parser.hasCurrentToken()).thenReturn(true);
        Mockito.when(parser.hasTokenId(JsonToken.START_OBJECT.id())).thenReturn(true);
        Mockito.when(parser.hasCurrentToken()).thenReturn(true);
        Map<String, IRootLevelProcessor<JsonParser>> fieldToProcessorMap = new HashMap<>();
        ClassificationProcessor cp = Mockito.mock(ClassificationProcessor.class);
        fieldToProcessorMap.put("testField", cp);
        ReflectionUtils.setField(S95DataProcessor.class, s95DataProcessor, "fieldToProcessorMap", fieldToProcessorMap);
        s95DataProcessor.process(parser, "Test Uuid");
    }
}
