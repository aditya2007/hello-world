/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.io.IOException;
import java.util.List;
import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.web.client.HttpClientErrorException;

import com.ge.apm.adapter.ccom.base.BaseTransformerTest;
import com.ge.apm.asset.model.Typed;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.validator.ValidationFailedException;

@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public abstract class BaseTypedTransformerTest<T extends Typed> extends BaseTransformerTest<T> {

    @Test
    public void create() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/create.xml");
        T[] expectedObjects = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/create.json");
        T[] returnObjects = readObjectsFromResourceFile("/assetOut" + getPrefix() + "/create.json");

        setupLookupForCreate();
        setupPOSTFor(getPrefix(), expectedObjects, returnObjects);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
        verifyPOSTCalls(getPrefix());
    }

    @Test(expected = ValidationFailedException.class)
    public void createThrowExceptionOnIdMissing() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/createIdMissing.xml");
        T[] returnObjects = readObjectsFromResourceFile("/assetOut" + getPrefix() + "/createIdMissing.json");
        T[] expectedObjects = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/createIdMissing.json");

        setupLookupForCreate();
        setupPOSTFor(getPrefix(), expectedObjects, returnObjects);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test(expected = ServiceException.class)
    public void createThrowException() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/create.xml");
        throwExceptionForPOST(new HttpClientErrorException(HttpStatus.UNPROCESSABLE_ENTITY));
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    protected void testWithNoSourceKeyLookup(String testName)
        throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/" + testName + ".xml");
        T[] expectedObjects = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/" + testName + ".json");
        T[] returnObjects = readObjectsFromResourceFile("/assetOut" + getPrefix() + "/" + testName + ".json");

        setupLookupForCreate();
        setupPOSTFor(getPrefix(), expectedObjects, returnObjects);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    protected abstract String getTypePrefix();

    protected abstract void setupLookupForCreate();

    protected abstract void setupLookupForUpdate();

    protected abstract void setupLookupForUpdateOne();
}
