/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.base;//package com.ge.apm.adapter.s95.base;
//
//import com.rabbitmq.client.AlreadyClosedException;
//import org.apache.camel.*;
//import org.apache.camel.builder.RouteBuilder;
//import org.apache.camel.component.mock.MockEndpoint;
//import org.apache.camel.component.rabbitmq.RabbitMQConstants;
//import org.apache.camel.test.junit4.CamelTestSupport;
//import org.junit.Test;
//
//import java.net.ConnectException;
//import java.util.concurrent.TimeUnit;
//
///**
// * Created by Suban Asif (212448111) on 7/29/16.
// */
//public class RabbitMQConnectionRetryTest extends CamelTestSupport {
//    private static final String EXCHANGE = "ex";
//
//    @Produce(uri = "direct:rabbitMQ")
//    protected ProducerTemplate directProducer;
//
//    @EndpointInject(uri = "rabbitmq:localhost:5672/ge.apm.topic" + EXCHANGE + "?vhost=/&username=guest&password=guest"
//            + "&queue=q3&exchangeType=topic&routingKey=rk3" + "&automaticRecoveryEnabled=true"
//            + "")
//
//    private Endpoint rabbitMQEndpoint;
//
//    @EndpointInject(uri = "mock:producing")
//    private MockEndpoint producingMockEndpoint;
//
//    @EndpointInject(uri = "mock:consuming")
//    private MockEndpoint consumingMockEndpoint;
//
//
//    @Override
//    protected RouteBuilder createRouteBuilder() throws Exception {
//        return new RouteBuilder() {
//
//            @Override
//            public void configure() throws Exception {
//                from("direct:rabbitMQ")
//                        .id("producingRoute")
//                        .onException(AlreadyClosedException.class, ConnectException.class)
//                        .maximumRedeliveries(10)
//                        .redeliveryDelay(500L)
//                        .end()
//                        .log("Sending message")
//                        .inOnly(rabbitMQEndpoint)
//                        .to(producingMockEndpoint);
//                from(rabbitMQEndpoint)
//                        .id("consumingRoute")
//                        .log("Receiving message")
//                        .to(consumingMockEndpoint);
//            }
//        };
//    }
//
//    @Test
//    public void testSendEndReceive() throws Exception {
//        int nbMessages = 50;
//        int failedMessages = 0;
//        for (int i = 0; i < nbMessages; i++) {
//            try {
//                directProducer.sendBodyAndHeader("Message #" + i, RabbitMQConstants.ROUTING_KEY, "rk3");
//            } catch (CamelExecutionException e) {
//                log.debug("Can not send message", e);
//                failedMessages++;
//            }
//            Thread.sleep(500L);
//        }
//        producingMockEndpoint.expectedMessageCount(nbMessages - failedMessages);
//        consumingMockEndpoint.expectedMessageCount(nbMessages - failedMessages);
//        assertMockEndpointsSatisfied(5, TimeUnit.SECONDS);
//    }
//}
