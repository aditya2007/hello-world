/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import com.ge.apm.adapter.common.constants.TaskStatus;
import com.ge.apm.adapter.domain.persistence.entity.Task;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.apm.adapter.model.Ingestion;
import com.ge.apm.adapter.model.IngestionPage;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.stuf.tenant.context.TenantContext;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Unit test for {@link TaskController}.
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Mar 2, 2016
 * @since 1.0
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(TenantContext.class)
public class TaskControllerTest {

    private static final String baseDir = "/s95/taskControllerTests";

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static final ObjectReader TASKS_READER = MAPPER.reader(Task[].class);

    private static final ObjectWriter WRITER = MAPPER.writer();

    private static final String TENANT_UUID = "Test Uuid";

    @InjectMocks
    @Spy
    private final TaskController controller = new TaskController();

    @Mock
    private ITaskProcessorRepository taskProcessorRepository;

    @Mock
    private TenantContext tenantContext;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        PowerMockito.mockStatic(TenantContext.class);
        when(TenantContext.getInstance()).thenReturn(tenantContext);
        when(tenantContext.getTenantUuid()).thenReturn(TENANT_UUID);
        controller.init();
    }

    @Test
    public void getTasks() throws IOException {
        setupQueryMockForGetTasks();
        List<com.ge.apm.adapter.model.Task> actual = controller.getTasks();
        List<com.ge.apm.adapter.model.Task> expected = readListFromFile(baseDir + "/getTasks/response.json",
            com.ge.apm.adapter.model.Task.class);
        Assert.assertEquals(expected.size(), actual.size());
    }

    private void setupQueryMockForGetTasks() throws IOException {
        List<Task> tasks = readListFromFile(baseDir + "/getTasks/findRootTasks.json", Task.class);
        tasks.forEach(task -> {
            task.setCompletedCount(0L);
            task.setTotalCount(0L);
        });
        when(taskProcessorRepository.findRootTasks(TENANT_UUID)).thenReturn(tasks);
        setupForChildren("/getTasks", tasks);
    }

    private void setupForChildren(String dataDir, List<Task> tasks) throws IOException {
        for (Task task : tasks) {
            List<Task> children = readListFromFile(baseDir + dataDir + "/findChildren-" + task.getUuid() + ".json",
                Task.class);
            children.forEach(child -> {
                child.setCompletedCount(0L);
                child.setTotalCount(0L);
            });
            when(taskProcessorRepository.findChildren(null, task.getUuid())).thenReturn(children);
            setupForChildren(dataDir, children);
        }
    }

    @Test
    public void getTaskById() throws IOException {
        String taskId = setupQueryMockForGetTaskById();
        com.ge.apm.adapter.model.Task actual = controller.getTaskById(taskId, false, false);
        com.ge.apm.adapter.model.Task expected = readOneFromFile(baseDir + "/getTaskById/response.json",
            com.ge.apm.adapter.model.Task.class);
        Assert.assertEquals(expected.getUuid(), actual.getUuid());
    }

    @Test
    public void getTaskById_includeAll_true() throws IOException {
        List<Task> rootTasks = new ArrayList<>();
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid(TENANT_UUID);
        rootTask1.setId(100L);
        rootTask1.setCompletedCount(null);
        rootTask1.setTotalCount(null);
        rootTask1.setTotalCount(0L);
        rootTask1.setCompletedCount(0L);
        rootTask1.setStatus(TaskStatus.COMPLETED);
        rootTask1.setUuid(UUID.randomUUID().toString());
        rootTask1.setCreatedOn(new Date());
        rootTask1.setUpdatedOn(new Date());
        rootTasks.add(rootTask1);
        List<Task> jsonTasks = new ArrayList<>();
        Task jsonTask1 = new Task();
        jsonTask1.setId(110L);
        jsonTask1.setUuid(UUID.randomUUID().toString());
        jsonTask1.setParent(rootTask1);
        jsonTask1.setTenantUuid(TENANT_UUID);
        jsonTask1.setStatus(TaskStatus.ARCHIVED);
        jsonTask1.setCreatedOn(new Date());
        jsonTask1.setUpdatedOn(new Date());
        Task jsonTask2 = new Task();
        jsonTask2.setId(120L);
        jsonTask2.setUuid(UUID.randomUUID().toString());
        jsonTask2.setParent(rootTask1);
        jsonTask2.setTenantUuid(TENANT_UUID);
        jsonTask2.setStatus(TaskStatus.ARCHIVED);
        jsonTask2.setCreatedOn(new Date());
        jsonTask2.setUpdatedOn(new Date());
        jsonTasks.add(jsonTask1);
        jsonTasks.add(jsonTask2);
        List<Task> childrenTasks = new ArrayList<>();
        List<Task> jsonTask1ChildrenTasks = new ArrayList<>();
        List<Task> jsonTask2ChildrenTasks = new ArrayList<>();
        Task childrenTask1 = new Task();
        childrenTask1.setId(111L);
        childrenTask1.setParent(jsonTask1);
        childrenTask1.setCompletedCount(1000L);
        childrenTask1.setTotalCount(2000L);
        childrenTask1.setStatus(TaskStatus.ARCHIVED);
        Task childrenTask2 = new Task();
        childrenTask2.setId(112L);
        childrenTask2.setParent(jsonTask1);
        childrenTask2.setCompletedCount(3000L);
        childrenTask2.setTotalCount(4000L);
        childrenTask2.setStatus(TaskStatus.ARCHIVED);
        jsonTask1ChildrenTasks.add(childrenTask1);
        jsonTask1ChildrenTasks.add(childrenTask2);
        Task childrenTask3 = new Task();
        childrenTask3.setId(121L);
        childrenTask3.setParent(jsonTask2);
        childrenTask3.setCompletedCount(5000L);
        childrenTask3.setTotalCount(6000L);
        childrenTask3.setStatus(TaskStatus.ARCHIVED);
        Task childrenTask4 = new Task();
        childrenTask4.setId(122L);
        childrenTask4.setParent(jsonTask2);
        childrenTask4.setCompletedCount(7000L);
        childrenTask4.setTotalCount(8000L);
        childrenTask4.setStatus(TaskStatus.ARCHIVED);
        jsonTask2ChildrenTasks.add(childrenTask3);
        jsonTask2ChildrenTasks.add(childrenTask4);
        childrenTasks.add(childrenTask1);
        childrenTasks.add(childrenTask2);
        childrenTasks.add(childrenTask3);
        childrenTasks.add(childrenTask4);
        when(taskProcessorRepository.findByTenantUuidAndUuid(rootTask1.getTenantUuid(), rootTask1.getUuid()))
            .thenReturn(rootTask1);
        when(taskProcessorRepository.findChildrenIncludeArchived(rootTask1.getTenantUuid(), rootTask1.getUuid()))
            .thenReturn(jsonTasks);
        when(taskProcessorRepository.findChildrenIncludeArchived(jsonTask1.getTenantUuid(), jsonTask1.getUuid()))
            .thenReturn(jsonTask1ChildrenTasks);
        when(taskProcessorRepository.findChildrenIncludeArchived(jsonTask2.getTenantUuid(), jsonTask2.getUuid()))
            .thenReturn(jsonTask2ChildrenTasks);
        Assert.assertEquals(controller.getTaskById(rootTask1.getUuid(), true, false).getChildren().size(), 2);
    }

    @Test
    public void getTaskById_includeAll_false() throws IOException {
        List<Task> rootTasks = new ArrayList<>();
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid(TENANT_UUID);
        rootTask1.setId(100L);
        rootTask1.setCompletedCount(null);
        rootTask1.setTotalCount(null);
        rootTask1.setTotalCount(0L);
        rootTask1.setCompletedCount(0L);
        rootTask1.setStatus(TaskStatus.COMPLETED);
        rootTask1.setUuid(UUID.randomUUID().toString());
        rootTask1.setCreatedOn(new Date());
        rootTask1.setUpdatedOn(new Date());
        rootTasks.add(rootTask1);
        List<Task> jsonTasks = new ArrayList<>();
        Task jsonTask1 = new Task();
        jsonTask1.setId(110L);
        jsonTask1.setUuid(UUID.randomUUID().toString());
        jsonTask1.setParent(rootTask1);
        jsonTask1.setTenantUuid(TENANT_UUID);
        jsonTask1.setStatus(TaskStatus.ARCHIVED);
        jsonTask1.setCreatedOn(new Date());
        jsonTask1.setUpdatedOn(new Date());
        Task jsonTask2 = new Task();
        jsonTask2.setId(120L);
        jsonTask2.setUuid(UUID.randomUUID().toString());
        jsonTask2.setParent(rootTask1);
        jsonTask2.setTenantUuid(TENANT_UUID);
        jsonTask2.setStatus(TaskStatus.ARCHIVED);
        jsonTask2.setCreatedOn(new Date());
        jsonTask2.setUpdatedOn(new Date());
        jsonTasks.add(jsonTask1);
        jsonTasks.add(jsonTask2);
        List<Task> childrenTasks = new ArrayList<>();
        List<Task> jsonTask1ChildrenTasks = new ArrayList<>();
        List<Task> jsonTask2ChildrenTasks = new ArrayList<>();
        Task childrenTask1 = new Task();
        childrenTask1.setId(111L);
        childrenTask1.setParent(jsonTask1);
        childrenTask1.setCompletedCount(1000L);
        childrenTask1.setTotalCount(2000L);
        childrenTask1.setStatus(TaskStatus.ARCHIVED);
        Task childrenTask2 = new Task();
        childrenTask2.setId(112L);
        childrenTask2.setParent(jsonTask1);
        childrenTask2.setCompletedCount(3000L);
        childrenTask2.setTotalCount(4000L);
        childrenTask2.setStatus(TaskStatus.ARCHIVED);
        jsonTask1ChildrenTasks.add(childrenTask1);
        jsonTask1ChildrenTasks.add(childrenTask2);
        Task childrenTask3 = new Task();
        childrenTask3.setId(121L);
        childrenTask3.setParent(jsonTask2);
        childrenTask3.setCompletedCount(5000L);
        childrenTask3.setTotalCount(6000L);
        childrenTask3.setStatus(TaskStatus.ARCHIVED);
        Task childrenTask4 = new Task();
        childrenTask4.setId(122L);
        childrenTask4.setParent(jsonTask2);
        childrenTask4.setCompletedCount(7000L);
        childrenTask4.setTotalCount(8000L);
        childrenTask4.setStatus(TaskStatus.ARCHIVED);
        jsonTask2ChildrenTasks.add(childrenTask3);
        jsonTask2ChildrenTasks.add(childrenTask4);
        childrenTasks.add(childrenTask1);
        childrenTasks.add(childrenTask2);
        childrenTasks.add(childrenTask3);
        childrenTasks.add(childrenTask4);
        when(taskProcessorRepository.findByTenantUuidAndUuid(rootTask1.getTenantUuid(), rootTask1.getUuid()))
            .thenReturn(rootTask1);
        when(taskProcessorRepository.findChildrenIncludeArchived(rootTask1.getTenantUuid(), rootTask1.getUuid()))
            .thenReturn(jsonTasks);
        when(taskProcessorRepository.findChildrenIncludeArchived(jsonTask1.getTenantUuid(), jsonTask1.getUuid()))
            .thenReturn(jsonTask1ChildrenTasks);
        when(taskProcessorRepository.findChildrenIncludeArchived(jsonTask2.getTenantUuid(), jsonTask2.getUuid()))
            .thenReturn(jsonTask2ChildrenTasks);
        controller.getTaskById(rootTask1.getUuid(), false, false);
        Assert.assertEquals(controller.getTaskById(rootTask1.getUuid(), false, false).getChildren().size(), 0);
    }

    @Test(expected = NotFoundException.class)
    public void getTaskById_notFound() throws IOException {
        Task task = readOneFromFile(baseDir + "/getTaskById/findByTenantUuidAndUuid.json", Task.class);
        when(taskProcessorRepository.findByTenantUuidAndUuid(null, task.getUuid())).thenReturn(null);
        controller.getTaskById(task.getUuid(), false, false);
    }

    private String setupQueryMockForGetTaskById() throws IOException {
        Task task = readOneFromFile(baseDir + "/getTaskById/findByTenantUuidAndUuid.json", Task.class);
        when(taskProcessorRepository.findByTenantUuidAndUuid(TENANT_UUID, task.getUuid())).thenReturn(task);
        List<Task> tasks = new ArrayList<>();
        tasks.add(task);
        setupForChildren("/getTaskById", tasks);
        return task.getUuid();
    }

    @Test
    public void getIngestionLogById() throws IOException {
        String taskId = setupQueryMockForGetIngestionLogById();
        Ingestion actual = controller.getIngestionLogById(taskId, false);
        Ingestion expected = readOneFromFile(baseDir + "/getIngestionLogById/response.json", Ingestion.class);
        Assert.assertEquals(expected.getUuid(), actual.getUuid());
    }

    @Test
    public void getIngestionLogById_includeAll_true() throws IOException {
        List<Task> rootTasks = new ArrayList<>();
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid(TENANT_UUID);
        rootTask1.setId(100L);
        rootTask1.setCompletedCount(null);
        rootTask1.setTotalCount(null);
        rootTask1.setTotalCount(0L);
        rootTask1.setCompletedCount(0L);
        rootTask1.setStatus(TaskStatus.COMPLETED);
        rootTask1.setUuid(UUID.randomUUID().toString());
        rootTasks.add(rootTask1);
        List<Task> jsonTasks = new ArrayList<>();
        Task jsonTask1 = new Task();
        jsonTask1.setId(110L);
        jsonTask1.setUuid(UUID.randomUUID().toString());
        jsonTask1.setParent(rootTask1);
        jsonTask1.setTenantUuid(TENANT_UUID);
        jsonTask1.setStatus(TaskStatus.ARCHIVED);
        Task jsonTask2 = new Task();
        jsonTask2.setId(120L);
        jsonTask2.setUuid(UUID.randomUUID().toString());
        jsonTask2.setParent(rootTask1);
        jsonTask2.setTenantUuid(TENANT_UUID);
        jsonTask2.setStatus(TaskStatus.ARCHIVED);
        jsonTasks.add(jsonTask1);
        jsonTasks.add(jsonTask2);
        List<Task> childrenTasks = new ArrayList<>();
        List<Task> jsonTask1ChildrenTasks = new ArrayList<>();
        List<Task> jsonTask2ChildrenTasks = new ArrayList<>();
        Task childrenTask1 = new Task();
        childrenTask1.setId(111L);
        childrenTask1.setParent(jsonTask1);
        childrenTask1.setCompletedCount(1000L);
        childrenTask1.setTotalCount(2000L);
        childrenTask1.setStatus(TaskStatus.ARCHIVED);
        Task childrenTask2 = new Task();
        childrenTask2.setId(112L);
        childrenTask2.setParent(jsonTask1);
        childrenTask2.setCompletedCount(3000L);
        childrenTask2.setTotalCount(4000L);
        childrenTask2.setStatus(TaskStatus.ARCHIVED);
        jsonTask1ChildrenTasks.add(childrenTask1);
        jsonTask1ChildrenTasks.add(childrenTask2);
        Task childrenTask3 = new Task();
        childrenTask3.setId(121L);
        childrenTask3.setParent(jsonTask2);
        childrenTask3.setCompletedCount(5000L);
        childrenTask3.setTotalCount(6000L);
        childrenTask3.setStatus(TaskStatus.ARCHIVED);
        Task childrenTask4 = new Task();
        childrenTask4.setId(122L);
        childrenTask4.setParent(jsonTask2);
        childrenTask4.setCompletedCount(7000L);
        childrenTask4.setTotalCount(8000L);
        childrenTask4.setStatus(TaskStatus.ARCHIVED);
        jsonTask2ChildrenTasks.add(childrenTask3);
        jsonTask2ChildrenTasks.add(childrenTask4);
        childrenTasks.add(childrenTask1);
        childrenTasks.add(childrenTask2);
        childrenTasks.add(childrenTask3);
        childrenTasks.add(childrenTask4);
        when(taskProcessorRepository.findByTenantUuidAndUuid(rootTask1.getTenantUuid(), rootTask1.getUuid()))
            .thenReturn(rootTask1);
        when(taskProcessorRepository.findChildrenIncludeArchived(rootTask1.getTenantUuid(), rootTask1.getUuid()))
            .thenReturn(jsonTasks);
        when(taskProcessorRepository.findChildrenIncludeArchived(jsonTask1.getTenantUuid(), jsonTask1.getUuid()))
            .thenReturn(jsonTask1ChildrenTasks);
        when(taskProcessorRepository.findChildrenIncludeArchived(jsonTask2.getTenantUuid(), jsonTask2.getUuid()))
            .thenReturn(jsonTask2ChildrenTasks);
        Ingestion ingestion = controller.getIngestionLogById(rootTask1.getUuid(), true);
        Assert.assertEquals(ingestion.getChildren().size(), 2);
    }

    @Test
    public void getIngestionLogById_includeAll_false() throws IOException {
        List<Task> rootTasks = new ArrayList<>();
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid(TENANT_UUID);
        rootTask1.setId(100L);
        rootTask1.setCompletedCount(null);
        rootTask1.setTotalCount(null);
        rootTask1.setTotalCount(0L);
        rootTask1.setCompletedCount(0L);
        rootTask1.setStatus(TaskStatus.COMPLETED);
        rootTask1.setUuid(UUID.randomUUID().toString());
        rootTasks.add(rootTask1);
        List<Task> jsonTasks = new ArrayList<>();
        Task jsonTask1 = new Task();
        jsonTask1.setId(110L);
        jsonTask1.setUuid(UUID.randomUUID().toString());
        jsonTask1.setParent(rootTask1);
        jsonTask1.setTenantUuid(TENANT_UUID);
        jsonTask1.setStatus(TaskStatus.ARCHIVED);
        Task jsonTask2 = new Task();
        jsonTask2.setId(120L);
        jsonTask2.setUuid(UUID.randomUUID().toString());
        jsonTask2.setParent(rootTask1);
        jsonTask2.setTenantUuid(TENANT_UUID);
        jsonTask2.setStatus(TaskStatus.ARCHIVED);
        jsonTasks.add(jsonTask1);
        jsonTasks.add(jsonTask2);
        List<Task> childrenTasks = new ArrayList<>();
        List<Task> jsonTask1ChildrenTasks = new ArrayList<>();
        List<Task> jsonTask2ChildrenTasks = new ArrayList<>();
        Task childrenTask1 = new Task();
        childrenTask1.setId(111L);
        childrenTask1.setParent(jsonTask1);
        childrenTask1.setCompletedCount(1000L);
        childrenTask1.setTotalCount(2000L);
        childrenTask1.setStatus(TaskStatus.ARCHIVED);
        Task childrenTask2 = new Task();
        childrenTask2.setId(112L);
        childrenTask2.setParent(jsonTask1);
        childrenTask2.setCompletedCount(3000L);
        childrenTask2.setTotalCount(4000L);
        childrenTask2.setStatus(TaskStatus.ARCHIVED);
        jsonTask1ChildrenTasks.add(childrenTask1);
        jsonTask1ChildrenTasks.add(childrenTask2);
        Task childrenTask3 = new Task();
        childrenTask3.setId(121L);
        childrenTask3.setParent(jsonTask2);
        childrenTask3.setCompletedCount(5000L);
        childrenTask3.setTotalCount(6000L);
        childrenTask3.setStatus(TaskStatus.ARCHIVED);
        Task childrenTask4 = new Task();
        childrenTask4.setId(122L);
        childrenTask4.setParent(jsonTask2);
        childrenTask4.setCompletedCount(7000L);
        childrenTask4.setTotalCount(8000L);
        childrenTask4.setStatus(TaskStatus.ARCHIVED);
        jsonTask2ChildrenTasks.add(childrenTask3);
        jsonTask2ChildrenTasks.add(childrenTask4);
        childrenTasks.add(childrenTask1);
        childrenTasks.add(childrenTask2);
        childrenTasks.add(childrenTask3);
        childrenTasks.add(childrenTask4);
        when(taskProcessorRepository.findByTenantUuidAndUuid(rootTask1.getTenantUuid(), rootTask1.getUuid()))
            .thenReturn(rootTask1);
        when(taskProcessorRepository.findChildrenIncludeArchived(rootTask1.getTenantUuid(), rootTask1.getUuid()))
            .thenReturn(jsonTasks);
        when(taskProcessorRepository.findChildrenIncludeArchived(jsonTask1.getTenantUuid(), jsonTask1.getUuid()))
            .thenReturn(jsonTask1ChildrenTasks);
        when(taskProcessorRepository.findChildrenIncludeArchived(jsonTask2.getTenantUuid(), jsonTask2.getUuid()))
            .thenReturn(jsonTask2ChildrenTasks);
        Ingestion ingestion = controller.getIngestionLogById(rootTask1.getUuid(), false);
        Assert.assertEquals(ingestion.getChildren().size(), 0);
    }

    @Test(expected = NotFoundException.class)
    public void getIngestionLogById_notFound() throws IOException {
        Task task = readOneFromFile(baseDir + "/getIngestionLogById/findByTenantUuidAndUuid.json", Task.class);
        when(taskProcessorRepository.findByTenantUuidAndUuid(null, task.getUuid())).thenReturn(null);
        controller.getIngestionLogById(task.getUuid(), false);
    }

    private String setupQueryMockForGetIngestionLogById() throws IOException {
        Task task = readOneFromFile(baseDir + "/getIngestionLogById/findByTenantUuidAndUuid.json", Task.class);
        when(taskProcessorRepository.findByTenantUuidAndUuid(TENANT_UUID, task.getUuid())).thenReturn(task);
        List<Task> tasks = new ArrayList<>();
        tasks.add(task);
        setupForChildren("/getTaskById", tasks);
        return task.getUuid();
    }

    @Test
    public void getIngestionLogs() throws IOException, BadRequestException {
        setupQueryMockForGetIngestionLogs();
        IngestionPage actual = controller.getIngestionLogs(1, "DESC", "", "", "createdon", 2);
        IngestionPage expected = readOneFromFile(baseDir + "/getIngestionLogs/response.json", IngestionPage.class);
        Assert.assertEquals(expected.getTotalPages(), actual.getTotalPages());
        Assert.assertEquals(expected.getCurrentPage(), actual.getCurrentPage());
        Assert.assertEquals(expected.getTotalItems(), actual.getTotalItems());
        Assert.assertEquals(expected.getItemsOnPage(), actual.getItemsOnPage());
        Assert.assertEquals(expected.getDtoList().size(), actual.getDtoList().size());
    }

    @SuppressWarnings("unchecked")
    private void setupQueryMockForGetIngestionLogs() throws IOException {
        Map<String, Object> data = readOneFromFile(baseDir + "/getIngestionLogs/findRootTasks.json", Map.class);
        ;
        List<Task> tasks = Arrays.asList(
            (Task[]) TASKS_READER.readValue(WRITER.writeValueAsString(data.get("content"))));
        PageRequest pageable = new PageRequest(0, 2, new Sort(Direction.DESC, "createdOn"));
        Page<Task> page = new PageImpl<>(tasks, pageable,
            Long.valueOf(data.get("totalElements").toString()).longValue());

        when(taskProcessorRepository.findRootTasks(anyString(), (PageRequest) anyObject())).thenReturn(page);

        setupForChildren("/getIngestionLogs",
            StreamSupport.stream(page.spliterator(), false).collect(Collectors.toList()));
    }

    @Test
    public void getFileNameFromPath() throws IOException {
        Pattern fileName_Pattern = Pattern.compile("(?<=file: )(.*)(?=, size:)|(?<=file: )(.*\\.\\w*)",
            Pattern.CASE_INSENSITIVE);

        Pattern fileFromPath_Pattern = Pattern.compile("[^\\/ ]*\\..*", Pattern.CASE_INSENSITIVE);

        Matcher matcher = fileName_Pattern.matcher("file: /this/is/the/path/to/correctFileName.json.zip");
        if (matcher.find()) {
            try {
                String pathName = java.net.URLDecoder.decode(matcher.group(), "UTF-8");
                matcher = fileFromPath_Pattern.matcher(pathName);
                if (matcher.find()) {
                    Assert.assertEquals("correctFileName.json.zip",
                        java.net.URLDecoder.decode(matcher.group(), "UTF-8"));
                } else {
                    Assert.fail();
                }
            } catch (UnsupportedEncodingException e) {
                Assert.fail();
            }
        } else {
            Assert.fail();
        }
    }

    @Test
    public void getIngestionLogs_uuid() throws IOException, BadRequestException {
        // uuid = b9351b17-fc2a-471d-ba7e-39ec4dcfd1cf
        setupQueryMockForGetIngestionLogs_uuid();
        IngestionPage actual = controller.getIngestionLogs(1, "DESC", "uuid", "b9351b17-fc2a-471d-ba7e-39ec4dcfd1cf",
            "createdOn", 2);
        IngestionPage expected = readOneFromFile(baseDir + "/getIngestionLogs/response-search-uuid.json",
            IngestionPage.class);
        Assert.assertEquals(expected.getTotalPages(), actual.getTotalPages());
        Assert.assertEquals(expected.getCurrentPage(), actual.getCurrentPage());
        Assert.assertEquals(expected.getTotalItems(), actual.getTotalItems());
        Assert.assertEquals(expected.getItemsOnPage(), actual.getItemsOnPage());
        Assert.assertEquals(expected.getDtoList().size(), actual.getDtoList().size());
        Assert.assertEquals(expected.getDtoList().get(0).getUuid(), actual.getDtoList().get(0).getUuid());
    }

    @SuppressWarnings("unchecked")
    private void setupQueryMockForGetIngestionLogs_uuid() throws IOException {
        Map<String, Object> data = readOneFromFile(baseDir + "/getIngestionLogs/searchUuidWildcard.json", Map.class);
        List<Task> tasks = Arrays.asList(TASKS_READER.readValue(WRITER.writeValueAsString(data.get("content"))));
        PageRequest pageable = new PageRequest(0, 2, new Sort(Direction.DESC, "createdOn"));
        Page<Task> page = new PageImpl<>(tasks, pageable,
            Long.valueOf(data.get("totalElements").toString()).longValue());

        when(taskProcessorRepository.searchUuidWildcard(anyString(), anyString(), (PageRequest) anyObject()))
            .thenReturn(page);

        setupForChildren("/getIngestionLogs",
            StreamSupport.stream(page.spliterator(), false).collect(Collectors.toList()));
    }

    @Test
    public void getIngestionLogs_createdOn() throws IOException, BadRequestException {
        // createdOn = 1456515212497
        setupQueryMockForGetIngestionLogs_createdOn();
        IngestionPage actual = controller.getIngestionLogs(1, "DESC", "createdOn", "1456515212497-1456515212497",
            "createdOn", 2);
        IngestionPage expected = readOneFromFile(baseDir + "/getIngestionLogs/response-search-createdOn.json",
            IngestionPage.class);
        Assert.assertEquals(expected.getTotalPages(), actual.getTotalPages());
        Assert.assertEquals(expected.getCurrentPage(), actual.getCurrentPage());
        Assert.assertEquals(expected.getTotalItems(), actual.getTotalItems());
        Assert.assertEquals(expected.getItemsOnPage(), actual.getItemsOnPage());
        Assert.assertEquals(expected.getDtoList().size(), actual.getDtoList().size());
        Assert.assertEquals(expected.getDtoList().get(0).getCreatedOn(), actual.getDtoList().get(0).getCreatedOn());
    }

    @SuppressWarnings("unchecked")
    private void setupQueryMockForGetIngestionLogs_createdOn() throws IOException {
        Map<String, Object> data = readOneFromFile(baseDir + "/getIngestionLogs/searchCreatedOn.json", Map.class);
        List<Task> tasks = Arrays.asList(TASKS_READER.readValue(WRITER.writeValueAsString(data.get("content"))));
        PageRequest pageable = new PageRequest(0, 2, new Sort(Direction.DESC, "createdOn"));
        Page<Task> page = new PageImpl<>(tasks, pageable,
            Long.valueOf(data.get("totalElements").toString()).longValue());

        when(taskProcessorRepository
            .searchCreatedOn(anyString(), (Date) anyObject(), (Date) anyObject(), (PageRequest) anyObject()))
            .thenReturn(page);

        setupForChildren("/getIngestionLogs",
            StreamSupport.stream(page.spliterator(), false).collect(Collectors.toList()));
    }

    @Test
    public void getIngestionLogs_updatedOn() throws IOException, BadRequestException {
        // updatedOn: 1456515213020
        setupQueryMockForGetIngestionLogs_updatedOn();
        IngestionPage actual = controller.getIngestionLogs(1, "DESC", "updatedOn", "1456515213020-1456515213020",
            "createdOn", 2);
        IngestionPage expected = readOneFromFile(baseDir + "/getIngestionLogs/response-search-updatedOn.json",
            IngestionPage.class);
        Assert.assertEquals(expected.getTotalPages(), actual.getTotalPages());
        Assert.assertEquals(expected.getCurrentPage(), actual.getCurrentPage());
        Assert.assertEquals(expected.getTotalItems(), actual.getTotalItems());
        Assert.assertEquals(expected.getItemsOnPage(), actual.getItemsOnPage());
        Assert.assertEquals(expected.getDtoList().size(), actual.getDtoList().size());
        Assert.assertEquals(expected.getDtoList().get(0).getUpdatedOn().toString(), actual.getDtoList().get(0)
            .getUpdatedOn().toString());
    }

    @SuppressWarnings("unchecked")
    private void setupQueryMockForGetIngestionLogs_updatedOn() throws IOException {
        Map<String, Object> data = readOneFromFile(baseDir + "/getIngestionLogs/searchUpdatedOn.json", Map.class);
        List<Task> tasks = Arrays.asList(TASKS_READER.readValue(WRITER.writeValueAsString(data.get("content"))));
        PageRequest pageable = new PageRequest(0, 2, new Sort(Direction.DESC, "createdOn"));
        Page<Task> page = new PageImpl<>(tasks, pageable,
            Long.valueOf(data.get("totalElements").toString()).longValue());

        when(taskProcessorRepository
            .searchUpdatedOn(anyString(), (Date) anyObject(), (Date) anyObject(), (PageRequest) anyObject()))
            .thenReturn(page);

        setupForChildren("/getIngestionLogs",
            StreamSupport.stream(page.spliterator(), false).collect(Collectors.toList()));
    }

    @Test
    public void getIngestionLogs_status() throws IOException, BadRequestException {
        // status=ERRPR
        setupQueryMockForGetIngestionLogs_status();
        IngestionPage actual = controller.getIngestionLogs(1, "DESC", "status", "ERROR", "createdOn", 2);
        IngestionPage expected = readOneFromFile(baseDir + "/getIngestionLogs/response-search-status.json",
            IngestionPage.class);
        Assert.assertEquals(expected.getTotalPages(), actual.getTotalPages());
        Assert.assertEquals(expected.getCurrentPage(), actual.getCurrentPage());
        Assert.assertEquals(expected.getTotalItems(), actual.getTotalItems());
        Assert.assertEquals(expected.getItemsOnPage(), actual.getItemsOnPage());
        Assert.assertEquals(expected.getDtoList().size(), actual.getDtoList().size());
        Assert.assertEquals(expected.getDtoList().get(0).getStatus(), actual.getDtoList().get(0).getStatus());
    }

    @Test
    public void enrichTotalAndCompletedCountsForRootTasks_rootTasks() {
        List<Task> rootTasks = new ArrayList<>();
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid("abcd");
        rootTask1.setId(100L);
        rootTask1.setCompletedCount(0L);
        rootTask1.setTotalCount(0L);
        rootTask1.setStatus(TaskStatus.IN_PROGRESS);
        Task rootTask2 = new Task();
        rootTask2.setParent(null);
        rootTask2.setTenantUuid("abcd");
        rootTask2.setId(200L);
        rootTask2.setCompletedCount(0L);
        rootTask2.setTotalCount(0L);
        rootTask2.setStatus(TaskStatus.IN_PROGRESS);
        rootTasks.add(rootTask1);
        rootTasks.add(rootTask2);
        List<Task> jsonTasks = new ArrayList<>();
        Task jsonTask1 = new Task();
        jsonTask1.setId(110L);
        jsonTask1.setParent(rootTask1);
        Task jsonTask2 = new Task();
        jsonTask2.setId(120L);
        jsonTask2.setParent(rootTask1);
        Task jsonTask3 = new Task();
        jsonTask3.setId(210L);
        jsonTask3.setParent(rootTask2);
        Task jsonTask4 = new Task();
        jsonTask4.setId(220L);
        jsonTask4.setParent(rootTask2);
        jsonTasks.add(jsonTask1);
        jsonTasks.add(jsonTask2);
        jsonTasks.add(jsonTask3);
        jsonTasks.add(jsonTask4);
        List<Task> childrenTasks = new ArrayList<>();
        Task childrenTask1 = new Task();
        childrenTask1.setId(111L);
        childrenTask1.setParent(jsonTask1);
        childrenTask1.setCompletedCount(1000L);
        childrenTask1.setTotalCount(2000L);
        Task childrenTask2 = new Task();
        childrenTask2.setId(112L);
        childrenTask2.setParent(jsonTask1);
        childrenTask2.setCompletedCount(3000L);
        childrenTask2.setTotalCount(4000L);
        Task childrenTask3 = new Task();
        childrenTask3.setId(121L);
        childrenTask3.setParent(jsonTask2);
        childrenTask3.setCompletedCount(5000L);
        childrenTask3.setTotalCount(6000L);
        Task childrenTask4 = new Task();
        childrenTask4.setId(122L);
        childrenTask4.setParent(jsonTask2);
        childrenTask4.setCompletedCount(7000L);
        childrenTask4.setTotalCount(8000L);
        Task childrenTask5 = new Task();
        childrenTask5.setId(211L);
        childrenTask5.setParent(jsonTask3);
        childrenTask5.setCompletedCount(10L);
        childrenTask5.setTotalCount(20L);
        Task childrenTask6 = new Task();
        childrenTask6.setId(212L);
        childrenTask6.setParent(jsonTask3);
        childrenTask6.setCompletedCount(30L);
        childrenTask6.setTotalCount(40L);
        Task childrenTask7 = new Task();
        childrenTask7.setId(221L);
        childrenTask7.setParent(jsonTask4);
        childrenTask7.setCompletedCount(50L);
        childrenTask7.setTotalCount(60L);
        Task childrenTask8 = new Task();
        childrenTask8.setId(222L);
        childrenTask8.setParent(jsonTask4);
        childrenTask8.setCompletedCount(70L);
        childrenTask8.setTotalCount(80L);
        childrenTasks.add(childrenTask1);
        childrenTasks.add(childrenTask2);
        childrenTasks.add(childrenTask3);
        childrenTasks.add(childrenTask4);
        childrenTasks.add(childrenTask5);
        childrenTasks.add(childrenTask6);
        childrenTasks.add(childrenTask7);
        childrenTasks.add(childrenTask8);
        Mockito.doNothing().when(controller).getTotalAndCompletedCounts(Mockito.anyList());
        when(taskProcessorRepository.findRootTasks(rootTask1.getTenantUuid())).thenReturn(rootTasks);
        when(taskProcessorRepository.findChildrenTasksBasedOnParentTasks(rootTask1.getTenantUuid(),
            rootTasks.stream().map(rootTask -> rootTask.getId()).collect(Collectors.toCollection(ArrayList::new))))
            .thenReturn(jsonTasks);
        when(taskProcessorRepository.findChildrenTasksBasedOnParentTasks(rootTask1.getTenantUuid(),
            jsonTasks.stream().map(jsonTask -> jsonTask.getId()).collect(Collectors.toCollection(ArrayList::new))))
            .thenReturn(childrenTasks);
        controller.enrichTotalAndCompletedCountsForRootTasks(rootTask1.getTenantUuid());
    }

    @Test
    public void enrichTotalAndCompletedCountsForRootTasks_oneRootTask() {
        List<Task> rootTasks = new ArrayList<>();
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid("abcd");
        rootTask1.setId(100L);
        rootTask1.setCompletedCount(null);
        rootTask1.setTotalCount(null);
        rootTask1.setTotalCount(0L);
        rootTask1.setCompletedCount(0L);
        rootTask1.setStatus(TaskStatus.IN_PROGRESS);
        rootTasks.add(rootTask1);
        List<Task> jsonTasks = new ArrayList<>();
        Task jsonTask1 = new Task();
        jsonTask1.setId(110L);
        jsonTask1.setParent(rootTask1);
        Task jsonTask2 = new Task();
        jsonTask2.setId(120L);
        jsonTask2.setParent(rootTask1);
        jsonTasks.add(jsonTask1);
        jsonTasks.add(jsonTask2);
        List<Task> childrenTasks = new ArrayList<>();
        Task childrenTask1 = new Task();
        childrenTask1.setId(111L);
        childrenTask1.setParent(jsonTask1);
        childrenTask1.setCompletedCount(1000L);
        childrenTask1.setTotalCount(2000L);
        Task childrenTask2 = new Task();
        childrenTask2.setId(112L);
        childrenTask2.setParent(jsonTask1);
        childrenTask2.setCompletedCount(3000L);
        childrenTask2.setTotalCount(4000L);
        Task childrenTask3 = new Task();
        childrenTask3.setId(121L);
        childrenTask3.setParent(jsonTask2);
        childrenTask3.setCompletedCount(5000L);
        childrenTask3.setTotalCount(6000L);
        Task childrenTask4 = new Task();
        childrenTask4.setId(122L);
        childrenTask4.setParent(jsonTask2);
        childrenTask4.setCompletedCount(7000L);
        childrenTask4.setTotalCount(8000L);
        childrenTasks.add(childrenTask1);
        childrenTasks.add(childrenTask2);
        childrenTasks.add(childrenTask3);
        childrenTasks.add(childrenTask4);
        Mockito.doNothing().when(controller).getTotalAndCompletedCounts(Mockito.anyList());
        when(taskProcessorRepository.findRootTasks(rootTask1.getTenantUuid())).thenReturn(rootTasks);
        when(taskProcessorRepository.findChildrenTasksBasedOnParentTasks(rootTask1.getTenantUuid(),
            rootTasks.stream().map(rootTask -> rootTask.getId()).collect(Collectors.toCollection(ArrayList::new))))
            .thenReturn(jsonTasks);
        controller.enrichTotalAndCompletedCountsForRootTasks(rootTask1.getTenantUuid());
    }

    @Test
    public void enrichTotalAndCompletedCountsForRootTasks_emptyTasks() {
        controller.enrichTotalAndCompletedCountsForRootTasks("any");
    }

    @Test
    public void enrichTotalAndCompletedCountsForRootTasks_nullTasks() {
        List<Task> rootTasks = null;
        controller.enrichTotalAndCompletedCountsForRootTasks("any");
    }

    @Test
    public void enrichTotalAndCompletedCountsForRootTasks_completedTasks() {
        List<Task> rootTasks = new ArrayList<>();
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid("abcd");
        rootTask1.setId(100L);
        rootTask1.setCompletedCount(1000L);
        rootTask1.setTotalCount(1000L);
        rootTasks.add(rootTask1);
        rootTask1.setStatus(TaskStatus.IN_PROGRESS);
        List<Task> jsonTasks = new ArrayList<>();
        Task jsonTask1 = new Task();
        jsonTask1.setId(110L);
        jsonTask1.setParent(rootTask1);
        Task jsonTask2 = new Task();
        jsonTask2.setId(120L);
        jsonTask2.setParent(rootTask1);
        jsonTasks.add(jsonTask1);
        jsonTasks.add(jsonTask2);
        List<Task> childrenTasks = new ArrayList<>();
        Task childrenTask1 = new Task();
        childrenTask1.setId(111L);
        childrenTask1.setParent(jsonTask1);
        childrenTask1.setCompletedCount(1000L);
        childrenTask1.setTotalCount(2000L);
        Task childrenTask2 = new Task();
        childrenTask2.setId(112L);
        childrenTask2.setParent(jsonTask1);
        childrenTask2.setCompletedCount(3000L);
        childrenTask2.setTotalCount(4000L);
        Task childrenTask3 = new Task();
        childrenTask3.setId(121L);
        childrenTask3.setParent(jsonTask2);
        childrenTask3.setCompletedCount(5000L);
        childrenTask3.setTotalCount(6000L);
        Task childrenTask4 = new Task();
        childrenTask4.setId(122L);
        childrenTask4.setParent(jsonTask2);
        childrenTask4.setCompletedCount(7000L);
        childrenTask4.setTotalCount(8000L);
        childrenTasks.add(childrenTask1);
        childrenTasks.add(childrenTask2);
        childrenTasks.add(childrenTask3);
        childrenTasks.add(childrenTask4);
        Mockito.doNothing().when(controller).getTotalAndCompletedCounts(Mockito.anyList());
        when(taskProcessorRepository.findRootTasks(rootTask1.getTenantUuid())).thenReturn(rootTasks);
        when(taskProcessorRepository.findChildrenTasksBasedOnParentTasks(rootTask1.getTenantUuid(),
            rootTasks.stream().map(rootTask -> rootTask.getId()).collect(Collectors.toCollection(ArrayList::new))))
            .thenReturn(jsonTasks);
        when(taskProcessorRepository.findChildrenTasksBasedOnParentTasks(rootTask1.getTenantUuid(),
            jsonTasks.stream().map(jsonTask -> jsonTask.getId()).collect(Collectors.toCollection(ArrayList::new))))
            .thenReturn(childrenTasks);
        controller.enrichTotalAndCompletedCountsForRootTasks(rootTask1.getTenantUuid());
    }

    @Test
    public void enrichTotalAndCompletedCountsForRootTasks_rootTasksOnly1() {
        List<Task> rootTasks = new ArrayList<>();
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid("abcd");
        rootTask1.setId(100L);
        rootTasks.add(rootTask1);
        rootTask1.setStatus(TaskStatus.IN_PROGRESS);
        when(taskProcessorRepository.findRootTasks(rootTask1.getTenantUuid())).thenReturn(rootTasks);
        when(taskProcessorRepository.findChildrenTasksBasedOnParentTasks(rootTask1.getTenantUuid(),
            rootTasks.stream().map(rootTask -> rootTask.getId()).collect(Collectors.toCollection(ArrayList::new))))
            .thenReturn(Collections.EMPTY_LIST);
        controller.enrichTotalAndCompletedCountsForRootTasks(rootTask1.getTenantUuid());
    }

    @Test
    public void enrichTotalAndCompletedCountsForRootTasks_rootTasksOnly2() {
        List<Task> rootTasks = new ArrayList<>();
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid("abcd");
        rootTask1.setId(100L);
        rootTasks.add(rootTask1);
        rootTask1.setStatus(TaskStatus.IN_PROGRESS);
        when(taskProcessorRepository.findRootTasks(rootTask1.getTenantUuid())).thenReturn(rootTasks);
        when(taskProcessorRepository.findChildrenTasksBasedOnParentTasks(rootTask1.getTenantUuid(),
            rootTasks.stream().map(rootTask -> rootTask.getId()).collect(Collectors.toCollection(ArrayList::new))))
            .thenReturn(null);
        controller.enrichTotalAndCompletedCountsForRootTasks(rootTask1.getTenantUuid());
        Assert.assertTrue(rootTasks.get(0).getCompletedCount() == 0L);
        Assert.assertTrue(rootTasks.get(0).getTotalCount() == 0L);
    }

    @Test
    public void enrichTotalAndCompletedCountsForRootTasks_rootJsonTasksOnly() {
        List<Task> rootTasks = new ArrayList<>();
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid("abcd");
        rootTask1.setId(100L);
        rootTask1.setCompletedCount(1000L);
        rootTask1.setTotalCount(1000L);
        rootTasks.add(rootTask1);
        rootTask1.setStatus(TaskStatus.IN_PROGRESS);
        List<Task> jsonTasks = new ArrayList<>();
        Task jsonTask1 = new Task();
        jsonTask1.setId(110L);
        jsonTask1.setParent(rootTask1);
        Task jsonTask2 = new Task();
        jsonTask2.setId(120L);
        jsonTask2.setParent(rootTask1);
        jsonTasks.add(jsonTask1);
        jsonTasks.add(jsonTask2);
        Mockito.doNothing().when(controller).getTotalAndCompletedCounts(Mockito.anyList());
        when(taskProcessorRepository.findRootTasks(rootTask1.getTenantUuid())).thenReturn(rootTasks);
        when(taskProcessorRepository.findChildrenTasksBasedOnParentTasks(rootTask1.getTenantUuid(),
            rootTasks.stream().map(rootTask -> rootTask.getId()).collect(Collectors.toCollection(ArrayList::new))))
            .thenReturn(jsonTasks);
        controller.enrichTotalAndCompletedCountsForRootTasks(rootTask1.getTenantUuid());
    }

    @SuppressWarnings("unchecked")
    private void setupQueryMockForGetIngestionLogs_status() throws IOException {
        Map<String, Object> data = readOneFromFile(baseDir + "/getIngestionLogs/searchStatusWildcard.json", Map.class);
        List<Task> tasks = Arrays.asList(TASKS_READER.readValue(WRITER.writeValueAsString(data.get("content"))));
        PageRequest pageable = new PageRequest(0, 2, new Sort(Direction.DESC, "createdOn"));
        Page<Task> page = new PageImpl<>(tasks, pageable,
            Long.valueOf(data.get("totalElements").toString()).longValue());

        when(taskProcessorRepository.searchStatusWildcard(anyString(), anyString(), (PageRequest) anyObject()))
            .thenReturn(page);

        setupForChildren("/getIngestionLogs",
            StreamSupport.stream(page.spliterator(), false).collect(Collectors.toList()));
    }

    private <T> List<T> readListFromFile(String filePath, Class<T> clazz) throws IOException {
        try (InputStream is = getClass().getResourceAsStream(filePath)) {
            if (is == null) {
                return Collections.emptyList();
            } else {
                T[] data = MAPPER.reader(Array.newInstance(clazz, 0).getClass()).readValue(is);
                return Arrays.asList(data);
            }
        }
    }

    private <T> T readOneFromFile(String filePath, Class<T> clazz) throws IOException {
        try (InputStream is = getClass().getResourceAsStream(filePath)) {
            if (is == null) {
                return null;
            } else {
                return MAPPER.reader(clazz).readValue(is);
            }
        }
    }
}
