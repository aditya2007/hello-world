/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.rest.client;

import java.util.Collections;

import org.junit.Test;

import com.ge.apm.asset.model.Enterprise;

/**
 * Description of AssetClientTest
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Mar 2, 2016
 * @since 1.0
 */
public class AssetClientTest {

    // This unit test is fairly useless except for test coverage

    @Test
    public void create_null() {
        AssetClient client = new AssetClient();
        client.<Enterprise>create("prefix", (Enterprise[]) null);
    }

    @Test
    public void create_empty() {
        AssetClient client = new AssetClient();
        client.<Enterprise>create("prefix", Collections.<Enterprise>emptyList().toArray(new Enterprise[0]));
    }

    @Test
    public void update_null() {
        AssetClient client = new AssetClient();
        client.<Enterprise>create("prefix", (Enterprise[]) null);
    }
}
