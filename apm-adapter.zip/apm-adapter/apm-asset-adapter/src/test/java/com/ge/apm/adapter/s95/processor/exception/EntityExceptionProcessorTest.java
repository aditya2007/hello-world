/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.exception;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.component.rabbitmq.RabbitMQConstants;
import org.apache.camel.impl.DefaultMessage;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.adapter.s95.exception.RecoverableException;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

/**
 * Created by 212438472 on 8/24/17.
 */
@PrepareForTest(Exchange.class)
@RunWith(PowerMockRunner.class)
public class EntityExceptionProcessorTest {

    //EntityExceptionProcessor exceptionProcessor = new EntityExceptionProcessor();
    @InjectMocks
    @Autowired
    EntityExceptionProcessor exceptionProcessor;

    @Mock
    private Exchange mockExchange;

    @Mock
    private Message mockMessage;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        PowerMockito.mockStatic(Exchange.class);
        HashMap<String, Object> mockHeaders = new HashMap<>();
        mockHeaders.put("mockKey", "mockValue");

        mockMessage = new DefaultMessage();
        mockMessage.setHeader(MessageConstants.TENANT_UUID, "mockTenant");
        mockMessage.setHeader(MessageConstants.TASK_UUID, "mockTask");
        mockMessage.setHeader(Exchange.FILE_NAME, "create.json");
        mockMessage.setHeader(MessageConstants.DESCRIPTION, "");
        mockMessage.setBody(this.getClass().getResourceAsStream("/assetIn/assetgroupassociations/create.json"));
        doReturn(mockMessage).when(mockExchange).getIn();
        doReturn(mockMessage).when(mockExchange).getOut();
    }

    @Test(expected = RecoverableException.class)
    public void testProcess() throws Exception {
        Throwable mockThrowable = new Throwable();
        mockThrowable.initCause(new IllegalStateException());
        when(mockExchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class)).thenReturn(mockThrowable);
        try {
            exceptionProcessor.process(mockExchange);
        } catch (RecoverableException exception) {
            Assert.assertEquals("Requeue not set:", mockExchange.getOut().getHeader(RabbitMQConstants.REQUEUE), "true");
            throw exception;
        }
    }

    @Test(expected = RecoverableException.class)
    public void testProcessThrowsValidationFailedException() throws Exception {
        Throwable mockThrowable = new Throwable();
        mockThrowable.initCause(new ValidationFailedException(new ArrayList<Error>()));
        when(mockExchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class)).thenReturn(mockThrowable);
        try {
            exceptionProcessor.process(mockExchange);
        } catch (RecoverableException exception) {
            Assert.assertEquals("Requeue not set:", mockExchange.getOut().getHeader(RabbitMQConstants.REQUEUE), "true");
            throw exception;
        }
    }

    @Test
    public void testProcessWithUnrecoverableException() throws Exception {
        exceptionProcessor.process(mockExchange);
        Assert.assertEquals(mockExchange.getOut().getBody(), mockMessage.getBody());
    }

    @Test
    public void testRabbitMQException() throws Exception {
        Throwable mockThrowable = new Throwable();
        mockThrowable.initCause(new IllegalStateException());
        when(mockExchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class)).thenReturn(mockThrowable);
        exceptionProcessor.rabbitmqException(mockExchange);
    }

    @Test
    public void testPostgresException() throws Exception {
        Throwable mockThrowable = new Throwable();
        mockThrowable.initCause(new IllegalStateException());
        when(mockExchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class)).thenReturn(mockThrowable);
        exceptionProcessor.postgresException(mockExchange);
    }
}
