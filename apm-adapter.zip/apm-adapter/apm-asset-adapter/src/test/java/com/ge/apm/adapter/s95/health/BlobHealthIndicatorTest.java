/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.health;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.actuate.health.Health;
import org.springframework.util.StopWatch.TaskInfo;

import com.ge.apm.adapter.s95.rest.client.BlobClient;
import com.ge.apm.blob.client.BlobArchiveClient;

import static org.mockito.Mockito.when;

/**
 * Unit test for {@link BlobHealthIndicatorTest}.
 */
@PrepareForTest(BlobArchiveClient.class)
@RunWith(PowerMockRunner.class)
public class BlobHealthIndicatorTest {

    @Mock
    private BlobClient blobClient;

    @Mock
    private BlobArchiveClient blobArchiveClient;

    public static boolean isTaskHealthCheck(Object healthStatus) {
        return "healthCheck".equals(((TaskInfo) healthStatus).getTaskName());
    }

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        PowerMockito.mockStatic(BlobArchiveClient.class);
    }

    @Test
    public void testBlobServiceUp() {
        when(blobClient.getBlobArchiveClient()).thenReturn(blobArchiveClient);
        when(blobArchiveClient.healthStatus()).thenReturn(true);
        final BlobHealthIndicator healthIndicator = new BlobHealthIndicator(blobClient);
        Health upHealth = healthIndicator.health();
        Assert.assertEquals("Service status is not correct:", "UP", upHealth.getStatus().getCode());
        Assert.assertEquals("Service details Size is not matching:", 1, upHealth.getDetails().size());
        Assert.assertTrue("Service details Key is not matching:", upHealth.getDetails().containsKey("apmBlob"));
        Assert.assertTrue("Service details Value is not matching:",
            upHealth.getDetails().values().stream().anyMatch(BlobHealthIndicatorTest::isTaskHealthCheck));
    }

    @Test
    public void testBlobServiceDown() {
        when(blobClient.getBlobArchiveClient()).thenReturn(blobArchiveClient);
        when(blobArchiveClient.healthStatus()).thenReturn(false);
        final BlobHealthIndicator healthIndicator = new BlobHealthIndicator(blobClient);
        Health upHealth = healthIndicator.health();
        Assert.assertEquals("Service status is not correct:", "DOWN", upHealth.getStatus().getCode());
        Assert.assertEquals("Service details Size is not matching:", 1, upHealth.getDetails().size());
        Assert.assertTrue("Service details Key is not matching:", upHealth.getDetails().containsKey("apmBlob"));
        Assert.assertTrue("Service details Value is not matching:",
            upHealth.getDetails().values().stream().anyMatch(BlobHealthIndicatorTest::isTaskHealthCheck));
    }
}