/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.type;

import java.io.IOException;
import java.util.List;
import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.springframework.test.annotation.DirtiesContext;

import com.ge.apm.adapter.ccom.base.BaseTransformerTest;
import com.ge.apm.asset.model.Type;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.asset.commons.validator.ValidationFailedException;

@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public abstract class BaseTypeTransformerTest<T extends Type> extends BaseTransformerTest<T> {

    @Test
    public void create() throws IOException, JAXBException, ValidationFailedException {
        testWithNoSourceKeyLookup("create");
        verifyPOSTCalls(getPrefix());
    }

    @Test
    public void createWithParent() throws IOException, JAXBException, ValidationFailedException {
        testWithOneSourceKeyLookup("createWithParent", Id1, Uuid1);
    }

    @Test(expected = ValidationFailedException.class)
    public void createThrowExceptionOnNameMissing() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/create.xml");
        entities.get(0).setName(null);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }
}
