/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.io.IOException;
import java.util.List;
import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.ccom.base.BaseTransformerTest;
import com.ge.apm.asset.model.Enterprise;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.asset.commons.validator.ValidationFailedException;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BaseTransformerTest.Configuration.class)
public class EnterpriseTransformerTest extends BaseTypedTransformerTest<Enterprise> {

    @Override
    protected String getPrefix() {
        return Prefixes.Enterprises;
    }

    @Override
    protected Class<Enterprise> getObjectClass() {
        return Enterprise.class;
    }

    @Override
    protected String getTypePrefix() {
        return Prefixes.EnterpriseTypes;
    }

    @Override
    protected void setupLookupForCreate() {
        setupLookupObjectUriFor(Id4, getTypePrefix(), Uuid4);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
    }

    @Override
    protected void setupLookupForUpdate() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupLookupObjectUriFor(Id4, getTypePrefix(), Uuid4);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
    }

    @Override
    protected void setupLookupForUpdateOne() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
    }

    @Test
    public void createWithEmptyName() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/create.xml");
        entities.get(0).setName(null);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }
}
