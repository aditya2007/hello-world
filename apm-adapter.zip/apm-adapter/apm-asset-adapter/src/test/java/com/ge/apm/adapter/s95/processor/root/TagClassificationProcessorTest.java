/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import com.fasterxml.jackson.core.JsonParser;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.ge.apm.adapter.common.util.IEntityDispatcher;
import com.ge.apm.adapter.s95.util.ReflectionUtils;
import com.ge.apm.s95.model.TagClassification;

import static org.junit.Assert.fail;

/**
 * @author 212312392
 */

public class TagClassificationProcessorTest {

    TagClassificationProcessor tagClassificationProcessor;

    @Before
    public void setUp() throws Exception {
        tagClassificationProcessor = new TagClassificationProcessor();
    }

    @Test
    public void testProcessJsonParser() {
        try {
            JsonParser parser = Mockito.mock(JsonParser.class);
            TagClassification classification = Mockito.mock(TagClassification.class);
            Mockito.when(parser.readValueAs(TagClassification.class)).thenReturn(classification);
            Mockito.when(classification.getParent()).thenReturn("testClassification");
            IEntityDispatcher iEntityDispatcher = Mockito.mock(IEntityDispatcher.class);
            ReflectionUtils.setField(TagClassificationProcessor.class, tagClassificationProcessor, "entityDispatcher",
                iEntityDispatcher);

            tagClassificationProcessor.process(parser);
        } catch (Exception exc) {
            fail(exc.getLocalizedMessage());
        }
    }

    @Test
    public void testSupportedField() {
        Assert.assertTrue(tagClassificationProcessor.supportedField().equals("tagClassifications"));
    }
}
