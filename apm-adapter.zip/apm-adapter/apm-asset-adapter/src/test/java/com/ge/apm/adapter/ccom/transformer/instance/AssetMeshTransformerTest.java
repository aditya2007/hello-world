/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.web.client.RestTemplate;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.BaseTransformer;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.core.types.TextType;
import com.ge.apm.ccom.model.core.types.UUID;
import com.ge.apm.ccom.model.network.connections.AssetConnection;
import com.ge.apm.ccom.model.network.connections.ConnectionType;
import com.ge.apm.ccom.model.network.topologies.AssetMesh;
import com.ge.apm.ccom.model.registry.Asset;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Description of AssetMeshTransformerTest
 *
 * @author Deepak 212400139
 * @version 1.0 Mar 9, 2016
 * @since 1.0
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest(BaseTransformer.class)
public class AssetMeshTransformerTest {

    public RestTemplate restTemplate;

    public AssetMesh assetMesh;

    public AssetMeshTransformer at;

    @Mock
    private AssetClient assetClient;

    @Mock
    private AssetConnection assetConnection;

    @Mock
    private ConnectionType connectionType;

    @Mock
    private TextType textType;

    @Mock
    private Asset asset;

    @Mock
    private UUID uuid;

    @Mock
    private List<Asset> assetsToUpdate;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        assetMesh = new AssetMesh();
        at = new AssetMeshTransformer(assetClient);
    }

    @Test
    public void testGetPrefix() {
        Assert.assertEquals(Prefixes.Assets, at.getPrefix());
    }

    @Test
    public void testOrder() {
        Assert.assertEquals(12, at.order());
    }

    @Test
    public void testSupportedCcomClass() {
        Assert.assertEquals(AssetMesh.class, at.supportedCcomClass());
    }

    @Test
    public void testDoCreateOrUpdateWithNoAssetToUpdate() {
        at.doDispatch();
    }

    @Test
    public void testDoCreateOrUpdateWithAssetToUpdate() {
        Mockito.when(assetsToUpdate.size()).thenReturn(1);
        at.doDispatch();
    }

    @Test
    public void testTransformWithNoAssetConnections() throws ServiceException, ValidationFailedException {
        at.transform(assetMesh);
        Assert.assertNotNull(at);
    }

    @Test
    public void testTransformWithAssetConnection() throws ServiceException, ValidationFailedException {
        List<AssetConnection> ac = new ArrayList<AssetConnection>();
        ac.add(assetConnection);

        assetMesh.getConnection().add(assetConnection);

        Mockito.when(assetConnection.getType()).thenReturn(connectionType);
        Mockito.when(connectionType.getName()).thenReturn(textType);
        Mockito.when(textType.getValue()).thenReturn("TestEnterprise");

        Mockito.when(assetConnection.getFrom()).thenReturn(asset);
        Mockito.when(assetConnection.getTo()).thenReturn(asset);
        Mockito.when(asset.getGUID()).thenReturn(uuid);
        Mockito.when(uuid.getValue()).thenReturn("TestFromSourceKey");

        at.transform(assetMesh);
        at.doDispatch();
        Assert.assertNotNull(at);
    }

    @After
    public void destroy() {
        restTemplate = null;
        assetClient = null;
        at = null;
        assetsToUpdate = null;
        assetMesh = null;
    }
}
