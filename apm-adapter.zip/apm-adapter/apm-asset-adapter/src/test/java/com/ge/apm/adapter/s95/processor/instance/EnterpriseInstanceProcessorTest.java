/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.instance;

import java.io.IOException;

import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.ccom.model.registry.Enterprise;
import com.ge.apm.ccom.model.registry.EnterpriseType;
import com.ge.apm.s95.model.Instance;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Description of AssetInstanceProcessorTest
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Nov 17, 2016
 * @since 1.0
 */
@RunWith(PowerMockRunner.class)
@Slf4j
public class EnterpriseInstanceProcessorTest {

    @Mock
    Enterprise enterprise;

    @Mock
    EnterpriseType enterpriseType;

    @Mock
    Instance instance;

    @InjectMocks
    @Autowired
    EnterpriseInstanceProcessor enterpriseInstanceProcessor;

    @Test
    public void testAssignEntityType() {
        enterprise = new Enterprise();
        enterpriseType = new EnterpriseType();
        enterpriseInstanceProcessor.assignEntityType(enterprise, enterpriseType);
        Assert.assertEquals("EnterpriseType not set:", enterprise.getType(), enterpriseType);
    }

    @Test
    public void testProcessOthers() throws IOException, ValidationFailedException {
        enterpriseInstanceProcessor.processOthers(enterprise, instance);
    }
}
