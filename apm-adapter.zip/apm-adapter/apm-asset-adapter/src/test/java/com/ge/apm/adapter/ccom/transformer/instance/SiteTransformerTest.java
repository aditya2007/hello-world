/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.io.IOException;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.ccom.base.BaseTransformerTest;
import com.ge.apm.asset.model.Site;
import com.ge.apm.asset.model.constants.Prefixes;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BaseTransformerTest.Configuration.class)
public class SiteTransformerTest extends BaseMonitoredTransformerTest<Site> {

    @Override
    protected String getPrefix() {
        return Prefixes.Sites;
    }

    @Override
    protected Class<Site> getObjectClass() {
        return Site.class;
    }

    @Override
    protected String getTypePrefix() {
        return Prefixes.SiteTypes;
    }

    @Override
    protected void setupLookupForCreate() {
        setupLookupObjectUriFor(Id3, Prefixes.Enterprises, Uuid3);
        setupLookupObjectUriFor(Id4, getTypePrefix(), Uuid4);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
    }

    @Ignore("todo")
    @Test
    @Override
    public void createThrowExceptionOnIdMissing() throws IOException {
        //Added an empty line for PMD.
    }

    @Override
    protected void setupLookupForUpdate() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Prefixes.Enterprises, Uuid3);
        setupLookupObjectUriFor(Id4, getTypePrefix(), Uuid4);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
    }

    @Override
    protected void setupLookupForUpdateOne() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id3, Prefixes.Enterprises, Uuid3);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
    }

    @Override
    protected void setupLookupForCreateWithConnections() {
        setupLookupObjectUriFor(Id3, Prefixes.Enterprises, Uuid3);
        setupLookupObjectUriFor(Id4, getTypePrefix(), Uuid4);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
        setupLookupObjectUriFor(Id6, Prefixes.Assets, Uuid6);
    }

    @Override
    protected void setupLookupForUpdateWithConnections() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Prefixes.Enterprises, Uuid3);
        setupLookupObjectUriFor(Id4, getTypePrefix(), Uuid4);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
        setupLookupObjectUriFor(Id6, Prefixes.Assets, Uuid6);
    }
}
