/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.scheduled;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.TestApp;
import com.ge.apm.adapter.domain.persistence.repository.IFileChecksumRepository;
import com.ge.apm.datasource.TenantDataSourceService;

/**
 * Description of FileChecksumJobTest
 *
 * @author Albert H. Yu hsiang-aiyu
 * @version 1.0 Mar 3, 2017
 * @since 1.0
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = { TestApp.class, FileChecksumJob.class })
public class FileChecksumJobTest {
    
    @InjectMocks
    @Autowired
    private FileChecksumJob fileChecksumJob;
    
    @MockBean
    private IFileChecksumRepository fileChecksumRepository;

    @MockBean
    private TenantDataSourceService tenantDataSourceService;
    
    @Test
    public void deleteFileChecksum() {
        fileChecksumJob.deleteFileChecksum();
    }

}
