/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

/**
 *
 */

package com.ge.apm.adapter.ccom.util;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import static org.mockito.Mockito.mock;

/**
 * @author 212312392
 *
 */
public class LocalConfigurationTest {

    public LocalConfiguration localConfiguration;

    public RedisTemplate<Object, Object> redisOperations;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        localConfiguration = new LocalConfiguration();
        redisOperations = mock(RedisTemplate.class);
    }

    @Test
    public void testConnectionFactory() {

        JedisConnectionFactory jedisConnectionFactory = localConfiguration.connectionFactory();
        Assert.assertTrue(jedisConnectionFactory.getUsePool());
    }

    @Test
    public void testRedisTemplate() {

        JedisConnectionFactory jedisConnectionFactory = localConfiguration.connectionFactory();
        RedisTemplate<Object, Object> redisTemplate = localConfiguration.redisTemplate(jedisConnectionFactory);
        Assert.assertNotNull(redisTemplate.getConnectionFactory());
    }

    @Test
    public void testApmCacheManager() {
        CacheManager cacheManager;
        cacheManager = localConfiguration.apmCacheManager(redisOperations);
        Assert.assertTrue(cacheManager instanceof RedisCacheManager);
    }
}
