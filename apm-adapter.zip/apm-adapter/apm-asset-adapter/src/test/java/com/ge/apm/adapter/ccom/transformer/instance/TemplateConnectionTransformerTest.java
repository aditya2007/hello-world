/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.io.IOException;
import java.util.List;
import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.ccom.base.BaseTransformerTest;
import com.ge.apm.asset.model.TemplateConnection;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Unit test for {@link TemplateConnectionTransformer}.
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BaseTransformerTest.Configuration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class TemplateConnectionTransformerTest extends BaseTypedTransformerTest<TemplateConnection> {

    @Override
    protected String getPrefix() {
        return "/templateConnections";
    }

    @Override
    protected Class<TemplateConnection> getObjectClass() {
        return TemplateConnection.class;
    }

    @Override
    protected String getTypePrefix() {
        return null;
    }

    @Override
    protected void setupLookupForCreate() {

    }

    @Override
    protected void setupLookupForUpdate() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id2, Uuid2);
    }

    @Override
    protected void setupLookupForUpdateOne() {

    }

    @Test
    @Override
    public void create() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/create.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        //setupGetTemplateConnection(Uuid1, Prefixes.TemplateConnections, "TEMPLATE_CONNECTIONS");
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test
    public void createWithSite() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/createWithSite.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        //setupGetTemplateConnection(Uuid1, Prefixes.TemplateConnections, "TEMPLATE_CONNECTIONS");
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test
    public void createWithSegment() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/createWithSegment.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        //setupGetTemplateConnection(Uuid1, Prefixes.TemplateConnections, "TEMPLATE_CONNECTIONS");
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test
    public void createWithAsset() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/createWithAsset.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        //setupGetTemplateConnection(Uuid1, Prefixes.TemplateConnections, "TEMPLATE_CONNECTIONS");
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    //Use this method for future implementation tests for different types
    @Test(expected = ServiceException.class)
    public void createTemplateConnectionForEnterprise() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/createWithEnterprise.xml");

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test
    @Override
    public void createThrowExceptionOnIdMissing() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/createMissingTemplateId.xml");
        entities.get(0).setGUID(null);
        try {
            entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "",
                false);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}