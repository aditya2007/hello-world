/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.mq;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.impl.DefaultMessage;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.adapter.domain.persistence.entity.Task;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.apm.adapter.s95.rest.client.BlobClient;
import com.ge.apm.blob.client.BlobArchiveClient;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

/**
 * Created by 212438472 on 8/24/17.
 */
@RunWith(PowerMockRunner.class)
public class FileProcessorTest {

    @InjectMocks
    @Autowired
    FileProcessor fileProcessor;

    @Mock
    private BlobClient blobClient;

    @Mock
    private BlobArchiveClient blobArchiveClient;

    @Mock
    private ITaskProcessorRepository taskProcessorRepository;

    @Mock
    private Exchange mockExchange;

    @Mock
    private Message mockMessage;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        MockitoAnnotations.initMocks(this);
        mockMessage = new DefaultMessage();
        mockMessage.setHeader(MessageConstants.TENANT_UUID, "mockTenant");
        mockMessage.setHeader(MessageConstants.TASK_UUID, "mockTask");
        mockMessage.setHeader(Exchange.FILE_NAME, "create.json");
        mockMessage.setHeader(MessageConstants.DESCRIPTION, "");
        mockMessage.setHeader(MessageConstants.PERDIX_BLOB_FILE_KEY, "anykey");
        doReturn(mockMessage).when(mockExchange).getIn();
        doReturn(mockMessage).when(mockExchange).getOut();
    }

       @Test
       public void testUploadFile() throws IOException, ValidationFailedException {
           mockMessage.setBody(this.getClass().getResourceAsStream("/assetIn/assetgroupassociations/create.json"));
           when(blobClient.getBlobArchiveClient()).thenReturn(blobArchiveClient);
           when(blobArchiveClient.archiveBlob(mockExchange, mockMessage.getBody(InputStream.class))).thenReturn(
               "/mockedDownloadUrl");
           Task task = new Task();
           task.setUuid(UUID.randomUUID().toString());
           when(taskProcessorRepository.findByTenantUuidAndUuid(any(), any()))
               .thenReturn(task);
           fileProcessor.uploadFile(mockExchange);
           Assert.assertEquals("download URL is not matching:", mockExchange.getOut().getBody(),
    "/mockedDownloadUrl");
           Assert.assertEquals("Upload headers are not matching:", mockExchange.getOut().getHeaders(),
               mockMessage.getHeaders());
       }

       @Test
       public void testDownloadFile() throws IOException, ValidationFailedException {
           InputStream mockStream = null;
        try {
            mockStream = this.getClass().getResourceAsStream("/assetIn/assetgroupassociations/create.json");
            mockMessage.setBody("/mockedDownloadUrl");
            when(blobClient.getBlobArchiveClient()).thenReturn(blobArchiveClient);
            when(blobArchiveClient.downloadBlob(mockExchange, "/mockedDownloadUrl")).thenReturn(mockStream);
            fileProcessor.downloadFile(mockExchange);
            Assert.assertEquals("download URL is not matching:", mockExchange.getOut().getBody(), mockStream);
            Assert.assertEquals("Upload headers are not matching:", mockExchange.getOut().getHeaders(),
                mockMessage.getHeaders());
        } finally {
            mockStream.close();
        }
       }

}
