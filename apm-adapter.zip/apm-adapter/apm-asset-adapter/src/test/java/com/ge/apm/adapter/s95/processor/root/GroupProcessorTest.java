/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.adapter.s95.base.BaseTest;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.common.util.IdGenerator;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.ValidationFailedException;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class })
public class GroupProcessorTest extends BaseTest {

    //TODO - Refactor unit tests for Tag Group Associations
    //    @Mock
    //    private IEntityDispatcher entityDispatcher;
    //    @Captor
    //    private ArgumentCaptor<Entity> entityCaptor;
    @InjectMocks
    private GroupProcessor groupProcessor;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        mockIdGenerator();
        RequestContext.put(RequestContext.TENANT_UUID, "Tenant1");
    }

    @Test
    public void processGroupInvalidID() throws IOException {
        JsonParser parser = getParserFor("/s95/groupProcessorTests/groupInvalidID.json");
        try {
            groupProcessor.process(parser);
        } catch (ValidationFailedException vfa) {
            Assert.assertEquals(vfa.getErrorCollection().get(0).getErrorCode(), ErrorConstants.GROUP_ID_MISSING_CODE);
        }
    }

    @Test
    public void processGroupMissingCCOM() throws IOException {
        JsonParser parser = getParserFor("/s95/groupProcessorTests/groupMissingCCOM.json");
        try {
            groupProcessor.process(parser);
        } catch (ValidationFailedException vfa) {
            Assert.assertEquals(vfa.getErrorCollection().get(0).getErrorCode(), ErrorConstants.MISSING_CCOM_GROUP);
        }
    }

    @Test
    public void processGroupInvalidCCOM() throws IOException {
        JsonParser parser = getParserFor("/s95/groupProcessorTests/groupInvalidCCOM.json");
        try {
            groupProcessor.process(parser);
        } catch (ValidationFailedException vfa) {
            Assert.assertEquals(vfa.getErrorCollection().get(0).getErrorCode(), ErrorConstants.INVALID_CCOM_GROUP);
        }
    }

    @Test
    public void processGroupMissingAssociatedEntityCcomClass() throws IOException {
        JsonParser parser = getParserFor("/s95/groupProcessorTests/groupMissingAssociatedEntityCcomClass.json");
        try {
            groupProcessor.process(parser);
        } catch (ValidationFailedException vfa) {
            Assert.assertEquals(vfa.getErrorCollection().get(0).getErrorCode(),
                ErrorConstants.MISSING_ASSOCIATED_ENTITY_CCOM_GROUP);
        }
    }

    @Test
    public void processGroupInvalidAssociatedEntityCcomClass() throws IOException {
        JsonParser parser = getParserFor("/s95/groupProcessorTests/groupInvalidAssociatedEntityCcomClass.json");
        try {
            groupProcessor.process(parser);
        } catch (ValidationFailedException vfa) {
            Assert.assertEquals(vfa.getErrorCollection().get(0).getErrorCode(),
                ErrorConstants.INVALID_ASSOCIATED_ENTITY_CCOM_GROUP);
        }
    }

    @Test
    public void processGroupMissingMappedInstanceCcomClass() throws IOException {
        JsonParser parser = getParserFor("/s95/groupProcessorTests/groupMissingMappedInstanceEntityCcomClass.json");
        try {
            groupProcessor.process(parser);
        } catch (ValidationFailedException vfa) {
            Assert.assertEquals(vfa.getErrorCollection().get(0).getErrorCode(),
                ErrorConstants.MISSING_ASSOCIATED_ENTITY_CCOM_GROUP);
        }
    }

    //TODO - Refactor unit tests for Tag Group Associations
    /*

    @Test
    public void processGroupBasic() throws Exception {
        JsonParser parser = getParserFor("/s95/groupProcessorTests/groupBasic.json");

        groupProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture());

        verifyEntity(entityCaptor.getAllValues(), "/ccom/groupProcessorTests/groupBasic.xml");
    }

    @Test
    public void processTagGroupAssociationBasic() throws Exception {
        JsonParser parser = getParserFor("/s95/groupProcessorTests/tagGroupAssociationBasic.json");

        tagGroupAssociationProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture());

        verifyEntity(entityCaptor.getAllValues(), "/ccom/groupProcessorTests/groupAssociationBasic.xml");
    }

    @Test
    public void processTagGroupAssociationMultipleGroups() throws Exception {
        JsonParser parser = getParserFor("/s95/groupProcessorTests/tagGroupAssociationMultipleGroups.json");

        tagGroupAssociationProcessor.process(parser);
        verify(entityDispatcher, VerificationModeFactory.times(3)).sendEntity(entityCaptor.capture());

        verifyEntity(entityCaptor.getAllValues(), "/ccom/groupProcessorTests/groupAssociationMultipleGroups.xml");
    }

     */

    @Test
    public void supportedField() {
        Assert.assertEquals("groups", new GroupProcessor().supportedField());
    }
}
