/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;
import java.util.Arrays;
import javax.xml.bind.JAXBException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.MappingJsonFactory;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.adapter.common.util.IEntityDispatcher;
import com.ge.apm.adapter.s95.base.BaseTest;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.common.util.IdGenerator;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.verify;

/**
 * Created by 502662077 on 3/3/17.
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class })
public class TemplateConnectionProcessorTest extends BaseTest {

    @Mock
    private IEntityDispatcher entityDispatcher;

    @Captor
    private ArgumentCaptor<Entity> entityCaptor;

    @InjectMocks
    private TemplateConnectionProcessor templateConnectionProcessor;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        mockIdGenerator();
        RequestContext.put(RequestContext.TENANT_UUID, "Tenant1");
    }

    private JsonParser getTemplateParser(String filePath) {
        JsonParser jsonParser = null;
        try {
            jsonParser = new MappingJsonFactory().createParser(BaseTest.class.getResourceAsStream(filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return jsonParser;
    }

    @Test
    public void processTemplateConnections_withoutParent()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        // parentEntityId==null, parentEntityCcomClass==null
        verifyValues("/s95/templateConnectionProcessorTests/templateConnections_withoutParent.json",
            "/ccom/templateConnectionProcessorTests/templateConnections01.xml");
    }

    @Test
    public void processTemplateConnections_emptyParentId()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        // parentEntityId=="", parentEntityCcomClass==null
        verifyValues("/s95/templateConnectionProcessorTests/templateConnections_emptyParentId.json",
            "/ccom/templateConnectionProcessorTests/templateConnections01.xml");
    }

    private void verifyValues(String filePath, String expectedXmlPath)
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getTemplateParser(filePath);
        Assert.assertNotNull(parser);
        templateConnectionProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(templateConnectionProcessor.supportedField()));
        verifyEntity(entityCaptor.getAllValues(), expectedXmlPath);
    }

    @Test
    public void processTemplateConnections_withParentAsset()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        // parentEntityId != null, parentEntityCcomClass == ASSET
        verifyValues("/s95/templateConnectionProcessorTests/templateConnections_withParentAsset.json",
            "/ccom/templateConnectionProcessorTests/templateConnections02.xml");
    }

    @Test
    public void processTemplateConnections_withParentSegment()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        // parentEntityId != null, parentEntityCcomClass == SEGMENT
        verifyValues("/s95/templateConnectionProcessorTests/templateConnections_withParentSegment.json",
            "/ccom/templateConnectionProcessorTests/templateConnections03.xml");
    }

    @Test
    public void processTemplateConnections_withParentSite()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        // parentEntityId != null, parentEntityCcomClass == SITE
        verifyValues("/s95/templateConnectionProcessorTests/templateConnections_withParentSite.json",
            "/ccom/templateConnectionProcessorTests/templateConnections04.xml");
    }

    @Test
    public void processTemplateConnections_nullParentCcom()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        try {
            // parentEntityId != null, parentEntityCcomClass == null
            verifyValues("/s95/templateConnectionProcessorTests/templateConnections_nullParentCcom.json", "");
        } catch (ValidationFailedException vfe) {
            assertEquals("E10032", vfe.getErrorCollection().get(0).getErrorCode());
            assertEquals("[null, parentEntityId1]", Arrays.toString(vfe.getErrorCollection().get(0).getPlaceHolders()));
        }
    }

    @Test
    public void processTemplateConnectionsWithoutCcomClass()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        try {
            verifyValues("/s95/templateConnectionProcessorTests/templateConnectionsWithoutCcom.json", "");
        } catch (ValidationFailedException vfe) {
            assertEquals("E10083", vfe.getErrorCollection().get(0).getErrorCode());
            assertEquals("[template2, ccomClass ]", Arrays.toString(vfe.getErrorCollection().get(0).getPlaceHolders()));
        }
    }

    @Test
    public void processTemplateConnectionsInvalidCcomClass()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        try {
            verifyValues("/s95/templateConnectionProcessorTests/templateConnectionsInvalidCcom.json", "");
        } catch (ValidationFailedException vfe) {
            assertEquals(2, vfe.getErrorCollection().size());
            assertEquals("ET1068", vfe.getErrorCollection().get(0).getErrorCode());
            assertEquals("[SITE, PART01, PPN01]", Arrays.toString(vfe.getErrorCollection().get(0).getPlaceHolders()));
            assertEquals("ET1068", vfe.getErrorCollection().get(1).getErrorCode());
            assertEquals("[SEGMENT, PART05, PPN04]", Arrays.toString(vfe.getErrorCollection().get(1).getPlaceHolders()));
        }
    }

    @Test
    public void processTemplateConnections_nullTemplateId()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        try {
            verifyValues("/s95/templateConnectionProcessorTests/templateConnections_nullTemplateId.json", "");
        } catch (ValidationFailedException vfe) {
            assertEquals("E10083", vfe.getErrorCollection().get(0).getErrorCode());
            assertEquals("[N/A, templateId]", Arrays.toString(vfe.getErrorCollection().get(0).getPlaceHolders()));
        }
    }

    @Test
    public void processTemplateConnections_nullConnections()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        try {
            verifyValues("/s95/templateConnectionProcessorTests/templateConnections_nullConnections.json", "");
        } catch (ValidationFailedException vfe) {
            assertEquals("E10083", vfe.getErrorCollection().get(0).getErrorCode());
            assertEquals("[template2, connections ]", Arrays.toString(vfe.getErrorCollection().get(0).getPlaceHolders()));
        }
    }

    @Test
    public void processTemplateConnections_emptyConnections()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        try {
            verifyValues("/s95/templateConnectionProcessorTests/templateConnections_emptyConnections.json", "");
        } catch (ValidationFailedException vfe) {
            assertEquals("E10083", vfe.getErrorCollection().get(0).getErrorCode());
            assertEquals("[template2, connections ]", Arrays.toString(vfe.getErrorCollection().get(0).getPlaceHolders()));
        }
    }

    @Test
    public void processTemplateConnections_nullConnectionId()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        try {
            verifyValues("/s95/templateConnectionProcessorTests/templateConnections_nullConnectionId.json", "");
        } catch (ValidationFailedException vfe) {
            assertEquals("E10083", vfe.getErrorCollection().get(0).getErrorCode());
            assertEquals("[template2, id ]", Arrays.toString(vfe.getErrorCollection().get(0).getPlaceHolders()));
        }
    }

    @Test
    public void processTemplateConnections_nullConnectionPlaceholderId()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        try {
            verifyValues("/s95/templateConnectionProcessorTests/templateConnections_nullConnectionPlaceholderId.json",
                "");
        } catch (ValidationFailedException vfe) {
            assertEquals("E10083", vfe.getErrorCollection().get(0).getErrorCode());
            assertEquals("[template2, placeholderId ]", Arrays.toString(vfe.getErrorCollection().get(0).getPlaceHolders()));
        }
    }

    @Test
    public void processTemplateConnections_emptyConnectionId()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        try {
            verifyValues("/s95/templateConnectionProcessorTests/templateConnections_emptyConnectionId.json", "");
        } catch (ValidationFailedException vfe) {
            assertEquals("E10083", vfe.getErrorCollection().get(0).getErrorCode());
            assertEquals("[template2, id ]", Arrays.toString(vfe.getErrorCollection().get(0).getPlaceHolders()));
        }
    }

    @Test
    public void processTemplateConnections_emptyConnectionPlaceholderId()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        try {
            verifyValues("/s95/templateConnectionProcessorTests/templateConnections_emptyConnectionPlaceholderId.json",
                "");
        } catch (ValidationFailedException vfe) {
            assertEquals("E10083", vfe.getErrorCollection().get(0).getErrorCode());
            assertEquals("[template2, placeholderId ]", Arrays.toString(vfe.getErrorCollection().get(0).getPlaceHolders()));
        }
    }

    @Test
    public void processTemplateConnection_withParentEnterprise()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        try {
            // parentEntityId != null, parentEntityCcomClass == ENTERPRISE
            verifyValues("/s95/templateConnectionProcessorTests/templateConnections_withParentEnterprise.json", "");
        } catch (ValidationFailedException vfe) {
            assertEquals("E10032", vfe.getErrorCollection().get(0).getErrorCode());
            assertEquals("[ENTERPRISE, parentEntityId1]", Arrays.toString(vfe.getErrorCollection().get(0).getPlaceHolders()));
        }
    }

    @Test
    public void supportedField() {
        assertEquals("templateConnections", new TemplateConnectionProcessor().supportedField());
    }
}
