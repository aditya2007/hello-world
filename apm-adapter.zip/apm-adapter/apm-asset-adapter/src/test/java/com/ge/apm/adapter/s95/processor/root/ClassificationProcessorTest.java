/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;
import javax.xml.bind.JAXBException;

import com.fasterxml.jackson.core.JsonParser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.adapter.common.util.IEntityDispatcher;
import com.ge.apm.adapter.s95.base.BaseTest;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.common.util.IdGenerator;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class })
public class ClassificationProcessorTest extends BaseTest {

    @Mock
    private IEntityDispatcher entityDispatcher;

    @Captor
    private ArgumentCaptor<Entity> entityCaptor;

    @InjectMocks
    private ClassificationProcessor classificationProcessor;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        mockIdGenerator();
        RequestContext.put(RequestContext.TENANT_UUID, "Tenant1");
    }

    @Test
    public void processEnterpriseTypeBasic() throws IOException, ValidationFailedException, JAXBException {
        JsonParser parser = getParserFor("/s95/classificationProcessorTests/enterpriseTypeBasic.json");

        classificationProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(classificationProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/classificationProcessorTests/enterpriseTypeBasic.xml");
    }

    @Test
    public void processEnterpriseTypeWithProperties() throws IOException, ValidationFailedException, JAXBException {
        JsonParser parser = getParserFor("/s95/classificationProcessorTests/enterpriseTypeWithProperties.json");

        classificationProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(classificationProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(),
            "/ccom/classificationProcessorTests/enterpriseTypeWithProperties.xml");
    }

    @Test
    public void processSiteTypeBasic() throws IOException, ValidationFailedException, JAXBException {
        JsonParser parser = getParserFor("/s95/classificationProcessorTests/siteTypeBasic.json");

        classificationProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(classificationProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/classificationProcessorTests/siteTypeBasic.xml");
    }

    @Test
    public void processSegmentTypeBasic() throws IOException, ValidationFailedException, JAXBException {
        JsonParser parser = getParserFor("/s95/classificationProcessorTests/segmentTypeBasic.json");

        classificationProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(classificationProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/classificationProcessorTests/segmentTypeBasic.xml");
    }

    @Test
    public void processAssetTypeBasic() throws IOException, ValidationFailedException, JAXBException {
        JsonParser parser = getParserFor("/s95/classificationProcessorTests/assetTypeBasic.json");

        classificationProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(classificationProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/classificationProcessorTests/assetTypeBasic.xml");
    }

    @Test
    public void processAssetTypeWithReservedProperties() throws IOException, ValidationFailedException, JAXBException {
        JsonParser parser = getParserFor("/s95/classificationProcessorTests/assetTypeWithReservedAttributes.json");

        classificationProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(classificationProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(),
            "/ccom/classificationProcessorTests/assetTypeWithReservedAttributes.xml");
    }

    @Test
    public void processAssetTypeWithInvalidReservedProperties()
        throws IOException, ValidationFailedException, JAXBException {
        JsonParser parser = getParserFor(
            "/s95/classificationProcessorTests/assetTypeWithInvalidReservedAttribute.json");

        classificationProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(classificationProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(),
            "/ccom/classificationProcessorTests/assetTypeWithInvalidReservedAttribute.xml");
    }

    @Test(expected = Exception.class)
    public void processUnknownClass() throws IOException, ValidationFailedException {
        JsonParser parser = getParserFor("/s95/classificationProcessorTests/unknownClass.json");

        classificationProcessor.process(parser);
    }

    @Test(expected = ValidationFailedException.class)
    public void processInvalidClass() throws IOException, ValidationFailedException {
        JsonParser parser = getParserFor("/s95/classificationProcessorTests/invalidClass.json");

        classificationProcessor.process(parser);
    }
}
