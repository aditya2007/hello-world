/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.bind.JAXBException;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.ccom.base.BaseTransformerTest;
import com.ge.apm.asset.model.Base;
import com.ge.apm.asset.model.ReservedAttributeConfig;
import com.ge.apm.asset.model.Template;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.custom.PlaceholderAssetTypeAssociation;
import com.ge.apm.ccom.model.custom.PlaceholderTagTypeAssociation;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.startsWith;
import static org.mockito.Mockito.doAnswer;

/**
 * Unit test for {@link TemplateTransformer}.
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BaseTransformerTest.Configuration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class TemplateTransformerTest extends BaseTypedTransformerTest<Template> {

    @Override
    protected String getPrefix() {
        return Prefixes.Templates;
    }

    @Override
    protected Class<Template> getObjectClass() {
        return Template.class;
    }

    @Override
    protected String getTypePrefix() {
        return null;
    }

    @Override
    protected void setupLookupForCreate() {

    }

    @Override
    protected void setupLookupForUpdate() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id2, Uuid2);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupGetTemplate(Uuid2, Prefixes.Templates, "TEMPLATE");
    }

    @Override
    protected void setupLookupForUpdateOne() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
    }

    @Test
    @Override
    public void create() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/create.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        setupPlaceholderAssociationsLookup(entities.get(0));
        setupPlaceholderTagAssociationsLookup(entities.get(0));

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test(expected = ValidationFailedException.class)
    public void create_withEmptyName() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/create_withEmptyName.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        setupPlaceholderAssociationsLookup(entities.get(0));
        setupPlaceholderTagAssociationsLookup(entities.get(0));

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test(expected = ValidationFailedException.class)
    public void create_withEmptyID() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/create_withEmptyID.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        setupPlaceholderAssociationsLookup(entities.get(0));
        setupPlaceholderTagAssociationsLookup(entities.get(0));

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test(expected = ValidationFailedException.class)
    public void create_withEmptyPlaceholderID() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/create_withEmptyPlaceholderID.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        setupPlaceholderAssociationsLookup(entities.get(0));
        setupPlaceholderTagAssociationsLookup(entities.get(0));
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test(expected = ValidationFailedException.class)
    public void create_withEmptyPlaceholderName() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/create_withEmptyPlaceholderName.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        setupPlaceholderAssociationsLookup(entities.get(0));
        setupPlaceholderTagAssociationsLookup(entities.get(0));

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test(expected = ValidationFailedException.class)
    public void createMissingAssociations() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/createMissingAssociations.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        setupPlaceholderAssociationsLookup(entities.get(0));
        setupPlaceholderTagAssociationsLookup(entities.get(0));

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test(expected = ValidationFailedException.class)
    public void createTemplateName() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/createMissingTemplateName.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        setupPlaceholderAssociationsLookup(entities.get(0));
        setupPlaceholderTagAssociationsLookup(entities.get(0));

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test(expected = ValidationFailedException.class)
    public void createInvalidAssociationType() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/createInvalidAssociationType.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        setupPlaceholderAssociationsLookup(entities.get(0));
        setupPlaceholderTagAssociationsLookup(entities.get(0));
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test(expected = ValidationFailedException.class)
    public void createInvalidAssociationTypeNullIdNullCcom() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/createInvalidAssociationType.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        setupPlaceholderAssociationsLookup(entities.get(0));
        setupPlaceholderTagAssociationsLookup(entities.get(0));
        ((com.ge.apm.ccom.model.custom.Template)  entities.get(0)).getPlaceholderMeshes().get(0).getConnection().get
            (0).getFrom().getAssetTypeAssociations().get(0).setAssociatedEntityCcomClass(null);
        ((com.ge.apm.ccom.model.custom.Template)  entities.get(0)).getPlaceholderMeshes().get(0).getConnection().get
            (0).getFrom().getAssetTypeAssociations().get(0).getAssociatedEntityId().setValue(null);
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test(expected = ValidationFailedException.class)
    public void createInvalidTagAssociationType() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/createInvalidTagAssociationType.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        setupPlaceholderAssociationsLookup(entities.get(0));
        setupPlaceholderTagAssociationsLookup(entities.get(0));
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test(expected = ValidationFailedException.class)
    public void createInvalidTagAssociationTypeNullIdNullCcom() throws IOException, JAXBException,
        ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/createInvalidTagAssociationType.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        setupPlaceholderAssociationsLookup(entities.get(0));
        setupPlaceholderTagAssociationsLookup(entities.get(0));
        ((com.ge.apm.ccom.model.custom.Template)  entities.get(0)).getPlaceholderMeshes().get(0).getConnection().get
            (0).getFrom().getTagTypeAssociations().get(0).setAssociatedEntityCcomClass(null);
        ((com.ge.apm.ccom.model.custom.Template)  entities.get(0)).getPlaceholderMeshes().get(0).getConnection().get
            (0).getFrom().getTagTypeAssociations().get(0).getAssociatedEntityId().setValue(null);
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Ignore("TODO: BROKEN DUE TO CODE REFACTORING IN REARCHITECTURE")
    @Test(expected = ServiceException.class)
    @Override
    public void createThrowExceptionOnIdMissing() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/create.xml");
        entities.get(0).setGUID(null);
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Ignore("TODO: BROKEN DUE TO CODE REFACTORING IN REARCHITECTURE")
    @Test(expected = ServiceException.class)
    public void createThrowExceptionOnAssociationUriMissing()
        throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/create.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Ignore("TODO: BROKEN DUE TO CODE REFACTORING IN REARCHITECTURE")
    @Test(expected = ServiceException.class)
    public void createThrowExceptionOnTagAssociationUriMissing()
        throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/create.xml");
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Uuid3);
        setupGetTemplate(Uuid1, Prefixes.Templates, "TEMPLATE");
        setupTemplateReservedAttributesLookUp(entities.get(0));
        setupPlaceholderAssociationsLookup(entities.get(0));
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Ignore("TODO: BROKEN DUE TO CODE REFACTORING IN REARCHITECTURE")
    @Test(expected = ServiceException.class)
    @Override
    public void createThrowException() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom/templates/create.xml");
        final String sourceKey = entities.get(0).getGUID().getValue();
        Mockito.doThrow(new ServiceException(HttpStatus.UNPROCESSABLE_ENTITY.toString())).
            when(configuration.restTemplate()).exchange(
            startsWith(getAssetUrl() + getTypePrefix() + "/bySourceKey?sourceKey=" + sourceKey), eq(HttpMethod.GET),
            any(HttpEntity.class), eq(Base.class));
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    @Test(expected = ValidationFailedException.class)
    public void createNullSourceKey() throws Exception {
        List<Entity> entities = fetchEntities("/ccom/templates/create.xml");
        entities.get(0).setGUID(null);
        setupLookupForCreate();
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    private void setupGetTemplate(String uuid, String prefix, String category) {
        doAnswer(invocation -> {
            Template object = new Template();
            object.setSourceKey(uuid);
            return new ResponseEntity<>(object, HttpStatus.OK);
        }).when(configuration.restTemplate()).exchange(startsWith(getAssetUrl() + prefix + "/" + uuid),
            eq(HttpMethod.GET), any(HttpEntity.class), eq(Template.class));
    }

    private ReservedAttributeConfig buildReservedAttributeConfig(String attributeName,
        List<com.ge.apm.ccom.model.core.Attribute> attributes) {
        for (com.ge.apm.ccom.model.core.Attribute attribute : attributes) {
            if (attribute.getName().getValue().contains(attributeName)) {
                ReservedAttributeConfig attributeConfig = new ReservedAttributeConfig();
                attributeConfig.setName(attributeName);
                attributeConfig.setType(attribute.getValueContent().getApmType().getType().getValue());
                attributeConfig.setArrayType(ReservedAttributeConfig.ArrayTypeEnum.NA.name());
                attributeConfig.setOverwrite(true);

                List<Object> possibleValues = new ArrayList<>();
                possibleValues.add(attribute.getValueContent().getApmType().getAttributeValue().getValue());
                attributeConfig.setPossibleValues(possibleValues);
                return attributeConfig;
            }
        }
        return null;
    }

    private void setupTemplateReservedAttributesLookUp(Entity entity) {
        com.ge.apm.ccom.model.custom.Template template = (com.ge.apm.ccom.model.custom.Template) entity;

        Map<String, ReservedAttributeConfig> reservedAttributeConfigMap = new HashMap<>();
        reservedAttributeConfigMap.put("status", buildReservedAttributeConfig("status", template.getAttribute()));
        reservedAttributeConfigMap.put("state", buildReservedAttributeConfig("state", template.getAttribute()));

        ResponseEntity response = new ResponseEntity<>(reservedAttributeConfigMap, HttpStatus.OK);
        Mockito.when(configuration.restTemplate()
            .exchange(startsWith(getAssetUrl() + Prefixes.Templates + "/reservedAttributes"), eq(HttpMethod.GET),
                any(HttpEntity.class), any(ParameterizedTypeReference.class))).thenReturn(response);
    }

    private void setupPlaceholderAssociationsLookup(Entity entity) {
        com.ge.apm.ccom.model.custom.Template template = (com.ge.apm.ccom.model.custom.Template) entity;

        if (template.getPlaceholderMeshes().isEmpty()) {
            return;
        }

        List<PlaceholderAssetTypeAssociation> associationList = new ArrayList<>();
        List<com.ge.apm.ccom.model.custom.PlaceholderConnection> connections = template.getPlaceholderMeshes().get(0)
            .getConnection();
        getAllPlaceholderAssociations(connections, associationList);

        for (PlaceholderAssetTypeAssociation association : associationList) {
            String prefix = Prefixes.getPrefixByCategory(association.getAssociatedEntityCcomClass().name());
            String uuid = association.getAssociatedEntityId().getValue();
            String sourceKey = association.getAssociatedEntityId().getValue();
            doAnswer(invocation -> {
                Base object = new Base();
                object.setUri(Prefixes.uri(prefix, uuid));
                return new ResponseEntity<>(object, HttpStatus.OK);
            }).when(configuration.restTemplate()).exchange(
                startsWith(getAssetUrl() + prefix + "/bySourceKey?sourceKey=" + sourceKey), eq(HttpMethod.GET),
                any(HttpEntity.class), eq(Base.class));
        }
    }

    private void setupPlaceholderTagAssociationsLookup(Entity entity) {
        com.ge.apm.ccom.model.custom.Template template = (com.ge.apm.ccom.model.custom.Template) entity;

        if (template.getPlaceholderMeshes().isEmpty()) {
            return;
        }

        List<PlaceholderTagTypeAssociation> tagAssociations = new ArrayList<>();
        List<com.ge.apm.ccom.model.custom.PlaceholderConnection> connections = template.getPlaceholderMeshes().get(0)
            .getConnection();
        getAllPlaceholderTagAssociations(connections, tagAssociations);

        for (PlaceholderTagTypeAssociation association : tagAssociations) {
            String prefix = Prefixes.getPrefixByCategory(association.getAssociatedEntityCcomClass().name());
            String uuid = association.getAssociatedEntityId().getValue();
            String sourceKey = association.getAssociatedEntityId().getValue();
            doAnswer(invocation -> {
                Base object = new Base();
                object.setUri(Prefixes.uri(prefix, uuid));
                return new ResponseEntity<>(object, HttpStatus.OK);
            }).when(configuration.restTemplate()).exchange(
                startsWith(getAssetUrl() + prefix + "/bySourceKey?sourceKey=" + sourceKey), eq(HttpMethod.GET),
                any(HttpEntity.class), eq(Base.class));
        }
    }

    private void getAllPlaceholderAssociations(List<com.ge.apm.ccom.model.custom.PlaceholderConnection> connections,
        List<PlaceholderAssetTypeAssociation> associations) {
        for (com.ge.apm.ccom.model.custom.PlaceholderConnection connection : connections) {
            associations.addAll(connection.getFrom().getAssetTypeAssociations());
            if (connection.getNetwork() != null) {
                getAllPlaceholderAssociations(connection.getNetwork().getConnection(), associations);
            }
        }
    }

    private void getAllPlaceholderTagAssociations(List<com.ge.apm.ccom.model.custom.PlaceholderConnection> connections,
        List<PlaceholderTagTypeAssociation> associations) {
        for (com.ge.apm.ccom.model.custom.PlaceholderConnection connection : connections) {
            associations.addAll(connection.getFrom().getTagTypeAssociations());
            if (connection.getNetwork() != null) {
                getAllPlaceholderTagAssociations(connection.getNetwork().getConnection(), associations);
            }
        }
    }
}