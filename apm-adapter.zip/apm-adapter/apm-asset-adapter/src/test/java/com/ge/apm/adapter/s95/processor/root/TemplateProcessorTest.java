/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;
import javax.xml.bind.JAXBException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.MappingJsonFactory;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.adapter.common.util.IEntityDispatcher;
import com.ge.apm.adapter.s95.base.BaseTest;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.common.util.IdGenerator;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.verify;

/**
 * Created by 502664102 on 10/25/16.
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class })
public class TemplateProcessorTest extends BaseTest {

    JsonParser jsonParser = null;

    @Mock
    private IEntityDispatcher entityDispatcher;

    @Captor
    private ArgumentCaptor<Entity> entityCaptor;

    @InjectMocks
    private TemplateProcessor templateProcessor;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        mockIdGenerator();
        RequestContext.put(RequestContext.TENANT_UUID, "Tenant1");
    }

    private JsonParser getTemplateParser(String filePath) {
        JsonParser jsonParser = null;
        try {
            jsonParser = new MappingJsonFactory().createParser(BaseTest.class.getResourceAsStream(filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return jsonParser;
    }

    @Test
    public void processBasicTemplate()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getTemplateParser("/s95/templateProcessorTests/basicTemplate.json");
        templateProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(templateProcessor.supportedField()));
        verifyEntity(entityCaptor.getAllValues(), "/ccom/templateProcessorTests/basicTemplate.xml");
    }

    @Test
    public void processTemplateWithPlaceholders()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {

        JsonParser parser = getTemplateParser("/s95/templateProcessorTests/TemplateWithPlaceholder.json");
        templateProcessor.process(parser);

        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(templateProcessor.supportedField()));
        verifyEntity(entityCaptor.getAllValues(), "/ccom/templateProcessorTests/templateWithPlaceholder.xml");
    }

    @Test
    public void processTemplateWithComplexPlaceholders()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {

        JsonParser parser = getTemplateParser(
            "/s95/templateProcessorTests/TemplateWithPlaceholderChildPlaceholder.json");
        templateProcessor.process(parser);

        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(templateProcessor.supportedField()));
        verifyEntity(entityCaptor.getAllValues(),
            "/ccom/templateProcessorTests/TemplateWithPlaceholderChildPlaceholder.xml");
    }

    @Test
    public void processTemplateWithoutRootPlaceholder()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getTemplateParser("/s95/templateProcessorTests/TemplateWithoutRootPlaceholder.json");
        templateProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(templateProcessor.supportedField()));
        verifyEntity(entityCaptor.getAllValues(), "/ccom/templateProcessorTests/TemplateWithoutRootPlaceholder.xml");
    }

    @Test
    public void processTemplateWithNullRootPlaceholder()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getTemplateParser("/s95/templateProcessorTests/TemplateWithNullRootPlaceholder.json");
        templateProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(templateProcessor.supportedField()));
        verifyEntity(entityCaptor.getAllValues(), "/ccom/templateProcessorTests/TemplateWithoutRootPlaceholder.xml");
    }

    @Test
    public void supportedField() {
        Assert.assertEquals("templates", new TemplateProcessor().supportedField());
    }
}
