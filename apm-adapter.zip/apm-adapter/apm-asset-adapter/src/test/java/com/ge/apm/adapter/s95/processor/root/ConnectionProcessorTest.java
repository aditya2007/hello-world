/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;
import javax.xml.bind.JAXBException;

import com.fasterxml.jackson.core.JsonParser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.adapter.common.util.IEntityDispatcher;
import com.ge.apm.adapter.s95.base.BaseTest;
import com.ge.apm.adapter.s95.processor.connection.AssetConnectionProcessor;
import com.ge.apm.adapter.s95.processor.connection.EnterpriseConnectionProcessor;
import com.ge.apm.adapter.s95.processor.connection.SegmentConnectionProcessor;
import com.ge.apm.adapter.s95.processor.connection.SiteConnectionProcessor;
import com.ge.apm.adapter.s95.util.ReflectionUtils;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.common.util.IdGenerator;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class })
@SuppressWarnings("PMD.TooManyMethods")
public class ConnectionProcessorTest extends BaseTest {

    @Mock
    private IEntityDispatcher entityDispatcher;

    @Captor
    private ArgumentCaptor<Entity> entityCaptor;

    @InjectMocks
    private ConnectionProcessor connectionProcessor;

    @InjectMocks
    private EnterpriseConnectionProcessor enterpriseConnectionProcessor;

    @InjectMocks
    private SiteConnectionProcessor siteConnectionProcessor;

    @InjectMocks
    private SegmentConnectionProcessor segmentConnectionProcessor;

    @InjectMocks
    private AssetConnectionProcessor assetConnectionProcessor;

    @Before
    public void setup() throws IllegalAccessException {
        MockitoAnnotations.initMocks(this);
        mockIdGenerator();
        RequestContext.put(RequestContext.TENANT_UUID, "Tenant1");

        ReflectionUtils.setField(ConnectionProcessor.class, connectionProcessor, "enterpriseConnectionProcessor",
            enterpriseConnectionProcessor);
        ReflectionUtils.setField(ConnectionProcessor.class, connectionProcessor, "siteConnectionProcessor",
            siteConnectionProcessor);
        ReflectionUtils.setField(ConnectionProcessor.class, connectionProcessor, "segmentConnectionProcessor",
            segmentConnectionProcessor);
        ReflectionUtils.setField(ConnectionProcessor.class, connectionProcessor, "assetConnectionProcessor",
            assetConnectionProcessor);
        connectionProcessor.afterPropertiesSet();
    }

    @Test
    public void processSiteParentConnections()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/siteParentConnections.json");

        connectionProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(connectionProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/connectionProcessorTests/siteParentConnections.xml");
    }

    @Test
    public void processSiteConnections()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/siteConnections.json");

        connectionProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(connectionProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/connectionProcessorTests/siteConnections.xml");
    }

    @Test
    public void processSegmentParentConnections()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/segmentParentConnections.json");

        connectionProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(connectionProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/connectionProcessorTests/segmentParentConnections.xml");
    }

    @Test
    public void processSegmentConnections()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/segmentConnections.json");

        connectionProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(connectionProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/connectionProcessorTests/segmentConnections.xml");
    }

    @Test
    public void processAssetParentConnections()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/assetParentConnections.json");

        connectionProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(connectionProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/connectionProcessorTests/assetParentConnections.xml");
    }

    @Test
    public void processAssetConnections()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/assetConnections.json");

        connectionProcessor.process(parser);
        verify(entityDispatcher, times(2)).sendEntity(entityCaptor.capture(), eq(connectionProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/connectionProcessorTests/assetConnections.xml");
    }

    @Test(expected = IllegalStateException.class)
    public void processConnectionTypeInvalid()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/connectionTypeInvalid.json");

        connectionProcessor.process(parser);
    }

    @Test(expected = ValidationFailedException.class)
    public void processSiteParentConnectionInvalid()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/siteParentConnectionInvalid.json");

        connectionProcessor.process(parser);
    }

    @Test(expected = IllegalStateException.class)
    public void processSiteConnectionInvalid()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/siteConnectionInvalid.json");

        connectionProcessor.process(parser);
    }

    @Test(expected = ValidationFailedException.class)
    public void processSegmentParentConnectionInvalid()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/segmentParentConnectionInvalid.json");

        connectionProcessor.process(parser);
    }

    @Test(expected = IllegalStateException.class)
    public void processSegmentConnectionInvalid()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/segmentConnectionInvalid.json");

        connectionProcessor.process(parser);
    }

    @Test(expected = ValidationFailedException.class)
    public void processAssetParentConnectionInvalid()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/assetParentConnectionInvalid.json");

        connectionProcessor.process(parser);
    }

    @Test(expected = IllegalStateException.class)
    public void processAssetConnectionInvalid()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/connectionProcessorTests/assetConnectionInvalid.json");

        connectionProcessor.process(parser);
    }
}
