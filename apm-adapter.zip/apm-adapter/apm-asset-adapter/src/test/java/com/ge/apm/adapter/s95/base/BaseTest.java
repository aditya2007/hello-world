/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.base;

import java.io.IOException;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.MappingJsonFactory;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;

import com.ge.apm.ccom.model.CCOMData;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.common.util.IdGenerator;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

public class BaseTest {

    private static Unmarshaller unmarshaller;

    private static Marshaller marshaller;

    static {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance("com.ge.apm.ccom.model:com.ge.apm.ccom.model.custom");
            unmarshaller = jaxbContext.createUnmarshaller();
            marshaller = jaxbContext.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    protected void mockIdGenerator() {
        PowerMockito.mockStatic(IdGenerator.class);
        when(IdGenerator.generateAsString()).then(new Answer<Object>() {
            private int count = 0;

            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                return "bb571726-c1a3-4610-99de-435ab7f74" + String.format("%03d", count++);
            }
        });
    }

    protected JsonParser getParserFor(String filePath) throws IOException {
        return new MappingJsonFactory().createParser(BaseTest.class.getResourceAsStream(filePath));
    }

    protected void verifyEntity(List<Entity> entities, String expectedXmlPath) throws IOException, JAXBException {
        CCOMData ccomData = new CCOMData();
        ccomData.getEntity().addAll(entities);
        marshaller.marshal(ccomData, System.out);
        Object expectedData = unmarshaller.unmarshal(BaseTest.class.getResourceAsStream(expectedXmlPath));
        assertEquals(expectedData, ccomData);
    }
}
