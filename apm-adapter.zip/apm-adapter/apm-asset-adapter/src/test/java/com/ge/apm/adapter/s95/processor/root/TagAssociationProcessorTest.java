/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import com.fasterxml.jackson.core.JsonParser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.adapter.common.util.IEntityDispatcher;
import com.ge.apm.adapter.s95.base.BaseTest;
import com.ge.apm.adapter.s95.util.ReflectionUtils;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.measurements.locations.MeasurementLocation;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.common.util.IdGenerator;
import com.ge.apm.s95.model.NextCorrelatedTag;
import com.ge.apm.s95.model.Node;
import com.ge.apm.s95.model.Tag;
import com.ge.apm.s95.model.TagAssociation;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;

/**
 * @author 212312392
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class })
public class TagAssociationProcessorTest extends BaseTest {

    @Mock
    private IEntityDispatcher entityDispatcher;

    @Captor
    private ArgumentCaptor<Entity> entityCaptor;

    @InjectMocks
    private TagAssociationProcessor tagAssociationProcessor;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        mockIdGenerator();
        RequestContext.put(RequestContext.TENANT_UUID, "Tenant1");
        tagAssociationProcessor = new TagAssociationProcessor();
    }

    /**
     * Test method for
     * {@link com.ge.apm.adapter.s95.processor.root.TagAssociationProcessor#process(com.fasterxml.jackson.core.JsonParser)}.
     */
    @Test
    public void testProcessJsonParserEnterprise() {

        try {
            JsonParser parser = Mockito.mock(JsonParser.class);
            TagAssociation ta = Mockito.mock(TagAssociation.class);
            Tag tag = new Tag();
            Tag[] tags = new Tag[1];
            tags[0] = tag;
            tag.setName("testTag");
            tag.setDescription("testdescription");
            Node node = Mockito.mock(Node.class);
            Mockito.when(parser.readValueAs(TagAssociation.class)).thenReturn(ta);
            Mockito.when(ta.getMonitoredEntity()).thenReturn(node);
            Mockito.when(ta.getTags()).thenReturn(tags);
            Mockito.when(node.getId()).thenReturn("testid");
            Mockito.when(node.getCcomClass()).thenReturn(MimosaCcomCategory.ENTERPRISE);
            IEntityDispatcher iEntityDispatcher = Mockito.mock(IEntityDispatcher.class);
            ReflectionUtils.setField(TagAssociationProcessor.class, tagAssociationProcessor, "entityDispatcher",
                iEntityDispatcher);
            tagAssociationProcessor.process(parser);
        } catch (Exception exc) {
            fail(exc.getLocalizedMessage());
        }
    }

    /**
     * Test method for
     * {@link com.ge.apm.adapter.s95.processor.root.TagAssociationProcessor#process(com.fasterxml.jackson.core.JsonParser)}.
     */
    @Test
    public void testProcessJsonParserSite() {

        try {
            JsonParser parser = Mockito.mock(JsonParser.class);
            TagAssociation ta = Mockito.mock(TagAssociation.class);
            Tag tag = new Tag();
            Tag[] tags = new Tag[1];
            tags[0] = tag;
            tag.setName("testTag");
            tag.setDescription("testdescription");
            Node node = Mockito.mock(Node.class);
            Mockito.when(parser.readValueAs(TagAssociation.class)).thenReturn(ta);
            Mockito.when(ta.getMonitoredEntity()).thenReturn(node);
            Mockito.when(ta.getTags()).thenReturn(tags);
            Mockito.when(node.getId()).thenReturn("testid");
            Mockito.when(node.getCcomClass()).thenReturn(MimosaCcomCategory.SITE);
            IEntityDispatcher iEntityDispatcher = Mockito.mock(IEntityDispatcher.class);
            ReflectionUtils.setField(TagAssociationProcessor.class, tagAssociationProcessor, "entityDispatcher",
                iEntityDispatcher);
            tagAssociationProcessor.process(parser);
        } catch (Exception exc) {
            fail(exc.getLocalizedMessage());
        }
    }

    /**
     * Test method for
     * {@link com.ge.apm.adapter.s95.processor.root.TagAssociationProcessor#process(com.fasterxml.jackson.core.JsonParser)}.
     */
    @Test
    public void testProcessJsonParserSegment() {

        try {
            JsonParser parser = Mockito.mock(JsonParser.class);
            TagAssociation ta = Mockito.mock(TagAssociation.class);
            Tag tag = new Tag();
            Tag[] tags = new Tag[1];
            tags[0] = tag;
            tag.setName("testTag");
            tag.setDescription("testdescription");
            Node node = Mockito.mock(Node.class);
            Mockito.when(parser.readValueAs(TagAssociation.class)).thenReturn(ta);
            Mockito.when(ta.getMonitoredEntity()).thenReturn(node);
            Mockito.when(ta.getTags()).thenReturn(tags);
            Mockito.when(node.getId()).thenReturn("testid");
            Mockito.when(node.getCcomClass()).thenReturn(MimosaCcomCategory.SEGMENT);
            IEntityDispatcher iEntityDispatcher = Mockito.mock(IEntityDispatcher.class);
            ReflectionUtils.setField(TagAssociationProcessor.class, tagAssociationProcessor, "entityDispatcher",
                iEntityDispatcher);
            tagAssociationProcessor.process(parser);
        } catch (Exception exc) {
            fail(exc.getLocalizedMessage());
        }
    }

    /**
     * Test method for
     * {@link com.ge.apm.adapter.s95.processor.root.TagAssociationProcessor#process(com.fasterxml.jackson.core.JsonParser)}.
     */
    @Test
    public void testProcessJsonParserAsset() {

        try {
            JsonParser parser = Mockito.mock(JsonParser.class);
            TagAssociation ta = Mockito.mock(TagAssociation.class);
            Tag tag = new Tag();
            Tag[] tags = new Tag[1];
            tags[0] = tag;
            tag.setName("testTag");
            tag.setDescription("testdescription");
            Node node = Mockito.mock(Node.class);
            Mockito.when(parser.readValueAs(TagAssociation.class)).thenReturn(ta);
            Mockito.when(ta.getMonitoredEntity()).thenReturn(node);
            Mockito.when(ta.getTags()).thenReturn(tags);
            Mockito.when(node.getId()).thenReturn("testid");
            Mockito.when(node.getCcomClass()).thenReturn(MimosaCcomCategory.ASSET);
            IEntityDispatcher iEntityDispatcher = Mockito.mock(IEntityDispatcher.class);
            ReflectionUtils.setField(TagAssociationProcessor.class, tagAssociationProcessor, "entityDispatcher",
                iEntityDispatcher);
            tagAssociationProcessor.process(parser);
        } catch (Exception exc) {
            fail(exc.getLocalizedMessage());
        }
    }

    /**
     * Test method for
     * {@link com.ge.apm.adapter.s95.processor.root.TagAssociationProcessor#process(com.fasterxml.jackson.core.JsonParser)}
     * .
     */
    @Test
    public void testProcessJsonParserAsset_withTagCorrelation() {

        try {
            JsonParser parser = Mockito.mock(JsonParser.class);
            TagAssociation ta = Mockito.mock(TagAssociation.class);
            Tag tag = new Tag();
            Tag[] tags = new Tag[1];
            tags[0] = tag;
            tag.setName("testTag");
            tag.setDescription("testdescription");
            NextCorrelatedTag nextRelatedTag = new NextCorrelatedTag();
            String id = "/assets/0ad63e94-a568-36f9-8751-f3fde87c936f";
            nextRelatedTag.setId(id);
            tag.setNextRelatedTag(nextRelatedTag);
            Node node = Mockito.mock(Node.class);
            Mockito.when(parser.readValueAs(TagAssociation.class)).thenReturn(ta);
            Mockito.when(ta.getMonitoredEntity()).thenReturn(node);
            Mockito.when(ta.getTags()).thenReturn(tags);
            Mockito.when(node.getId()).thenReturn("testid");
            Mockito.when(node.getCcomClass()).thenReturn(MimosaCcomCategory.ASSET);
            IEntityDispatcher iEntityDispatcher = Mockito.mock(IEntityDispatcher.class);
            ReflectionUtils.setField(TagAssociationProcessor.class, tagAssociationProcessor, "entityDispatcher",
                iEntityDispatcher);
            tagAssociationProcessor.process(parser);
        } catch (Exception exc) {
            fail(exc.getLocalizedMessage());
        }
    }

    /**
     * Test method for
     * {@link com.ge.apm.adapter.s95.processor.root.TagAssociationProcessor#process(com.fasterxml.jackson.core.JsonParser)}.
     */
    @Test
    public void testProcessJsonParserAsset_withTagAliases() {

        try {
            JsonParser parser = Mockito.mock(JsonParser.class);
            TagAssociation ta = Mockito.mock(TagAssociation.class);
            Tag tag = new Tag();
            Tag[] tags = new Tag[1];
            tags[0] = tag;
            String name = "testTag";
            String description = "testdescription";
            String alias1 = "tagAlias1";
            String alias2 = "tagAlias2";
            tag.setName(name);
            tag.setDescription(description);
            String[] aliases = new String[2];
            aliases[0] = alias1;
            aliases[1] = alias2;
            tag.setAliases(aliases);
            Node node = Mockito.mock(Node.class);
            Mockito.when(parser.readValueAs(TagAssociation.class)).thenReturn(ta);
            Mockito.when(ta.getMonitoredEntity()).thenReturn(node);
            Mockito.when(ta.getTags()).thenReturn(tags);
            Mockito.when(node.getId()).thenReturn("testid");
            Mockito.when(node.getCcomClass()).thenReturn(MimosaCcomCategory.ASSET);
            ReflectionUtils.setField(TagAssociationProcessor.class, tagAssociationProcessor, "entityDispatcher",
                entityDispatcher);
            tagAssociationProcessor.process(parser);
            verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(tagAssociationProcessor.supportedField()));
            MeasurementLocation tagValue = (MeasurementLocation) (entityCaptor.getValue());
            tagValue.getAttribute().stream().forEach(attribute -> {
                String attributeName = attribute.getName().getValue();
                if (!"description".equals(attributeName)) {
                    String value = attribute.getValueContent().getApmType().getAttributeValue().getValue();
                    assertTrue(value.equals(alias1) || value.equals(alias2));
                }
            });
        } catch (Exception exc) {
            fail(exc.getLocalizedMessage());
        }
    }

    /**
     * Test method for {@link com.ge.apm.adapter.s95.processor.root.TagAssociationProcessor#supportedField()}.
     */
    @Test
    public void testSupportedField() {

        assertTrue(tagAssociationProcessor.supportedField().equals("tagAssociations"));
    }
}
