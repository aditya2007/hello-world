/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.type;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.ccom.base.BaseTransformerTest;
import com.ge.apm.asset.model.SegmentType;
import com.ge.apm.asset.model.constants.Prefixes;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BaseTransformerTest.Configuration.class)
public class SegmentTypeTransformerTest extends BaseTypeTransformerTest<SegmentType> {

    @Override
    protected String getPrefix() {
        return Prefixes.SegmentTypes;
    }

    @Override
    protected Class<SegmentType> getObjectClass() {
        return SegmentType.class;
    }
}
