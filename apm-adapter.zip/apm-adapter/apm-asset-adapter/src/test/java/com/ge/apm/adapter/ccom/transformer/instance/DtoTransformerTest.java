/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.web.client.RestTemplate;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.BaseTransformer;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.Named;

import static org.mockito.Mockito.doNothing;

/**
 * Description of DtoTransformerTest
 *
 * @author Deepak 212400139
 * @version 1.0 Mar 9, 2016
 * @since 1.0
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(BaseTransformer.class)
public class DtoTransformerTest {

    public RestTemplate restTemplate;

    public DtoTransformer dt;

    @Mock
    private AssetClient assetClient;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        doNothing().when(assetClient).create(Mockito.anyString(), Mockito.any());
        dt = new DtoTransformer(assetClient);
    }

    @Test
    public void testGetPrefix() {
        Assert.assertNull(dt.getPrefix());
    }

    @Test
    public void testTransform() {
        Named n1 = new Named();
        n1.setUri("Uri1");
        n1.setSourceKey("SourceKey1");
        n1.setName("Name1");
        n1.setDescription("Description1");

        Named n2 = new MeasurementTagType();
        n2.setUri("Uri2");
        n2.setSourceKey("/tagTypes/SourceKey2");
        n2.setName("Name2");
        n2.setDescription("Description2");

        List<Named> dtoList = new ArrayList<Named>();
        dtoList.add(n1);
        dtoList.add(n2);

        dt.transform(dtoList);
        Assert.assertNotNull(dt);
    }

    @After
    public void destroy() {
        restTemplate = null;
        assetClient = null;
        dt = null;
    }
}
