/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.util;

import java.lang.reflect.Field;

public final class ReflectionUtils {

    private ReflectionUtils() {
        //Since this is a utility method, add a private constructor.
    }

    public static void setField(Class<?> clazz, Object target, String fieldName, Object value)
        throws IllegalAccessException {
        Field field = org.springframework.util.ReflectionUtils.findField(clazz, fieldName);
        org.springframework.util.ReflectionUtils.makeAccessible(field);
        field.set(target, value);
    }

    public static Object getField(Class<?> clazz, Object target, String fieldName)
        throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        Field f = clazz.getDeclaredField(fieldName); //NoSuchFieldException
        f.setAccessible(true);
        return f.get(target); //IllegalAccessException
    }
}
