/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.xml.bind.JAXBException;

import com.fasterxml.jackson.core.JsonParser;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.adapter.common.util.IEntityDispatcher;
import com.ge.apm.adapter.s95.base.BaseTest;
import com.ge.apm.adapter.s95.processor.instance.AssetInstanceProcessor;
import com.ge.apm.adapter.s95.processor.instance.EnterpriseInstanceProcessor;
import com.ge.apm.adapter.s95.processor.instance.SegmentInstanceProcessor;
import com.ge.apm.adapter.s95.processor.instance.SiteInstanceProcessor;
import com.ge.apm.adapter.s95.util.ReflectionUtils;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.common.util.IdGenerator;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.LocationContext;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ IdGenerator.class })
@SuppressWarnings("PMD.TooManyMethods")
public class InstanceProcessorTest extends BaseTest {

    @Mock
    private IEntityDispatcher entityDispatcher;

    @Captor
    private ArgumentCaptor<Entity> entityCaptor;

    @InjectMocks
    private InstanceProcessor instanceProcessor;

    @InjectMocks
    private EnterpriseInstanceProcessor enterpriseInstanceProcessor;

    @InjectMocks
    private SiteInstanceProcessor siteInstanceProcessor;

    @InjectMocks
    private SegmentInstanceProcessor segmentInstanceProcessor;

    @InjectMocks
    private AssetInstanceProcessor assetInstanceProcessor;

    @Before
    public void setup() throws IllegalAccessException {
        MockitoAnnotations.initMocks(this);
        mockIdGenerator();
        RequestContext.put(RequestContext.TENANT_UUID, "Tenant1");

        ReflectionUtils.setField(InstanceProcessor.class, instanceProcessor, "enterpriseInstanceProcessor",
            enterpriseInstanceProcessor);
        ReflectionUtils.setField(InstanceProcessor.class, instanceProcessor, "siteInstanceProcessor",
            siteInstanceProcessor);
        ReflectionUtils.setField(InstanceProcessor.class, instanceProcessor, "segmentInstanceProcessor",
            segmentInstanceProcessor);
        ReflectionUtils.setField(InstanceProcessor.class, instanceProcessor, "assetInstanceProcessor",
            assetInstanceProcessor);
        instanceProcessor.afterPropertiesSet();
    }

    @Test
    public void processEnterpriseBasic()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/enterpriseBasic.json");

        instanceProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(instanceProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/instanceProcessorTests/enterpriseBasic.xml");
    }

    @Test
    public void processEnterpriseWithProperties()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/enterpriseWithProperties.json");

        instanceProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(instanceProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/instanceProcessorTests/enterpriseWithProperties.xml");
    }

    @Test
    public void processSiteBasic()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/siteBasic.json");

        instanceProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(instanceProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/instanceProcessorTests/siteBasic.xml");
    }

    @Test
    public void processSegmentBasic()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/segmentBasic.json");

        instanceProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(instanceProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/instanceProcessorTests/segmentBasic.xml");
    }

    @Test
    public void processAssetBasic()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/assetBasic.json");

        instanceProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(instanceProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/instanceProcessorTests/assetBasic.xml");
    }

    @Test
    public void processAssetWithReservedAttributes()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/assetWithReservedAttributes.json");

        instanceProcessor.process(parser);
        verify(entityDispatcher).sendEntity(entityCaptor.capture(), eq(instanceProcessor.supportedField()));

        verifyEntity(entityCaptor.getAllValues(), "/ccom/instanceProcessorTests/assetWithReservedAttributes.xml");
    }

    @Test(expected = ValidationFailedException.class)
    public void processUnknownClass()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/unknownClass.json");

        instanceProcessor.process(parser);
    }

    @Test(expected = ValidationFailedException.class)
    public void processInvalidClass()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/invalidClass.json");

        instanceProcessor.process(parser);
    }

    @Test(expected = ValidationFailedException.class)
    public void invalidAssetLocation()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/invalidAssetLocation.json");

        try {
            instanceProcessor.process(parser);
        } catch (ValidationFailedException e) {
            List<Error> errors = e.getErrorCollection();
            Assert.assertEquals(11, errors.size());
            Set<String> errorCodes = new HashSet<>();
            for (Error each : errors) {
                Assert.assertEquals(Error.ErrorType.ERROR, each.getErrorType());
                errorCodes.add(each.getErrorCode());
            }

            for (String code : new String[] { ErrorConstants.GEO_POINT_ORDER_INVALID,
                ErrorConstants.GEO_POINT_GPS_VALUE_MISSING, ErrorConstants.GEO_POINT_GPS_VALUE_INVALID_RANGE,
                ErrorConstants.GEO_POINT_GPS_INVALID_PRECISION, ErrorConstants.GEO_TIMEZONE_INVALID }) {
                Assert.assertTrue(errorCodes.contains(code));
            }

            throw e;
        }
    }

    @Test(expected = ValidationFailedException.class)
    public void invalidAssetLocation_order_format()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/invalidAssetLocation-order-format.json");

        try {
            instanceProcessor.process(parser);
        } catch (ValidationFailedException e) {
            List<Error> errors = e.getErrorCollection();
            Assert.assertEquals(1, errors.size());
            Error error = errors.get(0);
            Assert.assertEquals(ErrorConstants.GEO_POINT_ORDER_INVALID, error.getErrorCode());
            Assert.assertEquals(Error.ErrorType.ERROR, error.getErrorType());
            Assert.assertEquals("abc", error.getPlaceHolders()[1]);
            Assert.assertEquals("0", error.getPlaceHolders()[2]);

            throw e;
        }
    }

    @Test(expected = ValidationFailedException.class)
    public void invalidAssetLocation_lat_format()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/invalidAssetLocation-lat-format.json");

        try {
            instanceProcessor.process(parser);
        } catch (ValidationFailedException e) {
            List<Error> errors = e.getErrorCollection();
            Assert.assertEquals(1, errors.size());
            Error error = errors.get(0);
            Assert.assertEquals(ErrorConstants.GEO_POINT_GPS_VALUE_INVALID_RANGE, error.getErrorCode());
            Assert.assertEquals(Error.ErrorType.ERROR, error.getErrorType());
            Assert.assertEquals(LocationContext.LATITUDE, error.getPlaceHolders()[1]);
            Assert.assertEquals("abc", error.getPlaceHolders()[2]);
            Assert.assertEquals("0", error.getPlaceHolders()[3]);
            Assert.assertEquals("-90.0", error.getResolutionPlaceHolders()[0]);
            Assert.assertEquals("90.0", error.getResolutionPlaceHolders()[1]);

            throw e;
        }
    }

    @Test(expected = ValidationFailedException.class)
    public void invalidAssetLocation_long_format()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/invalidAssetLocation-long-format.json");

        try {
            instanceProcessor.process(parser);
        } catch (ValidationFailedException e) {
            List<Error> errors = e.getErrorCollection();
            Assert.assertEquals(1, errors.size());
            Error error = errors.get(0);
            Assert.assertEquals(ErrorConstants.GEO_POINT_GPS_VALUE_INVALID_RANGE, error.getErrorCode());
            Assert.assertEquals(Error.ErrorType.ERROR, error.getErrorType());
            Assert.assertEquals(LocationContext.LONGITUDE, error.getPlaceHolders()[1]);
            Assert.assertEquals("abc", error.getPlaceHolders()[2]);
            Assert.assertEquals("0", error.getPlaceHolders()[3]);
            Assert.assertEquals("-180.0", error.getResolutionPlaceHolders()[0]);
            Assert.assertEquals("180.0", error.getResolutionPlaceHolders()[1]);

            throw e;
        }
    }

    @Test(expected = ValidationFailedException.class)
    public void invalidAssetLocation_alt_format()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        JsonParser parser = getParserFor("/s95/instanceProcessorTests/invalidAssetLocation-alt-format.json");

        try {
            instanceProcessor.process(parser);
        } catch (ValidationFailedException e) {
            List<Error> errors = e.getErrorCollection();
            Assert.assertEquals(1, errors.size());
            Error error = errors.get(0);
            Assert.assertEquals(ErrorConstants.GEO_POINT_ALTITUDE_NOT_NUMERIC, error.getErrorCode());
            Assert.assertEquals(Error.ErrorType.ERROR, error.getErrorType());
            Assert.assertEquals("abc", error.getPlaceHolders()[1]);
            Assert.assertEquals("0", error.getPlaceHolders()[2]);

            throw e;
        }
    }
}
