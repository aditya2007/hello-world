/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance.measurement.location;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.xml.bind.JAXBException;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.ccom.base.BaseTransformerTest;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.measurements.locations.MeasurementLocation;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BaseTransformerTest.Configuration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class MeasurementLocationTransformerTest extends BaseTransformerTest<MeasurementTag> {

    @Override
    protected String getPrefix() {
        return Prefixes.MeasurementTags;
    }

    @Override
    protected Class<MeasurementTag> getObjectClass() {
        return MeasurementTag.class;
    }

    @Test
    public void createForSite() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/forSite.xml");

        MeasurementTag[] expectedTags = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/forSite.json");
        setupPOSTFor(Prefixes.uri(Prefixes.Sites, Id3) + "/tags", expectedTags, "Ok", String.class);
        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    /*  @Test
      public void createForSiteWithUom() throws Exception {
          List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/forSiteWithUom.xml");

          setupLookupObjectUriFor(Id1, Prefixes.MeasurementTagTypes, Uuid1);
          setupLookupObjectUriFor(Id2, Prefixes.MeasurementTagTypes, Uuid2);
          setupLookupObjectUriFor(Id3, Prefixes.Sites, Uuid3);

          Map<String, String> nameTypeMap = new LinkedHashMap<>();
          nameTypeMap.put("uom" , "UnitOfMeasure");
          nameTypeMap.put("status", "KeyValue");
          DateTime dateTime = new DateTime();
          dateTime = dateTime.minusHours(48);
          Whitebox.setInternalState(EntityTransformerFactory.class,
                  "lastModifiedReserverAttributeTagAssociationConfig", dateTime);
          Field field = EntityTransformerFactory.class.getDeclaredField("reservedAttributeConfigCache");

          Method method = Class.forName("com.google.common.cache.Cache").getDeclaredMethod("getIfPresent", Object
                  .class);
          method.setAccessible(true);
          String fieldName = field.getName();

          method.invoke(String.class,null);

          MeasurementTag[] expectedTags =
                  readObjectsFromResourceFile("/assetIn" + getPrefix() + "/forSiteWithUom.json");
          setupPOSTFor(Prefixes.uri(Prefixes.Sites, Uuid3) + "/tags", expectedTags,
                  "Ok", String.class);

          entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid");


          verify(configuration.restTemplate()).postForObject(
                  eq(getAssetUrl() + Prefixes.uri(Prefixes.Sites, Uuid3) + "/tags"), any(HttpEntity.class),
                  eq(String.class));
      }
 */
    @Test
    public void createForSegment() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/forSegment.xml");

        MeasurementTag[] expectedTags = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/forSegment.json");
        setupPOSTFor(Prefixes.uri(Prefixes.Segments, Id3) + "/tags", expectedTags, "Ok", String.class);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);

        verifyPOSTCalls(Prefixes.uri(Prefixes.Segments, Id3) + "/tags");
    }

    @Test(expected = ValidationFailedException.class)
    public void createForSegment_MissingClassification() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/forSegment.xml");
        ((MeasurementLocation) entities.get(0)).getType().setGUID(null);
        MeasurementTag[] expectedTags = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/forSegment.json");
        expectedTags = Arrays.copyOfRange(expectedTags, 1, expectedTags.length);
        setupPOSTFor(Prefixes.uri(Prefixes.Segments, Id3) + "/tags", expectedTags, "Ok", String.class);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);

        verifyPOSTCalls(Prefixes.uri(Prefixes.Segments, Id3) + "/tags");
    }

    @Test
    public void createForSegment_MissingName() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/forSegment.xml");
        ((MeasurementLocation) entities.get(0)).setName(null);
        MeasurementTag[] expectedTags = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/forSegment.json");
        expectedTags[0].setName(null);
        setupPOSTFor(Prefixes.uri(Prefixes.Segments, Id3) + "/tags", expectedTags, "Ok", String.class);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);
    }

    /*@Test
    public void createForSegmentWithUom() throws Exception {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/forSegmentWithUom.xml");

        setupLookupObjectUriFor(Id1, Prefixes.MeasurementTagTypes, Uuid1);
        setupLookupObjectUriFor(Id2, Prefixes.MeasurementTagTypes, Uuid2);
        setupLookupObjectUriFor(Id3, Prefixes.Segments, Uuid3);
        Map<String, String> nameTypeMap = new LinkedHashMap<>();
        nameTypeMap.put("uom" , "UnitOfMeasure");
        DateTime dateTime = new DateTime();
        dateTime = dateTime.minusHours(48);
        Whitebox.setInternalState(EntityTransformerFactory.class,
        "lastModifiedReserverAttributeTagAssociationConfig", dateTime);

        setupReservedAttributeConfig(getPrefix(), nameTypeMap);

        MeasurementTag[] expectedTags =
                readObjectsFromResourceFile("/assetIn" + getPrefix() + "/forSegmentWithUom.json");
        setupPOSTFor(Prefixes.uri(Prefixes.Segments, Uuid3) + "/tags",
                expectedTags, "Ok", String.class);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid");

        verify(configuration.restTemplate())
                .postForObject(eq(getAssetUrl() + Prefixes.uri(Prefixes.Segments, Uuid3) + "/tags"),
                        any(HttpEntity.class), eq(String.class));
    }
*/

    @Ignore("TODO: BROKEN DUE TO CODE REFACTORING IN REARCHITECTURE")
    @Test
    public void createForAsset() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/forAsset.xml");

        Map<String, String> nameTypeMap = new LinkedHashMap<>();
        nameTypeMap.put("status", "KeyValue");

        setupReservedAttributeConfig(getPrefix(), nameTypeMap);

        MeasurementTag[] expectedTags1 = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/forAsset1.json");
        setupPOSTFor(Prefixes.uri(Prefixes.Assets, Id3) + "/tags", expectedTags1, "Ok", String.class);

        MeasurementTag[] expectedTags2 = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/forAsset2.json");
        setupPOSTFor(Prefixes.uri(Prefixes.Assets, Id4) + "/tags", expectedTags2, "Ok", String.class);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);

        verifyPOSTCalls(Prefixes.uri(Prefixes.Assets, Id3) + "/tags");
        verifyPOSTCalls(Prefixes.uri(Prefixes.Assets, Id4) + "/tags");
    }

    /*@Test
    public void createForAssetWithUom() throws Exception {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/forAssetWithUom.xml");

        setupLookupObjectUriFor(Id1, Prefixes.MeasurementTagTypes, Uuid1);
        setupLookupObjectUriFor(Id2, Prefixes.MeasurementTagTypes, Uuid2);
        setupLookupObjectUriFor(Id3, Prefixes.Assets, Uuid3);
        setupLookupObjectUriFor(Id4, Prefixes.Assets, Uuid4);

        Map<String, String> nameTypeMap = new LinkedHashMap<>();
        nameTypeMap.put("uom" , "UnitOfMeasure");
        DateTime dateTime = new DateTime();
        dateTime = dateTime.minusHours(48);
        Whitebox.setInternalState(EntityTransformerFactory.class,
        "lastModifiedReserverAttributeTagAssociationConfig", dateTime);

        setupReservedAttributeConfig(getPrefix(), nameTypeMap);

        MeasurementTag[] expectedTags1 =
                readObjectsFromResourceFile("/assetIn" + getPrefix() + "/forAsset1WithUom.json");
        setupPOSTFor(Prefixes.uri(Prefixes.Assets, Uuid3) + "/tags",
                expectedTags1, "Ok", String.class);


        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid");

        verify(configuration.restTemplate())
                .postForObject(eq(getAssetUrl() + Prefixes.uri(Prefixes.Assets, Uuid3) + "/tags"),
                        any(HttpEntity.class), eq(String.class));
    }
*/

    @Ignore("TODO: BROKEN DUE TO CODE REFACTORING IN REARCHITECTURE")
    @Test
    public void createForAsset_withTagCorrelation() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/forAssetWithTagCorrelation.xml");

        MeasurementTag[] expectedTags1 = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/forAsset1.json");
        MeasurementTag[] expectedCorrelatedTags1 = readObjectsFromResourceFile(
            "/assetIn" + getPrefix() + "/forAssetWithTagCorrelation1.json");
        MeasurementTag[] expectedCorrelatedTags2 = readObjectsFromResourceFile(
            "/assetIn" + getPrefix() + "/forAssetWithTagCorrelation2.json");
        Map<MeasurementTag[], String> expectedTagsMap = new HashMap<>();
        expectedTagsMap.put(expectedTags1, "Ok");
        expectedTagsMap.put(expectedCorrelatedTags1, "Ok");
        expectedTagsMap.put(expectedCorrelatedTags2, "Ok");
        setupPOSTForMultipleCalls(Prefixes.uri(Prefixes.Assets, Id3) + "/tags", expectedTagsMap, String.class);

        MeasurementTag[] expectedTags2 = readObjectsFromResourceFile(
            "/assetIn" + getPrefix() + "/forAssetWithoutTagCorrelation.json");
        setupPOSTFor(Prefixes.uri(Prefixes.Assets, Id4) + "/tags", expectedTags2, "Ok", String.class);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);

        verify(configuration.restTemplate(), times(3)).postForObject(
            eq(getAssetUrl() + Prefixes.uri(Prefixes.Assets, Id3) + "/tags"), any(HttpEntity.class), eq(String.class));
        verifyPOSTCalls(Prefixes.uri(Prefixes.Assets, Id4) + "/tags");
    }

    @Ignore("TODO: BROKEN DUE TO CODE REFACTORING IN REARCHITECTURE")
    @Test
    public void createForAsset_withTagCorrelation_skipsInvalidCorrelation()
        throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/forAssetWithTagCorrelation.xml");

        setupLookupObjectUriFor(Id1, Prefixes.MeasurementTagTypes, Uuid1);
        setupLookupObjectUriFor(Id2, Prefixes.MeasurementTagTypes, Uuid2);
        setupLookupObjectUriFor(Id3, Prefixes.Assets, Uuid3);
        setupLookupObjectUriFor(Id4, Prefixes.Assets, Uuid4);
        setupLookupObjectUriFor(Id5, Prefixes.MeasurementTags, Uuid5);

        MeasurementTag[] expectedTags1 = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/forAsset1.json");
        MeasurementTag[] expectedCorrelatedTags1 = readObjectsFromResourceFile(
            "/assetIn" + getPrefix() + "/forAssetWithTagCorrelation1.json");
        Map<MeasurementTag[], String> expectedTagsMap = new HashMap<>();
        expectedTagsMap.put(expectedTags1, "Ok");
        expectedTagsMap.put(expectedCorrelatedTags1, "Ok");
        setupPOSTForMultipleCalls(Prefixes.uri(Prefixes.Assets, Uuid3) + "/tags", expectedTagsMap, String.class);

        MeasurementTag[] expectedTags2 = readObjectsFromResourceFile(
            "/assetIn" + getPrefix() + "/forAssetWithoutTagCorrelation.json");
        setupPOSTFor(Prefixes.uri(Prefixes.Assets, Uuid4) + "/tags", expectedTags2, "Ok", String.class);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "", false);

        verify(configuration.restTemplate(), times(2)).postForObject(
            eq(getAssetUrl() + Prefixes.uri(Prefixes.Assets, Uuid3) + "/tags"), any(HttpEntity.class),
            eq(String.class));
        verify(configuration.restTemplate()).postForObject(
            eq(getAssetUrl() + Prefixes.uri(Prefixes.Assets, Uuid4) + "/tags"), any(HttpEntity.class),
            eq(String.class));
    }
}
