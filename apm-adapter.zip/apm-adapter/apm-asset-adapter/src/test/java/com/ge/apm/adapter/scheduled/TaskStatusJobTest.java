/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.scheduled;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.TestApp;
import com.ge.apm.adapter.domain.persistence.repository.IIngestionLogMsgRepository;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.apm.datasource.TenantDataSourceService;

/**
 * Created by 212576241 on 4/25/17.
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { TestApp.class, TaskStatusJob.class })
public class TaskStatusJobTest {

    @InjectMocks
    @Autowired
    private TaskStatusJob taskStatusJob;

    @MockBean
    private ITaskProcessorRepository taskProcessorRepository;

    @MockBean
    private IIngestionLogMsgRepository ingestionLogMsgRepository;

    @MockBean
    private TenantDataSourceService tenantDataSourceService;

    @Test
    public void testStaleTask() {
        //Test connects to sandbox db - dont want to run when building for deployment
        //taskStatusJob.cancelStaleTasks();
    }
}

