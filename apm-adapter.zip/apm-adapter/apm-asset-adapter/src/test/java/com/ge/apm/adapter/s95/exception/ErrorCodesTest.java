/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.exception;

import org.junit.Assert;
import org.junit.Test;

import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

/**
 * Description of ErrorCodesTest
 *
 * @author Albert H. Yu 212365823
 * @author Venkata Dharma Chand Bhaverisetti 212432041
 * @version 1.0 Mar 2, 2016
 * @since 1.0
 */
public class ErrorCodesTest {

    @Test
    public void test() {
        Assert.assertEquals("Failed to store %s as blob for task %s: %s",
            ErrorProvider.findError(ErrorConstants.ASSET_BLOB_STORAGE).message());
    }
}
