/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.instance;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.output.WriterOutputStream;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.apm.adapter.common.packer.AssetPacker;
import com.ge.apm.asset.model.GeoLocation;
import com.ge.apm.asset.model.GeoPoint;
import com.ge.apm.asset.model.PostalAddress;
import com.ge.apm.bod.model.BusinessObjectDocument;
import com.ge.apm.bod.model.noun.CcomPayload;
import com.ge.apm.bod.model.util.BodFactory;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.custom.locatable.Asset;
import com.ge.apm.ccom.model.tracking.geospatial.GPSLocation;
import com.ge.apm.s95.model.Instance;
import com.ge.apm.s95.model.Property;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Description of AssetInstanceProcessorTest
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Nov 17, 2016
 * @since 1.0
 */
@RunWith(PowerMockRunner.class)
@Slf4j
public class AssetInstanceProcessorTest {

    private final AssetInstanceProcessor processor = new AssetInstanceProcessor();

    @Mock
    private BodFactory bodFactory;

    @InjectMocks
    private AssetPacker assetPacker;

    @Test
    public void processInternal_OK()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        Assert.assertNotNull(newAsset(newInstance()));
    }

    @Test
    public void processInternal_onlyRequiredOK()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        Instance instance = newInstance();
        instance.getLocation().getGeoPoints().get(0).setName(null);
        instance.getLocation().getGeoPoints().get(0).setOrder(null);
        instance.getLocation().getGeoPoints().get(0).setAltitude(null);
        Assert.assertNotNull(newAsset(instance));
    }

    @Test(expected = ValidationFailedException.class)
    public void processInternal_missingLatitude()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        Instance instance = newInstance();
        instance.getLocation().getGeoPoints().get(0).setLatitude(null);
        processor.processInternal(instance);
    }

    @Test
    public void asymmetricNullXmlValueMarshalUnmarshal()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException, JAXBException {
        Instance instance = newInstance();
        // the null name will be unmarshalled as ""
        instance.getLocation().getGeoPoints().get(0).setName(null);
        instance.getLocation().getGeoPoints().get(0).setOrder(null);
        instance.getLocation().getGeoPoints().get(0).setAltitude(null);
        Asset asset = newAsset(instance);
        List<Entity> entities = new ArrayList<>();
        entities.add(asset);

        Mockito.when(bodFactory.getBod()).thenReturn(new BodFactory().getBod());

        BusinessObjectDocument bod = assetPacker.createEntities(entities);
        CcomPayload payload = (CcomPayload) bod.getDataArea().getNoun();
        GPSLocation gps = ((Asset) payload.getCcomData().getEntity().get(0)).getLocation().getGPSLocations().get(0);
        Assert.assertNull(gps.getName().getValue());

        JAXBContext ctx = JAXBContext.newInstance(
            "com.ge.apm.bod.model:com.ge.apm.ccom.model:com.ge.apm.ccom.model.custom");
        Marshaller marshaller = ctx.createMarshaller();

        StringWriter sw = new StringWriter();
        WriterOutputStream wos = new WriterOutputStream(sw, Charset.forName("UTF8").newDecoder());

        marshaller.marshal(bod, wos);
        wos.flush();
        Assert.assertNotNull(sw.toString());
        log.info(sw.toString());
        wos.close();
        StringReader reader = new StringReader(sw.toString());
        Unmarshaller unmarshaller = ctx.createUnmarshaller();
        Object rslt = unmarshaller.unmarshal(reader);
        Assert.assertTrue(rslt instanceof BusinessObjectDocument);
        CcomPayload outPayload = ((CcomPayload) ((BusinessObjectDocument) rslt).getDataArea().getNoun());
        GPSLocation outGps = ((Asset) outPayload.getCcomData().getEntity().get(0)).getLocation().getGPSLocations().get(
            0);

        Assert.assertEquals("", outGps.getName().getValue());
    }

    private Asset newAsset(Instance instance)
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        return processor.processInternal(instance);
    }

    private Instance newInstance() {
        Instance instance = new Instance();
        instance.setCcomClass(MimosaCcomCategory.ASSET);
        instance.setName("locatable-asset-name");
        instance.setDescription("This is a test for the custom locatable asset");
        instance.setClassification("locatable-asset-classification");
        instance.setId("locatable-asset-id");

        Property p = new Property();
        p.setId("model number");
        p.setType("string");
        p.setValue(new String[] { "model-123" });
        instance.setProperties(new Property[] { p });
        ;

        GeoLocation location = new GeoLocation();

        PostalAddress address = new PostalAddress();
        address.setStreet(new String[] { "2623 Camino Ramon", "4th Floor" });
        address.setCity("San Ramon");
        address.setState("CA");
        address.setZipcode("94583");
        address.setCountry("USA");
        location.setPostalAddress(address);

        GeoPoint pt = new GeoPoint();
        pt.setLatitude(37.766847);
        pt.setLongitude(-121.957748);
        List<GeoPoint> points = new ArrayList<>();
        points.add(pt);
        location.setGeoPoints(points);

        location.setTimezone("Pacific/Samoa");

        instance.setLocation(location);
        return instance;
    }
}
