/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

/**
 *
 */

package com.ge.apm.adapter.ccom.util;

import javax.sql.DataSource;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;

import static org.mockito.Mockito.mock;

/**
 * @author 212312392
 *
 */
@Configuration
public class CloudConfigurationTest {

    public CloudConfiguration cloudConfiguration;

    public DataSource dataSource;

    public RedisOperations<Object, Object> redisOperations;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {

        dataSource = mock(DataSource.class);
        cloudConfiguration = new CloudConfiguration();
        redisOperations = mock(RedisTemplate.class);
    }

    @Test
    public void testApmCacheManager() {
        CacheManager cacheManager;
        cacheManager = cloudConfiguration.apmCacheManager(redisOperations);
        Assert.assertTrue(cacheManager instanceof RedisCacheManager);
    }
}
