/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.apm.adapter.ccom.base.BaseTransformerTest;
import com.ge.apm.adapter.ccom.transformer.CcomClassNameMappingEnum;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.core.HierarchicalEntity;
import com.ge.apm.ccom.model.core.HierarchicalLink;
import com.ge.apm.ccom.model.registry.Segment;
import com.ge.apm.ccom.model.registry.Site;
import com.ge.asset.commons.validator.ValidationFailedException;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BaseTransformerTest.Configuration.class)
public class AssetTransformerTest extends BaseMonitoredTransformerTest<Asset> {

    @Override
    protected String getPrefix() {
        return Prefixes.Assets;
    }

    @Override
    protected Class<Asset> getObjectClass() {
        return Asset.class;
    }

    @Override
    protected String getTypePrefix() {
        return Prefixes.AssetTypes;
    }

    @Override
    protected void setupLookupForCreate() {
        setupLookupObjectUriFor(Id3, Prefixes.Sites, Uuid3);
        setupLookupObjectUriFor(Id4, getTypePrefix(), Uuid4);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
        setupLookupObjectUriFor(Id6, Prefixes.Segments, Uuid6);
    }

    @Override
    protected void setupLookupForUpdate() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Prefixes.Segments, Uuid3);
        setupLookupObjectUriFor(Id4, getTypePrefix(), Uuid4);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
    }

    @Override
    protected void setupLookupForUpdateOne() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id3, Prefixes.Assets, Uuid3);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
    }

    @Override
    protected void setupLookupForCreateWithConnections() {
        setupLookupObjectUriFor(Id3, Prefixes.Sites, Uuid3);
        setupLookupObjectUriFor(Id4, getTypePrefix(), Uuid4);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
        setupLookupObjectUriFor(Id6, Prefixes.Segments, Uuid6);
    }

    @Override
    protected void setupLookupForUpdateWithConnections() {
        setupLookupObjectUriFor(Id1, Uuid1);
        setupLookupObjectUriFor(Id2, Uuid2);
        setupLookupObjectUriFor(Id3, Prefixes.Segments, Uuid3);
        setupLookupObjectUriFor(Id4, getTypePrefix(), Uuid4);
        setupLookupObjectUriFor(Id5, getTypePrefix(), Uuid5);
    }

    @Test
    public void createWithReservedAttributes() throws IOException, JAXBException, ValidationFailedException {
        Map<String, String> nameTypeMap = new LinkedHashMap<>();
        nameTypeMap.put("state", "KeyValue");
        nameTypeMap.put("status", "KeyValue");
        setupReservedAttributeConfig(getPrefix(), nameTypeMap);
        testWithNoSourceKeyLookup("createWithReservedAttributes");
        verifyPOSTCalls(getPrefix());
    }

    @Test
    public void create() throws IOException, JAXBException, ValidationFailedException {
        super.create();
    }

    @Test
    public void testEnumValue() {
        String testNode = CcomClassNameMappingEnum.getSimpleJsonNodeNameFromEnum("Asset");
        Assert.assertTrue("instances".equals(testNode));
        String testClass = CcomClassNameMappingEnum.getSimpleClassNameFromEnum("Asset");
        Assert.assertTrue("ASSET".equals(testClass));
    }

    @Test
    public void test_getParentSourceKey() {
        com.ge.apm.ccom.model.registry.Asset ccomAsset = new com.ge.apm.ccom.model.registry.Asset();
        Site ccomObject = new Site();
        com.ge.apm.ccom.model.core.types.UUID ccomUUID = new com.ge.apm.ccom.model.core.types.UUID();
        ccomUUID.setValue("mySite");
        ccomObject.setGUID(ccomUUID);
        ccomAsset.setRegistrationSite(ccomObject);
        AssetTransformer assetTransformer = new AssetTransformer(null);
        String parentSourceKey = assetTransformer.getParentSourceKey(ccomAsset);
        Assert.assertEquals("mySite", parentSourceKey);

        Segment ccomSegment = new Segment();
        ccomUUID = new com.ge.apm.ccom.model.core.types.UUID();
        ccomUUID.setValue("mySegment");
        ccomSegment.setGUID(ccomUUID);
        ccomAsset = new com.ge.apm.ccom.model.registry.Asset();
        ccomAsset.setEquivalentSegment(ccomSegment);
        parentSourceKey = assetTransformer.getParentSourceKey(ccomAsset);
        Assert.assertEquals("mySegment", parentSourceKey);

        HierarchicalLink hierarchicalLink = new HierarchicalLink();
        HierarchicalEntity parentHierarchicalEnitity = new com.ge.apm.ccom.model.registry.Asset();
        ccomUUID = new com.ge.apm.ccom.model.core.types.UUID();
        ccomUUID.setValue("myParent");
        parentHierarchicalEnitity.setGUID(ccomUUID);
        hierarchicalLink.setParent(parentHierarchicalEnitity);
        ccomAsset = new com.ge.apm.ccom.model.registry.Asset();
        ccomAsset.getParentLink().add(hierarchicalLink);
        parentSourceKey = assetTransformer.getParentSourceKey(ccomAsset);
        Assert.assertEquals("myParent", parentSourceKey);
    }
}
