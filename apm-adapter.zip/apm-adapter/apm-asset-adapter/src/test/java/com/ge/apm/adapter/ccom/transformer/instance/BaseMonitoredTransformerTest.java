/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.io.IOException;
import java.util.List;
import javax.xml.bind.JAXBException;

import org.junit.Test;

import com.ge.apm.asset.model.Monitored;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.asset.commons.validator.ValidationFailedException;

public abstract class BaseMonitoredTransformerTest<T extends Monitored> extends BaseTypedTransformerTest<T> {

    @Test
    public void createWithConnections() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/createWithConnections.xml");
        T[] expectedObjects = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/createWithConnections.json");
        T[] returnObjects = readObjectsFromResourceFile("/assetOut" + getPrefix() + "/createWithConnections.json");

        setupLookupForCreateWithConnections();
        setupPOSTFor(getPrefix(), expectedObjects, returnObjects);

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "",
            "Connections",

            false);
        verifyPOSTCalls(getPrefix());
    }

    @Test
    public void createWithEmptyName() throws IOException, JAXBException, ValidationFailedException {
        List<Entity> entities = fetchEntities("/ccom" + getPrefix() + "/create.xml");
        entities.get(0).setName(null);
        /*T[] expectedObjects = readObjectsFromResourceFile("/assetIn" + getPrefix() + "/create.json");
        T[] returnObjects = readObjectsFromResourceFile("/assetOut" + getPrefix() + "/create.json");*/

        entityTransformer.transformEntities(entities, getAuthorization(), getTenantUuid(), "TraceUuid", "", "",

            false);
    }

    protected abstract void setupLookupForCreateWithConnections();

    protected abstract void setupLookupForUpdateWithConnections();
}
