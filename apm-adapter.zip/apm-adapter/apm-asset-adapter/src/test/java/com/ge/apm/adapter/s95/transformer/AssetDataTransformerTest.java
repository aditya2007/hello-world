/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.transformer;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;

import com.ge.apm.blob.client.MultipartClient;
import com.ge.apm.adapter.common.util.IEntityDispatcher;
import com.ge.apm.adapter.s95.processor.S95DataProcessor;
import com.ge.apm.adapter.s95.util.ReflectionUtils;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.util.AssetConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;
import com.ge.asset.commons.validator.ValidationResult;
import com.ge.asset.commons.validator.Validator;
import com.ge.asset.commons.validator.ValidatorException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * @author 212312392
 *
 */
public class AssetDataTransformerTest {

    Exchange exchange = null;
    Message msg = null;
    IEntityDispatcher iEntityDispatcher = null;
    S95DataProcessor s95DataProcessor = null;

    AssetDataTransformer assetDataTransformerTest = null;
    Validator validator = null;
    ValidationResult validationResult = null;

    @Before
    public void setup() {

        exchange = Mockito.mock(Exchange.class);
        msg = Mockito.mock(Message.class);
        Mockito.when(exchange.getIn()).thenReturn(msg);
        Message msgOut = Mockito.mock(Message.class);

        Mockito.when(exchange.getOut()).thenReturn(msgOut);
        Mockito.when(msg.getHeader(MessageConstants.ADAPTER_UUID, String.class)).thenReturn("Adapter uuid");
        Mockito.when(msg.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("Task uuid");
        Mockito.when(msg.getHeader(MessageConstants.AUTHORIZATION, String.class)).thenReturn("Authorization");
        Mockito.when(msg.getHeader(MessageConstants.TENANT_UUID, String.class)).thenReturn("Tenant uuid");
        Mockito.when(msg.getHeader(MessageConstants.BATCH_SIZE, String.class)).thenReturn("1");


        iEntityDispatcher = Mockito.mock(IEntityDispatcher.class);
        s95DataProcessor = Mockito.mock(S95DataProcessor.class);

        PowerMockito.when(msg.getHeader("parentEntityType", String.class)).thenReturn("assettest");
        PowerMockito.when(msg.getHeader(Exchange.FILE_NAME, String.class)).thenReturn("samplefile");
        PowerMockito.when(msg.getHeader(RequestContext.TENANT, String.class)).thenReturn("tenant");
        Map<String, String> headersMap = new HashMap<>();
        headersMap.put(RequestContext.AUTHORIZATION, "user");
        headersMap.put(RequestContext.TENANT, "tenant");

        MultipartClient.RestResponse restResponse = Mockito.mock(MultipartClient.RestResponse.class);
        Mockito.when(restResponse.getStatus()).thenReturn(HttpStatus.SC_OK);

        validationResult = new ValidationResult();
        assetDataTransformerTest = new AssetDataTransformer();
    }

    @Test
    public void testTransform() {
        try {
            InputStream stream = Mockito.mock(InputStream.class);
            Mockito.when(msg.getBody(InputStream.class)).thenReturn(stream);
            validationResult.setValid(true);
            validator = Mockito.mock(Validator.class);
            Mockito.when(validator.validate("")).thenReturn(validationResult);

            ReflectionUtils.setField(AssetDataTransformer.class, assetDataTransformerTest, "entityDispatcher",
                iEntityDispatcher);
            ReflectionUtils.setField(AssetDataTransformer.class, assetDataTransformerTest, "s95DataProcessor",
                s95DataProcessor);

            ReflectionUtils.setField(AssetDataTransformer.class, assetDataTransformerTest, "validator", validator);

            assetDataTransformerTest.transform(exchange);
            Assert.assertNotNull(exchange);
        } catch (Exception exc) {
            fail(exc.getLocalizedMessage());
            exc.printStackTrace();
        }
    }

    @Test
    public void testInputStreamWithNonNullValue()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        try (InputStream mockInputStream = IOUtils.toInputStream("some test data for my input stream")) {
            Mockito.when(msg.getBody(InputStream.class)).thenReturn(mockInputStream);
            validationResult.setValid(true);
            validator = Mockito.mock(Validator.class);
            Mockito.when(validator.validate("some test data for my input stream")).thenReturn(validationResult);

            ReflectionUtils.setField(AssetDataTransformer.class, assetDataTransformerTest, "entityDispatcher",
                iEntityDispatcher);
            ReflectionUtils.setField(AssetDataTransformer.class, assetDataTransformerTest, "s95DataProcessor",
                s95DataProcessor);
            ReflectionUtils.setField(AssetDataTransformer.class, assetDataTransformerTest, "validator", validator);

            assetDataTransformerTest.transform(exchange);
            Assert.assertNotNull(exchange);
        }
    }

    @Test
    public void testValidationResponseWithFalseReturn()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        try (InputStream stream = Mockito.mock(InputStream.class)) {
            Mockito.when(msg.getBody(InputStream.class)).thenReturn(stream);
            Error error = new Error(Error.ErrorType.ERROR, "E10001",
                ErrorProvider.findMessage(ErrorConstants.INVALID_JSON_CODE));
            error.setPlaceHolders(
                new String[] { AssetConstants.EMPTY_STRING, AssetConstants.EMPTY_STRING, AssetConstants.EMPTY_STRING });
            validationResult.getErrors().add(error);
            validationResult.setValid(false);
            validator = Mockito.mock(Validator.class);
            assetDataTransformerTest.setValidator(validator);
            Mockito.when(validator.validate("")).thenReturn(validationResult);

            ReflectionUtils.setField(AssetDataTransformer.class, assetDataTransformerTest, "entityDispatcher",
                iEntityDispatcher);
            ReflectionUtils.setField(AssetDataTransformer.class, assetDataTransformerTest, "s95DataProcessor",
                s95DataProcessor);

            assetDataTransformerTest.transform(exchange);
        } catch (ValidationFailedException validation) {
            assertEquals(validation.getErrorCollection().size(), 1);
            assertEquals(validation.getErrorCollection().get(0).getErrorCode(), "E10001");
        }
    }

    @Test
    public void testWithNullValidatorObject()
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        try (InputStream stream = Mockito.mock(InputStream.class)) {
            Mockito.when(msg.getBody(InputStream.class)).thenReturn(stream);
            assetDataTransformerTest.setValidator(null);

            ReflectionUtils.setField(AssetDataTransformer.class, assetDataTransformerTest, "entityDispatcher",
                iEntityDispatcher);
            ReflectionUtils.setField(AssetDataTransformer.class, assetDataTransformerTest, "s95DataProcessor",
                s95DataProcessor);

            assetDataTransformerTest.transform(exchange);
        } catch(ValidatorException validation) {
            assertTrue(validation.getMessage().startsWith("Error on loading schema:"));
        }
    }
}
