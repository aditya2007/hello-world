#!/bin/bash

####################################################################################################
#
# This script uploads zip files in the current folder to APM S95 Adapter and monitors their status
# to serialize the asset ingestion process. 
#
# The target APM and Predix Asset instances are configured in the ingest-${env}.cfg file in the same 
# folder.
#
# author: Albert H. Yu, 2123645823
#
####################################################################################################

env=dev
if [ $# -eq 1 ]; then
   env=$1
else
   echo "Usage: To start the upload process in the ${env} environment"
   echo "       ./ingest.sh ${env}"
  exit -1
fi

# Input configuration for APM and Predix Asset service instances
source ./ingest-${env}.cfg 

#
# fetch bearer token from APM UAA
#
bearer=`curl -s -X POST -H "Authorization: Basic $ingestor_basic_token" -H "Cache-Control: no-cache" -H "Content-Type: application/x-www-form-urlencoded" -d "grant_type=password&username=${tenant}_ingestor&password=${ingestor_password}" "https://${apm_uaa}/oauth/token" | python -c 'import json,sys;obj=json.load(sys.stdin);print obj["access_token"];'`

echo "Succssfully fetched bearer token from APM UAA ${apm_uaa}.${domain}"
echo ""

failed=""
files=`ls ./*.zip`
total=`echo $files | wc -w | sed 's/^[ ]*//'`
echo "Processing $total zip files"
echo ""

started_at_time=`date +%s`

ingestOne() {
  ts_start=`date +%s`
  # ingest a single zip
  #####################################################################################################################
  # TODO: need to figure out why the proper json response is coming back, yet the request is marked as 400 bad request
  #####################################################################################################################
  task=`curl -s -X POST -H "Authorization: Bearer $bearer" -H "tenant: $tenant" -H "Cache-Control: no-cache" "Content-Type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW" -F "file=@$f" "https://apm-s95-adapter-${env}.${domain}/v1/asset/upload" | grep tenantUuid | python -c 'import json,sys;obj=json.load(sys.stdin);print obj["uuid"];'`

  echo "Ingesting $f as task $task"

  status=""
  clock=`date +%s`
  now=$clock
  diff=$(( $now - $clock - $timeout ))
  isCompleted=false
  isError=false
  isTimedout=false

  # Keep polling for the task status until the task is either completed, or in error, or timed out
  while [ "$isCompleted" == false ] && [ "$isError" == false ] && [ "$isTimedout" == false ]; do
    sleep $wait_delta
  
    #
    # TODO: currently, this is limited to handle a zip file with one single children json file, parsing the status from that task
    #
    status=`curl -s -X GET -H "Authorization: Bearer $bearer" -H "tenant: $tenant" -H "Cache-Control: no-cache" "https://apm-adapter-config-provider-${env}.${domain}/v1/tasks/${task}" | python -c 'import json,sys;obj=json.load(sys.stdin);print obj["children"][0]["status"];'`
    echo "Monitoring $f: $status"

    [ "$status" == "COMPLETED" ] && isCompleted=true
    [ "`echo $status | cut -c1-5`" == "ERROR" ] && isError=true

    now=`date +%s`
    diff=$(( $now - $clock - $timeout ))
    [ $diff -gt 0 ] && isTimedout=true
  done

  if [ "$isCompleted" == true ]; then
     diff=$(( $now - $ts_start ))
     echo "Successfully ingested $f within $diff seconds"
  elif [ "$isError" == true ]; then
     echo "Failed to ingest $f again as task $task: error"
  else
     echo "Failed to ingest $f again as task $task: timed out after $timeout seconds"
  fi
  echo ""
}

for f in $files
do
  ingestOne
done

failedTotal=`echo $failed | wc -w | sed 's/^[ ]*//'`
if [ $failedTotal -gt 0 ]; then
  echo "$failedTotal failed ingestions out of $total total files"
  echo "Re-ingest $failedTotal files again"
  echo ""
fi

# One more try on the failed or timed out files
for f in $failed
do
  ingestOne
done

now=`date +%s`
diff=$(( $now - $started_at_time ))
echo "Total time spent processing $total zip files: $diff seconds"
