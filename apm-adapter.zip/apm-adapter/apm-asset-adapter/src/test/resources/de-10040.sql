--liquibase formatted sql

--changeset ChandraRamineni:5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = apm_adapter, pg_catalog;

-- invalid data type
UPDATE ingestion_log_msg_dict SET msg_code='E10054' WHERE msg_code='E10023';
UPDATE ingestion_log_msg_dict SET msg_code='E10053' WHERE msg_code='E10022';
UPDATE ingestion_log_msg_dict SET msg_code='E10052' WHERE msg_code='E10021';
UPDATE ingestion_log_msg_dict SET msg_code='E10051' WHERE msg_code='E10020';

-- invalid parent
UPDATE ingestion_log_msg_dict SET msg_code='E10043' WHERE msg_code='E10019';
UPDATE ingestion_log_msg_dict SET msg_code='E10042' WHERE msg_code='E10018';
UPDATE ingestion_log_msg_dict SET msg_code='E10041' WHERE msg_code='E10017';


-- invalid connections
UPDATE ingestion_log_msg_dict SET msg_code='E10027' WHERE msg_code='E10016';
UPDATE ingestion_log_msg_dict SET msg_code='E10026' WHERE msg_code='E10015';
UPDATE ingestion_log_msg_dict SET msg_code='E10025' WHERE msg_code='E10014';
UPDATE ingestion_log_msg_dict SET msg_code='E10024' WHERE msg_code='E10013';
UPDATE ingestion_log_msg_dict SET msg_code='E10023' WHERE msg_code='E10012';
UPDATE ingestion_log_msg_dict SET msg_code='E10022' WHERE msg_code='E10011';
UPDATE ingestion_log_msg_dict SET msg_code='E10021' WHERE msg_code='E10010';

-- new invalid ccomClass
INSERT INTO ingestion_log_msg_dict (msg_code, msg_type, msg, action, resolution)
    VALUES ('E10010', 'Business Rule', 'Invalid ccomClass "%s" specified for MonitoredEntity From %s - Type %s To: %s - Type %s', 'Skip and Continue', 
        'Specify one of the following supported ccomClass types for Connections: SITE, SEGMENT, ASSET');

