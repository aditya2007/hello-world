/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.instance;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.apm.asset.model.GeoPoint;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.custom.locatable.Asset;
import com.ge.apm.ccom.model.custom.locatable.Location;
import com.ge.apm.ccom.model.custom.locatable.PostalAddress;
import com.ge.apm.ccom.model.registry.AssetType;
import com.ge.apm.ccom.model.tracking.geospatial.GPSLocation;
import com.ge.apm.s95.model.Instance;
import com.ge.asset.commons.validator.LocationContext;
import com.ge.asset.commons.validator.ValidationFailedException;
import com.ge.asset.commons.validator.ValidationResult;
import com.ge.asset.commons.validator.Validator;

@Component
public class AssetInstanceProcessor extends InstanceObjectProcessor<Asset, AssetType> {

    @Value("${location.gps.name.max.length}")
    private Integer maxNameLength;

    @Value("${location.gps.max.precision}")
    private Integer gpsMaxPrecision;

    public AssetInstanceProcessor() {
        super(Asset.class, AssetType.class);
    }

    @Override
    protected void assignEntityType(Asset entity, AssetType typeEntity) {
        entity.setType(typeEntity);
    }

    @Override
    protected void processOthers(Asset entity, Instance instance) throws IOException, ValidationFailedException {
        if (instance.getLocation() != null) {
            Map<String, Object> validationCtx = new HashMap<>();
            validationCtx.put(LocationContext.KEY.parent.name(), Asset.class.getSimpleName() + " " + instance.getId());
            validationCtx.put(LocationContext.KEY.maxNameLength.name(), maxNameLength);
            validationCtx.put(LocationContext.KEY.gpsMaxPrecision.name(), gpsMaxPrecision);
            Validator validator = new Validator(Validator.LOCATION_S95_VALIDATION_KEY, validationCtx);
            ValidationResult validationRslt = validator.validate(instance.getLocation());
            if (validationRslt.isValid()) {
                Location location = new Location();
                com.ge.apm.asset.model.PostalAddress inAddr = instance.getLocation().getPostalAddress();
                String inTimezone = instance.getLocation().getTimezone();
                if (inAddr != null) {
                    PostalAddress postalAddress = getPostalAddress(inAddr);
                    location.setAddress(postalAddress);
                }

                if (inTimezone != null) {
                    location.setTimezone(inTimezone);
                }

                if (instance.getLocation().getGeoPoints() != null) {
                    for (GeoPoint point : instance.getLocation().getGeoPoints()) {
                        GPSLocation gps = getGpsLocation(point);
                        location.getGPSLocations().add(gps);
                    }
                }

                entity.setLocation(location);
            } else {
                throw new ValidationFailedException(validationRslt.getErrors());
            }
        }
    }

    private GPSLocation getGpsLocation(GeoPoint point) {
        GPSLocation gps = new GPSLocation();
        gps.setName(CcomTypeHelper.wrapText(point.getName()));
        if (point.getOrder() != null) {
            gps.setOrder(CcomTypeHelper.wrapNumber(point.getOrder()));
        }
        gps.setLatitude(CcomTypeHelper.wrapNumber(point.getLatitude()));
        gps.setLongitude(CcomTypeHelper.wrapNumber(point.getLongitude()));
        if (point.getAltitude() != null) {
            gps.setElevation(CcomTypeHelper.wrapNumber(point.getAltitude()));
        }
        return gps;
    }

    private PostalAddress getPostalAddress(com.ge.apm.asset.model.PostalAddress inAddr) {
        PostalAddress postalAddress = new PostalAddress();
        if (inAddr.getStreet() != null) {
            for (String line : inAddr.getStreet()) {
                postalAddress.getStreet().add(line);
            }
        }
        postalAddress.setCity(inAddr.getCity());
        postalAddress.setState(inAddr.getState());
        postalAddress.setCountry(inAddr.getCountry());
        postalAddress.setZipcode(inAddr.getZipcode());
        return postalAddress;
    }
}
