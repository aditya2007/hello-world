/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.BaseTransformer;
import com.ge.apm.adapter.ccom.transformer.IEntityTransformer;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.asset.model.Asset;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.network.connections.AssetConnection;
import com.ge.apm.ccom.model.network.topologies.AssetMesh;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
public class AssetMeshTransformer extends BaseTransformer implements IEntityTransformer<AssetMesh> {

    private final ThreadLocal<List<Asset>> assetsToUpdate;

    @Autowired
    public AssetMeshTransformer(AssetClient assetClient) {
        super(assetClient);
        this.assetsToUpdate = new ThreadLocal<List<Asset>>() {
            @Override
            protected List<Asset> initialValue() {
                return new ArrayList<>();
            }
        };
    }

    @Override
    public TransformResponse transform(AssetMesh entity) throws ServiceException, ValidationFailedException {

        TransformResponse transformResponse = new TransformResponse();
        AssetMesh assetMesh = (AssetMesh) entity;
        Map<String, Asset> assetMap = new HashMap<>();
        for (AssetConnection assetConnection : assetMesh.getConnection()) {
            String type = assetConnection.getType().getName().getValue();
            String fromSourceKey = assetConnection.getFrom().getGUID().getValue();

            // perform toSourceKey check first as an optimization, since "to" is a parent and can be repeated many times
            if (!assetMap.containsKey(fromSourceKey)) {
                Asset asset = new Asset();
                asset.setUri(fromSourceKey);
                assetMap.put(fromSourceKey, asset);
            }

            if (assetMap.get(fromSourceKey).getConnections() == null) {
                assetMap.get(fromSourceKey).setConnections(new LinkedHashMap<>());
            }
            if (!assetMap.get(fromSourceKey).getConnections().containsKey(type)) {
                assetMap.get(fromSourceKey).getConnections().put(type, new LinkedHashSet<>());
            }

            String toSourceKey = assetConnection.getTo().getGUID().getValue();
            assetMap.get(fromSourceKey).getConnections().get(type).add(toSourceKey);
        }
        assetsToUpdate.get().addAll(assetMap.values());

        if (transformResponse.getWarnings() != null && transformResponse.getWarnings().size() > 0) {
            transformResponse.setStatus(TransformResponse.EntityResponseStatus.CREATEDWITHWARNINGS);
        } else {
            transformResponse.setStatus(TransformResponse.EntityResponseStatus.OK);
        }

        return transformResponse;
    }

    @Override
    public void doDispatch() throws ServiceException {
        try {
            if (assetsToUpdate.get().size() > 0) {
                // TODO: this is really a no-op after re-architect, a piece of dead code???
                assetClient.update(Prefixes.Assets,
                    assetsToUpdate.get().toArray(new Asset[assetsToUpdate.get().size()]));
            }
        } finally {
            assetsToUpdate.get().clear();
        }
    }

    @Override
    protected String getPrefix() {
        return Prefixes.Assets;
    }

    @Override
    public int order() {
        return Priority.assetMesh.priority();
    }

    @Override
    public Class<AssetMesh> supportedCcomClass() {
        return AssetMesh.class;
    }
}
