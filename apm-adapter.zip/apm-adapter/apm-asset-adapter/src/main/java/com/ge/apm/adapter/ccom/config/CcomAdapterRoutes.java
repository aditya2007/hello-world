/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.config;

import com.ge.apm.adapter.common.config.AdapterRoutes;

/**
 * @author Chand Bhaverisetti 212432041
 * @version Feb 24, 2017
 * @since 1.0
 */
public class CcomAdapterRoutes extends AdapterRoutes {

    public static final String CCOM_APP_ID = "D47303E528AF4EE58CA036FD977FE945";

    public static final String LOG_ASSET_ERROR = "log:com.ge.apm.adapter.%s.createAsset?level=ERROR"
        + "&showCaughtException=true&showStackTrace=true";

    public static final String LOG_ASSET_TRACE = "log:com.ge.apm.adapter.%s.createAsset?level=TRACE";

    public static final String DIRECT_ASSET_CCOM_DATA = "direct:%s.process.asset.ccom.data";

    public static final String DIRECT_ASSET_DTO = "direct:apm.adapter.asset.dto";
}
