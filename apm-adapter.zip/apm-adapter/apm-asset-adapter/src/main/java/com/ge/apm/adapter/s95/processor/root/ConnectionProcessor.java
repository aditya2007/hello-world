/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.google.common.collect.ImmutableMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.s95.processor.IRootLevelProcessor;
import com.ge.apm.adapter.s95.processor.base.ObjectProcessor;
import com.ge.apm.adapter.s95.processor.connection.AssetConnectionProcessor;
import com.ge.apm.adapter.s95.processor.connection.ConnectionObjectProcessor;
import com.ge.apm.adapter.s95.processor.connection.EnterpriseConnectionProcessor;
import com.ge.apm.adapter.s95.processor.connection.SegmentConnectionProcessor;
import com.ge.apm.adapter.s95.processor.connection.SiteConnectionProcessor;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.AttributableEntity;
import com.ge.apm.s95.model.Connection;
import com.ge.apm.s95.model.Node;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.util.AssetConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
@Slf4j
@SuppressWarnings({ "PMD.CyclomaticComplexity", "PMD.NPathComplexity", "PMD.ModifiedCyclomaticComplexity",
    "PMD.StdCyclomaticComplexity", "PMD.ExcessiveMethodLength" })
public class ConnectionProcessor extends ObjectProcessor<JsonParser>
    implements InitializingBean, IRootLevelProcessor<JsonParser> {

    private final Set<String> toConnectionCcomClasses = new HashSet<>();

    private final Set<String> fromConnectionCcomClasses = new HashSet<>();

    private Map<MimosaCcomCategory, ConnectionObjectProcessor<? extends AttributableEntity>> connectionProcessorMap;

    @Autowired
    private EnterpriseConnectionProcessor enterpriseConnectionProcessor;

    @Autowired
    private SiteConnectionProcessor siteConnectionProcessor;

    @Autowired
    private SegmentConnectionProcessor segmentConnectionProcessor;

    @Autowired
    private AssetConnectionProcessor assetConnectionProcessor;

    @Override
    public void afterPropertiesSet() {
        connectionProcessorMap = ImmutableMap.of(MimosaCcomCategory.ENTERPRISE, enterpriseConnectionProcessor,
            MimosaCcomCategory.SITE, siteConnectionProcessor, MimosaCcomCategory.SEGMENT, segmentConnectionProcessor,
            MimosaCcomCategory.ASSET, assetConnectionProcessor);

        fromConnectionCcomClasses.addAll(Arrays.asList("ENTERPRISE", "SITE", "SEGMENT", "ASSET"));
        toConnectionCcomClasses.addAll(Arrays.asList("ENTERPRISE", "SITE", "SEGMENT", "ASSET"));
    }

    @Override
    public void process(JsonParser parser)
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        @SuppressWarnings("PMD.CloseResource") Connection connection;
        try {
            connection = parser.readValueAs(Connection.class);
            if (connection.getFrom() == null || connection.getTo() == null) {
                return;
            }
            MimosaCcomCategory category = connection.getFrom().getCcomClass();
            if (connectionProcessorMap.containsKey(category) && connection.getTo() != null
                && connection.getTo().length > 0 && connection.getTo()[0].getCcomClass() != null
                && toConnectionCcomClasses.contains(connection.getTo()[0].getCcomClass().name())) {
                connectionProcessorMap.get(category).process(connection);
            } else {
                getPlaceholders(parser, connection, category);
            }
        } catch (InvalidFormatException formatException) {
            getPlaceholders(parser, formatException);
        }
    }

    private void getPlaceholders(JsonParser parser, Connection connection, MimosaCcomCategory category)
        throws IOException, ValidationFailedException {

        String[] placeHolders = new String[5];
        if (connection.getFrom() == null) {
            placeHolders[1] = AssetConstants.EMPTY_STRING;
            placeHolders[2] = AssetConstants.EMPTY_STRING;
        } else {
            placeHolders[1] = connection.getFrom().getId() == null ? null : connection.getFrom().getId();
            placeHolders[2] = connection.getFrom().getCcomClass() == null ? null
                : connection.getFrom().getCcomClass().name();
        }

        if (connection.getTo() != null && connection.getTo().length > 0) {
            // Assume that To Connection array is always one.
            placeHolders[3] = connection.getTo()[0].getId() == null ? null : connection.getTo()[0].getId();
            placeHolders[4] = connection.getTo()[0].getCcomClass() == null ? null
                : connection.getTo()[0].getCcomClass().name();
        } else {
            placeHolders[3] = AssetConstants.EMPTY_STRING;
            placeHolders[4] = AssetConstants.EMPTY_STRING;
        }

        List<Error> errorList = new ArrayList<>();

        if (!connectionProcessorMap.containsKey(category)) {
            placeHolders[0] = placeHolders[2];
            try {
                processException(parser, placeHolders, ErrorConstants.INVALID_CCOM_CONNECTION, false);
            } catch (ValidationFailedException validationFailed) {
                log.error(validationFailed.getMessage(), validationFailed);
                errorList.addAll(validationFailed.getErrorCollection());
            }
        }

        if (connection.getTo() == null || connection.getTo().length == 0 || connection.getTo()[0].getCcomClass() == null
            || !toConnectionCcomClasses.contains(connection.getTo()[0].getCcomClass().name())) {
            String[] placeholder = Arrays.copyOf(placeHolders, placeHolders.length);
            placeholder[0] = placeholder[4];
            try {
                processException(parser, placeholder, ErrorConstants.INVALID_CCOM_CONNECTION, false);
            } catch (ValidationFailedException validationFailed) {
                log.error(validationFailed.getMessage(), validationFailed);
                errorList.addAll(validationFailed.getErrorCollection());
            }
        }

        throw new ValidationFailedException(errorList);
    }

    private void getPlaceholders(JsonParser parser, InvalidFormatException formatException)
        throws IOException, ValidationFailedException {

        String[] placeHolders = new String[5];
        String parent = null;

        if (formatException.getPath() != null) {
            /** If "Id" property comes next of "CCOM class" property in "from/To" Object, and parser failed in CCOM
             * class property, then we need to fetch "Id" property value from exception since parser has already moved
             * from "Id" property.
             */

            //Assume that CCOM class failed in "from" object, if path size is two.
            if (formatException.getPath().size() == 2) {
                // If parent string value equals to "from", then assume that parser failed in "from" object
                parent = parser.getParsingContext().getParent().getCurrentName();

                if (formatException.getPath().get(1) != null && formatException.getPath().get(1).getFrom() != null) {
                    placeHolders[1] = ((Node) formatException.getPath().get(1).getFrom()).getId();
                }
                placeHolders[2] = parser.getText();
            } else if (formatException.getPath().size() == 3) {
                /**
                 * Assume that CCOM class is failed in "To" object, if path size is three.
                 */
                // If parent string value equals to "to", then assume that parser failed in "to" object
                parent = parser.getParsingContext().getParent().getParent().getCurrentName();
                if (formatException.getPath().get(0) != null && formatException.getPath().get(0).getFrom() != null) {
                    @SuppressWarnings("PMD.CloseResource") Connection fromConnection = ((Connection) formatException
                        .getPath().get(0).getFrom());
                    placeHolders[1] = fromConnection.getFrom().getId();
                    placeHolders[2] = fromConnection.getFrom().getCcomClass() == null ? null
                        : fromConnection.getFrom().getCcomClass().name();
                }
                if (formatException.getPath().get(2) != null && formatException.getPath().get(2).getFrom() != null) {
                    placeHolders[3] = ((Node) formatException.getPath().get(2).getFrom()).getId();
                }
                placeHolders[4] = parser.getText();
            }
        }

        /**
         * move JSON parser cursor to end of from/To object.
         */
        while (parser.getCurrentToken() != JsonToken.END_OBJECT) {
            parser.nextToken();

            /**
             * If "Id" property comes next of "CCOM class" property in "from/To" Object, and parser failed in
             * "CCOM class" property, then we need to get "Id" property value by parsing remaining token in that object.
             */
            if (parser.getText().equalsIgnoreCase("id")) {
                parser.nextToken();
                placeHolders[1] = parser.getText();
            }
        }

        // If exception thrown at "from" object, then below loop will move the cursor to end of "To" object
        if (parent != null) {
            if (parent.toLowerCase(Locale.getDefault()).equals("from")) {
                parser.getCurrentToken();

                //Move parser cursor to "To" Array starting
                parser.nextToken();

                while (parser.getCurrentToken() != JsonToken.END_ARRAY) {
                    parser.nextToken();

                    if (parser.getText().equalsIgnoreCase("id")) {
                        parser.nextToken();
                        placeHolders[3] = parser.getText();
                    }
                    if (parser.getText().equalsIgnoreCase("ccomClass")) {
                        parser.nextToken();
                        placeHolders[4] = parser.getText();
                    }
                }
            } else if (parent.toLowerCase(Locale.getDefault()).equals("to")) {
                //Move parser cursor to "To" Array end
                parser.nextToken();
            }
        }

        List<Error> errorList = new ArrayList<>();

        // Create error message task for invalid CCOM class in "from" object
        if (!fromConnectionCcomClasses.contains(placeHolders[2])) {
            placeHolders[0] = placeHolders[2];
            try {
                processException(parser, placeHolders, ErrorConstants.INVALID_CCOM_CONNECTION, true);
            } catch (ValidationFailedException validationFailed) {
                log.error(validationFailed.getMessage(), validationFailed);
                errorList.add(validationFailed.getErrorCollection().get(0));
            }
        }

        // Create error message task for invalid CCOM class in "to" object
        if (!toConnectionCcomClasses.contains(placeHolders[4])) {
            String[] placeholder = Arrays.copyOf(placeHolders, placeHolders.length);
            placeholder[0] = placeholder[4];
            try {
                processException(parser, placeholder, ErrorConstants.INVALID_CCOM_CONNECTION, true);
            } catch (ValidationFailedException validationFailed) {
                log.error(validationFailed.getMessage(), validationFailed);
                errorList.add(validationFailed.getErrorCollection().get(0));
            }
        }

        throw new ValidationFailedException(errorList);
    }

    @Override
    public String supportedField() {
        return CONNECTIONS;
    }

    @Override
    public Class supportedClass() {
        return Connection.class;
    }
}
