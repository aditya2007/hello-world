/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonParser;
import org.apache.commons.lang.BooleanUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.adapter.s95.processor.IRootLevelProcessor;
import com.ge.apm.adapter.s95.processor.base.ObjectProcessor;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.agents.Agent;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.custom.PlaceholderConnection;
import com.ge.apm.ccom.model.custom.PlaceholderMesh;
import com.ge.apm.ccom.model.network.connections.ConnectionType;
import com.ge.apm.ccom.model.network.topologies.MeshType;
import com.ge.apm.common.util.IdGenerator;
import com.ge.apm.s95.model.Note;
import com.ge.apm.s95.model.Placeholder;
import com.ge.apm.s95.model.PlaceholderAssetTypeAssociation;
import com.ge.apm.s95.model.PlaceholderTagTypeAssociation;
import com.ge.apm.s95.model.TagExpression;
import com.ge.apm.s95.model.Template;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

import static com.ge.apm.ccom.model.CcomTypeHelper.wrapText;
import static com.ge.apm.ccom.model.CcomTypeHelper.wrapUUID;

@Component
public class TemplateProcessor extends ObjectProcessor<JsonParser> implements IRootLevelProcessor<JsonParser> {

    @Override
    public void process(JsonParser parser)
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {

        Template templateS95 = parser.readValueAs(Template.class);
        com.ge.apm.ccom.model.custom.Template templateCcom = new com.ge.apm.ccom.model.custom.Template();

        validateCcom(templateS95);
        processTemplateMetadata(templateCcom, templateS95);
        processBasicProperties(templateS95, templateCcom);
        processProperties(templateCcom, templateS95);
        processReservedProperties(templateCcom, templateS95);

        if (null != templateS95.getPlaceholders()) {
            processesPlaceholders(templateCcom, templateS95.getId(), templateS95.getPlaceholders(), null, null);
        }
        entityDispatcher.sendEntity(templateCcom, TEMPLATES);
    }

    private void processTemplateMetadata(com.ge.apm.ccom.model.custom.Template templateCcom, Template templateS95) {
        if (!StringUtils.isEmpty(templateS95.getRevision())) {
            templateCcom.setRevision(templateS95.getRevision());
        }

        List<com.ge.apm.ccom.model.custom.Note> ccomNotes = new ArrayList<>();
        List<Note> notes = templateS95.getNotes();
        if (notes != null && !notes.isEmpty()) {
            for (Note note : notes) {
                com.ge.apm.ccom.model.custom.Note ccomNote = new com.ge.apm.ccom.model.custom.Note();
                ccomNote.setGUID(wrapUUID(note.getId() != null ? note.getId() : IdGenerator.generateAsString()));
                ccomNote.setContent(note.getContent());

                Agent creator = new Agent();
                creator.setName(wrapText(note.getCreatedBy()));
                ccomNote.setCreator(creator);
                ccomNotes.add(ccomNote);
            }
        }

        templateCcom.setNotes(ccomNotes);
    }

    private final void processesPlaceholders(com.ge.apm.ccom.model.custom.Template templateCcom, String templateId,
        final List<Placeholder> placeholders, final com.ge.apm.ccom.model.custom.Placeholder parentPlaceholderCcom,
        final PlaceholderConnection phChildLinkFrom) throws ValidationFailedException {

        PlaceholderMesh placeholderMesh = new PlaceholderMesh();
        com.ge.apm.ccom.model.custom.Placeholder placeholderCcom = null;
        PlaceholderConnection phChildLink = null;

        for (Placeholder placeholder : placeholders) {

            placeholderCcom = new com.ge.apm.ccom.model.custom.Placeholder();

            //set the id of placeholder = <templateId>-<placeholderId>, both of them provided by user
            placeholder.setId(templateId + "-" + placeholder.getPlaceholderId());
            processBasicProperties(placeholder, placeholderCcom);
            processProperties(placeholderCcom, placeholder);
            processReservedProperties(placeholderCcom, placeholder);
            processAssociations(templateId, placeholderCcom, placeholder);
            processTagAssociations(placeholderCcom, placeholder);

            placeholderCcom.setPlaceholderId(CcomTypeHelper.wrapText(placeholder.getPlaceholderId()));

            phChildLink = new PlaceholderConnection();
            phChildLink.setType(new ConnectionType());
            phChildLink.setTo(parentPlaceholderCcom);
            phChildLink.setFrom(placeholderCcom);

            placeholderMesh.setType(new MeshType());
            placeholderMesh.getConnection().add(phChildLink);

            if (phChildLinkFrom != null) {
                phChildLinkFrom.setNetwork(placeholderMesh);
            }
            if (!isEmptyPlaceholder(placeholder)) {
                processesPlaceholders(templateCcom, templateId, placeholder.getPlaceholders(), placeholderCcom,
                    phChildLink);
            }
        }

        if (parentPlaceholderCcom == null) {
            templateCcom.getPlaceholderMeshes().add(placeholderMesh);
        }
    }

    private void processAssociations(final String templateId,
        final com.ge.apm.ccom.model.custom.Placeholder placeholderCcom, final Placeholder placeholder)
        throws ValidationFailedException {
        com.ge.apm.ccom.model.custom.PlaceholderAssetTypeAssociation associationCcom = null;
        Entity.Status status = null;
        for (PlaceholderAssetTypeAssociation placeholderAssetTypeAssociation : placeholder.getAssetTypeAssociations()) {
            associationCcom = new com.ge.apm.ccom.model.custom.PlaceholderAssetTypeAssociation();
            associationCcom.setAssociatedEntityId(wrapUUID(placeholderAssetTypeAssociation.getId()));
            associationCcom.setAssociatedEntityCcomClass(placeholderAssetTypeAssociation.getCcomClass());
            associationCcom.setPrimary(BooleanUtils.isTrue(placeholderAssetTypeAssociation.getIsPrimary()));
            status = new Entity.Status();
            status.setValue(placeholderAssetTypeAssociation.getStatus());
            associationCcom.setStatus(status);
            placeholderCcom.getAssetTypeAssociations().add(associationCcom);
        }
    }

    private void processTagAssociations(final com.ge.apm.ccom.model.custom.Placeholder placeholderCcom,
        final Placeholder placeholder) {
        com.ge.apm.ccom.model.custom.PlaceholderTagTypeAssociation associatedTagCcom = null;
        for (PlaceholderTagTypeAssociation placeholderAssociatedTag : placeholder.getTagTypeAssociations()) {
            associatedTagCcom = new com.ge.apm.ccom.model.custom.PlaceholderTagTypeAssociation();
            associatedTagCcom.setAssociatedEntityId(CcomTypeHelper.wrapUUID(placeholderAssociatedTag.getId()));
            associatedTagCcom.setAssociatedEntityCcomClass(placeholderAssociatedTag.getCcomClass());
            associatedTagCcom.setCategory(placeholderAssociatedTag.getCategory());

            if (!CollectionUtils.isEmpty(placeholderAssociatedTag.getTagExpressions())) {
                processTagExpressions(associatedTagCcom, placeholderAssociatedTag);
            }

            placeholderCcom.getTagTypeAssociations().add(associatedTagCcom);
        }
    }

    private void processTagExpressions(com.ge.apm.ccom.model.custom.PlaceholderTagTypeAssociation associatedTagCcom,
        PlaceholderTagTypeAssociation placeholderAssociatedTag) {
        associatedTagCcom.setTagExpressions(new ArrayList<>());
        com.ge.apm.ccom.model.custom.TagExpression tagExpressionCcom = null;
        for (TagExpression tagExpression : placeholderAssociatedTag.getTagExpressions()) {
            tagExpressionCcom = new com.ge.apm.ccom.model.custom.TagExpression();
            tagExpressionCcom.setIdExpr(tagExpression.getIdExpr());
            tagExpressionCcom.setNameExpr(tagExpression.getNameExpr());
            tagExpressionCcom.setTimeSeriesLinkExpr(tagExpression.getTimeSeriesLinkExpr());
            tagExpressionCcom.setRange(tagExpression.getRange());
            associatedTagCcom.getTagExpressions().add(tagExpressionCcom);
        }
    }

    private void validateCcom(Template templateS95) throws ValidationFailedException {
        MimosaCcomCategory ccom = templateS95.getCcomClass();
        if (ccom == null || ccom != MimosaCcomCategory.TEMPLATE) {
            List<Error> templateCcomErrorList = new ArrayList<>();
            Error sourceKeyError = new Error(Error.ErrorType.ERROR);

            String templateId = templateS95.getId();
            sourceKeyError.setErrorCode(ErrorConstants.MISSING_CCOM_TEMPLATE);
            sourceKeyError.setPlaceHolders(new String[] { ccom != null ? ccom.name() : "null", templateId });
            templateCcomErrorList.add(sourceKeyError);

            throw new ValidationFailedException(templateCcomErrorList);
        }
    }

    private boolean isEmptyPlaceholder(final Placeholder placeholder) {
        boolean isEmpty = true;

        if (null != placeholder.getPlaceholders()) {
            isEmpty = placeholder.getPlaceholders().isEmpty();
        }
        return isEmpty;
    }

    @Override
    public String supportedField() {
        return TEMPLATES;
    }

    @Override
    public Class supportedClass() {
        return Template.class;
    }
}
