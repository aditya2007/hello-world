/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.predicate;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by 502670744 on 10/23/17.
 */
@Component
@Slf4j
public class DownloadEnabledPredicate implements Predicate {

    @Value("${download.enabled}")
    private boolean enabled;

    @Override
    public boolean matches(Exchange exchange) {

        if (enabled) {
            return false;
        }
        return true;
    }

}

