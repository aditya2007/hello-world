/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.common.constants.AttributeTypes;
import com.ge.apm.adapter.s95.processor.IRootLevelProcessor;
import com.ge.apm.adapter.s95.processor.base.ObjectProcessor;
import com.ge.apm.asset.model.AttributeType;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.AttributableEntity;
import com.ge.apm.ccom.model.core.Attribute;
import com.ge.apm.ccom.model.core.UnitType;
import com.ge.apm.ccom.model.custom.MeasurementLocationCorrelation;
import com.ge.apm.ccom.model.measurements.locations.MeasurementLocation;
import com.ge.apm.ccom.model.measurements.locations.MeasurementLocationType;
import com.ge.apm.ccom.model.registry.Asset;
import com.ge.apm.ccom.model.registry.Enterprise;
import com.ge.apm.ccom.model.registry.MonitoredEntity;
import com.ge.apm.ccom.model.registry.Segment;
import com.ge.apm.ccom.model.registry.Site;
import com.ge.apm.s95.model.Tag;
import com.ge.apm.s95.model.TagAssociation;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
@Slf4j
@SuppressWarnings({ "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public class TagAssociationProcessor extends ObjectProcessor<JsonParser> implements IRootLevelProcessor<JsonParser> {

    private static void addFieldAsAttribute(AttributableEntity entity, String attributeType, String attributeName,
        Supplier<String[]> fieldGetter) {
        String[] value = fieldGetter.get();
        if (value != null) {
            for (int idx = 0; idx < value.length; idx++) {
                Attribute attribute = CcomTypeHelper.getAttribute(attributeType, idx);
                attribute.setName(CcomTypeHelper.wrapText(attributeName));
                attribute.setTag(CcomTypeHelper.wrapText(attributeName));
                CcomTypeHelper.wrapValueInValueContentV2(AttributeType.String.name(), null, value[idx],
                    attribute.getValueContent(), null);
                entity.getAttribute().add(attribute);
            }
        }
    }

    @Override
    public void process(JsonParser parser)
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        try {
            TagAssociation ta = parser.readValueAs(TagAssociation.class);

            processMissingMonitoredEntityId(ta);
            processMissingMonitoredEntityCcomClass(ta);

            if (ta.getMonitoredEntity().getCcomClass() == MimosaCcomCategory.ENTERPRISE) {
                processForEnterprise(ta);
            } else if (ta.getMonitoredEntity().getCcomClass() == MimosaCcomCategory.SITE) {
                processForSite(ta);
            } else if (ta.getMonitoredEntity().getCcomClass() == MimosaCcomCategory.SEGMENT) {
                processForSegment(ta);
            } else if (ta.getMonitoredEntity().getCcomClass() == MimosaCcomCategory.ASSET) {
                processForAsset(ta);
            }
        } catch (InvalidFormatException formatException) {
            log.error(formatException.getMessage(), formatException);
            String[] placeHolders = new String[5];
            placeHolders[0] = parser.getText();

            if (formatException.getPath() != null && formatException.getPath().get(0) != null
                && formatException.getPath().get(0).getFrom() != null) {
                TagAssociation errSrc = (TagAssociation) formatException.getPath().get(0).getFrom();
                if (errSrc != null && errSrc.getMonitoredEntity() != null) {
                    placeHolders[1] = errSrc.getMonitoredEntity().getId();
                }
            }

            String parsedId = handleInvalidCcomClass(parser);
            if (placeHolders[1] == null) {
                placeHolders[1] = parsedId;
            }
            processMonitoredEntityCcomClassException(parser, placeHolders,
                ErrorConstants.INVALID_CCOM_MONITORED_ENTITY);
        }
    }

    private void processMissingMonitoredEntityId(TagAssociation ta) throws ValidationFailedException {
        if (ta.getMonitoredEntity().getId() == null || ta.getMonitoredEntity().getId().length() == 0) {
            List<Error> idErrorList = new ArrayList<>();
            Error idError = new Error(Error.ErrorType.ERROR);

            String tagId = (ta.getTags().length > 0 && ta.getTags()[0].getId() != null) ? ta.getTags()[0].getId() : "";

            idError.setErrorCode(ErrorConstants.MISSING_MONITORED_ENTITY_ID);
            idError.setPlaceHolders(new String[] { String.valueOf(ta.getTags().length), tagId });
            idErrorList.add(idError);

            throw new ValidationFailedException(idErrorList);
        }
    }

    private void processMissingMonitoredEntityCcomClass(TagAssociation ta) throws ValidationFailedException {
        if (ta.getMonitoredEntity().getCcomClass() == null) {
            List<Error> ccomClassErrorList = new ArrayList<>();
            Error ccomClassError = new Error(Error.ErrorType.ERROR);

            String tagId = (ta.getTags().length > 0 && ta.getTags()[0].getId() != null) ? ta.getTags()[0].getId() : "";

            ccomClassError.setErrorCode(ErrorConstants.MISSING_MONITORED_ENTITY_CCOMCLASS);
            ccomClassError.setPlaceHolders(new String[] { String.valueOf(ta.getTags().length), tagId });
            ccomClassErrorList.add(ccomClassError);

            throw new ValidationFailedException(ccomClassErrorList);
        }
    }

    private void processMonitoredEntityCcomClassException(JsonParser parser, String[] placeHolders, String errorCode)
        throws ValidationFailedException, IOException {
        Error error = new Error(Error.ErrorType.ERROR);
        error.setErrorCode(errorCode);

        // move to the end of monitoredEntity, in case we add more attributes
        while (parser.getCurrentToken() != JsonToken.END_OBJECT) {
            parser.nextToken();
        }

        // skip tags if needed
        parser.nextToken();
        if ("tags".equals(parser.getText())) {
            parser.nextToken(); // move to START_OBJECT first in order to skip
            parser.skipChildren();
            parser.nextToken(); // move to END_OBJECT
        }

        error.setPlaceHolders(placeHolders);
        List<Error> errorList = new ArrayList<>();
        errorList.add(error);

        throw new ValidationFailedException(errorList);
    }

    private void processForEnterprise(TagAssociation ta) {
        Enterprise enterprise = new Enterprise();
        CcomTypeHelper.setUuidAndTag(enterprise, ta.getMonitoredEntity().getId());
        processForMonitoredEntity(ta, enterprise);
    }

    private void processForSite(TagAssociation ta) {
        Site site = new Site();
        CcomTypeHelper.setUuidAndTag(site, ta.getMonitoredEntity().getId());
        processForMonitoredEntity(ta, site);
    }

    private void processForSegment(TagAssociation ta) {
        Segment segment = new Segment();
        CcomTypeHelper.setUuidAndTag(segment, ta.getMonitoredEntity().getId());
        processForMonitoredEntity(ta, segment);
    }

    private void processForAsset(TagAssociation ta) {
        Asset asset = new Asset();
        CcomTypeHelper.setUuidAndTag(asset, ta.getMonitoredEntity().getId());
        processForMonitoredEntity(ta, asset);
    }

    private void processForMonitoredEntity(TagAssociation ta, MonitoredEntity me) {
        for (Tag tag : ta.getTags()) {
            MeasurementLocation ml = getMeasurementLocation(tag);
            ml.setMonitoredEntity(me);
            entityDispatcher.sendEntity(ml, this.supportedField());
        }
    }

    private MeasurementLocation getMeasurementLocation(Tag ta) {
        MeasurementLocation ml = new MeasurementLocation();
        if (ta.getName() != null) {
            ml.setName(CcomTypeHelper.wrapText(ta.getName()));
        }
        if (ta.getDescription() != null) {
            CcomTypeHelper.addAttribute(ml, "description", AttributeTypes.DESCRIPTION, ta.getDescription());
        }

        ml.setTag(CcomTypeHelper.wrapText(ta.getId()));
        ml.setType(new MeasurementLocationType());
        CcomTypeHelper.setUuidAndTag(ml.getType(), ta.getClassification());
        ml.setDefaultUnitType(new UnitType());

        addFieldAsAttribute(ml, AttributeTypes.ALIAS, MeasurementTag.Aliases, ta::getAliases);

        if (ta.getNextRelatedTag() != null) {
            MeasurementLocationCorrelation measurementLocationCorrelation = new MeasurementLocationCorrelation();
            measurementLocationCorrelation.setId(ta.getNextRelatedTag().getId());
            ml.setMeasurementLocationCorrelation(measurementLocationCorrelation);
        }

        processProperties(ml, ta);
        processReservedProperties(ml, ta);
        return ml;
    }

    @Override
    public String supportedField() {
        return TAG_ASSOCIATIONS;
    }

    @Override
    public Class supportedClass() {
        return TagAssociation.class;
    }
}
