/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.scheduled;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.eclipse.persistence.exceptions.DatabaseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.common.constants.TaskStatus;
import com.ge.apm.adapter.domain.persistence.entity.IngestionLogMsg;
import com.ge.apm.adapter.domain.persistence.repository.IIngestionLogMsgRepository;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.datasource.TenantDataSourceService;
import com.ge.asset.commons.errorprovider.AssetError;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

/**
 * Created by 212576241 on 4/25/17.
 */
@Component
@Slf4j
public class DownloadTaskStatusJob {

    @Autowired
    ITaskProcessorRepository taskProcessorRepository;

    @Autowired
    IIngestionLogMsgRepository ingestionLogMsgRepository;

    @Value("${scheduled.download.task.status.cleanup.when.older.than.min}")
    private int obsoleteWhenOlderThanMin;

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    @Autowired
    private TenantDataSourceService tenantDataSourceService;

    @Scheduled(cron = " ${download.cron.job.recurrence}")
    public void cancelStaleTasks() {

        for (String tenantId : getDatabases()) {
            RequestContext.put(RequestContext.TENANT_UUID, tenantId);
            try {
                Date expired = new Date(System.currentTimeMillis() - 60000L * obsoleteWhenOlderThanMin);

                List<String> taskIds = taskProcessorRepository.getStaleDownloadTasksUuid(expired,
                    TaskStatus.IN_PROGRESS, TaskStatus.QUEUED);

                int tasksUpdated = taskProcessorRepository.cleanUpStaleDownloadTasks(TaskStatus.ERROR, expired,
                    TaskStatus.IN_PROGRESS, TaskStatus.QUEUED);
                if (tasksUpdated > 0) {
                    List<IngestionLogMsg> ingestionLogMsgs = new LinkedList<>();
                    AssetError assetError = ErrorProvider.findError(ErrorConstants.TASK_INACTIVE_FAILED_DOWNLOAD);
                    taskIds.forEach(taskId -> ingestionLogMsgs.add(createLogsMsgForStaleTask(taskId, assetError)));
                    ingestionLogMsgRepository.save(ingestionLogMsgs);
                }
                if (log.isDebugEnabled()) {
                    log.debug("Cleaned up {} tasks with status older than {}.", tasksUpdated, sdf.format(expired));
                }
            } catch (DatabaseException dbe) {
                log.error("Unable to finalize stale tasks!", dbe);
            }
        }
    }

    private IngestionLogMsg createLogsMsgForStaleTask(String taskUuid, AssetError assetError) {
        IngestionLogMsg ilg = new IngestionLogMsg();
        ilg.setTaskUuid(taskUuid);
        ilg.setMsg(assetError.getMsg());
        ilg.setAction(assetError.getAction());
        ilg.setResolution(assetError.getResolution());
        ilg.setMsgType(assetError.getMsgType());
        ilg.setMsgCode(assetError.getMsgCode());
        return ilg;
    }

    private HashSet<String> getDatabases() {
        HashSet<String> set = new HashSet<>();
        set.add(TenantDataSourceService.DEFAULT_DATASOURCE);
        set.addAll(tenantDataSourceService.getTenants());
        return set;
    }
}
