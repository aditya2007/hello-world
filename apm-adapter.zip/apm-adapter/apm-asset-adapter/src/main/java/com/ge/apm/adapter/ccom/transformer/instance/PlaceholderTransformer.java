/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.CcomClassNameMappingEnum;
import com.ge.apm.adapter.ccom.transformer.DtoQueueHolder;
import com.ge.apm.adapter.ccom.transformer.EntityTransformerFactory;
import com.ge.apm.adapter.ccom.transformer.IEntityTransformer;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.adapter.common.constants.AttributeTypes;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.core.Attribute;
import com.ge.apm.ccom.model.custom.Placeholder;
import com.ge.apm.ccom.model.custom.PlaceholderAssetTypeAssociation;
import com.ge.apm.ccom.model.custom.PlaceholderTagTypeAssociation;
import com.ge.apm.ccom.model.custom.ReservedAttribute;
import com.ge.apm.ccom.model.custom.TagExpression;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.validator.ValidationFailedException;

import static com.ge.apm.asset.model.PlaceholderTagTypeAssociation.CATEGORY;

/**
 * Transformer for Placeholder. It only converts CCOM Placeholder object to DTO
 */
@Component
@Slf4j
public class PlaceholderTransformer extends DtoQueueHolder<com.ge.apm.asset.model.Placeholder>
    implements IEntityTransformer<Placeholder> {

    private transient com.ge.apm.asset.model.Placeholder placeholderDto;

    @Autowired
    public PlaceholderTransformer(AssetClient assetClient) {
        super(assetClient, com.ge.apm.asset.model.Placeholder.class);
    }

    public com.ge.apm.asset.model.Placeholder getPlaceholderDto() {
        return placeholderDto;
    }

    @Override
    public TransformResponse transform(Placeholder placeholder) throws ServiceException, ValidationFailedException {

        placeholderDto = new com.ge.apm.asset.model.Placeholder();

        baseValidateSourceKey(placeholder.getGUID().getValue(),
            CcomClassNameMappingEnum.getSimpleJsonNodeNameFromEnum(placeholderDto.getClass().getSimpleName()),
            placeholder.getName().getValue());

        validateName(placeholder.getName().getValue(),
            CcomClassNameMappingEnum.getSimpleJsonNodeNameFromEnum(placeholderDto.getClass().getSimpleName()),
            placeholder.getGUID().getValue());

        /*
         * Only Template update operation needs to set Placeholder URI,
         * we will not find Placeholder URI here, Asset API will find its URI based on sourceKey
         */
        placeholderDto.setSourceKey(placeholder.getGUID().getValue());

        placeholderDto.setName(placeholder.getName().getValue());
        if (placeholder.getPlaceholderId() != null) {
            placeholderDto.setPlaceholderId(placeholder.getPlaceholderId().getValue());
        }

        convertPlaceholderAssetTypeAssociations(placeholder);
        convertPlaceholderTagTypeAssociations(placeholder);

        Map<String, List<Attribute>> attributeTypeMap = CcomTypeHelper.getAttributeTypeMap(placeholder);
        List<Attribute> description = attributeTypeMap.remove(AttributeTypes.DESCRIPTION);
        if (description != null) {
            placeholderDto.setDescription(description.get(0).getValueContent().getText().getValue());
        }

        //Process all the regular properties
        processRegularProperties(attributeTypeMap);

        TransformResponse transformResponse = new TransformResponse();

        //Process all the reservedAttributes
        //convertEntity to Map of ReservedAttributes
        Map<String, List<ReservedAttribute>> reservedAttributeTypeMap = CcomTypeHelper.getReservedAttributeTypeMap(
            placeholder);

        processReservedProperties(reservedAttributeTypeMap);

        if (transformResponse.getWarnings() != null && transformResponse.getWarnings().size() > 0) {
            transformResponse.setStatus(TransformResponse.EntityResponseStatus.CREATEDWITHWARNINGS);
        } else {
            transformResponse.setStatus(TransformResponse.EntityResponseStatus.OK);
        }

        return transformResponse;
    }

    private void processReservedProperties(Map<String, List<ReservedAttribute>> reservedAttributeTypeMap) {

        //Convert the List of reservedAttributes to Map<String, Object>
        if (reservedAttributeTypeMap != null && !reservedAttributeTypeMap.isEmpty()) {
            @SuppressWarnings("unchecked") Map<String, Object> reservedAttributeTypeObjectMap = new HashedMap();
            reservedAttributeTypeMap.forEach((name, reservedAttributeList) -> {
                //Map<String, Object> reservedAttributeMap = new HashMap<>();
                Object attrValue = EntityTransformerFactory.extractReservedAttributeValues(reservedAttributeList);
                reservedAttributeTypeObjectMap.put(name, attrValue);
            });
            placeholderDto.setReservedAttributes(reservedAttributeTypeObjectMap);
        }
    }

    private void processRegularProperties(Map<String, List<Attribute>> attributeTypeMap) {
        LinkedHashMap<String, com.ge.apm.asset.model.Attribute> attributeDtoMap = EntityTransformerFactory
            .getAttributeMap(attributeTypeMap);

        if (attributeDtoMap == null || attributeDtoMap.isEmpty()) {
            placeholderDto.setAttributes(new LinkedHashMap<>());
        } else {
            placeholderDto.setAttributes(attributeDtoMap);
        }
    }

    private void convertPlaceholderAssetTypeAssociations(Placeholder placeholder) throws ValidationFailedException {
        List<PlaceholderAssetTypeAssociation> associations = placeholder.getAssetTypeAssociations();

        if (associations != null && !associations.isEmpty()) {
            List<com.ge.apm.asset.model.PlaceholderAssetTypeAssociation> associationDtos = new ArrayList<>();
            com.ge.apm.asset.model.PlaceholderAssetTypeAssociation associationDto = null;
            for (PlaceholderAssetTypeAssociation association : associations) {
                associationDto = new com.ge.apm.asset.model.PlaceholderAssetTypeAssociation();
                String category = association.getAssociatedEntityCcomClass() != null ? association
                    .getAssociatedEntityCcomClass().name() : "";
                String sourceKey = association.getAssociatedEntityId().getValue() != null ? association
                    .getAssociatedEntityId().getValue() : "";

                String prefix = StringUtils.isEmpty(category) ? "" : Prefixes.getPrefixByCategory(category) ;
                String entityUri = prefix + "/" + sourceKey;
                associationDto.setEntityUri(entityUri);
                if (entityUri.startsWith(Prefixes.AssetTypes)) {
                    associationDto.setIsPrimary(association.getPrimary());
                }
                associationDto.setStatus(association.getStatus().getValue());
                associationDtos.add(associationDto);
            }
            placeholderDto.setAssetTypeAssociations(associationDtos);
        }
    }

    private void convertPlaceholderTagTypeAssociations(Placeholder placeholder) throws ValidationFailedException {
        List<PlaceholderTagTypeAssociation> tagAssociations = placeholder.getTagTypeAssociations();
        if (tagAssociations != null && !tagAssociations.isEmpty()) {
            List<com.ge.apm.asset.model.PlaceholderTagTypeAssociation> tagAssociationDtos = new ArrayList<>();
            com.ge.apm.asset.model.PlaceholderTagTypeAssociation tagAssociationDto = null;
            for (PlaceholderTagTypeAssociation tagAssociation : tagAssociations) {
                tagAssociationDto = new com.ge.apm.asset.model.PlaceholderTagTypeAssociation();
                String category = tagAssociation.getAssociatedEntityCcomClass() != null ? tagAssociation
                    .getAssociatedEntityCcomClass().name() : "";
                String sourceKey = tagAssociation.getAssociatedEntityId().getValue() != null ? tagAssociation
                    .getAssociatedEntityId().getValue() : "";

                String prefix = StringUtils.isEmpty(category) ? "" : Prefixes.getPrefixByCategory(category) ;
                String entityUri = prefix + "/" + sourceKey;
                tagAssociationDto.setEntityUri(entityUri);
                if (tagAssociation.getCategory() != null) {
                    tagAssociationDto.setCategory(CATEGORY.valueOf(tagAssociation.getCategory()));
                }

                if (!CollectionUtils.isEmpty(tagAssociation.getTagExpressions())) {
                    tagAssociationDto.setTagExpressions(new ArrayList<>());
                    com.ge.apm.asset.model.TagExpression tagExpressionDto = null;
                    for (TagExpression tagExpression : tagAssociation.getTagExpressions()) {
                        tagExpressionDto = new com.ge.apm.asset.model.TagExpression();
                        tagExpressionDto.setIdExpr(tagExpression.getIdExpr());
                        tagExpressionDto.setNameExpr(tagExpression.getNameExpr());
                        tagExpressionDto.setTimeSeriesLinkExpr(tagExpression.getTimeSeriesLinkExpr());
                        tagExpressionDto.setRange(tagExpression.getRange());

                        tagAssociationDto.getTagExpressions().add(tagExpressionDto);
                    }
                }
                tagAssociationDtos.add(tagAssociationDto);
            }
            placeholderDto.setTagTypeAssociations(tagAssociationDtos);
        }
    }

    @Override
    protected String getPrefix() {
        return Prefixes.Placeholders;
    }

    @Override
    public int order() {
        return Priority.placeholder.priority();
    }

    @Override
    public Class<Placeholder> supportedCcomClass() {
        return null;
    }

    @Override
    public boolean supportsFailFast() {
        return false;
    }
}
