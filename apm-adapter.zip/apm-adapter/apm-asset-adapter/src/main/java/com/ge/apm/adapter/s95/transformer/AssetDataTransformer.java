/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.transformer;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.MappingJsonFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.common.util.IEntityDispatcher;
import com.ge.apm.adapter.s95.processor.S95DataProcessor;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.ValidationFailedException;
import com.ge.asset.commons.validator.ValidationResult;
import com.ge.asset.commons.validator.Validator;

@Component
@Slf4j
public class AssetDataTransformer {

    @Autowired
    protected IEntityDispatcher entityDispatcher;

    @Autowired
    protected S95DataProcessor s95DataProcessor;

    private Validator validator = null;

    public void transform(Exchange exchange)
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        Map<String, Object> headers = new HashMap<>();
        headers.put(MessageConstants.ADAPTER_UUID,
            exchange.getIn().getHeader(MessageConstants.ADAPTER_UUID, String.class));
        headers.put(MessageConstants.TASK_UUID, exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class));
        headers.put(MessageConstants.AUTHORIZATION,
            exchange.getIn().getHeader(MessageConstants.AUTHORIZATION, "", String.class));

        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        if (tenantUuid == null) {
            throw new IllegalStateException("Tenant not found");
        }
        headers.put(MessageConstants.TENANT_UUID, tenantUuid);

        String traceUuid = exchange.getIn().getHeader(MessageConstants.TRACE_UUID, String.class);
        headers.put(MessageConstants.TRACE_UUID, traceUuid);

        RequestContext.put(RequestContext.X_TENANT, traceUuid);

        MDC.put("X-B3-TraceId", traceUuid);
        MDC.put("tenant", tenantUuid);

        entityDispatcher.initialize(headers);

        String batchSizeString = exchange.getIn().getHeader(MessageConstants.BATCH_SIZE, String.class);
        String fileName = exchange.getIn().getHeader(MessageConstants.FILE_NAME, String.class);

        int batchSize = 1;
        try {
            batchSize = Integer.parseInt(batchSizeString);
        } catch (Exception ex) {
            //Ignore errors
            log.error(ex.getMessage(), ex);
        }

        RequestContext.put(S95DataProcessor.BATCH_SIZE, batchSize);
        try (InputStream input = exchange.getIn().getBody(InputStream.class); Scanner scanner = new Scanner(input)) {
            if (validator == null) {
                validator = new Validator("json-validation", null);
            }

            scanner.useDelimiter("\\A");
            String inputJson = scanner.hasNext() ? scanner.next() : "";

            ValidationResult validationResponse = validator.validate(inputJson);

            if (validationResponse.isValid()) {
                invokeProcess(inputJson, tenantUuid);
            } else {
                validationResponse.getErrors().stream().forEach(error -> {
                    String[] placeHolders = error.getPlaceHolders();
                    placeHolders[0] = fileName;
                    error.setPlaceHolders(placeHolders);
                });
                throw new ValidationFailedException(validationResponse.getErrors());
            }
        } finally {
            RequestContext.remove(S95DataProcessor.BATCH_SIZE);
        }

        exchange.getOut().setHeaders(headers);
        exchange.getOut().setBody(null);
    }

    public void setValidator(Validator validator) {
        this.validator = validator;
    }

    private void invokeProcess(final String inputJson, String tenantUuid)
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        Reader isr = new StringReader(inputJson);
        try (JsonParser parser = new MappingJsonFactory().createParser(isr)) {
            s95DataProcessor.process(parser, tenantUuid);
        }
    }
}
