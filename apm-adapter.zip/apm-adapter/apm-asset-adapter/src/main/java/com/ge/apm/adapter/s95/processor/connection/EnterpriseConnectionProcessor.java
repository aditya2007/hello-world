/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.connection;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.HierarchicalLink;
import com.ge.apm.ccom.model.network.connections.ConnectionType;
import com.ge.apm.ccom.model.network.connections.EnterpriseConnection;
import com.ge.apm.ccom.model.registry.Enterprise;
import com.ge.apm.s95.model.ToNode;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
public class EnterpriseConnectionProcessor extends ConnectionObjectProcessor<Enterprise> {

    public EnterpriseConnectionProcessor() {
        super(MimosaCcomCategory.ENTERPRISE, Enterprise.class);
    }

    @Override
    protected void processParentToNode(Enterprise enterprise, ToNode toNode) throws ValidationFailedException {
        if (toNode.getCcomClass() != MimosaCcomCategory.ENTERPRISE) {
            Error error = new Error(Error.ErrorType.ERROR);
            if (toNode.getCcomClass().name().equals(MimosaCcomCategory.SITE.name())) {
                error.setErrorCode(ErrorConstants.INVALID_PARENT_SITE_FOR_ENTERPRISE);
            } else if (toNode.getCcomClass().name().equals(MimosaCcomCategory.SEGMENT.name())) {
                error.setErrorCode(ErrorConstants.INVALID_PARENT_SEGMENT_FOR_ENTERPRISE);
            } else if (toNode.getCcomClass().name().equals(MimosaCcomCategory.ASSET.name())) {
                error.setErrorCode(ErrorConstants.INVALID_PARENT_ASSET_FOR_ENTERPRISE);
            } else {
                error.setErrorCode(ErrorConstants.INVALID_PARENT_FOR_ENTERPRISE);
            }
            error.setPlaceHolders(
                new String[] { enterprise.getGUID().getValue(), enterprise.getClass().getSimpleName(), toNode.getId(),
                    toNode.getCcomClass().name() });
            List<Error> errorList = new ArrayList<>();
            errorList.add(error);
            throw new ValidationFailedException(errorList);
        } else {
            HierarchicalLink hierarchicalLink = new HierarchicalLink();
            Enterprise parent = new Enterprise();
            CcomTypeHelper.setUuidAndTag(parent, toNode.getId());
            hierarchicalLink.setParent(parent);
            enterprise.getParentLink().add(hierarchicalLink);
        }
        /*if (toNode.getCcomClass() == MimosaCcomCategory.ENTERPRISE) {
            Enterprise parentEnterprise = new Enterprise();
            CcomTypeHelper.setUuidAndTag(parentEnterprise, toNode.getId());
            enterprise.setRegistrationEnterprise(parentEnterprise);
        }*/

    }

    @Override
    protected void addConnectionForToNode(Enterprise enterprise, ToNode toNode) {
        if (toNode.getCcomClass() != MimosaCcomCategory.ENTERPRISE) {
            throw new IllegalStateException(
                "Invalid connection: " + toNode + ". Enterprise can be connected to Enterprise only");
        }
        EnterpriseConnection enterpriseConnection = new EnterpriseConnection();
        enterpriseConnection.setType(new ConnectionType());
        enterpriseConnection.getType().setName(CcomTypeHelper.wrapText(toNode.getType()));
        enterpriseConnection.setTo(new Enterprise());
        enterpriseConnection.getTo().setGUID(CcomTypeHelper.wrapUUID(toNode.getId()));
        enterprise.getToConnection().add(enterpriseConnection);
    }
}
