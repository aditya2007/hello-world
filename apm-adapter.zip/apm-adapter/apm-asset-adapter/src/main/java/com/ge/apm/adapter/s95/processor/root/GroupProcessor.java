/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.s95.processor.IRootLevelProcessor;
import com.ge.apm.adapter.s95.processor.base.ObjectProcessor;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.s95.model.Group;
import com.ge.apm.s95.model.Instance;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

import static com.ge.apm.ccom.model.MimosaCcomCategory.GROUP;

@Component
@Slf4j
@SuppressWarnings({ "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public class GroupProcessor extends ObjectProcessor<JsonParser> implements IRootLevelProcessor<JsonParser> {

    @Override
    public void process(JsonParser parser) throws IOException, ValidationFailedException {
        Group tgS95 = null;
        try {
            tgS95 = parser.readValueAs(Group.class);
            validateSourceKey(tgS95);
            validateCcomGroup(tgS95.getCcomClass());
            validateAssociatedEntityCcomClass(tgS95);
            com.ge.apm.ccom.model.groups.Group tgCcom = new com.ge.apm.ccom.model.groups.Group();
            processBasicProperties(tgS95, tgCcom);
            processProperties(tgCcom, tgS95);
            tgCcom.setAssociatedEntityCcomClass(tgS95.getAssociatedEntityCcomClass());
            entityDispatcher.sendEntity(tgCcom, GROUPS);

            String[] associatedEntityIds = (tgS95.getAssociatedEntityIds()) == null ? new String[0]
                : tgS95.getAssociatedEntityIds();
            // send one group association object for each associated entity
            for (String tagId : associatedEntityIds) {
                com.ge.apm.ccom.model.groups.GroupAssociation tgaCcom
                    = new com.ge.apm.ccom.model.groups.GroupAssociation();

                // set entity fields
                tgaCcom.setAssociatedEntityId(CcomTypeHelper.wrapUUID(tagId));
                tgaCcom.setAssociatedEntityCcomClass(tgS95.getAssociatedEntityCcomClass());

                // set group field
                tgaCcom.setGroupId(CcomTypeHelper.wrapUUID(tgS95.getId()));

                entityDispatcher.sendEntity(tgaCcom, GROUPS);
            }
            /*
             * Process mapping/association of group with instances
             */
            processMappingOfAssetAndGroup(tgS95.getId(), tgS95.getMappedInstances());
        } catch (InvalidFormatException formatException) {
            log.error(formatException.getMessage(), formatException);
            String[] placeHolders = new String[5];
            placeHolders[0] = parser.getText();
            String errorCode = ErrorConstants.INVALID_CCOM_GROUP;

            if (formatException.getPath() != null) {
                if (formatException.getPath().get(0) != null && formatException.getPath().get(0).getFrom() != null) {
                    placeHolders[1] = ((Group) formatException.getPath().get(0).getFrom()).getId();
                }
                if (formatException.getPath().get(0) != null && formatException.getPath().get(0).getFieldName() != null
                    && formatException.getPath().get(0).getFieldName().equals("associatedEntityCcomClass")) {
                    errorCode = ErrorConstants.INVALID_ASSOCIATED_ENTITY_CCOM_GROUP;
                }
            }

            String parsedId = handleInvalidCcomClass(parser);
            if (placeHolders[1] == null) {
                placeHolders[1] = parsedId;
            }
            processException(parser, placeHolders, errorCode, true);
        } catch (IllegalStateException illegalStateException) {
            String errConstant = illegalStateException.getMessage();
            log.error(errConstant, illegalStateException);
            if (tgS95 != null) {
                processException(parser,
                    new String[] { tgS95.getCcomClass() == null ? tgS95.getId() : tgS95.getCcomClass().name(),
                        tgS95.getId() }, errConstant, false);
            }
        }
    }

    private void processMappingOfAssetAndGroup(String groupId, Instance[] mappedAssets) {
        if (mappedAssets != null) {
            for (Instance instance : mappedAssets) {
                com.ge.apm.ccom.model.groups.InstanceGroupMap assetGrpAndInstanceMappingCcom
                    = new com.ge.apm.ccom.model.groups.InstanceGroupMap();

                // set entity fields
                assetGrpAndInstanceMappingCcom.setEntityId(CcomTypeHelper.wrapUUID(instance.getId()));
                assetGrpAndInstanceMappingCcom.setEntityCcomClass(instance.getCcomClass());

                // set group field
                assetGrpAndInstanceMappingCcom.setGroupId(CcomTypeHelper.wrapUUID(groupId));

                entityDispatcher.sendEntity(assetGrpAndInstanceMappingCcom, GROUPS);
            }
        }
    }

    @Override
    public String supportedField() {
        return GROUPS;
    }

    @Override
    public Class supportedClass() {
        return Group.class;
    }

    private void validateSourceKey(Group g) throws ValidationFailedException {

        if (g.getId() == null || g.getId().length() == 0) {
            List<Error> sourceKeyErrorList = new ArrayList<>();
            Error sourceKeyError = new Error(Error.ErrorType.ERROR);

            String groupName = g.getName();
            sourceKeyError.setErrorCode(ErrorConstants.GROUP_ID_MISSING_CODE);
            sourceKeyError.setPlaceHolders(new String[] { groupName });
            sourceKeyErrorList.add(sourceKeyError);

            throw new ValidationFailedException(sourceKeyErrorList);
        }
    }

    private void validateCcomGroup(MimosaCcomCategory ccom) {
        if (ccom == null) {
            throw new IllegalStateException(ErrorConstants.MISSING_CCOM_GROUP);
        }
        if (ccom != GROUP) {
            throw new IllegalStateException(ErrorConstants.INVALID_CCOM_GROUP);
        }
    }

    private void validateAssociatedEntityCcomClass(Group g) throws ValidationFailedException {

        if (g.getAssociatedEntityCcomClass() == null || g.getAssociatedEntityCcomClass().toString().length() == 0) {
            List<Error> associatedCcomErrorList = new ArrayList<>();
            Error sourceKeyError = new Error(Error.ErrorType.ERROR);

            String groupName = g.getName();
            sourceKeyError.setErrorCode(ErrorConstants.MISSING_ASSOCIATED_ENTITY_CCOM_GROUP);
            sourceKeyError.setPlaceHolders(new String[] { groupName });
            associatedCcomErrorList.add(sourceKeyError);
            throw new ValidationFailedException(associatedCcomErrorList);
        }
    }
}
