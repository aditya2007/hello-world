/********************************************************************************
 * Copyright \(c\) 2015-2017 GE Digital. All rights reserved.                   *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import javax.sql.DataSource;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.util.StopWatch;

import com.ge.apm.common.support.RequestContext;
import com.ge.apm.datasource.TenantDataSourceService;

@Slf4j
@Configuration
@EnableAsync
public class DatabaseInit implements HealthIndicator {

    @Autowired
    public DatabaseInit(DataSource dataSource, TenantDataSourceService tenantDataSourceService) {
        this.dataSource = dataSource;
        this.tenantDataSourceService = tenantDataSourceService;
    }

    private final DataSource dataSource;

    private final TenantDataSourceService tenantDataSourceService;

    public static final String ERROR_EXECUTING_FLYWAY_MIGRATION = "Error executing flyway migration";

    private Status status = new Status("INIT");

    private final StartupStatus details = new StartupStatus();

    @Override
    public Health health() {
        return Health.status(status).withDetail("details", details).build();
    }

    @Async
    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationEvent(final ApplicationReadyEvent event) {
        try {
            log.info("Initializing Application");
            ArrayList<String> list = new ArrayList<>();
            list.add(TenantDataSourceService.DEFAULT_DATASOURCE);
            list.addAll(tenantDataSourceService.getTenants());

            List<Callable<Optional<Void>>> tasks = new ArrayList<>();
            list.forEach(e -> {
                tasks.add(new FlywayMigration(e, dataSource));
                if (StringUtils.equalsIgnoreCase(e, TenantDataSourceService.DEFAULT_DATASOURCE)) {
                    details.setStatus(status);
                } else {
                    details.addTenant(e, status);
                }
            });

            ExecutorService executor = Executors.newFixedThreadPool(10);

            List<Future<Optional<Void>>> results;
            try {
                results = executor.invokeAll(tasks);
            } catch (Exception excp1) {
                log.error("Error executing flyway migration", excp1);
                status = Status.OUT_OF_SERVICE;
                throw new BeanInitializationException("Error in flyway migration ", excp1);
            }

            try {
                executor.shutdown();
                if (!executor.awaitTermination(30, TimeUnit.SECONDS)) {
                    log.error("Flyway migration jobs did not complete within 30 seconds");
                    status = Status.OUT_OF_SERVICE;
                    throw new BeanInitializationException("Flyway migration jobs did not complete within 30 seconds");
                }
            } catch (Exception excp2) {
                log.error(ERROR_EXECUTING_FLYWAY_MIGRATION, excp2);
                throw new BeanInitializationException(ERROR_EXECUTING_FLYWAY_MIGRATION, excp2);
            }

            for (Future result : results) {
                try {
                    result.get();
                } catch (Exception excp3) {
                    status = Status.OUT_OF_SERVICE;
                    log.error(ERROR_EXECUTING_FLYWAY_MIGRATION, excp3);
                    throw new BeanInitializationException(ERROR_EXECUTING_FLYWAY_MIGRATION, excp3);
                }
            }
            status = Status.UP;
        } finally {
            RequestContext.destroy();
        }
    }

    private class FlywayMigration implements Callable<Optional<Void>> {

        private final String tenantId;

        private final DataSource dataSource;

        FlywayMigration(String tenantId, DataSource dataSource) {
            this.tenantId = tenantId;
            this.dataSource = dataSource;
        }

        @Override
        public Optional<Void> call() throws Exception {
            StopWatch watch = new StopWatch();
            try {
                watch.start();
                log.info(String.format("Executing flyway migration for tenant=%s", tenantId));
                RequestContext.put(RequestContext.TENANT_UUID, tenantId);
                Flyway flyway = new Flyway();
                flyway.setBaselineOnMigrate(false);
                flyway.setSchemas("apm_adapter");
                flyway.setLocations("classpath:db/migration");
                flyway.setDataSource(dataSource);
                flyway.migrate();
                if (StringUtils.equalsIgnoreCase(tenantId, TenantDataSourceService.DEFAULT_DATASOURCE)) {
                    details.setStatus(Status.UP);
                } else {
                    details.setStatus(tenantId, Status.UP);
                }
                return Optional.empty();
            } catch (Exception ex) {
                if (StringUtils.equalsIgnoreCase(tenantId, TenantDataSourceService.DEFAULT_DATASOURCE)) {
                    details.setStatus(Status.OUT_OF_SERVICE);
                    details.setDescription(ExceptionUtils.getStackTrace(ex));
                } else {
                    details.setStatus(tenantId, Status.OUT_OF_SERVICE, ExceptionUtils.getStackTrace(ex));
                }
                throw ex;
            } finally {
                watch.stop();
                log.info(String.format("Flyway migration for Tenant=%s executionTime(mSec) = %s", tenantId,
                    watch.getTotalTimeMillis()));
                RequestContext.destroy();
            }
        }
    }

    @Getter
    @Setter
    class StartupStatus {

        HashMap<String, String> sharedDB = new HashMap<>();

        ArrayList<TenantStatus> tenants = new ArrayList<>();

        void addTenant(String tenantId, Status status) {
            tenants.add(new TenantStatus(tenantId, status.getCode()));
        }

        void setStatus(Status status) {
            sharedDB.put("status", status.getCode());
        }

        void setDescription(String description) {
            sharedDB.put("description", description);
        }

        void setStatus(String tenantId, Status status) {
            this.setStatus(tenantId, status, "");
        }

        void setStatus(String tenantId, Status status, String description) {
            for (TenantStatus tenant : tenants) {
                if (StringUtils.equalsIgnoreCase(tenant.getTenantId(), tenantId)) {
                    tenant.setStatus(status.getCode());
                    tenant.setDescription(description);
                }
            }
        }
    }

    @Getter
    @Setter
    class TenantStatus {

        TenantStatus(String tenantId, String status) {
            this.tenantId = tenantId;
            this.status = status;
        }

        final String tenantId;

        String status;

        String description = "";
    }
}
