/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.config;

import java.io.InputStream;
import java.net.ConnectException;
import java.net.UnknownHostException;
import java.util.LinkedHashMap;
import java.util.Map;

import com.rabbitmq.client.AlreadyClosedException;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.component.rabbitmq.RabbitMQConstants;
import org.apache.camel.model.DataFormatDefinition;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.dataformat.SerializationDataFormat;
import org.apache.openjpa.lib.jdbc.ReportingSQLException;
import org.apache.openjpa.persistence.PersistenceException;
import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.common.config.AdapterRouteBuilder;
import com.ge.apm.adapter.common.config.AdapterRoutes;
import com.ge.apm.adapter.common.packer.AssetPacker;
import com.ge.apm.adapter.common.processor.AttachmentProcessor;
import com.ge.apm.adapter.common.processor.DownloadTaskProcessor;
import com.ge.apm.adapter.common.processor.DownloadTypeProcessor;
import com.ge.apm.adapter.common.processor.FileExtensionProcessor;
import com.ge.apm.adapter.common.processor.RestHeaderProcessor;
import com.ge.apm.adapter.common.processor.RestResponseProcessor;
import com.ge.apm.adapter.common.processor.TenantUuidProcessor;
import com.ge.apm.adapter.common.processor.UploadTaskProcessor;
import com.ge.apm.adapter.common.util.EntityDispatcher;
import com.ge.apm.adapter.config.TenantContextBean;
import com.ge.apm.adapter.s95.processor.exception.EntityExceptionProcessor;
import com.ge.apm.adapter.s95.processor.mq.FileProcessor;
import com.ge.apm.adapter.s95.processor.predicate.DownloadEnabledPredicate;
import com.ge.apm.adapter.s95.processor.predicate.DownloadTaskPredicate;
import com.ge.apm.adapter.s95.processor.predicate.FileChecksumPredicate;
import com.ge.apm.adapter.s95.transformer.AssetDataTransformer;
import com.ge.apm.asset.model.DownloadTask;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.mq.util.CryptoHelper;

@Component
public class S95AdapterRouteBuilder extends AdapterRouteBuilder {

    protected final DataFormatDefinition byteArrayDataFormat;

    private final AssetDataTransformer assetDataTransformer;

    @Value("${entity.dispatcher.batchSize:1000}")
    private Integer batchSize;

    @Value("${rabbitmq.concurrentVirtualConsumers}")
    private Integer virtualConsumerCount;

    @Autowired
    private AttachmentProcessor attachmentProcessor;

    @Autowired
    private TenantUuidProcessor tenantUuidProcessor;

    @Autowired
    private UploadTaskProcessor uploadTaskProcessor;

    @Autowired
    private DownloadTaskProcessor downloadTaskProcessor;

    @Autowired
    private RestHeaderProcessor restHeaderProcessor;

    @Autowired
    private AssetPacker assetPacker;

    @Autowired
    private EntityExceptionProcessor entityExceptionProcessor;

    @Autowired
    private FileChecksumPredicate fileChecksumPredicate;

    @Autowired
    private FileExtensionProcessor fileExtensionProcessor;

    @Autowired
    private DownloadTypeProcessor downloadTypeProcessor;

    @Autowired
    private FileProcessor fileProcessor;

    @Autowired
    private EntityDispatcher entityDispatcher;

    @Autowired
    private DownloadTaskPredicate downloadTaskPredicate;

    @Autowired
    private DownloadEnabledPredicate downloadEnabledPredicate;

    @Autowired
    private TenantContextBean tenantContextBean;

    @Autowired
    public S95AdapterRouteBuilder(AssetDataTransformer assetDataTransformer,
        CryptoHelper cryptoHelper) {
        super(S95AdapterRoutes.S95_APP_ID, cryptoHelper);
        this.assetDataTransformer = assetDataTransformer;
        this.byteArrayDataFormat = new SerializationDataFormat();
    }

    private static Map<String, Object> getErrors(ValidationException e) {
        Map<String, Object> error = new LinkedHashMap<>();
        error.put("message", e.getMessage());
        Object[] errors = e.getCausingExceptions().stream()
            .map(S95AdapterRouteBuilder::getErrors).toArray();
        if (errors.length > 0) {
            error.put("errors", errors);
        }
        return error;
    }

    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void configure() throws Exception {

        super.configure();

        validateRoute();

        uploadAndDownloadFiles();

        queueAssetsRoute();

        queueExport();

        ackQueueExport();

        processAssetsRoute();

        handleErrors();

    }

    /**
     * The cxf servlet will never route to this method as the uri mapping is /v1/asset/*
     * As such, the /v1/schema/validate endpoint is now deprecated.
     */
    private void validateRoute() {
        from(S95AdapterRoutes.CXFRS_VALIDATE_DATA)
            .setExchangePattern(ExchangePattern.InOut)
            .process(attachmentProcessor)
            .process(exchange -> {
                Map<String, Object> response;
                try (InputStream inputStream = getClass().getResourceAsStream("/s95-json-schema.json")) {
                    JSONObject rawSchema = new JSONObject(new JSONTokener(inputStream));
                    Schema schema = SchemaLoader.load(rawSchema);
                    InputStream fileStream = exchange.getIn().getBody(InputStream.class);
                    schema.validate(new JSONObject(new JSONTokener(fileStream)));

                    response = new LinkedHashMap<>();
                    response.put("status", "VALID");
                } catch (ValidationException ex) {
                    response = getErrors(ex);
                    response.put("status", "INVALID");
                }
                exchange.getOut().setBody(response);
            })
            .to(getRestResponseEndpoint());
    }

    private void queueAssetsRoute() {
        from(S95AdapterRoutes.CXFRS_FILE_UPLOAD)
            // call the route based on the operation invoked on the REST web service
            .recipientList(simple("direct:${header.operationName}"));

        from("direct:upload")
            .doTry()
                .setExchangePattern(ExchangePattern.InOut)
                .setHeader(MessageConstants.AUTHORIZATION).simple("${headers.Authorization}")
                .setHeader(MessageConstants.FILE_SIZE).simple("${headers[Content-Length]}")
                .setHeader(MessageConstants.OPERATION_NAME).simple("uploadAssets")

                .to(getEnrichEndpoint())
                .process(attachmentProcessor)
                .process(tenantUuidProcessor)

                .setHeader(MessageConstants.DESCRIPTION)
                .simple("Upload S95 assets from zip file: ${headers.CamelFileName}, "
                    + "size: ${headers.ApmFileSize} bytes.")

                .bean(uploadTaskProcessor, queueTask())
                .to(String.format(S95AdapterRoutes.DIRECT_ZIP_FILE_VALIDATE_AND_PROCESS, appId))
            .doCatch(AlreadyClosedException.class, ConnectException.class, UnknownHostException.class)
                .to(getHeaderDecryptorEndpoint())
                .bean(entityExceptionProcessor, rabbitmqException())
                .bean(uploadTaskProcessor, taskError())
            .doCatch(PersistenceException.class, ReportingSQLException.class)
                .bean(entityExceptionProcessor, postgresException())
                .bean(uploadTaskProcessor, taskError())
            .doFinally()
                .bean(uploadTaskProcessor, fetchTask())
                .bean(uploadTaskProcessor, "transformTask")
                .bean(RestResponseProcessor.class, "createResponse")
            .end();

        from(String.format(S95AdapterRoutes.DIRECT_ZIP_FILE_VALIDATE_AND_PROCESS, appId)).streamCaching()
                .choice()
                    .when().method(fileExtensionProcessor, "invalidZipFileExtension")
                        .bean(uploadTaskProcessor, taskError())
                    .when().method(fileExtensionProcessor, "zipFileSizeLimitExceeded")
                        .bean(uploadTaskProcessor, taskError())
                    .when(fileChecksumPredicate)
                        .bean(uploadTaskProcessor, markSkippedTask())
                        .log("Skipped processing task ${headers.ApmTaskUuid}")
                    .otherwise()
                        .to(String.format(S95AdapterRoutes.DIRECT_FILE_UPLOAD, appId))
                        .process(restHeaderProcessor)
                        .to(getHeaderEncryptorEndpoint())
                        .to(getRabbitmqEndpoint(S95AdapterRoutes.RMQ_TASK, S95AdapterRoutes.RMQ_TASK_ROUTING_KEY))
                        .to(getHeaderDecryptorEndpoint())
                .end();
    }

    private void processAssetsRoute() {

        from(String.format(S95AdapterRoutes.DIRECT_ASSET_FILES, appId))
            .bean(entityDispatcher, "initializeConnections")
            .split(body()).streaming()
            .choice()
            .when().method(fileExtensionProcessor, "invalidJsonExtensionOrBody")
                .log("Cannot process S95 assets file ${headers.CamelFileName} because it is not a json file")
            .otherwise()
                .doTry()
                    .setHeader(MessageConstants.DESCRIPTION)
                    .simple("Process S95 assets file: ${headers.CamelFileName}")
                    .setHeader(MessageConstants.FILE_NAME).simple("${headers.CamelFileName}")
                    .bean(uploadTaskProcessor, inProgressTask())
                    .setHeader(MessageConstants.BATCH_SIZE).constant(getBatchSize())
                    .bean(assetDataTransformer, "transform")
                    .bean(uploadTaskProcessor, markDoneProcessingTask())
                .doCatch(AlreadyClosedException.class, ConnectException.class)
                    .bean(entityExceptionProcessor, rabbitmqException())
                    .bean(uploadTaskProcessor, taskError())
                .doCatch(PersistenceException.class)
                    .bean(entityExceptionProcessor, postgresException())
                    .bean(uploadTaskProcessor, taskError())
                .doCatch(ReportingSQLException.class)
                    .bean(entityExceptionProcessor, postgresException())
                    .bean(uploadTaskProcessor, taskError())
                .doCatch(Exception.class)
                    .log("Exception caught in direct_asset_files endpoint.")
                    .bean(uploadTaskProcessor, markDoneProcessingTask())
                    .bean(uploadTaskProcessor, createAndMarkTaskError())
                .end()
            .end();

        from(String.format(S95AdapterRoutes.DIRECT_ZIP_FILE_PROCESSING, appId))
            .to(getHeaderDecryptorEndpoint())
            .to(String.format(S95AdapterRoutes.DIRECT_FILE_DOWNLOAD, appId))
            .bean(uploadTaskProcessor, markInProgressTask())
            .unmarshal(zipFileDataFormat)
            .to(String.format(S95AdapterRoutes.DIRECT_ASSET_FILES, appId))
            .bean(entityDispatcher, "forceSendConnections")
            .choice()
            .when().method(fileExtensionProcessor, "containsAtLeastOneJson")
            .bean(uploadTaskProcessor, markDoneProcessingTask())
            .otherwise()
                .log("Cannot process S95 assets file ${headers.CamelFileName} because it does not contain a json")
                .bean(uploadTaskProcessor, taskError())
            .end();

        from(getRabbitmqEndpoint(S95AdapterRoutes.RMQ_TASK, S95AdapterRoutes.RMQ_TASK_ROUTING_KEY)).doTry().bean(
            tenantContextBean, "init")
                .to(String.format(S95AdapterRoutes.DIRECT_ZIP_FILE_PROCESSING, appId))
            .doCatch(AlreadyClosedException.class, ConnectException.class)
                .bean(entityExceptionProcessor, rabbitmqException())
                .bean(uploadTaskProcessor, taskError())
            .doCatch(PersistenceException.class)
                .bean(entityExceptionProcessor, postgresException())
                .bean(uploadTaskProcessor, taskError())
            .doCatch(ReportingSQLException.class)
                .bean(entityExceptionProcessor, postgresException())
                .bean(uploadTaskProcessor, taskError())
            .doCatch(Exception.class).log("Exception caught in rmq_task endpoint.").to(
            String.format(AdapterRoutes.LOG_TASK_ERROR, appId)).doFinally().bean(tenantContextBean, "destroy")
            .end();
    }

    private void handleErrors() {
        from(S95AdapterRoutes.DIRECT_ASSET_ERROR).process(entityExceptionProcessor).end();
    }

    private void queueExport() {
        from("direct:download")
            .setExchangePattern(ExchangePattern.InOut)
            .setHeader(MessageConstants.AUTHORIZATION).simple("${headers.Authorization}")
            .setHeader(MessageConstants.OPERATION_NAME).simple("download")
            .setHeader(MessageConstants.DESCRIPTION)
            .simple("Download tenant classifications to zip file")
            .process(tenantUuidProcessor)
            .process(downloadTypeProcessor)
            .choice().when(downloadEnabledPredicate)
            .process(restHeaderProcessor)
            .bean(RestResponseProcessor.class, "disableResponse")
            .when(downloadTaskPredicate)
            .bean(downloadTaskProcessor, markSkippedTask())
            .process(restHeaderProcessor)
            .bean(RestResponseProcessor.class, "createResponse")
            .log("Skipped processing download task ${headers.ApmTaskUuid}")
            .otherwise()
            .doTry()
            .bean(downloadTaskProcessor, inProgressTask())
            .bean(downloadTaskProcessor, fetchTask())
            .bean(downloadTaskProcessor, "transformToDownloadTask")
            .process(restHeaderProcessor)
            .to(getHeaderEncryptorEndpoint())
            .marshal().json(JsonLibrary.Gson)
            .to(getRabbitmqEndpoint(S95AdapterRoutes.RMQ_DOWNLOAD_TASK,
                S95AdapterRoutes.RMQ_DOWNLOAD_TASK_ROUTING_KEY))
            .to(getHeaderDecryptorEndpoint())
            .bean(downloadTaskProcessor, fetchTask())
            .bean(downloadTaskProcessor, transformTask())
            .bean(RestResponseProcessor.class, createResponse())
            .doCatch(AlreadyClosedException.class, ConnectException.class,
                UnknownHostException.class)
            .bean(entityExceptionProcessor, rabbitmqException())
            .bean(downloadTaskProcessor, taskError())
            .doCatch(PersistenceException.class, ReportingSQLException.class)
            .bean(entityExceptionProcessor, postgresException())
            .bean(downloadTaskProcessor, taskError())
            .doCatch(ServiceException.class, Exception.class)
            .bean(RestResponseProcessor.class, createResponse())
            .doFinally()
            .end();
    }

    private void ackQueueExport() {

        from(getRabbitmqCustomEndpoint(S95AdapterRoutes.RMQ_ASSET_DOWNLAOD_ACK,
            S95AdapterRoutes.RMQ_ASSET_DOWNLAOD_ACK_ROUTING_KEY, virtualConsumerCount)).doTry().bean(tenantContextBean,
            "init")
            .to(getHeaderDecryptorEndpoint())
            .log("Received Ack for download: ${headers.ApmTaskUuid}")
            .choice()
            .when(header(RabbitMQConstants.ROUTING_KEY)
                .isEqualTo(S95AdapterRoutes.RMQ_ASSET_DOWNLAOD_ACK_COMPLETE_ROUTING_KEY))
            .unmarshal()
            .json(JsonLibrary.Gson, DownloadTask.class)
            .bean(downloadTaskProcessor, markCompletedTask())
            .otherwise()
            .unmarshal(zipDataFormat)
            .unmarshal(byteArrayDataFormat)
            .to(String.format(S95AdapterRoutes.LOG_TASK_ERROR, appId)).setHeader(Exchange.EXCEPTION_CAUGHT,
            body(Throwable.class)).bean(downloadTaskProcessor, taskError()).endDoTry().doFinally().bean(
            tenantContextBean, "destroy").end();
    }

    private void uploadAndDownloadFiles() {
        from(String.format(S95AdapterRoutes.DIRECT_FILE_UPLOAD, appId))
                .doTry()
                    .setHeader("parentEntityType").simple("AssetTask")
                    .bean(fileProcessor, "uploadFile")
                .doCatch(Exception.class)
                    .bean(uploadTaskProcessor, taskError())
                    .bean(uploadTaskProcessor, fetchTask())
                    .bean(uploadTaskProcessor, "transformTask")
                    .to(getRestResponseEndpoint())
                    .stop()
                .end();

        from(String.format(S95AdapterRoutes.DIRECT_FILE_DOWNLOAD, appId))
                .doTry()
                    .bean(fileProcessor, "downloadFile")
                .doCatch(Exception.class)
                    .bean(uploadTaskProcessor, taskError())
                    .stop()
                .end();
    }

    private int getBatchSize() {
        return this.batchSize;
    }
}
