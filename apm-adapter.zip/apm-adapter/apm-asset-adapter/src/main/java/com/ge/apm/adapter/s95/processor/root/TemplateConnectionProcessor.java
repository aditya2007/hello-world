/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonParser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ge.apm.adapter.s95.processor.IRootLevelProcessor;
import com.ge.apm.adapter.s95.processor.base.ObjectProcessor;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.s95.model.AssetPlaceholderConnection;
import com.ge.apm.s95.model.TemplateConnection;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
public class TemplateConnectionProcessor extends ObjectProcessor<JsonParser>
    implements IRootLevelProcessor<JsonParser> {

    public static final String CONNECTIONS = "connections";

    public static final String CONNECTION_ID = "id";

    public static final String PLACEHOLDER_ID = "placeholderId";

    public static final String CCOM_CLASS = "ccomClass";

    @Value("${template.remove.maxAssets:250}")
    private Integer maxAssetsRemoveCount;

    public TemplateConnectionProcessor() {
        super();
    }

    @Override
    public void process(JsonParser parser)
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {

        //TODO - Disabling template feature Q2 2017 release
        //throw new IllegalAccessException("Template feature not supported");

        TemplateConnection templateS95 = parser.readValueAs(TemplateConnection.class);
        com.ge.apm.ccom.model.custom.TemplateConnection templateConnectionCcom
            = new com.ge.apm.ccom.model.custom.TemplateConnection();

        validateTemplateConnection(templateS95);
        processMetadata(templateConnectionCcom, templateS95);
        processConnections(templateConnectionCcom, templateS95);

        entityDispatcher.sendEntity(templateConnectionCcom, TEMPLATE_CONNECTIONS);
    }

    private void processMetadata(com.ge.apm.ccom.model.custom.TemplateConnection templateConnectionCcom,
        TemplateConnection templateConnectionS95) {
        templateConnectionCcom.setTemplateId(templateConnectionS95.getTemplateId());
        if (!StringUtils.isEmpty(templateConnectionS95.getParentEntityId())) {
            templateConnectionCcom.setParentEntityId(templateConnectionS95.getParentEntityId());
            templateConnectionCcom.setParentEntityCcomClass(templateConnectionS95.getParentEntityCcomClass());
        }
    }

    private void processConnections(com.ge.apm.ccom.model.custom.TemplateConnection templateConnectionCcom,
        TemplateConnection templateConnectionS95) {
        List<AssetPlaceholderConnection> connections = templateConnectionS95.getConnections();
        List<com.ge.apm.ccom.model.custom.AssetPlaceholderConnection> ccomConnections = new ArrayList<>();
        for (AssetPlaceholderConnection connection : connections) {
            com.ge.apm.ccom.model.custom.AssetPlaceholderConnection ccomConnection
                = new com.ge.apm.ccom.model.custom.AssetPlaceholderConnection();
            ccomConnection.setId(connection.getId());
            ccomConnection.setPlaceholderId(connection.getPlaceholderId());

            ccomConnections.add(ccomConnection);
        }

        templateConnectionCcom.setConnections(ccomConnections);
    }

    private void validateTemplateConnection(TemplateConnection templateConnectionS95) throws ValidationFailedException {
        String templateId = templateConnectionS95.getTemplateId();
        if (StringUtils.isEmpty(templateId)) {
            missingRequiredFields(ErrorConstants.TEMPLATE_CONNECTIONS_FIELD_MISSING,
                new String[] { "N/A", "templateId" });
        }

        String parentEntityId = templateConnectionS95.getParentEntityId();
        MimosaCcomCategory ccomCategory = templateConnectionS95.getParentEntityCcomClass();
        if (!StringUtils.isEmpty(parentEntityId) && ccomCategory == null) {
            invalidParentForAsset("null", parentEntityId);
        }

        boolean allowedCategories = ccomCategory == MimosaCcomCategory.ASSET
            || ccomCategory == MimosaCcomCategory.SEGMENT || ccomCategory == MimosaCcomCategory.SITE;
        if (!StringUtils.isEmpty(parentEntityId) && ccomCategory != null && !allowedCategories) {
            invalidParentForAsset(ccomCategory.name(), parentEntityId);
        }

        validateConnections(templateConnectionS95, templateId);
    }

    private void validateConnections(TemplateConnection templateConnectionS95, String templateId)
        throws ValidationFailedException {
        StringBuilder missingFields = new StringBuilder();
        List<AssetPlaceholderConnection> connections = templateConnectionS95.getConnections();
        if (connections == null || connections.isEmpty()) {
            missingFields.append(CONNECTIONS).append(' ');
        } else {
            validateConnection(missingFields, connections, templateId);
        }

        if (!missingFields.toString().isEmpty()) {
            missingRequiredFields(ErrorConstants.TEMPLATE_CONNECTIONS_FIELD_MISSING,
                new String[] { templateId, missingFields.toString() });
        }
    }

    private boolean isAllIdsEmpty(List<AssetPlaceholderConnection> connections) {
        for (AssetPlaceholderConnection connection : connections) {
            if (!StringUtils.isEmpty(connection.getId())) {
                return false;
            }
        }
        return true;
    }

    private void validateConnection(StringBuilder missingFields, List<AssetPlaceholderConnection> connections,
        String templateId) throws ValidationFailedException {

        boolean isRemovalOperation = isAllIdsEmpty(connections);

        List<Error> invalidCcomClassInTemplateConnections = new ArrayList<>();

        // for removal operation, then all ID should be not, and placehoderId should not be null
        if (isRemovalOperation) {
            if (connections.size() > maxAssetsRemoveCount) {
                missingRequiredFields(ErrorConstants.CANNOT_REMOVE_MORE_THAN_COUNT,
                    new String[] { templateId, String.valueOf(maxAssetsRemoveCount) });
            } else {
                boolean isPlaceholderIdMissing = false;
                for (AssetPlaceholderConnection connection : connections) {
                    if (StringUtils.isEmpty(connection.getPlaceholderId())) {
                        isPlaceholderIdMissing = true;
                    }
                }
                if (isPlaceholderIdMissing) {
                    missingFields.append(PLACEHOLDER_ID).append(' ');
                }
            }
        } else {
            boolean isConnectionIdMissing = false;
            boolean isPlaceholderIdMissing = false;
            boolean isCcomClassMissing = false;
            Error error;
            //for creation & replacement operations, id & placeholderId are required
            for (AssetPlaceholderConnection connection : connections) {
                if (StringUtils.isEmpty(connection.getId())) {
                    isConnectionIdMissing = true;
                }
                if (StringUtils.isEmpty(connection.getPlaceholderId())) {
                    isPlaceholderIdMissing = true;
                }
                if (StringUtils.isEmpty(connection.getCcomClass())) {
                    isCcomClassMissing = true;
                } else if (connection.getCcomClass() != MimosaCcomCategory.ASSET) {
                    error = new Error(Error.ErrorType.ERROR, ErrorConstants.INVALID_CCOM_TEMPLATE_CONNECTIONS);
                    error.setPlaceHolders(new String[] { connection.getCcomClass().name(), connection.getId(),
                        connection.getPlaceholderId() });
                    invalidCcomClassInTemplateConnections.add(error);
                }
            }

            if (isConnectionIdMissing) {
                missingFields.append(CONNECTION_ID).append(' ');
            }

            if (isPlaceholderIdMissing) {
                missingFields.append(PLACEHOLDER_ID).append(' ');
            }

            if (isCcomClassMissing) {
                missingFields.append(CCOM_CLASS).append(' ');
            }

            if (invalidCcomClassInTemplateConnections.size() > 0 ) {
                throw new ValidationFailedException(invalidCcomClassInTemplateConnections);
            }
        }
    }

    private void invalidParentForAsset(String ccomCategory, String parentEntityId) throws ValidationFailedException {
        List<Error> templateConnectionsErrorList = new ArrayList<>();
        Error invalidParentError = new Error(Error.ErrorType.ERROR);

        invalidParentError.setErrorCode(ErrorConstants.INVALID_PARENT_FOR_ASSET);
        invalidParentError.setPlaceHolders(new String[] { ccomCategory, parentEntityId });
        templateConnectionsErrorList.add(invalidParentError);

        throw new ValidationFailedException(templateConnectionsErrorList);
    }

    private void missingRequiredFields(String errorCode, String[] placeHolders) throws ValidationFailedException {
        List<Error> templateConnectionsErrorList = new ArrayList<>();
        Error missingFieldError = new Error(Error.ErrorType.ERROR);

        missingFieldError.setErrorCode(errorCode);
        missingFieldError.setPlaceHolders(placeHolders);
        templateConnectionsErrorList.add(missingFieldError);

        throw new ValidationFailedException(templateConnectionsErrorList);
    }

    @Override
    public String supportedField() {
        return TEMPLATE_CONNECTIONS;
    }

    @Override
    public Class supportedClass() {
        return TemplateConnection.class;
    }
}
