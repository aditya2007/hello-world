/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.EntityTransformerFactory;
import com.ge.apm.adapter.ccom.transformer.IEntityTransformer;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.adapter.common.constants.AttributeTypes;
import com.ge.apm.asset.model.AttributeType;
import com.ge.apm.asset.model.DataSourceType;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.NextCorrelatedTag;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.core.Attribute;
import com.ge.apm.ccom.model.custom.MeasurementLocationCorrelation;
import com.ge.apm.ccom.model.custom.ReservedAttribute;
import com.ge.apm.ccom.model.measurements.locations.MeasurementLocation;
import com.ge.apm.ccom.model.registry.Asset;
import com.ge.apm.ccom.model.registry.Enterprise;
import com.ge.apm.ccom.model.registry.Segment;
import com.ge.apm.ccom.model.registry.Site;
import com.ge.apm.common.exception.DefaultErrorCode;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
@Slf4j
@SuppressWarnings({ "PMD.GodClass", "PMD.TooManyMethods" })
public class MeasurementLocationTransformer implements IEntityTransformer<MeasurementLocation> {

    private final AssetClient assetClient;

    private final ThreadLocal<Map<String, List<MeasurementTag>>> tagDtos;

    @Autowired
    public MeasurementLocationTransformer(AssetClient assetClient) {
        this.assetClient = assetClient;
        this.tagDtos = new ThreadLocal<Map<String, List<MeasurementTag>>>() {
            @Override
            protected Map<String, List<MeasurementTag>> initialValue() {
                return new HashMap<>();
            }
        };
    }

    @Override
    public TransformResponse transform(MeasurementLocation entity) throws ServiceException, ValidationFailedException {
        MeasurementLocation measurementLocation = entity;
        validateSourceKey(measurementLocation);
        transformMeasurementLocation(measurementLocation);

        TransformResponse transformResponse = new TransformResponse();
        if (transformResponse.getWarnings() != null && transformResponse.getWarnings().size() > 0) {
            transformResponse.setStatus(TransformResponse.EntityResponseStatus.CREATEDWITHWARNINGS);
        } else {
            transformResponse.setStatus(TransformResponse.EntityResponseStatus.OK);
        }

        return transformResponse;
    }

    @Override
    public void doDispatch() throws ServiceException {
        List<String> monitoredEntityUris = new ArrayList<>(tagDtos.get().keySet());
        StringBuilder exceptionString = new StringBuilder();

        // Create all tags with batch POST to APM Asset
        // Take care of tag correlation check on asset side - create correlated tag if it does not exist yet
        monitoredEntityUris.forEach(monitoredEntityUri -> {
            try {
                List<MeasurementTag> value = tagDtos.get().remove(monitoredEntityUri);
                assetClient.associateTag(monitoredEntityUri, value.toArray(new MeasurementTag[value.size()]));
            } catch (Exception ex) {
                log.error("Failed to associate tags for " + monitoredEntityUri, ex);
                exceptionString.append("Failed to associate tags for ").append(monitoredEntityUri).append(ex).append(
                    ". ");
            }
        });

        if (exceptionString.length() > 0) {
            throw new ServiceException(
                DefaultErrorCode.create("INVALID_MEASUREMENT_LOCATION", exceptionString.toString()));
        }
    }

    private void transformMeasurementLocation(MeasurementLocation measurementLocation) {
        String monitoredEntityPrefix = "";
        if (measurementLocation.getMonitoredEntity() instanceof Segment) {
            monitoredEntityPrefix = Prefixes.Segments;
        } else if (measurementLocation.getMonitoredEntity() instanceof Asset) {
            monitoredEntityPrefix = Prefixes.Assets;
        } else if (measurementLocation.getMonitoredEntity() instanceof Site) {
            monitoredEntityPrefix = Prefixes.Sites;
        } else if (measurementLocation.getMonitoredEntity() instanceof Enterprise) {
            monitoredEntityPrefix = Prefixes.Enterprises;
        }

        String monitoredEntitySourceKey = monitoredEntityPrefix + "/" + measurementLocation.getMonitoredEntity()
            .getGUID().getValue();
        transformInternal(measurementLocation, monitoredEntitySourceKey);
    }

    public void transformForSite(String siteSourceKey, List<MeasurementLocation> measurementLocations,
        TransformResponse transformResponse) {
        List<Error> allWarnings = new ArrayList<>();
        measurementLocations.forEach(ml -> {
            List<Error> warnings = new ArrayList<>();
            transformInternal(ml, siteSourceKey);
            if (warnings.size() > 0) {
                allWarnings.addAll(warnings);
            }
        });
        if (transformResponse.getWarnings() != null && transformResponse.getWarnings().size() > 0) {
            allWarnings.addAll(transformResponse.getWarnings());
        }
        transformResponse.setWarnings(allWarnings);
    }

    private void transformInternal(MeasurementLocation measurementLocation, String monitoredEntitySourceKey) {
        MeasurementTag tagDto = new MeasurementTag();
        if (measurementLocation.getName() != null) {
            tagDto.setName(measurementLocation.getName().getValue());
        }

        tagDto.setSourceKey(measurementLocation.getTag().getValue());
        tagDto.setType(measurementLocation.getType().getGUID().getValue());

        tagDto.setMonitoredEntitySourceKey(monitoredEntitySourceKey);

        Map<String, List<Attribute>> attributeTypeMap = CcomTypeHelper.getAttributeTypeMap(measurementLocation);
        List<Attribute> description = attributeTypeMap.remove(AttributeTypes.DESCRIPTION);
        if (description != null) {
            tagDto.setDescription(description.get(0).getValueContent().getText().getValue());
        }

        //Process all the regular properties
        processRegularProperties(tagDto, attributeTypeMap);

        //convertEntity to Map of ReservedAttributes
        Map<String, List<ReservedAttribute>> reservedAttributeTypeMap = CcomTypeHelper.getReservedAttributeTypeMap(
            measurementLocation);

        processReservedProperties(tagDto, reservedAttributeTypeMap);

        //Add the tag correlation directly to the tag dto
        MeasurementLocationCorrelation correlation = measurementLocation.getMeasurementLocationCorrelation();
        if (correlation != null) {
            NextCorrelatedTag nextCorrelatedTagDto = new NextCorrelatedTag();
            nextCorrelatedTagDto.setTagUri(correlation.getId());
            tagDto.setNextRelatedTag(nextCorrelatedTagDto);
        }

        if (!tagDtos.get().containsKey(monitoredEntitySourceKey)) {
            tagDtos.get().put(monitoredEntitySourceKey, new ArrayList<>());
        }
        tagDtos.get().get(monitoredEntitySourceKey).add(tagDto);
    }

    private void processReservedProperties(MeasurementTag tagDto,
        Map<String, List<ReservedAttribute>> reservedAttributeTypeMap) {

        //Convert the List of reservedAttributes to Map<String, Object>
        if (reservedAttributeTypeMap != null && !reservedAttributeTypeMap.isEmpty()) {
            @SuppressWarnings("unchecked") Map<String, Object> reservedAttributeTypeObjectMap = new HashedMap();
            reservedAttributeTypeMap.forEach((name, reservedAttributeList) -> {
                Object attrValue = EntityTransformerFactory.extractReservedAttributeValues(reservedAttributeList);
                reservedAttributeTypeObjectMap.put(name, attrValue);
            });
            tagDto.setReservedAttributes(reservedAttributeTypeObjectMap);
        }
    }

    private void processRegularProperties(MeasurementTag tagDto, Map<String, List<Attribute>> attributeTypeMap) {
        LinkedHashMap<String, com.ge.apm.asset.model.Attribute> attributeDtoMap = EntityTransformerFactory
            .getAttributeMap(attributeTypeMap);

        DataSourceType dataSourceType = DataSourceType.SENSOR;
        if (attributeDtoMap.containsKey("isComputed")) {
            com.ge.apm.asset.model.Attribute isComputed = attributeDtoMap.remove("isComputed");
            if (Boolean.TRUE.equals(isComputed.getValue().get(0))) {
                dataSourceType = DataSourceType.COMPUTED;
            }
        }
        if (attributeDtoMap.containsKey(MeasurementTag.Aliases)) {
            com.ge.apm.asset.model.Attribute aliases = attributeDtoMap.remove(MeasurementTag.Aliases);
            if (AttributeType.String.name().equalsIgnoreCase(aliases.getType())) {
                tagDto.setAliases(aliases.getValue().stream().map(Object::toString).toArray(String[]::new));
            }
        }
        tagDto.setTagType(dataSourceType);

        if (attributeDtoMap.isEmpty()) {
            tagDto.setAttributes(new LinkedHashMap<>());
        } else {
            tagDto.setAttributes(attributeDtoMap);
        }
    }

    @Override
    public int order() {
        return Priority.measurementLocation.priority();
    }

    @Override
    public Class<MeasurementLocation> supportedCcomClass() {
        return MeasurementLocation.class;
    }

    private void validateSourceKey(MeasurementLocation measurementLocation) throws ValidationFailedException {
        if (measurementLocation.getTag() == null || measurementLocation.getTag().getValue() == null
            || measurementLocation.getTag().getValue().length() == 0) {

            List<Error> sourceKeyErrorList = new ArrayList<>();
            Error sourceKeyError = new Error(Error.ErrorType.ERROR);

            String entityName = measurementLocation.getName().getValue();
            String monitoredEntitySourceKey = measurementLocation.getMonitoredEntity().getGUID().getValue();

            sourceKeyError.setErrorCode(ErrorConstants.TAG_ID_MISSING_CODE);
            sourceKeyError.setPlaceHolders(new String[] { entityName, monitoredEntitySourceKey });
            sourceKeyErrorList.add(sourceKeyError);

            throw new ValidationFailedException(sourceKeyErrorList);
        }

        if (measurementLocation.getType() == null || measurementLocation.getType().getGUID() == null
            || measurementLocation.getType().getGUID().getValue() == null || measurementLocation.getType().getGUID()
            .getValue().trim().isEmpty()) {

            List<Error> typeSourceKeyErrorList = new ArrayList<>();
            Error typeSourceKeyError = new Error(Error.ErrorType.ERROR);

            typeSourceKeyError.setErrorCode(ErrorConstants.MISSING_CLASSIFICATION_TAG_ASSOCIATION);
            typeSourceKeyError.setPlaceHolders(new String[] { measurementLocation.getTag().getValue() });
            typeSourceKeyErrorList.add(typeSourceKeyError);

            throw new ValidationFailedException(typeSourceKeyErrorList);
        }
    }
}
