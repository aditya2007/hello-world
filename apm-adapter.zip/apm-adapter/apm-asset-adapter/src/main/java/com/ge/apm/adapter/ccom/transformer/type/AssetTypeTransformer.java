/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.type;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.registry.AssetType;

@Component
public class AssetTypeTransformer extends BaseEntityTypeTransformer<AssetType, com.ge.apm.asset.model.AssetType> {

    @Autowired
    public AssetTypeTransformer(AssetClient assetClient) {
        super(assetClient, com.ge.apm.asset.model.AssetType.class);
    }

    @Override
    protected com.ge.apm.asset.model.AssetType createDtoObject() {
        return new com.ge.apm.asset.model.AssetType();
    }

    @Override
    protected String getPrefix() {
        return Prefixes.AssetTypes;
    }

    @Override
    public int order() {
        return Priority.assetType.priority();
    }

    @Override
    public Class<AssetType> supportedCcomClass() {
        return AssetType.class;
    }

    @Override
    protected void transform(AssetType entityObject, com.ge.apm.asset.model.AssetType dtoObject) {
        //no-op;
    }
}
