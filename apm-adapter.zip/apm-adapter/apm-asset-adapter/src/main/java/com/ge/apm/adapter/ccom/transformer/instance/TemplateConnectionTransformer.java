/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.DtoQueueHolder;
import com.ge.apm.adapter.ccom.transformer.IEntityTransformer;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.asset.model.EquipmentInstanceConnection;
import com.ge.apm.asset.model.EquipmentInstanceConnection.Category;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.custom.AssetPlaceholderConnection;
import com.ge.apm.ccom.model.custom.TemplateConnection;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.validator.ValidationFailedException;

@Slf4j
@Component
public class TemplateConnectionTransformer
    extends DtoQueueHolder<com.ge.apm.asset.model.EquipmentInstanceConnection>
    implements IEntityTransformer<TemplateConnection> {

    @Autowired
    public TemplateConnectionTransformer(AssetClient assetClient) {
        super(assetClient, com.ge.apm.asset.model.EquipmentInstanceConnection.class);
    }

    @Override
    public TransformResponse transform(TemplateConnection templateConnection)
        throws ServiceException, ValidationFailedException {

        EquipmentInstanceConnection equipmentInstanceConnection = new EquipmentInstanceConnection();

        //handle parent entity.
        if (!StringUtils.isEmpty(templateConnection.getParentEntityId())
            && templateConnection.getParentEntityCcomClass() != null) {
            setParentEntity(templateConnection, equipmentInstanceConnection);
        }

        ///handle connections
        com.ge.apm.asset.model.AssetPlaceholderConnection assetPlaceholderConnDto = null;
        List<com.ge.apm.asset.model.AssetPlaceholderConnection> assetPlaceholderConnections =
            new ArrayList<>();
        List<AssetPlaceholderConnection> connections = templateConnection.getConnections();
        for (AssetPlaceholderConnection connection : connections) {
            assetPlaceholderConnDto = new com.ge.apm.asset.model.AssetPlaceholderConnection();
            assetPlaceholderConnDto.setPlaceholderId(connection.getPlaceholderId());
            assetPlaceholderConnDto.setAssetSourceKey(connection.getId());
            assetPlaceholderConnections.add(assetPlaceholderConnDto);
        }
        equipmentInstanceConnection.setConnections(assetPlaceholderConnections);
        equipmentInstanceConnection.setTemplateSourceKey(templateConnection.getTemplateId());

        queueForDispatch(equipmentInstanceConnection);

        //TODO: should we valid duplicate Asset URI & placeholderId
        TransformResponse transformResponse = new TransformResponse();
        transformResponse.setStatus(TransformResponse.EntityResponseStatus.OK);

        return transformResponse;
    }

    private void setParentEntity(TemplateConnection templateConnection,
        EquipmentInstanceConnection equipmentInstanceConnection) {

        String parentPrefix = Prefixes
            .getPrefixByCategory(templateConnection.getParentEntityCcomClass().name());

        equipmentInstanceConnection.setParentEntitySrcKey(templateConnection.getParentEntityId());
        if (parentPrefix.equals(Prefixes.Sites)) {
            equipmentInstanceConnection.setParentEntityCategory(Category.SITE);
        } else if (parentPrefix.equals(Prefixes.Segments)) {
            equipmentInstanceConnection.setParentEntityCategory(Category.SEGMENT);
        } else if (parentPrefix.equals(Prefixes.Assets)) {
            equipmentInstanceConnection.setParentEntityCategory(Category.ASSET);
        } else {
            String errorMessage =
                "Unsupported parentEntity with prefix:" + parentPrefix + " in templateConnection.";
            log.error(errorMessage);
            throw new ServiceException(errorMessage);
        }
    }

    @Override
    protected String getPrefix() {
        return Prefixes.TemplateConnections;
    }

    @Override
    public int order() {
        return Priority.templateConnections.priority();
    }

    @Override
    public Class<TemplateConnection> supportedCcomClass() {
        return TemplateConnection.class;
    }
}
