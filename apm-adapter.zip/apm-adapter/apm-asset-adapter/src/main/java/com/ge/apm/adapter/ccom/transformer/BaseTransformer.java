/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer;

import java.util.ArrayList;
import java.util.List;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

public abstract class BaseTransformer {

    protected final AssetClient assetClient;

    public BaseTransformer(AssetClient assetClient) {
        this.assetClient = assetClient;
    }

    protected abstract String getPrefix();

    protected void processException(String[] placeHolders, String errorType) throws ValidationFailedException {
        Error error = new Error(Error.ErrorType.ERROR);
        error.setErrorCode(errorType);

        error.setPlaceHolders(placeHolders);
        List<Error> errorList = new ArrayList<>();
        errorList.add(error);

        throw new ValidationFailedException(errorList);
    }
}
