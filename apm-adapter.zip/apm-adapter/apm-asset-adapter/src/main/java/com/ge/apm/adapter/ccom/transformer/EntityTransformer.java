/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Header;
import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ge.apm.adapter.ccom.config.CcomAdapterRouteBuilder;
import com.ge.apm.adapter.ccom.transformer.instance.DtoTransformer;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.asset.model.Named;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.core.HierarchicalEntity;
import com.ge.apm.common.exception.DefaultErrorCode;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
@Slf4j
@SuppressWarnings({ "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public class EntityTransformer {

    public static final String ENTITIES_TRANSFORMED = "Entities transformed";

    public static final String DTOS_TRANSFORMED = "DTOs transformed";

    public static final String TEMPLATE_NAME = "name";

    private static final String STR_TENANT = "tenant";

    private static final String STR_TRACEID = "X-B3-TraceId";

    private final EntityTransformerFactory entityTransformerFactory;

    private final DtoTransformer dtoTransformer;

    @Autowired
    public EntityTransformer(final EntityTransformerFactory entityTransformerFactory,
        final DtoTransformer dtoTransformer) {
        this.entityTransformerFactory = entityTransformerFactory;
        this.dtoTransformer = dtoTransformer;
    }

    /**
     * Transforms CCOM entity data, see {@link CcomAdapterRouteBuilder}. A
     * {@link com.ge.apm.common.exception.ServiceException} is thrown if any entity fails its DTO transformation,
     * but only after all entities had a chance to be transformed.
     *
     * @param entities list of entities to be transformed into corresponding DTO's
     * @param authorization authorization message header
     * @param tenantUuid tenant UUID
     * @param traceUuid trace UUID
     * @param taskUuid task UUID
     * @param taskType task TYPE
     * @param skipBatchTransformation skipBatchTransformation
     *
     * @return "Entities transformed"
     *
     * @exception com.ge.apm.common.exception.ServiceException if any entity transformation fails
     */
    public String transformEntities(List<Entity> entities, @Header(MessageConstants.AUTHORIZATION) String authorization,
        @Header(MessageConstants.TENANT_UUID) String tenantUuid, @Header(MessageConstants.TRACE_UUID) String traceUuid,
        @Header(MessageConstants.TASK_UUID) String taskUuid, @Header(MessageConstants.TASK_ENTITY_TYPE) String taskType,
        @Header(MessageConstants.SKIP_BATCH_TRANSFORMATION) boolean skipBatchTransformation)
        throws ServiceException, ValidationFailedException {

        if (!skipBatchTransformation) {
            RequestContext.put(RequestContext.AUTHORIZATION, authorization);
            RequestContext.put(RequestContext.TENANT_UUID, tenantUuid);
            RequestContext.put(RequestContext.REQUEST_ID, traceUuid);
            RequestContext.put(RequestContext.SERVICE_INFO, taskUuid);
            MDC.put(STR_TENANT, tenantUuid);
            MDC.put(STR_TRACEID, traceUuid);
            StringBuilder exceptionString = new StringBuilder();

            if (log.isDebugEnabled()) {
                log.debug("EntityTransformer starting to transform " + entities.size() + " entities for TenantUuid "
                    + tenantUuid);
            }
            List<Error> validationErrorList = new ArrayList<>();

            for (Entity entity : entities) {
                transformEntity(exceptionString, validationErrorList, entity, taskType);
            }

            doDispatch();

            if (!validationErrorList.isEmpty()) {
                throw new ValidationFailedException(validationErrorList);
            }

            if (exceptionString.length() > 0) {
                throw new ServiceException(
                    DefaultErrorCode.create("CREATE_UPDATE_ENTITIES", exceptionString.toString()));
            }

            if (log.isDebugEnabled()) {
                log.debug("EntityTransformer finished transforming {} entities for TenantUuid {}.", entities.size(),
                    tenantUuid);
            }
        } else {
            if (log.isDebugEnabled()) {
                log.debug("EntityTransformer skipped transforming {} entities for Task {} for TenantUuid {}",
                    entities.size(), taskUuid, tenantUuid);
            }
        }
        return ENTITIES_TRANSFORMED;
    }

    private void transformEntity(StringBuilder exceptionString, List<Error> validationErrorList, Entity entity,
        String taskType) {
        String entityNameOrSrcKey = tryGetEntityNameOrSourceKey(entity);
        try {
            if (entity == null) {
                return;
            }
            // TODO: figure out how to avoid this cast
            @SuppressWarnings("unchecked") IEntityTransformer<Entity> entityTransformer;
            if (!StringUtils.isEmpty(taskType) && taskType.equals("Connections")) {
                entityTransformer = (IEntityTransformer<Entity>) entityTransformerFactory.getTransformerFor(
                    HierarchicalEntity.class);
            } else {
                entityTransformer = (IEntityTransformer<Entity>) entityTransformerFactory.getTransformerFor(
                    entity.getClass());
            }

            TransformResponse transformResponse = null;
            if (entityTransformer == null) {
                log.warn("[transformEntities] unknown entity {}: {}", entity.getClass().getSimpleName(),
                    entityNameOrSrcKey);
            } else {
                transformResponse = entityTransformer.transform(entity);
            }

            if (transformResponse != null && transformResponse.getWarnings() != null
                && transformResponse.getWarnings().size() > 0) {
                //add to sourceerrorlist
                for (Error warn : transformResponse.getWarnings()) {
                    validationErrorList.add(warn);
                }
            }
        } catch (ValidationFailedException ex) {
            log.error(ex.getMessage(), ex);
            validationErrorList.addAll(ex.getErrorCollection());
        } catch (Exception ex) {
            log.error("Failed to transform entity - " + entityNameOrSrcKey, ex);
            exceptionString.append("Failed to transform entity - ").append(entityNameOrSrcKey).append(". ").append(ex)
                .append(". ");
        }
    }

    private void doDispatch() {
        try {
            entityTransformerFactory.doDispatch();
        } catch (ServiceException se) {
            throw se;
        } catch (Exception ex) {
            throw new ServiceException(
                DefaultErrorCode.create("CREATE_UPDATE_ENTITIES", "Failed to create or update entities"), ex);
        } finally {
            RequestContext.remove(RequestContext.AUTHORIZATION);
        }
    }

    public String transformDtos(List<Named> dtoList, @Header(MessageConstants.AUTHORIZATION) String authorization,
        @Header(MessageConstants.TENANT_UUID) String tenantUuid, @Header(MessageConstants.TRACE_UUID) String traceUuid,
        @Header(MessageConstants.TASK_UUID) String taskUuid) throws ServiceException {
        RequestContext.put(RequestContext.AUTHORIZATION, authorization);
        RequestContext.put(RequestContext.TENANT_UUID, tenantUuid);
        RequestContext.put(RequestContext.REQUEST_ID, traceUuid);
        RequestContext.put(RequestContext.SERVICE_INFO, taskUuid);
        MDC.put(STR_TENANT, tenantUuid);
        MDC.put(STR_TRACEID, traceUuid);
        try {
            dtoTransformer.transform(dtoList);
            if (log.isDebugEnabled()) {
                log.debug("[transform] dto input: {} DTOs transformed.", dtoList.size());
            }
        } catch (Exception ex) {
            throw new ServiceException(DefaultErrorCode.create("CREATE_UPDATE_DTOS", "Failed to transform DTOs"), ex);
        } finally {
            RequestContext.remove(RequestContext.AUTHORIZATION);
            RequestContext.remove(RequestContext.SERVICE_INFO);
        }
        return DTOS_TRANSFORMED;
    }

    private String tryGetEntityNameOrSourceKey(Entity entity) {
        if (entity != null) {
            if (entity.getName() != null) {
                return entity.getName().getValue();
            } else if (entity.getTag() != null) {
                return entity.getTag().getValue();
            }
        }
        return null;
    }
}
