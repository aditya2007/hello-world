/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.base;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.adapter.common.constants.AttributeTypes;
import com.ge.apm.adapter.common.util.IEntityDispatcher;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.core.AttributableEntity;
import com.ge.apm.ccom.model.core.Attribute;
import com.ge.apm.ccom.model.custom.AttributeDef;
import com.ge.apm.ccom.model.custom.ReservedAttribute;
import com.ge.apm.common.util.IdGenerator;
import com.ge.apm.s95.model.BaseObject;
import com.ge.apm.s95.model.Property;
import com.ge.apm.s95.model.PropertyDef;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

@SuppressWarnings({ "PMD.GodClass", "PMD.TooManyMethods" })
public abstract class ObjectProcessor<T> {

    private static final String RESERVED_ATTRIBUTE = "/reservedAttribute_";

    @Autowired
    protected IEntityDispatcher entityDispatcher;

    public abstract void process(T object)
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException;

    protected void processProperties(AttributableEntity attributableEntity, BaseObject baseObject) {
        if (baseObject.getProperties() == null) {
            return;
        }
        for (Property property : baseObject.getProperties()) {
            processProperty(attributableEntity, property);
        }
    }

    private void processProperty(AttributableEntity attributableEntity, Property property) {
        int valueCount = 1;
        if (property.getValue() != null && property.getValue().length > 1) {
            valueCount = property.getValue().length;
        }

        String attributeTypeId = IdGenerator.generateAsString();
        for (int idx = 0; idx < valueCount; idx++) {
            Attribute attribute;
            if (valueCount > 1) {
                attribute = CcomTypeHelper.getAttribute(attributeTypeId, idx);
            } else {
                attribute = CcomTypeHelper.getAttribute(attributeTypeId);
            }

            attribute.setName(CcomTypeHelper.wrapText(property.getId()));
            attribute.setTag(CcomTypeHelper.wrapText(property.getId()));
            Object value = null;
            if (property.getValue() != null && property.getValue().length > 0) {
                value = property.getValue()[idx];
            }
            List<AttributeDef> metaInfo = getAttributeMetaInfo(property);

            CcomTypeHelper.wrapValueInValueContentV2(property.getType(), property.getUom(), value,
                attribute.getValueContent(), metaInfo);

            attributableEntity.getAttribute().add(attribute);
        }
    }

    private List<AttributeDef> getAttributeMetaInfo(Property property) {
        List<AttributeDef> metaInfo = null;
        if (property.getMetaInfo() != null && property.getMetaInfo().length > 0) {
            metaInfo = new ArrayList<>();
            for (PropertyDef propertyDef : property.getMetaInfo()) {
                AttributeDef attributeDef = new AttributeDef();
                attributeDef.setId(propertyDef.getId());
                attributeDef.setType(propertyDef.getType());
                metaInfo.add(attributeDef);
            }
        }
        return metaInfo;
    }

    protected void processReservedProperties(AttributableEntity attributableEntity, BaseObject baseObject) {
        if (baseObject.getReservedProperties() == null) {
            return;
        }
        for (Map.Entry<String, Object> reservedAttributeEntry : baseObject.getReservedProperties().entrySet()) {
            String reservedAttributeKey = reservedAttributeEntry.getKey();
            Object reservedAttributeValue = reservedAttributeEntry.getValue();
            String attributeTypeId = IdGenerator.generateAsString();
            ReservedAttribute reservedAttribute;
            if (reservedAttributeValue instanceof ArrayList) {
                List<?> reservedAttributeValueAsList = ((List<?>) reservedAttributeValue);
                for (int idx = 0; idx < reservedAttributeValueAsList.size(); idx++) {
                    reservedAttribute = CcomTypeHelper.getReservedAttribute(attributeTypeId, idx);
                    reservedAttribute.setName(CcomTypeHelper.wrapText(reservedAttributeKey));
                    reservedAttribute.setTag(CcomTypeHelper.wrapText(reservedAttributeKey));
                    CcomTypeHelper.wrapValueInValueContentV2(reservedAttributeValueAsList.get(idx).getClass()
                            .getSimpleName(), null, reservedAttributeValueAsList.get(idx),
                        reservedAttribute.getValueContent(), null);
                    attributableEntity.getReservedAttributes().add(reservedAttribute);
                }
            } else {
                reservedAttribute = CcomTypeHelper.getReservedAttribute(attributeTypeId);
                reservedAttribute.setName(CcomTypeHelper.wrapText(reservedAttributeKey));
                reservedAttribute.setTag(CcomTypeHelper.wrapText(reservedAttributeKey));
                if (reservedAttributeValue != null) {
                    CcomTypeHelper.wrapValueInValueContentV2(reservedAttributeValue.getClass().getSimpleName(), null,
                        reservedAttributeValue, reservedAttribute.getValueContent(), null);
                    attributableEntity.getReservedAttributes().add(reservedAttribute);
                }
            }
        }
    }

    protected void startObject(JsonParser parser) throws IOException {
        if (!parser.hasCurrentToken()) {
            parser.nextToken();
        }
        if (!parser.hasTokenId(JsonToken.START_OBJECT.id())) {
            throw new JsonParseException("Expected START_OBJECT but was " + parser.getCurrentToken(),
                parser.getCurrentLocation());
        }
    }

    protected void endObject(JsonParser parser) throws IOException {
        if (!parser.hasCurrentToken()) {
            parser.nextToken();
        }
        if (!parser.hasTokenId(JsonToken.END_OBJECT.id())) {
            throw new JsonParseException("Expected END_OBJECT but was " + parser.getCurrentToken(),
                parser.getCurrentLocation());
        }
    }

    protected void startArray(JsonParser parser) throws IOException {
        if (!parser.hasCurrentToken()) {
            parser.nextToken();
        }
        if (!parser.hasTokenId(JsonToken.START_ARRAY.id())) {
            throw new JsonParseException("Expected START_ARRAY but was " + parser.getCurrentToken(),
                parser.getCurrentLocation());
        }
    }

    protected void endArray(JsonParser parser) throws IOException {
        if (!parser.hasCurrentToken()) {
            parser.nextToken();
        }
        if (!parser.hasTokenId(JsonToken.END_ARRAY.id())) {
            throw new JsonParseException("Expected END_ARRAY but was " + parser.getCurrentToken(),
                parser.getCurrentLocation());
        }
    }

    protected void processException(JsonParser parser, String[] placeHolders, String errorType,
        boolean isExceptionThrown) throws ValidationFailedException, IOException {
        processException(parser, placeHolders, new String[0], errorType, isExceptionThrown);
    }

    protected void processException(JsonParser parser, String[] placeHolders, String[] resolutionPlaceHolders,
        String errorType, boolean isExceptionThrown) throws ValidationFailedException, IOException {
        Error error = new Error(Error.ErrorType.ERROR);
        error.setErrorCode(errorType);

        if (isExceptionThrown) {
            /*
             * If JSON parser throws InvalidFormatException, then cursor point to the location where invalid enum value
             * exists. So, below loop will move the cursor to end of the object.
             */
            while (parser.getCurrentToken() != JsonToken.END_OBJECT) {
                parser.nextToken();
            }
        }
        error.setPlaceHolders(placeHolders);
        error.setResolutionPlaceHolders(resolutionPlaceHolders);
        List<Error> errorList = new ArrayList<>();
        errorList.add(error);

        throw new ValidationFailedException(errorList);
    }

    protected void processBasicProperties(BaseObject baseObject, AttributableEntity attributableEntity) {
        processBasicProperties(baseObject, attributableEntity, true);
    }

    protected void processBasicProperties(BaseObject baseObject, AttributableEntity attributableEntity, boolean hasId) {
        if (hasId) {
            CcomTypeHelper.setUuidAndTag(attributableEntity, baseObject.getId());
        }
        attributableEntity.setName(CcomTypeHelper.wrapText(baseObject.getName()));
        CcomTypeHelper.addAttribute(attributableEntity, "description", AttributeTypes.DESCRIPTION,
            baseObject.getDescription());
    }

    /**
     * Handles invalid ccom class validationexception when parsing the JSON pay load. Parse <code>id</code> from the
     * remaining tokens in the current Json node for proper error message place holder.
     *
     * @param parser the Json parser
     *
     * @exception Exception when Json parsing encounters an error
     * @Return id of the current node if it exists, otherwise <code>null</code>
     */
    protected String handleInvalidCcomClass(JsonParser parser) throws IOException {
        @SuppressWarnings("unused") JsonToken token = null;
        // move JSON parser cursor to end of current node.
        String parsedId = null;
        while (parser.getCurrentToken() != JsonToken.END_OBJECT) {
            token = parser.nextToken();

            if (parser.getText().toLowerCase().equals("id")) {
                token = parser.nextToken();
                parsedId = parser.getText();
            }

            // "properties" and "reservedProperties" are array nodes, "location" is an object node
            if (parser.getCurrentToken() == JsonToken.START_ARRAY
                || parser.getCurrentToken() == JsonToken.START_OBJECT) {
                parser.skipChildren();
                token = parser.nextToken(); // skip the current END_ARRAY or END_OBJECT token
            }
        }

        return parsedId;
    }

    /**
     * Handles invalid asset location validation exception when parsing the JSON pay load. Parse <code>id</code> from
     * the remaining tokens in the current Json node for proper error message place holder.
     *
     * @param parser the Json parser
     *
     * @exception Exception when Json parsing encounters an error
     * @Return id of the current node if it exists, otherwise <code>null</code>
     */
    protected String handleInvalidLocation(JsonParser parser) throws IOException {
        @SuppressWarnings("unused") JsonToken token = null;

        // skip the current "location" node
        while (parser.getCurrentToken() != JsonToken.END_ARRAY) {
            token = parser.nextToken();
        }
        token = parser.nextToken();
        while (parser.getCurrentToken() != JsonToken.END_OBJECT) {
            parser.skipChildren(); // skip postalAddress
            token = parser.nextToken();
        }
        token = parser.nextToken();

        String parsedId = null;
        while (parser.getCurrentToken() != JsonToken.END_OBJECT) {
            token = parser.nextToken();

            if (parser.getText().toLowerCase().equals("id")) {
                token = parser.nextToken();
                parsedId = parser.getText();
            }

            // "properties" and "reservedProperties" are array nodes, "location" is an object node
            if (parser.getCurrentToken() == JsonToken.START_ARRAY
                || parser.getCurrentToken() == JsonToken.START_OBJECT) {
                parser.skipChildren();
                token = parser.nextToken(); // skip the current END_ARRAY or END_OBJECT token
            }
        }

        return parsedId;
    }
}
