/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.util;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;

@Configuration
@EnableCaching
@Profile("cloud")
public class CloudConfiguration {

    @Bean
    CacheManager apmCacheManager(RedisOperations<Object, Object> redisOperations) {
        RedisCacheManager redisCacheManager = new RedisCacheManager((RedisTemplate<Object, Object>) redisOperations);
        redisCacheManager.setDefaultExpiration(18000); //5 hours
        redisCacheManager.setUsePrefix(true);
        return redisCacheManager;
    }
}
