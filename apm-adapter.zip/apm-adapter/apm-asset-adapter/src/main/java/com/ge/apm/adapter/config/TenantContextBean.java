/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.config;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.mq.constants.MessageConstants;

@Component
public class TenantContextBean {

    public void init(Exchange exchange) {
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        RequestContext.put(RequestContext.TENANT_UUID, tenantUuid);
    }

    public void destroy() {
        RequestContext.destroy();
    }
}
