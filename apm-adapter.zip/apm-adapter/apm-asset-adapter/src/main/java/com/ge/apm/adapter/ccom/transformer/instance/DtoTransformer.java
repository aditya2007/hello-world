/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.BaseTransformer;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.Named;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.common.exception.DefaultErrorCode;
import com.ge.apm.common.exception.ServiceException;

@Component
@Slf4j
public class DtoTransformer extends BaseTransformer {

    @Autowired
    public DtoTransformer(AssetClient assetClient) {
        super(assetClient);
    }

    @Override
    protected String getPrefix() {
        return null;
    }

    public void transform(List<Named> dtoList) throws ServiceException {
        List<MeasurementTagType> newTagTypes = findNewAndUpdatedTagTypes(dtoList);

        createTags(newTagTypes);

        List<MeasurementTag> tags = dtoList.stream().filter(dto -> dto instanceof MeasurementTag).map(
            dto -> (MeasurementTag) dto).collect(Collectors.toList());

        if (log.isDebugEnabled()) {
            log.debug("[transform] dto created {} tag types", newTagTypes.size());
        }

        Map<String, List<MeasurementTag>> tagEntryMap = getTagEntryMap(tags);

        StringBuilder exceptionString = new StringBuilder();
        for (Map.Entry<String, List<MeasurementTag>> tagEntry : tagEntryMap.entrySet()) {
            exceptionString.append("Monitored entity ").append(tagEntry.getKey()).append(" not found. ");
        }

        if (exceptionString.length() > 0) {
            throw new ServiceException(DefaultErrorCode.create("INVALID_TAG", exceptionString.toString()));
        }
    }

    private List<MeasurementTagType> findNewAndUpdatedTagTypes(List<Named> dtoList) {
        List<MeasurementTagType> newTagTypes = new ArrayList<>();
        for (Named tagDto : dtoList) {
            if (tagDto instanceof MeasurementTagType) {
                MeasurementTagType measurementTagType = (MeasurementTagType) tagDto;
                newTagTypes.add(measurementTagType);
            }
        }
        return newTagTypes;
    }

    private Map<String, List<MeasurementTag>> getTagEntryMap(List<MeasurementTag> tags) {
        Map<String, List<MeasurementTag>> tagEntryMap = new HashMap<>();
        for (MeasurementTag tag : tags) {
            if (!tagEntryMap.containsKey(tag.getMonitoredEntitySourceKey())) {
                tagEntryMap.put(tag.getMonitoredEntitySourceKey(), new ArrayList<>());
            }
            tagEntryMap.get(tag.getMonitoredEntitySourceKey()).add(tag);
        }
        return tagEntryMap;
    }

    private void createTags(List<MeasurementTagType> newTags) throws ServiceException {
        MeasurementTagType[] tagsToCreate = newTags.toArray(new MeasurementTagType[newTags.size()]);
        assetClient.create(Prefixes.MeasurementTagTypes, tagsToCreate);
    }
}
