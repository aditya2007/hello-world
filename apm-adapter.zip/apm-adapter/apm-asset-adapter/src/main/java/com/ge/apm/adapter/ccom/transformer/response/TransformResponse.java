/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.response;

import java.io.Serializable;
import java.util.List;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.ge.asset.commons.validator.Error;

/**
 * Created by 502670744 on 10/14/16.
 */
@Getter
@Setter
@ToString(includeFieldNames = true)
@EqualsAndHashCode
public class TransformResponse implements Serializable {

    private static final long serialVersionUID = 5256876037692134927L;

    private EntityResponseStatus status;

    private List<Error> warnings;

    /**
     * Created by 502670744 on 10/17/16.
     */
    public static enum EntityResponseStatus {

        OK(200, "OK"),
        CREATED(201, "Created"),
        CREATEDWITHWARNINGS(202, "Created with warnings");

        private int code;

        private String desc;

        private String text;

        EntityResponseStatus(int code, String desc) {
            this.code = code;
            this.desc = desc;
            this.text = Integer.toString(code);
        }

        /**
         * Gets the EntityResponseStatus code.
         *
         * @return the status code number.
         */
        public int getCode() {
            return code;
        }

        /**
         * Gets the EntityResponseStatus as a text string.
         *
         * @return the status code as a text string.
         */
        public String asText() {
            return text;
        }

        /**
         * Get the description.
         *
         * @return the description of the status code.
         */
        public String getDesc() {
            return desc;
        }

    }
}
