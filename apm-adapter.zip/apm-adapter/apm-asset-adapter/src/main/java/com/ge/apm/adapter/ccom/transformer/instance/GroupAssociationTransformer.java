/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.DtoQueueHolder;
import com.ge.apm.adapter.ccom.transformer.IEntityTransformer;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.types.TextType;
import com.ge.apm.ccom.model.groups.GroupAssociation;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Transformer for GroupAssociation. Associates a Group to allowed entities. Internally stores as
 * 'GroupAssociation' in predix asset after performing all validations and processing.
 *
 * @author Nadkarni, Krishnapratik 212422632
 * @author Chand Bhaverisetti 212432041
 * @version 1.0 Feb 24, 2016
 */
@Component
@SuppressWarnings({ "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public class GroupAssociationTransformer extends DtoQueueHolder<com.ge.apm.asset.model.GroupAssociation>
    implements IEntityTransformer<GroupAssociation> {

    private static String typeUri;

    @Autowired
    public GroupAssociationTransformer(AssetClient assetClient) {
        super(assetClient, com.ge.apm.asset.model.GroupAssociation.class);
    }

    /**
     * Interface method overridden for special behavior within GroupAssociations.
     */
    @Override
    public TransformResponse transform(GroupAssociation entity) throws ServiceException, ValidationFailedException {
        TextType nameValue = new TextType();
        nameValue.setValue("Group Association");
        entity.setName(nameValue);
        TransformResponse transformResponse = new TransformResponse();
        transformGroupAssociation(entity);
        transformResponse.setStatus(TransformResponse.EntityResponseStatus.OK);
        return transformResponse;
    }

    /**
     * Create the GroupAssociation DTO and sets the properties.
     *
     * @param sourceKey sourceKey for the GroupAssociation object
     * @param fromUri uri for the associatedEntity object (uri for asset, assetClass, tag, tagClass or any other
     * associated
     * entity)
     * @param toUri uri for the Group object
     *
     * @return GroupAssociation object
     */
    private com.ge.apm.asset.model.GroupAssociation createDto(String sourceKey, String fromUri, String toUri) {
        com.ge.apm.asset.model.GroupAssociation dto = new com.ge.apm.asset.model.GroupAssociation();
        dto.setSourceKey(sourceKey);
        dto.setName(sourceKey);
        dto.setDescription(sourceKey);
        dto.setFromUri(fromUri);
        dto.setToUri(toUri);
        dto.setType(typeUri);
        return dto;
    }

    protected String getPrefix() {
        return Prefixes.GroupAssociations;
    }

    @Override
    public Class<GroupAssociation> supportedCcomClass() {
        return GroupAssociation.class;
    }

    /**
     * Creates and persists the GroupAssociation DTO after performing necessary validations.
     *
     * @param groupAssociation groupAssociation object
     */
    @SuppressWarnings("PMD")
    private void transformGroupAssociation(GroupAssociation groupAssociation)
        throws ServiceException, ValidationFailedException {
        MimosaCcomCategory ccomCategory = groupAssociation.getAssociatedEntityCcomClass();
        String fromSourceKey = groupAssociation.getAssociatedEntityId().getValue();
        String toSourceKey = groupAssociation.getGroupId().getValue();
        String fromUri = getAssociatedEntityPrefix(ccomCategory) + "/" + fromSourceKey;
        String toUri = Prefixes.Groups + "/" + toSourceKey;
        String sourceKey = generateSourceKey(fromSourceKey, toSourceKey);
        com.ge.apm.asset.model.GroupAssociation dto = createDto(sourceKey, fromUri, toUri);
        // persist in predix asset through apm asset services
        queueForDispatch(dto);
    }

    /**
     * Generates a source key for the group association as combination of the source keys of the entities it is
     * associating.
     *
     * @param fromSourceKey sourceKey for associated entity
     * @param toSourceKey source key for group
     *
     * @return generated source key
     */
    private String generateSourceKey(String fromSourceKey, String toSourceKey) {
        return fromSourceKey + " to " + toSourceKey + " association";
    }

    /**
     * Returns apm asset rest resource prefix based on the ccom object passed. groups allowed to be associated with
     * tag, tag classification, asset, asset classification, segment, segment classification, site, site classification,
     * enterprise, enterprise classification.
     *
     * @param ccomCategory ccomCategory
     *
     * @return the prefix for apm rest resources eg: /assets, /sites
     */
    String getAssociatedEntityPrefix(MimosaCcomCategory ccomCategory) {
        switch (ccomCategory) {
            case TAG:
                return Prefixes.MeasurementTags;
            case TAG_TYPE:
                return Prefixes.MeasurementTagTypes;
            case ASSET:
                return Prefixes.Assets;
            case ASSET_TYPE:
                return Prefixes.AssetTypes;
            case SEGMENT:
                return Prefixes.Segments;
            case SEGMENT_TYPE:
                return Prefixes.SegmentTypes;
            case SITE:
                return Prefixes.Sites;
            case SITE_TYPE:
                return Prefixes.SiteTypes;
            case ENTERPRISE:
                return Prefixes.Enterprises;
            case ENTERPRISE_TYPE:
                return Prefixes.EnterpriseTypes;
            case GROUP:
                return Prefixes.Groups;
            default:
                throw new IllegalStateException("Invalid associated entity type");
        }
    }

    /**
     * EntityTransformerFactory uses this to determine the order in which entities are persisted to predix asset. Look
     * for EntityTransformerFactory.doDispatch().
     */
    @Override
    public int order() {
        return Priority.groupAssociation.priority();
    }

    /**
     * <code>GroupAssocation</code> depends on <code>Group</code> while both are packaged in the <code>groups</code>
     * root level element in the Json payload. As such, this transformer cannot support fail-fast.
     *
     * @return <code>false</code>
     *
     * @see com.ge.apm.adapter.ccom.transformer.IEntityTransformer#supportsFailFast()
     */
    @Override
    public boolean supportsFailFast() {
        return false;
    }
}
