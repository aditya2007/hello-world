/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.common.constants.AttributeTypes;
import com.ge.apm.adapter.s95.processor.IRootLevelProcessor;
import com.ge.apm.adapter.s95.processor.base.ObjectProcessor;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.core.ReferenceUnitType;
import com.ge.apm.ccom.model.measurements.locations.MeasurementLocationType;
import com.ge.apm.s95.model.TagClassification;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
public class TagClassificationProcessor extends ObjectProcessor<JsonParser> implements IRootLevelProcessor<JsonParser> {

    @Override
    public void process(JsonParser parser)
        throws IOException, ValidationFailedException, InstantiationException, IllegalAccessException {
        TagClassification tagClassification = parser.readValueAs(TagClassification.class);
        MeasurementLocationType mlt = new MeasurementLocationType();
        processBasicProperties(tagClassification, mlt);
        if (tagClassification.getParent() != null && !tagClassification.getParent().isEmpty()) {
            CcomTypeHelper.addAttribute(mlt, "parent", AttributeTypes.PARENT, tagClassification.getParent());
        }
        processProperties(mlt, tagClassification);
        processReservedProperties(mlt, tagClassification);
        ReferenceUnitType rut = new ReferenceUnitType();
        //TODO - Cir Lookup for UnitGroup
        rut.setGUID(CcomTypeHelper.wrapUUID(tagClassification.getUnitGroup()));
        mlt.setReferenceUnitType(rut);
        entityDispatcher.sendEntity(mlt, this.supportedField());
    }

    @Override
    public String supportedField() {
        return TAG_CLASSIFICATIONS;
    }

    @Override
    public Class supportedClass() {
        return TagClassification.class;
    }
}
