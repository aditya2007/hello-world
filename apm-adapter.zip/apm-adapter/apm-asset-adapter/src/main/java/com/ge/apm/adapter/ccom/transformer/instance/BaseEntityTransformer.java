/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.CcomClassNameMappingEnum;
import com.ge.apm.adapter.ccom.transformer.DtoQueueHolder;
import com.ge.apm.adapter.ccom.transformer.EntityTransformerFactory;
import com.ge.apm.adapter.ccom.transformer.IEntityTransformer;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.adapter.common.constants.AttributeTypes;
import com.ge.apm.asset.model.Monitored;
import com.ge.apm.asset.model.Typed;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.core.AttributableEntity;
import com.ge.apm.ccom.model.core.Attribute;
import com.ge.apm.ccom.model.core.BaseType;
import com.ge.apm.ccom.model.custom.ReservedAttribute;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.util.AssetConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Base class for transforming <code>ccom</code> entities to <code>apm-asset</code> data transfer objects.
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Oct 14, 2016
 * @since 1.0
 */
@SuppressWarnings({ "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public abstract class BaseEntityTransformer<T extends AttributableEntity, D extends Typed> extends DtoQueueHolder<D>
    implements IEntityTransformer<T> {

    protected final AssetClient assetClient;

    protected BaseEntityTransformer(AssetClient assetClient, Class<D> dtoClazz) {
        super(assetClient, dtoClazz);
        this.assetClient = assetClient;
    }

    @Override
    public final TransformResponse transform(T entityObject) throws ServiceException, ValidationFailedException {
        validateEntity(entityObject);
        D dtoObject = createDtoObject(entityObject);

        validateSourceKey(entityObject, dtoObject);

        if (entityObject.getName() != null) {
            dtoObject.setName(entityObject.getName().getValue());
            dtoObject.setDescription(entityObject.getName().getValue());
        }

        assignType(dtoObject, entityObject);

        if (entityObject.getTag() != null) {
            dtoObject.setSourceKey(entityObject.getTag().getValue());
        }
        if (dtoObject instanceof Monitored) {
            setDependencyParent(entityObject, dtoObject);
        }

        Map<String, List<Attribute>> attributeTypeMap = CcomTypeHelper.getAttributeTypeMap(entityObject);
        List<Attribute> description = attributeTypeMap.remove(AttributeTypes.DESCRIPTION);
        if (description != null) {
            dtoObject.setDescription(description.get(0).getValueContent().getText().getValue());
        }

        //Process all the regular properties
        processRegularProperties(dtoObject, attributeTypeMap);

        //Process all the reserved properties
        //convertEntity to Map of ReservedAttributes
        Map<String, List<ReservedAttribute>> reservedAttributeTypeMap = CcomTypeHelper.getReservedAttributeTypeMap(
            entityObject);

        processReservedProperties(dtoObject, reservedAttributeTypeMap);

        TransformResponse transformResponse = new TransformResponse();

        transformConnections(entityObject, dtoObject);
        transformOtherParts(entityObject, dtoObject, transformResponse);
        queueForDispatch(dtoObject);

        if (transformResponse.getWarnings() != null && transformResponse.getWarnings().size() > 0) {
            transformResponse.setStatus(TransformResponse.EntityResponseStatus.CREATEDWITHWARNINGS);
        } else {
            transformResponse.setStatus(TransformResponse.EntityResponseStatus.OK);
        }

        return transformResponse;
    }

    private void setDependencyParent(T entityObject, D dtoObject) {
        String parentSourceKey = getParentSourceKey(entityObject);
        if (parentSourceKey != null && !parentSourceKey.isEmpty()) {
            String parentPrefix = getParentPrefix(entityObject);
            String parentUriCacheKey = parentPrefix + "/" + parentSourceKey;
            dtoObject.setParent(parentUriCacheKey);
        }
    }

    private void processReservedProperties(D dtoObject, Map<String, List<ReservedAttribute>> reservedAttributeTypeMap) {

        //Convert the List of reservedAttributes to Map<String, Object>
        if (reservedAttributeTypeMap != null && !reservedAttributeTypeMap.isEmpty()) {
            @SuppressWarnings("unchecked") Map<String, Object> reservedAttributeTypeObjectMap = new HashedMap();
            reservedAttributeTypeMap.forEach((name, reservedAttributeList) -> {
                Object attrValue = EntityTransformerFactory.extractReservedAttributeValues(reservedAttributeList);
                reservedAttributeTypeObjectMap.put(name, attrValue);
            });
            dtoObject.setReservedAttributes(reservedAttributeTypeObjectMap);
        }
    }

    private void processRegularProperties(D dtoObject, Map<String, List<Attribute>> attributeTypeMap) {
        LinkedHashMap<String, com.ge.apm.asset.model.Attribute> attributeDtoMap = EntityTransformerFactory
            .getAttributeMap(attributeTypeMap);

        if (attributeDtoMap == null || attributeDtoMap.isEmpty()) {
            dtoObject.setAttributes(new LinkedHashMap<>());
        } else {
            dtoObject.setAttributes(attributeDtoMap);
        }
    }

    private void validateSourceKey(T entityObject, D dtoObject) throws ValidationFailedException {
        if (entityObject.getGUID() == null) {
            Error sourceKeyError = new Error(Error.ErrorType.ERROR);
            sourceKeyError.setErrorCode(ErrorConstants.INSTANCE_ID_MISSING_CODE);
            sourceKeyError.setPlaceHolders(new String[] { entityObject.getName().getValue(),
                CcomClassNameMappingEnum.getSimpleJsonNodeNameFromEnum(dtoObject.getClass().getSimpleName()) });
            List<Error> sourceKeyErrorList = new ArrayList<>();
            sourceKeyErrorList.add(sourceKeyError);
            throw new ValidationFailedException(sourceKeyErrorList);
        }

        Map<String, String> connections = getConnections(entityObject);

        if (entityObject.getTag() == null || entityObject.getTag().getValue() == null
            || entityObject.getTag().getValue().length() == 0 || connections != null && Boolean.valueOf(
            connections.get(AssetConstants.IS_ID_MISSING))) {

            List<Error> sourceKeyErrorList = new ArrayList<>();

            // if dtoObject is type of "Instances / Connections", then it will be an instance of "Monitored"
            if (dtoObject instanceof Monitored) {
                // "Instances" if IS_CONNECTIONS is null
                if (connections == null || connections.get(AssetConstants.IS_CONNECTIONS) == null) {
                    Error sourceKeyError = new Error(Error.ErrorType.ERROR);
                    sourceKeyError.setErrorCode(ErrorConstants.INSTANCE_ID_MISSING_CODE);
                    sourceKeyError.setPlaceHolders(new String[] { entityObject.getName().getValue(),
                        CcomClassNameMappingEnum.getSimpleJsonNodeNameFromEnum(dtoObject.getClass().getSimpleName()) });
                    sourceKeyErrorList.add(sourceKeyError);
                } else {
                    // "Connections" if IS_CONNECTIONS is not null
                    Error sourceKeyError = new Error(Error.ErrorType.ERROR);
                    sourceKeyError.setErrorCode(ErrorConstants.CONNECTION_ID_MISSING_CODE);
                    sourceKeyError.setPlaceHolders(new String[] {
                        CcomClassNameMappingEnum.getSimpleClassNameFromEnum(connections.get(AssetConstants.FROM_CCOM)),
                        CcomClassNameMappingEnum.getSimpleClassNameFromEnum(connections.get(AssetConstants.TO_CCOM)) });
                    sourceKeyErrorList.add(sourceKeyError);
                }

                if (!sourceKeyErrorList.isEmpty()) {
                    throw new ValidationFailedException(sourceKeyErrorList);
                }
            }
        }
    }

    protected abstract void transformOtherParts(T entityObject, D dtoObject, TransformResponse transformResponse)
        throws ServiceException, ValidationFailedException;

    protected void assignType(D dtoObject, T entityObject) throws ServiceException {
        BaseType typeEntity = getTypeFromEntity(entityObject);
        if (typeEntity != null) {
            String typeSourceKey = typeEntity.getGUID().getValue();
            dtoObject.setType(getTypePrefix(entityObject) + "/" + typeSourceKey);
        }
    }

    protected abstract BaseType getTypeFromEntity(T entityObject);

    protected abstract D createDtoObject(T entityObject);

    protected abstract String getParentSourceKey(T entityObject);

    protected abstract String getParentPrefix(T entityObject);

    protected abstract Map<String, String> getConnections(T entityObject);

    protected abstract String getTypePrefix(T entityObject);

    protected abstract void transformConnections(T entityObject, D dtoObject);

    protected abstract void validateEntity(T entityObject) throws ServiceException, ValidationFailedException;
}
