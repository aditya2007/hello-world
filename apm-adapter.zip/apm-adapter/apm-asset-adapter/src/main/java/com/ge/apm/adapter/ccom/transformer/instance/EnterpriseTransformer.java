/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.core.BaseType;
import com.ge.apm.ccom.model.core.HierarchicalLink;
import com.ge.apm.ccom.model.network.connections.EnterpriseConnection;
import com.ge.apm.ccom.model.registry.Enterprise;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.util.AssetConstants;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
public class EnterpriseTransformer extends BaseEntityTransformer<Enterprise, com.ge.apm.asset.model.Enterprise> {

    @Autowired
    public EnterpriseTransformer(AssetClient assetClient) {
        super(assetClient, com.ge.apm.asset.model.Enterprise.class);
    }

    @Override
    protected BaseType getTypeFromEntity(Enterprise enterprise) {
        return enterprise.getType();
    }

    @Override
    protected com.ge.apm.asset.model.Enterprise createDtoObject(Enterprise entity) {
        return new com.ge.apm.asset.model.Enterprise();
    }

    @Override
    protected String getTypePrefix(Enterprise entityObject) {
        return Prefixes.EnterpriseTypes;
    }

    @Override
    protected void transformConnections(Enterprise enterprise, com.ge.apm.asset.model.Enterprise enterpriseDto) {
        if (enterprise.getToConnection() != null && enterprise.getToConnection().size() > 0) {
            if (enterpriseDto.getConnections() == null) {
                enterpriseDto.setConnections(new LinkedHashMap<>());
            }
            for (EnterpriseConnection enterpriseConnection : enterprise.getToConnection()) {
                String type = enterpriseConnection.getType().getName().getValue();
                if (!enterpriseDto.getConnections().containsKey(type)) {
                    enterpriseDto.getConnections().put(type, new LinkedHashSet<>());
                }
                enterpriseDto.getConnections().get(type).add(enterpriseConnection.getTo().getGUID().getValue());
            }
        }
    }

    @Override
    protected String getPrefix() {
        return Prefixes.Enterprises;
    }

    @Override
    public int order() {
        return Priority.enterprise.priority();
    }

    @Override
    public Class<Enterprise> supportedCcomClass() {
        return Enterprise.class;
    }

    @Override
    protected void validateEntity(Enterprise entityObject) throws ServiceException {
        // no operation
    }

    @Override
    protected void transformOtherParts(Enterprise entityObject, com.ge.apm.asset.model.Enterprise dtoObject,
        TransformResponse transformResponse) throws ServiceException, ValidationFailedException {
        // no operation
    }

    @Override
    protected String getParentSourceKey(Enterprise enterprise) {
        if (enterprise.getRegistrationEnterprise() != null) {
            return enterprise.getRegistrationEnterprise().getGUID().getValue();
        } else if (enterprise.getParentLink().size() > 0) {
            HierarchicalLink hierarchicalLink = enterprise.getParentLink().get(0);
            return hierarchicalLink.getParent().getGUID().getValue();
        }
        return null;
    }

    @Override
    protected String getParentPrefix(Enterprise enterprise) {
        if (enterprise.getParentLink().size() > 0 && enterprise.getParentLink().get(0)
            .getParent() instanceof Enterprise) {
            return Prefixes.Enterprises;
        }
        return null;
    }

    @Override
    protected Map<String, String> getConnections(Enterprise enterprise) {
        HashMap<String, String> connections = new HashMap<>();
        connections.put(AssetConstants.FROM_CCOM, enterprise.getClass().getSimpleName());

        if (enterprise.getRegistrationEnterprise() != null) {
            connections.put(AssetConstants.TO_CCOM, enterprise.getRegistrationEnterprise().getClass().getSimpleName());
            connections.put(AssetConstants.IS_CONNECTIONS, Boolean.TRUE.toString());
            if (enterprise.getRegistrationEnterprise().getGUID() == null
                || enterprise.getRegistrationEnterprise().getGUID().getValue() == null
                || enterprise.getRegistrationEnterprise().getGUID().getValue().length() == 0) {
                connections.put(AssetConstants.IS_ID_MISSING, Boolean.TRUE.toString());
                return connections;
            }
        } else if (enterprise.getParentLink().size() > 0) {
            HierarchicalLink hierarchicalLink = enterprise.getParentLink().get(0);
            if (hierarchicalLink.getParent() instanceof Enterprise) {
                connections.put(AssetConstants.TO_CCOM, hierarchicalLink.getParent().getClass().getSimpleName());
                connections.put(AssetConstants.IS_CONNECTIONS, Boolean.TRUE.toString());
                if (hierarchicalLink.getParent().getGUID() == null
                    || hierarchicalLink.getParent().getGUID().getValue() == null
                    || hierarchicalLink.getParent().getGUID().getValue().length() == 0) {
                    connections.put(AssetConstants.IS_ID_MISSING, Boolean.TRUE.toString());
                    return connections;
                }
            }
        }
        return connections;
    }
}
