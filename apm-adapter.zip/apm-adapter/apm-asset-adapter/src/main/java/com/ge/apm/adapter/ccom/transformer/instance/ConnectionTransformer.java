/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.asset.model.Typed;
import com.ge.apm.ccom.model.core.BaseType;
import com.ge.apm.ccom.model.core.HierarchicalEntity;
import com.ge.apm.ccom.model.registry.Asset;
import com.ge.apm.ccom.model.registry.Enterprise;
import com.ge.apm.ccom.model.registry.Segment;
import com.ge.apm.ccom.model.registry.Site;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
@SuppressWarnings(
    { "PMD.GodClass", "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public class ConnectionTransformer extends BaseEntityTransformer<HierarchicalEntity, Typed>
    implements InitializingBean {

    @Autowired
    private EnterpriseTransformer enterpriseTransformer;

    @Autowired
    private SiteTransformer siteTransformer;

    @Autowired
    private SegmentTransformer segmentTransformer;

    @Autowired
    private AssetTransformer assetTransformer;

    private Map<Class<? extends HierarchicalEntity>, BaseEntityTransformer> entityTransformerMap;

    @Autowired
    public ConnectionTransformer(AssetClient assetClient) {
        super(assetClient, Typed.class);
    }

    public BaseEntityTransformer getTransformer(HierarchicalEntity hierarchicalEntity) {
        return entityTransformerMap.get(hierarchicalEntity.getClass());
    }

    @Override
    protected BaseType getTypeFromEntity(HierarchicalEntity entity) {
        return getTransformer(entity).getTypeFromEntity(entity);
    }

    @Override
    protected Typed createDtoObject(HierarchicalEntity entity) {
        if (Asset.class.isAssignableFrom(entity.getClass())) {
            return new com.ge.apm.asset.model.Asset();
        } else if (Segment.class.isAssignableFrom(entity.getClass())) {
            return new com.ge.apm.asset.model.Segment();
        } else if (Site.class.isAssignableFrom(entity.getClass())) {
            return new com.ge.apm.asset.model.Site();
        } else if (Enterprise.class.isAssignableFrom(entity.getClass())) {
            return new com.ge.apm.asset.model.Enterprise();
        }

        return null;
    }

    @Override
    @SuppressWarnings("PMD.ConfusingTernary")
    protected String getParentSourceKey(HierarchicalEntity entity) {
        return getTransformer(entity).getParentSourceKey(entity);
    }

    @Override
    protected Map<String, String> getConnections(HierarchicalEntity entity) {
        return getTransformer(entity).getConnections(entity);
    }

    @Override
    @SuppressWarnings("PMD.ConfusingTernary")
    protected String getParentPrefix(HierarchicalEntity entity) {
        return getTransformer(entity).getParentPrefix(entity);
    }

    @Override
    protected String getTypePrefix(HierarchicalEntity entityObject) {
        return getTransformer(entityObject).getTypePrefix(entityObject);
    }

    @Override
    protected void transformConnections(HierarchicalEntity entity, Typed typedDto) {
        getTransformer(entity).transformConnections(entity, typedDto);
    }

    @Override
    protected void transformOtherParts(HierarchicalEntity entity, Typed typedDto, TransformResponse transformResponse)
        throws ServiceException, ValidationFailedException {
        getTransformer(entity).transformOtherParts(entity, typedDto, transformResponse);
    }

    //TODO: verify impact of of not inheriting
    @Override
    protected String getPrefix() {
        return MessageConstants.ASSET_CONNECTION_PREFIX;
    }

    @Override
    public int order() {
        return Priority.connection.priority();
    }

    //TODO: verify the return type on this thing, used in entitytransformerfactory
    @Override
    public Class<HierarchicalEntity> supportedCcomClass() {
        return HierarchicalEntity.class;
    }

    @Override
    protected void validateEntity(HierarchicalEntity entityObject) throws ServiceException, ValidationFailedException {
        getTransformer(entityObject).validateEntity(entityObject);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        this.entityTransformerMap = new HashMap<>();
        this.entityTransformerMap.put(Enterprise.class, enterpriseTransformer);
        this.entityTransformerMap.put(Site.class, siteTransformer);
        this.entityTransformerMap.put(Segment.class, segmentTransformer);
        this.entityTransformerMap.put(Asset.class, assetTransformer);
    }
}
