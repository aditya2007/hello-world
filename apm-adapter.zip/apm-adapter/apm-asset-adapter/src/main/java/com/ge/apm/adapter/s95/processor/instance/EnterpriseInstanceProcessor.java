/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.instance;

import java.io.IOException;

import org.springframework.stereotype.Component;

import com.ge.apm.ccom.model.registry.Enterprise;
import com.ge.apm.ccom.model.registry.EnterpriseType;
import com.ge.apm.s95.model.Instance;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
public class EnterpriseInstanceProcessor extends InstanceObjectProcessor<Enterprise, EnterpriseType> {

    public EnterpriseInstanceProcessor() {
        super(Enterprise.class, EnterpriseType.class);
    }

    @Override
    protected void assignEntityType(Enterprise entity, EnterpriseType typeEntity) {
        entity.setType(typeEntity);
    }

    @Override
    protected void processOthers(Enterprise entity, Instance instance) throws IOException, ValidationFailedException {
        //no op
    }
}
