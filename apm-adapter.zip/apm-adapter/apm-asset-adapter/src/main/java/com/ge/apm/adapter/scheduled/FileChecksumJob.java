/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.scheduled;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.HashSet;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.domain.persistence.repository.IFileChecksumRepository;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.datasource.TenantDataSourceService;

/**
 * Description of FileChecksumJob
 *
 * @author Albert H. Yu hsiang-aiyu
 * @version 1.0 Mar 3, 2017
 * @since 1.0
 */
@Component
@Slf4j
public class FileChecksumJob {

    @Value("${scheduled.file.checksum.delete.when.older.than.min}")
    private int obsoleteWhenOlderThanMin;

    @Autowired
    private IFileChecksumRepository fileChecksumRepository;

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    @Autowired
    private TenantDataSourceService tenantDataSourceService;

    // job is triggered on the hour
    @Scheduled(cron = "0 0 * * * ?")
    public void deleteFileChecksum() {
        for (String tenantId : getDatabases()) {
            RequestContext.put(RequestContext.TENANT_UUID, tenantId);
            Date expired = new Date(System.currentTimeMillis() - 60000L * obsoleteWhenOlderThanMin);
            int deleted = fileChecksumRepository.deleteWhenOlderThan(expired);
            if (log.isDebugEnabled()) {
                log.debug("Deleted {} file checksums older than {}.", deleted, sdf.format(expired));
            }
        }
    }

    private HashSet<String> getDatabases() {
        HashSet<String> set = new HashSet<>();
        set.add(TenantDataSourceService.DEFAULT_DATASOURCE);
        set.addAll(tenantDataSourceService.getTenants());
        return set;
    }
}
