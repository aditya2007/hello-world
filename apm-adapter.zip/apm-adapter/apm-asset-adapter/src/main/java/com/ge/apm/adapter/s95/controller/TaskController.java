/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.controller;

import java.io.UnsupportedEncodingException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.core.MediaType;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.MDC;
import org.apache.openjpa.persistence.PersistenceException;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.apm.adapter.common.constants.TaskStatus;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.apm.adapter.model.Ingestion;
import com.ge.apm.adapter.model.IngestionLogMsg;
import com.ge.apm.adapter.model.IngestionPage;
import com.ge.apm.adapter.model.Task;
import com.ge.apm.common.exception.BadRequestException;
import com.ge.apm.common.exception.ExceptionUtil;
import com.ge.apm.common.exception.NotFoundException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.stuf.tenant.context.TenantContext;

@Controller
@Slf4j
@SuppressWarnings("PMD.GodClass")
public class TaskController {

    private static final String EMPTY = "";

    private static final Pattern fileName_Pattern = Pattern.compile("(?<=file: )(.*)(?=, size:)|(?<=file: )(.*\\..*)",
        Pattern.CASE_INSENSITIVE);

    private static final Pattern fileFromPath_Pattern = Pattern.compile("[^\\/]*\\..*", Pattern.CASE_INSENSITIVE);

    private static final Pattern size_Pattern = Pattern.compile("(?<=size: )(.*)bytes", Pattern.CASE_INSENSITIVE);

    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss.SSS");

    private InheritableThreadLocal<AtomicBoolean> debugEnabled = new InheritableThreadLocal<>();

    @Inject
    private ITaskProcessorRepository taskProcessorRepository;

    @PersistenceContext
    private EntityManager entityManager;

    private static String parseFileName(String s) {
        Matcher matcher = fileName_Pattern.matcher(s);
        if (matcher.find()) {
            try {
                String pathName = java.net.URLDecoder.decode(matcher.group(), "UTF-8");
                matcher = fileFromPath_Pattern.matcher(pathName);
                if (matcher.find()) {
                    return java.net.URLDecoder.decode(matcher.group(), "UTF-8");
                } else {
                    return pathName;
                }
            } catch (UnsupportedEncodingException ex) {
                log.error("Failed to decode URL {}.", s, ex);
                return "Failed to decode URL";
            }
        } else {
            return "Not Found";
        }
    }

    private static String parseFileSize(String s) {
        Matcher matcher = size_Pattern.matcher(s);
        if (matcher.find()) {
            return matcher.group();
        } else {
            return "Not Found";
        }
    }

    protected void getTotalAndCompletedCounts(List<com.ge.apm.adapter.domain.persistence.entity.Task> tasks) {
        String commaSeparatedIds = tasks.stream().map(task -> task.getId().toString()).collect(
            Collectors.joining(",", "(", ")"));
        Query query = entityManager.createNativeQuery(
            "select sum(total_count) as total_count, sum(completed_count) as completed_count, parent_task as id "
                + "from apm_adapter.ingestion_task " + "where parent_task in " + commaSeparatedIds + " "
                + "group by parent_task", com.ge.apm.adapter.domain.persistence.entity.Task.class);
        Map<Long, com.ge.apm.adapter.domain.persistence.entity.Task> idToCount
            = (Map<Long, com.ge.apm.adapter.domain.persistence.entity.Task>) query.getResultList().stream().collect(
            Collectors.toMap(com.ge.apm.adapter.domain.persistence.entity.Task::getId, t -> t));
        enrichTasks(tasks, idToCount);
    }

    private void enrichTasks(List<com.ge.apm.adapter.domain.persistence.entity.Task> tasks,
        Map<Long, com.ge.apm.adapter.domain.persistence.entity.Task> idToCounts) {
        tasks.stream().forEach(task -> {
            com.ge.apm.adapter.domain.persistence.entity.Task count = idToCounts.get(task.getId());
            if (count != null) {
                task.setTotalCount(count.getTotalCount());
                task.setCompletedCount(count.getCompletedCount());
            }
        });
    }

    private List<com.ge.apm.adapter.domain.persistence.entity.Task> enrichTotalAndCompletedCountsForRootTasks(
        List<com.ge.apm.adapter.domain.persistence.entity.Task> rootTasks, String tenantUuid) {
        // query db to get json entities based on the parentTasks
        List<com.ge.apm.adapter.domain.persistence.entity.Task> jsonTasks = getChildrenTasksBasedOnParentIds(tenantUuid,
            rootTasks);
        // query db to get children entities based on the jsonTasks
        if (CollectionUtils.isNotEmpty(jsonTasks)) {
            // map json and children tasks
            getTotalAndCompletedCounts(jsonTasks);
            // map root and json tasks
            Map<Long, List<com.ge.apm.adapter.domain.persistence.entity.Task>> rootAndJsonTasksMap
                = mapParentAndChildrenTasks(rootTasks, jsonTasks);
        }
        return rootTasks;
    }

    protected List<com.ge.apm.adapter.domain.persistence.entity.Task> enrichTotalAndCompletedCountsForRootTasks(
        String tenantUuid) {
        List<com.ge.apm.adapter.domain.persistence.entity.Task> rootTasks = taskProcessorRepository.findRootTasks(
            tenantUuid);
        return enrichTotalAndCompletedCountsForRootTasks(tenantUuid, rootTasks);
    }

    private List<com.ge.apm.adapter.domain.persistence.entity.Task> enrichTotalAndCompletedCountsForRootTasks(
        String tenantUuid, List<com.ge.apm.adapter.domain.persistence.entity.Task> rootTasks) {
        if (CollectionUtils.isNotEmpty(rootTasks)) {
            List<com.ge.apm.adapter.domain.persistence.entity.Task> requestedRootTasks = new ArrayList<>();
            rootTasks.forEach(rootTask -> {
                if (!TaskStatus.COMPLETED.equals(rootTask.getStatus()) && !rootTask.getStatus().contains(
                    TaskStatus.ERROR)) {
                    requestedRootTasks.add(rootTask);
                }
            });
            if (CollectionUtils.isNotEmpty(requestedRootTasks)) {
                enrichTotalAndCompletedCountsForRootTasks(requestedRootTasks, tenantUuid);
            }
            return rootTasks;
        }
        return Collections.EMPTY_LIST;
    }

    private List<com.ge.apm.adapter.domain.persistence.entity.Task> getChildrenTasksBasedOnParentIds(String tenantUuid,
        List<com.ge.apm.adapter.domain.persistence.entity.Task> parentTasks) {
        return taskProcessorRepository.findChildrenTasksBasedOnParentTasks(tenantUuid,
            parentTasks.stream().map(parentTask -> parentTask.getId())
                .collect(Collectors.toCollection(ArrayList::new)));
    }

    private Map<Long, List<com.ge.apm.adapter.domain.persistence.entity.Task>> mapParentAndChildrenTasks(
        List<com.ge.apm.adapter.domain.persistence.entity.Task> parentTasks,
        List<com.ge.apm.adapter.domain.persistence.entity.Task> childrenTasks) {
        Map<Long, List<com.ge.apm.adapter.domain.persistence.entity.Task>> parentChildrenTasksMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(childrenTasks)) {
            for (com.ge.apm.adapter.domain.persistence.entity.Task childTask : childrenTasks) {
                if (parentChildrenTasksMap.get(childTask.getParent().getId()) != null) {
                    parentChildrenTasksMap.get(childTask.getParent().getId()).add(childTask);
                } else {
                    List<com.ge.apm.adapter.domain.persistence.entity.Task> newChildTasks = new ArrayList<>();
                    newChildTasks.add(childTask);
                    parentChildrenTasksMap.put(childTask.getParent().getId(), newChildTasks);
                }
            }
        }
        if (CollectionUtils.isNotEmpty(parentTasks)) {
            parentTasks.forEach(parentTask -> {
                if (parentChildrenTasksMap.get(parentTask.getId()) != null) {
                    parentTask.setTotalCount(parentChildrenTasksMap.get(parentTask.getId()).stream()
                        .mapToLong(child -> child.getTotalCount()).sum());
                    parentTask.setCompletedCount(parentChildrenTasksMap.get(parentTask.getId()).stream()
                        .mapToLong(child -> child.getCompletedCount()).sum());
                }
            });
        }
        return parentChildrenTasksMap;
    }

    @PostConstruct
    public void init() {
        debugEnabled.set(new AtomicBoolean(false));
    }

    @RequestMapping(method = RequestMethod.GET, value = "/v1/tasks", produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public List<Task> getTasks() {
        try {
            String tenantUuid = TenantContext.getInstance().getTenantUuid();
            if (StringUtils.isEmpty(tenantUuid)) {
                throw new IllegalStateException("Tenant not found from TenantContext");
            }
            MDC.put("tenant", tenantUuid);
            if (log.isDebugEnabled()) {
                log.info(String.format("Getting tasks for Tenant [%s]", tenantUuid));
            }
            List<com.ge.apm.adapter.domain.persistence.entity.Task> rootTasks
                = enrichTotalAndCompletedCountsForRootTasks(tenantUuid);
            return transformTasks(rootTasks);
        } catch (PersistenceException | JpaSystemException | InvalidDataAccessApiUsageException sqlException) {
            throw ExceptionUtil.wrapException(sqlException,
                ErrorConstants.POSTGRES_ERROR + " : Please contact predix support and provide this error.");
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = "/v1/tasks/{uuid}", produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public Task getTaskById(@PathVariable("uuid") String taskId,
        @RequestParam(required = false, defaultValue = "false") boolean includeAll,
        @RequestParam(required = false, defaultValue = "false") boolean debug) {
        try {
            debugEnabled.get().getAndSet(debug);
            String tenantUuid = TenantContext.getInstance().getTenantUuid();
            if (StringUtils.isEmpty(tenantUuid)) {
                throw new IllegalStateException("Tenant not found from TenantContext");
            }
            MDC.put("tenant", tenantUuid);
            if (log.isDebugEnabled()) {
                log.info(String.format("Getting tasks by taskUuid [%s] for Tenant [%s]", taskId, tenantUuid));
            }
            com.ge.apm.adapter.domain.persistence.entity.Task taskEntity = taskProcessorRepository
                .findByTenantUuidAndUuid(tenantUuid, taskId);
            if (taskEntity == null) {
                log.error(String.format("Task id %s not found for Tenant %s", taskId, tenantUuid));
                throw new NotFoundException(ErrorProvider.findError(ErrorConstants.NO_DATA_FOUND_COMMON));
            }
            Task task = transformTask(taskEntity);
            task.setChildren(fetchChildren(tenantUuid, task));
            // filter by includeAll flag, only childTask could be archived
            if (filterTask(includeAll, task)) {
                return new Task();
            }
            return task;
        } catch (PersistenceException | JpaSystemException | InvalidDataAccessApiUsageException sqlException) {
            throw ExceptionUtil.wrapException(sqlException,
                ErrorConstants.POSTGRES_ERROR + " : Please contact predix support and provide this error.");
        }
    }

    private boolean filterTask(@RequestParam(required = false, defaultValue = "false") boolean includeAll, Task task) {
        if (!includeAll) {
            if (CollectionUtils.isEmpty(task.getChildren()) && TaskStatus.ARCHIVED.equals(task.getStatus())) {
                return true;
            } else if (CollectionUtils.isNotEmpty(task.getChildren())) {
                List<Task> childrenTasks = new ArrayList<>();
                task.getChildren().forEach(jsonTask -> {
                    if (CollectionUtils.isNotEmpty(jsonTask.getChildren())) {
                        Iterator<Task> iterator = jsonTask.getChildren().iterator();
                        while (iterator.hasNext()) {
                            Task childTask = iterator.next();
                            if (TaskStatus.ARCHIVED.equals(childTask.getStatus())) {
                                iterator.remove();
                            }
                        }
                        childrenTasks.add(jsonTask);
                    } else {
                        if (!TaskStatus.ARCHIVED.equals(jsonTask.getStatus())) {
                            childrenTasks.add(jsonTask);
                        }
                    }
                });
                task.setChildren(childrenTasks);
            }
        }
        return false;
    }

    private boolean filterTask(@RequestParam(required = false, defaultValue = "false") boolean includeAll,
        Ingestion task) {
        if (!includeAll) {
            if (CollectionUtils.isEmpty(task.getChildren()) && TaskStatus.ARCHIVED.equals(task.getStatus())) {
                return true;
            } else if (CollectionUtils.isNotEmpty(task.getChildren())) {
                List<Ingestion> childrenTasks = new ArrayList<>();
                task.getChildren().forEach(jsonTask -> {
                    if (CollectionUtils.isNotEmpty(jsonTask.getChildren())) {
                        Iterator<Ingestion> iterator = jsonTask.getChildren().iterator();
                        while (iterator.hasNext()) {
                            Ingestion childTask = iterator.next();
                            if (TaskStatus.ARCHIVED.equals(childTask.getStatus())) {
                                iterator.remove();
                            }
                        }
                        childrenTasks.add(jsonTask);
                    } else {
                        if (!TaskStatus.ARCHIVED.equals(jsonTask.getStatus())) {
                            childrenTasks.add(jsonTask);
                        }
                    }
                });
                task.setChildren(childrenTasks);
            }
        }
        return false;
    }

    private List<Task> fetchChildren(String tenantUuid, Task parentTask) {
        List<Task> children = transformTasks(
            taskProcessorRepository.findChildrenIncludeArchived(tenantUuid, parentTask.getUuid()));
        boolean skipFetch = false;
        if (CollectionUtils.isNotEmpty(children)) {
            skipFetch = taskProcessorRepository.findCountOfAllChildren(children.get(0).getUuid(), tenantUuid) == 0
                ? true : false;
        }
        for (Task child : children) {
            if (!skipFetch) {
                child.setChildren(fetchChildren(tenantUuid, child));
            }
            if (parentTask.getTotalCount() != null) {
                parentTask.setTotalCount(children.stream().filter(
                    filteredChild -> filteredChild.getTotalCount() != null)
                    .mapToLong(filteredChild -> filteredChild.getTotalCount()).sum());
            }
            if (parentTask.getCompletedCount() != null) {
                parentTask.setCompletedCount(children.stream().filter(
                    filteredChild -> filteredChild.getCompletedCount() != null)
                    .mapToLong(filteredChild -> filteredChild.getCompletedCount()).sum());
            }
        }
        return children;
    }

    private List<Ingestion> fetchChildren(String tenantUuid, Ingestion parentTask) {
        List<Ingestion> children = transformIngestionLog(
            taskProcessorRepository.findChildrenIncludeArchived(tenantUuid, parentTask.getUuid()));
        boolean skipFetch = false;
        if (CollectionUtils.isNotEmpty(children)) {
            skipFetch = taskProcessorRepository.findCountOfAllChildren(children.get(0).getUuid(), tenantUuid) == 0
                ? true : false;
        }
        for (Ingestion child : children) {
            if (!skipFetch) {
                child.setChildren(fetchChildren(tenantUuid, child));
            }
            if (parentTask.getTotalCount() != null) {
                parentTask.setTotalCount(children.stream().filter(
                    filteredChild -> filteredChild.getTotalCount() != null)
                    .mapToLong(filteredChild -> filteredChild.getTotalCount()).sum());
            }
            if (parentTask.getCompletedCount() != null) {
                parentTask.setCompletedCount(children.stream().filter(
                    filteredChild -> filteredChild.getCompletedCount() != null)
                    .mapToLong(filteredChild -> filteredChild.getCompletedCount()).sum());
            }
        }
        return children;
    }

    private List<Task> transformTasks(List<com.ge.apm.adapter.domain.persistence.entity.Task> tasks) {
        return tasks.parallelStream().map(this::transformTask).collect(Collectors.toList());
    }

    private Task transformTask(com.ge.apm.adapter.domain.persistence.entity.Task task) {
        Task dto = new Task();
        dto.setUuid(task.getUuid());
        dto.setDescription(task.getDescription());
        dto.setStatus(task.getStatus());
        dto.setStartTime(dateFormatter.format(
            LocalDateTime.ofInstant(Instant.ofEpochMilli(task.getCreatedOn().getTime()), ZoneId.systemDefault())));
        dto.setEndTime(dateFormatter.format(
            LocalDateTime.ofInstant(Instant.ofEpochMilli(task.getUpdatedOn().getTime()), ZoneId.systemDefault())));
        dto.setMessages(
            task.getIngestionLogMsgList() == null ? null : transformIngestionLogMsgs(task.getIngestionLogMsgList()));
        if (task.getTotalCount() != null || task.getTotalCount() != 0) {
            dto.setTotalCount(task.getTotalCount());
        }
        if (task.getCompletedCount() != null || task.getCompletedCount() != 0) {
            dto.setCompletedCount(task.getCompletedCount());
        }
        dto.setTaskType(task.getTaskType());
        if (task.getTaskResponse() != null) {
            dto.setTaskResponse(task.getTaskResponse());
        }
        return dto;
    }

    private List<IngestionLogMsg> transformIngestionLogMsgs(
        List<com.ge.apm.adapter.domain.persistence.entity.IngestionLogMsg> logMsgEntityList) {
        return logMsgEntityList.parallelStream().map(this::transformIngestionLogMsg).collect(Collectors.toList());
    }

    private IngestionLogMsg transformIngestionLogMsg(
        com.ge.apm.adapter.domain.persistence.entity.IngestionLogMsg logMsgEntity) {
        IngestionLogMsg logMsgDto = new IngestionLogMsg();
        logMsgDto.setCode(logMsgEntity.getMsgCode());
        logMsgDto.setType(logMsgEntity.getMsgType());
        logMsgDto.setMessage(logMsgEntity.getMsg());
        logMsgDto.setAction(logMsgEntity.getAction());
        logMsgDto.setResolution(logMsgEntity.getResolution());
        logMsgDto.setDateTime(dateFormatter.format(LocalDateTime
            .ofInstant(Instant.ofEpochMilli(logMsgEntity.getUpdatedOn().getTime()), ZoneId.systemDefault())));
        if (debugEnabled.get().get()) {
            logMsgDto.setActualMessage(logMsgEntity.getActualMsg());
        }
        return logMsgDto;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/v1/ingestionlogs/{uuid}",
        produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public Ingestion getIngestionLogById(@PathVariable String uuid,
        @RequestParam(required = false, defaultValue = "false") boolean includeAll) {
        try {
            String tenantUuid = TenantContext.getInstance().getTenantUuid();
            if (StringUtils.isEmpty(tenantUuid)) {
                throw new IllegalStateException("Tenant not found from TenantContext");
            }
            MDC.put("tenant", tenantUuid);
            if (log.isDebugEnabled()) {
                log.debug("Getting Ingestion logs by uuid [{}] for Tenant [{}]", uuid, tenantUuid);
            }
            com.ge.apm.adapter.domain.persistence.entity.Task taskEntity = taskProcessorRepository
                .findByTenantUuidAndUuid(tenantUuid, uuid);
            if (taskEntity == null) {
                throw new NotFoundException(ErrorProvider.findError(ErrorConstants.NO_DATA_FOUND_COMMON));
            }
            //enrichTotalAndCompletedCountsForParentTasks(Arrays.asList(taskEntity));
            Ingestion ingestion = transformIngestionLog(taskEntity);
            ingestion.setChildren(fetchChildren(tenantUuid, ingestion));
            // filter by includeAll flag, only childTask could be archived
            if (filterTask(includeAll, ingestion)) {
                return new Ingestion();
            }
            return ingestion;
        } catch (PersistenceException | JpaSystemException | InvalidDataAccessApiUsageException sqlException) {
            throw ExceptionUtil.wrapException(sqlException,
                ErrorConstants.POSTGRES_ERROR + " : Please contact predix support and provide this error.");
        }
    }

    private List<Ingestion> transformIngestionLog(Iterable<com.ge.apm.adapter.domain.persistence.entity.Task> tasks) {
        return StreamSupport.stream(tasks.spliterator(), true).map(this::transformIngestionLog).collect(
            Collectors.toList());
    }

    private Ingestion transformIngestionLog(com.ge.apm.adapter.domain.persistence.entity.Task task) {
        Ingestion dto = new Ingestion();

        dto.setUuid(task.getUuid());
        dto.setTenantUuid(task.getTenantUuid());
        LinkedList<com.ge.apm.adapter.domain.persistence.entity.Task> original = new LinkedList<>();
        original.add(task);
        dto.setStatus(task.getStatus());
        dto.setCreatedOn(task.getCreatedOn());
        dto.setUpdatedOn(task.getUpdatedOn());
        String description = task.getDescription();
        if (description != null) {
            dto.setName(parseFileName(description));
            dto.setSize(parseFileSize(description));
        }
        dto.setMessages(
            task.getIngestionLogMsgList() == null ? null : transformIngestionLogMsgs(task.getIngestionLogMsgList()));
        if (task.getTotalCount() != null || task.getTotalCount() != 0) {
            dto.setTotalCount(task.getTotalCount());
        }
        if (task.getCompletedCount() != null || task.getCompletedCount() != 0) {
            dto.setCompletedCount(task.getCompletedCount());
        }
        dto.setTaskType(task.getTaskType());
        return dto;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/v1/ingestionlogs", produces = MediaType.APPLICATION_JSON)
    @ResponseBody
    public IngestionPage getIngestionLogs(@RequestParam(required = false, defaultValue = "1") int currentPage,
        @RequestParam(required = false, defaultValue = "DESC") final String sortOrder,
        @RequestParam(required = false, defaultValue = EMPTY) String searchField,
        @RequestParam(required = false, defaultValue = EMPTY) String searchValue,
        @RequestParam(required = false, defaultValue = "createdOn") String sortBy,
        @RequestParam(required = false, defaultValue = "10") int pageValue) throws BadRequestException {
        try {
            String tenantUuid = TenantContext.getInstance().getTenantUuid();
            if (StringUtils.isEmpty(tenantUuid)) {
                throw new IllegalStateException("Tenant not found from TenantContext");
            }
            MDC.put("tenant", tenantUuid);

            if (sortBy != null) {
                Boolean isValid = false;
                for (TaskSortColumns column : TaskSortColumns.values()) {
                    if (sortBy.equalsIgnoreCase(column.name())) {
                        isValid = true;
                        break;
                    }
                }
                if (!isValid) {
                    String inputParam = "sortBy " + sortBy;
                    String validValues = Arrays.toString(TaskSortColumns.values());
                    throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_INPUT_PARAM),
                        inputParam, validValues);
                }
            } else {
                sortBy = TaskSortColumns.CREATEDON.name();
            }

            if (log.isDebugEnabled()) {
                log.info("Getting Ingestion logs for Tenant [{}]", tenantUuid);
            }
            int pageId = currentPage;
            pageId = pageId > 0 ? pageId - 1 : 0; //ensures no lower limit out of bounds errors

            String updatedSortBy = sortBy;
            updatedSortBy = (updatedSortBy.compareTo("name") == 0 ? "adapterConfig.name" : updatedSortBy);

            return getIngestionPage(sortOrder, searchField, pageValue, searchValue, tenantUuid, pageId, updatedSortBy);
        } catch (PersistenceException | JpaSystemException | InvalidDataAccessApiUsageException sqlException) {
            throw ExceptionUtil.wrapException(sqlException,
                ErrorConstants.POSTGRES_ERROR + " : Please contact predix support and provide this error.");
        }
    }

    private IngestionPage getIngestionPage(String sortOrder, String searchField, int pageValue, String paramSearchValue,
        String tenantUuid, int pageId, String sortBy) {
        IngestionPage ingestionPage = new IngestionPage();
        List<Ingestion> ingestionList = new ArrayList<>();
        if (searchField.equalsIgnoreCase(EMPTY)) {
            final PageRequest page = new PageRequest(pageId, pageValue,
                "DESC".equalsIgnoreCase(sortOrder) ? Direction.DESC : Direction.ASC, sortBy);
            Page<com.ge.apm.adapter.domain.persistence.entity.Task> pages = taskProcessorRepository.findRootTasks(
                tenantUuid, page);
            ingestionPage.setTotalPages(pages.getTotalPages());
            ingestionPage.setTotalItems(new Long(pages.getTotalElements()).intValue());
            //enrichTotalAndCompletedCountsForParentTasks(pages.getContent());
            ingestionList = transformIngestionLog(
                enrichTotalAndCompletedCountsForRootTasks(tenantUuid, pages.getContent()));
        } else {
            String searchValue = paramSearchValue;
            final PageRequest page = new PageRequest(pageId, pageValue,
                "DESC".equalsIgnoreCase(sortOrder) ? Direction.DESC : Direction.ASC, sortBy);
            if (!searchField.equalsIgnoreCase(TaskSearchColumns.CREATEDON.name()) && !searchField.equalsIgnoreCase(
                TaskSearchColumns.UPDATEDON.name())) {
                searchValue = searchValue.replace('*', '%');
                searchValue = searchValue.concat("%");
            }
            ingestionList = getIngestionDtoSearch(tenantUuid, ingestionPage, searchField, searchValue, page,
                ingestionList);
        }
        ingestionPage.setDtoList(ingestionList);
        ingestionPage.setItemsOnPage(ingestionList.size());
        ingestionPage.setCurrentPage(pageId + 1);
        return ingestionPage;
    }

    private List<Ingestion> getIngestionDtoSearch(String tenantUuid, IngestionPage ingestionPage, String searchField,
        String searchValue, PageRequest page, List<Ingestion> paramIngestions) {
        List<Ingestion> ingestions = new ArrayList<>();
        ingestions.addAll(paramIngestions);
        Date startDate = null;
        Date endDate = null;
        if (searchField.equalsIgnoreCase(TaskSearchColumns.CREATEDON.name()) || searchField.equalsIgnoreCase(
            TaskSearchColumns.UPDATEDON.name())) {
            String start;
            String end;
            try {
                start = searchValue.substring(0, searchValue.indexOf('-'));
                end = searchValue.substring(searchValue.indexOf('-') + 1);
            } catch (Exception ex) {
                log.error("[GET ingestion logs paginated]", ex);
                throw ex;
            }
            Long startLong = Long.parseLong(start);
            Long endLong = Long.parseLong(end);
            startDate = new Date(startLong);
            endDate = new Date(endLong);
        }
        Page<com.ge.apm.adapter.domain.persistence.entity.Task> pages = null;
        if (searchField.equalsIgnoreCase(TaskSearchColumns.CREATEDON.name())) {
            pages = taskProcessorRepository.searchCreatedOn(tenantUuid, startDate, endDate, page);
        } else if (searchField.equalsIgnoreCase(TaskSearchColumns.UPDATEDON.name())) {
            pages = taskProcessorRepository.searchUpdatedOn(tenantUuid, startDate, endDate, page);
        } else if (searchField.equalsIgnoreCase(TaskSearchColumns.STATUS.name())) {
            if (searchValue != null) {
                searchValue = searchValue.toUpperCase(Locale.getDefault());
            }
            pages = taskProcessorRepository.searchStatusWildcard(tenantUuid, searchValue, page);
        } else if (searchField.equalsIgnoreCase(TaskSearchColumns.UUID.name())) {
            pages = taskProcessorRepository.searchUuidWildcard(tenantUuid, searchValue, page);
        } else {
            String inputParam = "searchField " + searchField;
            String validValues = Arrays.toString(TaskSearchColumns.values());
            throw new BadRequestException(ErrorProvider.findError(ErrorConstants.INVALID_INPUT_PARAM), inputParam,
                validValues);
        }
        enrichTotalAndCompletedCountsForRootTasks(tenantUuid, pages.getContent());
        ingestions = transformIngestionLog(pages.getContent());
        ingestionPage.setTotalItems((int) pages.getTotalElements());
        ingestionPage.setTotalPages(pages.getTotalPages());
        return ingestions;
    }

    private enum TaskSortColumns {
        CREATEDON,
        UPDATEDON,
        STATUS;
    }

    private enum TaskSearchColumns {
        CREATEDON,
        UPDATEDON,
        STATUS,
        UUID;
    }
}
