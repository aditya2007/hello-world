/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.core.BaseType;
import com.ge.apm.ccom.model.core.HierarchicalLink;
import com.ge.apm.ccom.model.network.connections.AssetConnection;
import com.ge.apm.ccom.model.registry.Site;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.util.AssetConstants;

@Component
@SuppressWarnings({ "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public class SiteTransformer extends BaseEntityTransformer<Site, com.ge.apm.asset.model.Site> {

    private final MeasurementLocationTransformer measurementLocationTransformer;

    @Autowired
    public SiteTransformer(MeasurementLocationTransformer measurementLocationTransformer, AssetClient assetClient) {
        super(assetClient, com.ge.apm.asset.model.Site.class);
        this.measurementLocationTransformer = measurementLocationTransformer;
    }

    @Override
    protected BaseType getTypeFromEntity(Site site) {
        return site.getType();
    }

    @Override
    protected com.ge.apm.asset.model.Site createDtoObject(Site entity) {
        return new com.ge.apm.asset.model.Site();
    }

    @Override
    protected String getParentSourceKey(Site site) {
        if (site.getRegistrationEnterprise() != null) {
            return site.getRegistrationEnterprise().getGUID().getValue();
        } else if (site.getRegistrationSite() != null) {
            return site.getRegistrationSite().getGUID().getValue();
        } else if (site.getParentLink().size() > 0) {
            HierarchicalLink hierarchicalLink = site.getParentLink().get(0);
            return hierarchicalLink.getParent().getGUID().getValue();
        }
        return null;
    }

    @Override
    protected Map<String, String> getConnections(Site site) {
        HashMap<String, String> connections = new HashMap<>();
        connections.put(AssetConstants.FROM_CCOM, site.getClass().getSimpleName());

        if (site.getRegistrationEnterprise() != null) {
            connections.put(AssetConstants.TO_CCOM, site.getRegistrationEnterprise().getClass().getSimpleName());
            connections.put(AssetConstants.IS_CONNECTIONS, Boolean.TRUE.toString());
            if (site.getRegistrationEnterprise().getGUID() == null
                || site.getRegistrationEnterprise().getGUID().getValue() == null
                || site.getRegistrationEnterprise().getGUID().getValue().length() == 0) {
                connections.put(AssetConstants.IS_ID_MISSING, Boolean.TRUE.toString());
                return connections;
            }
        } else if (site.getParentLink().size() > 0) {
            HierarchicalLink hierarchicalLink = site.getParentLink().get(0);
            if (hierarchicalLink.getParent() instanceof Site) {
                connections.put(AssetConstants.TO_CCOM, hierarchicalLink.getParent().getClass().getSimpleName());
                connections.put(AssetConstants.IS_CONNECTIONS, Boolean.TRUE.toString());
                if (hierarchicalLink.getParent().getGUID() == null
                    || hierarchicalLink.getParent().getGUID().getValue() == null
                    || hierarchicalLink.getParent().getGUID().getValue().length() == 0) {
                    connections.put(AssetConstants.IS_ID_MISSING, Boolean.TRUE.toString());
                    return connections;
                }
            }
        }

        /*if (site.getRegistrationSite() != null) {
            connections.put(AssetConstants.TO_CCOM, site.getRegistrationSite().getClass().getSimpleName());
            connections.put(AssetConstants.IS_CONNECTIONS, Boolean.TRUE.toString());
            if (site.getRegistrationSite().getGUID() == null
                || site.getRegistrationSite().getGUID().getValue() == null
                || site.getRegistrationSite().getGUID().getValue().length() == 0) {
                connections.put(AssetConstants.IS_ID_MISSING, Boolean.TRUE.toString());
                return connections;
            }
        }*/

        if (site.getControllingEnterprise() != null) {
            connections.put(AssetConstants.TO_CCOM, site.getControllingEnterprise().getClass().getSimpleName());
            connections.put(AssetConstants.IS_CONNECTIONS, Boolean.TRUE.toString());
            if (site.getControllingEnterprise().getGUID() == null
                || site.getControllingEnterprise().getGUID().getValue() == null
                || site.getControllingEnterprise().getGUID().getValue().length() == 0) {
                connections.put(AssetConstants.IS_ID_MISSING, Boolean.TRUE.toString());
                return connections;
            }
        }

        if (site.getEquivalentSegment() != null) {
            connections.put(AssetConstants.TO_CCOM, site.getEquivalentSegment().getClass().getSimpleName());
            connections.put(AssetConstants.IS_CONNECTIONS, Boolean.TRUE.toString());
            if (site.getEquivalentSegment().getGUID() == null
                || site.getEquivalentSegment().getGUID().getValue() == null
                || site.getEquivalentSegment().getGUID().getValue().length() == 0) {
                connections.put(AssetConstants.IS_ID_MISSING, Boolean.TRUE.toString());
                return connections;
            }
        }

        return connections;
    }

    @Override
    protected String getParentPrefix(Site site) {
        if (site.getRegistrationEnterprise() != null) {
            return Prefixes.Enterprises;
        } else if (site.getParentLink().size() > 0 && site.getParentLink().get(0).getParent() instanceof Site) {
            return Prefixes.Sites;
        }
        return null;
    }

    @Override
    protected String getTypePrefix(Site entityObject) {
        return Prefixes.SiteTypes;
    }

    @Override
    protected void transformConnections(Site site, com.ge.apm.asset.model.Site siteDto) {
        if (site.getToConnection() != null && site.getToConnection().size() > 0) {
            if (siteDto.getConnections() == null) {
                siteDto.setConnections(new LinkedHashMap<>());
            }
            for (AssetConnection assetConnection : site.getToConnection()) {
                String type = assetConnection.getType().getName().getValue();
                if (!siteDto.getConnections().containsKey(type)) {
                    siteDto.getConnections().put(type, new LinkedHashSet<>());
                }
                //Do uri lookup on asset side
                siteDto.getConnections().get(type).add(assetConnection.getTo().getGUID().getValue());
            }
        }
    }

    @Override
    protected void transformOtherParts(Site site, com.ge.apm.asset.model.Site siteDto,
        TransformResponse transformResponse) {
        if (site.getRegisteredMeasurementLocation().size() > 0) {
            measurementLocationTransformer.transformForSite(siteDto.getSourceKey(),
                site.getRegisteredMeasurementLocation(), transformResponse);
        }
    }

    @Override
    public void doDispatch() throws ServiceException {
        super.doDispatch();
        measurementLocationTransformer.doDispatch();
    }

    @Override
    protected String getPrefix() {
        return Prefixes.Sites;
    }

    @Override
    public int order() {
        return Priority.site.priority();
    }

    @Override
    public Class<Site> supportedCcomClass() {
        return Site.class;
    }

    @Override
    protected void validateEntity(Site entityObject) throws ServiceException {
        // no operation
    }
}
