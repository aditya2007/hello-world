/********************************************************************************
 * Copyright \(c\) 2015-2017 GE Digital. All rights reserved.                   *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter;

import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.ImportResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.ge.apm.service.instances.filter.ServiceInstancesFilter;
import com.ge.apm.util.interceptor.GzipHttpRequestInterceptor;

@Slf4j
@Configuration
@EnableAutoConfiguration
@ComponentScan(basePackages = { "org.apache.camel.spring.boot", "com.ge.apm.adapter", "com.ge.stuf", "com.ge.asset",
    "com.ge.apm.datasource", "com.ge.apm.commons.logging", "com.ge.apm.common.config", "com.ge.apm.blob.factory", "com.ge.apm.blob.repository", "com.ge.apm.rest",
    "com.ge.apm.service", "com.ge.apm.blob.client" }, excludeFilters=
@Filter(type = FilterType.ASSIGNABLE_TYPE, value = ServiceInstancesFilter.class))
@ImportResource({ "classpath:security-config.xml", "classpath:cxf-servlet.xml" })
@EnableJpaRepositories(basePackages = { "com.ge.apm.adapter.domain.persistence.repository" })
@EnableScheduling
public class Application extends SpringBootServletInitializer {

    public static final String ERROR_EXECUTING_FLYWAY_MIGRATION = "Error executing flyway migration";

    @Value("${http.client.connection.timeout.ms}")
    private int connectionTimeout;

    @Value("${http.client.connection.request.timeout.ms}")
    private int connectionRequestTimeout;

    public static void main(String[] args) {
        new SpringApplicationBuilder(Application.class)
            // .environment(CloudFoundryVcapEnvironmentPostProcessor.class)
            .run(args);
    }

    @Bean
    public ServletRegistrationBean servletRegistrationBean() {
        CXFServlet cxfServlet = new CXFServlet();
        ServletRegistrationBean registrationBean = new ServletRegistrationBean(cxfServlet, true, "/v1/asset/*");
        registrationBean.setLoadOnStartup(1);
        return registrationBean;
    }

    @Bean
    public CommonsMultipartResolver multipartResolver() {
        return new CommonsMultipartResolver();
    }

    @Bean
    public RestTemplate restTemplate(ClientHttpRequestFactory clientHttpRequestFactory) {
        HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory
            = (HttpComponentsClientHttpRequestFactory) clientHttpRequestFactory;
        httpComponentsClientHttpRequestFactory.setConnectTimeout(connectionTimeout);
        httpComponentsClientHttpRequestFactory.setConnectionRequestTimeout(connectionRequestTimeout);
        RestTemplate restTemplate = new RestTemplate(httpComponentsClientHttpRequestFactory);
        restTemplate.getInterceptors().add(new GzipHttpRequestInterceptor());
        return restTemplate;
    }

}
