/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.instance;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

import com.ge.apm.adapter.s95.processor.IRootLevelProcessor;
import com.ge.apm.adapter.s95.processor.base.ObjectProcessor;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.core.AttributableEntity;
import com.ge.apm.ccom.model.core.BaseType;
import com.ge.apm.s95.model.Instance;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.Error.ErrorType;
import com.ge.asset.commons.validator.ValidationFailedException;

import static com.ge.asset.commons.errorprovider.ErrorConstants.CLASSIFICATION_MISSING_FOR_INSTANCE;

public abstract class InstanceObjectProcessor<T extends AttributableEntity, E extends BaseType>
    extends ObjectProcessor<Instance> {

    protected final Class<T> entityClazz;

    protected final Class<E> typeEntityClazz;

    protected InstanceObjectProcessor(Class<T> entityClazz, Class<E> typeEntityClazz) {
        this.entityClazz = entityClazz;
        this.typeEntityClazz = typeEntityClazz;
    }

    @Override
    public void process(Instance instance)
        throws IOException, IllegalAccessException, InstantiationException, ValidationFailedException {
        T entity = processInternal(instance);
        entityDispatcher.sendEntity(entity, IRootLevelProcessor.INSTANCES);
    }

    protected T processInternal(Instance instance)
        throws IOException, IllegalAccessException, InstantiationException, ValidationFailedException {
        T entity = entityClazz.newInstance();
        E typeEntity = typeEntityClazz.newInstance();
        if (StringUtils.isEmpty(instance.getClassification())) {
            Error classificationIdMissing = new Error(ErrorType.ERROR, CLASSIFICATION_MISSING_FOR_INSTANCE);
            classificationIdMissing.setPlaceHolders(new String[] { instance.getId() });
            classificationIdMissing.setResolutionPlaceHolders(new String[] { instance.getId() });
            List<Error> errorList = new ArrayList<>();
            errorList.add(classificationIdMissing);
            throw new ValidationFailedException(errorList);
        }
        processBasicProperties(instance, entity, typeEntity);
        assignEntityType(entity, typeEntity);
        processProperties(entity, instance);
        processReservedProperties(entity, instance);
        processOthers(entity, instance);
        return entity;
    }

    protected void processBasicProperties(Instance instance, AttributableEntity attributableEntity,
        BaseType typeEntity) {
        processBasicProperties(instance, attributableEntity);
        CcomTypeHelper.setUuidAndTag(typeEntity, instance.getClassification());
    }

    protected abstract void processOthers(T entity, Instance instance) throws IOException, ValidationFailedException;

    protected abstract void assignEntityType(T entity, E typeEntity);
}
