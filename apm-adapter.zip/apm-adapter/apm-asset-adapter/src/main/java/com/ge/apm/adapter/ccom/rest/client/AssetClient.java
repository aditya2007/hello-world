/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.rest.client;

import java.util.HashMap;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.common.util.DtoDispatcher;
import com.ge.apm.asset.model.Base;
import com.ge.apm.asset.model.MeasurementTag;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.support.RequestContext;
import com.ge.apm.common.support.RequestIdListener;
import com.ge.asset.commons.mq.constants.MessageConstants;

@Component
@Slf4j
public class AssetClient {

    private static final String TRACE_ID_HEADER_NAME = "X-Trace-Id";

    @Autowired
    protected DtoDispatcher dtoDispatcher;

    private static Map<String, String> getHeaders(String prefix) {
        Map<String, String> headers = new HashMap<>();
        headers.put(MessageConstants.AUTHORIZATION, RequestContext.get(RequestContext.AUTHORIZATION, String.class));
        headers.put(RequestIdListener.requestIdHeader, RequestContext.get(RequestContext.REQUEST_ID, String.class));
        headers.put(MessageConstants.TENANT_UUID, RequestContext.get(RequestContext.TENANT_UUID, String.class));
        headers.put(HttpHeaders.CONTENT_TYPE, org.springframework.http.MediaType.APPLICATION_JSON_VALUE);
        headers.put(HttpHeaders.ACCEPT, org.springframework.http.MediaType.APPLICATION_JSON_VALUE);
        headers.put(HttpHeaders.ACCEPT_ENCODING, "gzip");
        headers.put(MessageConstants.TRACE_UUID, RequestContext.get(RequestContext.REQUEST_ID, String.class));
        headers.put(MessageConstants.TASK_UUID, RequestContext.get(RequestContext.SERVICE_INFO, String.class));
        headers.put(MessageConstants.ASSET_PREFIX, prefix);
        return headers;
    }

    @SuppressWarnings("unchecked")
    public <T extends Base> void create(String prefix, T... dtos) throws ServiceException {
        if (dtos != null && dtos.length > 0) {
            if (log.isTraceEnabled()) {
                log.trace("Asset client creating " + dtos.length + " entities of " + dtos.getClass());
            }
            dtoDispatcher.initialize(getHeaders(prefix));
            dtoDispatcher.sendDtos(dtos);
        }
    }

    @SuppressWarnings("unchecked")
    public <T extends Base> void update(String prefix, T... dtos) throws ServiceException {
        if (dtos != null && dtos.length > 0) {
            if (log.isTraceEnabled()) {
                log.trace("Asset client updating " + dtos.length + " entities of " + dtos.getClass());
            }
            dtoDispatcher.initialize(getHeaders(prefix));
        }
    }

    public void associateTag(String monitoredEntityUri, MeasurementTag... tagDtos) throws ServiceException {
        if (tagDtos != null && tagDtos.length > 0) {
            if (log.isTraceEnabled()) {
                log.trace("Asset client associating " + tagDtos.length + " tags to " + monitoredEntityUri);
            }
            dtoDispatcher.initialize(getHeaders(Prefixes.MeasurementTags));
            dtoDispatcher.sendDtos(tagDtos);
        }
    }
}
