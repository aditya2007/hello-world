/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.instance;

import java.io.IOException;

import org.springframework.stereotype.Component;

import com.ge.apm.ccom.model.registry.Site;
import com.ge.apm.ccom.model.registry.SiteType;
import com.ge.apm.s95.model.Instance;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
public class SiteInstanceProcessor extends InstanceObjectProcessor<Site, SiteType> {

    public SiteInstanceProcessor() {
        super(Site.class, SiteType.class);
    }

    @Override
    protected void assignEntityType(Site entity, SiteType typeEntity) {
        entity.setType(typeEntity);
    }

    @Override
    protected void processOthers(Site entity, Instance instance) throws IOException, ValidationFailedException {
        //no-op
    }
}
