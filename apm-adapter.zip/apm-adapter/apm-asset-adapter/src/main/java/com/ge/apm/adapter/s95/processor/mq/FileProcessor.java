/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.mq;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.ge.apm.adapter.domain.persistence.entity.Task;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.apm.adapter.s95.rest.client.BlobClient;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Created by 212576241 on 4/24/17.
 */
@Component
@Slf4j
public class FileProcessor {

    @Autowired
    BlobClient blobArchiveClient;

    @Autowired
    private ITaskProcessorRepository taskProcessorRepository;

    private static final String delimiter = "/";

    private static final String folder = "apm-asset";

    public void uploadFile(Exchange exchange) throws ValidationFailedException, IOException {
        // get root task from db
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        Task task = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, taskId);
        exchange.getIn().setHeader(MessageConstants.PERDIX_BLOB_FILE_KEY, task.getUuid());

        StopWatch stufStopWatch = new StopWatch("Uploading to BLOB");
        stufStopWatch.start();

        String downloadUrl = blobArchiveClient.getBlobArchiveClient().archiveBlob(exchange,
            exchange.getIn().getBody(InputStream.class));
        stufStopWatch.stop();
        log.info(stufStopWatch.shortSummary());

        // update task with taskResponse
        Map<String, String> downloadUrlMap = new HashMap<>();
        downloadUrlMap.put("url1:", downloadUrl);
        JsonObject jsonObject = new JsonObject();
        jsonObject.add("responseUri", new Gson().toJsonTree(downloadUrlMap));
        task.setTaskResponse(getJsonNode(jsonObject));
        taskProcessorRepository.saveAndFlush(task);

        exchange.getOut().setBody(downloadUrl);
        exchange.getOut().setHeaders(exchange.getIn().getHeaders());
    }

    public void downloadFile(Exchange exchange) throws ValidationFailedException, IOException {
        StopWatch stufStopWatch = new StopWatch("Downloading from BLOB");
        stufStopWatch.start();
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        String downloadUrl = exchange.getIn().getBody(String.class);
        InputStream inputStream = blobArchiveClient.getBlobArchiveClient().downloadBlob(exchange, downloadUrl);
        stufStopWatch.stop();
        log.info(stufStopWatch.shortSummary());
        exchange.getOut().setBody(inputStream);
        exchange.getOut().setHeaders(exchange.getIn().getHeaders());
    }

    private JsonNode getJsonNode(JsonObject jsonObject) throws IOException {
        Gson gson = new Gson();
        String json = gson.toJson(jsonObject);
        return new ObjectMapper().readTree(json);
    }
    
}
