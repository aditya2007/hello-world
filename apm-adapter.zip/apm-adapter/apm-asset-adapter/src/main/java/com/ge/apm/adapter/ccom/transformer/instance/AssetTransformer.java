/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.asset.model.GeoLocation;
import com.ge.apm.asset.model.GeoPoint;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.core.BaseType;
import com.ge.apm.ccom.model.core.HierarchicalLink;
import com.ge.apm.ccom.model.custom.locatable.Location;
import com.ge.apm.ccom.model.custom.locatable.PostalAddress;
import com.ge.apm.ccom.model.registry.Asset;
import com.ge.apm.ccom.model.registry.Segment;
import com.ge.apm.ccom.model.tracking.geospatial.GPSLocation;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.util.AssetConstants;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
@SuppressWarnings(
    { "PMD.GodClass", "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public class AssetTransformer extends BaseEntityTransformer<Asset, com.ge.apm.asset.model.Asset> {

    private static final Comparator<GPSLocation> GPS_ORDER_COMPARATOR = new Comparator<GPSLocation>() {
        @Override
        public int compare(GPSLocation gpsLocX, GPSLocation gpsLocY) {
            int ox = Integer.MAX_VALUE;
            if (gpsLocX.getOrder() != null && gpsLocX.getOrder().getValue() != null) {
                ox = Integer.parseInt(gpsLocX.getOrder().getValue());
            }
            int oy = Integer.MAX_VALUE;
            if (gpsLocY.getOrder() != null && gpsLocY.getOrder().getValue() != null) {
                oy = Integer.parseInt(gpsLocY.getOrder().getValue());
            }
            return ox - oy;
        }
    };

    @Autowired
    public AssetTransformer(AssetClient assetClient) {
        super(assetClient, com.ge.apm.asset.model.Asset.class);
    }

    @Override
    protected BaseType getTypeFromEntity(Asset asset) {
        return asset.getType();
    }

    @Override
    protected com.ge.apm.asset.model.Asset createDtoObject(Asset entity) {
        return new com.ge.apm.asset.model.Asset();
    }

    @Override
    @SuppressWarnings("PMD.ConfusingTernary")
    protected String getParentSourceKey(Asset asset) {
        if (asset.getRegistrationSite() != null) {
            return asset.getRegistrationSite().getGUID().getValue();
        } else if (asset.getEquivalentSegment() != null) {
            return asset.getEquivalentSegment().getGUID().getValue();
        } else if (asset.getParentLink().size() > 0) {
            HierarchicalLink hierarchicalLink = asset.getParentLink().get(0);
            return hierarchicalLink.getParent().getGUID().getValue();
        }
        return null;
    }

    @Override
    protected Map<String, String> getConnections(Asset asset) {
        HashMap<String, String> connections = new HashMap<>();
        connections.put(AssetConstants.FROM_CCOM, asset.getClass().getSimpleName());

        if (asset.getRegistrationSite() != null) {
            connections.put(AssetConstants.TO_CCOM, asset.getRegistrationSite().getClass().getSimpleName());
            connections.put(AssetConstants.IS_CONNECTIONS, Boolean.TRUE.toString());
            if (asset.getRegistrationSite().getGUID() == null
                || asset.getRegistrationSite().getGUID().getValue() == null
                || asset.getRegistrationSite().getGUID().getValue().length() == 0) {
                connections.put(AssetConstants.IS_ID_MISSING, Boolean.TRUE.toString());
                return connections;
            }
        }

        if (asset.getEquivalentSegment() != null) {
            connections.put(AssetConstants.IS_CONNECTIONS, Boolean.TRUE.toString());
            connections.put(AssetConstants.TO_CCOM, asset.getEquivalentSegment().getClass().getSimpleName());
            if (asset.getEquivalentSegment().getGUID() == null
                || asset.getEquivalentSegment().getGUID().getValue() == null
                || asset.getEquivalentSegment().getGUID().getValue().length() == 0) {
                connections.put(AssetConstants.IS_ID_MISSING, Boolean.TRUE.toString());
                return connections;
            }
        }

        if (asset.getParentLink().size() > 0) {
            HierarchicalLink hierarchicalLink = asset.getParentLink().get(0);
            connections.put(AssetConstants.TO_CCOM, hierarchicalLink.getParent().getClass().getSimpleName());
            connections.put(AssetConstants.IS_CONNECTIONS, Boolean.TRUE.toString());
            if (hierarchicalLink.getParent().getGUID() == null
                || hierarchicalLink.getParent().getGUID().getValue() == null
                || hierarchicalLink.getParent().getGUID().getValue().length() == 0) {
                connections.put(AssetConstants.IS_ID_MISSING, Boolean.TRUE.toString());
                return connections;
            }
        }
        return connections;
    }

    @Override
    @SuppressWarnings("PMD.ConfusingTernary")
    protected String getParentPrefix(Asset asset) {
        if (asset.getRegistrationSite() != null) {
            return Prefixes.Sites;
        } else if (asset.getEquivalentSegment() != null) {
            return Prefixes.Segments;
        } else if (asset.getParentLink().size() > 0) {
            if (asset.getParentLink().get(0).getParent() instanceof Segment) {
                return Prefixes.Segments;
            } else if (asset.getParentLink().get(0).getParent() instanceof Asset) {
                return Prefixes.Assets;
            }
        }
        return null;
    }

    @Override
    protected String getTypePrefix(Asset entityObject) {
        return Prefixes.AssetTypes;
    }

    @Override
    protected void transformConnections(Asset asset, com.ge.apm.asset.model.Asset assetDto) {
        // no-op
    }

    /*
     * Transforms the geo location data.
     * 
     */
    @Override
    protected void transformOtherParts(Asset asset, com.ge.apm.asset.model.Asset assetDto,
        TransformResponse transformResponse) throws ServiceException, ValidationFailedException {
        if (asset instanceof com.ge.apm.ccom.model.custom.locatable.Asset) {
            com.ge.apm.ccom.model.custom.locatable.Asset locatableAsset
                = (com.ge.apm.ccom.model.custom.locatable.Asset) asset;
            GeoLocation geoLocation = new GeoLocation();
            if (locatableAsset.getLocation() != null) {
                Location location = locatableAsset.getLocation();
                if (location.getAddress() != null) {
                    com.ge.apm.asset.model.PostalAddress outAddr = constructPostalAddress(location);
                    geoLocation.setPostalAddress(outAddr);
                }

                List<GeoPoint> geoPoints = new ArrayList<>();

                location.getGPSLocations().sort(GPS_ORDER_COMPARATOR);
                for (GPSLocation gps : location.getGPSLocations()) {
                    GeoPoint point = constructGeoPoint(gps);
                    geoPoints.add(point);
                }
                geoLocation.setGeoPoints(geoPoints);
                geoLocation.setTimezone(location.getTimezone());
            }

            assetDto.setLocation(geoLocation);
        }
    }

    @SuppressWarnings("PMD.NPathComplexity")
    private GeoPoint constructGeoPoint(GPSLocation gps) {
        GeoPoint point = new GeoPoint();
        if (gps.getName() != null && gps.getName().getValue() != null) {
            point.setName(gps.getName().getValue());
        }
        if (gps.getOrder() != null && gps.getOrder().getValue() != null) {
            point.setOrder(Integer.parseInt(gps.getOrder().getValue()));
        }
        if (gps.getLatitude() != null && gps.getLatitude().getValue() != null) {
            point.setLatitude(Double.parseDouble(gps.getLatitude().getValue()));
        }
        if (gps.getLongitude() != null && gps.getLongitude().getValue() != null) {
            point.setLongitude(Double.parseDouble(gps.getLongitude().getValue()));
        }
        if (gps.getElevation() != null && gps.getElevation().getValue() != null) {
            point.setAltitude(Double.parseDouble(gps.getElevation().getValue()));
        }
        return point;
    }

    private com.ge.apm.asset.model.PostalAddress constructPostalAddress(Location location) {
        PostalAddress inAddr = location.getAddress();
        com.ge.apm.asset.model.PostalAddress outAddr = new com.ge.apm.asset.model.PostalAddress();
        String[] lines = new String[inAddr.getStreet().size()];
        for (int idx = 0, size = inAddr.getStreet().size(); idx < size; idx++) {
            lines[idx] = inAddr.getStreet().get(idx);
        }
        outAddr.setStreet(lines);

        outAddr.setCity(inAddr.getCity());
        outAddr.setState(inAddr.getState());
        outAddr.setCountry(inAddr.getCountry());
        outAddr.setZipcode(inAddr.getZipcode());
        return outAddr;
    }

    @Override
    protected String getPrefix() {
        return Prefixes.Assets;
    }

    @Override
    public int order() {
        return Priority.asset.priority();
    }

    @Override
    public Class<Asset> supportedCcomClass() {
        return Asset.class;
    }

    @Override
    protected void validateEntity(Asset entityObject) throws ServiceException {
        // no operation
    }
}
