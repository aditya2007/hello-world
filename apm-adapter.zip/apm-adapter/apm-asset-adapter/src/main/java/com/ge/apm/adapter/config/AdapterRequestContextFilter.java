/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.config;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.ge.apm.common.support.RequestContext;

@Component
@Order(1)
public class AdapterRequestContextFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
        throws ServletException, IOException {
        RequestContext.put(RequestContext.AUTHORIZATION, request.getHeader(HttpHeaders.AUTHORIZATION));
        RequestContext.put(RequestContext.TENANT_UUID, request.getHeader(RequestContext.TENANT));
        RequestContext.put(RequestContext.REQUEST_ID, MDC.get("X-B3-TraceId"));
        try {
            filterChain.doFilter(request, response);
        } finally {
            RequestContext.destroy();
        }
    }
}
