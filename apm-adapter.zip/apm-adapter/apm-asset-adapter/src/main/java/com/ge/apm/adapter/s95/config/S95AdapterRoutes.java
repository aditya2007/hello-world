/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.config;

import com.ge.apm.adapter.common.config.AdapterRoutes;

/**
 * @author Chand Bhaverisetti 212432041
 * @version Feb 24, 2017
 * @since 1.0
 */
public class S95AdapterRoutes extends AdapterRoutes {

    public static final String S95_APP_ID = "4DA468EA288E4346B69D89427E1EEE79";

    public static final String CXFRS_VALIDATE_DATA
        = "cxfrs:///schema?resourceClasses=com.ge.apm.adapter.s95.api.IS95Schema";

    public static final String CXFRS_FILE_UPLOAD = "cxfrs://?resourceClasses=com.ge.apm.adapter.common.api.IFileUpload";

    public static final String RMQ_TASK = "ge.apm.asset.ingestion.task";

    public static final String RMQ_TASK_ROUTING_KEY = "asset.ingestion.task";

    public static final String DIRECT_ASSET_ERROR = "direct:apm.adapter.asset.error";

    public static final String DIRECT_ASSET_FILES = "direct:%s.process.asset.files";

    public static final String DIRECT_ZIP_FILE_PROCESSING = "direct:%s.process.asset.zip.file";

    public static final String DIRECT_ZIP_FILE_VALIDATE_AND_PROCESS = "direct:%s.validate.asset.zip.file";

    public static final String DIRECT_FILE_UPLOAD = "direct:%s.file.upload";

    public static final String DIRECT_FILE_DOWNLOAD = "direct:%s.file.download";
}
