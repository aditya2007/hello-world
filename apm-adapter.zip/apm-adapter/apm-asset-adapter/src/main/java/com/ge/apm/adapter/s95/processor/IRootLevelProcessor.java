/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor;

import java.io.IOException;

import com.ge.asset.commons.validator.ValidationFailedException;

public interface IRootLevelProcessor<T> {

    String TEMPLATES = "templates";

    String CLASSIFICATIONS = "classifications";

    String INSTANCES = "instances";

    String CONNECTIONS = "connections";

    String TAG_CLASSIFICATIONS = "tagClassifications";

    String TAG_ASSOCIATIONS = "tagAssociations";

    String GROUPS = "groups";

    String TEMPLATE_CONNECTIONS = "templateConnections";

    /**
     * Convert a JSON object into a CCOM object and dispatch it.
     *
     * @param object An object to parse the input JSON.
     *
     * @exception Exception if there was an error.
     */
    void process(T object)
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException;

    /**
     * Returns the supported field.
     *
     * @return The JSON field (for example, "classifications") that is supported by this processor.
     */
    String supportedField();

    /**
     * Returns the class to which the objs this proccessor is proccessing maps to
     *
     * @return The corresponding Object Class
     */
    Class<T> supportedClass();
}
