/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.config;

import java.net.ConnectException;

import com.rabbitmq.client.AlreadyClosedException;
import org.apache.camel.Exchange;
import org.apache.camel.component.rabbitmq.RabbitMQConstants;
import org.apache.camel.model.DataFormatDefinition;
import org.apache.camel.model.dataformat.SerializationDataFormat;
import org.apache.openjpa.lib.jdbc.ReportingSQLException;
import org.apache.openjpa.persistence.PersistenceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.transformer.EntityTransformer;
import com.ge.apm.adapter.common.config.AdapterRouteBuilder;
import com.ge.apm.adapter.common.packer.AssetUnpacker;
import com.ge.apm.adapter.common.processor.UploadTaskProcessor;
import com.ge.apm.adapter.config.TenantContextBean;
import com.ge.apm.adapter.s95.processor.exception.EntityExceptionProcessor;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.mq.util.CryptoHelper;

@Component
public class CcomAdapterRouteBuilder extends AdapterRouteBuilder {

    @Value("${rabbitmq.concurrentVirtualConsumers}")
    private Integer virtualConsumerCount;

    @Value("${rabbitmq.msgRate}")
    private Integer publishingRate;

    protected final DataFormatDefinition byteArrayDataFormat;

    @Autowired
    private UploadTaskProcessor taskProcessor;

    @Autowired
    private AssetUnpacker assetUnpacker;

    @Autowired
    private EntityTransformer entityTransformer;

    @Autowired
    private EntityExceptionProcessor entityExceptionProcessor;

    @Autowired
    private TenantContextBean tenantContextBean;

    @Autowired
    public CcomAdapterRouteBuilder(CryptoHelper cryptoHelper) {
        super(CcomAdapterRoutes.CCOM_APP_ID, cryptoHelper);
        this.byteArrayDataFormat = new SerializationDataFormat();

    }

    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void configure() throws Exception {
        super.configure();

        processAssetsRoute();

        processDtos();
        processAckDtos();
    }

    private void processAssetsRoute() {
        from(CcomAdapterRoutes.DIRECT_ASSET_CCOM_RECEIVER)
            .doTry()
                .setHeader(MessageConstants.MESSAGE_ID).simple("createEntities")
                .setHeader(MessageConstants.DESCRIPTION)
                .simple("Process ${headers.ApmAssetType} Asset entities: ${headers.ApmAssetDetail}")
                .to(String.format(CcomAdapterRoutes.DIRECT_ASSET_CCOM_DATA, appId))
            .doCatch(Exception.class)
                .to(String.format(CcomAdapterRoutes.LOG_ASSET_ERROR, appId))
            .end();

        from(String.format(CcomAdapterRoutes.DIRECT_ASSET_CCOM_DATA, appId))
            .doTry()
            .bean(taskProcessor, inProgressTask())
            .bean(entityTransformer, transformEntities())
                .to(String.format(CcomAdapterRoutes.LOG_ASSET_TRACE, appId))
            .doCatch(AlreadyClosedException.class, ConnectException.class)
                .bean(entityExceptionProcessor, rabbitmqException())
                .bean(taskProcessor, taskError())
            .doCatch(PersistenceException.class)
                .bean(entityExceptionProcessor, postgresException())
                .bean(taskProcessor, taskError())
            .doCatch(ReportingSQLException.class)
                .bean(entityExceptionProcessor, postgresException())
                .bean(taskProcessor, taskError())
            .doCatch(Exception.class)
                .to(String.format(CcomAdapterRoutes.LOG_ASSET_ERROR, appId))
                .bean(taskProcessor, taskError())
            .end();

    }

    private void processDtos() {
        from(CcomAdapterRoutes.DIRECT_ASSET_DTO)
            .marshal(byteArrayDataFormat)
            .marshal(zipDataFormat)
            .to(getHeaderEncryptorEndpoint())
            .throttle(publishingRate).asyncDelayed()
            .to(getRabbitmqEndpoint(CcomAdapterRoutes.RMQ_ASSET_DTO, CcomAdapterRoutes.RMQ_ASSET_DTO_ROUTING_KEY))
            .end();
    }

    private void processAckDtos() {
        from(getRabbitmqCustomEndpoint(CcomAdapterRoutes.RMQ_ASSET_DTO_ACK,
            CcomAdapterRoutes.RMQ_ASSET_DTO_ACK_ROUTING_KEY, virtualConsumerCount)).doTry().bean(tenantContextBean,
            "init")
            .to(getHeaderDecryptorEndpoint())
            .log("Received Ack for task: ${headers.ApmTaskUuid}")
            .unmarshal(zipDataFormat)
            .unmarshal(byteArrayDataFormat)
            .choice()
                .when(header(RabbitMQConstants.ROUTING_KEY)
                        .isEqualTo(CcomAdapterRoutes.RMQ_ASSET_DTO_ACK_COMPLETE_ROUTING_KEY))
                    .bean(taskProcessor, markCompletedTask())
                .otherwise()
                    .to(String.format(CcomAdapterRoutes.LOG_TASK_ERROR, appId))
                    .setProperty(Exchange.EXCEPTION_CAUGHT, body(Throwable.class)).bean(taskProcessor, taskError())
            .endDoTry().doFinally().bean(tenantContextBean, "destroy")
            .end();
    }
}
