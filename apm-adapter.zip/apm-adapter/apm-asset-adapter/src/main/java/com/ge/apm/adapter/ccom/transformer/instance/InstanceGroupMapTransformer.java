/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.DtoQueueHolder;
import com.ge.apm.adapter.ccom.transformer.IEntityTransformer;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.types.TextType;
import com.ge.apm.ccom.model.groups.InstanceGroupMap;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Transformer for InstanceGroupMap. Creates a map between a Group to allowed entities.
 */
@Component
@SuppressWarnings({ "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public class InstanceGroupMapTransformer extends DtoQueueHolder<com.ge.apm.asset.model.InstanceGroupMap>
    implements IEntityTransformer<InstanceGroupMap> {

    private static String typeUri;

    @Autowired
    public InstanceGroupMapTransformer(AssetClient assetClient) {
        super(assetClient, com.ge.apm.asset.model.InstanceGroupMap.class);
    }

    /**
     * Interface method overridden for special behavior within InstanceGroupMap.
     */
    @Override
    public TransformResponse transform(InstanceGroupMap entity) throws ServiceException, ValidationFailedException {
        TextType nameValue = new TextType();
        nameValue.setValue("Group Association");
        entity.setName(nameValue);
        TransformResponse transformResponse = new TransformResponse();
        transformInstanceGroupMap(entity);
        transformResponse.setStatus(TransformResponse.EntityResponseStatus.OK);
        return transformResponse;
    }

    /**
     * Create the com.ge.apm.asset.model.InstanceGroupMap DTO and sets the properties.
     *
     * @param instanceSourceKey sourceKey for the instance(enterprise, site, segment & asset) object
     * @param instancePrefix prefix of instance
     * @param groupSourceKey source key of the Group object
     *
     * @return InstanceGroupMap object
     */
    private com.ge.apm.asset.model.InstanceGroupMap createDto(String instanceSourceKey, String instancePrefix,
        String groupSourceKey) {
        com.ge.apm.asset.model.InstanceGroupMap dto = new com.ge.apm.asset.model.InstanceGroupMap();
        dto.setGroupSourceKey(groupSourceKey);
        dto.setInstancePrefix(instancePrefix);
        dto.setInstanceSourceKey(instanceSourceKey);
        return dto;
    }

    protected String getPrefix() {
        return Prefixes.AssetGroupAssociations;
    }

    @Override
    public Class<InstanceGroupMap> supportedCcomClass() {
        return InstanceGroupMap.class;
    }

    /**
     * Creates and persists the InstanceGroupMap DTO after performing necessary validations.
     *
     * @param instanceGroupMap InstanceGroupMap object
     */
    @SuppressWarnings("PMD")
    private void transformInstanceGroupMap(InstanceGroupMap instanceGroupMap)
        throws ServiceException, ValidationFailedException {
        MimosaCcomCategory ccomCategory = instanceGroupMap.getEntityCcomClass();
        String instanceSourceKey = instanceGroupMap.getEntityId().getValue();
        String groupSourceKey = instanceGroupMap.getGroupId().getValue();
        String instancePrefix = getEntityPrefix(ccomCategory);
        com.ge.apm.asset.model.InstanceGroupMap dto = createDto(instanceSourceKey, instancePrefix, groupSourceKey);
        queueForDispatch(dto);
    }

    /**
     * Returns apm asset rest resource prefix based on the ccom object passed. groups allowed to be mapped with
     * asset, segment, site, & enterprise.
     *
     * @param ccomCategory ccomCategory
     *
     * @return the prefix for apm rest resources eg: /assets, /sites
     */
    String getEntityPrefix(MimosaCcomCategory ccomCategory) {
        switch (ccomCategory) {
            case ASSET:
                return Prefixes.Assets;
            case SEGMENT:
                return Prefixes.Segments;
            case SITE:
                return Prefixes.Sites;
            case ENTERPRISE:
                return Prefixes.Enterprises;
            default:
                throw new IllegalStateException("Invalid mapped instance CCOM class");
        }
    }

    /**
     * EntityTransformerFactory uses this to determine the order in which entities are persisted to predix asset. Look
     * for EntityTransformerFactory.doDispatch().
     */
    @Override
    public int order() {
        return Priority.instanceGroupMap.priority();
    }

    /**
     * <code>InstanceGroupMap</code> depends on <code>Group</code> while both are packaged in the <code>groups</code>
     * root level element in the Json payload. As such, this transformer cannot support fail-fast.
     *
     * @return <code>false</code>
     *
     * @see com.ge.apm.adapter.ccom.transformer.IEntityTransformer#supportsFailFast()
     */
    @Override
    public boolean supportsFailFast() {
        return false;
    }
}
