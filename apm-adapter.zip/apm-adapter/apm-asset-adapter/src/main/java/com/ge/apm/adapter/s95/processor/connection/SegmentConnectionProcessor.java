/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.connection;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.HierarchicalLink;
import com.ge.apm.ccom.model.network.connections.ConnectionType;
import com.ge.apm.ccom.model.network.connections.SegmentConnection;
import com.ge.apm.ccom.model.registry.Segment;
import com.ge.apm.ccom.model.registry.Site;
import com.ge.apm.s95.model.ToNode;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
public class SegmentConnectionProcessor extends ConnectionObjectProcessor<Segment> {

    public SegmentConnectionProcessor() {
        super(MimosaCcomCategory.SEGMENT, Segment.class);
    }

    @Override
    protected void processParentToNode(Segment segment, ToNode toNode) throws ValidationFailedException {
        if (toNode.getCcomClass() != MimosaCcomCategory.SITE && toNode.getCcomClass() != MimosaCcomCategory.SEGMENT) {
            Error error = new Error(Error.ErrorType.ERROR);
            if (toNode.getCcomClass().name().equals(MimosaCcomCategory.ENTERPRISE.name())) {
                error.setErrorCode(ErrorConstants.INVALID_PARENT_ENTERPRISE_FOR_SEGMENT);
            } else if (toNode.getCcomClass().name().equals(MimosaCcomCategory.ASSET.name())) {
                error.setErrorCode(ErrorConstants.INVALID_PARENT_ASSET_FOR_SEGMENT);
            } else {
                error.setErrorCode(ErrorConstants.INVALID_PARENT_FOR_SEGMENT);
            }
            error.setPlaceHolders(
                new String[] { segment.getGUID().getValue(), segment.getClass().getSimpleName(), toNode.getId(),
                    toNode.getCcomClass().name() });
            List<Error> errorList = new ArrayList<>();
            errorList.add(error);
            throw new ValidationFailedException(errorList);
        }
        if (toNode.getCcomClass() == MimosaCcomCategory.SITE) {
            Site site = new Site();
            CcomTypeHelper.setUuidAndTag(site, toNode.getId());
            segment.setRegistrationSite(site);
        } else {
            HierarchicalLink hierarchicalLink = new HierarchicalLink();
            Segment parent = new Segment();
            CcomTypeHelper.setUuidAndTag(parent, toNode.getId());
            hierarchicalLink.setParent(parent);
            segment.getParentLink().add(hierarchicalLink);
        }
    }

    @Override
    protected void addConnectionForToNode(Segment segment, ToNode toNode) {
        if (toNode.getCcomClass() != MimosaCcomCategory.SEGMENT) {
            throw new IllegalStateException(
                "Invalid connection: " + toNode + ". Segment can be connected to Segment only");
        }
        SegmentConnection segmentConnection = new SegmentConnection();
        segmentConnection.setType(new ConnectionType());
        segmentConnection.getType().setName(CcomTypeHelper.wrapText(toNode.getType()));
        segmentConnection.setTo(new Segment());
        segmentConnection.getTo().setGUID(CcomTypeHelper.wrapUUID(toNode.getId()));
        segment.getToConnection().add(segmentConnection);
    }
}
