/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.connection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ge.apm.adapter.s95.processor.IRootLevelProcessor;
import com.ge.apm.adapter.s95.processor.base.ObjectProcessor;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.AttributableEntity;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.network.connections.AssetConnection;
import com.ge.apm.ccom.model.network.topologies.AssetMesh;
import com.ge.apm.ccom.model.registry.Asset;
import com.ge.apm.s95.model.Connection;
import com.ge.apm.s95.model.ToNode;
import com.ge.asset.commons.validator.ValidationFailedException;

public abstract class ConnectionObjectProcessor<T extends AttributableEntity> extends ObjectProcessor<Connection> {

    protected final MimosaCcomCategory category;

    protected final Class<T> entityClazz;

    private final ThreadLocal<List<Entity>> entitiesToDispatch;

    private final ThreadLocal<Map<String, AssetMesh>> assetMeshMap;

    protected ConnectionObjectProcessor(MimosaCcomCategory category, Class<T> entityClazz) {
        this.category = category;
        this.entityClazz = entityClazz;

        this.entitiesToDispatch = new ThreadLocal<List<Entity>>() {
            @Override
            protected List<Entity> initialValue() {
                return new ArrayList<>();
            }
        };
        this.assetMeshMap = new ThreadLocal<Map<String, AssetMesh>>() {
            @Override
            protected Map<String, AssetMesh> initialValue() {
                return new HashMap<>();
            }
        };
    }

    @Override
    public void process(Connection connection)
        throws ValidationFailedException, IllegalAccessException, InstantiationException {
        try {
            T entity = entityClazz.newInstance();
            CcomTypeHelper.setUuidAndTag(entity, connection.getFrom().getId());
            queueEntity(entity);
            for (ToNode toNode : connection.getTo()) {
                processToNode(entity, toNode);
            }

            entitiesToDispatch.get().forEach(
                each -> entityDispatcher.sendEntity(each, IRootLevelProcessor.CONNECTIONS));
            assetMeshMap.get().values().forEach(
                each -> entityDispatcher.sendEntity(each, IRootLevelProcessor.CONNECTIONS));
        } finally {
            entitiesToDispatch.get().clear();
            assetMeshMap.get().clear();
        }
    }

    protected void queueEntity(Entity entity) {
        if (!entitiesToDispatch.get().contains(entity)) {
            entitiesToDispatch.get().add(entity);
        }
    }

    protected void queueAssetConnection(Asset asset, AssetConnection assetConnection) {
        if (!assetMeshMap.get().containsKey(asset.getGUID().getValue())) {
            assetMeshMap.get().put(asset.getGUID().getValue(), new AssetMesh());
        }
        assetMeshMap.get().get(asset.getGUID().getValue()).getConnection().add(assetConnection);
    }

    private void processToNode(T entity, ToNode toNode) throws ValidationFailedException {
        if (toNode.getType() == null || toNode.getType().isEmpty()) {
            throw new IllegalStateException("Connection type cannot be null or empty");
        }
        if (toNode.getType().toUpperCase().equals("PARENT")) {
            processParentToNode(entity, toNode);
        } else {
            addConnectionForToNode(entity, toNode);
        }
    }

    protected abstract void processParentToNode(T entity, ToNode toNode) throws ValidationFailedException;

    protected abstract void addConnectionForToNode(T entity, ToNode toNode);
}
