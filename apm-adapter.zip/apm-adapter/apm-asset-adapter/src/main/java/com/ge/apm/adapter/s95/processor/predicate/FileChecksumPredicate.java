/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.predicate;

import java.io.InputStream;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.domain.persistence.entity.FileChecksum;
import com.ge.apm.adapter.domain.persistence.entity.Task;
import com.ge.apm.adapter.domain.persistence.repository.IFileChecksumRepository;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.util.checksum.ChecksumUtil;

/**
 * Checks to see if the MD5 checksum of a given file payload matches those already being processed. If a match is found,
 * the current ingestion task is marked as {@link #TaskStatus.SKIPPED} with updated description detailing which other
 * task is in progress.
 *
 * @author Albert H. Yu hsiang-aiyu
 * @version 1.0 Mar 1, 2017
 * @since 1.0
 */
@Component
@Slf4j
public class FileChecksumPredicate implements Predicate {

    @Autowired
    private ITaskProcessorRepository taskRepository;

    @Autowired
    private IFileChecksumRepository fileChecksumRepository;

    @Override
    public boolean matches(Exchange exchange) {
        Message msg = exchange.getIn();

        String tenantUuid = msg.getHeader(MessageConstants.TENANT_UUID, String.class);
        String taskUuid = msg.getHeader(MessageConstants.TASK_UUID, String.class);
        String fileName = msg.getHeader(Exchange.FILE_NAME, String.class);

        InputStream is = msg.getBody(InputStream.class);
        String checksum = ChecksumUtil.generateHash(is);

        FileChecksum existing = fileChecksumRepository.findByTenantUuidAndChecksum(tenantUuid, checksum);
        if (existing == null) {
            FileChecksum fc = new FileChecksum();
            fc.setChecksum(checksum);
            fc.setTenantUuid(tenantUuid);
            fc.setName(fileName);

            Task task = taskRepository.findByTenantUuidAndUuid(tenantUuid, taskUuid);
            if (task == null) {
                throw new IllegalStateException(String
                    .format("Missing task %s for tenant %s while processing %s.", taskUuid, tenantUuid, fileName));
            }

            fc.setTask(task);
            FileChecksum persisted = fileChecksumRepository.saveAndFlush(fc);

            if (log.isDebugEnabled()) {
                log.debug("File {} checksum {} stored with id {}.", persisted.getName(), persisted.getChecksum(),
                    persisted.getId());
            }

            return false;
        } else {
            if (log.isDebugEnabled()) {
                log.debug("Matching checksum {} for payload {} detected for in-progress {} and checksum id {}.",
                    checksum, existing.getName(), fileName, existing.getId());
            }

            Task inProgress = taskRepository.findOne(existing.getTask().getId());
            StringBuilder description = new StringBuilder(msg.getHeader(MessageConstants.DESCRIPTION, String.class));
            description.append(" The checksum of this payload matched an in-progress ingestion. ").append(
                "Please check the status of task ").append(inProgress.getUuid()).append(
                " before uploading the same content again.");
            msg.setHeader(MessageConstants.DESCRIPTION, description.toString());

            return true;
        }
    }
}
