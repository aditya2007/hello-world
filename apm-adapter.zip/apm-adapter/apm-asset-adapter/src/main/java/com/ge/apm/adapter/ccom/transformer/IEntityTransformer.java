/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer;

import java.util.Arrays;

import org.springframework.util.StringUtils;

import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

public interface IEntityTransformer<T extends Entity> {

    /**
     * Transforms the given CCOM entity into a DTO which is ready to be created or updated in APM-Asset.
     *
     * @param entity A CCOM-Model object
     *
     * @exception ServiceException if there is an non-validation error
     * @exception ValidationFailedException if there is a validation error
     */
    TransformResponse transform(T entity) throws ServiceException, ValidationFailedException;

    /**
     * Send all DTOs to be created/updated to APM-Asset.
     *
     * @exception ServiceException if there is an error
     */
    void doDispatch() throws ServiceException;

    /**
     * Determines the order in which the transformers send DTOs to APM-Asset. If transformer1.order() <
     * transformer2.order(), transformer1 will send DTOs to APM-Asset before transformer2. The reason for ordering is to
     * handle dependencies. For example, EnterpriseTypes must be sent before Enterprises, since Enterprises point to
     * EnterpriseTypes.
     *
     * @return An integer representing the relative order in which to send DTOs.
     */
    int order();

    /**
     * Returns the supported CCOM class.
     *
     * @return The supported CCOM class
     */
    Class<T> supportedCcomClass();

    /**
     * Returns <code>true</code> if the transformer supports the fail-fast algorithm in payload processing. A fail-fast
     * algorithm can only be supported if the payload contain no circular dependency references. For example, all
     * classifications (types), tag classifications, and groups have such circular dependency.
     *
     * @return <code>true</code> by default to support
     */
    default boolean supportsFailFast() {
        return true;
    }

    default void validateName(String name, String jsonElementKey, String sourceKey) throws ValidationFailedException {
        if (StringUtils.isEmpty(name) || name.trim().length() == 0) {
            Error invalidNameError = new Error(Error.ErrorType.ERROR);
            invalidNameError.setErrorCode(ErrorConstants.EMPTY_NAME);
            invalidNameError.setPlaceHolders(
                new String[] { jsonElementKey, StringUtils.isEmpty(sourceKey) ? "" : " with ID: " + sourceKey });
            throw new ValidationFailedException(Arrays.asList(invalidNameError));
        }
    }

    default void baseValidateSourceKey(String sourceKey, String jsonElementKey, String refIdentifier)
        throws ValidationFailedException {
        if (StringUtils.isEmpty(sourceKey) || sourceKey.trim().length() == 0) {
            Error invalidSourceKeyError = new Error(Error.ErrorType.ERROR);
            invalidSourceKeyError.setErrorCode(ErrorConstants.MISSING_ID);
            invalidSourceKeyError.setPlaceHolders(new String[] { jsonElementKey, refIdentifier });
            throw new ValidationFailedException(Arrays.asList(invalidSourceKeyError));
        }
    }
}
