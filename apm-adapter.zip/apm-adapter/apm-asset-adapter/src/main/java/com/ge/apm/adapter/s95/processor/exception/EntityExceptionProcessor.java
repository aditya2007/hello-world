/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.exception;

import java.util.Arrays;

import com.fasterxml.jackson.core.JsonParseException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.rabbitmq.RabbitMQConstants;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.s95.exception.RecoverableException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.Error.ErrorType;
import com.ge.asset.commons.validator.ValidationFailedException;

/**
 * Created by 212576241 on 2/6/17.
 */

@Component
public class EntityExceptionProcessor implements Processor {

    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    @Override
    public void process(Exchange exchange) throws java.lang.Exception {
        exchange.getOut().setHeaders(exchange.getIn().getHeaders());
        Throwable caused = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
        //TODO: handle BLOB exceptions
        if (caused != null) {
            if (!(caused instanceof IllegalStateException || caused instanceof ValidationFailedException
                || caused instanceof JsonParseException) || caused instanceof ValidationFailedException) {
                //exchange.getOut().setHeaders(exchange.getIn().getHeaders());
                exchange.getOut().setHeader(RabbitMQConstants.REQUEUE, "true");
                throw new RecoverableException(caused);
            }
        }
        exchange.getOut().setBody(exchange.getIn().getBody());
    }

    public void rabbitmqException(Exchange exchange) {
        Throwable caused = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
        if (caused != null) {
            setExceptionInExchange(exchange, ErrorConstants.RABBITMQ_ERROR);
        }
    }

    public void postgresException(Exchange exchange) {
        Throwable caused = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
        if (caused != null) {
            setExceptionInExchange(exchange, ErrorConstants.POSTGRES_ERROR);
        }
    }

    private void setExceptionInExchange(Exchange exchange, String errorConstant) {
        Throwable caused = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
        String actualMsg = caused.getCause() != null ? caused.getCause().getMessage() : caused.getMessage();
        Error rmqError = new Error(ErrorType.ERROR);
        rmqError.setErrorCode(errorConstant);
        rmqError.setActualMessage(actualMsg);
        exchange.setProperty(Exchange.EXCEPTION_CAUGHT, new ValidationFailedException(Arrays.asList(rmqError)));
        exchange.getOut().setHeaders(exchange.getIn().getHeaders());
    }
}

