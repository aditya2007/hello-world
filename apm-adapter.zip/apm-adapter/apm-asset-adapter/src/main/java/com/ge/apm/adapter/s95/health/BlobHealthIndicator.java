/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.health;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.ge.apm.adapter.s95.rest.client.BlobClient;

@Component
@ConditionalOnExpression("${health.custom.blob.enabled:false}")
public class BlobHealthIndicator implements HealthIndicator {

    private final BlobClient blobArchiveClient;

    @Autowired
    public BlobHealthIndicator(BlobClient blobArchiveClient) {
        this.blobArchiveClient = blobArchiveClient;
    }

    @Override
    public Health health() {
        StopWatch watch = new StopWatch();

        watch.start("healthCheck");
        boolean blobUp = blobArchiveClient.getBlobArchiveClient().healthStatus();
        watch.stop();

        Health.Builder builder;
        if (blobUp) {
            builder = Health.up();
        } else {
            builder = Health.down();
        }

        builder.withDetail("apmBlob", watch.getLastTaskInfo());
        return builder.build();
    }
}
