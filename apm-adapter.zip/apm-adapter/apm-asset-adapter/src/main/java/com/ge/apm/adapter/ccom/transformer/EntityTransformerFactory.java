/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.asset.model.Attribute;
import com.ge.apm.asset.model.AttributeType;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.core.types.ValueContent;
import com.ge.apm.ccom.model.custom.AttributeDef;
import com.ge.apm.ccom.model.custom.ReservedAttribute;
import com.ge.apm.common.exception.DefaultErrorCode;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;
import com.ge.asset.commons.validator.ValidationResult;
import com.ge.asset.commons.validator.Validator;

@Component
@Slf4j
@SuppressWarnings(
    { "PMD.GodClass", "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity",
        "PMD.TooManyMethods" })
public class EntityTransformerFactory implements InitializingBean {

    private static final String TYPE_INT = "INT";

    private static final String TYPE_CHAR = "CHAR";

    private static final String TYPE_INTEGER = "Integer";

    private static final String TYPE_CHARACTER = "Character";

    private static final String ATTRIBUTE_TYPE = "attributeType";

    private static final String ATTRIBUTE_TYPE_VALIDATION = "attribute-type-validation";

    private static final String ATTRIBUTE_DEF_ID = "id";

    private static final String ATTRIBUTE_DEF_TYPE = "type";

    private static final Comparator<IEntityTransformer<? extends Entity>> byOrder = (e1, e2) -> Integer.compare(
        e1.order(), e2.order());

    private final List<IEntityTransformer<? extends Entity>> entityTransformers;

    private Map<Class<? extends Entity>, IEntityTransformer<? extends Entity>> entityTransformerMap;

    @Autowired
    public EntityTransformerFactory(List<IEntityTransformer<? extends Entity>> entityTransformers) {
        this.entityTransformers = entityTransformers;
    }

    public static Attribute transformAttribute(List<com.ge.apm.ccom.model.core.Attribute> attributes) {
        String attributeName = null;
        Attribute attributeDto = new Attribute();
        attributeDto.setValue(new ArrayList<>());
        for (com.ge.apm.ccom.model.core.Attribute attribute : attributes) {
            if (attributeName == null) {
                attributeName = attribute.getName().getValue();
            } else if (!attributeName.equals(attribute.getName().getValue())) {
                log.error("Cannot have attribute with multiple names: Name should be {} but was {}.", attributeName,
                    attribute.getName().getValue());
            }
            Attribute populatedAttribute = populateAttribute(attributeDto, attribute);
            if (populatedAttribute == null) {
                return null;
            } else {
                attributeDto = populatedAttribute;
            }
        }
        return attributeDto;
    }

    private static Attribute populateAttribute(Attribute attributeDto, com.ge.apm.ccom.model.core.Attribute attribute) {
        ValueContent valueContent = attribute.getValueContent();
        if (valueContent.getMeasure() != null) {
            ensureUnitIsSame(attributeDto, valueContent.getMeasure().getUnitType().getTag().getValue());
        }

        if (valueContent.getApmType() != null) {
            String type = constructAttributeType(valueContent);

            if (null == AttributeType.getAttributeType(type)) {
                return null;
            } else {
                attributeDto.setType(AttributeType.getAttributeType(type).name());

                String value = valueContent.getApmType().getAttributeValue().getValue();
                List<Object> values = new ArrayList<>();
                try {
                    if (value != null && !value.isEmpty()) {
                        values = AttributeType.getAttributeType(type).queryValues(value);
                    }
                } catch (Exception ex) {
                    log.error("Failed to process {}: {}", value, ex.getMessage(), ex);
                    return null;
                }
                if (values != null && !values.isEmpty()) {
                    attributeDto.getValue().add(values.get(0));
                }
                List<Object> metaInfo = null;
                if (valueContent.getApmType().getAttributeMetaInfo() != null
                    && valueContent.getApmType().getAttributeMetaInfo().size() > 0) {
                    metaInfo = new ArrayList<>();
                    for (AttributeDef attributeDef : valueContent.getApmType().getAttributeMetaInfo()) {
                        //metaInfo.add((Object) attributeDef);
                        Map<String, String> map = new LinkedHashMap<>();
                        map.put(ATTRIBUTE_DEF_ID, attributeDef.getId());
                        map.put(ATTRIBUTE_DEF_TYPE, attributeDef.getType());
                        metaInfo.add(map);
                    }
                }
                attributeDto.setMetaInfo(metaInfo);
            }
        }
        return attributeDto;
    }

    private static String constructAttributeType(ValueContent valueContent) {
        String type = valueContent.getApmType().getType().getValue();
        if (type.toUpperCase(Locale.getDefault()).startsWith(TYPE_INT)) {
            type = AttributeType.getName(TYPE_INTEGER);
        } else if (type.toUpperCase(Locale.getDefault()).startsWith(TYPE_CHAR)) {
            type = AttributeType.getName(TYPE_CHARACTER);
        }
        return type;
    }

    private static void ensureUnitIsSame(Attribute attributeDto, String unit) {
        if (attributeDto.getUnit() == null || attributeDto.getUnit().isEmpty()) {
            attributeDto.setUnit(unit);
        } else if (!attributeDto.getUnit().equals(unit)) {
            throw new IllegalStateException(
                "Cannot have attribute values with multiple Units: Unit should be " + attributeDto.getUnit()
                    + " but was " + unit);
        }
    }

    public static Object extractReservedAttributeValues(List<ReservedAttribute> reservedAttributeList) {
        //Here we are assuming that only order will be set only when values in ingestion is indicated as array.
        if (reservedAttributeList.size() == 1 && reservedAttributeList.get(0).getOrder() == null) {
            String attrType = reservedAttributeList.get(0).getValueContent().getApmType().getType().getValue()
                .toUpperCase();
            String attrValue = reservedAttributeList.get(0).getValueContent().getApmType().getAttributeValue()
                .getValue();
            Object convertedAttrValue;
            switch (attrType) {
                case "INTEGER":
                    convertedAttrValue = Integer.valueOf(attrValue);
                    break;
                case "DOUBLE":
                    convertedAttrValue = Double.valueOf(attrValue);
                    break;
                case "FLOAT":
                    convertedAttrValue = Float.valueOf(attrValue);
                    break;
                default:
                    convertedAttrValue = attrValue;
                    break;
            }
            return convertedAttrValue;
        } else {
            List<Object> attrValue = new ArrayList<>();
            for (ReservedAttribute reservedAttribute : reservedAttributeList) {
                switch (reservedAttribute.getValueContent().getApmType().getType().getValue().toUpperCase()) {
                    case "INTEGER":
                        attrValue.add(Integer
                            .valueOf(reservedAttribute.getValueContent().getApmType().getAttributeValue().getValue()));
                        break;
                    case "DOUBLE":
                        attrValue.add(Double
                            .valueOf(reservedAttribute.getValueContent().getApmType().getAttributeValue().getValue()));
                        break;
                    case "FLOAT":
                        attrValue.add(Float
                            .valueOf(reservedAttribute.getValueContent().getApmType().getAttributeValue().getValue()));
                        break;
                    default:
                        attrValue.add(reservedAttribute.getValueContent().getApmType().getAttributeValue().getValue());
                        break;
                }
            }
            return attrValue;
        }
    }

    @SuppressWarnings("PMD.LooseCoupling")
    public static LinkedHashMap<String, com.ge.apm.asset.model.Attribute> getAttributeMap(
        Map<String, List<com.ge.apm.ccom.model.core.Attribute>> attributeTypeMap) {
        Map<String, Object> validationContext = new HashMap<>();
        LinkedHashMap<String, com.ge.apm.asset.model.Attribute> attributeDtoMap = new LinkedHashMap<>();
        attributeTypeMap.values().stream().filter(attributes -> attributes != null && !attributes.isEmpty()).forEach(
            attributes -> {
                Attribute attributeDto = transformAttribute(attributes);
                validateAttribute(validationContext, attributeDtoMap, attributes, attributeDto);
            });
        return attributeDtoMap;
    }

    @SuppressWarnings("PMD.LooseCoupling")
    public static void validateAttribute(Map<String, Object> validationContext,
        LinkedHashMap<String, Attribute> attributeDtoMap, List<com.ge.apm.ccom.model.core.Attribute> attributes,
        Attribute attributeDto) {
        if (attributeDto != null && attributeDto.getType() != null && attributeDto.getValue() != null) {
            validationContext.put(ATTRIBUTE_TYPE, attributeDto.getType());

            Validator validator = new Validator(ATTRIBUTE_TYPE_VALIDATION, validationContext);
            ValidationResult validationResult = validator.validate(attributeDto.getValue());

            if (validationResult == null || validationResult.isValid()) {
                attributeDtoMap.put(attributes.get(0).getName().getValue(), attributeDto);
            } else {
                if (log.isDebugEnabled()) {
                    List<com.ge.asset.commons.validator.Error> errors = validationResult.getErrors();
                    StringBuilder errorMessage = new StringBuilder();
                    if (errors == null || errors.isEmpty()) {
                        errorMessage.append("An error occurred while validating attributes.");
                    } else {
                        for (Error error : errors) {
                            errorMessage.append(error.getMessage()).append(" ");
                        }
                    }
                    log.debug(errorMessage.toString());
                }
            }
        }
    }

    @Override
    public void afterPropertiesSet() {
        this.entityTransformerMap = new HashMap<>();
        if (entityTransformers != null) {
            entityTransformers.stream().forEach(t -> entityTransformerMap.put(t.supportedCcomClass(), t));
            // TODO: fix ccom model and jaxb object factory so we don't have to hack like this with LocatableAsset
            if (entityTransformerMap.get(com.ge.apm.ccom.model.registry.Asset.class) != null) {
                entityTransformerMap.put(com.ge.apm.ccom.model.custom.locatable.Asset.class,
                    entityTransformerMap.get(com.ge.apm.ccom.model.registry.Asset.class));
            }
        }
    }

    public IEntityTransformer<? extends Entity> getTransformerFor(Class<? extends Entity> clazz) {
        if (entityTransformerMap.containsKey(clazz)) {
            return entityTransformerMap.get(clazz);
        }
        return null;
    }

    @SuppressWarnings("PMD.PreserveStackTrace")
    public void doDispatch() throws ServiceException {
        StringBuilder exceptionString = new StringBuilder();
        entityTransformerMap.values().stream().sorted(byOrder).forEach((entityTransformer) -> {
            try {
                entityTransformer.doDispatch();
            } catch (ServiceException ex) {
                log.error("Failed to doDispatch for " + entityTransformer.getClass().getSimpleName(), ex);

                if (ex.getCause() instanceof ValidationFailedException) {
                    throw new ServiceException("", ex.getCause());
                }

                exceptionString.append("Failed to doDispatch for ").append(entityTransformer.getClass().getSimpleName())
                    .append(". ").append(ex);
            }
        });
        if (exceptionString.length() > 0) {
            throw new ServiceException(DefaultErrorCode.create("CREATE_UPDATE_ENTITY", exceptionString.toString()));
        }
    }
}
