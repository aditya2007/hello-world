/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.asset.model.Base;
import com.ge.apm.asset.model.Typed;
import com.ge.apm.common.exception.ServiceException;

/**
 * Queue holder for APM asset model data transfer objects (DTO). These DTO are transferred over to the
 * <code>apm-asset</code> service layer to be sent to Predix Asset for persistence.
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Oct 14, 2016
 * @since 1.0
 */
public abstract class DtoQueueHolder<D extends Base> extends BaseTransformer {

    private final ThreadLocal<List<D>> createQueue;

    private final Class<D> dtoClazz;

    protected DtoQueueHolder(AssetClient assetClient, Class<D> dtoClazz) {
        super(assetClient);
        this.dtoClazz = dtoClazz;

        this.createQueue = new ThreadLocal<List<D>>() {
            @Override
            protected List<D> initialValue() {
                return new ArrayList<>();
            }
        };
    }

    protected void queueForDispatch(D dtoObject) {
        createQueue.get().add(dtoObject);
    }

    @SuppressWarnings("unchecked")
    public void doDispatch() throws ServiceException {
        try {
            if (createQueue.get().size() > 0) {
                if (dtoClazz != createQueue.get().get(0).getClass() && dtoClazz != Typed.class) {
                    throw new IllegalArgumentException(
                        "DtoQueueHolder for " + dtoClazz + " cannot be used to create " + createQueue.get().get(0)
                            .getClass());
                }
                assetClient.create(getPrefix(),
                    createQueue.get().toArray((D[]) Array.newInstance(dtoClazz, createQueue.get().size())));
            }
        } finally {
            createQueue.get().clear();
        }
    }
}
