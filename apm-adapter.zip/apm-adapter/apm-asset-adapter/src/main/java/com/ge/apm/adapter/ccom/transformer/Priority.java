/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer;

/**
 * Defines the priority of entity transformation as dictated by entity dependencies. For example, an enterprise depends
 * on the existence of its enterprise type.
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Sep 29, 2016
 * @since 1.0
 */
public enum Priority {
    enterpriseType,
    siteType,
    segmentType,
    assetType,
    measurementLocationType,
    templateType,
    enterprise,
    site,
    segment,
    asset,
    connection,
    assetMesh,
    measurementLocation,
    group,
    groupAssociation,
    template,
    placeholder,
    templateConnections,
    instanceGroupMap;

    /**
     * Returns the transformation priority of the given enum entity.
     *
     * @return priority of entity transformation
     */
    public int priority() {
        return this.ordinal() + 1;
    }
}
