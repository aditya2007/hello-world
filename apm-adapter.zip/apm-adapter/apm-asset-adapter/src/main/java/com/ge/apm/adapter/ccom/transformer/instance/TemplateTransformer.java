/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.instance;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.CcomClassNameMappingEnum;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.asset.model.Placeholder;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.core.BaseType;
import com.ge.apm.ccom.model.custom.Note;
import com.ge.apm.ccom.model.custom.PlaceholderConnection;
import com.ge.apm.ccom.model.custom.PlaceholderMesh;
import com.ge.apm.ccom.model.custom.Template;
import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.util.IdGenerator;
import com.ge.asset.commons.validator.ValidationFailedException;
import com.ge.asset.commons.validator.ValidationResult;
import com.ge.asset.commons.validator.apm.PlaceholdersValidation;

@Slf4j
@Component
public class TemplateTransformer extends BaseEntityTransformer<Template, com.ge.apm.asset.model.Template> {

    public static final String TEMPLATE_NAME = "name";

    private final PlaceholderTransformer placeholderTransformer;

    @Autowired
    public TemplateTransformer(PlaceholderTransformer placeholderTransformer, AssetClient assetClient) {
        super(assetClient, com.ge.apm.asset.model.Template.class);
        this.placeholderTransformer = placeholderTransformer;
    }

    @Override
    protected com.ge.apm.asset.model.Template createDtoObject(Template entity) {
        return new com.ge.apm.asset.model.Template();
    }

    @Override
    protected String getTypePrefix(Template entityObject) {
        return null;
    }

    @Override
    protected String getPrefix() {
        return Prefixes.Templates;
    }

    @Override
    public int order() {
        return Priority.template.priority();
    }

    @Override
    public Class<Template> supportedCcomClass() {
        return Template.class;
    }

    @Override
    protected void transformConnections(Template entityObject, com.ge.apm.asset.model.Template dtoObject) {
        // noop
    }

    @Override
    protected void validateEntity(Template entityObject) throws ServiceException, ValidationFailedException {

        baseValidateSourceKey(entityObject.getGUID() == null ? null : entityObject.getGUID().getValue(),
            CcomClassNameMappingEnum.getSimpleJsonNodeNameFromEnum(Template.class.getSimpleName()),
            entityObject.getName() == null ? "" : entityObject.getName().getValue());

        validateName(entityObject.getName() == null ? null : entityObject.getName().getValue(),
            CcomClassNameMappingEnum.getSimpleJsonNodeNameFromEnum(Template.class.getSimpleName()),
            entityObject.getGUID() == null ? "" : entityObject.getGUID().getValue());
    }

    public List<com.ge.apm.asset.model.Placeholder> getPlaceholders(String templateSrcKey,
        List<PlaceholderMesh> meshs, TransformResponse transformResponse) throws ValidationFailedException {
        List<com.ge.apm.asset.model.Placeholder> placeholders = new ArrayList<>();
        com.ge.apm.asset.model.Placeholder placeholder;
        for (PlaceholderMesh mesh : meshs) {
            List<PlaceholderConnection> conns = mesh.getConnection();
            for (PlaceholderConnection conn : conns) {
                placeholder = processConnection(conn, templateSrcKey);
                placeholders.add(placeholder);
            }
        }

        return placeholders;
    }

    private com.ge.apm.asset.model.Placeholder processConnection(PlaceholderConnection conn, String templateSrcKey)
        throws ValidationFailedException {

        placeholderTransformer.transform(conn.getFrom());

        com.ge.apm.asset.model.Placeholder placeholder = placeholderTransformer.getPlaceholderDto();
        placeholder.setPlaceholders(new ArrayList<>());
        placeholder.setTemplate(templateSrcKey);

        if (null != conn.getNetwork()) {
            for (PlaceholderConnection connection : conn.getNetwork().getConnection()) {
                Placeholder nextPlaceholder = processConnection(connection, templateSrcKey);
                nextPlaceholder.setTemplate(templateSrcKey);
                placeholder.getPlaceholders().add(nextPlaceholder);
            }
        }

        return placeholder;
    }

    @Override
    protected void transformOtherParts(Template entityObject, com.ge.apm.asset.model.Template dtoObject,
        TransformResponse transformResponse) throws ServiceException, ValidationFailedException {

        transformTemplateMetadata(entityObject, dtoObject);

        final List<PlaceholderMesh> phMeshes = entityObject.getPlaceholderMeshes();
        List<com.ge.apm.asset.model.Placeholder> placeholderList =
            getPlaceholders(dtoObject.getSourceKey(), phMeshes, transformResponse);

        validatePlaceholders(placeholderList, transformResponse);

        dtoObject.setPlaceholders(placeholderList);
    }

    private void validatePlaceholders(List<Placeholder> placeholderList, TransformResponse transformResponse)
        throws ValidationFailedException {
        //convert Placeholders as sequential by clone and then perform validation
        List<Placeholder> allPlaceholders = convertToSequential(placeholderList, null);
        PlaceholdersValidation validator = new PlaceholdersValidation();
        ValidationResult validationResult = validator.validate(allPlaceholders);
        if (validationResult != null && !validationResult.isValid()) {
            throw new ValidationFailedException(validationResult.getErrors());
        }
    }

    private List<Placeholder> convertToSequential(List<Placeholder> placeholderList, String parent) {
        List<Placeholder> sequential = new ArrayList<>();
        if (placeholderList == null || placeholderList.isEmpty()) {
            return sequential;
        }
        placeholderList.forEach(o -> {
            Placeholder tempPlaceholder = (Placeholder) SerializationUtils.clone(o);
            String fakePhUri = Prefixes.uri(Prefixes.Placeholders,
                IdGenerator.generateFrom("/", Prefixes.Placeholders, tempPlaceholder.getSourceKey()));
            tempPlaceholder.setUri(fakePhUri);
            tempPlaceholder.setParent(parent);
            tempPlaceholder.setPlaceholders(null);
            sequential.add(tempPlaceholder);

            List<Placeholder> placeholders = o.getPlaceholders();
            if (placeholders != null && placeholders.size() > 0) {
                sequential.addAll(this.convertToSequential(placeholders, tempPlaceholder.getUri()));
            }
        });
        return sequential;
    }

    private void transformTemplateMetadata(Template entityObject, com.ge.apm.asset.model.Template dtoObject) {
        dtoObject.setRevision(entityObject.getRevision());

        List<Note> notes = entityObject.getNotes();
        if (notes != null && !notes.isEmpty()) {
            List<com.ge.apm.asset.model.Note> dtoNotes = new ArrayList<>();
            for (Note note : notes) {
                com.ge.apm.asset.model.Note dtoNote = new com.ge.apm.asset.model.Note();
                dtoNote.setSourceKey(note.getGUID().getValue());
                dtoNote.setContent(note.getContent());
                dtoNote.setCreatedBy(note.getCreator().getName().getValue());
                dtoNotes.add(dtoNote);
            }

            dtoObject.setNotes(dtoNotes);
        }
    }

    @Override
    protected BaseType getTypeFromEntity(Template template) {
        return null;
    }

    @Override
    protected String getParentSourceKey(Template template) {
        if (template.getCreator() != null) {
            return template.getCreator().getGUID().getValue();
        }
        return null;
    }

    @Override
    public boolean supportsFailFast() {
        return false;
    }

    @Override
    protected String getParentPrefix(Template entityObject) {
        return null;
    }

    @Override
    protected Map<String, String> getConnections(Template entityObject) {
        return null;
    }
}