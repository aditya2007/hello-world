/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.type;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.CcomClassNameMappingEnum;
import com.ge.apm.adapter.ccom.transformer.DtoQueueHolder;
import com.ge.apm.adapter.ccom.transformer.EntityTransformerFactory;
import com.ge.apm.adapter.ccom.transformer.IEntityTransformer;
import com.ge.apm.adapter.ccom.transformer.response.TransformResponse;
import com.ge.apm.adapter.common.constants.AttributeTypes;
import com.ge.apm.asset.model.MeasurementTagType;
import com.ge.apm.asset.model.Type;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.core.AttributableEntity;
import com.ge.apm.ccom.model.core.Attribute;
import com.ge.apm.ccom.model.custom.ReservedAttribute;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

@SuppressWarnings({ "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public abstract class BaseEntityTypeTransformer<T extends AttributableEntity, D extends Type> extends DtoQueueHolder<D>
    implements IEntityTransformer<T> {

    protected BaseEntityTypeTransformer(AssetClient assetClient, Class<D> dtoClazz) {
        super(assetClient, dtoClazz);
    }

    @Override
    public final TransformResponse transform(T entity) throws ServiceException, ValidationFailedException {

        D dtoObject = createDtoObject();

        validateSourceKey(entity, dtoObject);

        validateName(entity.getName() == null ? null : entity.getName().getValue(),
            CcomClassNameMappingEnum.getSimpleJsonNodeNameFromEnum(entity.getClass().getSimpleName()),
            entity.getTag().getValue());

        if (entity.getName() != null) {
            dtoObject.setName(entity.getName().getValue());
            dtoObject.setDescription(entity.getName().getValue());
        }

        Map<String, List<Attribute>> attributeTypeMap = CcomTypeHelper.getAttributeTypeMap(entity);
        List<Attribute> description = attributeTypeMap.remove(AttributeTypes.DESCRIPTION);
        if (description != null) {
            dtoObject.setDescription(description.get(0).getValueContent().getText().getValue());
        }

        if (entity.getTag() != null) {
            dtoObject.setSourceKey(entity.getTag().getValue());
        }
        List<Attribute> parent = attributeTypeMap.remove(AttributeTypes.PARENT);
        if (parent != null) {
            String parentSourceKey = parent.get(0).getValueContent().getText().getValue();
            String parentPrefix = getPrefix();
            String parentUriCacheKey = parentPrefix + "/" + parentSourceKey;
            dtoObject.setParent(parentUriCacheKey);
        }

        // Process all the regular properties
        processRegularProperties(dtoObject, attributeTypeMap);

        //convertEntity to Map of ReservedAttributes
        Map<String, List<ReservedAttribute>> reservedAttributeTypeMap = CcomTypeHelper.getReservedAttributeTypeMap(
            entity);

        processReservedProperties(dtoObject, reservedAttributeTypeMap);

        transform(entity, dtoObject);
        queueForDispatch(dtoObject);

        TransformResponse transformResponse = new TransformResponse();
        transformResponse.setStatus(TransformResponse.EntityResponseStatus.OK);
        return transformResponse;
    }

    protected abstract void transform(T entityObject, D dtoObject);

    protected abstract D createDtoObject();

    private void processReservedProperties(D dtoObject, Map<String, List<ReservedAttribute>> reservedAttributeTypeMap) {

        //Convert the List of reservedAttributes to Map<String, Object>
        if (reservedAttributeTypeMap != null && !reservedAttributeTypeMap.isEmpty()) {
            @SuppressWarnings("unchecked") Map<String, Object> reservedAttributeTypeObjectMap
                = new java.util.HashMap<>();
            reservedAttributeTypeMap.forEach((name, reservedAttributeList) -> {
                Object attrValue = EntityTransformerFactory.extractReservedAttributeValues(reservedAttributeList);
                reservedAttributeTypeObjectMap.put(name, attrValue);
            });
            dtoObject.setReservedAttributes(reservedAttributeTypeObjectMap);
        }
    }

    private void processRegularProperties(D dtoObject, Map<String, List<Attribute>> attributeTypeMap) {
        LinkedHashMap<String, com.ge.apm.asset.model.Attribute> attributeDtoMap = EntityTransformerFactory
            .getAttributeMap(attributeTypeMap);

        if (attributeDtoMap == null || attributeDtoMap.isEmpty()) {
            dtoObject.setAttributes(new LinkedHashMap<>());
        } else {
            dtoObject.setAttributes(attributeDtoMap);
        }
    }

    private void validateSourceKey(T entityObject, D dtoObject) throws ValidationFailedException {
        if (entityObject.getTag() == null || entityObject.getTag().getValue() == null
            || entityObject.getTag().getValue().length() == 0) {

            List<com.ge.asset.commons.validator.Error> sourceKeyErrorList = new ArrayList<>();
            Error sourceKeyError = new Error(Error.ErrorType.ERROR);

            String entityName = entityObject.getName().getValue();

            // "Tag Classification type" if dtoObject is an instance of "MeasurementTagType"
            if (dtoObject instanceof MeasurementTagType) {
                sourceKeyError.setErrorCode(ErrorConstants.TAG_CLASS_ID_MISSING_CODE);
                sourceKeyError.setPlaceHolders(new String[] { entityName });
            } else if (dtoObject instanceof Type) {
                // "Classification type" if dtoObject is an instance of "Type"
                sourceKeyError.setErrorCode(ErrorConstants.CLASS_ID_MISSING_CODE);
                sourceKeyError.setPlaceHolders(new String[] { entityName,
                    CcomClassNameMappingEnum.getSimpleJsonNodeNameFromEnum(dtoObject.getClass().getSimpleName()) });
            }
            sourceKeyErrorList.add(sourceKeyError);

            throw new ValidationFailedException(sourceKeyErrorList);
        }
    }

    /**
     * All classifications, including tag classifications allow parent-child dependency. As such, this transformer
     * cannot support fail-fast.
     *
     * @return <code>false</code> since this transformer cannot support fail-fast
     */
    @Override
    public boolean supportsFailFast() {
        return false;
    }
}
