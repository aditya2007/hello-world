/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer.type;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.ccom.rest.client.AssetClient;
import com.ge.apm.adapter.ccom.transformer.Priority;
import com.ge.apm.asset.model.constants.Prefixes;
import com.ge.apm.ccom.model.registry.SiteType;

@Component
public class SiteTypeTransformer extends BaseEntityTypeTransformer<SiteType, com.ge.apm.asset.model.SiteType> {

    @Autowired
    public SiteTypeTransformer(AssetClient assetClient) {
        super(assetClient, com.ge.apm.asset.model.SiteType.class);
    }

    @Override
    protected com.ge.apm.asset.model.SiteType createDtoObject() {
        return new com.ge.apm.asset.model.SiteType();
    }

    @Override
    protected String getPrefix() {
        return Prefixes.SiteTypes;
    }

    @Override
    public int order() {
        return Priority.site.priority();
    }

    @Override
    public Class<SiteType> supportedCcomClass() {
        return SiteType.class;
    }

    @Override
    protected void transform(SiteType entityObject, com.ge.apm.asset.model.SiteType dtoObject) {
        //no-op;
    }
}
