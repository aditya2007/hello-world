/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.ccom.transformer;

import java.util.Arrays;
import java.util.List;

/**
 * Created by 502670744 on 11/9/16.
 */
public enum CcomClassNameMappingEnum {
    Enterprise("ENTERPRISE", "instances"),
    Site("SITE", "instances"),
    Segment("SEGMENT", "instances"),
    Asset("ASSET", "instances"),
    MeasurementLocation("TAG", "tagAssociations"),
    EnterpriseType("ENTERPRISE_TYPE", "classifications"),
    SiteType("SITE_TYPE", "classifications"),
    SegmentType("SEGMENT_TYPE", "classifications"),
    AssetType("ASSET_TYPE", "classifications"),
    MeasurementLocationType("TAG_TYPE", "tagClassifications"),
    Group("GROUP", "groups"),
    Template("TEMPLATE", "templates"),
    Placeholder("TEMPLATE", "placeholders");

    private static List<CcomClassNameMappingEnum> enumList = Arrays.asList(CcomClassNameMappingEnum.values());

    private String simpleJsonNodeName;

    private String simpleClassName;

    CcomClassNameMappingEnum(String simpleClassName, String simpleJsonNodeName) {
        this.simpleJsonNodeName = simpleJsonNodeName;
        this.simpleClassName = simpleClassName;
    }

    public static String getSimpleJsonNodeNameFromEnum(String name) {
        CcomClassNameMappingEnum classNameMappingEnum = enumList.stream().filter(m -> m.name().equals(name)).findAny()
            .orElseThrow(IllegalArgumentException::new);
        return classNameMappingEnum.getSimpleJsonNodeName();
    }

    public static String getSimpleClassNameFromEnum(String name) {
        CcomClassNameMappingEnum classNameMappingEnum = enumList.stream().filter(m -> m.name().equals(name)).findAny()
            .orElseThrow(IllegalArgumentException::new);
        return classNameMappingEnum.getSimpleClassName();
    }

    public String getSimpleClassName() {
        return simpleClassName;
    }

    public String getSimpleJsonNodeName() {
        return simpleJsonNodeName;
    }

    @Override
    public String toString() {
        return this.getSimpleJsonNodeName();
    }
}
