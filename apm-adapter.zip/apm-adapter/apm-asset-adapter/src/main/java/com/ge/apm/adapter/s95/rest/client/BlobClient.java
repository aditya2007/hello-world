/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.rest.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.apm.blob.client.BlobArchiveClient;

@Component
public class BlobClient {

    @Autowired
    private BlobArchiveClient blobArchiveClient;

    @Value("${blobStorage.url}")
    private String blobStorageUrl;

    // public BlobClient() {
    //     this.blobArchiveClient = new BlobArchiveClient(this.blobStorageUrl);
    // }

    public BlobArchiveClient getBlobArchiveClient() {
        if (this.blobArchiveClient == null) {
            this.blobArchiveClient = new BlobArchiveClient(this.blobStorageUrl);
        }
        return this.blobArchiveClient;
    }
}
