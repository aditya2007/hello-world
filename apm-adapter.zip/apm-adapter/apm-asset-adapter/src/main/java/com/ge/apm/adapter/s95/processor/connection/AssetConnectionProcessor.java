/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.connection;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.HierarchicalLink;
import com.ge.apm.ccom.model.network.connections.AssetConnection;
import com.ge.apm.ccom.model.network.connections.ConnectionType;
import com.ge.apm.ccom.model.registry.Asset;
import com.ge.apm.ccom.model.registry.Segment;
import com.ge.apm.ccom.model.registry.Site;
import com.ge.apm.s95.model.ToNode;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.util.AssetConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
public class AssetConnectionProcessor extends ConnectionObjectProcessor<Asset> {

    public AssetConnectionProcessor() {
        super(MimosaCcomCategory.ASSET, Asset.class);
    }

    @Override
    protected void processParentToNode(Asset asset, ToNode toNode) throws ValidationFailedException {
        if (toNode.getCcomClass() != MimosaCcomCategory.SITE && toNode.getCcomClass() != MimosaCcomCategory.SEGMENT
            && toNode.getCcomClass() != MimosaCcomCategory.ASSET) {
            Error error = new Error(Error.ErrorType.ERROR);
            if (toNode.getCcomClass().name().equals(MimosaCcomCategory.ENTERPRISE.name())) {
                error.setErrorCode(ErrorConstants.INVALID_PARENT_ENTERPRISE_FOR_ASSET);
            } else {
                error.setErrorCode(ErrorConstants.INVALID_PARENT_FOR_ASSET);
            }
            error.setPlaceHolders(
                new String[] { asset.getGUID().getValue(), asset.getClass().getSimpleName(), toNode.getId(),
                    toNode.getCcomClass() == null ? AssetConstants.EMPTY_STRING : toNode.getCcomClass().name() });
            List<Error> errorList = new ArrayList<>();
            errorList.add(error);
            throw new ValidationFailedException(errorList);
        }
        if (toNode.getCcomClass() == MimosaCcomCategory.SITE) {
            Site site = new Site();
            CcomTypeHelper.setUuidAndTag(site, toNode.getId());
            asset.setRegistrationSite(site);
        } else if (toNode.getCcomClass() == MimosaCcomCategory.SEGMENT) {
            Segment segment = new Segment();
            CcomTypeHelper.setUuidAndTag(segment, toNode.getId());
            asset.setEquivalentSegment(segment);
        } else {
            HierarchicalLink hierarchicalLink = new HierarchicalLink();
            Asset parent = new Asset();
            CcomTypeHelper.setUuidAndTag(parent, toNode.getId());
            hierarchicalLink.setParent(parent);
            asset.getParentLink().add(hierarchicalLink);
        }
    }

    @Override
    protected void addConnectionForToNode(Asset asset, ToNode toNode) {
        if (toNode.getCcomClass() != MimosaCcomCategory.ASSET) {
            throw new IllegalStateException("Invalid connection: " + toNode + ". Asset can be connected to Asset only");
        }
        AssetConnection assetConnection = new AssetConnection();
        assetConnection.setType(new ConnectionType());
        assetConnection.getType().setName(CcomTypeHelper.wrapText(toNode.getType()));
        assetConnection.setFrom(new Asset());
        assetConnection.getFrom().setGUID(asset.getGUID());
        assetConnection.setTo(new Asset());
        assetConnection.getTo().setGUID(CcomTypeHelper.wrapUUID(toNode.getId()));

        queueAssetConnection(asset, assetConnection);
    }
}
