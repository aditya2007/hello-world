/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.common.constants.AttributeTypes;
import com.ge.apm.adapter.s95.processor.IRootLevelProcessor;
import com.ge.apm.adapter.s95.processor.base.ObjectProcessor;
import com.ge.apm.ccom.model.CcomTypeHelper;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.BaseType;
import com.ge.apm.ccom.model.registry.AssetType;
import com.ge.apm.ccom.model.registry.EnterpriseType;
import com.ge.apm.ccom.model.registry.SegmentType;
import com.ge.apm.ccom.model.registry.SiteType;
import com.ge.apm.s95.model.Classification;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.util.AssetConstants;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
@Slf4j
@SuppressWarnings({ "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public class ClassificationProcessor extends ObjectProcessor<JsonParser> implements IRootLevelProcessor<JsonParser> {

    @Override
    public void process(JsonParser parser) throws IOException, ValidationFailedException {
        Classification classification = null;
        try {
            classification = parser.readValueAs(Classification.class);
            MimosaCcomCategory category = classification.getCcomClass();
            BaseType typeEntity = getTypeEntityFor(category);

            processBasicProperties(classification, typeEntity);
            if (classification.getParent() != null && !classification.getParent().isEmpty()) {
                CcomTypeHelper.addAttribute(typeEntity, "parent", AttributeTypes.PARENT, classification.getParent());
            }
            processProperties(typeEntity, classification);
            processReservedProperties(typeEntity, classification);
            entityDispatcher.sendEntity(typeEntity, this.supportedField());
        } catch (InvalidFormatException formatException) {
            log.error(formatException.getMessage(), formatException);
            String[] placeHolders = new String[5];
            placeHolders[0] = parser.getText();

            if (formatException.getPath() != null && formatException.getPath().get(0) != null
                && formatException.getPath().get(0).getFrom() != null) {
                placeHolders[1] = ((Classification) formatException.getPath().get(0).getFrom()).getId();
            }

            String parsedId = handleInvalidCcomClass(parser);
            if (placeHolders[1] == null) {
                placeHolders[1] = parsedId;
            }
            processException(parser, placeHolders, ErrorConstants.INVALID_CCOM_CLASSIFICATION, true);
        } catch (IllegalStateException illegalStateException) {
            log.error(illegalStateException.getMessage(), illegalStateException);
            if (classification != null) {
                processException(parser, new String[] {
                        classification.getCcomClass() == null ? AssetConstants.EMPTY_STRING
                            : classification.getCcomClass().name(), classification.getId() },
                    ErrorConstants.INVALID_CCOM_CLASSIFICATION, false);
            }
        }
    }

    private BaseType getTypeEntityFor(MimosaCcomCategory category) {
        switch (category) {
            case ENTERPRISE_TYPE:
                return new EnterpriseType();
            case SITE_TYPE:
                return new SiteType();
            case SEGMENT_TYPE:
                return new SegmentType();
            case ASSET_TYPE:
                return new AssetType();
            default:
                throw new IllegalStateException("Unknown ccomClass for classification: " + category);
        }
    }

    @Override
    public String supportedField() {
        return CLASSIFICATIONS;
    }

    @Override
    public Class supportedClass() {
        return Classification.class;
    }
}
