/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor.root;

import java.io.IOException;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.google.common.collect.ImmutableMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.s95.processor.IRootLevelProcessor;
import com.ge.apm.adapter.s95.processor.base.ObjectProcessor;
import com.ge.apm.adapter.s95.processor.instance.AssetInstanceProcessor;
import com.ge.apm.adapter.s95.processor.instance.EnterpriseInstanceProcessor;
import com.ge.apm.adapter.s95.processor.instance.InstanceObjectProcessor;
import com.ge.apm.adapter.s95.processor.instance.SegmentInstanceProcessor;
import com.ge.apm.adapter.s95.processor.instance.SiteInstanceProcessor;
import com.ge.apm.ccom.model.MimosaCcomCategory;
import com.ge.apm.ccom.model.core.AttributableEntity;
import com.ge.apm.ccom.model.core.BaseType;
import com.ge.apm.s95.model.Instance;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.util.AssetConstants;
import com.ge.asset.commons.validator.LocationContext;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
@Slf4j
@SuppressWarnings({ "PMD.CyclomaticComplexity", "PMD.ModifiedCyclomaticComplexity", "PMD.StdCyclomaticComplexity" })
public class InstanceProcessor extends ObjectProcessor<JsonParser>
    implements InitializingBean, IRootLevelProcessor<JsonParser> {

    private Map<MimosaCcomCategory, InstanceObjectProcessor<? extends AttributableEntity, ? extends BaseType>>
        instanceProcessorMap;

    @Autowired
    private EnterpriseInstanceProcessor enterpriseInstanceProcessor;

    @Autowired
    private SiteInstanceProcessor siteInstanceProcessor;

    @Autowired
    private SegmentInstanceProcessor segmentInstanceProcessor;

    @Autowired
    private AssetInstanceProcessor assetInstanceProcessor;

    @Override
    public void afterPropertiesSet() {
        instanceProcessorMap = ImmutableMap.of(MimosaCcomCategory.ENTERPRISE, enterpriseInstanceProcessor,
            MimosaCcomCategory.SITE, siteInstanceProcessor, MimosaCcomCategory.SEGMENT, segmentInstanceProcessor,
            MimosaCcomCategory.ASSET, assetInstanceProcessor);
    }

    @Override
    public void process(JsonParser parser)
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        MimosaCcomCategory category = null;
        try {
            Instance instance = parser.readValueAs(Instance.class);
            category = instance.getCcomClass();
            if (instanceProcessorMap.containsKey(category)) {
                instanceProcessorMap.get(category).process(instance);
            } else {
                processException(parser, new String[] {
                    instance.getCcomClass() == null ? AssetConstants.EMPTY_STRING : instance.getCcomClass().name(),
                    instance.getId() }, ErrorConstants.INVALID_CCOM_INSTANCE, false);
            }
        } catch (InvalidFormatException ife) {
            String[] placeHolders;
            String invalidValue = parser.getText();
            String id = null;
            if (ife.getPath() != null && ife.getPath().get(0) != null) {
                switch (ife.getPath().get(0).getFieldName()) {
                    case "ccomClass":
                        placeHolders = buildPlaceHolders(parser, ife, invalidValue, id);
                        processException(parser, placeHolders, ErrorConstants.INVALID_CCOM_INSTANCE, true);
                        break;
                    case "location":
                        id = getLocationId(parser, ife, id);
                        String entityTypeAndId = "Asset " + id;
                        String index = String.valueOf(ife.getPath().get(2).getIndex());
                        placeHolders = new String[] { "Asset " + id, null, invalidValue, index };
                        String[] resolutionPlaceHolders = null;
                        String field = ife.getPath().get(3).getFieldName();
                        switch (field) {
                            case LocationContext.ORDER:
                                placeHolders = new String[] { entityTypeAndId, invalidValue, index };
                                processException(parser, placeHolders, ErrorConstants.GEO_POINT_ORDER_INVALID, true);
                                break;
                            case LocationContext.LATITUDE:
                                placeHolders = new String[] { entityTypeAndId, LocationContext.LATITUDE, invalidValue,
                                    index };
                                resolutionPlaceHolders = new String[] { String.valueOf(
                                    LocationContext.LATITUDE_RANGE[0]), String.valueOf(
                                    LocationContext.LATITUDE_RANGE[1]) };
                                processException(parser, placeHolders, resolutionPlaceHolders,
                                    ErrorConstants.GEO_POINT_GPS_VALUE_INVALID_RANGE, true);
                                break;
                            case LocationContext.LONGITUDE:
                                placeHolders = new String[] { entityTypeAndId, LocationContext.LONGITUDE, invalidValue,
                                    index };
                                resolutionPlaceHolders = new String[] { String.valueOf(
                                    LocationContext.LONGITUDE_RANGE[0]), String.valueOf(
                                    LocationContext.LONGITUDE_RANGE[1]) };
                                processException(parser, placeHolders, resolutionPlaceHolders,
                                    ErrorConstants.GEO_POINT_GPS_VALUE_INVALID_RANGE, true);
                                break;
                            case LocationContext.ALTITUDE:
                                placeHolders = new String[] { entityTypeAndId, invalidValue, index };
                                processException(parser, placeHolders, ErrorConstants.GEO_POINT_ALTITUDE_NOT_NUMERIC,
                                    true);
                                break;
                            default:
                                log.warn("Unhandled InvalidFormatException for location: {}", ife.toString());
                                break;
                        }
                        break;
                    default:
                        log.warn("Unhandled payload InvalidFormatException: {}", ife.toString());
                }
            }
        }
    }

    private String getLocationId(JsonParser parser, InvalidFormatException ife, String paramId) throws IOException {
        String id = paramId;
        String parsedId;
        if (ife.getPath().get(0).getFrom() != null) {
            id = ((Instance) ife.getPath().get(0).getFrom()).getId();
        }
        parsedId = handleInvalidLocation(parser);
        if (id == null) {
            id = parsedId;
        }
        return id;
    }

    private String[] buildPlaceHolders(JsonParser parser, InvalidFormatException ife, String invalidValue,
        String paramId) throws IOException {
        String[] placeHolders;
        placeHolders = new String[2];
        placeHolders[0] = invalidValue;
        String id = paramId;
        if (ife.getPath().get(0).getFrom() != null) {
            id = ((Instance) ife.getPath().get(0).getFrom()).getId();
        }
        String parsedId;
        parsedId = handleInvalidCcomClass(parser);
        placeHolders[1] = id == null ? parsedId : id;
        return placeHolders;
    }

    @Override
    public String supportedField() {
        return INSTANCES;
    }

    @Override
    public Class supportedClass() {
        return Instance.class;
    }
}
