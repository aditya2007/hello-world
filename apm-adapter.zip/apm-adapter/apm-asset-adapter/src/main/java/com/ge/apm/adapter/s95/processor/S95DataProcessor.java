/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.s95.processor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.TreeTraversingParser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.s95.processor.base.ObjectProcessor;
import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

import static com.ge.apm.adapter.common.util.JsonValidator.validateJsonAgainstClass;

@Component
@Slf4j
public class S95DataProcessor extends ObjectProcessor<JsonParser> implements InitializingBean {

    public static final String BATCH_SIZE = "batchSize";

    @Inject
    private List<IRootLevelProcessor<JsonParser>> rootLevelProcessors;

    private Map<String, IRootLevelProcessor<JsonParser>> fieldToProcessorMap;

    @Override
    public void afterPropertiesSet() {
        // This method maps the valid JSON fields ("classifications", "instances", "connections",
        // "tagClassifications", "tagAssociations", "groups") to their corresponding
        // processors (contained in /apm-s95-adapter/src/main/java/com/ge/apm/adapter/s95/processor/root)
        fieldToProcessorMap = new HashMap<>();
        if (rootLevelProcessors != null) {
            rootLevelProcessors.stream().forEach(p -> fieldToProcessorMap.put(p.supportedField(), p));
        }
    }

    @Override
    public void process(JsonParser parser) {
        //Do Nothing.
    }

    // TODO: tmp fix for RequestContext tenant mix-up, will refactor the interface to use this one instead
    public void process(JsonParser parser, String tenantUuid)
        throws IOException, ValidationFailedException, IllegalAccessException, InstantiationException {
        String fieldName = "";
        try {
            startObject(parser);
            fieldName = parser.nextFieldName();
            List<Error> errorList = new ArrayList<>();
            while (fieldName != null) {
                parser.nextToken();
                if (fieldToProcessorMap.containsKey(fieldName)) {
                    if (log.isDebugEnabled()) {
                        log.debug("S95DataProcessor started processing {} for tenant {}.", fieldName, tenantUuid);
                    }
                    try {
                        process(fieldToProcessorMap.get(fieldName), parser);
                    } catch (ValidationFailedException validationFailed) {
                        log.error(validationFailed.getMessage(), validationFailed);
                        errorList.addAll(validationFailed.getErrorCollection());
                    }
                    if (log.isDebugEnabled()) {
                        log.debug("S95DataProcessor finished processing {} for tenant {}.", fieldName, tenantUuid);
                    }
                } else {
                    log.error("Unknown field: {}", fieldName);
                }
                fieldName = parser.nextFieldName();
            }
            endObject(parser);

            if (!errorList.isEmpty()) {
                throw new ValidationFailedException(errorList);
            }
        } catch (JsonParseException ex) {
            log.error(String.format("Failed to process %s for token %s at %s: %s ", fieldName, parser.getCurrentToken(),
                parser.getCurrentLocation(), ex.getMessage()), ex);
            throw ex;
        }
    }

    private void process(IRootLevelProcessor<JsonParser> processor, JsonParser parser)
        throws IOException, ValidationFailedException, InstantiationException, IllegalAccessException {
        startArray(parser);
        parser.nextToken();

        /*if (processor instanceof ClassificationProcessor) {
            entityDispatcher.setBatchSize(1);
        } else {
            entityDispatcher.setBatchSize(RequestContext.get(BATCH_SIZE, Integer.class));
        }*/
        entityDispatcher.setBatchSize(RequestContext.get(BATCH_SIZE, Integer.class));
        List<Error> errorList = new ArrayList<>();

        while (parser.isExpectedStartObjectToken()) {
            String json = parser.readValueAsTree().toString();
            try {
                validateJsonAgainstClass(json, processor.supportedClass());

                JsonNode jsonNode = new ObjectMapper().readTree(json);
                JsonParser parserCopy = new TreeTraversingParser(jsonNode);
                parserCopy.setCodec(parser.getCodec());

                processor.process(parserCopy);
            } catch (ValidationFailedException validationFailed) {
                log.error(validationFailed.getMessage(), validationFailed);
                errorList.addAll(validationFailed.getErrorCollection());
            } catch (JsonMappingException ex) {
                log.error(ex.getMessage(), ex);
                json = json.replace("\"", "");
                json = json.split(",")[0] + "...}";

                Error error = new Error(Error.ErrorType.ERROR);
                error.setErrorCode(ErrorConstants.VALIDATION_INVALID_OBJ);
                error.setPlaceHolders(new String[] { json, processor.supportedField(), ex.getMessage() });
                errorList.add(error);
            }
            parser.nextToken();
        }
        entityDispatcher.sendBatch(processor.supportedField());
        entityDispatcher.flushConnections();

        endArray(parser);

        if (!errorList.isEmpty()) {
            throw new ValidationFailedException(errorList);
        }
    }
}
