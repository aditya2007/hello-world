/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

@Component
public class RestHeaderProcessor implements Processor {

    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void process(Exchange exchange) throws Exception {
        Map<String, Object> filteredHeaders = new HashMap<>();
        exchange.getIn().getHeaders().entrySet().stream().filter(
            inHeader -> inHeader.getKey().startsWith("Apm") || inHeader.getKey().startsWith("Camel")).forEach(
            inHeader -> filteredHeaders.put(inHeader.getKey(), inHeader.getValue()));
        exchange.getIn().setHeaders(filteredHeaders);
    }
}
