/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.IllegalFormatException;
import java.util.List;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import lombok.extern.slf4j.Slf4j;

import org.apache.camel.Exchange;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.common.constants.TaskStatus;
import com.ge.apm.adapter.domain.persistence.entity.IngestionLogMsg;
import com.ge.apm.adapter.domain.persistence.entity.Task;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.asset.commons.errorprovider.AssetError;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.util.checksum.ChecksumUtil;
import com.ge.asset.commons.validator.Error;

@Component
@Slf4j
@SuppressWarnings("PMD.TooManyMethods")
public abstract class TaskProcessor implements ITaskProcessor {

    protected static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(
        "MM-dd-yyyy HH:mm:ss.SSS");

    @Autowired
    private ITaskProcessorRepository taskProcessorRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void queueTask(Exchange exchange) {
        createTask(exchange, TaskStatus.QUEUED);
    }

    @Override
    public void inProgressTask(Exchange exchange) {
        createTask(exchange, TaskStatus.IN_PROGRESS);
    }

    @Override
    public void fetchTask(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);

        Task task = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, taskId);
        exchange.getIn().setBody(task);
    }

    public void transformTask(Exchange exchange) {
        Task task = exchange.getIn().getBody(Task.class);
        com.ge.apm.adapter.model.Task dto = new com.ge.apm.adapter.model.Task();
        dto.setUuid(task.getUuid());
        dto.setDescription(task.getDescription());
        dto.setStatus(task.getStatus());
        dto.setStartTime(dateFormatter.format(
            LocalDateTime.ofInstant(Instant.ofEpochMilli(task.getCreatedOn().getTime()),
                ZoneId.systemDefault())));
        exchange.getIn().setBody(dto);
    }

    public void createAndMarkTaskError(Exchange exchange) {
        createTask(exchange, TaskStatus.QUEUED);
        taskError(exchange);
    }

    public void requeueTask(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        String taskDescription = exchange.getIn().getHeader(MessageConstants.DESCRIPTION,
            String.class);

        Task task = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, taskId);
        if (!TaskStatus.IN_PROGRESS.equals(task.getStatus())) {
            throw new UnsupportedOperationException("Task status is not 'IN PROGRESS': " + taskId);
        }
        task.setStatus(TaskStatus.QUEUED);
        task.setDescription(taskDescription);
        saveAndFlush(task);
    }

    @Override
    public void markInProgress(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);

        Task task = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, taskId);
        task.setStatus(TaskStatus.IN_PROGRESS);
        saveAndFlush(task);
    }

    private void createTask(Exchange exchange, String status) {
        Task task = new Task();
        String parentTaskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, null,
            String.class);
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        Task parentTask = null;
        if (parentTaskId != null && !parentTaskId.isEmpty()) {
            parentTask = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, parentTaskId);
        }
        if (parentTask != null && parentTask.getParent() == null) {
            String jsonFileName = exchange.getIn().getHeader(Exchange.FILE_NAME, String.class);
            if (checkAndSetDeterministicTaskUuid(exchange, task, parentTaskId, tenantUuid,
                jsonFileName)) {
                return;
            }
        } else if (parentTask != null && parentTask.getParent() != null) {
            String batchChecksum = exchange.getIn().getHeader(
                MessageConstants.BATCH_OBJECT_CHECKSUM, String.class);
            if (checkAndSetDeterministicTaskUuid(exchange, task, parentTaskId, tenantUuid,
                batchChecksum)) {
                return;
            }
        }

        task.setParent(parentTask);
        task.setTenantUuid(tenantUuid);
        task.setDescription(
            exchange.getIn().getHeader(MessageConstants.DESCRIPTION, null, String.class));
        task.setStatus(status);
        task.setTaskType(
            exchange.getIn().getHeader(MessageConstants.TASK_ENTITY_TYPE, String.class));
        task.setTotalCount(
            exchange.getIn().getHeader(MessageConstants.TASK_ENTITY_TOTAL, 0, Long.class));

        saveAndFlush(task);
        //updateParentTaskTotal(parentTask, task.getTotalCount());
        exchange.getIn().setHeader(MessageConstants.TASK_UUID, task.getUuid());
    }

    private boolean checkAndSetDeterministicTaskUuid(Exchange exchange, Task task,
                                                     String parentTaskId,
                                                     String tenantUuid, String batchChecksum) {
        String taskUuid = generateTaskUuid(parentTaskId, tenantUuid, batchChecksum);
        Task existingTask = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, taskUuid);
        if (existingTask != null) {
            exchange.getIn().setHeader(MessageConstants.TASK_UUID, existingTask.getUuid());
            if (existingTask.getStatus().equals(TaskStatus.COMPLETED) || existingTask.getStatus()
                    .equals(
                            TaskStatus.ARCHIVED)) {
                exchange.getIn().setHeader(MessageConstants.SKIP_BATCH_TRANSFORMATION, true);
            }
            return true;
        }
        task.setUuid(taskUuid);
        return false;
    }

    protected String generateTaskUuid(String parentTaskId, String tenantUuid, String fileName) {
        String fileChecksum = ChecksumUtil.generateHash(tenantUuid + parentTaskId + fileName);
        return UUID.nameUUIDFromBytes(fileChecksum.getBytes()).toString();
    }

    protected Task saveAndFlush(Task task) {
        task.setUpdatedOn(new java.util.Date());
        return taskProcessorRepository.saveAndFlush(task);
    }

    protected void setStatusToError(Task task, String error) {
        task.setStatus(TaskStatus.ERROR + error);
    }

    protected String getStackTrace(Throwable ex) {
        if (ex == null) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        String[] stackTrace = ExceptionUtils.getRootCauseStackTrace(ex);
        Arrays.stream(stackTrace).forEach(s -> builder.append(builder.length() < 5000 ? s : ""));
        return builder.toString();
    }

    protected void updateIngestionLogMsg(Task task,
        List<Error> errors) {

        List<IngestionLogMsg> logMsgList = new ArrayList<>();
        errors.forEach(error -> {
            AssetError assetError = ErrorProvider.findError(error.getErrorCode());
            String message = assetError.getMsg();
            if (error.getPlaceHolders() != null && error.getPlaceHolders().length > 0) {
                try {
                    message = String.format(message, error.getPlaceHolders());
                } catch (IllegalFormatException ife) {
                    log.error("failed to format error message", ife);
                    message = error.getMessage();
                }
            }

            if (!message.isEmpty() && message.contains("%") && (error.getPlaceHolders() == null
                || error.getPlaceHolders().length == 0)) {
                message = error.getMessage();
            }

            IngestionLogMsg logMsg = new IngestionLogMsg();
            logMsg.setMsgCode(error.getErrorCode());
            logMsg.setMsg(message);
            logMsg.setAction(assetError.getAction());
            logMsg.setActualMsg(error.getActualMessage());
            String resolution = assetError.getResolution();
            if (error.getResolutionPlaceHolders() != null
                && error.getResolutionPlaceHolders().length > 0) {
                try {
                    resolution = String.format(resolution, error.getResolutionPlaceHolders());
                } catch (IllegalFormatException ife) {
                    log.error("failed to format resolution", ife);
                }
            }
            logMsg.setResolution(resolution);
            logMsg.setMsgType(assetError.getMsgType());
            logMsg.setTaskUuid(task.getUuid());
            logMsgList.add(logMsg);
        });
        if (task.getIngestionLogMsgList() != null) {
            task.getIngestionLogMsgList().addAll(logMsgList);
        } else {
            task.setIngestionLogMsgList(logMsgList);
        }
    }

    protected void updateIngestionLogMsgForAssetError(Task task,
        List<AssetError> errors,
        Throwable cause) {
        List<IngestionLogMsg> logMsgList = new ArrayList<>();
        String stackTrace = getStackTrace(cause);
        errors.forEach(error -> {
            IngestionLogMsg logMsg = new IngestionLogMsg();
            logMsg.setMsgCode(error.getMsgCode());
            logMsg.setMsg(error.getMsg() != null ? error.getMsg() : "");
            logMsg.setActualMsg(error.getActualMsg() != null ? error.getActualMsg() : stackTrace);
            logMsg.setAction(error.getAction());
            logMsg.setResolution(error.getResolution());
            logMsg.setMsgType(error.getMsgType());
            logMsg.setTaskUuid(task.getUuid());
            logMsgList.add(logMsg);
        });
        if (task.getIngestionLogMsgList() != null) {
            task.getIngestionLogMsgList().addAll(logMsgList);
        } else {
            task.setIngestionLogMsgList(logMsgList);
        }
    }

}
