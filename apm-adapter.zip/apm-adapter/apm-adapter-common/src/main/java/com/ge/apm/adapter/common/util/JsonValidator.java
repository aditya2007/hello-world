/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.util;

import java.io.IOException;
import java.util.Map;
import java.util.regex.Pattern;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import com.ge.apm.s95.model.TagAssociation;
import com.ge.asset.commons.validator.ValidationFailedException;

import static net.javacrumbs.jsonunit.JsonAssert.assertJsonEquals;

/**
 * Created by lingpeili on 10/25/17.
 */
@Component
@Slf4j
public class JsonValidator {

    // @JsonIgnoreProperties({ "unit", "unitGroup" })
    // public interface IMixinForTags { }

    private static final ObjectMapper CUSTOM_MAPPER = new ObjectMapper();

    private static final Pattern EXTRA = Pattern.compile("Extra:(.?)|\n");

    private static final Pattern GOT = Pattern.compile("(got(.?)|.\n)");

    static {
        CUSTOM_MAPPER.setSerializationInclusion(Include.NON_NULL);
        CUSTOM_MAPPER.enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS);
        CUSTOM_MAPPER.configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false);
        CUSTOM_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);
    }

    public static <T> void validateJsonAgainstClass(String json, Class<T> objClass)
        throws IOException, ValidationFailedException {
        String errContext = null;
        String errReason = null;

        try {
            json = json.replace("[]", "null");

            if (objClass.equals(TagAssociation.class)) {
                json = json.replaceAll("\"unit\"[ ]*:[^,}\\]]*[,]?", "");
                json = json.replaceAll("\"unitGroup\"[ ]*:[^,}\\]]*[,]?", "");
                json = json.replaceAll("\",}", "\"}");
            }

            T generatedObj = CUSTOM_MAPPER.reader(objClass).readValue(json);
            Map<?, ?> originalJsonMap = CUSTOM_MAPPER.readValue(json, Map.class);

            JsonNode generatedObjMap = CUSTOM_MAPPER.valueToTree(generatedObj);
            JsonNode originalObjMap = CUSTOM_MAPPER.valueToTree(originalJsonMap);

            assertJsonEquals(generatedObjMap, originalObjMap);
        } catch (AssertionError ae) {
            String fieldName = ae.getMessage();
            Pattern pattern = fieldName.contains("Extra") ? EXTRA : GOT;
            String[] split = pattern.split(fieldName);

            errContext = split[split.length - 1];
            errReason = "is an Invalid field/value";
            String errMsg = "'" + errContext + "' " + errReason;
            throw new JsonMappingException(errMsg, ae);
        } catch (UnrecognizedPropertyException exception) {
            errContext = exception.getPropertyName();
            errReason = "is an Unrecognized field";
            String errMsg = "'" + errContext + "' " + errReason;
            throw new JsonMappingException(errMsg, exception);
        } catch (JsonMappingException exception) {
            errContext = exception.getPath().get(0).getFieldName();
            errReason = "or its value is defined with the wrong data type";
            String errMsg = "'" + errContext + "' " + errReason;
            throw new JsonMappingException(errMsg, exception);
        }
    }
}