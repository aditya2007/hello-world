/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.config;

import com.ge.asset.commons.mq.config.BaseRoutes;

/**
 * @author Chand Bhaverisetti 212432041
 * @version Feb 24, 2017
 * @since 1.0
 */
public class AdapterRoutes extends BaseRoutes {

    public static final String DIRECT_ASSET_CCOM_RECEIVER = "direct:apm.adapter.asset.ccom.receiver";

    public static final String LOG_TASK_ERROR = "log:com.ge.apm.adapter.%s.asset.task?level=ERROR"
        + "&showCaughtException=true&showStackTrace=true";

    public static final String DIRECT_REST_RESPONSE = "direct:adapter.%s.response.rest";
    public static final String DIRECT_DOWNLOAD_REST_RESPONSE = "direct:adapter.%s.download.response.rest";
    public static final String DIRECT_ENRICH = "direct:adapter.%s.enrich";
    public static final String DIRECT_ENRICH_DOWNLOAD = "direct:adapter.%s.download.enrich";

}
