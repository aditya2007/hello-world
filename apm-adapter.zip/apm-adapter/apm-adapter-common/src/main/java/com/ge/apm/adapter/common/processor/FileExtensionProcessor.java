/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.domain.persistence.entity.Task;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.Error.ErrorType;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
public class FileExtensionProcessor {

    @Autowired
    private ITaskProcessorRepository taskRepository;

    @Value("${zip.file.size.limit:10485760}")
    private long maxBytes;

    public boolean invalidZipFileExtension(Exchange exchange) {
        String fileName = exchange.getIn().getHeader(Exchange.FILE_NAME, String.class);
        if (fileName == null || !fileName.toUpperCase().endsWith(".ZIP")) {
            setExceptionInExchange(exchange, ErrorConstants.INVALID_ZIP_FORMAT);
            return true;
        }
        return false;
    }

    public boolean zipFileSizeLimitExceeded(Exchange exchange) {
        long zipFileSize = exchange.getIn().getHeader(MessageConstants.FILE_SIZE, 0, Long.TYPE);
        if (zipFileSize > maxBytes) {
            setExceptionInExchange(exchange, ErrorConstants.FILE_SIZE_LIMIT_EXCEEDED);
            return true;
        }
        return false;
    }

    public boolean invalidJsonExtensionOrBody(Exchange exchange) {
        String fileName = exchange.getIn().getHeader(Exchange.FILE_NAME, String.class);
        if (fileName == null || !fileName.endsWith(".json") || FilenameUtils.getName(fileName).startsWith(".")
            || exchange.getIn().getBody() == null) {
            return true;
        }
        return false;
    }

    public boolean containsAtLeastOneJson(Exchange exchange) {
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        String taskUuid = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        List<Task> task = taskRepository.findChildren(tenantUuid, taskUuid);
        if (task != null && !task.isEmpty()) {
            return true;
        }
        setExceptionInExchange(exchange, ErrorConstants.INVALID_ZIP_CONTENT);
        return false;
    }

    private void setExceptionInExchange(Exchange exchange, String errorConstant) {
        List<Error> fileExtensionErrorList = new ArrayList<>();
        Error fileExtensionError = new Error(ErrorType.ERROR);
        fileExtensionError.setErrorCode(errorConstant);
        fileExtensionErrorList.add(fileExtensionError);
        exchange.setProperty(Exchange.EXCEPTION_CAUGHT, new ValidationFailedException(fileExtensionErrorList));
    }
}
