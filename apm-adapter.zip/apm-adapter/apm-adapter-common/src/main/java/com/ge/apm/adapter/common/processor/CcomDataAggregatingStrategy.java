/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.ge.apm.ccom.model.CCOMData;
import com.ge.asset.commons.mq.processor.base.BaseAggregatingStrategy;

@Component
public class CcomDataAggregatingStrategy extends BaseAggregatingStrategy {

    @Override
    public Exchange aggregate(Exchange paramOldExchange, Exchange newExchange) {
        Exchange oldExchange = paramOldExchange;
        CCOMData oldCcomData = null;
        CCOMData newCcomData = null;

        if (oldExchange != null) {
            oldCcomData = oldExchange.getIn().getBody(CCOMData.class);
        }
        if (newExchange != null) {
            newCcomData = newExchange.getIn().getBody(CCOMData.class);
        }

        if (oldCcomData == null) {
            if (newCcomData == null) {
                oldCcomData = new CCOMData();
            } else {
                oldCcomData = newCcomData;
            }
        } else if (newCcomData != null) {
            oldCcomData.getEntity().addAll(newCcomData.getEntity());
        }

        oldExchange = mergeExchange(oldExchange, newExchange);

        if (oldExchange != null) {
            oldExchange.getIn().setBody(oldCcomData);
        }
        return oldExchange;
    }
}
