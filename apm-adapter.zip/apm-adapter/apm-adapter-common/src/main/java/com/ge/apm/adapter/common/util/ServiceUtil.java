/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.util;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.ge.apm.common.exception.ServiceException;
import com.ge.apm.common.util.JsonBuilder;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.mq.model.Error;

public final class ServiceUtil {

    private ServiceUtil() {
        //since this is a utility method, adding this private constructor for PMD.
    }

    public static Response createResponse(Object data) {
        if (data instanceof Exception) {
            return createResponse((Exception) data);
        }
        if (data == null) {
            return Response.noContent().build();
        }
        return Response.ok(JsonBuilder.toNullExcludedJson(data), MediaType.APPLICATION_JSON).build();
    }

    private static Response createResponse(Exception e) {
        Object data;
        Response.ResponseBuilder responseBuilder = Response.status(Status.INTERNAL_SERVER_ERROR);
        if (e instanceof ServiceException) {
            ServiceException svcExp = (ServiceException) e;
            data = new Error(svcExp.getCode(), svcExp.getMessage(), null);
            if (ErrorProvider.findError(ErrorConstants.NO_DATA_FOUND_COMMON).name().equals(svcExp.getCode())) {
                responseBuilder = Response.status(Status.NOT_FOUND);
            }
        } else {
            data = e;
            responseBuilder = Response.status(Status.INTERNAL_SERVER_ERROR);
        }
        responseBuilder.entity(JsonBuilder.toNullExcludedJson(data));
        responseBuilder.type(MediaType.APPLICATION_JSON);
        return responseBuilder.build();
    }

    public static Response createErrorResponse(Object data) {
        Response.ResponseBuilder responseBuilder = Response.status(Status.INTERNAL_SERVER_ERROR);
        responseBuilder.entity(JsonBuilder.toNullExcludedJson(data));
        responseBuilder.type(MediaType.APPLICATION_JSON);
        return responseBuilder.build();
    }
}
