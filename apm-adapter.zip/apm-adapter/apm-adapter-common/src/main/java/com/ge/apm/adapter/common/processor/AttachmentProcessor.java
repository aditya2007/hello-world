/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.io.IOException;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.springframework.stereotype.Component;

@Component
public class AttachmentProcessor implements Processor {

    @Override
    public void process(Exchange exchange) throws IOException {
        Attachment attachment = exchange.getIn().getBody(Attachment.class);

        if (attachment == null) {
            exchange.getIn().setBody(null);
        } else {
            exchange.getIn().setHeader(Exchange.FILE_NAME, attachment.getDataHandler().getName());
            exchange.getIn().setBody(attachment.getDataHandler().getInputStream());
        }
    }
}
