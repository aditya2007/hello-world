/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.common.constants.TaskStatus;
import com.ge.apm.adapter.domain.persistence.entity.Task;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.apm.asset.model.DownloadTask;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.AssetError;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.exception.AssetServiceException;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.Error.ErrorType;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
@Slf4j
@SuppressWarnings("PMD.TooManyMethods")
public class DownloadTaskProcessor extends TaskProcessor {

    @Autowired
    private ITaskProcessorRepository taskProcessorRepository;

    @Override
    public void inProgressTask(Exchange exchange) {
        exchange.getIn().setHeader(MessageConstants.TASK_ENTITY_TYPE, "Download");
        super.inProgressTask(exchange);
    }

    public void transformToDownloadTask(Exchange exchange) {
        Task task = exchange.getIn().getBody(Task.class);
        DownloadTask dto = new DownloadTask();
        dto.setTaskUuid(task.getUuid());
        dto.setDescription(task.getDescription());
        dto.setTaskStatus(task.getStatus());
        dto.setLastUpdatedTime(task.getUpdatedOn().getTime());
        exchange.getIn().setBody(dto);
    }

    @Override
    public void markCompleted(Exchange exchange) {

        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID,
            String.class);
        Task task = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, taskId);
        if (task.getStatus().equals(TaskStatus.ERROR)) {
            log.debug("task " + task.getUuid() + "is in error status and cannot be updated");
        } else {
            DownloadTask downloadTask = (DownloadTask) exchange.getIn().getBody();
            task.setStatus(TaskStatus.COMPLETED);
            try {
                task.setTaskResponse(getJsonNode(downloadTask.getTaskResponse()));
                saveAndFlush(task);
            } catch (Exception ex) {
                log.error(ex.getMessage(), ex);
                task.setStatus(TaskStatus.ERROR);
                setStatusToError(task, "");
            }
        }

    }

    public void markSkipped(Exchange exchange) {

        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        com.ge.apm.adapter.model.Task dto = new com.ge.apm.adapter.model.Task();
        dto.setDescription(exchange.getIn().getHeader(MessageConstants.DESCRIPTION).toString());
        dto.setUuid(exchange.getIn().getHeader(MessageConstants.TASK_UUID).toString());
        exchange.getIn().setBody(dto);
        if (log.isDebugEnabled()) {
            log.debug(String
                .format(
                    "Received another download request for the same tenantId %s, %s",
                    tenantUuid, DateTime.now()));
        }
    }

    @Override
    public void taskError(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        Task task = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, taskId);
        if (!(task.getStatus().equals(TaskStatus.ARCHIVED))) {
            task.setCompletedCount(
                exchange.getIn().getHeader(MessageConstants.TASK_ENTITY_COMPLETE, 0, Long.class));
            Throwable caused = exchange.getIn().getHeader(Exchange.EXCEPTION_CAUGHT, Throwable.class);
            if (caused instanceof ValidationFailedException) {
                updateIngestionLogMsg(task,
                    ((ValidationFailedException) caused).getErrorCollection());
            } else if (caused.getCause() != null && caused.getCause() instanceof ValidationFailedException) {
                updateIngestionLogMsg(task,
                    ((ValidationFailedException) caused.getCause()).getErrorCollection());
            } else if (caused instanceof AssetServiceException) {
                List<AssetError> errorList = ((AssetServiceException) caused).getErrors();
                updateIngestionLogMsgForAssetError(task, errorList, caused);
            } else if (caused instanceof ServiceException && ((ServiceException) caused).getCode()
                .startsWith("E")) {
                List<Error> errorList = new ArrayList<>();
                Error error = new Error(ErrorType.ERROR, ((ServiceException) caused).getCode());
                error.setActualMessage(getStackTrace(caused));
                error.setMessage(caused.getMessage());
                errorList.add(error);
                updateIngestionLogMsg(task, errorList);
            } else {
                log.error("Download error has occurred!", caused);

                AssetError assetError = ErrorProvider.findError("E50018");
                updateIngestionLogMsgForAssetError(task,
                    Arrays.asList(assetError), caused);
            }

            setStatusToError(task, "");
            saveAndFlush(task);
        }
    }

    private JsonNode getJsonNode(JsonObject jsonObject) throws IOException {

        Gson gson = new Gson();
        String json = gson.toJson(jsonObject);
        return new ObjectMapper().readTree(json);
    }

}
