/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.config;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.camel.Converter;
import org.apache.camel.dataformat.zipfile.ZipIterator;
import org.apache.commons.io.IOUtils;

/**
 * A camel type converter to convert {@link ZipIterator} to <code>byte[]</code>.
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Dec 15, 2016
 * @since 1.0
 */
public class ZipIteratorToBytesConverter {

    @Converter
    public byte[] convertZipIterator(ZipIterator zipIterator) throws IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            while (zipIterator.hasNext()) {
                baos.write(IOUtils.toByteArray((InputStream) zipIterator.next().getBody()));
            }

            return baos.toByteArray();
        }
    }
}
