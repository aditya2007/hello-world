/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.util;

import java.util.HashMap;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.EndpointInject;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.rabbitmq.RabbitMQConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ge.apm.asset.model.Base;
import com.ge.apm.asset.model.Typed;
import com.ge.asset.commons.mq.constants.MessageConstants;

@Component
@Slf4j
public class DtoDispatcher {

    @EndpointInject(uri = "direct:apm.adapter.asset.dto")
    protected ProducerTemplate dataProducer;

    @Value("${rabbitmq.deliveryMode}")
    private int rabbitmqDeliveryMode;

    private ThreadLocal<Map<String, Object>> headers;

    public DtoDispatcher() {
        this.headers = new ThreadLocal<Map<String, Object>>() {
            @Override
            protected Map<String, Object> initialValue() {
                return new HashMap<>();
            }
        };
    }

    public <T extends Object> void initialize(Map<String, T> headers) {
        this.headers.set(new HashMap<>(headers));
        this.headers.get().put(MessageConstants.ASSET_TYPE, "DTO");
    }

    public <T extends Base> void sendDtos(T... dto) {
        if (dto.length > 0) {
            Map<String, Object> headers = new HashMap<>(this.headers.get());
            headers.put(RabbitMQConstants.DELIVERY_MODE, rabbitmqDeliveryMode);
            headers.put(MessageConstants.ASSET_TYPE, dto[0].getClass().getSimpleName());
            headers.put(MessageConstants.TASK_ENTITY_TOTAL, dto.length);
            if (log.isDebugEnabled()) {
                log.debug("Sending DTOs - batch size {}, Task Id: {}", dto.length,
                    this.headers.get().get(MessageConstants.TASK_UUID));
            }
            if (isConnection(dto[0])) {
                headers.put(MessageConstants.ASSET_TYPE, MessageConstants.ASSET_CONNECTION_PREFIX);
            }
            dataProducer.sendBodyAndHeaders(dto, headers);
        }
    }

    private <T extends Base> boolean isConnection(T dto) {
        return (Typed.class.isAssignableFrom(dto.getClass()) && !StringUtils.isEmpty(((Typed) dto).getParent()));
    }

    public Map<String, Object> getHeaders() {
        return headers.get();
    }
}
