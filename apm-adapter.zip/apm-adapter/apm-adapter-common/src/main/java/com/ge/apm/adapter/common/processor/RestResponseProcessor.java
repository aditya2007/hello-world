/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.common.util.ServiceUtil;
import com.ge.asset.commons.mq.model.Error;
import com.ge.asset.commons.mq.processor.base.BaseResponseProcessor;

@Component
public class RestResponseProcessor extends BaseResponseProcessor {

    private final ConcurrentLinkedQueue<java.lang.Error> errors;

    public RestResponseProcessor() {
        this.errors = new ConcurrentLinkedQueue<>();
    }

    public RestResponseProcessor(final ConcurrentLinkedQueue<java.lang.Error> errors) {
        this.errors = errors;
    }

    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void process(Exchange exchange) throws Exception {
        List<java.lang.Error> errorsCaught = new ArrayList<>();
        while (errors.peek() != null) {
            errorsCaught.add(errors.poll());
        }

        if (errorsCaught.isEmpty()) {
            exchange.getOut().setBody(ServiceUtil.createResponse(exchange.getIn().getBody()));
        } else {
            List<Error> responses = new ArrayList<>();
            for (java.lang.Error error : errorsCaught) {
                Error response = new Error();
                updateResponse(error, response);
                responses.add(response);
            }
            exchange.getOut().setBody(ServiceUtil.createErrorResponse(responses));
        }

        exchange.getOut().setHeaders(exchange.getIn().getHeaders());
    }

    public void createResponse(Exchange exchange) {
        exchange.getOut().setBody(ServiceUtil.createResponse(exchange.getIn().getBody()));
        exchange.getOut().setHeaders(exchange.getIn().getHeaders());
    }

    public void disableResponse(Exchange exchange) {

        Response.ResponseBuilder responseBuilder = Response.status(Status.FORBIDDEN);
        responseBuilder.type(MediaType.APPLICATION_JSON);
        exchange.getOut().setBody(responseBuilder.build());
        exchange.getOut().setHeaders(exchange.getIn().getHeaders());

    }
}
