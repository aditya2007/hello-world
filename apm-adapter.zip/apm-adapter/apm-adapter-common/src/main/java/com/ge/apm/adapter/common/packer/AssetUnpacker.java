/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.packer;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import com.ge.apm.asset.model.Named;
import com.ge.apm.bod.model.BusinessObjectDocument;
import com.ge.apm.bod.model.noun.CcomPayload;
import com.ge.apm.bod.model.noun.DtoPayload;
import com.ge.apm.bod.model.verb.Sync;
import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.common.exception.DefaultErrorCode;
import com.ge.apm.common.exception.ServiceException;

@Component
@Slf4j
public class AssetUnpacker {

    public Object createEntities(BusinessObjectDocument bod) {
        if (!(bod.getDataArea().getVerb() instanceof Sync)) {
            log.error("Verb not supported for this operation: " + bod);
            throw new ServiceException(DefaultErrorCode.create("INVALID_BOD", "Verb not supported for this operation"));
        }

        if (bod.getDataArea().getNoun() instanceof CcomPayload) {
            return unpackCcomPayload((CcomPayload) bod.getDataArea().getNoun());
        } else if (bod.getDataArea().getNoun() instanceof DtoPayload) {
            return unpackDtoPayload((DtoPayload) bod.getDataArea().getNoun());
        }

        log.error("Noun not supported for this operation: " + bod);
        throw new ServiceException(DefaultErrorCode.create("INVALID_BOD", "Noun not supported for this operation"));
    }

    private Object unpackCcomPayload(CcomPayload payload) {
        List<Entity> entities = new ArrayList<>();
        if (payload != null && payload.getCcomData() != null) {
            entities = payload.getCcomData().getEntity();
        }
        return entities;
    }

    private Object unpackDtoPayload(DtoPayload payload) {
        List<Named> dtos = new ArrayList<>();
        if (payload != null && payload.getDtoData() != null) {
            dtos = payload.getDtoData().getDto();
        }
        return dtos;
    }
}
