/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.util.List;
import java.util.Map;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;
import org.springframework.stereotype.Component;

import com.ge.apm.adapter.common.util.ServiceUtil;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.mq.model.DownloadType;


@Component
public class DownloadTypeProcessor implements Processor {

    private static final String DOWNLAODTYPE = "type";

    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void process(Exchange exchange) throws Exception {

        String queryString = exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class);

        MultivaluedMap<String, String> queryMap = JAXRSUtils.getStructuredParams(queryString, "&",
            false, false);

        for (Map.Entry<String, List<String>> eachQueryParam : queryMap.entrySet()) {
            exchange.setProperty(eachQueryParam.getKey(),
                eachQueryParam.getValue().toString().replaceAll("\\[(.*?)\\]", "$1"));
        }

        if (exchange.getProperty(DOWNLAODTYPE) != null) {

            String exportType = exchange.getProperty("type").toString();
            if (!DownloadType.isValid(exportType)) {
                exchange.getIn().setBody(ServiceUtil.createErrorResponse("Unsupported Download Type."));
                throw new ServiceException("Unsupported Download Type.");
            } else {
                exchange.getIn().getHeaders().put(MessageConstants.ASSET_DOWNLOAD_TYPE, exportType);
            }
        }
    }

}