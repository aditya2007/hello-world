/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.ge.apm.common.support.RequestContext;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.stuf.tenant.context.TenantContext;

@Component
public class TenantUuidProcessor implements Processor {

    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void process(Exchange exchange) throws Exception {
        String tenantUuid = null;
        if (TenantContext.getInstance() != null) {
            tenantUuid = TenantContext.getInstance().getTenantUuid();
        }
        if (tenantUuid == null) {
            throw new IllegalStateException("Tenant not found");
        }

        String traceUuid = RequestContext.get(RequestContext.REQUEST_ID, String.class);
        exchange.getIn().setHeader(MessageConstants.TENANT_UUID, tenantUuid);
        exchange.getIn().setHeader(MessageConstants.TRACE_UUID, traceUuid);
        MDC.put("X-B3-TraceId", traceUuid);
        MDC.put("tenant", tenantUuid);
    }
}
