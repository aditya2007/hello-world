/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.constants;

public final class AttributeTypes {

    public static final String DESCRIPTION = "4298F434F1E04F33BE545D4E0FC3B096";

    public static final String QUALIFIED_NAME = "588DC15D61FA4A76A06E30267C6D310A";

    public static final String EQUIPMENT_ID = "383F53E86FAA458180910D824BD35773";

    public static final String PARENT = "5A11DA1081F64BF6A78E2C74F53D895A";

    public static final String ALIAS = "15C933A302534FF1949CADC2D429ECF6";

    private AttributeTypes() {
    }
}
