/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.constants;

public final class TaskStatus {

    public static final String QUEUED = "QUEUED";

    public static final String IN_PROGRESS = "IN PROGRESS...";

    public static final String COMPLETED = "COMPLETED";

    public static final String ERROR = "ERROR: ";

    public static final String DONE_PROCESSING = "DONE PROCESSING";

    public static final String ARCHIVED = "ARCHIVED";

    public static final String SKIPPED = "SKIPPED";
}
