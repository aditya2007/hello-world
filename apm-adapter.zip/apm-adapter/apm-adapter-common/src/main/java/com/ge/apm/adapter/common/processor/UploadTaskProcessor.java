/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.ge.apm.adapter.common.constants.TaskStatus;
import com.ge.apm.adapter.domain.persistence.entity.FileChecksum;
import com.ge.apm.adapter.domain.persistence.entity.IngestionLogMsg;
import com.ge.apm.adapter.domain.persistence.entity.Task;
import com.ge.apm.adapter.domain.persistence.repository.IFileChecksumRepository;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.AssetError;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.exception.AssetServiceException;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.Error.ErrorType;
import com.ge.asset.commons.validator.ValidationFailedException;

@Component
@Slf4j
@SuppressWarnings("PMD.TooManyMethods")
public class UploadTaskProcessor extends TaskProcessor {

    public static final String ERROR_IN_CHILD_TASK = "Error in child task";

    @Autowired
    private ITaskProcessorRepository taskProcessorRepository;

    @Autowired
    private IFileChecksumRepository fileChecksumRepository;

    @Override
    public void markCompleted(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        Long completedCount = exchange.getIn().getHeader(MessageConstants.TASK_ENTITY_COMPLETE, 0, Long.class);
        setStatusCompleted(tenantUuid, taskId, completedCount);
    }

    public void markSkipped(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        Task task = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, taskId);
        if (task.getParent() == null) {
            task.setDescription(exchange.getIn().getHeader(MessageConstants.DESCRIPTION, String.class));
            task.setStatus(TaskStatus.SKIPPED);
            AssetError assetError = ErrorProvider.findError(ErrorConstants.SKIPPED_PROCESSING_ZIP);
            updateIngestionLogMsgForAssetError(task, Arrays.asList(assetError), null);
            saveAndFlush(task);
        } else {
            if (log.isDebugEnabled()) {
                log.debug(String
                    .format("Unsupported: a task can only be marked as %s if it's the zip file level root task",
                        TaskStatus.SKIPPED));
            }
        }
    }

    public void markDoneProcessing(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        setStatusDoneProcessing(tenantUuid, taskId);
    }

    @Override
    public void taskError(Exchange exchange) {
        String taskId = exchange.getIn().getHeader(MessageConstants.TASK_UUID, String.class);
        String tenantUuid = exchange.getIn().getHeader(MessageConstants.TENANT_UUID, String.class);
        Task task = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, taskId);
        if (!(task.getStatus().equals(TaskStatus.ARCHIVED))) {
            //task = entityManager.find(Task.class, task.getId(), LockModeType.PESSIMISTIC_WRITE);

            task.setCompletedCount(exchange.getIn().getHeader(MessageConstants.TASK_ENTITY_COMPLETE, 0, Long.class));
            Throwable caused = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);

            if (caused instanceof ValidationFailedException) {
                updateIngestionLogMsg(task, ((ValidationFailedException) caused).getErrorCollection());
            } else if (caused.getCause() instanceof ValidationFailedException) {
                updateIngestionLogMsg(task, ((ValidationFailedException) caused.getCause()).getErrorCollection());
            } else if (caused instanceof AssetServiceException) {
                List<AssetError> errorList = ((AssetServiceException) caused).getErrors();
                updateIngestionLogMsgForAssetError(task, errorList, caused);
            } else if (caused instanceof ServiceException && ((ServiceException) caused).getCode().startsWith("E")) {
                List<Error> errorList = new ArrayList<>();
                Error error = new Error(ErrorType.ERROR, ((ServiceException) caused).getCode());
                error.setActualMessage(getStackTrace(caused));
                error.setMessage(caused.getMessage());
                errorList.add(error);
                updateIngestionLogMsg(task, errorList);
            } else {
                log.error("Ingestion error has occurred!", caused);

                AssetError assetError = ErrorProvider.findError("E10000");
                updateIngestionLogMsgForAssetError(task, Arrays.asList(assetError), caused);
            }

            setStatusToError(task, "");
            saveAndFlush(task);
            propagateErrorToParents(task, ERROR_IN_CHILD_TASK);
        }
    }

    private void setStatusDoneProcessing(String tenantUuid, String taskId) {
        Task task = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, taskId);
        //task = entityManager.find(Task.class, task.getId(), LockModeType.PESSIMISTIC_WRITE);
        if (task.getStatus().equals(TaskStatus.IN_PROGRESS)) {
            task.setStatus(TaskStatus.DONE_PROCESSING);
            saveAndFlush(task);

            List<Task> childTasksInError = taskProcessorRepository.findChildrenInStatus(task.getId(), TaskStatus.ERROR);
            if (!CollectionUtils.isEmpty(childTasksInError)) {
                propagateErrorToParents(childTasksInError.get(0), ERROR_IN_CHILD_TASK);
            }
        }
    }

    public void setStatusCompleted(String tenantUuid, String taskId, Long completedCount) {
        Task task = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, taskId);
        //task = entityManager.find(Task.class, task.getId(), LockModeType.PESSIMISTIC_WRITE);
        Task parentTask = task.getParent();
        if (parentTask != null && !task.getStatus().equals(TaskStatus.ARCHIVED)) {
            //parentTask = entityManager.find(Task.class, parentTask.getId(), LockModeType
            // .PESSIMISTIC_WRITE);
            parentTask = taskProcessorRepository.findByTenantUuidAndUuid(tenantUuid, parentTask.getUuid());
            Task grandParentTask = parentTask.getParent();
            // leaf node
            if (grandParentTask != null) {
                task.setCompletedCount(completedCount);
                boolean hasValidationError = hasValidationError(task);
                if (!task.getStatus().equals(TaskStatus.ERROR) || (task.getStatus().equals(TaskStatus.ERROR)
                    && !hasValidationError)) {
                    if (task.getStatus().equals(TaskStatus.ERROR)) {
                        //marking system error tasks to archived is required for ingestion recovery
                        log.debug("marking task {} as ARCHIVED from ERROR", task.getUuid());
                    }
                    task.setStatus(TaskStatus.ARCHIVED);

                    if (completedCount != task.getTotalCount()) {
                        log.debug("marking incomplete task as ERROR", task.getUuid());
                        task.setStatus(TaskStatus.ERROR);
                    }
                }
                saveAndFlush(task);
                if (task.getStatus().equals(TaskStatus.ARCHIVED) && completedCount.intValue() == 0) {
                    log.error("leaf is archived but complete count is " + completedCount);
                }
            }

            Integer inprogressCount = taskProcessorRepository.findCountOfChildrenInStatus(parentTask.getId(),
                TaskStatus.IN_PROGRESS, TaskStatus.QUEUED, TaskStatus.DONE_PROCESSING);
            if (inprogressCount <= 0 && parentTask.getStatus().contains(TaskStatus.DONE_PROCESSING)) {
                Integer errorCount = taskProcessorRepository.findCountOfChildrenInError(parentTask.getId(),
                    TaskStatus.ERROR + "%");

                if (errorCount == 0) {
                    parentTask = taskProcessorRepository.findOne(parentTask.getId());
                    parentTask.setStatus(TaskStatus.COMPLETED);
                    if (grandParentTask == null) {
                        // the zip file root task is being marked as COMPLETED, delete file checksum
                        FileChecksum fc = fileChecksumRepository.findByTenantUuidAndTaskId(tenantUuid,
                            parentTask.getId());
                        if (fc != null) {
                            fileChecksumRepository.delete(fc);
                        }
                        updateTotalAndCompletedCounts(parentTask);
                    }
                    saveAndFlush(parentTask);
                    setStatusCompleted(tenantUuid, parentTask.getUuid(), parentTask.getCompletedCount());
                } else {
                    setStatusToError(parentTask, ERROR_IN_CHILD_TASK);
                    saveAndFlush(parentTask);
                    propagateErrorToParents(parentTask, ERROR_IN_CHILD_TASK);
                }
            }
        }
    }

    private boolean hasValidationError(Task task) {
        List<IngestionLogMsg> logMsgs = task.getIngestionLogMsgList();
        boolean hasValidationError = false;
        if (CollectionUtils.isEmpty(logMsgs)) {
            return hasValidationError;
        }
        for (IngestionLogMsg logMsg : logMsgs) {
            if (!logMsg.getMsgCode().equals(ErrorConstants.SYSTEM_ERROR)) {
                hasValidationError = true;
                break;
            }
        }
        return hasValidationError;
    }

    public void updateTotalAndCompletedCounts(Task parentTask) {
        // update root task total and complete count
        List<Task> jsonTasks = taskProcessorRepository.findChildren(parentTask.getTenantUuid(), parentTask.getUuid());
        if (!CollectionUtils.isEmpty(jsonTasks)) {
            List<Long> jsonTaskIds = new ArrayList<>();
            jsonTasks.stream().forEach(t -> jsonTaskIds.add(t.getId()));
            Object[][] results = taskProcessorRepository.findTotalCompletedCountBasedOnJsonParentIds(
                parentTask.getTenantUuid(), jsonTaskIds);
            if (results != null && results[0][0] != null && results[0][1] != null) {
                parentTask.setCompletedCount((Long) results[0][0]);
                parentTask.setTotalCount((Long) results[0][1]);
                saveAndFlush(parentTask);
            }

            // update json task total and complete count
            Map<Task, List<Task>> jsonTaskChildrenMap = new HashMap<>();
            jsonTasks.stream().forEach(jsonTask -> jsonTaskChildrenMap.put(jsonTask,
                taskProcessorRepository.findChildrenIncludeArchived(jsonTask.getTenantUuid(), jsonTask.getUuid())));
            jsonTaskChildrenMap.forEach((jsonTask, childrenTasks) -> {
                if (CollectionUtils.isEmpty(childrenTasks)) {
                    jsonTask.setTotalCount(childrenTasks.stream().mapToLong(child -> child.getTotalCount()).sum());
                    jsonTask.setCompletedCount(
                        childrenTasks.stream().mapToLong(child -> child.getCompletedCount()).sum());
                }
            });
            taskProcessorRepository.save(jsonTasks);
        }
    }

    public void propagateErrorToParents(Task child, String error) {
        if (child.getParent() != null) {
            //Task parent = entityManager.find(Task.class, child.getParent().getId(),
            // LockModeType.PESSIMISTIC_WRITE);
            Task parent = taskProcessorRepository.findByTenantUuidAndUuid(child.getTenantUuid(),
                child.getParent().getUuid());
            if (parent != null) {
                //updateParentTaskCompletion(parent);
                Integer count = taskProcessorRepository.findCountOfChildrenInStatus(parent.getId(),
                    TaskStatus.IN_PROGRESS, TaskStatus.QUEUED, TaskStatus.DONE_PROCESSING);
                if (count <= 0 && (parent.getStatus().equals(TaskStatus.DONE_PROCESSING)
                    || parent.getParent() == null)) {
                    parent.setStatus(TaskStatus.ERROR + error);
                    saveAndFlush(parent);
                    propagateErrorToParents(parent, error);
                }
            }
        } else {
            FileChecksum fc = fileChecksumRepository.findByTenantUuidAndTaskId(child.getTenantUuid(), child.getId());
            if (fc != null) {
                fileChecksumRepository.delete(fc);
            }
            updateTotalAndCompletedCounts(child);
        }
    }
}
