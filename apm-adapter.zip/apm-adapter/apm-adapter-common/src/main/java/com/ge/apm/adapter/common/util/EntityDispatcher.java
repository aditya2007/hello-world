/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.EndpointInject;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.rabbitmq.RabbitMQConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.apm.ccom.model.core.Entity;
import com.ge.apm.ccom.model.measurements.locations.MeasurementLocation;
import com.ge.apm.ccom.model.registry.MonitoredEntity;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.util.checksum.ChecksumUtil;

@Component
@Slf4j
public class EntityDispatcher implements IEntityDispatcher {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    //TODO: This value is in IRootLevelProcessor, when we collapse adapter-common grab from there
    private static final String CONNECTIONS = "connections";

    //Below endpoint is also specified for consumer in @CcomAdapterRouteBuilder
    @EndpointInject(uri = "direct:apm.adapter.asset.ccom.receiver")
    protected ProducerTemplate dataProducer;

    @Value("${rabbitmq.deliveryMode}")
    private int rabbitmqDeliveryMode;

    @Value("${entity.dispatcher.connection.batchSize:20}")
    private int connectionBatchSize;

    private ThreadLocal<Map<String, Object>> headers;

    private ThreadLocal<Integer> batchSize;

    private ThreadLocal<Map<String, List<Entity>>> entitiesTypeMap;

    private ThreadLocal<List<Entity>> connectionList;

    private HashMap<String, String> typeToLabelMap;

    public EntityDispatcher() {
        this.entitiesTypeMap = new ThreadLocal<Map<String, List<Entity>>>() {
            @Override
            protected Map<String, List<Entity>> initialValue() {
                return new HashMap<>();
            }
        };
        this.connectionList = new ThreadLocal<List<Entity>>() {
            @Override
            protected List<Entity> initialValue() {
                return new ArrayList<>();
            }
        };
        this.batchSize = new ThreadLocal<Integer>() {
            @Override
            protected Integer initialValue() {
                return 1;
            }
        };
        this.headers = new ThreadLocal<Map<String, Object>>() {
            @Override
            protected Map<String, Object> initialValue() {
                Map<String, Object> value = new HashMap<>();
                value.put(MessageConstants.ASSET_TYPE, "CCOM");
                return value;
            }
        };

        try {
            typeToLabelMap = MAPPER.readValue(this.getClass().getResourceAsStream("/TypeToLabel.json"), HashMap.class);
        } catch (IOException ioe) {
            log.error(ioe.getMessage(), ioe);
            typeToLabelMap = new HashMap<>();
        }
    }

    @Override
    public void initialize(Map<String, Object> headers) {
        Map<String, Object> value = new HashMap<>(headers);
        value.put(MessageConstants.ASSET_TYPE, "CCOM");
        this.headers.set(value);
        this.entitiesTypeMap.set(new HashMap<>());
    }

    @Override
    public void setBatchSize(int size) {
        /*
        commenting the following line because, tasks with null as parent was created in the
        postgres database which lead to rows with "Not Found" as file name in the UI-ingestion logs page"
         */
        //sendBatch();
        this.batchSize.set(size);
    }

    @Override
    @SuppressWarnings("PMD.ConfusingTernary")
    public void sendEntity(Entity entity, String rootNode) {
        String entityId = null;
        String entityClass = null;

        if (entity != null) {
            entityClass = entity.getClass().getSimpleName();
            if (entity instanceof MeasurementLocation) {
                //Tag Associations are batched based on their monitoredEntity sourceKey
                MonitoredEntity monitoredEntity = ((MeasurementLocation) entity).getMonitoredEntity();
                entityClass = entityClass + "/" + monitoredEntity.getClass().getSimpleName() + "/" + monitoredEntity
                    .getGUID().getValue();
            }
            if (entity.getTag() != null && !"".equals(entity.getTag().getValue())) {
                entityId = entity.getTag().getValue();
            } else if (entity.getName() != null) {
                entityId = entity.getName().getValue();
            }
        }

        if (rootNode.equals(CONNECTIONS)) {
            this.connectionList.get().add(entity);
            sendConnections(false);
        } else {
            List<Entity> entityList = entitiesTypeMap.get().getOrDefault(entityClass, new ArrayList<>());
            entityList.add(entity);
            entitiesTypeMap.get().put(entityClass, entityList);
            if (log.isTraceEnabled()) {
                log.trace("[sendEntity] {}: class={}, id/name={}, count={}", rootNode, entityClass, entityId,
                    entityList.size());
            }
        }

        sendBatchInternal(false, rootNode);
    }

    @Override
    public void sendBatch(String rootNode) {
        sendBatchInternal(true, rootNode);
    }

    private void sendBatchInternal(boolean forceSend, String rootNode) {
        entitiesTypeMap.get().forEach((entityClass, entityList) -> {
            if (entityList.size() > 0 && (forceSend || entityList.size() >= batchSize.get())) {
                List<Entity> toSend = new ArrayList<>();
                if (entityList.size() > batchSize.get()) {
                    toSend.addAll(entityList.subList(0, batchSize.get()));
                    entityList.removeAll(toSend);
                } else {
                    toSend.addAll(entityList);
                    entityList.clear();
                }
                if (log.isDebugEnabled()) {
                    log.debug("[SENDING_BATCH] : class={}, count={}", entityClass, toSend.size());
                }

                Map<String, Object> headers = new HashMap<>(this.headers.get());
                headers.put(RabbitMQConstants.DELIVERY_MODE, rabbitmqDeliveryMode);
                headers.put(MessageConstants.COMPLETION_COUNT, toSend.size());
                headers.put(MessageConstants.TASK_ENTITY_TOTAL, toSend.size());
                String taskType = toSend.get(0).getClass().getSimpleName();
                if (rootNode.equals(CONNECTIONS)) {
                    taskType += CONNECTIONS;
                }
                String taskTypeLabel = typeToLabelMap.get(taskType);
                if (taskTypeLabel == null) {
                    taskTypeLabel = "Not Found";
                }
                headers.put(MessageConstants.TASK_ENTITY_TYPE, taskTypeLabel);
                headers.put(MessageConstants.ASSET_DETAIL, rootNode + " (" + toSend.size() + ")");

                dispatchBatch(headers, toSend, entityClass);
                sendBatchInternal(forceSend, rootNode);
            }
        });
    }

    public void forceSendConnections() {
        sendConnections(true);
    }

    public void flushConnections() {
        if (connectionBatchSize != 0) {
            forceSendConnections();
        }
    }

    public void sendConnections(boolean forceSend) {
        List<Entity> connectionsToSend = new ArrayList<>();
        connectionsToSend.addAll(this.connectionList.get());
        if (connectionsToSend.size() != 0 && (connectionsToSend.size() == connectionBatchSize || forceSend)) {
            try {
                Map<String, Object> headers = new HashMap<>(this.headers.get());
                headers.put(RabbitMQConstants.DELIVERY_MODE, rabbitmqDeliveryMode);
                headers.put(MessageConstants.COMPLETION_COUNT, connectionsToSend.size());
                headers.put(MessageConstants.TASK_ENTITY_TOTAL, connectionsToSend.size());
                String taskType = CONNECTIONS;
                String taskTypeLabel = typeToLabelMap.get(taskType);
                if (taskTypeLabel == null) {
                    taskTypeLabel = "Not Found";
                }
                headers.put(MessageConstants.TASK_ENTITY_TYPE, taskTypeLabel);
                headers.put(MessageConstants.ASSET_DETAIL, CONNECTIONS + " (" + connectionsToSend.size() + ")");

                dispatchBatch(headers, connectionsToSend, taskType);
            } finally {
                this.connectionList.get().clear();
            }
        }
    }

    public void initializeConnections() {
        this.connectionList.set(new ArrayList<Entity>());
    }

    private void dispatchBatch(Map<String, Object> headers, List<Entity> toSend, String entityClass) {
        //If TENANT_UUID is missing in the headers throw error back.
        if (!headers.containsKey(MessageConstants.TENANT_UUID)) {
            throw new IllegalStateException("Tenant not found");
        }
        headers.put(MessageConstants.BATCH_OBJECT_CHECKSUM, generateObjectChecksum(toSend, entityClass));
        //By default we don't want to skip transformation, the taskProcessor will decide if it should be skipped.
        headers.put(MessageConstants.SKIP_BATCH_TRANSFORMATION, false);
        dataProducer.sendBodyAndHeaders(toSend, headers);
    }

    private String generateObjectChecksum(List<Entity> entities, String entityClass) {
        String objectChecksum = ChecksumUtil.generateHash(entityClass + "/" + entities.stream().map(entity -> {
            String entityIdentifier;
            if (entity.getGUID() != null) {
                entityIdentifier = entity.getGUID().getValue();
            } else if (entity.getTag() != null && !"".equals(entity.getTag().getValue())) {
                entityIdentifier = entity.getTag().getValue();
            } else if (entity.getName() != null) {
                entityIdentifier = entity.getName().getValue();
            } else {
                log.warn("Unable to acquire unique identifier for entity, defaulting to toString!");
                entityIdentifier = entity.toString();
            }
            return entityIdentifier + entity.getClass().getSimpleName();
        }).collect(Collectors.joining("/")));
        log.debug("objectChecksum: " + objectChecksum);
        return objectChecksum;
    }
}
