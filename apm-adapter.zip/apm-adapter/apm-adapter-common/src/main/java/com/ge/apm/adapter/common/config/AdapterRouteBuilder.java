/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.config;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.camel.model.DataFormatDefinition;
import org.apache.camel.model.dataformat.JaxbDataFormat;
import org.apache.camel.model.dataformat.ZipFileDataFormat;
import org.apache.camel.processor.interceptor.Tracer;

import com.ge.apm.adapter.common.processor.RestResponseProcessor;
import com.ge.asset.commons.mq.config.BaseRouteBuilder;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.mq.processor.ExceptionProcessor;
import com.ge.asset.commons.mq.util.CryptoHelper;

@SuppressWarnings("PMD.TooManyMethods")
public abstract class AdapterRouteBuilder extends BaseRouteBuilder {

    protected final DataFormatDefinition jaxbDataFormat;

    protected final DataFormatDefinition zipFileDataFormat;

    protected AdapterRouteBuilder(String adapterId, CryptoHelper cryptoHelper) {
        super(adapterId, cryptoHelper);
        JaxbDataFormat jaxb = new JaxbDataFormat();
        jaxb.setContextPath("com.ge.apm.bod.model:com.ge.apm.ccom.model:com.ge.apm.ccom.model.custom");
        jaxb.setPrettyPrint(false);
        jaxbDataFormat = jaxb;

        ZipFileDataFormat zipFile = new ZipFileDataFormat();
        zipFile.setUsingIterator(true);
        zipFileDataFormat = zipFile;
    }

    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void configure() throws Exception {
        ((Tracer) getContext().getDefaultTracer()).getDefaultTraceFormatter().setShowHeaders(false);
        ((Tracer) getContext().getDefaultTracer()).getDefaultTraceFormatter().setShowOutHeaders(false);
        ((Tracer) getContext().getDefaultTracer()).getDefaultTraceFormatter().setShowBody(false);

        getContext().setErrorHandlerBuilder(defaultErrorHandler().logExhaustedMessageHistory(false));

        final ConcurrentLinkedQueue<Error> errors = new ConcurrentLinkedQueue<>();
        onException(Exception.class).process(new ExceptionProcessor(errors));
        from(getRestResponseEndpoint()).process(new RestResponseProcessor(errors));

        from(getEnrichEndpoint()).process(exchange -> exchange.getIn().setHeader(MessageConstants.ADAPTER_UUID, appId));
        super.configure();
    }

    public String getRestResponseEndpoint() {
        return String.format(AdapterRoutes.DIRECT_REST_RESPONSE, appId);
    }

    protected String getEnrichEndpoint() {
        return String.format(AdapterRoutes.DIRECT_ENRICH, appId);
    }

    protected String getEnrichDownloadEndpoint() {
        return String.format(AdapterRoutes.DIRECT_ENRICH_DOWNLOAD, appId);
    }

    protected String createEntities() {
        return "createEntities";
    }

    protected String queueTask() {
        return "queueTask";
    }

    protected String fetchTask() {
        return "fetchTask";
    }

    protected String transformTask() {
        return "transformTask";
    }

    protected String requeueTask() {
        return "requeueTask";
    }

    protected String markInProgressTask() {
        return "markInProgress";
    }

    protected String inProgressTask() {
        return "inProgressTask";
    }

    protected String markDoneProcessingTask() {
        return "markDoneProcessing";
    }

    protected String markCompletedTask() {
        return "markCompleted";
    }

    protected String markSkippedTask() {
        return "markSkipped";
    }

    protected String taskError() {
        return "taskError";
    }

    protected String createAndMarkTaskError() {
        return "createAndMarkTaskError";
    }

    protected String entityTransformer() {
        return "entityTransformer";
    }

    protected String transformEntities() {
        return "transformEntities";
    }

    protected String rabbitmqException() {
        return "rabbitmqException";
    }

    protected String postgresException() {
        return "postgresException";
    }

    protected String createResponse() {
        return "createResponse";
    }
}
