/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.packer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.apm.bod.model.ActionCodeEnumeration;
import com.ge.apm.bod.model.ActionCriteria;
import com.ge.apm.bod.model.ActionExpression;
import com.ge.apm.bod.model.BusinessObjectDocument;
import com.ge.apm.bod.model.DtoData;
import com.ge.apm.bod.model.noun.CcomPayload;
import com.ge.apm.bod.model.noun.DtoPayload;
import com.ge.apm.bod.model.util.BodFactory;
import com.ge.apm.bod.model.verb.Sync;
import com.ge.apm.ccom.model.CCOMData;
import com.ge.apm.ccom.model.core.Entity;

@Component
public class AssetPacker {

    @Autowired
    private BodFactory bodFactory;

    public BusinessObjectDocument createEntities(CCOMData entityData) {
        if (entityData == null) {
            return this.bodFactory.getBod();
        }

        Sync syncVerb = new Sync();
        ActionCriteria actionCriteria = new ActionCriteria();

        ActionExpression actionExpression = new ActionExpression();
        actionExpression.setActionCode(ActionCodeEnumeration.ADD);
        actionCriteria.getActionExpression().add(actionExpression);

        syncVerb.setActionCriteria(actionCriteria);

        BusinessObjectDocument bod = this.bodFactory.getBod();
        bod.getDataArea().setVerb(syncVerb);

        CcomPayload ccomPayload = new CcomPayload();
        ccomPayload.setCcomData(entityData);
        bod.getDataArea().setNoun(ccomPayload);

        return bod;
    }

    public BusinessObjectDocument createEntities(List<Entity> entityData) {
        if (entityData == null) {
            return this.bodFactory.getBod();
        }

        CCOMData ccomData = new CCOMData();
        ccomData.getEntity().addAll(entityData);
        return createEntities(ccomData);
    }

    public BusinessObjectDocument createEntities(DtoData dtoData) {
        if (dtoData == null) {
            return this.bodFactory.getBod();
        }

        Sync syncVerb = new Sync();
        ActionCriteria actionCriteria = new ActionCriteria();

        ActionExpression actionExpression = new ActionExpression();
        actionExpression.setActionCode(ActionCodeEnumeration.ADD);
        actionCriteria.getActionExpression().add(actionExpression);

        syncVerb.setActionCriteria(actionCriteria);

        BusinessObjectDocument bod = this.bodFactory.getBod();
        bod.getDataArea().setVerb(syncVerb);

        DtoPayload dtoPayload = new DtoPayload();
        dtoPayload.setDtoData(dtoData);
        bod.getDataArea().setNoun(dtoPayload);

        return bod;
    }
}
