/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.io.IOException;
import java.io.InputStream;
import javax.activation.DataHandler;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class AttachmentProcessorTest {

    @Mock
    private Exchange exchange;

    @Mock
    private Message message;

    private AttachmentProcessor attachmentProcessor;

    @Before
    public void setup() {
        attachmentProcessor = new AttachmentProcessor();
        MockitoAnnotations.initMocks(this);

        Mockito.when(exchange.getIn()).thenReturn(message);
    }

    @Test
    public void attachmentNull() throws IOException {
        Mockito.when(message.getBody(eq(Attachment.class))).thenReturn(null);
        attachmentProcessor.process(exchange);
        verify(message).setBody(eq(null));
    }

    @Test
    public void attachment() throws IOException {
        Attachment attachment = mock(Attachment.class);
        Mockito.when(message.getBody(eq(Attachment.class))).thenReturn(attachment);

        DataHandler dataHandler = mock(DataHandler.class);
        doReturn(dataHandler).when(attachment).getDataHandler();
        InputStream inputStream = mock(InputStream.class);
        doReturn("Sample File").when(dataHandler).getName();
        doReturn(inputStream).when(dataHandler).getInputStream();

        attachmentProcessor.process(exchange);

        verify(message).setHeader(eq(Exchange.FILE_NAME), eq("Sample File"));
        verify(message).setBody(eq(inputStream));
    }
}
