/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.packer;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ge.apm.bod.model.BusinessObjectDocument;
import com.ge.apm.bod.model.DtoData;
import com.ge.apm.bod.model.noun.CcomPayload;
import com.ge.apm.bod.model.noun.ConfigPayload;
import com.ge.apm.bod.model.noun.DtoPayload;
import com.ge.apm.bod.model.util.BodFactory;
import com.ge.apm.bod.model.verb.Get;
import com.ge.apm.bod.model.verb.Sync;
import com.ge.apm.ccom.model.CCOMData;
import com.ge.apm.common.exception.ServiceException;

import static org.junit.Assert.fail;

public class AssetUnpackerTest {

    private AssetUnpacker assetUnpacker;

    private BodFactory bodFactory;

    @Before
    public void setup() {
        assetUnpacker = new AssetUnpacker();
        bodFactory = new BodFactory();
    }

    @Test(expected = ServiceException.class)
    public void createEntities_NotSync() {
        BusinessObjectDocument bod = bodFactory.getBod();
        bod.getDataArea().setVerb(new Get());
        assetUnpacker.createEntities(bod);
    }

    @Test
    public void createEntities_CcomPayload() {
        BusinessObjectDocument bod = bodFactory.getBod();
        bod.getDataArea().setVerb(new Sync());

        CcomPayload ccomPayload = new CcomPayload();
        CCOMData ccomData = new CCOMData();
        ccomPayload.setCcomData(ccomData);
        bod.getDataArea().setNoun(ccomPayload);

        Assert.assertEquals(ccomData.getEntity(), assetUnpacker.createEntities(bod));
    }

    @Test
    public void createEntities_CcomPayloadDataNull() {
        BusinessObjectDocument bod = bodFactory.getBod();
        bod.getDataArea().setVerb(new Sync());

        CcomPayload ccomPayload = new CcomPayload();
        ccomPayload.setCcomData(null);
        bod.getDataArea().setNoun(ccomPayload);
        assetUnpacker.createEntities(bod);
        Assert.assertNotNull(bod);
    }

    @Test
    public void createEntities_DtoPayload() {
        BusinessObjectDocument bod = bodFactory.getBod();
        bod.getDataArea().setVerb(new Sync());

        DtoPayload dtoPayload = new DtoPayload();
        DtoData dtoData = new DtoData();
        dtoPayload.setDtoData(dtoData);
        bod.getDataArea().setNoun(dtoPayload);

        Assert.assertEquals(dtoData.getDto(), assetUnpacker.createEntities(bod));
    }

    @Test
    public void createEntities_DtoPayloadNullData() {
        BusinessObjectDocument bod = bodFactory.getBod();
        bod.getDataArea().setVerb(new Sync());

        DtoPayload dtoPayload = new DtoPayload();
        dtoPayload.setDtoData(null);
        bod.getDataArea().setNoun(dtoPayload);
        assetUnpacker.createEntities(bod);
        Assert.assertNotNull(bod);
    }

    @Test
    public void createEntities_UnexpectedPayload() {
        BusinessObjectDocument bod = bodFactory.getBod();
        bod.getDataArea().setVerb(new Sync());
        bod.getDataArea().setNoun(new ConfigPayload());
        try {
            assetUnpacker.createEntities(bod);
            fail("Should Throw ServiceException");
        } catch (ServiceException exc) {
            Assert.assertNotNull(bod);
        } catch (Exception exc) {
            fail(exc.getLocalizedMessage());
            exc.printStackTrace();
        }
    }
}
