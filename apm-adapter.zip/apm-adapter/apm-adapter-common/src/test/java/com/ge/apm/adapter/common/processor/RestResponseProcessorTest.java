/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.impl.DefaultMessage;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.ge.apm.adapter.domain.persistence.entity.Task;

/**
 * Description of ResponseProcessorTest
 *
 * @author Deepak 212400139
 * @version 1.1 Mar 8, 2016
 * @since 1.0
 */

public class RestResponseProcessorTest {

    public ConcurrentLinkedQueue<java.lang.Error> testErrors;

    public Error testError;

    public Exchange e;

    public Message msgIn;

    public Message msgOut;

    public Task task;

    public Map<String, Object> testMapIn;

    @Before
    public void setUp() throws Exception {
        testErrors = new ConcurrentLinkedQueue<java.lang.Error>();
        testError = new Error("Test Error");
        e = Mockito.mock(Exchange.class);
        msgIn = new DefaultMessage();
        msgOut = new DefaultMessage();
        Mockito.when(e.getIn()).thenReturn(msgIn);
        Mockito.when(e.getOut()).thenReturn(msgOut);
        testMapIn = new HashMap<String, Object>();
        testMapIn.put("APM Test Header", "Test Header");
        msgIn.setHeaders(testMapIn);
    }

    @Test
    public void testProcessWithNoErrors() {
        try {
            RestResponseProcessor testRestResponseProcessor = new RestResponseProcessor(testErrors);
            testRestResponseProcessor.process(e);
            Assert.assertNotNull(msgOut.getBody());
            Assert.assertEquals(msgOut.getHeaders(), testMapIn);
        } catch (Exception e) {
            Assert.fail(e.getLocalizedMessage());
            e.printStackTrace();
        }
    }

    @Test
    public void testProcessWithErrors() {
        try {
            testErrors.add(testError);
            RestResponseProcessor testRestResponseProcessor = new RestResponseProcessor(testErrors);
            testRestResponseProcessor.process(e);
            Assert.assertNotNull(msgOut.getBody());
            Assert.assertEquals(msgOut.getHeaders(), testMapIn);
        } catch (Exception e) {
            Assert.fail(e.getLocalizedMessage());
            e.printStackTrace();
        }
    }

    @After
    public void destroy() {
        e = null;
        msgIn = null;
        msgOut = null;
        task = null;
        testError = null;
        testErrors = null;
        testMapIn = null;
    }
}

