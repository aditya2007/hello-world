/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.apm.adapter.common.constants.TaskStatus;
import com.ge.apm.adapter.domain.persistence.entity.Task;
import com.ge.apm.adapter.domain.persistence.repository.IFileChecksumRepository;
import com.ge.apm.adapter.domain.persistence.repository.IIngestionLogMsgRepository;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.apm.asset.model.DownloadTask;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.google.gson.JsonObject;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;

import java.io.IOException;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

public class DownloadTaskProcessorTest {

    @InjectMocks
    @Autowired
    DownloadTaskProcessor dtp;

    @Mock
    private Exchange exchange;

    @Mock
    private Message message;

    @Mock
    private ITaskProcessorRepository taskProcessorRepository;

    @Mock
    private EntityManager entityManager;

    private Task task;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        when(exchange.getIn()).thenReturn(message);

        when(message.getHeader(MessageConstants.TENANT_UUID, String.class)).thenReturn("Tenant uuid");
        when(message.getHeader(MessageConstants.DESCRIPTION, null, String.class)).thenReturn("Test Description");
        when(message.getHeader(MessageConstants.TASK_ENTITY_TOTAL, 0, Long.class)).thenReturn(new Long(0));

        task = new Task();
        task.setId(new Long(1));
        task.setDescription("ParentTask");
        task.setStatus(TaskStatus.QUEUED);

        when(entityManager.find(Task.class, task.getId(), LockModeType.PESSIMISTIC_WRITE)).thenReturn(task);
    }

    @Test
    public void testQueueTask() throws IllegalAccessException {
        when(message.getHeader(MessageConstants.TASK_UUID, null, String.class)).thenReturn("Task uuid");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
                task);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());
        when(entityManager.find(any(), any())).thenReturn(task);
        dtp.queueTask(exchange);
        Assert.assertNotNull(task);
        Assert.assertNotNull(dtp);
    }

    @Test
    public void testInProgressTask() throws IllegalAccessException {
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
                task);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());
        when(entityManager.find(any(), any())).thenReturn(task);
        dtp.inProgressTask(exchange);
        Assert.assertNotNull(task);
        Assert.assertNotNull(dtp);
    }

    @Test
    public void testFetchTask() throws IllegalAccessException {
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("Task uuid");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
                task);
        dtp.fetchTask(exchange);
        Assert.assertNotNull(task);
        Assert.assertNotNull(dtp);
    }

    @Test
    public void testMarkCompletedWithoutError() throws IllegalAccessException {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("title", "album1");

        DownloadTask downloadTask = new DownloadTask();
        downloadTask.setTaskUuid(task.getUuid());
        downloadTask.setTaskResponse(jsonObject);

        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("1");
        when(message.getBody()).thenReturn(downloadTask);
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(task);

        dtp.markCompleted(exchange);
        Assert.assertEquals(TaskStatus.COMPLETED, task.getStatus());
    }

}
