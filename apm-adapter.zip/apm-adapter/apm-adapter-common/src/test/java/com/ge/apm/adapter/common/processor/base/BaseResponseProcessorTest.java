/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor.base;

import org.apache.camel.Exchange;
import org.junit.Assert;
import org.junit.Test;

import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.mq.model.Error;
import com.ge.asset.commons.mq.processor.base.BaseResponseProcessor;

/**
 * Unit test for {@link BaseResponseProcessor}.
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Mar 2, 2016
 * @since 1.0
 */
public class BaseResponseProcessorTest {

    @Test
    public void updateResponse_isServiceException() {
        BaseResponseProcessor brp = new BaseResponseProcessor() {
            @Override
            public void process(Exchange exchange) {
                throw new UnsupportedOperationException();
            }
        };

        ServiceException cause = new ServiceException("serviceExceptionErrorCode", "serviceExceptionErrorMessage",
            new Exception());
        java.lang.Error error = new java.lang.Error("javaLangError", cause);
        Error response = new Error("", "", new Exception());

        brp.updateResponse(error, response);
        Assert.assertEquals(cause.getCode(), response.getErrorCode());
        Assert.assertEquals(cause.getMessage(), response.getErrorMessage());
        Assert.assertEquals(cause.getCause(), response.getCause());
    }

    @Test
    public void updateResponse_isOtherException() {
        BaseResponseProcessor brp = new BaseResponseProcessor() {
            @Override
            public void process(Exchange exchange) {
                throw new UnsupportedOperationException();
            }
        };

        Exception cause = new Exception("serviceExceptionErrorMessage", new Exception());
        java.lang.Error error = new java.lang.Error("javaLangError", cause);
        Error response = new Error("", "", new Exception());

        brp.updateResponse(error, response);
        Assert.assertEquals(error.getMessage(), response.getErrorMessage());
        Assert.assertEquals(error.getCause(), response.getCause());
    }
}
