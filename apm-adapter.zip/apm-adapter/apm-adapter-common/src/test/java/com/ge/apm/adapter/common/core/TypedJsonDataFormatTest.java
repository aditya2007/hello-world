/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.core;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Type;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonSerializationContext;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ge.apm.bod.model.ActionCodeEnumeration;
import com.ge.apm.bod.model.ActionExpression;
import com.ge.asset.commons.mq.core.TypedJsonDataFormat;
import com.ge.asset.commons.mq.util.TypedJsonSerializableAdapter;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;

/**
 * Description of TypedJsonDataFormatTest
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Mar 2, 2016
 * @since 1.0
 */
public class TypedJsonDataFormatTest {

    private final TypedJsonDataFormat format = new TypedJsonDataFormat();

    private JsonSerializationContext serializationCtx = null;

    private TypedJsonSerializableAdapter adapter = null;

    @Before
    public void setup() {
        final Gson gson = new Gson();
        serializationCtx = new JsonSerializationContext() {
            @Override
            public JsonElement serialize(Object src) {
                return gson.toJsonTree(src);
            }

            @Override
            public JsonElement serialize(Object src, Type typeOfSrc) {
                return gson.toJsonTree(src, typeOfSrc);
            }
        };

        adapter = new TypedJsonSerializableAdapter();
    }

    @Test
    public void marshall() throws IOException {
        // TODO: validate with an ByteArrayOutputStream
        format.marshal(null, new Object(), mock(OutputStream.class));
    }

    @Test
    public void marshallWithError() {
        try {
            format.marshal(null, new Object(), null);
            fail("Should Throw an Exception");
        } catch (Exception exc) {
            Assert.assertNotNull(format);
        }
    }

    @Test
    public void unmarshal() throws IOException {
        ActionExpression expression = new ActionExpression();
        expression.setValue("test");
        expression.setActionCode(ActionCodeEnumeration.ADD);
        JsonElement data = adapter.serialize(expression, null, serializationCtx);
        Object rslt = format.unmarshal(null, new ByteArrayInputStream(data.toString().getBytes("UTF-8")));
        Assert.assertTrue(rslt instanceof ActionExpression);
    }

    @Test
    public void unmarshalWithError() {
        try {
            format.unmarshal(null, null);
            fail("Should Throw an Exception");
        } catch (Exception exc) {
            Assert.assertNotNull(format);
        }
    }
}
