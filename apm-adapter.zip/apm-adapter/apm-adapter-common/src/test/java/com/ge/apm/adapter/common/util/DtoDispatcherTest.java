/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.util;

import java.util.HashMap;
import java.util.Map;

import com.google.common.collect.ImmutableMap;
import org.apache.camel.ProducerTemplate;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.ge.apm.asset.model.Enterprise;
import com.ge.asset.commons.mq.constants.MessageConstants;

import static org.mockito.Matchers.anyMapOf;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;

/**
 * Unit test for {@link DtoDispatcher}.
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Mar 1, 2016
 * @since 1.0
 */
public class DtoDispatcherTest {

    @InjectMocks
    private final DtoDispatcher dispatcher = new DtoDispatcher();

    @Mock
    private ProducerTemplate dataProducer;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        Map<String, String> headers = ImmutableMap.of("test", "unit test");
        dispatcher.initialize(headers);
        doNothing().when(this.dataProducer).sendBodyAndHeaders(anyObject(), anyMapOf(String.class, Object.class));
    }

    @Test
    public void initialize() {
        Assert.assertEquals("DTO", dispatcher.getHeaders().get(MessageConstants.ASSET_TYPE));
    }

    @Test
    public void testResetOnInitialize() {
        Map<String, String> headers = ImmutableMap.of("test", "unit test");
        dispatcher.initialize(headers);
        Assert.assertEquals("DTO", dispatcher.getHeaders().get(MessageConstants.ASSET_TYPE));
        Assert.assertEquals("unit test", dispatcher.getHeaders().get("test"));
        dispatcher.initialize(new HashMap<>());
        Assert.assertNull(dispatcher.getHeaders().get("test"));
    }

    @Test
    public void sendDtos() {
        Enterprise enterprise = new Enterprise();
        enterprise.setName("unitTestEnterprise");
        Enterprise enterprise2 = new Enterprise();
        enterprise2.setName("unitTestEnterprise2");
        Enterprise[] dtos = new Enterprise[] { enterprise, enterprise2 };
        dispatcher.sendDtos(dtos);
        Mockito.verify(dataProducer, times(1)).sendBodyAndHeaders(eq(dtos), anyMapOf(String.class, Object.class));
    }
}
