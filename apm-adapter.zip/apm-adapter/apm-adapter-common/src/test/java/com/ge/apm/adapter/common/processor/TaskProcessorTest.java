/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.persistence.EntityManager;
import javax.persistence.LockModeType;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.apm.adapter.common.constants.TaskStatus;
import com.ge.apm.adapter.domain.persistence.entity.Task;
import com.ge.apm.adapter.domain.persistence.repository.IFileChecksumRepository;
import com.ge.apm.adapter.domain.persistence.repository.IIngestionLogMsgRepository;
import com.ge.apm.adapter.domain.persistence.repository.ITaskProcessorRepository;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;
import com.ge.asset.commons.mq.constants.MessageConstants;
import com.ge.asset.commons.validator.Error;
import com.ge.asset.commons.validator.ValidationFailedException;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

/**
 * Description of TaskProcessorTest
 *
 * @author Deepak 212400139
 * @version 1.0 Mar 8, 2016
 * @since 1.0
 */

@SuppressWarnings("PMD.TooManyMethods")
public class TaskProcessorTest {

    @InjectMocks
    @Autowired
    UploadTaskProcessor tp;

    @Mock
    private Exchange exchange;

    @Mock
    private Message message;

    @Mock
    private ITaskProcessorRepository taskProcessorRepository;

    @Mock
    private IIngestionLogMsgRepository ingestionLogMsgRepository;

    @Mock
    private IFileChecksumRepository fileChecksumRepository;

    @Mock
    private EntityManager entityManager;

    private Task parentTask;

    private Task parentTaskDone;

    private Task grandParentTask;

    private Task grandParentTaskDone;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        when(exchange.getIn()).thenReturn(message);

        when(message.getHeader(MessageConstants.TENANT_UUID, String.class)).thenReturn("Tenant uuid");
        when(message.getHeader(MessageConstants.DESCRIPTION, null, String.class)).thenReturn("Test Description");
        when(message.getHeader(MessageConstants.TASK_ENTITY_TOTAL, 0, Long.class)).thenReturn(new Long(0));

        parentTask = new Task();
        parentTask.setId(new Long(1));
        parentTask.setDescription("ParentTask");
        parentTask.setStatus(TaskStatus.QUEUED);
        grandParentTask = new Task();
        grandParentTask.setId(new Long(2));
        grandParentTask.setStatus(TaskStatus.QUEUED);
        grandParentTask.setDescription("GrandParentTask");
        grandParentTask.setUuid("grandParentTask");
        parentTask.setParent(grandParentTask);

        parentTaskDone = new Task();
        parentTaskDone.setId(new Long(3));
        parentTaskDone.setDescription("ParentTaskDone");
        parentTaskDone.setStatus(TaskStatus.DONE_PROCESSING);
        grandParentTaskDone = new Task();
        grandParentTaskDone.setId(new Long(4));
        grandParentTaskDone.setStatus(TaskStatus.DONE_PROCESSING);
        grandParentTaskDone.setDescription("GrandParentTaskDone");
        grandParentTaskDone.setUuid("grandParentTaskDone");
        parentTaskDone.setParent(grandParentTaskDone);

        when(entityManager.find(Task.class, parentTask.getId(), LockModeType.PESSIMISTIC_WRITE)).thenReturn(parentTask);
        when(entityManager.find(Task.class, grandParentTask.getId(), LockModeType.PESSIMISTIC_WRITE)).thenReturn(
            grandParentTask);
    }

    @Test
    public void testUpdateTotalAndCompletedCounts() {
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid("abcd");
        rootTask1.setId(100L);
        rootTask1.setCompletedCount(0L);
        rootTask1.setTotalCount(0L);
        rootTask1.setStatus(TaskStatus.IN_PROGRESS);
        rootTask1.setUuid(UUID.randomUUID().toString());
        List<Task> jsonTasks = new ArrayList<>();
        Task jsonTask1 = new Task();
        jsonTask1.setId(110L);
        jsonTask1.setUuid(UUID.randomUUID().toString());
        jsonTask1.setParent(rootTask1);
        Task jsonTask2 = new Task();
        jsonTask2.setId(120L);
        jsonTask2.setUuid(UUID.randomUUID().toString());
        jsonTask2.setParent(rootTask1);
        jsonTasks.add(jsonTask1);
        jsonTasks.add(jsonTask2);
        List<Task> childrenTasks = new ArrayList<>();
        Task childrenTask1 = new Task();
        childrenTask1.setId(111L);
        childrenTask1.setParent(jsonTask1);
        childrenTask1.setCompletedCount(1000L);
        childrenTask1.setTotalCount(2000L);
        Task childrenTask2 = new Task();
        childrenTask2.setId(112L);
        childrenTask2.setParent(jsonTask1);
        childrenTask2.setCompletedCount(3000L);
        childrenTask2.setTotalCount(4000L);
        Task childrenTask3 = new Task();
        childrenTask3.setId(121L);
        childrenTask3.setParent(jsonTask2);
        childrenTask3.setCompletedCount(5000L);
        childrenTask3.setTotalCount(6000L);
        Task childrenTask4 = new Task();
        childrenTask4.setId(122L);
        childrenTask4.setParent(jsonTask2);
        childrenTask4.setCompletedCount(7000L);
        childrenTask4.setTotalCount(8000L);
        childrenTasks.add(childrenTask1);
        childrenTasks.add(childrenTask2);
        childrenTasks.add(childrenTask3);
        childrenTasks.add(childrenTask4);
        when(taskProcessorRepository.findChildren(rootTask1.getTenantUuid(), rootTask1.getUuid())).thenReturn(
            jsonTasks);
        Object[][] result = { { 16000L, 20000L } };
        List<Long> jsonTaskIds = new ArrayList<>();
        jsonTaskIds.add(jsonTask1.getId());
        jsonTaskIds.add(jsonTask2.getId());
        when(
            taskProcessorRepository.findTotalCompletedCountBasedOnJsonParentIds(rootTask1.getTenantUuid(), jsonTaskIds))
            .thenReturn(result);
        List<Task> jsonTask1Children = new ArrayList<>();
        jsonTask1Children.add(childrenTask1);
        jsonTask1Children.add(childrenTask2);
        List<Task> jsonTask2Children = new ArrayList<>();
        jsonTask2Children.add(childrenTask3);
        jsonTask2Children.add(childrenTask4);
        when(taskProcessorRepository.findChildrenIncludeArchived(rootTask1.getTenantUuid(), jsonTask1.getUuid()))
            .thenReturn(jsonTask1Children);
        when(taskProcessorRepository.findChildrenIncludeArchived(rootTask1.getTenantUuid(), jsonTask2.getUuid()))
            .thenReturn(jsonTask2Children);
        when(taskProcessorRepository.save(jsonTasks)).thenReturn(null);
        tp.updateTotalAndCompletedCounts(rootTask1);
    }

    @Test
    public void testUpdateTotalAndCompletedCounts_jsonTasksAreNull() {
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid("abcd");
        rootTask1.setId(100L);
        rootTask1.setCompletedCount(0L);
        rootTask1.setTotalCount(0L);
        rootTask1.setStatus(TaskStatus.IN_PROGRESS);
        rootTask1.setUuid(UUID.randomUUID().toString());
        when(taskProcessorRepository.findChildren(rootTask1.getTenantUuid(), rootTask1.getUuid())).thenReturn(null);
        tp.updateTotalAndCompletedCounts(rootTask1);
    }

    @Test
    public void testUpdateTotalAndCompletedCounts_jsonTasksAreEmpty() {
        Task rootTask1 = new Task();
        rootTask1.setParent(null);
        rootTask1.setTenantUuid("abcd");
        rootTask1.setId(100L);
        rootTask1.setCompletedCount(0L);
        rootTask1.setTotalCount(0L);
        rootTask1.setStatus(TaskStatus.IN_PROGRESS);
        rootTask1.setUuid(UUID.randomUUID().toString());
        List<Task> jsonTasks = new ArrayList<>();
        when(taskProcessorRepository.findChildren(rootTask1.getTenantUuid(), rootTask1.getUuid())).thenReturn(
            jsonTasks);
        tp.updateTotalAndCompletedCounts(rootTask1);
    }

    @Test
    public void testQueueTask() throws IllegalAccessException {
        when(message.getHeader(MessageConstants.TASK_UUID, null, String.class)).thenReturn("Task uuid");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
            parentTask);
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), eq(grandParentTask.getUuid())))
            .thenReturn(grandParentTask);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());
        when(entityManager.find(any(), any())).thenReturn(parentTask);
        tp.queueTask(exchange);
        Assert.assertNotNull(parentTask);
        Assert.assertNotNull(tp);
    }

    @Test
    public void testInProgressTask() throws IllegalAccessException {
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
            parentTask);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());
        when(entityManager.find(any(), any())).thenReturn(parentTask);
        tp.inProgressTask(exchange);
        Assert.assertNotNull(parentTask);
        Assert.assertNotNull(tp);
    }

    @Test
    public void testFetchTask() throws IllegalAccessException {
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("Task uuid");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
            parentTask);
        tp.fetchTask(exchange);
        Assert.assertNotNull(parentTask);
        Assert.assertNotNull(tp);
    }

    @Test
    public void testMarkInProgressWhenQueued() throws IllegalAccessException {
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("Task uuid");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
            parentTask);
        parentTask.setStatus(TaskStatus.QUEUED);
        tp.markInProgress(exchange);
        Assert.assertNotNull(parentTask);
        Assert.assertEquals(TaskStatus.IN_PROGRESS, parentTask.getStatus());
        Assert.assertNotNull(tp);
    }

    @Test
    public void testMarkCompletedWithoutError() throws IllegalAccessException {
        parentTask.setUuid("1");
        parentTask.setId(1L);
        grandParentTask.setUuid("2");
        grandParentTask.setId(2L);
        Task childTask = new Task();
        childTask.setUuid("0");
        childTask.setParent(parentTask);
        childTask.setStatus(TaskStatus.IN_PROGRESS);
        childTask.setTotalCount(3L);
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("0");
        when(message.getHeader(MessageConstants.TASK_ENTITY_COMPLETE, 0, Long.class)).thenReturn(3L);
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq(childTask.getUuid())))
            .thenReturn(childTask);
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq(parentTask.getUuid())))
            .thenReturn(parentTask);
        when(
            taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq(grandParentTask.getUuid())))
            .thenReturn(grandParentTask);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());
        when(taskProcessorRepository.findOne(Mockito.eq(parentTask.getId()))).thenReturn(parentTask);
        when(taskProcessorRepository.findOne(Mockito.eq(grandParentTask.getId()))).thenReturn(grandParentTask);
        when(taskProcessorRepository
            .findCountOfChildrenInStatus(grandParentTask.getId(), TaskStatus.IN_PROGRESS, TaskStatus.QUEUED,
                TaskStatus.DONE_PROCESSING)).thenReturn(0);
        when(taskProcessorRepository
            .findCountOfChildrenInStatus(parentTask.getId(), TaskStatus.IN_PROGRESS, TaskStatus.QUEUED,
                TaskStatus.DONE_PROCESSING)).thenReturn(0);
        when(taskProcessorRepository.findCountOfChildrenInError(grandParentTask.getId(), TaskStatus.ERROR + "%"))
            .thenReturn(0);
        Long[][] result = new Long[1][2];
        result[0][0] = 1L;
        result[0][1] = 2L;
        when(taskProcessorRepository
            .findTotalCompletedCountBasedOnJsonParentIds(Mockito.anyObject(), Mockito.anyObject())).thenReturn(result);

        parentTask.setStatus(TaskStatus.DONE_PROCESSING);
        grandParentTask.setStatus(TaskStatus.DONE_PROCESSING);
        tp.markCompleted(exchange);
        Assert.assertEquals(TaskStatus.ARCHIVED, childTask.getStatus());
        Assert.assertEquals(TaskStatus.COMPLETED, parentTask.getStatus());
        Assert.assertEquals(TaskStatus.COMPLETED, grandParentTask.getStatus());
    }

    @Test
    public void testMarkCompletedWithError() throws IllegalAccessException {
        parentTask.setUuid("1");
        grandParentTask.setUuid("0");
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("Task uuid");
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("1");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq(parentTask.getUuid())))
            .thenReturn(parentTask);
        when(
            taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq(grandParentTask.getUuid())))
            .thenReturn(grandParentTask);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());
        when(taskProcessorRepository
            .findCountOfChildrenInStatus(grandParentTask.getId(), TaskStatus.IN_PROGRESS, TaskStatus.QUEUED,
                TaskStatus.DONE_PROCESSING)).thenReturn(0);
        when(taskProcessorRepository.findCountOfChildrenInError(grandParentTask.getId(), TaskStatus.ERROR + "%"))
            .thenReturn(1);
        when(taskProcessorRepository.findOne(Mockito.anyLong())).thenReturn(grandParentTask);
        Long[][] result = new Long[1][2];
        result[0][0] = 1L;
        result[0][1] = 2L;
        when(taskProcessorRepository
            .findTotalCompletedCountBasedOnJsonParentIds(Mockito.anyObject(), Mockito.anyObject())).thenReturn(result);
        parentTask.setStatus(TaskStatus.ERROR);
        tp.markCompleted(exchange);
        Assert.assertEquals(TaskStatus.ERROR, parentTask.getStatus());
    }

    @Test
    public void testMarkDoneProcessingWithParentAndNoChild() throws IllegalAccessException {
        Task task = new Task();
        task.setStatus(TaskStatus.IN_PROGRESS);
        task.setId(new Long(1));
        task.setParent(parentTask);
        Task grandParent = new Task();
        grandParent.setDescription("Grand Parent");
        grandParent.setId(new Long(3));
        parentTask.setParent(grandParent);
        parentTask.setId(new Long(2));

        parentTask.setStatus(TaskStatus.IN_PROGRESS);
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("Task uuid");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
            task);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());
        when(taskProcessorRepository.findOne(Mockito.anyLong())).thenReturn(parentTask);

        when(entityManager.find(Task.class, task.getId(), LockModeType.PESSIMISTIC_WRITE)).thenReturn(task);
        when(entityManager.find(Task.class, parentTask.getId(), LockModeType.PESSIMISTIC_WRITE)).thenReturn(parentTask);
        when(entityManager.find(Task.class, grandParentTask.getId(), LockModeType.PESSIMISTIC_WRITE)).thenReturn(
            grandParentTask);

        tp.markDoneProcessing(exchange);
        Assert.assertEquals(TaskStatus.DONE_PROCESSING, task.getStatus());
        //Assert.assertNotNull(parentTask.getUpdatedOn());
    }

    @Test
    public void testMarkDoneProcessingWithParentAndChild() throws IllegalAccessException {
        Task grandParent = new Task();
        grandParent.setDescription("Grand Parent");
        grandParent.setId(new Long(1));
        parentTask.setParent(grandParent);
        parentTask.setStatus(TaskStatus.IN_PROGRESS);
        List<Task> childTasks = new ArrayList<Task>();
        childTasks.add(grandParent);
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("Task uuid");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
            parentTask);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());
        when(taskProcessorRepository.findOne(Mockito.anyLong())).thenReturn(grandParent);
        when(taskProcessorRepository.findChildren(Mockito.anyString(), Mockito.anyString())).thenReturn(childTasks);

        tp.markDoneProcessing(exchange);
        Assert.assertEquals(TaskStatus.DONE_PROCESSING, parentTask.getStatus());
        Assert.assertNull(grandParent.getUpdatedOn());
    }

    @Test
    public void testMarkDoneProcessingWithParentAndError() throws IllegalAccessException {
        Task grandParent = new Task();
        grandParent.setDescription("Grand Parent");
        grandParent.setId(new Long(1));
        parentTask.setParent(grandParent);
        parentTask.setStatus(TaskStatus.IN_PROGRESS);
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("Task uuid");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
            parentTask);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());

        when(taskProcessorRepository.findOne(Mockito.anyLong())).thenReturn(parentTask);

        tp.markDoneProcessing(exchange);
        Assert.assertEquals(TaskStatus.DONE_PROCESSING, parentTask.getStatus());
        Assert.assertNull(grandParent.getUpdatedOn());
    }

    @Test
    public void testTaskError() throws IllegalAccessException {
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("Task uuid");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
            parentTask);
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
            parentTask);
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq("Task uuid"))).thenReturn(
            parentTask);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());

        Exception testException = new Exception("Test Exception");
        Throwable caused = new Throwable("Test Exception");
        caused.initCause(testException);

        when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class)).thenReturn(caused);

        when(taskProcessorRepository.findOne(Mockito.anyLong())).thenReturn(grandParentTaskDone);

        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq("Task uuid"))).thenReturn(
            parentTaskDone);
        when(taskProcessorRepository
            .findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq(grandParentTaskDone.getUuid()))).thenReturn(
            grandParentTaskDone);

        Long[][] result = new Long[1][2];
        result[0][0] = 3L;
        result[0][1] = 4L;
        when(taskProcessorRepository
            .findTotalCompletedCountBasedOnJsonParentIds(Mockito.anyObject(), Mockito.anyObject())).thenReturn(result);

        tp.taskError(exchange);

        Assert.assertEquals(TaskStatus.ERROR, parentTaskDone.getStatus());
        Assert.assertEquals(TaskStatus.ERROR + "Error in child task", parentTaskDone.getParent().getStatus());
    }

    @Test
    public void testTaskErrorWithErrorCodeAndMsg() throws IllegalAccessException {
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("Task uuid");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
            parentTaskDone);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());

        Throwable caused = new Throwable("E10001: JSON file \"ZYZ\" is not well " + "formed.");

        when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class)).thenReturn(caused);

        when(taskProcessorRepository.findOne(grandParentTaskDone.getId())).thenReturn(grandParentTaskDone);

        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq("Task uuid"))).thenReturn(
            parentTaskDone);
        when(taskProcessorRepository
            .findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq(grandParentTaskDone.getUuid()))).thenReturn(
            grandParentTaskDone);
        Long[][] result = new Long[1][2];
        result[0][0] = 3L;
        result[0][1] = 4L;
        when(taskProcessorRepository
            .findTotalCompletedCountBasedOnJsonParentIds(Mockito.anyObject(), Mockito.anyObject())).thenReturn(result);

        tp.taskError(exchange);

        Assert.assertEquals(TaskStatus.ERROR, parentTaskDone.getStatus());
        Assert.assertEquals(TaskStatus.ERROR + "Error in child task", parentTaskDone.getParent().getStatus());
    }

    @Test
    public void testTaskErrorWithLongMessage() throws IllegalAccessException {
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("Task uuid");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq("Task uuid"))).thenReturn(
            parentTask);
        when(
            taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq(grandParentTask.getUuid())))
            .thenReturn(grandParentTask);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());
        String str = new String(new char[6000]).replace("\0", "a");

        Exception testException = new Exception(str);
        Throwable caused = new Throwable(str);
        caused.initCause(testException);

        when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class)).thenReturn(caused);
        when(taskProcessorRepository.findOne(grandParentTask.getId())).thenReturn(grandParentTask);
        Long[][] result = new Long[1][2];
        result[0][0] = 1L;
        result[0][1] = 2L;
        when(taskProcessorRepository
            .findTotalCompletedCountBasedOnJsonParentIds(Mockito.anyObject(), Mockito.anyObject())).thenReturn(result);
        tp.taskError(exchange);
        //no longer appending ingestion log msg to the task status, task status will either be 'Error: '
        // or 'Error: error in child task'
        Assert.assertEquals(TaskStatus.ERROR, parentTask.getStatus());
    }

    @Test
    public void testTaskErrorWithValidationFailedException() throws IllegalAccessException {
        when(message.getHeader(MessageConstants.TASK_UUID, String.class)).thenReturn("Task uuid");
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.anyString())).thenReturn(
            parentTask);
        when(taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq("Task uuid"))).thenReturn(
            parentTask);
        when(
            taskProcessorRepository.findByTenantUuidAndUuid(Mockito.anyString(), Mockito.eq(grandParentTask.getUuid())))
            .thenReturn(grandParentTask);
        when(taskProcessorRepository.saveAndFlush(Mockito.anyObject())).then(AdditionalAnswers.returnsFirstArg());
        when(taskProcessorRepository.findOne(grandParentTask.getId())).thenReturn(grandParentTask);

        List<com.ge.asset.commons.validator.Error> errors = new ArrayList<>();
        errors.add(
            new Error(Error.ErrorType.ERROR, "E10001", ErrorProvider.findMessage(ErrorConstants.INVALID_JSON_CODE)));
        ValidationFailedException exception = new ValidationFailedException(errors);

        when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class)).thenReturn(exception);
        Long[][] result = new Long[1][2];
        result[0][0] = 1L;
        result[0][1] = 2L;
        when(taskProcessorRepository
            .findTotalCompletedCountBasedOnJsonParentIds(Mockito.anyObject(), Mockito.anyObject())).thenReturn(result);
        tp.taskError(exchange);
        Assert.assertEquals(TaskStatus.ERROR, parentTask.getStatus());
        Assert.assertEquals(1, parentTask.getIngestionLogMsgList().size());
    }

    @After
    public void destroy() {
        exchange = null;
        message = null;
        taskProcessorRepository = null;
        parentTask = null;
    }
}
