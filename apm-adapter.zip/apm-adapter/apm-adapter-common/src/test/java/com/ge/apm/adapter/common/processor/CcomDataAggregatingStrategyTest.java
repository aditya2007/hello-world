/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.ge.apm.ccom.model.CCOMData;
import com.ge.apm.ccom.model.core.Entity;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class CcomDataAggregatingStrategyTest {

    @Mock
    private Exchange oldExchange;

    @Mock
    private Exchange newExchange;

    @Mock
    private Message oldMessage;

    @Mock
    private Message newMessage;

    private CcomDataAggregatingStrategy ccomDataAggregatingStrategy;

    @Before
    public void setUp() throws Exception {
        ccomDataAggregatingStrategy = new CcomDataAggregatingStrategy();
        MockitoAnnotations.initMocks(this);

        Mockito.when(oldExchange.getIn()).thenReturn(oldMessage);
        Mockito.when(newExchange.getIn()).thenReturn(newMessage);
    }

    @Test
    public void oldExchangeAndNewExchangeNull() {
        Assert.assertNull(ccomDataAggregatingStrategy.aggregate(null, null));
    }

    @Test
    public void oldExchangeNotNullNewExchangeNull() {
        Assert.assertEquals(oldExchange, ccomDataAggregatingStrategy.aggregate(oldExchange, null));
        verify(oldMessage).setBody(any(CCOMData.class));
    }

    @Test
    public void oldExchangeNullNewExchangeNotNull() {
        Assert.assertEquals(newExchange, ccomDataAggregatingStrategy.aggregate(null, newExchange));
        verify(newMessage).setBody(any(CCOMData.class));
    }

    @Test
    public void oldCcomDataNotNullNewCcomDataNull() {
        CCOMData oldData = new CCOMData();
        Mockito.when(oldMessage.getBody(CCOMData.class)).thenReturn(oldData);
        Assert.assertEquals(oldExchange, ccomDataAggregatingStrategy.aggregate(oldExchange, newExchange));
        verify(oldMessage).setBody(eq(oldData));
    }

    @Test
    public void oldCcomDataNullNewCcomDataNotNull() {
        CCOMData newData = new CCOMData();
        Mockito.when(newMessage.getBody(CCOMData.class)).thenReturn(newData);

        Assert.assertEquals(oldExchange, ccomDataAggregatingStrategy.aggregate(oldExchange, newExchange));
        verify(oldMessage).setBody(eq(newData));
    }

    @Test
    public void oldCcomDataNotNullNewCcomDataNotNull() {
        CCOMData oldData = new CCOMData();
        CCOMData newData = new CCOMData();
        Mockito.when(oldMessage.getBody(CCOMData.class)).thenReturn(oldData);
        Mockito.when(newMessage.getBody(CCOMData.class)).thenReturn(newData);

        Entity entity1 = mock(Entity.class);
        Entity entity2 = mock(Entity.class);
        Entity entity3 = mock(Entity.class);
        Entity entity4 = mock(Entity.class);

        oldData.getEntity().add(entity1);
        oldData.getEntity().add(entity2);
        newData.getEntity().add(entity3);
        newData.getEntity().add(entity4);

        Assert.assertEquals(oldExchange, ccomDataAggregatingStrategy.aggregate(oldExchange, newExchange));
        verify(oldMessage).setBody(eq(oldData));

        Assert.assertEquals(4, oldData.getEntity().size());
        Assert.assertTrue(oldData.getEntity().contains(entity1));
        Assert.assertTrue(oldData.getEntity().contains(entity2));
        Assert.assertTrue(oldData.getEntity().contains(entity3));
        Assert.assertTrue(oldData.getEntity().contains(entity4));
    }
}
