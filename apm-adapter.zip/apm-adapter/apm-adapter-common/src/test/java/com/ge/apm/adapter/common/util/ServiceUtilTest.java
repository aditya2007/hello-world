/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.util;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.junit.Assert;
import org.junit.Test;

import com.ge.apm.common.exception.ServiceException;
import com.ge.asset.commons.errorprovider.ErrorConstants;
import com.ge.asset.commons.errorprovider.ErrorProvider;

/**
 * Description of ServiceUtilTest
 *
 * @author Albert H. Yu 212365823
 * @version 1.0 Mar 1, 2016
 * @since 1.0
 */
public class ServiceUtilTest {

    @Test
    public void createResponse_noContent() {
        Assert.assertEquals(Response.Status.NO_CONTENT.getStatusCode(), ServiceUtil.createResponse(null).getStatus());
    }

    @Test
    public void createResponse_withServiceException() {
        ServiceException se = new ServiceException("unit test");
        Response resp = ServiceUtil.createResponse(se);
        Assert.assertEquals(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), resp.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON, resp.getMediaType().toString());
    }

    @Test
    public void createResponse_noDataFound() {
        ServiceException se = new ServiceException(ErrorProvider.findError(ErrorConstants.NO_DATA_FOUND_COMMON),
            "unit test");
        Response resp = ServiceUtil.createResponse(se);
        Assert.assertEquals(Response.Status.NOT_FOUND.getStatusCode(), resp.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON, resp.getMediaType().toString());
    }

    @Test
    public void createResponse_withOtherException() {
        Exception se = new Exception("unit test");
        Response resp = ServiceUtil.createResponse(se);
        Assert.assertEquals(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), resp.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON, resp.getMediaType().toString());
    }

    @Test
    public void createErrorResponse() {
        Response resp = ServiceUtil.createErrorResponse("unit test");
        Assert.assertEquals(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), resp.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON, resp.getMediaType().toString());
    }

    @Test
    public void createResponse_withGenericObject() {
        Object object = new Object();
        Response resp = ServiceUtil.createResponse(object);
        Assert.assertEquals(Response.Status.OK.getStatusCode(), resp.getStatus());
    }
}
