/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.when;

public class RestHeaderProcessorTest {

    @Mock
    private Exchange exchange;

    @Mock
    private Message message;

    private RestHeaderProcessor restHeaderProcessor;

    @Before
    public void setUp() {

        MockitoAnnotations.initMocks(this);
        restHeaderProcessor = new RestHeaderProcessor();
    }

    @Test
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void processTest() throws Exception {

        Map<String, Object> headers = new HashMap<String, Object>();
        headers.put("ApmTaskUuid", "051c4250-c171-4e13-85b2-e1f7dff2c41b");
        when(exchange.getIn()).thenReturn(message);
        when(message.getHeaders()).thenReturn(headers);

        restHeaderProcessor.process(exchange);

        Message actualInMsg = exchange.getIn();
        Map<String, Object> actual = actualInMsg.getHeaders();
        Assert.assertNotNull(actual.get("ApmTaskUuid"));
    }
}
