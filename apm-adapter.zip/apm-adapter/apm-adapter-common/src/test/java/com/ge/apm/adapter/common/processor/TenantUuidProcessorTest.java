/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.impl.DefaultMessage;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ge.stuf.tenant.context.TenantContext;

/**
 * Description of TenantUuidProcessorTest
 *
 * @author Deepak 212400139
 * @version 1.1 Mar 8, 2016
 * @since 1.0
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest(TenantContext.class)
public class TenantUuidProcessorTest {

    public Exchange exchange;

    public Message msgIn;

    public Message msgOut;

    public TenantContext tenCon;

    @Before
    public void setUp() {
        exchange = Mockito.mock(Exchange.class);
        msgIn = new DefaultMessage();
        msgOut = new DefaultMessage();
        Mockito.when(exchange.getIn()).thenReturn(msgIn);
        Mockito.when(exchange.getOut()).thenReturn(msgOut);
        PowerMockito.mockStatic(TenantContext.class);
    }

    @Test
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void testProcessWithTenantID() throws Exception {
        TenantUuidProcessor tenantUuidProcessorTest = new TenantUuidProcessor();
        tenCon = Mockito.mock(TenantContext.class);
        Mockito.when(TenantContext.getInstance()).thenReturn(tenCon);
        Mockito.when(tenCon.getTenantUuid()).thenReturn("Test Uuid");
        tenantUuidProcessorTest.process(exchange);
        Assert.assertNotNull(msgOut.getHeaders());
    }

    @Test(expected = IllegalStateException.class)
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void testProcessWithGetInstanceError() throws Exception {
        TenantUuidProcessor tenantUuidProcessorTest = new TenantUuidProcessor();
        tenantUuidProcessorTest.process(exchange);
        Assert.assertNotNull(msgOut.getHeaders());
    }

    @Test
    public void testProcessWithTenantIDNull() {
        TenantUuidProcessor tenantUuidProcessorTest = new TenantUuidProcessor();
        try {
            PowerMockito.when(TenantContext.getInstance()).thenReturn(null);
            tenantUuidProcessorTest.process(exchange);
        } catch (Exception e) {
            Assert.assertEquals("Tenant not found", e.getMessage());
        }
    }

    @After
    public void destroy() {
        exchange = null;
        msgIn = null;
        msgOut = null;
        tenCon = null;
    }
}
