/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.packer;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ge.apm.adapter.common.util.ReflectionUtils;
import com.ge.apm.bod.model.ActionCodeEnumeration;
import com.ge.apm.bod.model.ActionExpression;
import com.ge.apm.bod.model.BusinessObjectDocument;
import com.ge.apm.bod.model.DtoData;
import com.ge.apm.bod.model.noun.CcomPayload;
import com.ge.apm.bod.model.noun.DtoPayload;
import com.ge.apm.bod.model.util.BodFactory;
import com.ge.apm.bod.model.verb.Sync;
import com.ge.apm.ccom.model.CCOMData;

public class AssetPackerTest {

    private AssetPacker assetPacker;

    @Before
    public void setup() throws IllegalAccessException {
        assetPacker = new AssetPacker();
        ReflectionUtils.setField(AssetPacker.class, assetPacker, "bodFactory", new BodFactory());
    }

    @Test
    public void createEntities_CcomData_Null() {
        BusinessObjectDocument bod = assetPacker.createEntities((CCOMData) null);
        Assert.assertNotNull(bod);
    }

    @Test
    public void createEntities_CcomData() {
        CCOMData ccomData = new CCOMData();
        BusinessObjectDocument bod = assetPacker.createEntities(ccomData);
        Assert.assertNotNull(bod);
        Assert.assertNotNull(bod.getApplicationArea());
        Assert.assertNotNull(bod.getDataArea());
        Assert.assertTrue(bod.getDataArea().getVerb() instanceof Sync);
        Assert.assertNotNull(((Sync) bod.getDataArea().getVerb()).getActionCriteria());
        List<ActionExpression> actionExpression = ((Sync) bod.getDataArea().getVerb()).getActionCriteria()
            .getActionExpression();
        Assert.assertEquals(ActionCodeEnumeration.ADD, actionExpression.get(0).getActionCode());
        Assert.assertTrue(bod.getDataArea().getNoun() instanceof CcomPayload);
        Assert.assertEquals(ccomData, ((CcomPayload) bod.getDataArea().getNoun()).getCcomData());
    }

    @Test
    public void createEntities_DtoData_Null() {
        BusinessObjectDocument bod = assetPacker.createEntities((DtoData) null);
        Assert.assertNotNull(bod);
    }

    @Test
    public void createEntities_DtoData() {
        DtoData dtoData = new DtoData();
        BusinessObjectDocument bod = assetPacker.createEntities(dtoData);
        Assert.assertNotNull(bod);
        Assert.assertNotNull(bod.getApplicationArea());
        Assert.assertNotNull(bod.getDataArea());
        Assert.assertTrue(bod.getDataArea().getVerb() instanceof Sync);
        Assert.assertNotNull(((Sync) bod.getDataArea().getVerb()).getActionCriteria());
        List<ActionExpression> actionExpression = ((Sync) bod.getDataArea().getVerb()).getActionCriteria()
            .getActionExpression();
        Assert.assertEquals(ActionCodeEnumeration.ADD, actionExpression.get(0).getActionCode());
        Assert.assertTrue(bod.getDataArea().getNoun() instanceof DtoPayload);
        Assert.assertEquals(dtoData, ((DtoPayload) bod.getDataArea().getNoun()).getDtoData());
    }
}
