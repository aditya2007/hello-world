/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.ge.apm.asset.model.Named;
import com.ge.apm.bod.model.DtoData;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class DtoDataAggregatingStrategyTest {

    @Mock
    private Exchange oldExchange;

    @Mock
    private Exchange newExchange;

    @Mock
    private Message oldMessage;

    @Mock
    private Message newMessage;

    private DtoDataAggregatingStrategy dtoDataAggregatingStrategy;

    @Before
    public void setUp() throws Exception {
        dtoDataAggregatingStrategy = new DtoDataAggregatingStrategy();
        MockitoAnnotations.initMocks(this);

        Mockito.when(oldExchange.getIn()).thenReturn(oldMessage);
        Mockito.when(newExchange.getIn()).thenReturn(newMessage);
    }

    @Test
    public void oldExchangeAndNewExchangeNull() {
        Assert.assertNull(dtoDataAggregatingStrategy.aggregate(null, null));
    }

    @Test
    public void oldExchangeNotNullNewExchangeNull() {
        Assert.assertEquals(oldExchange, dtoDataAggregatingStrategy.aggregate(oldExchange, null));
        verify(oldMessage).setBody(any(DtoData.class));
    }

    @Test
    public void oldExchangeNullNewExchangeNotNull() {
        Assert.assertEquals(newExchange, dtoDataAggregatingStrategy.aggregate(null, newExchange));
        verify(newMessage).setBody(any(DtoData.class));
    }

    @Test
    public void oldCcomDataNotNullNewCcomDataNull() {
        DtoData oldData = new DtoData();
        Mockito.when(oldMessage.getBody(DtoData.class)).thenReturn(oldData);
        Assert.assertEquals(oldExchange, dtoDataAggregatingStrategy.aggregate(oldExchange, newExchange));
        verify(oldMessage).setBody(eq(oldData));
    }

    @Test
    public void oldCcomDataNullNewCcomDataNotNull() {
        DtoData newData = new DtoData();
        Mockito.when(newMessage.getBody(DtoData.class)).thenReturn(newData);

        Assert.assertEquals(oldExchange, dtoDataAggregatingStrategy.aggregate(oldExchange, newExchange));
        verify(oldMessage).setBody(eq(newData));
    }

    @Test
    public void oldCcomDataNotNullNewCcomDataNotNull() {
        DtoData oldData = new DtoData();
        DtoData newData = new DtoData();
        Mockito.when(oldMessage.getBody(DtoData.class)).thenReturn(oldData);
        Mockito.when(newMessage.getBody(DtoData.class)).thenReturn(newData);

        Named dto1 = mock(Named.class);
        Named dto2 = mock(Named.class);
        Named dto3 = mock(Named.class);
        Named dto4 = mock(Named.class);

        oldData.getDto().add(dto1);
        oldData.getDto().add(dto2);
        newData.getDto().add(dto3);
        newData.getDto().add(dto4);

        Assert.assertEquals(oldExchange, dtoDataAggregatingStrategy.aggregate(oldExchange, newExchange));
        verify(oldMessage).setBody(eq(oldData));

        Assert.assertEquals(4, oldData.getDto().size());
        Assert.assertTrue(oldData.getDto().contains(dto1));
        Assert.assertTrue(oldData.getDto().contains(dto2));
        Assert.assertTrue(oldData.getDto().contains(dto3));
        Assert.assertTrue(oldData.getDto().contains(dto4));
    }
}
