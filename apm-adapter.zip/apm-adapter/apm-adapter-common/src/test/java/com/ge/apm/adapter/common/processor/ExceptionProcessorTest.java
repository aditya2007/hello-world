/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.adapter.common.processor;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ge.asset.commons.mq.processor.ExceptionProcessor;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ExceptionProcessorTest {

    @Mock
    private Exchange exchange;

    @Mock
    private Message message;

    private ConcurrentLinkedQueue<Error> errors;

    private ExceptionProcessor exceptionProcessor;

    @Before
    public void setUp() {
        errors = new ConcurrentLinkedQueue<>();
        exceptionProcessor = new ExceptionProcessor(errors);
        MockitoAnnotations.initMocks(this);

        when(exchange.getIn()).thenReturn(message);
    }

    @Test
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void process() throws Exception {
        Throwable throwable = mock(Throwable.class);
        when(exchange.getProperty(eq(Exchange.EXCEPTION_CAUGHT), eq(Throwable.class))).thenReturn(throwable);
        when(message.getBody()).thenReturn("Sample Body");

        exceptionProcessor.process(exchange);

        Assert.assertEquals(1, errors.size());
        Error nextError = errors.peek();
        Assert.assertNotNull(nextError);
        Assert.assertEquals("Body: Sample Body", nextError.getMessage());
        Assert.assertEquals(throwable, nextError.getCause());
    }

    @Test
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    public void processWithoutBody() throws Exception {
        Throwable throwable = mock(Throwable.class);
        when(exchange.getProperty(eq(Exchange.EXCEPTION_CAUGHT), eq(Throwable.class))).thenReturn(throwable);
        when(message.getBody()).thenReturn(null);

        exceptionProcessor.process(exchange);

        Assert.assertEquals(1, errors.size());
        Error nextError = errors.peek();
        Assert.assertEquals(throwable, nextError.getCause());
    }
}
