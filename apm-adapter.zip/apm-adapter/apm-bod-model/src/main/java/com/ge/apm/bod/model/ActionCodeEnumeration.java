/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.bod.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "ActionCodeEnumeration")
@XmlEnum
public enum ActionCodeEnumeration {

    @XmlEnumValue("Add") ADD("Add"),
    @XmlEnumValue("Change") CHANGE("Change"),
    @XmlEnumValue("Replace") REPLACE("Replace"),
    @XmlEnumValue("Delete") DELETE("Delete");

    private final String value;

    ActionCodeEnumeration(String v) {
        value = v;
    }

    public static ActionCodeEnumeration fromValue(String value) {
        for (ActionCodeEnumeration code : ActionCodeEnumeration.values()) {
            if (code.value.equals(value)) {
                return code;
            }
        }
        throw new IllegalArgumentException(value);
    }

    public String value() {
        return value;
    }

}
