# APM Commons Logging

APM Commons Logging v 1.0.1.RELEASE

This library provides the following features:
1.	Enable distributed tracing by using Spring Sleuth
2.	Includes http request filter to ingest commons fields like tenant id in logs
3.	Emits machine readable JSON logs using log-stash
4.	Includes a standard application logging format

Usage:
1. Include this project as a dependency in your Spring Boot application
   ```
    <dependency>
     <groupId>com.ge.apm</groupId>
     <artifactId>commons-logging</artifactId>
     <version>1.0.1.RELEASE</version>
    </dependency>
   ```
2. Include "com.ge.apm.commons.logging" in your component scan path
   ```
   @SpringBootApplication(scanBasePackages = {"com.ge.apm.commons.logging" })
   ```
3. Include this in your logback.xml
   ```
   <include resource="com/ge/apm/common/logging/logback/base.xml"/>
   ```
4. Use com.ge.apm.commons.logging.Tracer to get current trace id
   - Typical Usage: 
   ```
   @Autowired
   com.ge.apm.commons.logging.Tracer tracer;
   
   String currentTraceId = tracer.getCurrentTraceId();
   ```


References:
1. https://devcloud.swcoe.ge.com/devspace/pages/viewpage.action?spaceKey=RMOCM&title=Standard+Application+Logging+Pattern#StandardApplicationLoggingPattern-CallStack(stck)

APM Commons Logging v 1.0.2.RELEASE

This library provides the following features:
1.	Includes fields subject, operation and result
2.	Support for non-http requests logging for non-http scenarios like Scheduled Jobs
     
     ```
     Example: Use com.ge.apm.commons.logging.LogEntry for non-http scenarios like Scheduled Jobs
     
     @Autowired
     com.ge.apm.commons.logging.LogEntry logEntry;
     
     try {
         logEntry.init();
         logEntry.setTenant("T1");
         logEntry.setSubject("");
         logEntry.setOperation("List");
         logEntry.setResult("Success");
         logger.info("Custom Logging Test");
     } finally {
         logEntry.clear();
     }
     ```
     
     
APM Commons Logging v 1.0.3.RELEASE

This library provides the following features:
1.  Bearer token will be masked when present in the following fields: tnt, msg, exception

    ```
    Regex: (?i)bearer [a-zA-Z0-9\\\\-_]+?\\\\.[a-zA-Z0-9\\\\-_]+?\\\\.([a-zA-Z0-9\\\\-_]+)
    
    Will match bearer, ignoring case, and replace the matching string with 'Bearer ***********'
    ```