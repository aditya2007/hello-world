rm -vrf ${WORKSPACE}/../.m2ApmCommonsLogging/repository/com/ge/apm/apm-datasource

mkdir -p ${WORKSPACE}/../.m2ApmCommonsLogging
export MAVEN_OPTS="-Dmaven.repo.local=${WORKSPACE}/../.m2ApmCommonsLogging/repository"
export JAVA_HOME=${JAVA_HOME_ORACLEJDK8}
export PATH=${JAVA_HOME}/bin:${PATH}
mvn -U clean deploy -s menlo_settings.xml
