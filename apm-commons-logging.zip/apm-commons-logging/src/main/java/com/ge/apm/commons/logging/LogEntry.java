/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.commons.logging;

import javax.annotation.PostConstruct;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class LogEntry {

    @Value("${spring.application.name:}")
    private String appName;

    @Value("${vcap.application.application_name:}")
    private String applicationName;

    @Value("${vcap.application.application_id:}")
    private String applicationId;

    @Value("${vcap.application.instance_id:}")
    private String instanceId;

    @PostConstruct
    private void postConstruct() {
        if (StringUtils.isEmpty(applicationName)) {
            applicationName = appName;
        }
    }

    public void init() {
        MDC.put("applicationName", applicationName);
        MDC.put("applicationId", applicationId);
        MDC.put("instanceId", instanceId);
    }

    public void setTenant(String tenant) {
        MDC.put("tenant", tenant);
    }

    public void setSubject(String subject) {
        MDC.put("subject", subject);
    }

    public void setOperation(String operation) {
        MDC.put("operation", operation);
    }

    public void setResult(String result) {
        MDC.put("result", result);
    }

    public void clear() {
        MDC.clear();
    }
}
