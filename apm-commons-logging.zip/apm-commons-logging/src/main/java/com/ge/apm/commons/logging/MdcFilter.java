/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.commons.logging;

import java.io.IOException;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
@Order(Ordered.LOWEST_PRECEDENCE)
public class MdcFilter extends OncePerRequestFilter {

    @Value("${spring.application.name:}")
    private String appName;

    @Value("${vcap.application.application_name:}")
    private String applicationName;

    @Value("${vcap.application.application_id:}")
    private String applicationId;

    @Value("${vcap.application.instance_id:}")
    private String instanceId;

    @PostConstruct
    private void init() {
        if (StringUtils.isEmpty(applicationName)) {
            applicationName = appName;
        }
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
        throws ServletException, IOException {
        MDC.put("tenant", request.getHeader("tenant"));
        MDC.put("applicationName", applicationName);
        MDC.put("applicationId", applicationId);
        MDC.put("instanceId", instanceId);
        MDC.put("subject", getSubject(request));
        MDC.put("operation", getOperation(request));
        try {
            filterChain.doFilter(request, response);
        } finally {
            MDC.clear();
        }
    }

    private String getSubject(HttpServletRequest request) {
        String result = "";
        try {
            String authorization = request.getHeader("Authorization");
            if (StringUtils.isNotEmpty(authorization) && StringUtils.startsWithIgnoreCase(authorization, "Bearer")) {
                int index = StringUtils.indexOfIgnoreCase(authorization, "bearer", 0);
                String token = StringUtils.substring(authorization, index + "Bearer".length());
                Jwt jwt = JwtHelper.decode(token);
                Map<String, Object> claims = new ObjectMapper().readValue(jwt.getClaims(), Map.class);
                String email = (String) claims.get("email");
                String sub = (String) claims.get("sub");
                if (StringUtils.isNotEmpty(email)) {
                    result = email;
                } else if (StringUtils.isNotEmpty(sub)) {
                    result = sub;
                }
            }
        } catch (

            Exception e)

        {
            logger.error("Error in extracting the subject", e);
        }
        return result;
    }

    private String getOperation(HttpServletRequest request) {
        StringBuilder buffer = new StringBuilder();
        buffer.append(request.getMethod());
        buffer.append(" ");
        buffer.append(request.getRequestURI());
        if (StringUtils.isNotEmpty(request.getQueryString())) {
            buffer.append("?").append(request.getQueryString());
        }
        return buffer.toString();
    }

}