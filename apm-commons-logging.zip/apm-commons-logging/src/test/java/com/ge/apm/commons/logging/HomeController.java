/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.commons.logging;

import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;
import java.nio.charset.Charset;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
class HomeController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private Tracer tracer;

    @Autowired
    private LogEntry logEntry;

    @GetMapping(value = "/no-headers", produces = "application/json")
    public String noHeaders() throws Exception {

        PipedOutputStream pipeOut = new PipedOutputStream();
        PipedInputStream pipeIn = new PipedInputStream(pipeOut);
        System.setOut(new PrintStream(pipeOut));

        logger.info("No Headers Test");

        pipeOut.close();

        String result = StreamUtils.copyToString(pipeIn, Charset.defaultCharset());

        pipeIn.close();

        return result;
    }

    @GetMapping(value = "/standard-logging", produces = "application/json")
    public String standardLogging() throws Exception {

        PipedOutputStream pipeOut = new PipedOutputStream();
        PipedInputStream pipeIn = new PipedInputStream(pipeOut);
        System.setOut(new PrintStream(pipeOut));

        logger.info("Standard Logging Format Test");

        pipeOut.close();

        String result = StreamUtils.copyToString(pipeIn, Charset.defaultCharset());

        pipeIn.close();

        return result;
    }

    @GetMapping(value = "/custom-logging", produces = "application/json")
    public String customLogging() throws Exception {

        PipedOutputStream pipeOut = new PipedOutputStream();
        PipedInputStream pipeIn = new PipedInputStream(pipeOut);
        System.setOut(new PrintStream(pipeOut));

        try {
            logEntry.init();
            logEntry.setTenant("T1");
            logEntry.setSubject("Joe");
            logEntry.setOperation("List");
            logEntry.setResult("Success");
            logger.info("Custom Logging Test");
        } finally {
            logEntry.clear();
        }

        pipeOut.close();

        String result = StreamUtils.copyToString(pipeIn, Charset.defaultCharset());

        pipeIn.close();

        return result;
    }

    @GetMapping(value = "/mask-logging", produces = "application/json")
    public String maskLogging() throws Exception {

        PipedOutputStream pipeOut = new PipedOutputStream();
        PipedInputStream pipeIn = new PipedInputStream(pipeOut);
        System.setOut(new PrintStream(pipeOut));

        try {
            logEntry.init();
            logEntry.setTenant(IntegrationTest.BEARER_TOKEN);
            logger.info("Mask Logging Format Test" + IntegrationTest.BEARER_TOKEN + ", nothing to see here");
        } finally {
            logEntry.clear();
        }

        pipeOut.close();

        String result = StreamUtils.copyToString(pipeIn, Charset.defaultCharset());

        pipeIn.close();

        return result;
    }
}
