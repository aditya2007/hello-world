/********************************************************************************
 * Copyright (c) 2015-2017 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

package com.ge.apm.commons.logging;

import com.jayway.restassured.RestAssured;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.core.IsNull.notNullValue;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = Application.class)
@TestPropertySource(locations = "classpath:application-test.yml")
@Profile("test")
@ActiveProfiles("test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class IntegrationTest {

    @Value("${local.server.port}")
    protected int port;


    @Before
    public void setUp() throws Exception {
        RestAssured.port = port;
        RestAssured.basePath = "";
    }

    public static final String BEARER_TOKEN =
        "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ"
            + ".eyJqdGkiOiI1YzM1ZTE4NGEzNzc0YTg3OTNmOWUxY2EzMGI4NTg4ZCIsInN1YiI6IjIxYTk"
            + "yODg3LTU3Y2YtNDY5ZS1iODZkLTg2NTJmMzMzNzBjNyIsInNjb3BlIjpbInBhc3N3b3JkLnd"
            + "yaXRlIiwib3BlbmlkIl0sImNsaWVudF9pZCI6ImluZ2VzdG9yLjQ5NmJiNjQxLTc4YjUtNGE"
            + "xOC1iMWI3LWZkZTI5Nzg4ZGIzOC45OTFlNWMyMy0zZTljLTQ5NDQtYjA4Yi05ZTgzZWYwYWI"
            + "1OTgiLCJjaWQiOiJpbmdlc3Rvci40OTZiYjY0MS03OGI1LTRhMTgtYjFiNy1mZGUyOTc4OGR"
            + "iMzguOTkxZTVjMjMtM2U5Yy00OTQ0LWIwOGItOWU4M2VmMGFiNTk4IiwiYXpwIjoiaW5nZXN"
            + "0b3IuNDk2YmI2NDEtNzhiNS00YTE4LWIxYjctZmRlMjk3ODhkYjM4Ljk5MWU1YzIzLTNlOWM"
            + "tNDk0NC1iMDhiLTllODNlZjBhYjU5OCIsImdyYW50X3R5cGUiOiJwYXNzd29yZCIsInVzZXJ"
            + "faWQiOiIyMWE5Mjg4Ny01N2NmLTQ2OWUtYjg2ZC04NjUyZjMzMzcwYzciLCJvcmlnaW4iOiJ"
            + "1YWEiLCJ1c2VyX25hbWUiOiI5YWExZjMwZS03OTk3LTRhYjItYTI3Yi01MWI3YjcxNzlmMzR"
            + "faW5nZXN0b3IiLCJlbWFpbCI6IjlhYTFmMzBlLTc5OTctNGFiMi1hMjdiLTUxYjdiNzE3OWY"
            + "zNF9pbmdlc3RvckBhcG1kZXYuaW50LWFwcC5hd3MtdXN3MDItcHIucHJlZGl4LmlvIiwiYXV"
            + "0aF90aW1lIjoxNTE5MTYzMzQzLCJyZXZfc2lnIjoiYzkxMjQzMDQiLCJpYXQiOjE1MTkxNjM"
            + "zNDMsImV4cCI6MTUxOTI0OTc0MywiaXNzIjoiaHR0cHM6Ly9kMTczMGFkZS03YzBkLTQ2NTI"
            + "tOGQ0NC1jYjU2M2ZjYzFlMjcucHJlZGl4LXVhYS5ydW4uYXdzLXVzdzAyLXByLmljZS5wcmV"
            + "kaXguaW8vb2F1dGgvdG9rZW4iLCJ6aWQiOiJkMTczMGFkZS03YzBkLTQ2NTItOGQ0NC1jYjU"
            + "2M2ZjYzFlMjciLCJhdWQiOlsiaW5nZXN0b3IuNDk2YmI2NDEtNzhiNS00YTE4LWIxYjctZmR"
            + "lMjk3ODhkYjM4Ljk5MWU1YzIzLTNlOWMtNDk0NC1iMDhiLTllODNlZjBhYjU5OCIsInBhc3N"
            + "3b3JkIiwib3BlbmlkIl19.tOd9ZSHfYUL9f_IIrUJsApKJmsJ4E1tPi3284gKTTJbIFyKNn0"
            + "VfgRZF2kwEPrT-QagHHCCoGr3_Rw_V79vd6K2Wo15UJ_Q_FBpnyaq0ItaY6PSM5MgHpYMx5r"
            + "fJKaecP1l2IQvYpNsO0pua8JfzO9J1ytT3r4mujBzbXLKzqKWIJ9SS4CRpE2x8EeGBycT8c3"
            + "EApTmiqmyk-XPnrHAo9sATlmrBIkGkjohCWa3yUeouePvQ4xS5DMD0NOgxXlIH75yMSUJ6eo"
            + "vZ865ch32BWkyhVLFuP3-b4huam2URRffq0DUxkm--H9uRMVVDKFeqQ5QoOr8ASupJkYnRkcbbNg";

    @Test
    public void noHeadersTest() throws Exception {
        given().
            when().get("/no-headers?q=search").prettyPeek().then().statusCode(200).body("appn",
            is(equalTo("Sample Logging Client"))).body("tnt", is(equalTo(""))).body("subj", is(notNullValue())).body(
            "oper", is(equalTo("GET /no-headers?q=search"))).body("corr", is(notNullValue())).body("span",
            is(notNullValue())).body("msg", is(equalTo("No Headers Test")));
    }

    @Test
    public void standardLoggingTest() throws Exception {
        given().
            header("tenant", "t1").
            header("Authorization", BEARER_TOKEN).
            when().get("/standard-logging").prettyPeek().then().statusCode(200).body("time", is(notNullValue())).body(
            "time", is(notNullValue())).body("tnt", is(equalTo("t1"))).body("corr", is(notNullValue())).body("appn",
            is(equalTo("Sample Logging Client"))).body("subj",
            is(equalTo("9aa1f30e-7997-4ab2-a27b-51b7b7179f34_ingestor@apmdev.int-app.aws-usw02-pr.predix.io"))).body(
            "oper", is(equalTo("GET /standard-logging"))).body("dpmt", is(equalTo(""))).body("inst", is(equalTo("")))
            .body("span", is(notNullValue())).body("prnt", is(equalTo(""))).body("expt", is(equalTo("false"))).body(
            "tid", is(notNullValue())).body("mod", is(equalTo("com.ge.apm.commons.logging.HomeController"))).body("lvl",
            is(equalTo("INFO"))).body("msg", is(equalTo("Standard Logging Format Test"))).body("exception",
            is(equalTo("")));
    }

    @Test
    public void customLoggingTest() throws Exception {
        given().
            when().get("/custom-logging").prettyPeek().then().statusCode(200).body("time", is(notNullValue())).body(
            "time", is(notNullValue())).body("tnt", is(equalTo("T1"))).body("corr", is(notNullValue())).body("appn",
            is(equalTo("Sample Logging Client"))).body("subj", is(equalTo("Joe"))).body("oper", is(equalTo("List")))
            .body("rslt", is(equalTo("Success"))).body("dpmt", is(equalTo(""))).body("inst", is(equalTo(""))).body(
            "span", is(notNullValue())).body("prnt", is(equalTo(""))).body("expt", is(equalTo("false"))).body("tid",
            is(notNullValue())).body("mod", is(equalTo("com.ge.apm.commons.logging.HomeController"))).body("lvl",
            is(equalTo("INFO"))).body("msg", is(equalTo("Custom Logging Test"))).body("exception", is(equalTo("")));
    }

    @Test
    public void maskLoggingTest() throws Exception {
        given().
            header("tenant", "t1").
            header("Authorization", BEARER_TOKEN).
            when().get("/mask-logging").prettyPeek().then().statusCode(200).body("time", is(notNullValue())).body(
            "time", is(notNullValue())).body("tnt", is(equalTo("Bearer ***********"))).body("corr", is(notNullValue()))
            .body("appn", is(equalTo("Sample Logging Client"))).body("subj",
            is(equalTo("9aa1f30e-7997-4ab2-a27b-51b7b7179f34_ingestor@apmdev.int-app.aws-usw02-pr.predix.io"))).body(
            "oper", is(equalTo("GET /mask-logging"))).body("dpmt", is(equalTo(""))).body("inst", is(equalTo("")))
            .body("span", is(notNullValue())).body("prnt", is(equalTo(""))).body("expt", is(equalTo("false"))).body(
            "tid", is(notNullValue())).body("mod", is(equalTo("com.ge.apm.commons.logging.HomeController"))).body("lvl",
            is(equalTo("INFO"))).body("msg", is(equalTo("Mask Logging Format TestBearer ***********, nothing to see here"))).body
            ("exception",
                is(equalTo("")));
    }
}
